# Synthèse de vérification fournie par l'utilisateur (Vial), 24.10.2026 18:21 — LOT_004 (SSP / DX.1–DX.10)

### SSP — Posologies de référence
- Ferinject® (carboxymaltose ferrique) : schéma simplifié selon Hb/poids ou Ganzoni. Hb < 10 g/dL : 1500 mg (35–<70 kg) ou 2000 mg (≥70 kg) ; Hb 10–14 : 1000/1500 mg ; carence sans anémie : 500 mg. Dose unitaire max 1000 mg (ou 20 mg/kg en perfusion / 15 mg/kg en IVD), max 1000 mg/semaine ; intervalle ≥7 jours si besoin supérieur. Vitesse : ≥6 min (>200–500 mg), ≥15 min (>500–1000 mg) ; surveillance ≥30 min.
- Fer oral : 80–100 mg/j (jusqu'à 200 mg) de fer élémentaire, ou 60–100 mg un jour sur deux (meilleure absorption fractionnelle, moins d'effets digestifs via hepcidine).
- Lévothyroxine : 1,6 µg/kg/j (poids idéal si obésité) à jeun ≥30 min avant petit-déjeuner ; initiation 50–100 µg chez le jeune sain. Sujet âgé/coronarien : start low (12,5–25 µg), paliers 12,5–25 µg / 4–6 sem.
- Sertraline : 50 mg/j (dépression/TOC) ; 25 mg/j pendant 1 sem puis 50 mg (panique/TSPT/anxiété sociale). Titration +50 mg / ≥1 sem, max 200 mg/j.
Sources : Swissmedic/Compendium.ch (Ferinject®, Euthyrox®/Tirosint®, Zoloft®) ; Stoffel et al. Lancet Haematol 2017 (PMID 29032957) ; ATA 2014 (PMID 25266247).

### DX.1 — Ganzoni et première perfusion ≤500 mg
Formule : déficit total (mg) = poids (kg) × (Hb cible − Hb actuelle) [g/dL] × 2,4 + réserves (500 mg si ≥35 kg). Hb cible 15 g/dL (≥35 kg). Poids idéal (IMC 25) en cas d'obésité.
Swissmedic autorise jusqu'à 1000 mg (≤20 mg/kg) chez ≥50 kg. Le plafond clinique ≤500 mg en première perfusion concerne surtout la carence martiale sans anémie (IDWA) ou les petits poids/tolérance, afin de limiter le risque d'hypophosphatémie FGF-23 liée au carboxymaltose ferrique.
Sources : Ganzoni 1970 (PMID 5413918) ; Swissmedic/Compendium ; Nowak et al. Swiss Med Wkly 2019 (PMID 31269224) ; Wolf et al. JAMA 2020 (PMID 32016310).

### DX.2 — ISRS / venlafaxine, Spravato®, PHQ-9
Doses usuelles Swissmedic (initiation → entretien → max) : escitalopram 10→10–20 mg (max 10 mg >65 ans) ; citalopram 20→20–40 mg (max 20 mg >65 ans) ; sertraline 50→50–150 mg (max 200) ; fluoxétine 20→20–40/60 mg (max 80) ; paroxétine 20→20–40 mg (max 50–60) ; fluvoxamine 50→100–200 mg (max 300) ; venlafaxine 75→75–225 mg (max 375 ; effet IRSN ≥150 mg).
Spravato® (eskétamine) : autorisé Swissmedic (cat. A). Indications : TRD (≥2 antidépresseurs) et urgence dépressive aiguë. Remboursement AOS sous Limitation stricte (entrée SL ~1er octobre 2025) : 18–74 ans, CGI-S ≥5, échec de 2 AD + 1 augmentation, ECT non indiquée/refusée/inaccessible, centres BAG désignés (~52), après garantie de prise en charge (médecin-conseil), max ~10 mois. Administration sous surveillance médicale.
PHQ-9 (0–27) : 0–4 minimal ; 5–9 léger ; 10–14 modéré (seuil de dépistage ≥10 : Se/Sp ≈88 %) ; 15–19 modérément sévère ; 20–27 sévère.
Sources : Compendium.ch / Swissmedic ; BAG Spezialitätenliste ; Kroenke et al. J Gen Intern Med 2001 (PMID 11556941).

### DX.3 — Règle OPAS et statut tirzépatide / AD109
Observance CPAP (OPAS / LiMA 14.05, SSP) : ≥4 h/nuit sur ≥70 % des nuits (relevé objectif) pour maintien du remboursement, avec amélioration clinique (Epworth) et IAH résiduel <10/h.
Tirzépatide (Mounjaro®) : autorisé Swissmedic pour DT2 (2022) et contrôle chronique du poids (extension 09.07.2024) si IMC ≥30 ou ≥27 + ≥1 comorbidité liée au poids. Le SAOS est explicitement cité parmi les comorbidités qualifiantes. Pas d'indication isolée sans surpoids. Posologie : 2,5 mg/sem ×4 sem → 5 mg, puis +2,5 mg / ≥4 sem jusqu'à 10 ou 15 mg/sem.
AD109 (aroxybutynine + atomoxétine) : médicament expérimental. NDA acceptée par la FDA (juillet 2026, PDUFA 28.02.2027). Non autorisé en Suisse (Swissmedic), ni EMA.
Sources : OPAS/LiMA ; Swissmedic SwissPAR Mounjaro® (2024) ; Malhotra et al. NEJM 2024 (PMID 38912654) ; données Apnimed / FDA 2026.

### DX.4 — Lévothyroxine et seuil ETA de 70 ans
ETA 2013 (hypothyroïdie infraclinique) : seuil d'âge ~70 ans. <70 ans : traiter si TSH ≥10 mUI/L ; essai 3–6 mois si TSH 4–10 + symptômes. ≥70 ans : abstention (« wait-and-see ») si TSH 4–10 (valeurs jusqu'à 7–8 peuvent être physiologiques) ; traitement seulement si symptômes francs ou risque CV élevé si TSH ≥10. Cibles TSH sous traitement : 0,4–2,5 mUI/L (<70 ans), 1–5 mUI/L (>70 ans). Posologie franche : 1,5–1,8 µg/kg/j (standard 1,6) ; initiation basse chez l'âgé/coronarien.
Sources : Pearce et al. Eur Thyroid J 2013 (PMID 24783053) ; Stott et al. TRUST NEJM 2017 (PMID 28402245).

### DX.5 — Éruption 29,5 % et étude de Dubbo 12 %
- Éruption sous amoxicilline dans la mononucléose (EBV) : 29,5 % (IC 95 % 18,5–42,6 %) selon Chovel-Sella et al. (Pediatrics 2013, PMID 23589810), contre 23 % d'éruption virale spontanée et 80–100 % historique sous ampicilline. Non allergique IgE définitive dans la majorité des cas.
- Dubbo Infection Outcomes Study (Hickie et al. BMJ 2006, PMID 16950834) : 253 patients (EBV, Ross River, C. burnetii). À 6 mois : 11–12 % remplissent les critères d'EM/SFC (27 % à 3 mois, 9 % à 12 mois). Incidence identique quel que soit le pathogène ; seul prédicteur = sévérité de la phase aiguë.

### DX.6 à DX.10 — NT-proBNP, posologies ciblées, crises d'Addison, Plenadren®
- NT-proBNP (ESC 2021/2023) : exclusion (VPN) <125 pg/mL en ambulatoire (VPN 94–98 %) ; <300 pg/mL en aigu (VPN 98–99 %). Rule-in aigu ajusté à l'âge : >450 (<50 ans), >900 (50–75), >1800 (>75).
- Finérénone : si K⁺ ≤4,8 : DFGe ≥60 → 20 mg/j ; 25–<60 → 10 mg/j. Titration à 20 mg (ou jusqu'à 40 mg en IC si DFGe ≥60).
- Pembrolizumab : 200 mg Q3W ou 400 mg Q6W IV (perfusion 30 min).
- Ivabradine : 5 mg 2×/j (2,5 mg si ≥75 ans ou POTS) ; ajustement selon FC cible 50–60 bpm, max 7,5 mg 2×/j.
- Midodrine : initiation 2,5 mg 2–3×/j ; entretien 5–10 mg 3×/j ; max ~30 mg/j. Dernière prise ≥4 h avant le coucher (risque d'HTA de décubitus).
- Naltrexone faible dose (LDN) : off-label, titration lente 0,5–1,5 mg → 3–4,5 mg/j (modulateur TLR4 / rebond endorphinique).
- Crises d'Addison : 8,3 / 100 patients-années (Hahner et al. JCEM 2015, PMID 25419882 ; 64 crises / 767,5 PA) ; mortalité spécifique 0,5 / 100 PA. Déclencheurs principaux : gastro-entérite, fièvre, stress émotionnel (~20 % chacun).
- Plenadren® : autorisé Swissmedic (cat. B, hydrocortisone à libération modifiée 5/20 mg). Remboursement sous Limitation (après garantie de prise en charge) pour insuffisance surrénalienne primaire avec fatigue/QoL insuffisante sous hydrocortisone conventionnelle ≥6 mois ; prescription réservée aux endocrinologues hospitaliers (centres cat. A/B). Posologie : 20–30 mg en une prise matinale à jeun. PK non linéaire : en intercurrent, répéter la dose plutôt que simplement doubler la prise unique.
Sources : McDonagh et al. Eur Heart J 2021 (PMID 34447992) ; Compendium.ch (Kerendia®, Keytruda®, Procoralan®, Gutron®, Plenadren®) ; Younger et al. Clin Rheumatol 2014 (PMID 24526250) ; Hahner 2015 ; BAG/Swissmedic.
