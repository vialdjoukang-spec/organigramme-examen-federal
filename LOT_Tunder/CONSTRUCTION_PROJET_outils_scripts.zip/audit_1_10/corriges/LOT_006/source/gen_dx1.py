# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.1 · Infections respiratoires hautes et basses (LOT 6, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('dx1')
M = meta('dx1', 'DX.1', 'Infections respiratoires', 'Infections des voies respiratoires hautes et basses (rhinopharyngite, angine, sinusite, bronchite, pneumonie)',
         'LOT_006_DX1_Infections_respiratoires_AUDITÉ.html')
PAC = T('pneumonie acquise en communauté (PAC)', 'La PAC est une infection du tissu pulmonaire contractée hors de l’hôpital, ou dans les 48 premières heures d’une hospitalisation.')
ALV = T('alvéole', 'L’alvéole est le petit sac terminal du poumon où l’oxygène passe dans le sang ; quand elle se remplit de pus, l’échange gazeux baisse.')
CONDENS = T('syndrome de condensation', 'Le syndrome de condensation regroupe les signes d’un poumon rempli de liquide : matité à la percussion, vibrations vocales augmentées, souffle tubaire et râles crépitants.')
CRB = T('score CRB-65', 'Le CRB-65 compte 1 point pour chacun : Confusion récente, fréquence Respiratoire ≥ 30/min, pression artérielle (Blood pressure) systolique < 90 ou diastolique ≤ 60 mmHg, âge ≥ 65 ans.')
PTS = []

# ---------- 1
PTS.append(POINT(1, 'Définition et sémantique',
 P('Une infection respiratoire aiguë est une maladie de moins de 21 jours qui touche les voies respiratoires : toux, mal de gorge, fièvre, expectorations, dyspnée ou douleur thoracique. '
   'Les formes hautes (nez, sinus, pharynx) sont surtout virales et guérissent seules. '
   f'La forme basse grave est la {PAC}, définie par des symptômes respiratoires ET un nouvel infiltrat à l’imagerie.', 11, 10) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Rhinopharyngite', 'Inflammation virale du nez et du pharynx', 'Sinusite bactérienne (évolution ≥ 10 jours ou « double aggravation »)'],
    ['Pharyngite (angine)', 'Inflammation de la gorge, virale dans la majorité des cas', 'Angine à streptocoque du groupe A, seule à justifier un antibiotique'],
    ['Bronchite aiguë', 'Infection des bronches, toux sans infiltrat', 'Pneumonie (infiltrat à l’imagerie)'],
    ['Pneumonie', 'Infection des alvéoles avec infiltrat nouveau', 'Œdème pulmonaire, embolie, atélectasie'],
    ['Syndrome grippal', 'Fièvre, myalgies, céphalées, toux, d’origine virale', 'Sepsis débutant'],
   ]), 11, 10)))

# ---------- 2
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, l’OFSP a enregistré en 52 semaines 1 079 infections invasives à pneumocoque (11,9 pour 100 000 habitants) et 580 légionelloses (6,4 pour 100 000). '
   'En Europe, aux Pays-Bas, la pneumonie bactérienne explique 27,2 % des adultes consultant les urgences pour fièvre. '
   'Le pourcentage « 40 % des fièvres » de l’original n’a été retrouvé dans aucune source et il est retiré.', 25, 49, 99) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Infections invasives à pneumocoque', '11,9/100 000 par an', 'Suisse, déclarations OFSP, 52 semaines'],
    ['Légionellose', '6,4/100 000 (580 cas) ; 5,5/100 000 en 2024', 'Suisse, OFSP'],
    ['Pneumonie hospitalisée', '24,8/10 000 adultes par an ; 164,3/10 000 dès 80 ans', 'États-Unis (étude EPIC)'],
    ['Germe identifié', '38 % des pneumonies hospitalisées', 'Même étude'],
    ['Mortalité à 30 jours selon le CURB-65', '0,7 % (0 point) à 57 % (5 points)', 'Cohortes britannique, néerlandaise et néo-zélandaise'],
   ], 'Le facteur de risque principal est l’âge : l’incidence de la pneumonie hospitalisée augmente avec l’âge pour chaque germe.') +
   P('Les facteurs de terrain sont l’âge ≥ 65 ans, la BPCO, le tabac, l’immunosuppression et l’alcool. '
     'Le pronostic dépend surtout de la gravité initiale, que mesure le score CURB-65.', 60, 59), 25, 27, 60, 59)))

# ---------- 3
PTS.append(POINT(3, 'Physiopathologie',
 P('Un virus ou une bactérie franchit les défenses du nez et des bronches : mucus, cils, toux. '
   f'Les macrophages libèrent IL-1, IL-6 et TNF-α, qui dilatent les capillaires et remplissent l’{ALV} d’exsudat. '
   'Les mêmes cytokines remontent le thermostat de l’hypothalamus par la prostaglandine E2, d’où la fièvre.', 53, 10) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Voies hautes (nez, sinus, pharynx) séparées des voies basses (bronches, alvéoles) par le larynx.'],
    ['Physiologie', 'Le tapis de cils et la toux évacuent les germes ; l’alvéole échange l’oxygène.'],
    ['Physiopathologie', 'Le germe colonise, les cytokines provoquent exsudat, toux et fièvre ; l’alvéole pleine n’échange plus l’oxygène.'],
    ['Clinique', 'D’où la toux productive, la fièvre, la tachypnée, les crépitants et la baisse de la SpO2.'],
    ['Examens', 'L’imagerie montre l’alvéole remplie (infiltrat) ; la CRP et la procalcitonine mesurent la réponse inflammatoire.'],
    ['Traitement', 'Comme la majorité des formes hautes est virale, l’antibiotique est réservé à la pneumonie et à l’angine streptococcique prouvée.'],
   ]), 53, 11, 10) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Infection virale des voies hautes', 'Clinique seule', 'Traitement symptomatique'],
    ['Angine à streptocoque A', 'Score de Centor puis test rapide', 'Pénicilline V ou amoxicilline 6 jours'],
    ['Exsudat alvéolaire bactérien', 'Radiographie ou échographie pulmonaire', 'Amoxicilline ± acide clavulanique'],
    ['Hypoxémie', 'SpO2, gaz du sang', 'Oxygène'],
    ['Germe intracellulaire (légionelle)', 'Antigène urinaire, PCR', 'Macrolide ou quinolone'],
   ]), 10, 12) +
 F('Score de gravité CRB-65 / CURB-65 : calcul',
   TAB(['Critère (1 point chacun)', 'Seuil'], [
    ['Confusion', 'Récente'],
    ['Urée (CURB-65 seulement, à l’hôpital)', '> 7 mmol/L'],
    ['Fréquence respiratoire', '≥ 30/min'],
    ['Pression artérielle', 'Systolique < 90 mmHg ou diastolique ≤ 60 mmHg'],
    ['Âge', '≥ 65 ans'],
   ], 'Mortalité à 30 jours (CURB-65) : 0 point 0,7 % ; 1 point 3,2 % ; 2 points 3 % ; 3 points 17 % ; 4 points 41,5 % ; 5 points 57 %.') +
   P('Exemple de l’original : homme de 72 ans (1 point), confus (1 point), urée 8,2 mmol/L (1 point), pression 110/70 mmHg, fréquence respiratoire 22/min. '
     'Le CURB-65 vaut 3 : la mortalité attendue est d’environ 17 % et le patient est hospitalisé avec surveillance rapprochée.', 59, 10), 59, 10)))

# ---------- 4
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin cherche d’abord une urgence : SpO2 < 92 %, fréquence respiratoire ≥ 30/min, pression systolique < 90 mmHg, confusion, stridor ou hémoptysie. '
   'Il sépare ensuite les formes hautes, presque toujours virales, des formes basses. '
   'Devant une forme basse, il cherche la pneumonie, puis les causes non infectieuses : œdème pulmonaire, embolie pulmonaire.', 11, 10) +
 F('Diagnostic différentiel des germes (fréquences en exposant rouge, même unité : % des adultes hospitalisés pour pneumonie, étude EPIC)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Pneumonie virale (tous virus)' + PR('23 %', 60), 'Saison hivernale, entourage malade', 'PCR sur frottis nasopharyngé'],
    ['Rhinovirus' + PR('9 %', 60), 'Rhume préalable', 'PCR multiplex'],
    ['Grippe' + PR('6 %', 60), 'Début brutal, myalgies, épidémie', 'PCR grippe'],
    ['Pneumonie bactérienne (toutes bactéries)' + PR('11 %', 60), 'Fièvre élevée, frissons, foyer', 'Hémocultures, antigènes urinaires'],
    ['Pneumocoque' + PR('5 %', 60), 'Début brutal, douleur pleurale', 'Antigène urinaire pneumocoque'],
    ['Aucun germe identifié' + PR('62 %', 60), 'Cas le plus fréquent', 'Le traitement reste probabiliste'],
    ['Œdème pulmonaire, embolie pulmonaire', 'Pas de fièvre durable, contexte cardiaque ou thrombotique', 'BNP, D-dimères, scanner'],
   ]) + P('Ces fréquences décrivent des adultes hospitalisés aux États-Unis ; elles ne sont pas des probabilités devant un patient ambulatoire. '
          'La valeur « 62 % » est calculée à partir des 38 % de germes identifiés. '
          'Pour l’œdème et l’embolie, aucune fréquence dans cette même population n’a été retrouvée.', 60), 60)))

# ---------- 5
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise la durée, la toux, la dyspnée, l’âge, les comorbidités, l’exposition à l’eau tiède en aérosol et les antibiotiques récents.', 11, 10) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis quand toussez-vous ?', 'Une toux > 3 semaines sort du cadre aigu.', 'Penser à la tuberculose, à la coqueluche.'],
    ['Êtes-vous essoufflé au repos ?', 'Signe d’atteinte alvéolaire.', 'SpO2 et imagerie.'],
    ['Avez-vous mal en respirant profondément ?', 'Douleur pleurale.', 'Pneumonie ou embolie.'],
    ['Avez-vous séjourné à l’hôtel, au spa ?', 'Exposition à la légionelle.', 'Antigène urinaire légionelle.'],
    ['Avez-vous pris un antibiotique ces 3 derniers mois ?', 'Risque de résistance.', 'Choix de l’antibiotique.'],
    ['Avez-vous mal à la gorge sans toux ?', 'Profil d’angine streptococcique.', 'Score de Centor.'],
   ]), 10, 12) +
 U('<b>Drapeaux rouges (urgence, 144 ou hospitalisation)</b> : mauvaise impression générale, pression systolique < 90 mmHg, fréquence respiratoire ≥ 30/min, SpO2 < 92 %, hémoptysie, stridor, maladie pulmonaire sévère, immunodéficience sévère.', 11)))

# ---------- 6
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen mesure d’abord les constantes : température, pouls, pression, fréquence respiratoire et SpO2. '
   'Il inspecte la gorge, palpe les ganglions cervicaux, percute et ausculte le thorax de façon symétrique. '
   'Un examen pulmonaire normal n’exclut pas une pneumonie, d’où l’imagerie si les constantes sont anormales.', 10, 11) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Fréquence respiratoire (compter 30 secondes)', '12–20/min', '≥ 22/min : tester la CRP ; ≥ 30/min : critère de gravité'],
    ['SpO2 à l’air', '≥ 95 %', '< 92 % : hospitalisation à envisager ; < 90 % : hypoxémie'],
    ['Percussion du thorax', 'Sonorité égale des deux côtés', 'Matité localisée : condensation ou épanchement'],
    ['Auscultation', 'Murmure vésiculaire symétrique', 'Crépitants localisés, souffle tubaire : condensation'],
    ['Gorge et ganglions', 'Amygdales sans exsudat', 'Exsudat et ganglions sensibles : points du score de Centor'],
   ]) + P('La valeur de chaque signe isolé est modeste : aucun ne confirme ni n’exclut seul une pneumonie ; c’est l’association avec les constantes qui guide l’imagerie.', 11, 10), 10, 11)))

# ---------- 7
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les symptômes sont la toux, les expectorations, la dyspnée, la douleur thoracique, le mal de gorge et la fièvre. '
   f'Les signes physiques sont la tachypnée, les crépitants et le {CONDENS}. '
   'Chez la personne âgée, la confusion peut être le seul signe.', 10, 11) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme'], [
    ['Syndrome de condensation alvéolaire', 'Matité, crépitants, souffle tubaire, fièvre', 'Alvéoles remplies d’exsudat'],
    ['Syndrome catarrhal des voies hautes', 'Rhinorrhée, obstruction nasale, pharynx rouge, fébricule', 'Inflammation virale de la muqueuse'],
    ['Syndrome angineux', 'Mal de gorge, exsudat, ganglions sensibles', 'Infection des amygdales'],
    ['Syndrome bronchique', 'Toux, râles bronchiques, pas de foyer', 'Inflammation des bronches'],
   ]) + P('Termes : ' + CRB + ', ' + T('souffle tubaire', 'Le souffle tubaire est un bruit rude entendu à l’auscultation, parce que le poumon condensé transmet le son des grosses bronches.') + ', '
          + T('râles crépitants', 'Les crépitants sont de fins craquements en fin d’inspiration, produits par l’ouverture d’alvéoles remplies de liquide.') + '.', 10), 10, 11)))

# ---------- 8
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Selon la Société suisse d’infectiologie (SSI, recommandation PAC), la pneumonie est retenue avec un nouvel infiltrat à l’imagerie ET des symptômes d’infection respiratoire basse. '
   'La gravité se mesure par le CRB-65 en ambulatoire ; plus de 2 points indiquent une pneumonie sévère. '
   'La clinique seule ne suffit pas à poser le diagnostic de pneumonie, et une CRP élevée seule non plus.', 10) +
 F('Critères retenus (SSI 2024–2025 ; Centor pour l’angine)',
   TAB(['Situation', 'Critère', 'Conséquence'], [
    ['Pneumonie', 'Infiltrat nouveau + symptômes respiratoires bas', 'Antibiotique'],
    ['Hospitalisation', 'CRB-65 ≥ 1 (sauf âge seul), SpO2 < 90 %, comorbidité instable', 'Hôpital'],
    ['Angine', 'Centor 3–4 et test rapide positif', 'Antibiotique 6 jours'],
    ['Sinusite bactérienne', '≥ 10 jours sans amélioration, ou fièvre ≥ 39 °C avec pus 3–4 jours, ou double aggravation', 'Antibiotique à discuter'],
    ['Bronchite', 'Toux, pas d’infiltrat, CRP < 50 mg/L', 'Pas d’antibiotique'],
   ]), 10, 12, 13, 11)))

# ---------- 9
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Radiographie du thorax face et profil', 'Infiltrat nouveau, donc pneumonie', 'Sensibilité limitée, d’où l’échographie pulmonaire possible', 'Pneumonie centrale mal vue en échographie'],
    ['Scanner thoracique', 'Référence d’imagerie en cas de doute', 'Meilleure sensibilité que la radiographie ; chiffres exacts non retenus ici', 'Irradiation, coût'],
    ['Test rapide streptocoque A', 'Angine streptococcique', 'Valeurs non chiffrées par la SSI', 'Inutile si Centor 0–2'],
   ]) + P('Il n’existe pas d’examen microbiologique de référence en ambulatoire : la SSI ne recommande pas de test microbiologique pour la pneumonie légère.', 10), 10, 11, 12) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'SpO2, CRP (seulement si critères de test présents)', 'Toux aiguë avec fièvre > 3 jours, dyspnée, fréquence ≥ 22/min, foyer ou pouls ≥ 100/min'],
    ['Première', 'Radiographie du thorax', 'Suspicion de pneumonie ; exigée chez le patient hospitalisé'],
    ['Première à l’hôpital', '2 paires d’hémocultures, antigènes urinaires légionelle et pneumocoque, PCR grippe en saison, NFS, créatinine, urée', 'Pneumonie hospitalisée'],
    ['Seconde', 'Scanner thoracique', 'Doute diagnostique, abcès, empyème, échec'],
    ['Seconde', 'Test VIH', 'Deux pneumonies ou plus en 12 mois sans facteur de risque'],
   ]), 10, 11) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Les <b>hémocultures</b> se prélèvent avant la première dose d’antibiotique, sans retarder celle-ci en cas de sepsis.',
       'Le <b>test rapide</b> n’est indiqué que si un antibiotique sera donné en cas de résultat positif.',
       'La <b>procalcitonine</b> en cabinet n’est pas remboursée en premier recours (état juin 2025).',
       'L’<b>expectoration</b> n’est analysée que si le laboratoire la reçoit dans les 4 heures ; pas de préparation particulière.']), 10, 11, 12) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Normal', 'Seuil', 'Signification et conduite'], [
    ['CRP', '< 5 mg/L', '< 50 mg/L / ≥ 100 mg/L', 'Traitement symptomatique / antibiotique à envisager ; décision partagée entre les deux'],
    ['Procalcitonine', '< 0,05 µg/L', '< 0,25 µg/L / ≥ 0,25 µg/L', 'Pas d’antibiotique / antibiotique à envisager'],
    ['SpO2', '≥ 95 %', '< 92 % ; < 90 %', 'Hospitalisation à envisager ; hypoxémie : oxygène'],
    ['Antigène urinaire légionelle', 'Négatif', 'Positif', 'Légionellose : monothérapie par quinolone'],
    ['Radiographie', 'Pas d’infiltrat', 'Infiltrat multilobaire', 'Pneumonie sévère, surveillance accrue'],
   ]) + P('L’original indiquait un seuil d’antibiothérapie à 0,50 µg/L ; la SSI retient 0,25 µg/L. Les algorithmes guidés par la procalcitonine réduisent l’exposition aux antibiotiques (5,7 contre 8,1 jours) et la mortalité (9 % contre 10 %).', 11, 63), 11, 10, 63) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (CRP élevée, radiographie normale)', 'Échographie pulmonaire ou scanner si la clinique est forte'],
    ['Résultat négatif mais clinique typique', 'Une pneumonie débutante peut précéder l’infiltrat : réévaluer à 48–72 heures'],
    ['Résultat limite (CRP 50–100 mg/L)', 'Décision partagée avec le patient'],
    ['Grossesse', 'Échographie pulmonaire ; radiographie possible avec protection'],
    ['Enfant', 'Doses pédiatriques ; doxycycline seulement dès 8 ans'],
    ['Insuffisance rénale (DFGe bas)', 'Adapter certains antibiotiques ; urée moins interprétable'],
    ['Allergie à l’iode, pacemaker ou IRM', 'Scanner sans injection suffisant pour le parenchyme'],
   ]), 10, 11))
PTS.append(POINT(9, 'Examens complémentaires',
 P('L’imagerie confirme la pneumonie. '
   'La CRP et la procalcitonine aident à décider de l’antibiotique. '
   'Les examens microbiologiques sont réservés au patient hospitalisé.', 10, 11) + P9))

# ---------- 10
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si un drapeau rouge est présent, alors le médecin adresse le patient à l’hôpital. '
   'Si la toux aiguë s’accompagne de rhinorrhée, de mal de gorge et d’une fièvre < 38,5 °C sans dyspnée, alors il ne teste pas et traite les symptômes. '
   'Si un critère de test est présent, alors il dose la CRP et demande une imagerie en cas de suspicion de pneumonie.', 11, 10) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Mal de gorge, Centor 0–2', 'Ni test ni antibiotique', 'Consignes de reconsultation'],
    ['Centor 3–4', 'Test rapide si un antibiotique est envisagé', 'Antibiotique si positif'],
    ['CRP < 50 mg/L', 'Traitement symptomatique', 'Réévaluer si aggravation'],
    ['Pneumonie avec un CRB-65 nul', 'Antibiotique oral en ambulatoire', 'Réévaluation à 48–72 heures'],
    ['CRB-65 ≥ 1 (sauf âge seul) ou SpO2 < 90 %', 'Hospitalisation à envisager', 'Hémocultures, antigènes urinaires'],
    ['Fréquence ≥ 30/min, infiltrat multilobaire, confusion, hypotension', 'Surveillance accrue, soins intensifs à discuter', 'Lactate'],
   ]) + P('Correction de l’original : un CURB-65 ≥ 1 n’impose pas l’hospitalisation ni l’antibiotique IV ; la SSI demande d’envisager l’hôpital à partir de CRB-65 ≥ 1, sauf si l’âge est le seul critère.', 10), 10, 11, 12)))

# ---------- 11
MED = F('Fiches médicamenteuses (posologies AIPS et SSI)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Amoxicilline, Amoxi-Mepha® (aminopénicilline)', 'Bactéricide : inhibe la synthèse de la paroi ; élimination rénale, demi-vie courte, d’où 3 prises', 'PAC sans comorbidité : 1 g toutes les 8 heures per os ; angine : 1 g toutes les 12 heures, 6 jours', 'Allergie, éruption avec la mononucléose ; CI : allergie aux pénicillines'],
   ['Amoxicilline/acide clavulanique, Augmentin®, Co-Amoxi-Mepha® (pénicilline + inhibiteur de bêta-lactamase)', 'L’acide clavulanique bloque l’enzyme qui détruit l’amoxicilline', 'Comorbidités : 1 g toutes les 8 heures per os ; hôpital : 2,2 g toutes les 8 heures IV', 'Diarrhée, hépatite cholestatique ; CI : antécédent d’ictère sous ce produit'],
   ['Clarithromycine, Klacid® (macrolide)', 'Bloque la synthèse protéique bactérienne ; couvre les germes intracellulaires', '500 mg toutes les 12 heures per os ou IV', 'Allongement du QT, troubles digestifs ; inhibiteur du CYP3A4 (statines, anticoagulants)'],
   ['Doxycycline, Doxylag® (tétracycline)', 'Bactériostatique, bonne diffusion pulmonaire', '100 mg toutes les 12 heures (charge facultative 200 mg) ; dès 8 ans', 'Photosensibilité, œsophagite ; CI : grossesse, enfant < 8 ans'],
   ['Pénicilline V, Ospen® (pénicilline)', 'Bactéricide sur le streptocoque A', 'Angine : 1 million UI toutes les 12 heures, 6 jours', 'Allergie'],
   ['Oséltamivir, Tamiflu® (inhibiteur de la neuraminidase)', 'Empêche la libération des virus grippaux', '75 mg 2 fois par jour pendant 5 jours, début dans les 48 heures', 'Nausées ; adapter si insuffisance rénale'],
   ['Paracétamol, Dafalgan® (antalgique-antipyrétique)', 'Inhibe la COX centrale, baisse le thermostat', '500–1000 mg par prise, toutes les 4–8 heures, maximum 4 g/j', 'Hépatotoxicité en surdose ; prudence en cas d’alcoolisme'],
  ]) + P('Correction de l’original : sans comorbidité, la SSI recommande l’amoxicilline seule et non l’amoxicilline/acide clavulanique. La durée habituelle d’une PAC est de 5 jours, au moins 2 jours après la stabilisation.', 10), 1, 2, 10, 12)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge réserve l’antibiotique aux infections bactériennes probables, parce que la majorité des formes hautes est virale. '
   'Elle traite les symptômes, corrige l’hypoxémie et choisit le lieu de soins selon la gravité. '
   'Le but chiffré est la stabilisation clinique (fréquence respiratoire < 24/min, SpO2 ≥ 90 %) avant d’arrêter l’antibiotique au 5e jour.', 10, 11) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans une pneumonie sévère (soins intensifs, instabilité respiratoire ou circulatoire), le but est de survivre : antibiotique IV dans l’heure, oxygène et corticoïde. '
     'Dans une forme non compliquée, le but est la guérison en ambulatoire, sans antibiotique inutile.', 10, 64), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Forme compliquée, en urgence (première heure)</b> : 144 si instabilité ; oxygène ; 2 paires d’hémocultures puis amoxicilline/acide clavulanique 2,2 g toutes les 8 heures IV plus azithromycine ou clarithromycine pendant 24–72 heures ; hydrocortisone 200 mg/j ou prednisone 50 mg/j pendant 4–8 jours dans la forme sévère.',
         '<b>B. Pneumonie de gravité moyenne à l’hôpital</b> : même bêta-lactamine IV ; ceftriaxone 2 g/j si allergie non sévère à la pénicilline.',
         '<b>C. Forme non compliquée, en ambulatoire</b> : amoxicilline 1 g toutes les 8 heures ; macrolide ou doxycycline si allergie ; mesures générales (hydratation, repos, arrêt du tabac, éducation sur les signes d’alerte).',
         '<b>D. Infections hautes</b> : traitement symptomatique ; antibiotique seulement pour l’angine streptococcique prouvée ou la sinusite bactérienne.']) +
     P('Cet ordre vient de la gravité : la mortalité de la forme sévère dépasse 17 % (CURB-65 ≥ 3), alors que la forme légère guérit presque toujours.', 59), 10, 12, 13) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail de quelques jours est habituel pour une pneumonie ; la reprise suit la disparition de la fièvre.',
            'La conduite automobile est déconseillée tant que la fièvre, la fatigue ou un traitement sédatif diminuent la vigilance.',
            'La légionellose est à déclaration obligatoire ; une exposition professionnelle (tours de refroidissement) relève de la LAA.'), 25, 27) +
   F('Traitements non médicamenteux',
     UL(['Oxygène pour une SpO2 ≥ 90 % ; ventilation non invasive en soins intensifs si besoin.',
         'Hydratation, mobilisation précoce, kinésithérapie respiratoire si encombrement.',
         'Drainage chirurgical ou par drain thoracique d’un empyème.']), 10) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Amoxicilline possible ; doxycycline et quinolones à éviter'],
      ['Enfant', 'Amoxicilline 25 mg/kg toutes les 12 heures pour l’angine ; doxycycline dès 8 ans'],
      ['Sujet âgé', 'Confusion fréquente, hospitalisation plus large ; objectif curatif ou palliatif discuté'],
      ['Insuffisance hépatique', 'Prudence avec l’amoxicilline/acide clavulanique et les macrolides'],
      ['Insuffisance rénale (DFGe bas)', 'Adapter amoxicilline, oséltamivir et lévofloxacine'],
     ]), 10, 12, 2), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Fièvre, fréquence respiratoire, SpO2', 'Chaque jour à l’hôpital ; à 48–72 heures en ambulatoire', 'Pas d’amélioration : réévaluer, imagerie'],
    ['CRP ou procalcitonine', 'Après 3–4 jours', 'Pas de baisse : complication, germe résistant'],
    ['Radiographie de contrôle', 'Seulement si symptômes > 30 jours ou facteur de risque de cancer', 'Infiltrat persistant : scanner, bronchoscopie'],
    ['Antibiotique', 'Arrêt au 5e jour en principe', 'Arrêt 2–3 jours après la normalisation de la température'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Température normale et fréquence respiratoire normale.', 'SpO2 ≥ 90 % à l’air.', 'Prise orale possible et état mental habituel.', 'Suivi organisé et soutien à domicile suffisant.']), 10) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La guérison est la règle dans les formes légères ; la mortalité dépend du score CURB-65. '
     'La recommandation ATS 2026 traite de l’échographie pulmonaire, de l’antibiotique si un test viral est positif, de la durée et des corticoïdes. '
     'L’essai suisse de Boillat-Blanco (2021) a évalué procalcitonine et échographie au cabinet.', 59, 62, 10), 'fenetre')))

# ---------- 12
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur les vaccins du Plan de vaccination suisse 2026. '
   'Il recommande la grippe chaque année dès 65 ans et pour les groupes à risque, et une dose de PCV20 ou PCV21 dès 65 ans. '
   'Elle comprend aussi l’arrêt du tabac et l’hygiène des mains. '
   'La prévention secondaire évite les antibiotiques inutiles, qui sélectionnent les résistances.', 26, 11) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Vaccins grippe et pneumocoque ; arrêt du tabac ; hygiène des mains, masque si symptômes'],
    ['Secondaire', 'Traitement précoce de la grippe chez le patient à risque ; usage ciblé des antibiotiques'],
    ['Tertiaire', 'Rééducation après pneumonie sévère ; vaccination après l’épisode'],
   ], 'L’efficacité d’une dose de vaccin conjugué après 65 ans est de 75 % contre les infections invasives et de 46 % contre les pneumonies des sérotypes vaccinaux.'), 26)))

# ---------- 13
PTS.append(POINT(13, 'Points clés',
 P('La majorité des infections respiratoires hautes est virale et ne justifie pas d’antibiotique. '
   'La pneumonie se prouve par l’imagerie. '
   'Le CRB-65 et la SpO2 décident du lieu de soins. '
   'Chez la personne âgée, une confusion peut être le seul signe d’une pneumonie. '
   'Sans comorbidité, l’amoxicilline seule pendant 5 jours suffit en principe. '
   'Le médecin n’oublie jamais de vérifier la SpO2 et la fréquence respiratoire, et de proposer les vaccins grippe et pneumocoque dès 65 ans.', 11, 10, 26)))

# ---------- 14
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Prescrire un antibiotique pour une rhinopharyngite virale.', 'Non : traitement symptomatique.'],
  ['Hospitaliser d’office tout patient dont le seul point CURB-65 est l’âge.', 'Non : l’âge seul ne suffit pas (SSI).'],
  ['Exclure une pneumonie sur un examen pulmonaire normal.', 'Non : imagerie si les constantes sont anormales.'],
  ['Faire un test rapide streptococcique à tout mal de gorge.', 'Non : seulement si Centor 3–4 et antibiotique envisagé.'],
  ['Donner de l’amoxicilline/acide clavulanique à tout patient.', 'Non : amoxicilline seule sans comorbidité.'],
  ['Prolonger l’antibiotique 10 jours.', 'Non : 5 jours en principe.'],
 ]) + P('Ces pièges entraînent le raisonnement ; ils ne sont pas des questions officielles de l’examen fédéral.', 10, 11, 12)))

CTX = {'_prefixe': 'Dans une infection respiratoire',
 'crp': 'Une CRP < 50 mg/L oriente vers un traitement symptomatique ; ≥ 100 mg/L, un antibiotique se discute (SSI).',
 'pct': 'Une procalcitonine < 0,25 µg/L permet de ne pas prescrire d’antibiotique (SSI).',
 'radio': 'La radiographie du thorax cherche un infiltrat nouveau, condition du diagnostic de pneumonie.',
 'tdm': 'Le scanner thoracique cherche un abcès, un empyème ou une pneumonie non vue à la radiographie.',
 'echo': 'L’échographie pulmonaire est une alternative si l’opérateur est expérimenté ; elle voit mal les pneumonies centrales.',
 'hemoc': 'Deux paires d’hémocultures sont prélevées chez le patient hospitalisé, avant l’antibiotique.',
 'oxy': 'Une SpO2 < 92 % fait envisager l’hospitalisation ; < 90 % définit l’hypoxémie.',
 'gds': 'Les gaz du sang mesurent la PaO2 (≤ 7 kPa : insuffisance respiratoire sévère) et le lactate.',
 'nfs': 'Une leucopénie < 4 G/L ou des plaquettes < 100 G/L signalent une pneumonie grave.',
 'uree': 'Une urée > 7 mmol/L ajoute 1 point au CURB-65.',
 'creat': 'La créatinine cherche une insuffisance rénale aiguë et guide les doses.',
 'pcr': 'La PCR sur frottis nasopharyngé identifie la grippe ou le SARS-CoV-2.',
 'antigu': 'L’antigène urinaire légionelle positif fait passer à une monothérapie par quinolone (SSI).',
 'tdr': 'Le test rapide streptococcique n’est fait que si le score de Centor vaut 3–4.',
 'expecto': 'L’expectoration n’est utile que si elle arrive au laboratoire dans les 4 heures.',
 'lact': 'Le lactate se mesure en cas de dysfonction d’organe.',
 'vih': 'Un test VIH est proposé après au moins deux pneumonies en 12 mois.',
 'bnp': 'Un BNP élevé oriente vers un œdème pulmonaire plutôt qu’une pneumonie.',
 'ddim': 'Les D-dimères servent à exclure une embolie pulmonaire si la probabilité clinique est faible.',
 'sero': 'La sérologie de Coxiella burnetii se discute selon l’exposition.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
