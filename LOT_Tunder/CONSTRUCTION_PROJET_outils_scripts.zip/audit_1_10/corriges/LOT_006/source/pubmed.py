# -*- coding: utf-8 -*-
"""Vérification bibliographique via PubMed E-utilities. Usage : pubmed.py 'requête1' 'requête2'... ou pmid:123
Affiche auteurs, titre, revue, année;vol:pages, PMID et le résumé (tronqué). Cache dans verif/pubmed_cache.json."""
import sys, json, os, time, urllib.request, urllib.parse, re
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'verif'); os.makedirs(D, exist_ok=True)
C = os.path.join(D, 'pubmed_cache.json'); cache = json.load(open(C)) if os.path.exists(C) else {}
E = 'https://eutils.ncbi.nlm.nih.gov/entrez/eutils/'
def get(u):
    for i in range(4):
        try: return urllib.request.urlopen(u, timeout=30).read().decode()
        except Exception as e: time.sleep(1.5)
    return ''
def search(q, n=3):
    j = json.loads(get(E + 'esearch.fcgi?db=pubmed&retmode=json&retmax=%d&term=' % n + urllib.parse.quote(q)) or '{}')
    return j.get('esearchresult', {}).get('idlist', [])
def summ(pmid):
    if pmid in cache: return cache[pmid]
    j = json.loads(get(E + 'esummary.fcgi?db=pubmed&retmode=json&id=' + pmid))['result'][pmid]
    ab = get(E + 'efetch.fcgi?db=pubmed&rettype=abstract&retmode=text&id=' + pmid)
    r = dict(pmid=pmid, authors=', '.join(a['name'] for a in j.get('authors', [])[:4]) + (' et al.' if len(j.get('authors', [])) > 4 else ''),
             title=j.get('title'), src=j.get('source'), date=j.get('pubdate'), vol=j.get('volume'), issue=j.get('issue'), pages=j.get('pages'),
             doi=j.get('elocationid'), abstract=ab)
    cache[pmid] = r; json.dump(cache, open(C, 'w'), ensure_ascii=False, indent=0); time.sleep(0.35); return r
full = '--full' in sys.argv
n = 1 if '--1' in sys.argv else 2
for q in [a for a in sys.argv[1:] if not a.startswith('--')]:
    ids = [q[5:]] if q.startswith('pmid:') else search(q, n)
    print('#####', q, '→', ids or 'AUCUN RÉSULTAT')
    for i in ids:
        r = summ(i)
        print(f"  PMID {i} | {r['authors']} | {r['title']} | {r['src']} {r['date']};{r['vol']}:{r['pages']} | {r['doi']}")
        ab = re.sub(r'\s+', ' ', r['abstract'])
        m = re.search(r'(RESULTS?:|DATA SYNTHESIS:|FINDINGS:|MEASUREMENTS AND MAIN RESULTS:|MAIN RESULTS:)', ab)
        body = ab[m.start():] if m else ab[min(len(ab), 250):]
        body = re.split(r'(Copyright|©|DOI: 10\.|PMID: \d)', body)[0]
        print('   ABS:', ab if full else body[:1600])
