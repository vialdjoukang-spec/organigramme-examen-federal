# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.7 · Infections ostéoarticulaires (LOT 6, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('dx7')
M = meta('dx7', 'DX.7', 'Infections ostéoarticulaires', 'Infections ostéoarticulaires : arthrite septique, ostéomyélite, spondylodiscite et infection de prothèse',
         'LOT_006_DX7_Infections_osteoarticulaires_AUDITÉ.html')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('Les infections ostéoarticulaires (IOA) regroupent l’arthrite septique (infection d’une articulation), l’ostéomyélite (infection de l’os) et la spondylodiscite (infection d’un disque et des vertèbres voisines). '
   'L’infection de prothèse articulaire forme un groupe à part, car les bactéries collent au matériel. '
   'L’arthrite septique détruit le cartilage en quelques jours et reste une urgence.', 80, 127) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Arthrite septique', 'Bactéries dans le liquide articulaire', 'Arthrite microcristalline (goutte, chondrocalcinose)'],
    ['Arthrite réactive', 'Arthrite stérile après une infection digestive ou génitale', 'Arthrite septique'],
    ['Ostéomyélite aiguë', 'Symptômes depuis moins de 2 semaines', 'Ostéomyélite chronique (plus de 3 mois)'],
    ['Spondylodiscite', 'Infection du disque et des plateaux vertébraux', 'Tassement ostéoporotique, métastase'],
    ['Infection de prothèse', 'Infection du matériel et des tissus voisins', 'Descellement mécanique'],
   ]), 128, 15)))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, la surveillance Swissnoso de 116 981 prothèses de hanche et de genou trouve une infection du site opératoire chez 1,01 % des patients, et 1,44 % pendant les canicules. '
   'Le chiffre « 3,5 % des causes de fièvre » de l’original n’a été retrouvé dans aucune source et il est retiré. '
   'En Europe, en Allemagne, l’incidence de la spondylodiscite était de 12,4 pour 100 000 habitants en 2019, avec une mortalité hospitalière de 6,7 %.', 123, 124, 125, 99) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Infection après prothèse de hanche ou de genou' + PR('1,01 %', 123), 'Hors canicule', 'Suisse, 122 hôpitaux'],
    ['Spondylodiscite' + PR('12,4/100 000', 124), 'Par an, 2019', 'Allemagne'],
    ['Mortalité hospitalière de la spondylodiscite' + PR('6,7 %', 125), '49 951 cas', 'Allemagne, 2019–2023'],
    ['Arthrite septique parmi les arthrites ponctionnées', '653 sur 6 242 (10,5 %)', 'Méta-analyse de 14 études (2007)'],
   ], 'Les facteurs de terrain sont l’âge, le diabète, la polyarthrite rhumatoïde, une prothèse, une chirurgie articulaire et une infection cutanée.'), 123, 124, 125, 80)))
PTS.append(POINT(3, 'Physiopathologie',
 P('Les bactéries arrivent par le sang, par contiguïté (plaie, escarre, ulcère du pied diabétique) ou par inoculation directe (chirurgie, infiltration). '
   'Dans l’articulation, les enzymes des neutrophiles détruisent le cartilage en quelques jours. '
   'Sur une prothèse ou un os mort, les bactéries forment un biofilm qui résiste aux antibiotiques, d’où le rôle de la chirurgie.', 80, 127) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Grosses articulations (genou, hanche), os longs chez l’enfant, rachis lombaire chez l’adulte.'],
    ['Physiologie', 'Le cartilage n’a pas de vaisseaux, il se nourrit par le liquide articulaire.'],
    ['Physiopathologie', 'Pus articulaire, destruction du cartilage, nécrose osseuse, biofilm.'],
    ['Clinique', 'Douleur, gonflement, impotence, fièvre inconstante.'],
    ['Examens', 'Ponction, hémocultures, IRM.'],
    ['Traitement', 'Drainage ou chirurgie, puis antibiotique prolongé.'],
   ]), 80, 128) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Pus dans l’articulation', 'Ponction articulaire', 'Lavage articulaire'],
    ['Bactériémie', 'Hémocultures', 'Antibiotique adapté'],
    ['Œdème de l’os et du disque', 'IRM', 'Biopsie, antibiotique 6 semaines'],
    ['Biofilm sur prothèse', 'Ponction, cultures de biopsies opératoires', 'Chirurgie de la prothèse'],
   ]), 80, 81, 127) +
 F('Liquide articulaire : comptage et exemple',
   P('Plus le nombre de leucocytes du liquide est élevé, plus l’arthrite septique est probable. '
     'Le rapport de vraisemblance est de 0,32 sous 25 000/µL, de 7,7 au-dessus de 50 000/µL et de 28 au-dessus de 100 000/µL. '
     'Exemple : un genou chaud avec 78 000 leucocytes/µL et 95 % de neutrophiles rend l’infection probable, mais seule la culture la prouve.', 80) +
   P('Correction de l’original : le seuil de 50 000/µL n’est pas un « seuil de certitude », car une goutte peut le dépasser et une infection peut rester en dessous.', 80), 80)))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant une monoarthrite aiguë, le médecin pense d’abord à l’arthrite septique et recherche une urgence : sepsis, prothèse, déficit neurologique en cas de douleur du dos. '
   'Il ponctionne ensuite l’articulation avant tout antibiotique, puis cherche des cristaux et des germes. '
   'Il distingue enfin l’infection de la goutte, de la chondrocalcinose et de l’arthrite réactive.', 80) +
 F('Diagnostic différentiel de la monoarthrite aiguë (fréquence en exposant rouge : méta-analyse de 2007)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Arthrite septique' + PR('10,5 %', 80), 'Fièvre (57 % seulement), prothèse, diabète', 'Ponction : leucocytes, Gram, culture'],
    ['Goutte', 'Gros orteil, hyperuricémie, diurétique', 'Cristaux d’urate en lumière polarisée'],
    ['Chondrocalcinose', 'Sujet âgé, genou, poignet', 'Cristaux de pyrophosphate de calcium'],
    ['Arthrite réactive', 'Diarrhée ou urétrite 1 à 4 semaines avant', 'Liquide stérile'],
    ['Arthrite gonococcique', 'Adulte jeune, pustules, ténosynovite', 'PCR et culture gonocoque'],
    ['Arthrite de Lyme', 'Genou, piqûre de tique', 'Sérologie, PCR du liquide'],
   ]) + P('Seule l’arthrite septique a une fréquence publiée dans cette population, les autres diagnostics n’ont pas de fréquence.', 80), 80, 129, 15)))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise le début, la porte d’entrée, une prothèse, une infiltration récente, le diabète, l’immunosuppression, une drogue IV et les rapports sexuels à risque.', 80, 129) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Avez-vous une prothèse dans cette articulation ?', 'Infection de prothèse.', 'Avis orthopédique, pas d’antibiotique avant la ponction.'],
    ['Avez-vous reçu une infiltration récemment ?', 'Inoculation directe.', 'Arthrite septique probable.'],
    ['Avez-vous eu une diarrhée ou un écoulement urétral ?', 'Arthrite réactive ou gonococcique.', 'PCR, sérologies.'],
    ['Avez-vous déjà eu des crises de goutte ?', 'Arthrite microcristalline.', 'Chercher aussi les cristaux, sans exclure l’infection.'],
    ['La douleur du dos vous réveille-t-elle la nuit ?', 'Douleur inflammatoire.', 'IRM du rachis.'],
    ['Avez-vous une faiblesse des jambes ou des troubles urinaires ?', 'Abcès épidural.', 'IRM en urgence.'],
   ]), 80, 82) +
 U('<b>Drapeaux rouges (144 ou urgences)</b> : sepsis, déficit neurologique ou troubles sphinctériens avec douleur du dos fébrile, articulation prothétique chaude et douloureuse.', 82)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen compare les deux côtés, cherche un épanchement et teste la mobilité active et passive. '
   'Il recherche une porte d’entrée cutanée et palpe le rachis. '
   'La fièvre manque dans 43 % des arthrites septiques, donc une température normale n’exclut rien.', 80) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Inspection et palpation de l’articulation', 'Pas de chaleur ni de gonflement', 'Rougeur, chaleur, épanchement'],
    ['Choc rotulien', 'Absent', 'Épanchement du genou'],
    ['Mobilisation passive douce', 'Indolore', 'Douleur à tout mouvement : arthrite'],
    ['Percussion des épineuses', 'Indolore', 'Douleur localisée : spondylodiscite'],
    ['Examen neurologique des membres inférieurs', 'Force et réflexes normaux', 'Déficit : abcès épidural'],
    ['Peau', 'Intacte', 'Plaie, ulcère, pustules (gonocoque)'],
   ]) + P('La valeur de la clinique est limitée : douleur articulaire sensibilité 85 %, gonflement 78 %, fièvre 57 %, frissons 19 %.', 80), 80, 82, 129)))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la douleur, l’impotence et la douleur du dos nocturne. '
   'Les signes physiques sont l’épanchement, la chaleur, la limitation de la mobilité et la fièvre. '
   'Le tableau varie selon l’articulation, l’os atteint et l’âge du patient.', 80, 82) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme'], [
    ['Syndrome de monoarthrite aiguë', 'Articulation chaude, gonflée, douloureuse', 'Pus ou cristaux'],
    ['Syndrome rachidien inflammatoire', 'Douleur du dos nocturne, raideur, fièvre', 'Spondylodiscite'],
    ['Syndrome de compression médullaire', 'Faiblesse, troubles sensitifs et sphinctériens', 'Abcès épidural'],
    ['Syndrome arthrite-dermatite', 'Polyarthralgies, ténosynovite, pustules', 'Gonococcie disséminée'],
   ]), 80, 82, 129) +
 F('Signe : choc rotulien',
   P('Geste : vider le cul-de-sac au-dessus de la rotule d’une main, puis appuyer sur la rotule de l’autre. '
     'Signe : la rotule rebondit sur le fémur. '
     'Mécanisme : un épanchement soulève la rotule.', 80), 80) +
 F('Signe : impotence douloureuse',
   P('Geste : mobiliser doucement l’articulation de façon passive. '
     'Signe : toute amplitude est douloureuse. '
     'Mécanisme : la capsule distendue par le pus est très sensible.', 80), 80) +
 F('Signe : douleur à la percussion des épineuses',
   P('Geste : percuter chaque épineuse du rachis. '
     'Signe : douleur vive à un niveau. '
     'Mécanisme : inflammation du disque et des vertèbres.', 82), 82)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('L’arthrite septique est prouvée par un germe dans le liquide articulaire ou par une forte probabilité clinique avec hémocultures positives. '
   'L’infection de prothèse suit les critères 2021 de la Société européenne des infections osseuses et articulaires (EBJIS), avalisés par d’autres sociétés européennes. '
   'Un liquide à moins de 50 000/µL ne suffit pas à exclure l’infection.', 80, 127) +
 F('Critères',
   TAB(['Situation', 'Critère', 'Remarque'], [
    ['Arthrite septique', 'Germe à l’examen direct ou en culture du liquide', 'Leucocytes > 50 000/µL : rapport de vraisemblance 7,7'],
    ['Spondylodiscite (IDSA 2015)', 'IRM compatible et germe dans les hémocultures ou la biopsie', 'Biopsie si hémocultures négatives'],
    ['Infection de prothèse confirmée (EBJIS 2021)', 'Fistule, pus, ou au moins 2 cultures positives au même germe', 'Leucocytes du liquide > 3 000/µL ou neutrophiles > 80 %'],
    ['Infection de prothèse probable', 'Critères partiels', 'Discussion multidisciplinaire'],
   ]) + P('Les seuils de liquide de l’EBJIS (3 000/µL, 80 %) viennent du texte complet de la définition, à vérifier sur la publication.', 127), 80, 82, 127)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Ponction articulaire', 'Leucocytes, cristaux, germe', 'Leucocytes > 100 000/µL : rapport de vraisemblance 28', 'Culture négative après antibiotique'],
    ['IRM du rachis', 'Œdème du disque, abcès', 'Examen de choix de la spondylodiscite', 'Peut rester normale au tout début'],
    ['Biopsie disco-vertébrale', 'Germe, histologie', 'Indiquée si hémocultures négatives', 'Rendement diminué après antibiotique'],
    ['Cultures de biopsies opératoires', 'Germe d’une infection de prothèse', '≥ 2 cultures concordantes', 'Contamination si une seule'],
   ]), 80, 82, 127) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Ponction articulaire', 'Toute monoarthrite aiguë'],
    ['Première', '2 paires d’hémocultures', 'Avant l’antibiotique'],
    ['Première', 'NFS, CRP, créatinine', 'Toujours'],
    ['Première', 'Radiographie', 'Référence, autres causes'],
    ['Seconde', 'IRM', 'Rachis, ostéomyélite'],
    ['Seconde', 'Biopsie osseuse ou discale', 'Hémocultures négatives'],
    ['Seconde', 'Échocardiographie', 'Staphylococcus aureus dans le sang'],
   ]), 82, 128) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Ponctionner avant l’antibiotique, en asepsie stricte.', 'Envoyer le liquide pour leucocytes, cristaux, Gram et culture, avec un flacon d’hémoculture.', 'Chez le patient stable sans abcès épidural, différer l’antibiotique jusqu’à la biopsie de spondylodiscite.']), 80, 82, 128) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Normal', 'Seuil', 'Signification et conduite'], [
    ['Leucocytes du liquide articulaire', '< 2 000/µL', '> 50 000/µL', 'Infection probable : lavage'],
    ['Neutrophiles du liquide', '< 25 %', '≥ 90 %', 'Rapport de vraisemblance 3,4'],
    ['Cristaux', 'Absents', 'Présents', 'Goutte ou chondrocalcinose, sans exclure l’infection'],
    ['CRP', '< 5 mg/L', 'Élevée', 'Suivi de la réponse'],
   ]), 80) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (germe de la peau dans une seule culture)', 'Contamination probable : répéter'],
    ['Résultat négatif mais clinique forte', 'PCR du liquide, nouvelle ponction'],
    ['Résultat limite (25 000 à 50 000/µL)', 'Décision selon la clinique et le terrain'],
    ['Grossesse', 'Échographie, IRM sans gadolinium'],
    ['Enfant', 'IRM dans les 48 heures, Kingella kingae entre 6 mois et 4 ans'],
    ['DFGe bas', 'IRM sans gadolinium'],
    ['Pacemaker', 'Scanner, scintigraphie, PET-CT'],
   ]), 80, 128))
PTS.append(POINT(9, 'Examens complémentaires',
 P('La ponction articulaire est l’examen clé de l’arthrite. '
   'L’IRM est l’examen de choix de la spondylodiscite et de l’ostéomyélite. '
   'Les hémocultures sont prélevées avant tout antibiotique.', 80, 82, 128) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une monoarthrite aiguë apparaît, alors le médecin ponctionne l’articulation avant l’antibiotique. '
   'Si le liquide est purulent ou le Gram positif, alors l’orthopédiste lave l’articulation en urgence. '
   'Si une douleur du dos fébrile s’accompagne d’un déficit, alors une IRM est faite en urgence.', 80, 82) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Liquide purulent ou Gram positif', 'Lavage articulaire et antibiotique IV', 'CRP, nouvelle ponction si besoin'],
    ['Cristaux sans germe, patient bien', 'Traitement de la crise, culture attendue', 'Résultat de la culture'],
    ['Spondylodiscite, hémocultures positives', 'Antibiotique adapté, pas de biopsie', 'Échocardiographie si Staphylococcus aureus'],
    ['Spondylodiscite, hémocultures négatives', 'Biopsie guidée', 'Antibiotique selon le germe'],
    ['Déficit neurologique', 'IRM et chirurgie en urgence', 'Neurochirurgie'],
    ['Infection de prothèse', 'Équipe orthopédique et infectiologique', 'Chirurgie selon l’âge de l’infection'],
   ]), 80, 82, 127)))
MED = F('Fiches médicamenteuses (AIPS et recommandations)',
  TAB(['Médicament (classe)', 'Mécanisme d’action et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Flucloxacilline, Floxapen® (pénicilline antistaphylococcique)', 'Inhibe la synthèse de la paroi bactérienne, élimination rénale, demi-vie courte', '2–8 g/j en 3–4 perfusions, durée selon le site', 'Hépatite cholestatique ; contre-indiquée en cas d’allergie aux pénicillines'],
   ['Céfazoline (céphalosporine)', 'Staphylocoques et streptocoques', '1,5–4 g/j IV', 'Allergie'],
   ['Ceftriaxone, Rocephin® (céphalosporine)', 'Une prise par jour, gonocoque', '1 g toutes les 24 heures pendant 7 jours (gonococcie disséminée)', 'Allergie, boue biliaire'],
   ['Vancomycine (glycopeptide)', 'Staphylocoques résistants', '15–20 mg/kg toutes les 8–12 heures, selon la concentration', 'Atteinte rénale, adapter au DFGe'],
   ['Clindamycine, Dalacin® C (lincosamide)', 'Bonne diffusion osseuse, relais oral', '1 200–1 800 mg/j per os', 'Colite à Clostridioides difficile ; interaction avec les curares'],
  ]), 4, 5, 129)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge associe le drainage du pus et un antibiotique adapté au germe, parce que l’antibiotique seul ne stérilise pas un pus collecté. '
   'Une arthrite native drainée guérit chez 99 % des patients après 2 semaines d’antibiotique. '
   'La spondylodiscite guérit chez 90,9 % des patients après 6 semaines, sans gain à 12 semaines.', 126, 81) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans la forme compliquée (sepsis, abcès épidural, prothèse), le but est un drainage ou une chirurgie dans les heures qui suivent selon l’urgence. '
     'Dans la forme non compliquée, le but est de guérir sans séquelle avec un relais oral précoce.', 82, 126, 83), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures',
     OL(['<b>A. Urgence</b> : sepsis ou déficit neurologique : antibiotique immédiat après hémocultures, chirurgie.',
         '<b>B. Drainage</b> : lavage articulaire par arthroscopie ou arthrotomie, ponctions répétées si nécessaire.',
         '<b>C. Antibiotique</b> : empirique antistaphylococcique, puis adapté ; 2 semaines après drainage d’une arthrite native, 6 semaines pour une spondylodiscite.',
         '<b>D. Forme non compliquée</b> : mesures générales (repos antalgique, mobilisation précoce, contrôle du diabète) ; relais oral, non inférieur au traitement IV (13,2 % contre 14,6 % d’échecs).']), 126, 81, 83) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail de 2 à 6 semaines est habituel, plus long après chirurgie de prothèse ou du rachis.',
            'La conduite automobile reste suspendue tant que l’articulation du membre inférieur ou la douleur empêche un freinage d’urgence.',
            'Une ostéomyélite après fracture ouverte relève de la LAA (accident) ; des séquelles durables peuvent relever de la LAI.'), 81) +
   F('Traitements non médicamenteux',
     UL(['Immobilisation antalgique courte puis physiothérapie précoce.', 'Décharge du membre selon l’orthopédiste.', 'Soins de plaie, contrôle du diabète.']), 126) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Bêtalactamines possibles, éviter les fluoroquinolones'],
      ['Enfant', 'Flucloxacilline 50 mg/kg/dose 3 fois par jour IV au-delà de 4 ans, relais oral précoce'],
      ['Sujet âgé', 'Présentation trompeuse, chercher une endocardite si Staphylococcus aureus'],
      ['Insuffisance hépatique', 'Surveiller flucloxacilline et clindamycine'],
      ['Insuffisance rénale (DFGe bas)', 'Adapter vancomycine et céfazoline'],
     ]), 128, 4), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Douleur, mobilité, fièvre', 'Chaque jour', 'Pas d’amélioration à 48–72 heures : nouvelle ponction ou lavage'],
    ['CRP', '2 fois par semaine', 'Baisse attendue ; relais oral chez l’enfant si < 20 mg/L'],
    ['Fonction rénale et hépatique', 'Chaque semaine', 'Adapter les doses'],
    ['Examen neurologique (spondylodiscite)', 'Chaque jour', 'Nouveau déficit : IRM en urgence'],
   ]) + H4('Critères de sortie, un par un') + OL(['Apyrexie et douleur contrôlée.', 'CRP en baisse.', 'Antibiotique oral toléré.', 'Suivi orthopédique et infectiologique organisé.']), 128, 126) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('L’arthrite native drainée guérit chez 97–99 % des patients. '
     'La spondylodiscite garde une mortalité hospitalière de 6,7 %. '
     'La recherche 2026 suit en Suisse une cohorte nationale des infections de prothèse.', 126, 125), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur l’asepsie stricte lors des ponctions et des infiltrations. '
   'La recommandation suisse de Swissnoso surveille les infections après prothèse de hanche et de genou dans les hôpitaux. '
   'La prévention tertiaire limite les séquelles par la physiothérapie.', 123) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Asepsie des gestes, antibioprophylaxie avant pose de prothèse, contrôle du diabète'],
    ['Secondaire', 'Ponction rapide de toute articulation chaude, surtout prothétique'],
    ['Tertiaire', 'Physiothérapie, suivi des prothèses, éducation du patient'],
   ]), 123, 80)))
PTS.append(POINT(13, 'Points clés',
 P('Une monoarthrite aiguë, avec ou sans fièvre, est une arthrite septique jusqu’à preuve du contraire. '
   'La ponction articulaire et les hémocultures précèdent toujours l’antibiotique chez le patient stable. '
   'Une douleur du dos fébrile avec faiblesse des jambes impose une IRM en urgence. '
   'Une arthrite native drainée se traite 2 semaines, une spondylodiscite 6 semaines.', 80, 81, 82, 126)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Infiltrer des corticoïdes sans exclure une infection.', 'Non : ponctionner et cultiver d’abord.'],
  ['Exclure l’infection parce que des cristaux sont présents.', 'Non : les deux peuvent coexister.'],
  ['Exclure l’infection sans fièvre.', 'Non : fièvre présente chez 57 % seulement.'],
  ['Traiter une spondylodiscite 12 semaines par principe.', 'Non : 6 semaines suffisent dans l’essai de référence.'],
  ['Débuter l’antibiotique avant la ponction chez un patient stable.', 'Non : la culture deviendrait négative.'],
 ]) + P('Ces pièges entraînent le raisonnement ; ils ne sont pas des questions officielles de l’examen fédéral.', 80, 81)))
CTX = {'_prefixe': 'Dans une infection ostéoarticulaire',
 'synov': 'La ponction articulaire mesure leucocytes et neutrophiles, cherche des cristaux et met le germe en culture.',
 'hemoc': 'Les hémocultures avant l’antibiotique identifient souvent le germe d’une spondylodiscite.',
 'irm': 'L’IRM est l’examen de choix de la spondylodiscite et de l’ostéomyélite.',
 'radio': 'La radiographie sert de référence et cherche une autre cause, elle est souvent normale au début.',
 'crp': 'La CRP suit la réponse au traitement.',
 'nfs': 'La NFS peut montrer une hyperleucocytose, souvent absente.',
 'creat': 'La créatinine guide la dose des antibiotiques.',
 'biopsie': 'La biopsie disco-vertébrale identifie le germe quand les hémocultures restent négatives.',
 'tdm': 'Le scanner guide la biopsie et cherche un abcès.',
 'pcr': 'La PCR du liquide détecte un germe difficile à cultiver.',
 'echocoeur': 'L’échocardiographie cherche une endocardite associée à Staphylococcus aureus.',
 'pct': 'La procalcitonine est peu sensible dans les infections localisées.',
 'vs': 'La vitesse de sédimentation suit l’évolution, elle reste peu spécifique.',
 'tep': 'Le PET-CT aide pour les infections de matériel.',
 'scinti': 'La scintigraphie aide si l’IRM est impossible.',
 'echo': 'L’échographie montre un épanchement et guide la ponction.',
 'sero': 'La sérologie de Lyme oriente une monoarthrite du genou.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
