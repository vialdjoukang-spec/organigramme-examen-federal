# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.9 · Néoplasies et hémopathies (LOT 6, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('dx9')
M = meta('dx9', 'DX.9', 'Néoplasies et hémopathies', 'Fièvre et cancer : fièvre néoplasique, lymphomes, leucémies et neutropénie fébrile',
         'LOT_006_DX9_Neoplasies_hemopathies_AUDITÉ.html')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('Un cancer solide ou une hémopathie maligne, surtout un lymphome, une leucémie aiguë ou un cancer du rein, peut causer une fièvre prolongée. '
   'La fièvre néoplasique est une fièvre causée par la tumeur elle-même, retenue seulement après exclusion d’une infection et d’une réaction médicamenteuse. '
   'Chez un patient sous chimiothérapie, la fièvre est d’abord une neutropénie fébrile jusqu’à preuve du contraire.', 88, 44) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Fièvre néoplasique', 'Fièvre due au cancer, sans infection retrouvée', 'Fièvre infectieuse du patient cancéreux'],
    ['Neutropénie fébrile', 'Température orale > 38,3 °C (ou 2 mesures > 38,0 °C pendant 2 heures) et neutrophiles < 0,5 G/L', 'Fièvre sans neutropénie'],
    ['Symptômes B', 'Fièvre > 38,3 °C, sueurs nocturnes profuses, perte de poids > 10 % en 6 mois', 'Altération de l’état général non spécifique'],
    ['Syndrome d’activation macrophagique', 'Activation excessive des macrophages avec cytopénies et ferritine très élevée', 'Simple syndrome inflammatoire'],
    ['Fièvre d’origine inconnue', 'Plus de 3 semaines, > 38,3 °C, sans diagnostic après bilan de base', 'Fièvre prolongée simple'],
   ]), 44, 89, 142, 130)))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, 952 hommes et 738 femmes reçoivent chaque année un diagnostic de lymphome non hodgkinien, avec un risque avant 70 ans de 0,86 % chez l’homme et de 0,60 % chez la femme. '
   'Le chiffre « 2,5 % des causes de fièvre » de l’original n’a été retrouvé dans aucune source et il est retiré. '
   'En Europe, une étude néerlandaise de fièvres d’origine inconnue trouve une néoplasie chez 7 % des patients.', 135, 99, 130) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Lymphome non hodgkinien', '1690 nouveaux cas par an, âge médian 70–72 ans', 'Suisse, 2018–2022'],
    ['Lymphome de Hodgkin', '290 nouveaux cas par an, âge médian 41–45 ans', 'Suisse, 2018–2022'],
    ['Néoplasie parmi les fièvres d’origine inconnue' + PR('7 %', 130), '73 patients', 'Pays-Bas'],
    ['Mortalité hospitalière de la neutropénie fébrile' + PR('9,5 %', 140), '41 779 patients', 'États-Unis'],
   ], 'Le terrain oriente : âge élevé pour les lymphomes non hodgkiniens, adulte jeune pour le lymphome de Hodgkin ; le pronostic de la neutropénie fébrile dépend des comorbidités (mortalité 2,6 % sans comorbidité majeure, ≥ 21,4 % avec plus d’une).'), 135, 130, 140)))
PTS.append(POINT(3, 'Physiopathologie',
 P('La tumeur et les cellules immunitaires qui l’entourent libèrent des cytokines pyrogènes comme l’interleukine 6 et le TNF-alpha. '
   'Ces cytokines augmentent la synthèse des prostaglandines dans l’hypothalamus, ce qui élève la température de consigne. '
   'La chimiothérapie détruit les neutrophiles et ouvre la porte aux bactéries de l’intestin et de la peau.', 88, 143, 44) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Ganglions, rate, moelle osseuse, organes pleins.'],
    ['Physiologie', 'L’hypothalamus règle la température sous l’effet des prostaglandines.'],
    ['Physiopathologie', 'Cytokines tumorales, nécrose tumorale, neutropénie après chimiothérapie.'],
    ['Clinique', 'Fièvre, sueurs, perte de poids, adénopathies, splénomégalie.'],
    ['Examens', 'NFS, frottis, LDH, imagerie, biopsie.'],
    ['Traitement', 'Traiter le cancer, AINS pour la fièvre néoplasique, antibiotique en urgence si neutropénie.'],
   ]), 88, 89) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Cytokines pyrogènes de la tumeur', 'CRP, LDH, imagerie', 'Naproxène, traitement du cancer'],
    ['Nécrose tumorale', 'Scanner, PET-CT', 'Exérèse ou traitement local'],
    ['Neutropénie après chimiothérapie', 'NFS, hémocultures', 'Antibiotique dans l’heure'],
    ['Activation macrophagique', 'Ferritine, triglycérides, fibrinogène', 'Avis hématologique, traitement de la cause'],
   ]), 88, 44, 141) +
 F('Score MASCC : comptage et exemple',
   TAB(['Élément', 'Points'], [
    ['Peu ou pas de symptômes (symptômes modérés : 3)', '5'],
    ['Pas d’hypotension', '5'],
    ['Pas de BPCO', '4'],
    ['Tumeur solide, ou hémopathie sans infection fongique antérieure', '4'],
    ['Patient ambulatoire', '3'],
    ['Pas de déshydratation', '3'],
    ['Âge < 60 ans', '2'],
   ]) + P('Un score ≥ 21 sur 26 définit un faible risque de complication. '
     'Exemple : patiente de 52 ans, ambulatoire, tumeur solide, symptômes légers, sans hypotension, BPCO ni déshydratation : elle obtient les 26 points et relève du faible risque.', 138), 138)))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant une fièvre chez un patient cancéreux, le médecin cherche d’abord une urgence : neutropénie fébrile, sepsis, syndrome d’activation macrophagique. '
   'Il exclut ensuite une infection et une réaction médicamenteuse, puis seulement retient une fièvre néoplasique. '
   'Sans cancer connu, adénopathies, splénomégalie et symptômes B orientent vers un lymphome.', 44, 88, 89) +
 F('Diagnostic différentiel de la fièvre d’origine inconnue (fréquences en exposant rouge, même population : étude néerlandaise)',
   TAB(['Cause et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Néoplasie' + PR('7 %', 130), 'Perte de poids, adénopathies, LDH élevées', 'Scanner, PET-CT, biopsie'],
    ['Infection' + PR('16 %', 130), 'Frissons, cathéter, voyage', 'Hémocultures, imagerie'],
    ['Maladie inflammatoire non infectieuse' + PR('22 %', 130), 'Arthrites, éruption, âge', 'Auto-anticorps, PET-CT'],
    ['Causes diverses' + PR('4 %', 130), 'Médicament, thrombose', 'Arrêt du médicament'],
    ['Pas de diagnostic' + PR('51 %', 130), 'Souvent évolution favorable', 'Suivi'],
   ]), 130)))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien recherche la date de la dernière chimiothérapie, les sueurs nocturnes, la perte de poids, le prurit, la douleur osseuse et les médicaments récents.', 89, 44) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Quand avez-vous reçu la dernière chimiothérapie ?', 'Neutropénie probable.', 'NFS et antibiotique dans l’heure.'],
    ['Devez-vous changer de pyjama la nuit ?', 'Sueurs nocturnes profuses.', 'Symptôme B.'],
    ['Avez-vous perdu du poids sans régime ?', 'Plus de 10 % en 6 mois.', 'Symptôme B.'],
    ['Avez-vous des démangeaisons ?', 'Prurit du lymphome de Hodgkin.', 'Imagerie, biopsie ganglionnaire.'],
    ['Avez-vous un cathéter ou une chambre implantable ?', 'Infection de cathéter.', 'Hémocultures sur le cathéter et en périphérie.'],
    ['Quels médicaments prenez-vous depuis peu ?', 'Fièvre médicamenteuse.', 'Arrêt du médicament suspect.'],
   ]), 89, 44) +
 U('<b>Drapeaux rouges (144 ou urgences)</b> : fièvre dans les semaines qui suivent une chimiothérapie, hypotension, confusion, frissons au rinçage du cathéter, saignements avec cytopénie.', 44, 139)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen palpe toutes les aires ganglionnaires, le foie et la rate. '
   'Chez un patient neutropénique, il inspecte la bouche, la peau, le point de ponction du cathéter et la région périanale, sans toucher rectal. '
   'Un examen normal n’exclut ni une infection chez le neutropénique ni un lymphome profond.', 44, 89) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Palpation des aires ganglionnaires', 'Ganglions < 1 cm, souples', 'Ganglion dur, fixé, sus-claviculaire : cancer, lymphome'],
    ['Palpation de la rate', 'Non palpable', 'Splénomégalie : lymphome, leucémie, activation macrophagique'],
    ['Palpation du foie', 'Non palpable sous le rebord costal', 'Hépatomégalie : infiltration, métastases'],
    ['Inspection de la bouche', 'Muqueuse rose', 'Mucite, candidose : porte d’entrée'],
    ['Point de ponction du cathéter', 'Peau normale', 'Rougeur, pus : infection de cathéter'],
    ['Peau', 'Normale', 'Pétéchies : thrombopénie'],
   ]) + P('La valeur des signes est limitée chez le neutropénique, qui forme peu de pus : la fièvre peut être le seul signe d’infection.', 44), 44, 89)))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fièvre, les sueurs, la fatigue et la perte de poids. '
   'Les signes physiques sont les adénopathies, la splénomégalie et les signes de cytopénie. '
   'Plusieurs syndromes se combinent souvent.', 89, 142) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme'], [
    ['Syndrome tumoral ganglionnaire', 'Adénopathies, splénomégalie', 'Prolifération lymphoïde'],
    ['Syndrome d’insuffisance médullaire', 'Pâleur, infections, saignements', 'Moelle envahie ou détruite par la chimiothérapie'],
    ['Syndrome d’activation macrophagique', 'Fièvre, splénomégalie, bicytopénie, ferritine élevée', 'Cytokines, macrophages activés'],
    ['Syndrome de fièvre néoplasique', 'Fièvre prolongée sans infection, bien tolérée', 'Cytokines tumorales'],
   ]), 89, 142, 88) +
 F('Signe : ganglion sus-claviculaire dur',
   P('Geste : palper le creux au-dessus de la clavicule, patient assis. '
     'Signe : ganglion dur, indolore, fixé. '
     'Mécanisme : drainage lymphatique du thorax et de l’abdomen envahi.', 89), 89) +
 F('Signe : splénomégalie',
   P('Geste : palper sous le rebord costal gauche pendant l’inspiration. '
     'Signe : pôle de la rate perçu au doigt. '
     'Mécanisme : infiltration par le lymphome ou activation macrophagique.', 142), 142) +
 F('Signe : pétéchies',
   P('Geste : inspecter les jambes et la bouche. '
     'Signe : petites taches rouges qui ne s’effacent pas à la pression. '
     'Mécanisme : thrombopénie par envahissement médullaire.', 44), 44)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Selon la recommandation ESMO 2016, la neutropénie fébrile associe une température orale > 38,3 °C et des neutrophiles < 0,5 G/L. '
   'Le diagnostic d’un lymphome repose sur une biopsie ganglionnaire chirurgicale, car la cytoponction est insuffisante selon la classification de Lugano 2014. '
   'Une réponse au naproxène ne suffit pas pour retenir une fièvre néoplasique, car il faut d’abord exclure une infection.', 44, 89, 88) +
 F('Critères',
   TAB(['Situation', 'Critère', 'Performance'], [
    ['Neutropénie fébrile (ESMO 2016)', 'Température orale > 38,3 °C ou 2 mesures > 38,0 °C pendant 2 heures, neutrophiles < 0,5 G/L', 'Définition de prise en charge'],
    ['Faible risque (score MASCC 2000)', 'Score ≥ 21', 'Valeur prédictive positive 91 %, sensibilité 71 %, spécificité 68 %'],
    ['Syndrome d’activation macrophagique (HLH-2004)', '5 critères sur 8', 'Critères pédiatriques appliqués à l’adulte'],
    ['HScore (2014)', '9 variables', 'Probabilité < 1 % si ≤ 90, > 99 % si ≥ 250'],
    ['Symptômes B (Lugano 2014)', 'Fièvre > 38,3 °C, sueurs nocturnes, perte de poids > 10 % en 6 mois', 'Notés seulement dans le lymphome de Hodgkin'],
   ]) + P('Correction de l’original : la classification de Lugano fixe la fièvre des symptômes B à plus de 38,3 °C, et non 38 °C.', 89), 44, 138, 142, 141, 89)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Biopsie ganglionnaire chirurgicale', 'Type exact du lymphome (morphologie, immunohistochimie, cytométrie en flux)', 'Examen de référence', 'Geste invasif'],
    ['Biopsie à l’aiguille épaisse', 'Diagnostic si la chirurgie est impossible', 'Moins de tissu', 'Si non contributive : biopsie chirurgicale'],
    ['PET-CT au FDG', 'Bilan d’extension des lymphomes avides de FDG', 'Change le stade chez 10 à 30 % des patients', 'Ne remplace pas la biopsie'],
    ['Myélogramme et biopsie médullaire', 'Leucémie, activation macrophagique', 'Hémophagocytose visible', 'Plus nécessaire dans le bilan du lymphome de Hodgkin'],
   ]), 89, 142) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'NFS avec formule, frottis sanguin', 'Toujours'],
    ['Première', '2 paires d’hémocultures, dont une sur le cathéter', 'Avant l’antibiotique, sans le retarder'],
    ['Première', 'CRP, créatinine, tests hépatiques, LDH', 'Toujours'],
    ['Première', 'Radiographie du thorax, analyse d’urine', 'Selon les signes'],
    ['Seconde', 'Scanner thoraco-abdomino-pelvien ou PET-CT', 'Fièvre inexpliquée, adénopathies'],
    ['Seconde', 'Ferritine, triglycérides, fibrinogène', 'Suspicion d’activation macrophagique'],
    ['Seconde', 'Électrophorèse des protéines', 'Suspicion de myélome'],
   ]), 44, 89, 141) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Prélever les hémocultures et la NFS dès l’arrivée, sans retarder l’antibiotique.', 'Demander la biopsie ganglionnaire avant tout glucocorticoïde, qui peut masquer un lymphome.', 'Réserver le PET-CT aux fièvres inexpliquées après bilan de base.']), 44, 89) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Normal', 'Seuil', 'Signification et conduite'], [
    ['Neutrophiles', 'Selon le laboratoire', '< 0,5 G/L', 'Neutropénie fébrile si fièvre'],
    ['LDH', 'Selon le laboratoire', 'Élevées', 'Masse tumorale active, lyse cellulaire'],
    ['Ferritine', 'Selon le laboratoire', 'Très élevée', 'Activation macrophagique : calculer le HScore'],
    ['HScore', '—', '≥ 250', 'Probabilité > 99 % de syndrome d’activation macrophagique'],
   ]) + P('Correction de l’original : les valeurs normales des LDH et de la ferritine dépendent du laboratoire ; l’audit ne reprend pas les bornes fixes de l’original.', 99), 44, 141) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (LDH élevées sans masse)', 'Hémolyse, infarctus, atteinte du foie : répéter'],
    ['Résultat négatif mais clinique forte', 'PET-CT, nouvelle biopsie'],
    ['Résultat limite', 'Avis hématologique ou oncologique'],
    ['Grossesse', 'Échographie, IRM sans gadolinium ; éviter le PET-CT'],
    ['Enfant', 'Avis en onco-hématologie pédiatrique'],
    ['DFGe bas', 'Éviter le produit de contraste iodé, préférer le PET-CT sans contraste'],
    ['Allergie au produit de contraste', 'PET-CT sans contraste, IRM'],
   ]), 89))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le bilan commence par la NFS, le frottis, la CRP, les LDH et des hémocultures. '
   'L’imagerie recherche une masse, et la biopsie confirme le type de cancer. '
   'Chez le neutropénique, ces examens ne doivent pas retarder l’antibiotique.', 44, 89) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si un patient sous chimiothérapie a de la fièvre, alors il reçoit un antibiotique dans l’heure, sans attendre la NFS. '
   'Si le score MASCC est ≥ 21 et que le patient est stable, alors un traitement oral ambulatoire est possible après au moins 4 heures de surveillance. '
   'Si la fièvre persiste sans infection malgré le bilan, alors une fièvre néoplasique est discutée en colloque d’oncologie.', 44, 139, 138, 88) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Fièvre après chimiothérapie', 'Hémocultures et antibiotique intraveineux dans l’heure', 'NFS, score MASCC'],
    ['Score MASCC ≥ 21, patient stable', 'Fluoroquinolone avec amoxicilline-acide clavulanique en ambulatoire', 'Réévaluation si fièvre après 2 à 3 jours'],
    ['Score MASCC < 21 ou instabilité', 'Hospitalisation, bêtalactamine antipseudomonas', 'Réévaluation à 48 heures'],
    ['Ferritine très élevée, cytopénies', 'HScore, myélogramme, avis hématologique', 'Traitement de la cause'],
    ['Fièvre inexpliquée, cancer connu, bilan négatif', 'Test au naproxène', 'Apyrexie en 24 heures ou non'],
   ]), 44, 139, 138, 141, 136)))
MED = F('Fiches médicamenteuses (AIPS et recommandations)',
  TAB(['Médicament (classe)', 'Mécanisme d’action et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Pipéracilline-tazobactam (bêtalactamine et inhibiteur de bêtalactamase)', 'Inhibe la synthèse de la paroi bactérienne ; élimination rénale, demi-vie courte', '4,5 g toutes les 8 heures IV ; durée jusqu’à neutrophiles ≥ 0,5 G/L et 48 heures sans fièvre', 'Allergie aux pénicillines : contre-indication ; adapter au DFGe ; interaction avec le méthotrexate'],
   ['Méropénème, Meronem® (carbapénème)', 'Inhibe la synthèse de la paroi ; élimination rénale', '1 g toutes les 8 heures IV dans la neutropénie fébrile', 'Convulsions ; interaction : baisse du valproate'],
   ['Naproxène, Naproxen-Mepha® (AINS)', 'Inhibe la synthèse des prostaglandines ; demi-vie d’environ 13 heures, élimination urinaire', 'Test : 250 mg 2 fois par jour, dose maximale 1250 mg/j ; quelques jours (hors indication autorisée)', 'Ulcère, insuffisance rénale ; contre-indications : hémorragie digestive, 3e trimestre de grossesse ; interactions : méthotrexate, IEC, sartans'],
   ['Amoxicilline-acide clavulanique avec ciprofloxacine (traitement oral)', 'Paroi bactérienne et ADN gyrase', 'Selon l’AIPS, chez le patient à faible risque', 'Contre-indiqué si prophylaxie par fluoroquinolone déjà en cours'],
  ]), 5, 143, 137, 139)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge sépare deux situations : la neutropénie fébrile, qui est une urgence, et la fièvre néoplasique, qui se traite avec le cancer. '
   'Le traitement de la cause est décidé en colloque multidisciplinaire d’oncologie. '
   'Multiplier les antibiotiques sans réévaluer la piste tumorale retarde le diagnostic.', 44, 88) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans la forme compliquée (neutropénie fébrile à haut risque, sepsis, activation macrophagique), le but est un antibiotique intraveineux dans l’heure qui suit l’admission. '
     'Dans la forme non compliquée (score MASCC ≥ 21), le but est un traitement oral en ambulatoire après au moins 4 heures de surveillance.', 44, 139), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures',
     OL(['<b>A. Urgence</b> : hémocultures, puis antibiotique dans l’heure ; remplissage si hypotension.',
         '<b>B. Stratifier le risque</b> : score MASCC, type de cancer, comorbidités.',
         '<b>C. Traiter la cause</b> : chimiothérapie, immunothérapie, chirurgie ou radiothérapie décidées en colloque.',
         '<b>D. Forme non compliquée</b> : mesures générales (hydratation, hygiène de la bouche et des mains, éducation du patient à mesurer sa température), suivi ambulatoire.']), 44, 139) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail est souvent nécessaire pendant la chimiothérapie et les épisodes de neutropénie fébrile.',
            'La conduite automobile est déconseillée en cas de fièvre, de fatigue marquée ou de médicaments sédatifs.',
            'Un cancer avec perte durable de capacité de travail peut relever de la LAI ; la LAMal prend en charge les traitements.'), 44) +
   F('Traitements non médicamenteux',
     UL(['Éducation du patient : consulter dès 38 °C après une chimiothérapie.', 'Hygiène de la bouche et des mains.', 'Retrait du cathéter s’il est infecté.']), 44, 139) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Pas d’AINS au 3e trimestre ; avis spécialisé'],
      ['Enfant', 'Protocoles d’onco-hématologie pédiatrique'],
      ['Sujet âgé', 'Prudence avec les AINS (rein, estomac)'],
      ['Insuffisance hépatique', 'Adapter selon l’AIPS'],
      ['Insuffisance rénale (DFGe bas)', 'Adapter pipéracilline-tazobactam et méropénème, éviter les AINS'],
     ]), 143, 5), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Température, pression artérielle', 'Toutes les 2 à 4 heures si instable', 'Hypotension : soins intensifs'],
    ['NFS, créatinine', 'Chaque jour', 'Neutrophiles ≥ 0,5 G/L : désescalade'],
    ['Hémocultures', 'À 48 heures si fièvre', 'Positive : traitement ciblé'],
    ['Durée de l’antibiotique', 'Neutrophiles ≥ 0,5 G/L, 48 heures sans fièvre, hémocultures négatives', 'Arrêt'],
   ]) + H4('Critères de sortie, un par un') + OL(['Pas de signe de gravité.', 'Score MASCC ≥ 21.', 'Traitement oral toléré.', 'Retour possible en moins d’une heure et suivi organisé.']), 44, 139) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La mortalité hospitalière de la neutropénie fébrile est de 9,5 % dans une grande série américaine, et dépend des comorbidités. '
     'La fièvre néoplasique répond au naproxène dans 94,1 % des cas d’une méta-analyse. '
     'La recherche 2026 évalue des scores de risque plus précis et la durée courte des antibiotiques.', 140, 137), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire de certains cancers passe par la vaccination. '
   'La recommandation suisse du plan de vaccination 2026 prévoit 2 doses de vaccin contre les HPV entre 11 et 14 ans, avec un objectif de couverture de 90 %. '
   'La prévention tertiaire limite la neutropénie fébrile chez les patients sous chimiothérapie.', 26, 44) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Vaccination contre les HPV et l’hépatite B, arrêt du tabac'],
    ['Secondaire', 'Dépistage des cancers selon l’âge, biopsie rapide d’un ganglion suspect'],
    ['Tertiaire', 'Éducation du patient sous chimiothérapie, antibiotique dans l’heure en cas de fièvre'],
   ]), 26, 44)))
PTS.append(POINT(13, 'Points clés',
 P('Une fièvre après une chimiothérapie est une neutropénie fébrile jusqu’à preuve du contraire et impose un antibiotique dans l’heure. '
   'Un lymphome se diagnostique par biopsie ganglionnaire chirurgicale, pas par cytoponction. '
   'La fièvre néoplasique est un diagnostic d’exclusion, que le test au naproxène soutient. '
   'Une ferritine très élevée avec cytopénies fait calculer le HScore.', 44, 89, 136, 141)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Attendre la NFS avant l’antibiotique chez un patient sous chimiothérapie.', 'Non : antibiotique dans l’heure.'],
  ['Multiplier les antibiotiques devant une fièvre néoplasique.', 'Non : réévaluer la piste tumorale.'],
  ['Poser un diagnostic de lymphome sur une cytoponction.', 'Non : biopsie chirurgicale.'],
  ['Donner des glucocorticoïdes avant la biopsie.', 'Non : ils peuvent masquer le lymphome.'],
  ['Faire un toucher rectal chez un neutropénique.', 'Non : risque de bactériémie.'],
 ]) + P('Ces pièges entraînent le raisonnement ; ils ne sont pas des questions officielles de l’examen fédéral.', 44, 89)))
CTX = {'_prefixe': 'Chez un patient cancéreux',
 'nfs': 'La NFS cherche une neutropénie (< 0,5 G/L) ou une cytopénie d’envahissement médullaire.',
 'frottis': 'Le frottis sanguin cherche des blastes ou des cellules lymphomateuses.',
 'ldh': 'Les LDH élevées reflètent la masse tumorale active.',
 'ferritine': 'Une ferritine très élevée avec cytopénies fait évoquer un syndrome d’activation macrophagique.',
 'crp': 'La CRP est élevée dans l’infection comme dans la fièvre néoplasique.',
 'epp': 'L’électrophorèse des protéines cherche un pic monoclonal de myélome.',
 'tep': 'Le PET-CT au FDG fait le bilan d’extension des lymphomes avides de FDG.',
 'biopsie': 'La biopsie ganglionnaire chirurgicale établit le type de lymphome.',
 'tdm': 'Le scanner cherche une masse ou un abcès.',
 'radio': 'La radiographie du thorax cherche une pneumonie ou une masse médiastinale.',
 'hemoc': 'Les hémocultures précèdent l’antibiotique, sans le retarder.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
