# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.10 · Fièvres d’importation (LOT 6, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('dx10')
M = meta('dx10', 'DX.10', 'Fièvres d’importation', 'Fièvre au retour de voyage : paludisme, dengue, fièvre entérique et rickettsioses',
         'LOT_006_DX10_Fievres_importation_AUDITÉ.html')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('Une fièvre d’importation est une fièvre qui débute pendant ou après un séjour en zone tropicale ou subtropicale. '
   'Le paludisme à Plasmodium falciparum est l’urgence à exclure en premier, car il peut tuer en quelques heures. '
   'Selon les experts suisses, toute fièvre > 37,5 °C au retour d’une zone d’endémie impose un test de paludisme dans les 24 heures.', 30, 29) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Paludisme non compliqué', 'Paludisme sans aucun critère de gravité', 'Paludisme grave'],
    ['Paludisme grave', 'Au moins 1 critère de gravité (Swiss TPH 2025), dont une parasitémie ≥ 2 %', 'Neuropaludisme seul'],
    ['Fièvre entérique', 'Fièvre typhoïde ou paratyphoïde à Salmonella Typhi ou Paratyphi', 'Diarrhée du voyageur'],
    ['Dengue avec signes d’alerte', 'Dengue avec signes qui précèdent la forme sévère (OMS 2009)', 'Dengue sans signe d’alerte'],
    ['Fièvre précoce', 'Fièvre dans le mois qui suit le retour', 'Fièvre tardive (P. vivax, P. ovale)'],
   ]), 29, 146, 145)))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, l’OFSP a reçu sur 52 semaines 274 déclarations de paludisme (3,0 pour 100 000 habitants) et 180 de dengue. '
   'Le chiffre « 2 % des causes de fièvre chez le voyageur » de l’original n’a été retrouvé dans aucune source et il est retiré. '
   'Dans le réseau mondial GeoSentinel, le paludisme est le premier diagnostic précis chez 21 % des voyageurs fébriles.', 25, 99, 144) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Paludisme déclaré', '274 cas sur 52 semaines (3,0 pour 100 000)', 'Suisse, bulletin OFSP 52/2025'],
    ['Dengue déclarée', '180 cas (2,0 pour 100 000)', 'Suisse, bulletin OFSP 52/2025'],
    ['Paludisme importé 1990–2019', '8 439 cas, 52 décès, presque tous dus à P. falciparum', 'Suisse'],
    ['Paludisme parmi les voyageurs fébriles' + PR('21 %', 144), '6957 voyageurs', 'Réseau mondial GeoSentinel'],
    ['Hospitalisation des voyageurs fébriles' + PR('26 %', 144), '6957 voyageurs', 'Réseau mondial GeoSentinel'],
   ], 'Le terrain oriente : les migrants qui rendent visite à leur famille ont plus de fièvres graves ; l’Afrique subsaharienne est la première région du paludisme ; le pronostic dépend du délai de traitement, et le paludisme cause 33 % des décès des voyageurs fébriles du réseau, une mortalité évitable.'), 25, 32, 144)))
PTS.append(POINT(3, 'Physiopathologie',
 P('L’anophèle injecte des sporozoïtes qui se multiplient dans le foie, puis dans les globules rouges, qu’ils détruisent. '
   'Les globules rouges parasités par P. falciparum adhèrent aux petits vaisseaux du cerveau et des reins, ce qui cause la forme grave. '
   'La dengue, transmise par le moustique Aedes, cause une fuite plasmatique, et la fièvre entérique une infection systémique après ingestion.', 147, 29, 146) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Foie, globules rouges, rate, microcirculation.'],
    ['Physiologie', 'La rate retire les globules rouges anormaux.'],
    ['Physiopathologie', 'Hémolyse, adhérence des globules rouges parasités, fuite plasmatique dans la dengue.'],
    ['Clinique', 'Fièvre, frissons, céphalée, splénomégalie, ictère, confusion.'],
    ['Examens', 'Frottis et goutte épaisse, test rapide, NFS, bilirubine, créatinine, glycémie.'],
    ['Traitement', 'Artésunate IV si grave, combinaison à base d’artémisinine par voie orale sinon.'],
   ]), 29, 147) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Multiplication dans les globules rouges', 'Parasitémie en %', 'Artésunate, artéméther-luméfantrine'],
    ['Hémolyse', 'Hémoglobine, bilirubine, LDH', 'Transfusion si anémie grave'],
    ['Fuite plasmatique de la dengue', 'Hématocrite, plaquettes', 'Hydratation surveillée'],
    ['Bactériémie de la fièvre entérique', 'Hémocultures', 'Antibiotique selon l’antibiogramme'],
   ]), 29, 146) +
 F('Critères de paludisme grave (Swiss TPH 2025) : seuils et exemple',
   P('Un seul critère suffit : score de Glasgow < 11, créatinine > 265 µmol/L, pH < 7,3 ou lactates ≥ 5 mmol/L, glycémie < 2,2 mmol/L, bilirubine > 50 µmol/L avec parasitémie > 2 %, hémoglobine < 7 g/dL, choc, parasitémie ≥ 2 %. '
     'Exemple : voyageur de retour du Cameroun, confus, parasitémie 6,4 %, créatinine 280 µmol/L, glycémie 2,1 mmol/L : 3 critères, donc paludisme grave et artésunate IV aux soins intensifs. '
     'Correction de l’original : le seuil d’acidose est un pH < 7,3 (et non 7,35), les lactates ≥ 5 mmol/L.', 29), 29)))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant une fièvre au retour de voyage, le médecin cherche d’abord un paludisme, même si le patient a pris une prophylaxie. '
   'Il évalue ensuite la gravité, puis cherche les autres causes selon la région, la durée d’incubation et les signes. '
   'Les infections cosmopolites, comme la grippe ou la pyélonéphrite, restent fréquentes chez le voyageur.', 30, 144, 145) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même population : réseau mondial GeoSentinel, 6957 voyageurs fébriles)',
   TAB(['Cause et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Maladie fébrile systémique' + PR('35 %', 144), 'Fièvre sans point d’appel', 'Frottis, goutte épaisse, hémocultures'],
    ['dont paludisme' + PR('21 %', 144), 'Splénomégalie, plaquettes < 150 G/L, bilirubine élevée', 'Frottis et goutte épaisse, test rapide'],
    ['Fièvre avec diarrhée' + PR('15 %', 144), 'Diarrhée, sang dans les selles', 'Coproculture'],
    ['Fièvre respiratoire' + PR('14 %', 144), 'Toux, dyspnée', 'Radiographie, PCR respiratoire'],
    ['Dengue (fréquence non chiffrée dans cette source)', 'Éruption, leucopénie, thrombopénie', 'PCR ou antigène NS1, sérologie'],
    ['Fièvre entérique (fréquence non chiffrée dans cette source)', 'Splénomégalie, ALAT ≥ 70 U/L', 'Hémocultures'],
   ]), 144, 145)))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise les pays et les régions visités, les dates de départ et de retour, la prophylaxie, les vaccinations, les piqûres, les baignades en eau douce et les contacts sexuels.', 30, 145) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Dans quels pays et régions êtes-vous allé ?', 'Le risque dépend de la région.', 'Afrique subsaharienne : paludisme d’abord.'],
    ['Quand êtes-vous rentré ?', 'Incubation d’au moins 6 jours pour le paludisme.', 'Fièvre avant 6 jours de séjour : autre cause.'],
    ['Avez-vous pris une prophylaxie ?', 'Aucune n’est efficace à 100 %.', 'Le test reste obligatoire.'],
    ['Vous êtes-vous baigné en eau douce ?', 'Schistosomose aiguë.', 'Éosinophiles, sérologie.'],
    ['Avez-vous une tache noire sur la peau ?', 'Escarre d’une rickettsiose.', 'Doxycycline.'],
    ['Êtes-vous confus ou somnolent ?', 'Paludisme grave.', 'Soins intensifs.'],
   ]), 147, 145, 30) +
 U('<b>Drapeaux rouges (144 ou urgences)</b> : confusion, convulsions, ictère, urines rares, saignements, détresse respiratoire, vomissements répétés.', 29)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen évalue la conscience avec le score de Glasgow, la pression artérielle et la respiration. '
   'Il recherche une splénomégalie, un ictère, une éruption, une escarre et des pétéchies. '
   'Un examen normal n’exclut pas un paludisme.', 29, 145) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Score de Glasgow', '15', '< 11 : paludisme cérébral'],
    ['Pression artérielle, remplissage capillaire', 'Normale, < 3 secondes', 'Pression systolique < 80 mmHg ou remplissage ≥ 3 secondes : choc'],
    ['Palpation de la rate', 'Non palpable', 'Splénomégalie : paludisme, fièvre entérique'],
    ['Inspection des conjonctives', 'Blanches', 'Ictère : hémolyse'],
    ['Inspection de la peau', 'Normale', 'Éruption : dengue ; escarre : rickettsiose'],
    ['Fréquence respiratoire', '12–20 par minute', 'Détresse : œdème pulmonaire'],
   ]) + P('La valeur des signes est faible pour exclure : la fièvre sans point d’appel est justement un signe prédictif de paludisme.', 145), 29, 145)))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fièvre, les frissons, la céphalée et les myalgies. '
   'Les signes physiques sont la splénomégalie, l’ictère et l’éruption. '
   'Plusieurs syndromes se combinent souvent.', 147, 145) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme'], [
    ['Syndrome palustre simple', 'Fièvre, frissons, céphalée, myalgies', 'Éclatement des globules rouges'],
    ['Syndrome de paludisme grave', 'Coma, acidose, insuffisance rénale, choc', 'Adhérence des globules rouges parasités'],
    ['Syndrome de fuite plasmatique', 'Douleur abdominale, épanchements, hématocrite en hausse', 'Dengue'],
    ['Syndrome éruptif fébrile', 'Éruption, escarre', 'Dengue, rickettsiose'],
   ]), 29, 146, 145) +
 F('Signe : splénomégalie',
   P('Geste : palper sous le rebord costal gauche pendant l’inspiration. '
     'Signe : pôle de la rate perçu au doigt. '
     'Mécanisme : la rate retire les globules rouges parasités.', 145), 145) +
 F('Signe : escarre d’inoculation',
   P('Geste : inspecter toute la peau, y compris les plis. '
     'Signe : croûte noire entourée d’une rougeur. '
     'Mécanisme : piqûre de tique infectée par une rickettsie.', 145), 145) +
 F('Signe : saignement muqueux de la dengue',
   P('Geste : inspecter les muqueuses et la peau des jambes. '
     'Signe : saignement des gencives ou pétéchies. '
     'Mécanisme : thrombopénie et fragilité des capillaires, un signe d’alerte.', 146), 146)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le diagnostic de paludisme repose sur le frottis sanguin et la goutte épaisse, avec la parasitémie en %. '
   'Selon la recommandation Swiss TPH 2025, adaptée des critères de l’OMS, un seul critère de gravité suffit, dont une créatinine > 265 µmol/L ou une parasitémie ≥ 2 %. '
   'Un premier test négatif ne suffit pas, car le paludisme n’est exclu qu’après 3 jours consécutifs de tests négatifs.', 29, 30) +
 F('Critères',
   TAB(['Situation', 'Critère', 'Remarque'], [
    ['Paludisme grave (Swiss TPH 2025)', '≥ 1 critère de gravité', 'Seuil suisse de parasitémie : ≥ 2 %'],
    ['Seuil de parasitémie selon d’autres pays', 'Allemagne : ≥ 5 % ; OMS : ≥ 10 %', 'Choix suisse plus prudent'],
    ['Symptômes depuis ≥ 3 jours', 'Critère suisse si la parasitémie n’est pas disponible', 'Traiter comme grave'],
    ['Exclusion du paludisme (ECTM)', '3 jours consécutifs de tests négatifs', 'Correction : l’original parlait de 3 frottis espacés'],
    ['Dengue avec signes d’alerte (OMS 2009)', 'Douleur abdominale, vomissements, foie > 2 cm, hématocrite en hausse avec chute des plaquettes', 'Surveillance hospitalière'],
   ]), 29, 30, 146)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Goutte épaisse', 'Présence de plasmodiums', 'Plus sensible que le frottis', 'Espèce difficile à lire'],
    ['Frottis sanguin mince', 'Espèce et parasitémie en %', 'Spécifique', 'Moins sensible'],
    ['Test de diagnostic rapide', 'Antigène de P. falciparum', 'Rapide', 'Ne donne pas la parasitémie'],
    ['Hémocultures', 'Fièvre entérique, bactériémie', 'Référence pour la fièvre entérique', 'Positives seulement dans une partie des cas'],
   ]), 29, 145) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Frottis et goutte épaisse ou test rapide', 'Toujours, dans les 24 heures'],
    ['Première', 'NFS, plaquettes', 'Toujours'],
    ['Première', 'Créatinine, bilirubine, glycémie, lactates', 'Toujours (critères de gravité)'],
    ['Première', 'Hémocultures', 'Toujours'],
    ['Seconde', 'PCR ou antigène NS1 de la dengue', 'Éruption, leucopénie'],
    ['Seconde', 'Sérologies (schistosomose, rickettsiose)', 'Éosinophilie, escarre'],
   ]), 29, 30, 145) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Demander le test de paludisme le jour même, au plus tard dans les 24 heures.', 'Répéter le test chaque jour pendant 3 jours s’il est négatif.', 'Signaler la région du voyage au laboratoire.']), 30) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Normal', 'Seuil', 'Signification et conduite'], [
    ['Parasitémie', '0 %', '≥ 2 %', 'Paludisme grave : artésunate IV'],
    ['Créatinine', 'Selon le laboratoire', '> 265 µmol/L', 'Paludisme grave'],
    ['Glycémie', '4–6 mmol/L', '< 2,2 mmol/L', 'Paludisme grave : glucose IV'],
    ['Plaquettes', '150–400 G/L', '< 150 G/L', 'Oriente vers le paludisme ou la dengue'],
    ['Éosinophiles', '< 0,5 G/L', '≥ 0,5 G/L', 'Schistosomose aiguë'],
   ]), 29, 145) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (test rapide positif, frottis négatif)', 'Antigène persistant après un traitement : avis du laboratoire'],
    ['Résultat négatif mais clinique forte', 'Répéter chaque jour pendant 3 jours'],
    ['Résultat limite', 'Avis du Swiss TPH, joignable 24 h/24'],
    ['Grossesse', 'Risque de forme grave : hospitalisation'],
    ['Enfant', 'Critères pédiatriques, risque élevé'],
    ['DFGe bas (< 30 mL/min)', 'Insuffisance rénale : critère de gravité ; éviter le produit de contraste iodé'],
    ['Allergie au produit de contraste iodé, pacemaker', 'Échographie de l’abdomen ; IRM seulement si le pacemaker est compatible'],
   ]), 29, 147))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le bilan commence par le frottis et la goutte épaisse ou un test rapide, la NFS, la créatinine, la bilirubine, la glycémie et des hémocultures. '
   'Les autres examens suivent la région et les signes. '
   'Le test de paludisme se répète si le premier est négatif.', 29, 30) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si un test de paludisme est positif avec au moins 1 critère de gravité, alors le patient reçoit de l’artésunate IV aux soins intensifs. '
   'Si le paludisme est non compliqué, alors un traitement oral par artéméther-luméfantrine est possible en ambulatoire. '
   'Si le test est négatif, alors il est répété chaque jour pendant 3 jours.', 29, 30) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Paludisme avec critère de gravité', 'Artésunate IV, soins intensifs', 'Parasitémie chaque jour, hémolyse retardée aux jours 7, 14, 21, 28'],
    ['Paludisme non compliqué', 'Artéméther-luméfantrine par voie orale', 'Suivi ambulatoire'],
    ['Parasitémie 2 à 4 % sans autre critère, adulte sans comorbidité', 'Traitement oral possible, 2 doses en observation (8 heures)', 'Suivi rapproché'],
    ['Test négatif', 'Répéter chaque jour pendant 3 jours', 'Chercher dengue et fièvre entérique'],
    ['Éruption et thrombopénie', 'Dengue : chercher les signes d’alerte', 'Hématocrite, plaquettes'],
   ]), 29, 30, 146)))
MED = F('Fiches médicamenteuses (AIPS et recommandations)',
  TAB(['Médicament (classe)', 'Mécanisme d’action et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Artésunate IV (dérivé de l’artémisinine)', 'Élimine vite les parasites ; pas d’adaptation en cas d’insuffisance rénale ou hépatique', '2,4 mg/kg IV à 0, 12 et 24 heures, puis toutes les 24 heures, puis relais oral', 'Hémolyse retardée chez environ 27 % des voyageurs européens : contrôler aux jours 7, 14, 21 et 28'],
   ['Artéméther-luméfantrine, Riamet® (combinaison à base d’artémisinine)', 'Agit sur les schizontes ; demi-vie de l’artéméther 2 heures, de la luméfantrine 2 à 6 jours', 'AIPS : 24 comprimés sur 3 jours ; Swiss TPH 2025 : 4 comprimés 2 fois par jour pendant 5 jours (40 comprimés), avec un repas gras', 'Contre-indications : paludisme grave, QTc long ; interactions : macrolides, fluoroquinolones'],
   ['Atovaquone-proguanil, Malarone® (antipaludéen)', 'Inhibe le complexe cytochrome bc1 mitochondrial ; demi-vie de l’atovaquone 2 à 3 jours', 'Traitement : 4 comprimés 1 fois par jour pendant 3 jours ; prophylaxie : 1 comprimé par jour', 'Prophylaxie contre-indiquée si clairance de la créatinine < 30 mL/min ; interactions : coumarines, rifampicine'],
  ]), 29, 31, 6, 148)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge dépend de la gravité : hospitalisation et artésunate IV pour le paludisme grave, traitement oral pour le paludisme non compliqué. '
   'Le Swiss TPH donne un conseil 24 heures sur 24 aux médecins. '
   'L’artésunate réduit la mortalité du paludisme grave de 22 % à 15 % par rapport à la quinine.', 29, 92) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans la forme compliquée (paludisme grave), le but est d’injecter l’artésunate IV dans l’heure, aux soins intensifs. '
     'Dans la forme non compliquée, le but est un traitement oral complet en ambulatoire avec un suivi rapproché.', 29), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures',
     OL(['<b>A. Urgence</b> : paludisme grave : artésunate IV, soins intensifs, glucose si hypoglycémie.',
         '<b>B. Classer la gravité</b> : critères Swiss TPH 2025, parasitémie, car un seul critère impose la voie IV.',
         '<b>C. Traitement oral</b> : artéméther-luméfantrine pendant 5 jours selon le Swiss TPH.',
         '<b>D. Forme non compliquée</b> : mesures générales (hydratation, antipyrétique par paracétamol, éviter les AINS si dengue possible), suivi ambulatoire.']), 29, 146) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail est nécessaire pendant la phase aiguë.',
            'La conduite automobile est interdite pendant la fièvre et la convalescence d’un paludisme grave.',
            'Le paludisme contracté pendant un séjour professionnel hors d’Europe figure dans la liste des maladies professionnelles de la LAA ; sinon la LAMal prend en charge le traitement.'), 29, 149) +
   F('Traitements non médicamenteux',
     UL(['Hydratation surveillée dans la dengue.', 'Transfusion si anémie grave.', 'Dialyse si insuffisance rénale.']), 29, 146) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Artésunate IV pour le paludisme grave à tout trimestre ; artéméther-luméfantrine possible aussi au 1er trimestre'],
      ['Enfant', 'Dose selon le poids (AIPS et Swiss TPH)'],
      ['Sujet âgé', 'Risque de forme grave : hospitalisation large'],
      ['Insuffisance hépatique', 'Artésunate sans adaptation ; Riamet contre-indiqué si sévère'],
      ['Insuffisance rénale (DFGe bas)', 'Artésunate sans adaptation ; Malarone en prophylaxie contre-indiquée si clairance < 30 mL/min'],
     ]), 29, 148), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Parasitémie', 'Chaque jour', 'Absence de baisse : avis spécialisé'],
    ['Glycémie, créatinine, lactates', 'Plusieurs fois par jour si grave', 'Aggravation : soins intensifs'],
    ['Hémoglobine et marqueurs d’hémolyse', 'Jours 7, 14, 21, 28 après l’artésunate', 'Hémolyse retardée : transfusion si besoin'],
    ['Hématocrite et plaquettes (dengue)', 'Chaque jour', 'Signes d’alerte : hospitalisation'],
   ]) + H4('Critères de sortie, un par un') + OL(['Aucun critère de gravité.', 'Au moins 2 doses de traitement oral prises et gardées.', 'Fièvre en baisse.', 'Suivi ambulatoire organisé.']), 29, 146) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('En Suisse, 52 patients sont morts du paludisme importé en 30 ans, presque tous d’un P. falciparum. '
     'Le pronostic dépend surtout du délai du diagnostic. '
     'La recherche 2026 évalue la durée de 5 jours de l’artéméther-luméfantrine et la surveillance de l’hémolyse retardée.', 32, 29), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur la protection contre les piqûres de moustiques et, selon la destination, une prophylaxie médicamenteuse ou un traitement d’urgence. '
   'La recommandation suisse de l’OFSP conseille une consultation 4 à 6 semaines avant le départ. '
   'La prévention tertiaire consiste à consulter dès la fièvre pour un test dans les 24 heures.', 147, 30) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Vêtements couvrants, répulsifs, moustiquaires imprégnées ; prophylaxie (par exemple atovaquone-proguanil) selon la destination'],
    ['Secondaire', 'Test de paludisme dans les 24 heures pour toute fièvre > 37,5 °C au retour'],
    ['Tertiaire', 'Artésunate rapide, surveillance de l’hémolyse retardée'],
   ]), 147, 30, 6)))
PTS.append(POINT(13, 'Points clés',
 P('Une fièvre au retour d’une zone d’endémie est un paludisme jusqu’à preuve du contraire, même après une prophylaxie. '
   'Le test se fait dans les 24 heures et se répète pendant 3 jours s’il est négatif. '
   'Un seul critère de gravité impose l’artésunate IV aux soins intensifs. '
   'En Suisse, le seuil de parasitémie du paludisme grave est de 2 %.', 30, 29)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Exclure le paludisme parce que le patient a pris sa prophylaxie.', 'Non : aucune prophylaxie n’est efficace à 100 %.'],
  ['S’arrêter à un seul test négatif.', 'Non : répéter pendant 3 jours.'],
  ['Traiter un paludisme grave par voie orale.', 'Non : artésunate IV.'],
  ['Donner un AINS en cas de dengue possible.', 'Non : paracétamol.'],
  ['Oublier le contrôle de l’hémolyse après l’artésunate.', 'Non : jours 7, 14, 21 et 28.'],
 ]) + P('Ces pièges entraînent le raisonnement ; ils ne sont pas des questions officielles de l’examen fédéral.', 29, 30)))
CTX = {'_prefixe': 'Au retour de voyage',
 'tdr': 'Le test de diagnostic rapide détecte un antigène de P. falciparum, sans donner la parasitémie.',
 'frottis': 'Le frottis sanguin et la goutte épaisse confirment le paludisme et donnent la parasitémie.',
 'nfs': 'La NFS montre une thrombopénie dans le paludisme et la dengue.',
 'crp': 'La CRP est élevée mais ne distingue pas les causes.',
 'creat': 'Une créatinine > 265 µmol/L est un critère de paludisme grave.',
 'gly': 'Une glycémie < 2,2 mmol/L est un critère de paludisme grave.',
 'lact': 'Des lactates ≥ 5 mmol/L sont un critère de paludisme grave.',
 'hemoc': 'Les hémocultures cherchent une fièvre entérique.',
 'pcr': 'La PCR confirme la dengue au début de la maladie.',
 'sero': 'Les sérologies cherchent une schistosomose ou une rickettsiose.',
 'copro': 'La coproculture cherche une cause de fièvre avec diarrhée.',
 'radio': 'La radiographie du thorax cherche une pneumonie ou un œdème pulmonaire.',
 'echoabdo': 'L’échographie de l’abdomen mesure la rate.',
 'tdm': 'Le scanner cherche un abcès du foie.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
