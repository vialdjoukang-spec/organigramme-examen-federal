# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.8 · Maladies systémiques et connectivites (LOT 6, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('dx8')
M = meta('dx8', 'DX.8', 'Maladies systémiques et connectivites', 'Fièvre et maladies systémiques : lupus, artérite à cellules géantes, maladie de Still et polyarthrite rhumatoïde',
         'LOT_006_DX8_Maladies_systemiques_connectivites_AUDITÉ.html')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('Les maladies systémiques sont des maladies inflammatoires non infectieuses qui touchent plusieurs organes, comme le lupus, les vascularites, la maladie de Still et la polyarthrite rhumatoïde. '
   'Elles se révèlent parfois par une fièvre prolongée avec une CRP élevée. '
   'Le diagnostic n’est retenu qu’après avoir exclu une infection et un cancer.', 130, 84) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Connectivite', 'Maladie auto-immune avec auto-anticorps (lupus, syndrome de Sjögren, sclérodermie)', 'Vascularite'],
    ['Vascularite', 'Inflammation de la paroi des vaisseaux (artérite à cellules géantes, vascularites à ANCA)', 'Athérosclérose'],
    ['Maladie auto-inflammatoire', 'Inflammation de l’immunité innée sans auto-anticorps (maladie de Still)', 'Infection'],
    ['Critères de classification', 'Outil de recherche pour des groupes homogènes', 'Critères diagnostiques individuels'],
    ['Fièvre d’origine inconnue', 'Plus de 3 semaines, > 38,3 °C, sans diagnostic après bilan de base', 'Fièvre prolongée simple'],
   ]), 130, 86)))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, le registre national de l’artérite à cellules géantes compte 337 patients d’âge médian 72 ans, dont 64 % de femmes et 31 % avec des symptômes visuels. '
   'Le chiffre « 3 % des fièvres prolongées en Suisse » attribué à la Société suisse de rhumatologie de l’original n’a été retrouvé dans aucune source et il est retiré. '
   'En Europe, une étude néerlandaise de fièvres d’origine inconnue trouve une maladie inflammatoire non infectieuse chez 22 % des patients.', 131, 130, 99) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Maladies inflammatoires non infectieuses' + PR('22 %', 130), 'Parmi 73 fièvres d’origine inconnue', 'Pays-Bas'],
    ['Âge médian de l’artérite à cellules géantes', '72 ans', 'Registre suisse SCQM'],
    ['Symptômes visuels au diagnostic' + PR('31 %', 131), '337 patients', 'Registre suisse SCQM'],
    ['Biopsie temporale positive', '66 % des biopsies faites', 'Registre suisse SCQM'],
   ], 'Le terrain oriente : femme jeune pour le lupus, âge > 50 ans pour l’artérite à cellules géantes ; le pronostic dépend de l’atteinte rénale, oculaire et des infections sous traitement, une cause de mortalité.'), 130, 131)))
PTS.append(POINT(3, 'Physiopathologie',
 P('Dans les connectivites, une perte de tolérance produit des auto-anticorps et des complexes immuns qui se déposent dans les reins, la peau et les séreuses. '
   'Dans les maladies auto-inflammatoires, l’immunité innée produit trop d’interleukine 1 et d’interleukine 6, qui causent fièvre et CRP élevée. '
   'Les traitements visent ces mécanismes.', 132, 133) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Reins, peau, articulations, séreuses, artères de la tête.'],
    ['Physiologie', 'La tolérance du soi évite l’attaque des propres tissus.'],
    ['Physiopathologie', 'Auto-anticorps, complexes immuns, cytokines.'],
    ['Clinique', 'Fièvre, arthrites, éruption, céphalée, atteinte d’organe.'],
    ['Examens', 'CRP, auto-anticorps, complément, urine, imagerie.'],
    ['Traitement', 'Glucocorticoïdes, hydroxychloroquine, immunosuppresseurs, biothérapies.'],
   ]), 132) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Auto-anticorps et complexes immuns', 'Anticorps antinucléaires, anti-ADN, complément', 'Hydroxychloroquine, immunosuppresseurs'],
    ['Interleukine 6 dans l’artérite', 'CRP, échographie des temporales', 'Tocilizumab'],
    ['Interleukine 1 dans la maladie de Still', 'Ferritine, CRP', 'Anakinra'],
    ['Inflammation de la synoviale', 'Anti-CCP, échographie', 'Méthotrexate'],
   ]), 132, 133) +
 F('Critères EULAR/ACR 2019 du lupus : comptage et exemple',
   P('Le critère d’entrée est un test d’anticorps antinucléaires positif. '
     'Les items cliniques et immunologiques valent 2 à 10 points, et le lupus est classé à partir de 10 points. '
     'Exemple : fièvre (2), arthrite (6), anti-ADN natif (6), soit 14 points, à condition d’avoir exclu une infection.', 86), 86)))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant une fièvre prolongée, le médecin cherche d’abord une urgence : sepsis, perte visuelle de l’artérite, atteinte rénale. '
   'Il exclut ensuite une infection et un cancer, puis cherche une maladie systémique. '
   'Chez un patient sous immunosuppresseur, la fièvre est infectieuse jusqu’à preuve du contraire.', 130, 133) +
 F('Diagnostic différentiel de la fièvre d’origine inconnue (fréquences en exposant rouge, même population : étude néerlandaise)',
   TAB(['Cause et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Maladie inflammatoire non infectieuse' + PR('22 %', 130), 'Arthrites, éruption, céphalée, âge', 'Auto-anticorps, PET-CT'],
    ['Infection' + PR('16 %', 130), 'Souffle, voyage, matériel', 'Hémocultures, imagerie'],
    ['Néoplasie' + PR('7 %', 130), 'Perte de poids, adénopathies', 'Scanner, biopsie'],
    ['Causes diverses' + PR('4 %', 130), 'Médicament, thrombose', 'Arrêt du médicament'],
    ['Pas de diagnostic' + PR('51 %', 130), 'Souvent évolution favorable', 'Suivi'],
   ]), 130)))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien recherche les arthralgies, l’éruption, la photosensibilité, la sécheresse buccale, la céphalée, la claudication de la mâchoire, les troubles visuels et les traitements immunosuppresseurs.', 131, 86) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Avez-vous mal en mâchant ?', 'Claudication de la mâchoire.', 'Artérite à cellules géantes.'],
    ['Voyez-vous flou ou double ?', 'Ischémie du nerf optique.', 'Glucocorticoïdes immédiats.'],
    ['Avez-vous une éruption au soleil ?', 'Photosensibilité.', 'Lupus.'],
    ['Avez-vous mal aux épaules le matin ?', 'Pseudopolyarthrite rhizomélique.', 'CRP, échographie.'],
    ['Prenez-vous un traitement qui baisse l’immunité ?', 'Infection opportuniste.', 'Hémocultures avant tout.'],
    ['Avez-vous mal à la gorge avec une éruption saumonée ?', 'Maladie de Still.', 'Ferritine.'],
   ]), 131, 84) +
 U('<b>Drapeaux rouges (144 ou urgences)</b> : perte visuelle brutale chez un patient de plus de 50 ans, dyspnée, œdèmes avec urine mousseuse, fièvre sous immunosuppresseur.', 133, 132)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen palpe les artères temporales, compte les articulations gonflées et inspecte la peau et la bouche. '
   'Il mesure la pression artérielle et recherche des œdèmes. '
   'Un examen normal n’exclut pas une maladie systémique.', 131, 86) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Palpation des artères temporales', 'Pouls présent, artère souple', 'Artère indurée, sans pouls : artérite'],
    ['Comptage des articulations', 'Pas de synovite', 'Arthrite des mains : lupus, polyarthrite rhumatoïde'],
    ['Inspection du visage', 'Peau normale', 'Éruption en ailes de papillon : lupus'],
    ['Inspection de la bouche', 'Muqueuse normale', 'Ulcérations : lupus'],
    ['Pression artérielle et œdèmes', 'Normale, pas d’œdème', 'Hypertension, œdèmes : néphrite lupique'],
    ['Ganglions et rate', 'Non palpables', 'Adénopathies, splénomégalie : Still, lymphome'],
   ]) + P('La valeur des signes isolés est faible : la biopsie temporale n’est positive que dans 66 % des cas où elle est faite.', 131), 131, 86)))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fièvre, la fatigue, la céphalée et les douleurs articulaires. '
   'Les signes physiques sont l’arthrite, l’éruption et l’induration des artères temporales. '
   'Plusieurs syndromes se combinent souvent.', 131, 86) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme'], [
    ['Syndrome de polyarthrite inflammatoire', 'Raideur matinale, synovites des mains', 'Synovite'],
    ['Syndrome cutanéo-articulaire', 'Éruption, arthrites, séreuses', 'Lupus'],
    ['Syndrome de l’artérite temporale', 'Céphalée, claudication de la mâchoire, troubles visuels', 'Inflammation des grosses artères'],
    ['Syndrome de Still', 'Fièvre en pics, éruption saumonée, mal de gorge', 'Interleukine 1'],
   ]), 84, 131) +
 F('Signe : éruption saumonée fugace',
   P('Geste : examiner la peau au pic de fièvre. '
     'Signe : macules rose saumon qui disparaissent avec la fièvre. '
     'Mécanisme : inflammation de la maladie de Still.', 84), 84) +
 F('Signe : artère temporale indurée',
   P('Geste : palper les deux artères devant l’oreille. '
     'Signe : cordon dur, douloureux, sans pouls. '
     'Mécanisme : paroi épaissie par l’inflammation.', 131), 131) +
 F('Signe : synovite des mains',
   P('Geste : presser les articulations des doigts. '
     'Signe : gonflement mou, douloureux. '
     'Mécanisme : inflammation de la synoviale.', 85), 85)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Les critères de classification EULAR/ACR 2019 du lupus ont une sensibilité de 96,1 % et une spécificité de 93,4 %. '
   'Les critères ACR/EULAR 2022 de l’artérite à cellules géantes s’appliquent à partir de 50 ans et de 6 points. '
   'Remplir des critères de classification ne suffit pas, car il faut d’abord exclure infection et cancer.', 86, 87, 84) +
 F('Critères',
   TAB(['Maladie', 'Critère', 'Performance'], [
    ['Lupus (EULAR/ACR 2019)', 'Anticorps antinucléaires positifs, puis ≥ 10 points', 'Sensibilité 96,1 %, spécificité 93,4 %'],
    ['Artérite à cellules géantes (ACR/EULAR 2022)', 'Âge ≥ 50 ans, ≥ 6 points', 'Sensibilité 87,0 %, spécificité 94,8 %'],
    ['Maladie de Still (Yamaguchi 1992)', '≥ 5 critères dont 2 majeurs, exclusions', 'Sensibilité 96,2 %, spécificité 92,1 %'],
    ['Polyarthrite rhumatoïde (ACR/EULAR 2010)', 'Score ≥ 6 sur 10', 'Classement'],
   ]) + P('La ferritine est souvent très élevée dans la maladie de Still, mais elle ne fait pas partie des critères de Yamaguchi.', 84), 86, 87, 84, 85)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Anticorps antinucléaires', 'Critère d’entrée du lupus', 'Très sensibles', 'Peu spécifiques'],
    ['Anti-ADN natif, anti-Sm', 'Lupus', 'Spécifiques', 'Moins sensibles'],
    ['Échographie des temporales', 'Artérite', 'Examen le plus utilisé en Suisse (76 %)', 'Dépend de l’opérateur'],
    ['Biopsie de l’artère temporale', 'Artérite', 'Positive dans 66 % des cas', 'Lésions segmentaires'],
    ['PET-CT', 'Vascularite des gros vaisseaux, cause cachée', 'Utile si CRP élevée', 'Disponibilité'],
   ]), 131, 86, 130) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'NFS, CRP, créatinine, analyse d’urine', 'Toujours'],
    ['Première', 'Hémocultures', 'Avant tout traitement'],
    ['Première', 'Anticorps antinucléaires, facteur rhumatoïde, anti-CCP', 'Suspicion de connectivite ou de polyarthrite'],
    ['Seconde', 'Anti-ADN, complément C3 et C4', 'Anticorps antinucléaires positifs'],
    ['Seconde', 'Échographie des temporales, PET-CT', 'Âge > 50 ans, céphalée'],
    ['Seconde', 'Ferritine', 'Suspicion de Still'],
   ]), 130, 131) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Demander les auto-anticorps sur une suspicion clinique, pas en dépistage.', 'Faire l’échographie temporale dans les jours qui suivent le début des glucocorticoïdes.', 'Prélever les hémocultures avant tout immunosuppresseur.']), 133, 130) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Normal', 'Seuil', 'Signification et conduite'], [
    ['Anticorps antinucléaires', 'Négatifs', '≥ 1/80', 'Entrée dans les critères du lupus'],
    ['Complément C3, C4', 'Normal', 'Bas', 'Lupus actif'],
    ['CRP', '< 5 mg/L', 'Très élevée chez un lupique', 'Penser à une infection'],
    ['Protéinurie', '< 0,15 g/j', '> 0,5 g/j', 'Néphrite lupique : biopsie rénale'],
   ]), 86, 132) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (anticorps antinucléaires faibles sans signe)', 'Fréquent chez les sujets sains : ne pas traiter'],
    ['Résultat négatif mais clinique forte', 'Répéter, biopsie d’organe'],
    ['Résultat limite', 'Avis rhumatologique'],
    ['Grossesse', 'Anticorps anti-Ro et antiphospholipides, suivi spécialisé'],
    ['Enfant', 'Maladie de Still de l’enfant, avis pédiatrique'],
    ['DFGe bas', 'Biopsie rénale, IRM sans gadolinium'],
    ['Allergie au produit de contraste', 'Échographie, PET-CT'],
   ]), 132))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le bilan commence par la NFS, la CRP, la créatinine et l’analyse d’urine, avec des hémocultures. '
   'Les auto-anticorps se demandent selon l’orientation clinique. '
   'L’imagerie vasculaire confirme l’artérite.', 130, 131) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une artérite à cellules géantes est fortement suspectée, alors les glucocorticoïdes débutent sans délai et l’avis spécialisé a lieu dans les 24 heures. '
   'Si un lupique a de la fièvre avec une CRP très élevée, alors une infection est recherchée d’abord. '
   'Si les auto-anticorps sont positifs, alors un rhumatologue confirme le diagnostic.', 133, 132) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Perte visuelle et âge > 50 ans', 'Glucocorticoïdes en urgence, ophtalmologie', 'Échographie temporale'],
    ['Fièvre sous immunosuppresseur', 'Hémocultures, imagerie, antibiotique si sepsis', 'Réévaluation à 48 heures'],
    ['Protéinurie chez un lupique', 'Biopsie rénale', 'Traitement de la néphrite'],
    ['Ferritine très élevée et fièvre en pics', 'Exclure infection et lymphome, puis Still', 'Critères de Yamaguchi'],
    ['Aucun diagnostic après bilan', 'Suivi, PET-CT si CRP élevée', 'Évolution'],
   ]), 133, 132, 84, 130)))
MED = F('Fiches médicamenteuses (AIPS et recommandations)',
  TAB(['Médicament (classe)', 'Mécanisme d’action et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Prednisone (glucocorticoïde)', 'Inhibe la transcription des cytokines, demi-vie courte', 'Artérite : 40–60 mg/j puis décroissance ; lupus : ≤ 5 mg/j en entretien', 'Diabète, ostéoporose, infections ; interaction avec les AINS (ulcère)'],
   ['Hydroxychloroquine, Plaquenil® (antipaludéen)', 'Modulation de l’immunité innée, élimination lente', '400–600 mg/j puis 200–400 mg/j ; cible 5 mg/kg/j, pendant toute la maladie', 'Toxicité rétinienne : contrôle ophtalmologique ; contre-indication : rétinopathie'],
   ['Méthotrexate (antimétabolite)', 'Inhibe la dihydrofolate réductase', '1 fois par semaine, jamais chaque jour', 'Atteinte du foie et de la moelle ; interaction avec le triméthoprime'],
   ['Tocilizumab (anti-récepteur de l’IL-6)', 'Bloque l’interleukine 6', 'Selon l’AIPS, en épargne cortisonique', 'Infections, perforation digestive ; la CRP ne monte plus en cas d’infection'],
   ['Mycophénolate (immunosuppresseur)', 'Inhibe la prolifération des lymphocytes', 'Néphrite lupique', 'Contre-indiqué pendant la grossesse'],
  ]), 132, 133, 134, 5)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge suit l’organe atteint : glucocorticoïdes en traitement de pont, puis traitement de fond pour les épargner. '
   'L’hydroxychloroquine est recommandée pour tous les patients lupiques. '
   'Le but est la rémission avec le moins de glucocorticoïdes possible.', 132, 133) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans la forme compliquée (perte visuelle, néphrite, atteinte neurologique), le but est un traitement en urgence dans les heures qui suivent. '
     'Dans la forme non compliquée, le but est la rémission en ambulatoire avec moins de 5 mg/j de prednisone en entretien.', 133, 132), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures',
     OL(['<b>A. Urgence</b> : perte visuelle : glucocorticoïdes immédiats ; néphrite : avis néphrologique.',
         '<b>B. Exclure l’infection</b> : hémocultures, imagerie avant d’augmenter l’immunosuppression.',
         '<b>C. Traitement de fond</b> : hydroxychloroquine (lupus), méthotrexate, tocilizumab (artérite).',
         '<b>D. Forme non compliquée</b> : mesures générales (protection solaire, arrêt du tabac, vaccinations, prévention de l’ostéoporose), suivi ambulatoire.']), 132, 133) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail est souvent nécessaire pendant les poussées ; un aménagement du poste aide en cas de fatigue.',
            'La conduite automobile est interdite en cas de perte visuelle de l’artérite jusqu’à l’avis ophtalmologique.',
            'Une maladie chronique avec perte de capacité de travail peut relever de la LAI ; la LAMal prend en charge les traitements de base.'), 132) +
   F('Traitements non médicamenteux',
     UL(['Protection solaire dans le lupus.', 'Activité physique adaptée.', 'Calcium, vitamine D et prévention de l’ostéoporose sous glucocorticoïdes.']), 132) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Poursuivre l’hydroxychloroquine ; arrêter méthotrexate et mycophénolate'],
      ['Enfant', 'Avis pédiatrique, hydroxychloroquine 5–7 mg/kg/j'],
      ['Sujet âgé', 'Risque cortisonique (diabète, chute) : épargne précoce'],
      ['Insuffisance hépatique', 'Prudence avec le méthotrexate'],
      ['Insuffisance rénale (DFGe bas)', 'Adapter hydroxychloroquine et méthotrexate'],
     ]), 132, 134), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['CRP, NFS', 'Chaque semaine au début', 'Remontée : poussée ou infection'],
    ['Urine et créatinine', 'À chaque consultation (lupus)', 'Protéinurie : néphrite'],
    ['Glycémie et pression artérielle', 'Sous glucocorticoïdes', 'Traiter'],
    ['Fond d’œil', 'Chaque année après 5 ans d’hydroxychloroquine', 'Rétinopathie : arrêt'],
   ]) + H4('Critères de sortie, un par un') + OL(['Infection exclue.', 'Fièvre et douleurs contrôlées.', 'Traitement oral toléré.', 'Suivi rhumatologique organisé.']), 132, 133) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic dépend des atteintes d’organe et des infections sous traitement. '
     'En Suisse, 77 % des patients avec artérite reçoivent un épargneur de glucocorticoïdes. '
     'La recherche 2026 évalue l’upadacitinib et l’arrêt des biothérapies.', 131, 133), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire de ces maladies n’existe pas, sauf l’arrêt du tabac pour la polyarthrite rhumatoïde. '
   'La recommandation suisse du plan de vaccination 2026 prévoit 2 doses de vaccin contre le zona avant un traitement immunosuppresseur. '
   'La prévention tertiaire limite les complications des traitements.', 26, 85) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Arrêt du tabac, protection solaire chez le lupique'],
    ['Secondaire', 'Analyse d’urine régulière dans le lupus, avis rapide devant une céphalée après 50 ans'],
    ['Tertiaire', 'Vaccinations (zona, grippe, pneumocoque) idéalement ≥ 4 semaines avant l’immunosuppression, prévention de l’ostéoporose'],
   ]), 26, 132)))
PTS.append(POINT(13, 'Points clés',
 P('Une fièvre prolongée chez un patient sous immunosuppresseur est infectieuse jusqu’à preuve du contraire. '
   'Après 50 ans, une céphalée nouvelle avec CRP élevée impose de penser à l’artérite à cellules géantes et de traiter vite. '
   'L’hydroxychloroquine est donnée à tous les lupiques. '
   'Les critères de classification ne remplacent pas l’exclusion des infections et des cancers.', 132, 133, 130)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Attribuer une fièvre à une poussée lupique sans chercher d’infection.', 'Non : hémocultures et imagerie d’abord.'],
  ['Attendre la biopsie temporale avant les glucocorticoïdes.', 'Non : traiter sans délai si suspicion forte.'],
  ['Diagnostiquer un lupus sur des anticorps antinucléaires seuls.', 'Non : critère d’entrée, pas diagnostic.'],
  ['Se rassurer sur une CRP normale sous tocilizumab.', 'Non : l’IL-6 bloquée masque l’infection.'],
  ['Prescrire le méthotrexate chaque jour.', 'Non : 1 fois par semaine.'],
 ]) + P('Ces pièges entraînent le raisonnement ; ils ne sont pas des questions officielles de l’examen fédéral.', 132, 133)))
CTX = {'_prefixe': 'Dans une maladie systémique',
 'autoac': 'Les auto-anticorps se demandent sur une suspicion clinique : anticorps antinucléaires, anti-ADN, facteur rhumatoïde, anti-CCP, ANCA.',
 'crp': 'Une CRP très élevée chez un lupique fait d’abord chercher une infection.',
 'vs': 'La vitesse de sédimentation est élevée dans l’artérite à cellules géantes.',
 'nfs': 'La NFS montre une cytopénie dans le lupus ou une hyperleucocytose dans la maladie de Still.',
 'creat': 'La créatinine dépiste l’atteinte rénale.',
 'ecbu': 'L’analyse d’urine dépiste la néphrite lupique.',
 'ferritine': 'Une ferritine très élevée oriente vers une maladie de Still, après exclusion d’une infection et d’un lymphome.',
 'tep': 'Le PET-CT montre une vascularite des gros vaisseaux ou une cause cachée de fièvre.',
 'doppler': 'L’échographie des temporales montre un halo autour de l’artère.',
 'echo': 'L’échographie montre une synovite ou une artérite.',
 'biopsie': 'La biopsie de l’artère temporale ou du rein confirme le diagnostic.',
 'hemoc': 'Les hémocultures précèdent toute augmentation de l’immunosuppression.',
 'echocoeur': 'L’échocardiographie cherche une endocardite, diagnostic différentiel classique.',
 'radio': 'La radiographie des mains cherche des érosions.',
 'tdm': 'Le scanner cherche une infection ou un cancer.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
