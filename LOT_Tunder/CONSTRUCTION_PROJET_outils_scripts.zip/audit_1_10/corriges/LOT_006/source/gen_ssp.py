# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ de l’Appel A du LOT 6 : SSP G6 « Fièvre » (14 points) + bloc 2 (liste des dix diagnostics).
Original : LOT_6_Appel_A_V5 (export Google Docs, sans section Sources). Toutes les références viennent du registre lot6_commun (audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('ssp')
M = dict(pref='ssp', dx='SSP G6', court='Fièvre', long='Fièvre (situation clinique de départ)', dossier='corriges/LOT_006',
         fichier='LOT_006_Appel_A_SSP_G6_Fievre_AUDITÉ.html', lot_titre='LOT 6 · G6 · Fièvre',
         sous_titre='PROFILES 2023 · SSP G6 · LOT 6 · Appel A · V7 · version AUDITÉE (14 points et liste des dix diagnostics)',
         statut='Cette version corrige l’Appel A du LOT 6 (plan monographique et liste différentielle V5, export Google Docs) après audit médical et linguistique. '
                'L’original ne citait aucune source : toutes les références ont été ajoutées et ouvertes par l’audit ; les doses proviennent des informations professionnelles suisses (AIPS) et des recommandations de la SSI.')
_build = gen_v7.build
def _build_ssp(*a, **k):
    return _build(*a, **k).replace('<a href="#ssp-p15">15</a>', '<a href="#ssp-p15">Dix DX</a>')
gen_v7.build = _build_ssp

CONS = T('point de consigne', 'Le point de consigne est la température que l’hypothalamus cherche à maintenir, comme le réglage d’un thermostat.')
PYRO = T('pyrogène', 'Un pyrogène est une substance qui provoque la fièvre ; il est exogène s’il vient d’un microbe, endogène s’il est fabriqué par l’organisme, comme l’IL-1.')
OVLT = T('organum vasculosum de la lame terminale', 'L’organum vasculosum de la lame terminale est une petite zone du cerveau sans barrière hémato-encéphalique complète, près de l’hypothalamus.')
HYPER = T('hyperthermie', 'L’hyperthermie est une hausse de la température avec un point de consigne normal : la chaleur reçue ou produite dépasse les pertes, comme dans le coup de chaleur.')
BRADY = T('bradycardie relative', 'La bradycardie relative, ou dissociation pouls-température (signe de Faget), est un pouls plus lent que celui attendu pour le degré de fièvre.')
FOI = T('fièvre d’origine inconnue', 'La fièvre d’origine inconnue (FOI) est une fièvre prolongée sans cause trouvée malgré un bilan initial complet et bien conduit.')
QSOFA = T('qSOFA', 'Le qSOFA (quick Sequential Organ Failure Assessment) compte 1 point pour chacun de ces signes : fréquence respiratoire ≥ 22/min, conscience altérée, pression systolique ≤ 100 mmHg.')
PTS = []

# ---------- 1
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'La fièvre est une hausse de la température centrale due à une élévation du {CONS} hypothalamique, sous l’effet de {PYRO}s. '
   f'Elle se distingue de l’{HYPER}, où le point de consigne reste normal. '
   'La limite supérieure de la température buccale normale est 37,7 °C ; le seuil de 38,0 °C est une convention clinique.', 53, 51) +
 F('Terminologie : mot courant et terme exact',
   TAB(['Mot courant', 'Terme exact', 'Définition et seuil', 'À ne pas confondre avec'], [
    ['« J’ai de la température »', 'Fièvre', 'Point de consigne élevé ; seuil usuel ≥ 38,0 °C, variable selon le site de mesure', 'Hyperthermie (coup de chaleur, médicament)'],
    ['« Un peu de fièvre »', 'Fébricule', 'Température entre la limite normale et 38,0 °C', 'Variation du soir, normale jusqu’à 0,5 °C'],
    ['« Fièvre au retour de voyage »', 'Fièvre d’importation', 'Toute température > 37,5 °C au retour d’une zone d’endémie du paludisme est une urgence', 'Fièvre banale'],
    ['« Fièvre sous chimiothérapie »', 'Neutropénie fébrile', 'Température buccale > 38,3 °C, ou 2 mesures > 38,0 °C, avec neutrophiles < 0,5 G/L', 'Fièvre sans neutropénie'],
    ['« Fièvre qui dure »', 'Fièvre d’origine inconnue', '> 38,3 °C à plusieurs reprises, plus de 3 semaines, sans cause après un bilan', 'Fièvre prolongée à cause connue'],
   ]) + P(f'Le terme {FOI} a des critères précis, détaillés au point 8.', 55, 56), 51, 30, 44, 55, 56) +
 F('Pourquoi ces mots changent la décision',
   UL(['Une hyperthermie ne répond pas au paracétamol : elle impose un refroidissement physique.',
       'Une fièvre d’importation impose un test du paludisme dans les 24 heures.',
       'Une neutropénie fébrile impose un antibiotique dans l’heure.']), 30, 44, 53)))

# ---------- 2
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, aucune statistique publiée ne chiffre la part de la fièvre parmi les consultations. '
   'Le chiffre de l’original, « 10 à 15 % des motifs aigus selon la SSMIG », n’a pas été retrouvé et a été retiré. '
   'Les déclarations obligatoires donnent en revanche les infections fébriles graves les plus fréquentes.', 99, 25) +
 F('Chiffres comparables : même unité quand c’est possible',
   TAB(['Cause', 'Valeur', 'Population et nature du chiffre'], [
    ['Pneumocoques invasifs', '1 079 cas, 11,9/100 000' + S(25), 'Suisse, déclarations sur 52 semaines, 2025'],
    ['Légionellose', '580 cas, 6,4/100 000' + S(25), 'Suisse, 2025'],
    ['Paludisme', '274 cas, 3,0/100 000' + S(25), 'Suisse, 2025, cas importés'],
    ['Dengue', '180 cas, 2,0/100 000' + S(25), 'Suisse, 2025, cas importés'],
    ['Méningocoques invasifs', '37 cas, 0,4/100 000' + S(25), 'Suisse, 2025'],
   ], 'Ces chiffres comptent des cas déclarés : ils sous-estiment les infections bénignes, jamais déclarées.') +
   P('En Europe, aux urgences d’un hôpital néerlandais, une infection bactérienne est confirmée chez 35,2 % des adultes fébriles. '
     'La pneumonie bactérienne est la première cause, avec 27,2 % des patients ; 4,2 % décèdent.', 49), 25, 49) +
 F('Facteurs de risque, terrain et pronostic',
   TAB(['Facteur ou terrain', 'Pourquoi il compte'], [
    ['Âge ≥ 65 ans', 'Fièvre absente ou atténuée dans 20 à 30 % des infections ; une fièvre à cet âge signale plus souvent une infection grave'],
    ['Âge et mortalité', 'Seul facteur lié au décès chez les adultes fébriles aux urgences'],
    ['Neutropénie après chimiothérapie', 'Urgence : antibiotique dans l’heure'],
    ['Voyage en zone tropicale', 'Le paludisme cause 33 % des décès des voyageurs fébriles'],
    ['Prothèse valvulaire ou articulaire', 'Endocardite ou infection de prothèse possible'],
   ]) + P('Le terrain change donc le seuil d’alarme plus que la hauteur de la fièvre.', 150, 49), 150, 49, 44, 144)))

# ---------- 3
PTS.append(POINT(3, 'Physiopathologie',
 P('Un microbe ou une lésion des tissus active les macrophages, qui libèrent des cytokines : IL-1, IL-6 et TNF-α. '
   'Ces cytokines induisent la COX-2, qui fabrique la prostaglandine E2 près de l’hypothalamus. '
   'Le point de consigne monte : frissons et vasoconstriction élèvent la température jusqu’au nouveau réglage.', 53) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', f'L’aire préoptique de l’hypothalamus règle la température ; l’{OVLT} laisse passer les messages du sang.'],
    ['Physiologie', 'La température varie de 0,5 °C dans la journée, plus basse vers 6 h, plus haute vers 16–18 h.'],
    ['Physiopathologie', 'Les pyrogènes, dont les récepteurs Toll, agissent tous par la COX-2 et la prostaglandine E2.'],
    ['Clinique', 'Frissons à la montée, sueurs à la descente ; le pouls accélère d’environ 8,5 battements par minute par degré.'],
    ['Examens', 'La CRP et la procalcitonine reflètent la réponse inflammatoire, pas son site.'],
    ['Traitement', 'Le paracétamol et les AINS bloquent la COX : ils baissent le point de consigne sans traiter la cause.'],
   ]), 53, 51, 50) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration qui le montre', 'Cible thérapeutique'], [
    ['Infection bactérienne', 'Hémocultures, procalcitonine, foyer', 'Antibiotique adapté au foyer'],
    ['Infection virale', 'Clinique, PCR si cela change la conduite', 'Traitement symptomatique'],
    ['Inflammation non infectieuse', 'VS, CRP, auto-anticorps, imagerie', 'Corticoïde ou traitement spécifique'],
    ['Fièvre tumorale', 'Imagerie, biopsie', 'Traitement du cancer ; naproxène en test'],
    ['Hyperthermie (point de consigne normal)', 'Contexte de chaleur ou médicament', 'Refroidissement physique, pas d’antipyrétique'],
   ]) + P('Le mécanisme explique pourquoi l’antipyrétique soulage sans guérir.', 53, 137), 53, 63, 137) +
 F('Fenêtre bio-mathématique : fièvre et fréquence cardiaque, score de Centor',
   P('Dans une étude de 27 jeunes hommes fébriles, le pouls a augmenté en moyenne de 8,5 battements par minute pour 1 °C.', 50) +
   P('Règle pratique : FC attendue ≈ FC de base + 8,5 × (température − 37).', 50) +
   P('Exemple : pouls de base 70/min, température 39,5 °C. '
     'Le pouls attendu vaut 70 + 8,5 × 2,5, soit environ 91/min ; un pouls mesuré de 115/min est donc disproportionné.', 50) +
   P('Un tel excès fait chercher un sepsis, une déshydratation ou une douleur ; un pouls plus lent que prévu définit la ' + BRADY + '.', 50, 54) +
   TAB(['Paramètre', 'Valeur normale', 'Seuil décisionnel', 'Interprétation et conduite'], [
    ['Score de Centor (angine)', '0 point', '3–4 points', '0–2 : ni test ni antibiotique ; 3–4 : test rapide si un antibiotique est envisagé'],
    ['Test rapide du streptocoque A', 'Négatif', 'Positif avec Centor 3–4', 'Pénicilline V 1 million UI toutes les 12 heures ou amoxicilline 1 g toutes les 12 heures pendant 6 jours'],
    ['Pouls et température', '+ 8,5 battements par minute par °C', 'Pouls bas malgré ≥ 38,9 °C', 'Bradycardie relative : légionellose, fièvre typhoïde, leptospirose, psittacose ; exclure d’abord un bêtabloquant'],
   ]) +
   P('Correction de l’original : la SSI utilise le score de Centor, plus répandu en Suisse ; le score de McIsaac lui ajoute un critère d’âge.', 12, 58) +
   P('Les risques de l’original (« < 10 %, 15–35 %, > 50 % ») et la hausse du métabolisme de « 10 à 13 % par degré » n’ont pas été retrouvés ; ils sont retirés.', 58, 50), 12, 50, 54, 58)))

# ---------- 4
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin écarte d’abord les urgences : sepsis, méningite, purpura fulminans, neutropénie fébrile et paludisme grave. '
   'Il cherche ensuite un foyer, ce qui classe la fièvre comme respiratoire, urinaire, digestive, cutanée ou neurologique. '
   'Une fièvre de plus de 3 semaines sans foyer relève de la démarche de fièvre d’origine inconnue.', 64, 19, 44, 29, 56) +
 F('Diagnostic différentiel (fréquence sourcée en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Infection respiratoire' + PR('pneumonie bactérienne : 27,2 % des adultes fébriles aux urgences', 49), 'Toux, crépitants, dyspnée', 'Radiographie du thorax, CRP'],
    ['Infection urinaire' + PR('près de la moitié des femmes au cours de la vie', 100), 'Brûlures mictionnelles, douleur lombaire', 'Bandelette, culture d’urine'],
    ['Gastro-entérite' + PR('campylobactériose : 92/100 000 par an (Suisse)', 28), 'Diarrhée, contage alimentaire', 'Culture ou PCR des selles si gravité'],
    ['Peau et tissus mous' + PR('cellulite : 199/100 000 personnes-années', 108), 'Placard rouge, porte d’entrée', 'Clinique ; IRM si fasciite possible'],
    ['Méningite, encéphalite' + PR('méningocoques invasifs : 0,4/100 000 (Suisse, 2025)', 25), 'Céphalée, raideur de nuque, confusion', 'Ponction lombaire, hémocultures'],
    ['Endocardite' + PR('13,8/100 000 par an (monde)', 41), 'Souffle, prothèse, toxicomanie IV', '3 paires d’hémocultures, échocardiographie'],
    ['Infection ostéo-articulaire' + PR('spondylodiscite : 12,4/100 000 (Allemagne, 2019)', 124), 'Douleur rachidienne ou articulaire fébrile', 'IRM, ponction articulaire'],
    ['Maladie inflammatoire' + PR('22 % des fièvres d’origine inconnue', 130), 'Céphalée après 50 ans, arthrites', 'VS, CRP, auto-anticorps'],
    ['Néoplasie, hémopathie' + PR('7 % des fièvres d’origine inconnue', 130), 'Sueurs, amaigrissement, adénopathies', 'Imagerie, biopsie'],
    ['Fièvre d’importation' + PR('paludisme : 21 % des voyageurs fébriles', 144), 'Retour de zone tropicale', 'Test du paludisme dans les 24 heures'],
   ]) + P('Ces chiffres ont des populations différentes : ils ne sont pas des probabilités devant un patient donné.', 99)) +
 F('Hiérarchie des urgences : danger, discriminant, action',
   TAB(['Danger', 'Discriminant', 'Action immédiate'], [
    ['Sepsis', 'qSOFA ≥ 2, lactate ≥ 2 mmol/L, marbrures', 'Hémocultures puis antibiotique dans l’heure'],
    ['Méningite, purpura fulminans', 'Raideur de nuque, purpura qui ne s’efface pas', 'Antibiotique dans l’heure, sans attendre le scanner'],
    ['Neutropénie fébrile', 'Chimiothérapie récente', 'Antibiotique dans l’heure qui suit l’admission'],
    ['Paludisme grave', 'Retour de zone d’endémie, critère de gravité', 'Artésunate IV aux soins intensifs'],
   ]), 64, 19, 44, 29)))

# ---------- 5
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise la mesure, la durée et le rythme de la fièvre. '
   'Il recherche un foyer, un voyage, une immunosuppression, une prothèse et les médicaments récents.', 52, 30) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Comment et où la température a-t-elle été mesurée ?', 'Les thermomètres périphériques ont une sensibilité de 64 % seulement.', 'Mesure centrale si le doute change la conduite.'],
    ['Depuis combien de jours ?', 'Plus de 3 semaines : démarche de fièvre d’origine inconnue.', 'Bilan structuré.'],
    ['Avez-vous voyagé hors d’Europe cette année ?', 'Le paludisme est le premier diagnostic précis chez le voyageur fébrile.', 'Test du paludisme dans les 24 heures.'],
    ['Recevez-vous une chimiothérapie ou un immunosuppresseur ?', 'Une neutropénie fébrile tue en quelques heures.', 'NFS et antibiotique dans l’heure.'],
    ['Avez-vous une valve artificielle ou une prothèse articulaire ?', 'Une infection de matériel est possible.', 'Hémocultures avant tout antibiotique.'],
    ['Quel médicament avez-vous commencé récemment ?', 'Une fièvre médicamenteuse est possible.', 'Arrêt et réévaluation.'],
    ['Toux, brûlures urinaires, diarrhée, céphalée, éruption ?', 'Ces signes désignent le foyer.', 'Examen ciblé.'],
   ]), 52, 56, 144, 44, 41) +
 U('<b>Drapeaux rouges (appel du 144 ou urgences)</b> : purpura qui ne s’efface pas, raideur de nuque, confusion, hypotension, fréquence respiratoire ≥ 22/min, fièvre sous chimiothérapie, fièvre au retour de zone tropicale.', 19, 64, 44, 30)))

# ---------- 6
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen commence par toutes les constantes : température, pouls, pression, fréquence respiratoire, SpO2 et état de conscience. '
   'Le patient est ensuite déshabillé pour inspecter toute la peau, puis chaque organe est examiné à la recherche d’un foyer.', 64, 5) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Fréquence respiratoire (1 minute)', '12–20/min', '≥ 22/min : critère qSOFA' + S(64)],
    ['Pouls rapporté à la température', '+ 8,5/min par °C', 'Pouls lent : bradycardie relative' + S(50, 54)],
    ['Peau entière, patient déshabillé', 'Pas de lésion', 'Purpura, érythème migrant, escarre, cellulite' + S(19, 73)],
    ['Gorge et ganglions cervicaux', 'Amygdales sans exsudat', 'Exsudat, ganglions sensibles : score de Centor' + S(12)],
    ['Auscultation cardiaque', 'Pas de souffle', 'Souffle nouveau : endocardite' + S(41)],
    ['Auscultation pulmonaire', 'Murmure symétrique', 'Crépitants : pneumonie' + S(10)],
    ['Fosses lombaires', 'Indolores', 'Douleur à l’ébranlement : pyélonéphrite' + S(14)],
    ['Nuque', 'Souple', 'Raideur : méningite' + S(47)],
    ['Rate et foie', 'Non palpables', 'Splénomégalie : paludisme, endocardite, hémopathie' + S(29)],
   ]) + P('Termes : ' + T('purpura', 'Le purpura est une tache rouge due à du sang sorti des vaisseaux ; il ne s’efface pas quand on appuie dessus.') + '.', 19))))

# ---------- 7
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont rapportés : frissons, sueurs, céphalée, myalgies. '
   'Les signes physiques sont constatés : fièvre, tachycardie, tachypnée, raideur de nuque, purpura. '
   'Ils se regroupent en syndromes, chacun avec son discriminant.', 53, 47) +
 F('Syndromes et signes définis',
   TAB(['Syndrome', 'Signes', 'Mécanisme', 'Discriminant'], [
    ['Syndrome infectieux aigu', 'Fièvre, frissons, tachycardie adaptée, sueurs, myalgies', 'Cytokines et prostaglandine E2', 'Foyer clinique' + S(53)],
    ['Syndrome méningé fébrile', 'Céphalée, raideur de nuque, photophobie, vomissements', 'Inflammation des méninges', 'Ponction lombaire ; triade complète dans 44 % seulement' + S(47)],
    ['Sepsis', 'Confusion, tachypnée, hypotension, marbrures', 'Dysfonction d’organe due à l’infection', 'qSOFA, lactate, SOFA' + S(64)],
    ['Fièvre d’origine inconnue', '> 38,3 °C, plus de 3 semaines, bilan initial négatif', 'Infection, inflammation, néoplasie', 'Bilan structuré' + S(56, 130)],
    ['Fièvre avec bradycardie relative', 'Pouls lent malgré une forte fièvre', 'Germe intracellulaire, médicament', 'Hémocultures, sérologies' + S(54)],
   ]))))

# ---------- 8
PTS.append(POINT(8, 'Critères diagnostiques',
 P('La fièvre n’a pas de critère unique : son seuil dépend du site de mesure et du contexte. '
   'Une température isolée ne suffit pas à poser un diagnostic : le diagnostic positif est celui de la cause. '
   'La fièvre d’origine inconnue, la neutropénie fébrile et le sepsis ont des critères définis par des sociétés savantes.', 51, 56, 44, 64) +
 F('Critères (société, année, seuil)',
   TAB(['Situation', 'Référence', 'Critère et seuil'], [
    ['Fièvre d’origine inconnue classique', 'Petersdorf et Beeson, 1961', '> 38,3 °C à plusieurs reprises, plus de 3 semaines, sans diagnostic après 1 semaine d’hôpital'],
    ['Fièvre d’origine inconnue révisée', 'Durack et Street, 1991', 'Même seuil ; bilan de 3 jours d’hôpital ou 3 consultations ; formes nosocomiale, neutropénique et liée au VIH'],
    ['Consensus Delphi', 'Groupe international, 2024', 'Intègre le voyage ; refuse la TEP-FDG comme critère de définition'],
    ['Neutropénie fébrile', 'ESMO, 2016', 'Température buccale > 38,3 °C ou 2 mesures > 38,0 °C, neutrophiles < 0,5 G/L'],
    ['Sepsis', 'Consensus Sepsis-3, 2016', 'Infection et hausse du score SOFA d’au moins 2 points'],
    ['Fièvre au retour de voyage', 'ECTM et OFSP', '> 37,5 °C au retour d’une zone d’endémie : test du paludisme'],
   ]) + P('Correction de l’original : la définition de 3 jours d’hôpital ou 3 consultations vient de Durack et Street (1991), pas de la définition initiale de 1961.', 55, 56), 55, 56, 57, 44, 64, 30)))

# ---------- 9
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Question', 'Examen de référence', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Fièvre réelle ?', 'Température centrale', 'Thermomètres périphériques : sensibilité 64 %, spécificité 96 %' + S(52), 'Une mesure périphérique normale n’exclut pas'],
    ['Bactériémie, endocardite ?', '2 à 3 paires d’hémocultures avant antibiotique', 'Référence ; moins sensibles après un antibiotique' + S(41), 'Délai de 24 à 72 heures'],
    ['Méningite ?', 'Ponction lombaire', 'Lactate du liquide ≥ 4 mmol/L très spécifique' + S(19), 'Scanner avant seulement si signes focaux'],
    ['Paludisme ?', 'Frottis et goutte épaisse ou test rapide', 'Exclu après 3 jours de tests négatifs' + S(30), 'Un test négatif isolé ne suffit pas'],
    ['Foyer caché d’une fièvre d’origine inconnue ?', 'TEP-TDM au FDG', 'Sensibilité poolée 85 %' + S(151), 'Faux positifs ; examen de seconde intention'],
   ]), 'fenetre') +
  F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Aucun examen si fièvre bénigne avec foyer viral évident', 'Patient stable' + S(11)],
    ['Première, laboratoire', 'NFS, CRP, créatinine, ionogramme, bilan hépatique, bandelette urinaire', 'Fièvre ≥ 38,5 °C plus de 3 jours, dyspnée ou pouls ≥ 100/min' + S(11)],
    ['Première, ciblée', 'Hémocultures, lactate, procalcitonine', 'Suspicion de sepsis' + S(64, 63)],
    ['Première, ciblée', 'Test du paludisme', 'Retour de zone d’endémie' + S(30)],
    ['Seconde', 'Radiographie du thorax, échographie, échocardiographie', 'Foyer suspecté' + S(10, 41)],
    ['Seconde', 'Sérologies ciblées (VIH, EBV, CMV), scanner thoraco-abdominal', 'Fièvre d’origine inconnue' + S(130)],
    ['Troisième', 'TEP-TDM au FDG', 'Bilan initial négatif' + S(151, 57)],
   ]), 'fenetre') +
  F('9.c Prescription : indication, moment, préparation',
   UL(['Les hémocultures se prélèvent avant l’antibiotique, sans retarder celui-ci en cas de sepsis ou de méningite.',
       'Le test du paludisme se fait le jour même et se répète pendant 3 jours s’il est négatif.',
       'La procalcitonine se dose au début et se répète pour décider de l’arrêt de l’antibiotique.']), 19, 30, 63) +
  F('9.d Interprétation',
   TAB(['Résultat', 'Signification', 'Conduite'], [
    ['CRP < 50 mg/L, infection respiratoire', 'Pneumonie bactérienne peu probable', 'Pas d’antibiotique si l’état est stable'],
    ['CRP ≥ 100 mg/L', 'Infection bactérienne plus probable', 'Antibiotique envisagé selon le foyer'],
    ['Lactate ≥ 2 mmol/L', 'Hypoperfusion possible', 'Filière sepsis'],
    ['Neutrophiles < 0,5 G/L', 'Neutropénie fébrile', 'Antibiotique dans l’heure'],
    ['Test du paludisme négatif', 'Pas d’exclusion', 'Répéter pendant 3 jours'],
   ]) + P('Un examen normal ne ferme une branche que dans les conditions validées de sa méthode.', 11, 64, 44, 30), 'fenetre') +
  F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Test de grossesse d’abord ; échographie préférée ; radiographie du thorax possible avec protection'],
    ['Enfant', 'Valeurs de référence adaptées à l’âge ; score qSOFA non validé chez l’enfant'],
    ['DFGe bas (< 30 mL/min), insuffisance rénale', 'Produit de contraste iodé seulement si nécessaire ; doses d’antibiotique adaptées'],
    ['Allergie au produit de contraste iodé', 'Échographie ou IRM'],
    ['Pacemaker (stimulateur cardiaque)', 'IRM seulement si le pacemaker est compatible'],
    ['Personne âgée', 'Fièvre absente ou atténuée dans 20 à 30 % des infections : bilan même sans fièvre'],
    ['Résultat positif mais discordant avec la clinique', 'Contamination possible d’une hémoculture (un seul flacon positif à un germe cutané) : répéter'],
    ['Résultat négatif mais clinique forte', 'Répéter l’examen ; un test du paludisme négatif se répète pendant 3 jours'],
    ['Résultat limite (procalcitonine proche du seuil)', 'Décider sur la clinique et répéter le dosage'],
   ]), 150, 64, 30, 63, 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le bilan teste d’abord les branches dangereuses, puis cherche le foyer. '
   'Une fièvre bénigne avec foyer viral évident ne demande aucun examen. '
   'Les examens d’imagerie lourde sont réservés à la fièvre d’origine inconnue.', 11, 64, 151) + P9))

# ---------- 10
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si un signe de gravité est présent, alors le patient est adressé aux urgences et reçoit l’antibiotique dans l’heure. '
   'Si l’état est stable avec un foyer évident, alors le traitement suit la recommandation de la SSI pour ce foyer. '
   'Si aucun foyer n’est trouvé, alors un bilan de base et une réévaluation à 48–72 heures sont organisés.', 64, 19, 11) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['qSOFA ≥ 2, purpura, raideur de nuque', 'Hémocultures, antibiotique dans l’heure', 'Soins intensifs selon l’évolution'],
    ['Fièvre sous chimiothérapie', 'NFS, antibiotique dans l’heure', 'Score de risque MASCC'],
    ['Retour de zone d’endémie', 'Test du paludisme dans les 24 heures', 'Répéter pendant 3 jours'],
    ['Foyer évident, état stable', 'Traitement selon la SSI', 'Réévaluation à 48–72 heures'],
    ['Pas de foyer, plus de 3 semaines', 'Démarche de fièvre d’origine inconnue', 'Bilan structuré, TEP-TDM si négatif'],
   ]), 64, 44, 138, 30, 56, 151)))

# ---------- 11
MED = F('Fiches médicamenteuses (posologies AIPS et SSI)',
  TAB(['Médicament (classe)', 'Mécanisme d’action et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Paracétamol, Dafalgan® (analgésique antipyrétique)', 'Inhibe la synthèse centrale des prostaglandines ; métabolisme hépatique', '500–1000 mg par prise, intervalle 4–8 heures, maximum 4 g par jour (adulte > 40 kg)', 'Hépatotoxicité en surdosage ; contre-indiqué en insuffisance hépatique sévère ; interaction : alcool'],
   ['Ibuprofène, Brufen® (AINS)', 'Inhibe la COX-1 et la COX-2', '400 mg par prise, maximum 2 400 mg par jour', 'Ulcère, insuffisance rénale ; à éviter si dengue possible ; interaction : anticoagulants'],
   ['Métamizole, Novalgin® (analgésique antipyrétique)', 'Effet antipyrétique central', '500–1000 mg par prise, maximum 4 g par jour', 'Agranulocytose, hypotension si injection IV rapide'],
   ['Ceftriaxone, Rocephin® (céphalosporine de 3e génération)', 'Bloque la paroi bactérienne ; une injection par jour', 'Pyélonéphrite instable : 1 g par jour (SSI) ; méningite : 2 g toutes les 12 heures (SSI)', 'Allergie, boue biliaire ; interaction : calcium IV chez le nouveau-né'],
   ['Amoxicilline-acide clavulanique, Co-Amoxi® IV (pénicilline et inhibiteur)', 'Le clavulanate inhibe les bêtalactamases', 'Pneumonie hospitalisée : 2,2 g IV toutes les 8 heures, durée habituelle 5 jours', 'Diarrhée, hépatite cholestatique ; contre-indication : allergie aux pénicillines'],
  ]) + P('Correction de l’original : la ceftriaxone de la méningite se donne à 2 g toutes les 12 heures, pas toutes les 24 heures.', 1, 5, 2, 10, 14, 19))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge traite la cause ; l’antipyrétique ne sert qu’au confort. '
   'Dans l’essai HEAT, le paracétamol n’a pas changé la mortalité à 90 jours des patients infectés de soins intensifs : 15,9 % contre 16,6 %. '
   'L’antibiotique est réservé aux infections bactériennes probables.', 97, 63) +
 F('11.A Buts : formes compliquées et non compliquées',
   P('Dans la forme compliquée (sepsis, méningite, neutropénie fébrile, paludisme grave), c’est une urgence : antibiotique ou artésunate dans l’heure, à l’hôpital.', 64, 19, 44, 29) +
   P('Dans la forme non compliquée, le but est de soulager et de traiter le foyer en ambulatoire : mesures générales d’abord, puis traitement du foyer, avec éducation aux signes d’alerte.', 11), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures',
     OL(['<b>A. Urgence</b> : forme compliquée : hémocultures puis antibiotique dans l’heure.',
         '<b>B. Foyer</b> : traitement selon la recommandation de la SSI, car le foyer fixe la molécule et la durée.',
         '<b>C. Confort</b> : paracétamol si la fièvre gêne ; hydratation orale selon la soif et les pertes.',
         '<b>D. Forme non compliquée</b> : surveillance ambulatoire et consignes écrites de reconsultation.']), 64, 11, 1) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail court suffit souvent pour une infection fébrile simple.',
            'La conduite automobile est déconseillée en cas de forte fièvre, de confusion ou de traitement sédatif.',
            'Une infection contractée au travail, comme le paludisme lors d’un séjour professionnel hors d’Europe, peut relever de la LAA.'), 149) +
   F('Traitements non médicamenteux',
     UL(['Ne pas trop couvrir le patient fébrile.', 'Refroidissement physique seulement en cas d’hyperthermie, où l’antipyrétique est inefficace.',
         'Correction de l’original : la règle « + 500 mL d’eau par degré » n’a pas été retrouvée et a été retirée.']), 53) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Paracétamol préféré ; AINS évités ; antibiotique choisi selon l’AIPS'],
      ['Enfant', 'Doses calculées au poids'],
      ['Personne âgée', 'Seuil d’hospitalisation plus bas ; fièvre parfois absente'],
      ['Insuffisance rénale', 'AINS évités ; doses d’antibiotique adaptées au DFGe'],
      ['Insuffisance hépatique', 'Paracétamol réduit, avis spécialisé'],
     ]), 1, 150), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Température, pouls, pression, vigilance', 'Toutes les heures si hospitalisé', 'Aggravation : filière urgente'],
    ['CRP, NFS', 'Contrôle à 48–72 heures', 'Absence de baisse : réévaluer le foyer'],
    ['Procalcitonine', 'Tous les 2–3 jours sous antibiotique', 'Baisse nette : arrêt possible'],
    ['Symptômes en ambulatoire', '48–72 heures', 'Pas d’amélioration : reconsulter'],
   ]) + P('Pourquoi surveiller : la procalcitonine raccourcit l’antibiothérapie de 8,1 à 5,7 jours, avec une mortalité de 9 % contre 10 %.', 63) +
   H4('Critères de sortie, un par un') +
   OL(['Constantes normales et qSOFA à 0.', 'Foyer identifié et traité, ou fièvre bénigne.', 'Prise orale possible.', 'Consignes de reconsultation comprises.']), 63, 64) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic dépend de la cause : 4,2 % des adultes fébriles admis aux urgences décèdent, surtout les plus âgés. '
     'En 2026, la TEP-TDM au FDG est un examen de seconde intention de la fièvre d’origine inconnue, pas un examen systématique. '
     'La recherche d’ADN microbien libre dans le plasma reste en évaluation : elle a aidé le diagnostic dans 30 % d’une série rétrospective.', 49, 151, 57, 152), 'fenetre')))

# ---------- 12
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur la vaccination selon le Plan de vaccination suisse, recommandation suisse de l’OFSP et de la CFV. '
   'La prévention secondaire est le dépistage précoce des formes graves. '
   'La prévention tertiaire limite les complications et les antibiotiques inutiles.', 26, 30, 63) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure', 'Source'], [
    ['Primaire', 'Grippe chaque année dès 65 ans et pour les groupes à risque', 'OFSP' + S(26)],
    ['Primaire', 'Pneumocoques : une dose de vaccin conjugué dès 65 ans', 'OFSP' + S(26)],
    ['Primaire', 'Conseil avant un voyage tropical : protection contre les moustiques, prophylaxie selon la destination', 'ECTM' + S(147)],
    ['Secondaire', 'Test du paludisme dans les 24 heures au retour', 'ECTM' + S(30)],
    ['Tertiaire', 'Arrêt de l’antibiotique guidé par la procalcitonine', 'Méta-analyse' + S(63)],
   ]))))

# ---------- 13
PTS.append(POINT(13, 'Points clés',
 P('La hauteur de la fièvre ne mesure pas la gravité : chez la personne âgée, la fièvre manque dans 20 à 30 % des infections. '
   'Le médecin mesure toutes les constantes et calcule le qSOFA. '
   'Il cherche un voyage, une neutropénie et une prothèse. '
   'Il prélève les hémocultures avant l’antibiotique. '
   'Il ne prescrit pas d’antibiotique sans foyer bactérien probable.', 150, 64, 30, 44, 41)))

# ---------- 14
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Prescrire un antibiotique à toute fièvre isolée sans hémocultures ni foyer.', 'Non : chercher le foyer, prélever d’abord.'],
  ['Exclure une infection grave chez une personne âgée sans fièvre.', 'Non : la fièvre manque souvent à cet âge.'],
  ['S’arrêter à un test du paludisme négatif.', 'Non : répéter pendant 3 jours.'],
  ['Attendre le scanner avant l’antibiotique dans une méningite.', 'Non : antibiotique dans l’heure.'],
  ['Donner du paracétamol pour un coup de chaleur.', 'Non : hyperthermie, refroidissement physique.'],
  ['Oublier une fièvre médicamenteuse, une thyroïdite subaiguë ou une connectivite.', 'Non : causes non infectieuses à chercher.'],
 ]) + P('Ces pièges entraînent le raisonnement et ne sont pas des questions officielles de l’examen fédéral.', 150, 30, 19, 130)))

# ---------- Bloc 2
L = lambda f, t: f'<a href="{f}">{t}</a>'
DXL = [
 ('DX.1', 'Infections respiratoires', 'LOT_006_DX1_Infections_respiratoires_AUDITÉ.html', PR('pneumonie bactérienne : 27,2 % des adultes fébriles aux urgences (Pays-Bas)', 49), 'Première infection trouvée chez l’adulte fébrile aux urgences.', (49, 10)),
 ('DX.2', 'Infections urinaires', 'LOT_006_DX2_Infections_urinaires_AUDITÉ.html', PR('près de la moitié des femmes au cours de la vie', 100), 'Fréquentes chez la femme ; pyélonéphrite fébrile chez la personne âgée.', (100, 14)),
 ('DX.3', 'Gastro-entérites infectieuses', 'LOT_006_DX3_Gastroenterites_infectieuses_AUDITÉ.html', PR('campylobactériose : 92/100 000 par an (Suisse, 2024)', 28), 'Fièvre avec diarrhée, souvent alimentaire.', (28, 15)),
 ('DX.4', 'Infections de la peau et des tissus mous', 'LOT_006_DX4_Infections_peau_tissus_mous_AUDITÉ.html', PR('cellulite : 199/100 000 personnes-années', 108), 'Porte d’entrée cutanée ; la fasciite nécrosante est l’urgence.', (108, 17)),
 ('DX.5', 'Méningites et encéphalites', 'LOT_006_DX5_Meningites_encephalites_AUDITÉ.html', PR('méningocoques invasifs : 0,4/100 000 ; FSME : 5,5/100 000 (Suisse)', 25, 114), 'Rare mais vitale : antibiotique dans l’heure.', (19, 25)),
 ('DX.6', 'Endocardite infectieuse', 'LOT_006_DX6_Endocardite_infectieuse_AUDITÉ.html', PR('13,8/100 000 par an (monde, 2019)', 41), 'Fièvre prolongée avec souffle ou prothèse valvulaire.', (41, 42)),
 ('DX.7', 'Infections ostéo-articulaires', 'LOT_006_DX7_Infections_osteoarticulaires_AUDITÉ.html', PR('spondylodiscite : 12,4/100 000 (Allemagne, 2019)', 124), 'Douleur rachidienne ou articulaire fébrile, prothèse.', (124, 123)),
 ('DX.8', 'Maladies systémiques et connectivites', 'LOT_006_DX8_Maladies_systemiques_connectivites_AUDITÉ.html', PR('22 % des fièvres d’origine inconnue', 130), 'Première cause non infectieuse de fièvre prolongée.', (130, 131)),
 ('DX.9', 'Néoplasies et hémopathies', 'LOT_006_DX9_Neoplasies_hemopathies_AUDITÉ.html', PR('7 % des fièvres d’origine inconnue', 130), 'Fièvre tumorale ou neutropénie fébrile sous traitement.', (130, 44)),
 ('DX.10', 'Fièvres d’importation', 'LOT_006_DX10_Fievres_importation_AUDITÉ.html', PR('paludisme : 21 % des voyageurs fébriles', 144), 'Le paludisme tue : test dans les 24 heures au retour.', (144, 30)),
]
b15 = (P('Les dix diagnostics suivent l’ordre de l’original. '
         'Les pourcentages de l’original (40 %, 18 %… 2 %) n’ont aucune source vérifiable : ils sont remplacés par la fréquence publiée de chaque cause, dans sa propre population.', 99) +
  TAB(['Rang', 'Diagnostic et fréquence', 'Pourquoi il figure dans la liste'],
      [[d, L(f, n) + pr, j + S(*s)] for d, n, f, pr, j, s in DXL]) +
  F('Tableau comparatif : signe, examen, mécanisme, décision',
    TAB(['Diagnostic', 'Signe clé', 'Examen clé', 'Mécanisme', 'Décision immédiate'], [
     ['Respiratoire', 'Toux, crépitants', 'Radiographie, CRP', 'Infection pulmonaire', 'CURB-65, antibiotique si bactérien'],
     ['Urinaire', 'Brûlures, douleur lombaire', 'Bandelette, culture', 'Infection ascendante', 'Antibiotique selon la SSI'],
     ['Digestive', 'Diarrhée', 'Selles si gravité', 'Entérite', 'Réhydratation'],
     ['Peau', 'Placard rouge', 'Clinique', 'Dermo-hypodermite', 'Antibiotique ; chirurgie si nécrose'],
     ['Méningite', 'Raideur de nuque', 'Ponction lombaire', 'Inflammation méningée', 'Antibiotique dans l’heure'],
     ['Endocardite', 'Souffle', 'Hémocultures, échocardiographie', 'Infection valvulaire', 'Hôpital'],
     ['Ostéo-articulaire', 'Douleur localisée', 'IRM, ponction', 'Infection osseuse', 'Prélever avant l’antibiotique'],
     ['Systémique', 'Céphalée, arthrites', 'VS, CRP, auto-anticorps', 'Inflammation', 'Avis spécialisé'],
     ['Néoplasie', 'Sueurs, amaigrissement', 'Imagerie, biopsie', 'Cytokines tumorales', 'Bilan oncologique'],
     ['Importation', 'Retour de voyage', 'Test du paludisme', 'Parasite, virus', 'Test dans les 24 heures'],
    ]), 59, 14, 19, 41, 30) +
  F('Algorithme discriminant',
    OL(['Signe de gravité ou qSOFA ≥ 2 ? Sepsis, méningite : filière urgente.',
        'Neutropénie ou chimiothérapie ? Antibiotique dans l’heure.',
        'Retour de zone tropicale ? Paludisme d’abord.',
        'Foyer évident ? Respiratoire, urinaire, digestif, cutané ou ostéo-articulaire.',
        'Souffle ou prothèse ? Endocardite : hémocultures.',
        'Plus de 3 semaines sans foyer ? Fièvre d’origine inconnue : inflammation, néoplasie, infection cachée.']) +
    P('Plusieurs branches peuvent coexister, surtout chez la personne âgée.', 64, 44, 30, 56)))
PTS.append(f'<section class="point" id="ssp-p15"><h3><strong>Bloc 2 · Liste des dix diagnostics du LOT 6</strong></h3>\n{b15}</section>\n')

CTX = {'_prefixe': 'Devant une fièvre',
 'nfs': 'L’hémogramme cherche une hyperleucocytose, une neutropénie ou une thrombopénie.',
 'crp': 'Une CRP < 50 mg/L rend une pneumonie bactérienne peu probable chez le patient stable.',
 'pct': 'La procalcitonine guide la durée de l’antibiotique.',
 'lact': 'Un lactate ≥ 2 mmol/L impose la filière sepsis.',
 'hemoc': 'Les hémocultures se prélèvent avant tout antibiotique.',
 'iono': 'Le ionogramme cherche une déshydratation ou une hyponatrémie.',
 'creat': 'La créatinine guide les doses d’antibiotique.',
 'hep': 'Les transaminases cherchent une hépatite ou un paludisme grave.',
 'ecbu': 'La bandelette urinaire et la culture d’urine cherchent une infection urinaire.',
 'radio': 'La radiographie du thorax cherche une pneumonie.',
 'tdr': 'Le test rapide du streptocoque A n’est fait que si le score de Centor vaut 3–4.',
 'frottis': 'Le frottis sanguin et la goutte épaisse cherchent un paludisme au retour de voyage.',
 'pl': 'La ponction lombaire confirme une méningite.',
 'vs': 'Une VS élevée oriente vers une maladie inflammatoire ou une néoplasie.',
 'tep': 'La TEP-TDM au FDG cherche un foyer caché après un bilan initial négatif.',
 'echocardio': 'L’échocardiographie cherche une végétation d’endocardite.',
 'hcg': 'Le test de grossesse précède l’imagerie et certains traitements.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
