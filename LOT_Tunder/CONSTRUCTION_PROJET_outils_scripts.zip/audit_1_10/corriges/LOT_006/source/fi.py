#!/usr/bin/env python3
"""Recherche une information professionnelle suisse (texte Swissmedic AIPS repris par ODDB.org).
usage: fi.py <terme recherche> [indice] -> imprime liste des produits + section Posologie du choix."""
import sys,re,html,urllib.request,urllib.parse,os,json
UA={'User-Agent':'curl/8.0'}
def get(u):
    return urllib.request.urlopen(urllib.request.Request(u,headers=UA),timeout=40).read().decode('utf-8','ignore')
def txt(t):
    t=re.sub(r'<script.*?</script>|<style.*?</style>','',t,flags=re.S)
    t=html.unescape(re.sub(r'<[^>]+>','\n',t)); return re.sub(r'\n\s*\n+','\n',t)
q=sys.argv[1]; idx=int(sys.argv[2]) if len(sys.argv)>2 else 0
if q.startswith('reg:'):
    regs=[(q[4:],'')]; idx=0
else:
  s=get('https://ch.oddb.org/fr/gcc/search/zone/drugs/search_query/%s/search_type/st_oddb'%urllib.parse.quote(q))
  regs=[]
  for m in re.finditer(r'href="([^"]*fachinfo/reg/(\d+))"',s):
      if m.group(2) not in [r for r,_ in regs]: regs.append((m.group(2),m.group(1)))
print('REGS',[r for r,_ in regs][:15])
if not regs: sys.exit()
reg,u=regs[min(idx,len(regs)-1)]
t=txt(get('https://ch.oddb.org/fr/gcc/fachinfo/reg/%s'%reg))
m0=re.search(r'Information professionnelle sur ([^\n]*)',t); nom=[m0.group(1) if m0 else '?']
mj=re.search(r'\nPosologie ?/ ?[Mm]ode',t); j=mj.start() if mj else 0; k=t.find('\nContre-indications\n',j)
ic=t.find('\nComposition\n'); comp=t[ic:ic+350].replace('\n',' ')
out='URL https://ch.oddb.org/fr/gcc/fachinfo/reg/%s\nNOM %s\nCOMP %s\n%s\n'%(reg,' | '.join(nom),comp,t[j:k if k>0 else j+9000][:9000])
m=re.search(r'Mise à jour de l.information[^\n]*\n?[^\n]*',t)
if m: out+='\nMAJ '+m.group(0).replace('\n',' ')
print(out)
open(os.path.join(os.path.dirname(__file__),'verif/fi/%s_%s.txt'%(re.sub(r'\W','_',q),reg)),'w').write(out)
