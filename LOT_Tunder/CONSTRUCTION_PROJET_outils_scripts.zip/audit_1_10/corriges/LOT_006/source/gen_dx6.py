# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.6 · Endocardite infectieuse (LOT 6, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('dx6')
M = meta('dx6', 'DX.6', 'Endocardite infectieuse', 'Endocardite infectieuse : fièvre, souffle, embolies, hémocultures et échocardiographie',
         'LOT_006_DX6_Endocardite_infectieuse_AUDITÉ.html')
VEG = T('végétation', 'Une végétation est un amas de plaquettes, de fibrine et de bactéries fixé sur une valve ; elle peut se détacher et boucher une artère.')
ETO = T('échocardiographie transœsophagienne (ETO)', 'L’ETO place la sonde d’échographie dans l’œsophage, juste derrière le cœur ; elle voit mieux les valves que l’échographie par le thorax (ETT).')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'L’endocardite infectieuse (EI) est une infection de l’endocarde, surtout des valves, avec formation d’une {VEG}. '
   'Elle détruit la valve et envoie des embolies septiques dans le cerveau, la rate, les reins ou la peau. '
   'L’ancien terme « maladie d’Osler » désigne la forme subaiguë.', 41) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['EI aiguë', 'Évolution en jours, souvent Staphylococcus aureus', 'Sepsis d’un autre foyer'],
    ['EI subaiguë', 'Évolution en semaines, streptocoques oraux', 'Fièvre prolongée d’une autre cause (lymphome, maladie systémique)'],
    ['EI sur prothèse', 'Infection d’une valve artificielle', 'Thrombose de prothèse'],
    ['EI sur matériel', 'Infection de sonde de stimulateur ou défibrillateur', 'Infection de la loge seule'],
    ['Endocardite non infectieuse', 'Végétations stériles (cancer, lupus)', 'EI à hémocultures négatives'],
   ]) + P('L’ETO place la sonde d’échographie dans l’œsophage, juste derrière le cœur ; elle voit mieux les valves que l’échographie par le thorax (ETT).', 41), 41)))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, une cohorte nationale de 18 253 remplacements de valve aortique montre une incidence d’EI maximale dans les 3 premiers mois, 23,6 pour 1 000 personnes-années après TAVI. '
   'Le chiffre « 600 à 800 cas par an en Suisse » de l’original n’a été retrouvé dans aucune source et il est retiré. '
   'Au niveau mondial, l’incidence était de 13,8 pour 100 000 par an en 2019, et la mortalité hospitalière européenne atteint 17,1 %.', 119, 41, 42, 99) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Incidence mondiale' + PR('13,8/100 000', 41), 'Par an, 2019', 'ESC 2023'],
    ['Mortalité hospitalière' + PR('17,1 %', 42), '3 116 patients', 'Registre européen de l’endocardite'],
    ['EI après TAVI, 3 premiers mois', '23,6 pour 1 000 personnes-années', 'Cohorte suisse'],
    ['AVC', '16,9 %', 'Cohorte internationale de l’endocardite'],
    ['Insuffisance cardiaque', '32,3 %', 'Même cohorte'],
   ], 'Les facteurs de mauvais pronostic sont la prothèse, l’âge, l’œdème pulmonaire et Staphylococcus aureus (cohorte internationale de l’endocardite).'), 41, 42, 118, 119)))
PTS.append(POINT(3, 'Physiopathologie',
 P('Une lésion de l’endothélium valvulaire attire plaquettes et fibrine, formant une végétation stérile. '
   'Des bactéries du sang s’y fixent et s’y protègent dans un biofilm, à l’abri des défenses et des antibiotiques. '
   'Cela explique les hémocultures positives en continu, les embolies et la durée longue du traitement.', 41) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Valves mitrale et aortique surtout, tricuspide chez l’usager de drogues IV.'],
    ['Physiologie', 'L’endothélium intact résiste à la fixation des bactéries.'],
    ['Physiopathologie', 'Végétation, biofilm, destruction valvulaire, embolies.'],
    ['Clinique', 'Fièvre, souffle nouveau, embolies.'],
    ['Examens', 'Hémocultures répétées, échocardiographie.'],
    ['Traitement', 'Antibiotiques bactéricides IV prolongés, chirurgie si complication.'],
   ]), 41) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Bactériémie continue', '3 paires d’hémocultures', 'Antibiotique adapté au germe'],
    ['Destruction valvulaire', 'Échocardiographie', 'Chirurgie valvulaire'],
    ['Embolies', 'Scanner, IRM cérébrale', 'Chirurgie précoce si grosse végétation'],
    ['Abcès péri-valvulaire', 'ETO, PET-CT', 'Chirurgie'],
   ]), 41) +
 F('Critères de Duke : comptage et exemple',
   P('Le diagnostic est certain avec 2 critères majeurs, ou 1 majeur et 3 mineurs, ou 5 mineurs. '
     'Exemple : hémocultures positives à streptocoque oral (1 majeur), fièvre, valvulopathie connue et lésion de Janeway (3 mineurs), donc EI certaine. '
     'Les critères de Duke 2023 de la Société internationale des maladies infectieuses cardiovasculaires (ISCVID) sont plus sensibles que les critères modifiés : 84,2 % contre 74,9 %.', 121, 122), 121, 122)))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant une fièvre avec souffle nouveau, prothèse ou embolie, le médecin pense d’abord à l’EI et cherche une urgence : insuffisance cardiaque aiguë, AVC, choc. '
   'Il prélève ensuite 3 paires d’hémocultures avant tout antibiotique, puis demande une échocardiographie. '
   'Il distingue enfin l’EI des autres fièvres prolongées.', 41) +
 F('Diagnostic différentiel des germes (fréquences en exposant rouge, même population : registre européen de l’endocardite)',
   TAB(['Germe et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Staphylocoques' + PR('44,1 %', 42), 'Évolution aiguë, cathéter, drogue IV', 'Hémocultures'],
    ['Entérocoques' + PR('15,8 %', 42), 'Âge, geste urologique ou digestif', 'Hémocultures'],
    ['Streptocoques oraux' + PR('12,3 %', 42), 'Soins dentaires, évolution subaiguë', 'Hémocultures'],
    ['Streptococcus gallolyticus' + PR('6,6 %', 42), 'Cancer du côlon associé', 'Hémocultures puis coloscopie'],
    ['EI à hémocultures négatives', 'Antibiotique préalable, germes difficiles (Coxiella, Bartonella)', 'Sérologies, PCR'],
   ]) + P('Les diagnostics non infectieux (lymphome, maladie systémique, endocardite non infectieuse) n’ont pas de fréquence dans cette population.', 42), 42, 41)))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien recherche une valvulopathie ou une prothèse, un antécédent d’EI, des soins dentaires, une drogue IV, un cathéter, un stimulateur et un antibiotique récent.', 41) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Avez-vous une valve artificielle ou un stimulateur ?', 'Haut risque.', 'ETO rapide.'],
    ['Avez-vous déjà eu une endocardite ?', 'Haut risque.', 'Seuil de suspicion bas.'],
    ['Avez-vous pris un antibiotique récemment ?', 'Hémocultures négatives possibles.', 'Prélever avant toute nouvelle dose.'],
    ['Vous injectez-vous des drogues ?', 'EI droite à Staphylococcus aureus.', 'Couverture antistaphylococcique.'],
    ['Avez-vous eu des soins dentaires ?', 'Streptocoques oraux.', 'Orientation du germe.'],
    ['Avez-vous mal au dos, une faiblesse d’un côté ?', 'Embolie, spondylodiscite.', 'Imagerie.'],
   ]), 41) +
 U('<b>Drapeaux rouges (144 ou urgences)</b> : dyspnée aiguë (fuite valvulaire), déficit neurologique fébrile, choc, douleur lombaire brutale (infarctus rénal).', 41)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen ausculte le cœur à la recherche d’un souffle nouveau et cherche les signes d’embolie sur la peau, les doigts, les yeux et la rate. '
   'Il examine les dents et les points d’injection. '
   'Un examen normal n’exclut pas l’EI, car la plupart des patients se présentent tôt, sans les signes classiques.', 118) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Auscultation des 4 foyers', 'Bruits du cœur sans souffle', 'Souffle nouveau : fuite valvulaire'],
    ['Pulpe des doigts', 'Souple, indolore', 'Nodosité d’Osler (douloureuse) : phénomène immunologique'],
    ['Paumes et plantes', 'Peau normale', 'Lésion de Janeway (indolore) : embolie'],
    ['Conjonctives, ongles', 'Normaux', 'Pétéchies, hémorragies en flammèche'],
    ['Fond d’œil', 'Normal', 'Tache de Roth'],
    ['Palpation de la rate', 'Non palpable', 'Splénomégalie'],
   ]) + P('La valeur de ces signes est faible : dans la cohorte internationale de l’endocardite, 77 % des patients se présentent en moins de 30 jours, avec peu de signes classiques.', 118), 118, 41)))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fatigue, la perte de poids, les sueurs et la dyspnée. '
   'Les signes physiques sont la fièvre, le souffle, les signes cutanés et la splénomégalie. '
   'Les complications révèlent parfois la maladie.', 41, 118) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme'], [
    ['Syndrome infectieux', 'Fièvre, sueurs, perte de poids', 'Bactériémie continue'],
    ['Syndrome embolique', 'AVC, infarctus splénique ou rénal, ischémie d’un membre', 'Fragment de végétation'],
    ['Syndrome d’insuffisance cardiaque', 'Dyspnée, œdème pulmonaire', 'Destruction valvulaire'],
    ['Syndrome immunologique', 'Nodosités d’Osler, taches de Roth, glomérulonéphrite', 'Complexes immuns'],
   ]), 41) +
 F('Signe : souffle de régurgitation nouveau',
   P('Geste : ausculter au foyer mitral et aortique, patient assis penché en avant pour le foyer aortique. '
     'Signe : souffle doux qui n’existait pas. '
     'Mécanisme : la valve détruite ne ferme plus.', 41), 41) +
 F('Signe : nodosité d’Osler',
   P('Geste : palper la pulpe des doigts et des orteils. '
     'Signe : petit nodule rouge, douloureux, fugace. '
     'Mécanisme : réaction immunitaire dans les petits vaisseaux.', 41), 41) +
 F('Signe : lésion de Janeway',
   P('Geste : inspecter paumes et plantes. '
     'Signe : macule rouge, indolore, qui ne s’efface pas. '
     'Mécanisme : micro-embolie septique.', 41), 41)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le diagnostic repose sur les critères de Duke modifiés par l’ESC en 2023 et par le consensus Duke-ISCVID 2023. '
   'Les critères majeurs sont des hémocultures typiques et une imagerie positive (végétation, abcès, fuite de prothèse). '
   'Une ETT normale ne suffit pas pour exclure une EI.', 41, 121, 120) +
 F('Critères',
   TAB(['Catégorie', 'Contenu', 'Remarque'], [
    ['Majeur microbiologique', 'Germe typique dans ≥ 2 hémocultures séparées, ou bactériémie persistante', '3 paires, 40–60 mL de sang au total'],
    ['Majeur imagerie', 'Végétation, abcès, perforation, fuite de prothèse ; PET-CT pour les prothèses', 'ETO ou ETT'],
    ['Mineurs', 'Prédisposition, fièvre > 38 °C, phénomènes vasculaires, phénomènes immunologiques, microbiologie non typique', '—'],
    ['EI certaine', '2 majeurs, ou 1 majeur et 3 mineurs, ou 5 mineurs', 'Duke'],
    ['EI possible', '1 majeur et 1 mineur, ou 3 mineurs', 'Duke'],
   ]), 41, 121)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Hémocultures (3 paires)', 'Germe et sensibilité', 'Négatives si antibiotique préalable', 'Prélever avant l’antibiotique'],
    ['ETO', 'Végétation, abcès', 'Référence de l’imagerie valvulaire', 'Examen invasif'],
    ['ETT', 'Première imagerie', 'Sensibilité 72 % par rapport à l’ETO', 'Ne permet pas d’exclure'],
    ['Critères Duke-ISCVID', 'Classement diagnostique', 'Sensibilité 84,2 %', 'Moins spécifique que l’avis d’experts'],
   ]), 41, 120, 122) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', '3 paires d’hémocultures', 'Avant tout antibiotique'],
    ['Première', 'ETT', 'Toute suspicion'],
    ['Première', 'NFS, CRP, créatinine, analyse d’urine', 'Toujours'],
    ['Seconde', 'ETO', 'Prothèse, ETT négative mais suspicion forte, complication'],
    ['Seconde', 'PET-CT, scanner cardiaque', 'Prothèse, abcès'],
    ['Seconde', 'IRM ou scanner cérébral', 'Signes neurologiques, avant chirurgie'],
   ]), 41) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Prélever 3 paires d’hémocultures à des sites distincts, avant l’antibiotique.', 'Chez le patient stable, attendre le résultat des hémocultures avant l’antibiotique.', 'Répéter l’ETO si la suspicion persiste après un premier examen négatif.']), 41) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Normal', 'Seuil', 'Signification et conduite'], [
    ['Hémocultures', 'Négatives', '≥ 2 positives au même germe typique', 'Critère majeur'],
    ['Végétation à l’échographie', 'Absente', '> 10 mm, mobile', 'Risque embolique : avis chirurgical'],
    ['Créatinine', 'Selon l’âge', 'Hausse', 'Glomérulonéphrite, toxicité, adapter les doses'],
    ['CRP', '< 5 mg/L', 'Élevée', 'Suivi de la réponse'],
   ]), 41) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (staphylocoque à coagulase négative sur 1 flacon)', 'Contamination probable : répéter'],
    ['Résultat négatif mais clinique forte', 'Sérologies Coxiella et Bartonella, PCR de la valve'],
    ['Résultat limite à l’ETT', 'ETO'],
    ['Grossesse', 'Échocardiographie, IRM sans gadolinium'],
    ['Enfant', 'ETT souvent suffisante'],
    ['DFGe bas', 'Scanner sans injection, PET-CT'],
    ['Allergie au produit iodé, pacemaker', 'PET-CT, ETO'],
   ]), 41))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Les hémocultures et l’échocardiographie sont les deux piliers. '
   'L’ETO s’impose chez les porteurs de prothèse et quand l’ETT est négative malgré une forte suspicion. '
   'L’imagerie nucléaire aide pour les prothèses.', 41, 120) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si le patient est stable, alors le médecin prélève 3 paires d’hémocultures et attend leur résultat avant l’antibiotique. '
   'Si le patient est instable, alors il prélève puis débute un antibiotique empirique immédiatement. '
   'Si l’EI est confirmée, alors l’équipe d’endocardite décide du traitement et d’une chirurgie.', 41) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['ETT négative, suspicion faible', 'Chercher un autre diagnostic', 'Réévaluation'],
    ['ETT négative, suspicion forte ou prothèse', 'ETO', 'Répéter à 5–7 jours si négative'],
    ['Insuffisance cardiaque par fuite valvulaire', 'Chirurgie en urgence', 'Équipe d’endocardite'],
    ['Infection non contrôlée (abcès, hémocultures persistantes)', 'Chirurgie urgente', 'Hémocultures de contrôle'],
    ['Végétation > 10 mm avec embolie', 'Chirurgie précoce', 'Imagerie cérébrale'],
    ['Patient stable après au moins 10 jours IV', 'Relais oral possible (POET)', 'Suivi ambulatoire'],
   ]), 41, 79)))
MED = F('Fiches médicamenteuses (posologies ESC 2023 et AIPS)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Pénicilline G (pénicilline)', 'Bactéricide, temps-dépendante', '12–18 millions UI/j IV, 4 semaines (streptocoques, valve native)', 'Allergie (CI) ; convulsions à forte dose'],
   ['Ceftriaxone, Rocephin® (céphalosporine)', 'Bactéricide, une prise par jour', '2 g/j IV', 'Allergie ; boue biliaire'],
   ['Flucloxacilline, Floxapen® (pénicilline antistaphylococcique)', 'Active sur Staphylococcus aureus sensible', '12 g/j IV en 4–6 doses, 4–6 semaines', 'Hépatite cholestatique, allergie'],
   ['Vancomycine (glycopeptide)', 'Active sur staphylocoques résistants', '15–20 mg/kg toutes les 8–12 heures, selon la concentration', 'Atteinte rénale ; adapter au DFGe'],
   ['Gentamicine (aminoside)', 'Synergie avec une pénicilline', '3 mg/kg/j, durée courte selon le germe', 'Atteinte rénale et de l’oreille interne ; plus recommandée dans l’EI à Staphylococcus aureus sur valve native'],
  ]) + P('Correction de l’original : la gentamicine n’est plus associée de routine ; l’ESC 2023 la réserve à certains germes et schémas. '
         'Les durées sont de 4 semaines pour une valve native et de 6 semaines pour une prothèse.', 41, 4, 5), 41, 4, 5)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge associe des antibiotiques bactéricides prolongés, parce que les bactéries sont protégées dans la végétation. '
   'Elle discute la chirurgie dans l’équipe d’endocardite pour les complications. '
   'Le but est de stériliser les hémocultures et d’éviter embolies et insuffisance cardiaque, alors que la mortalité hospitalière reste de 17 %.', 41, 118) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans la forme compliquée (insuffisance cardiaque, abcès, embolie), le but est une chirurgie dans les heures ou jours selon l’urgence. '
     'Dans la forme non compliquée, le but est une guérison par antibiotiques seuls, avec relais oral possible chez le patient stable.', 41, 79), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures',
     OL(['<b>A. Urgence</b> : insuffisance cardiaque ou choc : soins intensifs, chirurgie en urgence.',
         '<b>B. Antibiotique</b> : selon le germe et la valve, 4 à 6 semaines ; hémocultures de contrôle.',
         '<b>C. Forme non compliquée</b> : mesures générales (soins dentaires, retrait des cathéters, contrôle des foyers) ; relais oral après au moins 10 jours IV si stable.',
         '<b>D. Suivi</b> : échocardiographie de fin de traitement, éducation du patient.']), 41, 79) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail de plusieurs semaines à mois est habituel, prolongé après une chirurgie cardiaque.',
            'La conduite automobile est suspendue après un AVC ou une chirurgie cardiaque, selon les règles de la médecine du trafic.',
            'Une EI après piqûre accidentelle chez un soignant relève de la LAA ; une invalidité après AVC peut relever de la LAI.'), 41) +
   F('Traitements non médicamenteux',
     UL(['Soins dentaires avant chirurgie valvulaire.', 'Retrait d’un stimulateur infecté.', 'Accompagnement de l’usager de drogues IV.']), 41) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Équipe d’endocardite avec obstétrique ; bêtalactamines utilisables'],
      ['Enfant', 'Doses selon le poids'],
      ['Sujet âgé', 'Présentation trompeuse ; prudence avec gentamicine'],
      ['Insuffisance hépatique', 'Surveiller la flucloxacilline'],
      ['Insuffisance rénale (DFGe bas)', 'Adapter vancomycine et gentamicine ; dosage'],
     ]), 41, 4), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Hémocultures de contrôle', '48–72 heures', 'Persistance : chercher un abcès, chirurgie'],
    ['Température, CRP', 'Chaque jour puis chaque semaine', 'Pas de baisse : réévaluer'],
    ['Créatinine, concentration de vancomycine', '2 fois par semaine', 'Adapter les doses'],
    ['Échocardiographie', 'Fin de traitement', 'Référence pour la suite'],
   ]) + H4('Critères de sortie, un par un') + OL(['Hémocultures stériles.', 'Apyrexie.', 'Pas de complication en cours.', 'Relais oral ou traitement ambulatoire organisé.']), 41) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La mortalité hospitalière est de 17,7 % dans la cohorte internationale et de 17,1 % dans le registre européen. '
     'Le relais oral chez le patient stable est non inférieur au traitement IV (12,1 % contre 9,0 % d’événements). '
     'La recherche 2026 porte sur le PET-CT et les critères Duke-ISCVID.', 118, 42, 79, 122), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur une bonne hygiène dentaire et cutanée pour tous. '
   'La recommandation suisse de la SSI limite la prophylaxie antibiotique aux patients à haut risque avant les gestes dentaires sur la gencive ou la région péri-apicale. '
   'Elle consiste en amoxicilline 2 g per os 30 à 60 minutes avant le geste.', 20) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Dentiste 1–2 fois par an, désinfection des plaies, piercings et tatouages déconseillés chez les patients à haut risque'],
    ['Secondaire', 'Hémocultures avant tout antibiotique devant une fièvre chez un porteur de prothèse'],
    ['Tertiaire', 'Prophylaxie avant gestes dentaires chez les patients à haut risque (antécédent d’EI, prothèse, certaines cardiopathies congénitales)'],
   ]), 20, 41)))
PTS.append(POINT(13, 'Points clés',
 P('Fièvre et souffle nouveau, ou fièvre chez un porteur de prothèse, font penser à une endocardite. '
   'Les hémocultures se prélèvent avant tout antibiotique. '
   'Une ETT normale n’exclut pas l’EI. '
   'L’équipe d’endocardite décide de la chirurgie.', 41, 120)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Donner un antibiotique avant les hémocultures chez un patient stable.', 'Non : prélever d’abord.'],
  ['Exclure une EI sur une ETT normale.', 'Non : sensibilité 72 %.'],
  ['Ajouter la gentamicine à toute EI à staphylocoque.', 'Non : plus recommandé sur valve native.'],
  ['Donner une prophylaxie pour une coloscopie.', 'Non selon la SSI.'],
  ['Oublier la coloscopie après Streptococcus gallolyticus.', 'Chercher un cancer du côlon.'],
 ]) + P('Ces pièges entraînent le raisonnement ; ils ne sont pas des questions officielles de l’examen fédéral.', 41, 120, 20)))
CTX = {'_prefixe': 'Dans une endocardite infectieuse',
 'hemoc': 'Trois paires d’hémocultures à des sites distincts, avant l’antibiotique, sont le premier examen.',
 'ett': 'L’ETT est la première imagerie ; sa sensibilité est de 72 % par rapport à l’ETO.',
 'eto': 'L’ETO voit les végétations et les abcès ; elle est indiquée chez les porteurs de prothèse.',
 'echocoeur': 'L’échocardiographie recherche végétation, abcès et fuite valvulaire.',
 'nfs': 'La NFS montre souvent une anémie inflammatoire et une hausse des neutrophiles.',
 'crp': 'La CRP suit la réponse au traitement.',
 'creat': 'La créatinine surveille la glomérulonéphrite et la toxicité des antibiotiques.',
 'urine': 'La bandelette urinaire montre une hématurie en cas de glomérulonéphrite ou d’infarctus rénal.',
 'pet': 'Le PET-CT détecte l’infection d’une prothèse valvulaire et les embolies.',
 'tdm': 'Le scanner cherche des embolies et des abcès.',
 'irm': 'L’IRM cérébrale cherche des embolies avant chirurgie.',
 'ecg': 'L’ECG cherche un trouble de conduction, signe d’abcès.',
 'sero': 'Les sérologies Coxiella et Bartonella sont faites si les hémocultures restent négatives.',
 'vs': 'La vitesse de sédimentation est élevée mais non spécifique.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
