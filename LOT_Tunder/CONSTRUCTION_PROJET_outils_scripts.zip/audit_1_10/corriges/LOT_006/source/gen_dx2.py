# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.2 · Infections urinaires fébriles (LOT 6, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('dx2')
M = meta('dx2', 'DX.2', 'Infections urinaires', 'Infections urinaires : cystite, pyélonéphrite, prostatite et urosepsis',
         'LOT_006_DX2_Infections_urinaires_AUDITÉ.html')
PYELO = T('pyélonéphrite', 'La pyélonéphrite est l’infection du rein et du bassinet ; elle donne fièvre et douleur lombaire, contrairement à la cystite.')
OBST = T('pyélonéphrite obstructive', 'Une pyélonéphrite obstructive est une infection en amont d’un obstacle (calcul, tumeur) : l’urine infectée ne s’évacue plus et le sepsis s’aggrave vite.')
BA = T('bactériurie asymptomatique', 'La bactériurie asymptomatique est la présence de ≥ 10⁵ bactéries/mL dans l’urine sans symptôme ; elle ne se traite pas, sauf grossesse et avant une intervention urologique.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('L’infection urinaire est l’invasion de l’arbre urinaire par une bactérie, avec symptômes. '
   f'La cystite touche la vessie, sans fièvre ; la {PYELO} touche le rein, avec fièvre. '
   'La SSI la dit « simple » en l’absence d’anomalie urinaire, de sonde, de grossesse et d’immunosuppression.', 14) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Cystite simple', 'Dysurie, pollakiurie, urgence, hématurie, sans fièvre', 'Urétrite (IST), vaginite'],
    ['Pyélonéphrite', 'Fièvre, douleur lombaire, nausées', 'Colique néphrétique non infectée'],
    ['Prostatite aiguë', 'Fièvre, troubles mictionnels, douleur pelvienne chez l’homme', 'Pyélonéphrite isolée'],
    ['Urosepsis', 'Dysfonction d’organe due à une infection urinaire', 'Fièvre isolée'],
    ['Bactériurie asymptomatique', '≥ 10⁵ UFC/mL sans symptôme', 'Infection urinaire à traiter'],
   ]) + P('Terme : ' + BA + '.', 14), 14, 105)))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, 20 à 30 % des isolats urinaires sont résistants au triméthoprime/sulfaméthoxazole selon la SSI. '
   'Près d’une femme sur deux aura une infection urinaire au cours de sa vie, selon les données internationales de Foxman. '
   'Le classement « 2e cause de fièvre, 18 % » de l’original n’a pas été retrouvé dans une publication et il est retiré.', 14, 100, 99) +
 F('Chiffres et terrain',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Résistance au triméthoprime/sulfaméthoxazole', '20–30 % des isolats urinaires' + PR('20–30 %', 14), 'Suisse (SSI)'],
    ['Au moins une infection urinaire traitée avant 24 ans', 'près d’1 femme sur 3', 'États-Unis (Foxman)'],
    ['Au moins une infection urinaire dans la vie', 'près de la moitié des femmes' + PR('≈ 50 %', 100), 'États-Unis (Foxman)'],
    ['Prostatites avec infection bactérienne confirmée', '< 10 %', 'Recommandation européenne EAU'],
   ], 'Les femmes sont nettement plus touchées que les hommes ; le risque augmente avec la grossesse, l’âge, la sonde et le diabète. Le pronostic dépend de l’obstacle et du sepsis ; aucune mortalité suisse publiée n’a été retrouvée.') +
   P('Les terrains à risque sont la femme jeune sexuellement active, la grossesse, la personne âgée, l’homme avec hypertrophie de la prostate et le porteur de sonde.', 100), 14, 100, 105)))
PTS.append(POINT(3, 'Physiopathologie',
 P('Des bactéries du tube digestif remontent l’urètre jusqu’à la vessie : c’est la voie ascendante. '
   'Escherichia coli uropathogène en est la première cause grâce à ses adhésines, et si les bactéries montent jusqu’au rein, la réaction inflammatoire provoque fièvre, frissons et parfois bactériémie.', 104) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'L’urètre féminin est court, d’où le risque plus élevé chez la femme ; la prostate entoure l’urètre de l’homme.'],
    ['Physiologie', 'Le flux d’urine et la vidange complète de la vessie chassent les bactéries.'],
    ['Physiopathologie', 'Un obstacle (calcul, prostate) ou une sonde empêche cette vidange et favorise l’infection.'],
    ['Clinique', 'Vessie : brûlures, pollakiurie ; rein : fièvre, douleur lombaire ; prostate : fièvre et rétention.'],
    ['Examens', 'La bandelette montre leucocytes et nitrites ; la culture identifie le germe et sa sensibilité.'],
    ['Traitement', 'Antibiotique qui atteint le tissu infecté ; drainage si obstacle.'],
   ]), 104, 14, 105) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Infection de la vessie', 'Clinique seule chez la femme typique', 'Nitrofurantoïne 5 jours'],
    ['Infection du rein', 'Bandelette, culture, 2 paires d’hémocultures', 'Ciprofloxacine 7 jours'],
    ['Obstacle des voies urinaires', 'Échographie rénale, scanner', 'Drainage (sonde double J, néphrostomie)'],
    ['Infection de la prostate', 'Bandelette, culture, hémocultures', 'Traitement de 2–4 semaines'],
   ]), 14, 105) +
 F('Seuils de l’examen d’urine : calcul et exemple',
   TAB(['Paramètre', 'Seuil retenu', 'Source'], [
    ['Pyurie', '> 10 leucocytes/mm³', 'SSI'],
    ['Culture positive (infection symptomatique)', '≥ 10³ UFC/mL d’un uropathogène', 'SSI (consensus)'],
    ['Bactériurie asymptomatique', '≥ 10⁵ UFC/mL', 'SSI'],
   ]) + P('Exemple : femme de 32 ans, dysurie et fièvre à 38,5 °C, culture à Escherichia coli > 10⁵ UFC/mL. '
          'La fièvre indique une pyélonéphrite et non une cystite ; le traitement dure 7 jours.', 14), 14)))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin cherche d’abord une urgence : urosepsis ou obstacle, qui imposent un drainage urgent. '
   'Il distingue ensuite la cystite sans fièvre de la pyélonéphrite et, chez l’homme, de la prostatite. '
   'Il pense enfin aux diagnostics qui imitent les symptômes urinaires : vaginite, urétrite, appendicite.', 105, 14) +
 F('Probabilité d’infection urinaire chez la femme symptomatique (même population : femmes consultant pour au moins un symptôme urinaire)',
   TAB(['Situation et probabilité', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Au moins un symptôme urinaire' + PR('≈ 50 %', 66), 'Dysurie, pollakiurie, hématurie', 'Bandelette, culture si atypique'],
    ['Dysurie et pollakiurie sans pertes vaginales' + PR('> 90 %', 66), 'Rapport de vraisemblance 24,6', 'Aucun : traitement empirique'],
    ['Pertes ou irritation vaginales', 'Rapports de vraisemblance 0,3 et 0,2 : l’infection urinaire devient moins probable', 'Examen gynécologique'],
    ['Urétrite (IST)', 'Partenaire nouveau, écoulement', 'PCR chlamydia et gonocoque'],
    ['Pyélonéphrite obstructive', 'Fièvre, douleur lombaire, colique, choc', 'Échographie ou scanner'],
   ]) + P('Ces probabilités viennent d’une méta-analyse de femmes sans complication ; aucune fréquence comparable n’a été retrouvée pour l’urétrite et l’obstacle dans la même population.', 66), 66, 14)))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise les brûlures, la pollakiurie, la fièvre, la douleur lombaire, les pertes vaginales, la grossesse, une sonde et les antibiotiques récents.', 66, 14) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Avez-vous de la fièvre ou des frissons ?', 'Atteinte du rein ou de la prostate.', 'Culture, hémocultures.'],
    ['Avez-vous mal dans le dos, d’un côté ?', 'Douleur lombaire de pyélonéphrite.', 'Fait chercher un obstacle.'],
    ['Avez-vous des pertes ou des démangeaisons vaginales ?', 'Rapports de vraisemblance 0,3 et 0,2.', 'Penser à une vaginite.'],
    ['Êtes-vous enceinte ?', 'Infection à risque.', 'Culture et traitement adapté.'],
    ['Avez-vous pris un antibiotique récemment ?', 'Risque de résistance.', 'Choix de l’antibiotique.'],
    ['Urinez-vous difficilement ?', 'Rétention, prostate.', 'Échographie vésicale.'],
   ]), 66, 14) +
 U('<b>Drapeaux rouges (144 ou urgences)</b> : hypotension, confusion, fréquence respiratoire ≥ 22/min (qSOFA), anurie, rétention aiguë d’urine, douleur lombaire fébrile sur rein unique ou calcul connu.', 105, 64)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen mesure la température, la pression, le pouls et la fréquence respiratoire. '
   'Il palpe l’hypogastre, percute doucement les fosses lombaires et cherche un globe vésical. '
   'Chez l’homme, le toucher rectal est doux et sans massage de la prostate.', 105, 66) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Percussion de l’angle costo-vertébral', 'Indolore', 'Douleur : rapport de vraisemblance 1,7 pour une infection urinaire'],
    ['Palpation sus-pubienne', 'Souple, indolore', 'Sensibilité : cystite ; masse : globe vésical'],
    ['Toucher rectal', 'Prostate indolore, ferme', 'Prostate chaude et très douloureuse : prostatite (pas de massage)'],
    ['Constantes', 'Pression systolique > 100 mmHg, fréquence < 22/min', 'Critères qSOFA : sepsis possible'],
   ]) + P('La valeur des signes est modeste : leur sensibilité est faible et aucun ne permet d’exclure l’infection chez une femme symptomatique.', 66), 66, 105)))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont les brûlures mictionnelles, la pollakiurie, l’urgence, l’hématurie et la douleur lombaire. '
   'Les signes physiques sont la fièvre, la douleur lombaire à la percussion et la prostate douloureuse. '
   'Chez la personne âgée, une confusion peut révéler l’infection.', 14, 105) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme'], [
    ['Syndrome cystite', 'Dysurie, pollakiurie, urgence, sans fièvre', 'Inflammation de la vessie'],
    ['Syndrome de pyélonéphrite aiguë', 'Fièvre, frissons, douleur lombaire, nausées', 'Infection du rein'],
    ['Syndrome de prostatite aiguë', 'Fièvre, dysurie, douleur périnéale, rétention', 'Infection de la prostate'],
    ['Syndrome d’urosepsis', 'Hypotension, confusion, tachypnée', 'Réponse dérégulée à l’infection'],
   ]) + P('Terme : ' + OBST + '.', 105), 14, 105)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Selon la recommandation SSI de 2020, l’infection simple associe des symptômes typiques, une pyurie et une culture positive (seuils au tableau). '
   'Chez une femme avec symptômes typiques de cystite, aucun examen d’urine n’est nécessaire. '
   'Une bandelette positive ne suffit pas sans symptômes : c’est une bactériurie asymptomatique. '
   'Le critère de gravité est le qSOFA : pression systolique ≤ 100 mmHg, fréquence respiratoire ≥ 22/min, confusion.', 14, 67, 105) +
 F('Critères retenus',
   TAB(['Situation', 'Critère', 'Conséquence'], [
    ['Cystite simple', 'Symptômes typiques, pas de fièvre', 'Traitement empirique'],
    ['Pyélonéphrite', 'Fièvre et douleur lombaire, pyurie, culture ≥ 10³ UFC/mL', 'Culture, hémocultures, antibiotique'],
    ['Urosepsis', 'qSOFA ≥ 2 ou hausse du score SOFA ≥ 2', 'Antibiotique IV dans l’heure, drainage'],
    ['Bactériurie asymptomatique', '≥ 10⁵ UFC/mL sans symptôme', 'Pas de traitement (sauf grossesse, chirurgie urologique)'],
   ]), 14, 64, 105, 67)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Culture d’urine avec antibiogramme (ECBU)', 'Germe et sensibilité', 'Référence', 'Résultat en 24–48 heures'],
    ['Hémocultures (2 paires)', 'Bactériémie', 'Positives dans une partie des pyélonéphrites ; chiffre exact non retenu', 'Prélever avant l’antibiotique'],
    ['Bandelette urinaire', 'Leucocytes, nitrites', 'Ne permet pas d’exclure l’infection chez la femme symptomatique', 'Nitrites négatifs avec les germes qui ne réduisent pas les nitrates'],
   ]), 14, 66, 105) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Aucun', 'Pas d’examen', 'Cystite typique de la femme'],
    ['Première', 'Bandelette, culture d’urine, 2 paires d’hémocultures', 'Pyélonéphrite, prostatite'],
    ['Première', 'NFS, CRP, créatinine', 'Forme fébrile'],
    ['Première (urgence)', 'Échographie rénale', 'Suspicion d’obstacle, sepsis'],
    ['Seconde', 'Scanner abdominal injecté', 'Abcès, fièvre persistante après 72 heures'],
   ]), 14, 105) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['L’urine du milieu de jet est recueillie après toilette, idéalement le matin ; elle est analysée dans les 2 heures ou réfrigérée.',
       'Les hémocultures et la culture d’urine précèdent l’antibiotique.',
       'Le scanner injecté demande une créatinine récente.']), 14, 105) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Normal', 'Seuil', 'Signification et conduite'], [
    ['Leucocytes urinaires', '≤ 10/mm³', '> 10/mm³', 'Pyurie, compatible avec l’infection'],
    ['Culture', 'Stérile', '≥ 10³ UFC/mL (symptômes)', 'Infection ; adapter à l’antibiogramme'],
    ['Culture sans symptôme', '—', '≥ 10⁵ UFC/mL', 'Bactériurie asymptomatique : ne pas traiter'],
    ['Créatinine', 'Selon l’âge et le sexe', 'Hausse aiguë', 'Atteinte rénale, obstacle ; adapter les doses'],
    ['Échographie', 'Cavités fines', 'Dilatation des cavités', 'Obstacle : drainage urgent'],
   ]) + P('Correction de l’original : une bandelette négative n’exclut pas l’infection chez une femme symptomatique ; la culture reste nécessaire si les symptômes sont atypiques.', 66), 14, 66) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (culture positive sans symptôme)', 'Bactériurie asymptomatique : pas d’antibiotique'],
    ['Résultat négatif mais clinique forte', 'Culture, chercher une urétrite ou une prostatite'],
    ['Résultat limite (10²–10³ UFC/mL d’Escherichia coli)', 'Peut être pertinent ; ne pas banaliser (SSI)'],
    ['Grossesse', 'Dépistage unique de la bactériurie au 2e trimestre ; échographie plutôt que scanner'],
    ['Enfant', 'Hors du champ de la recommandation SSI : avis pédiatrique'],
    ['DFGe bas', 'Nitrofurantoïne contre-indiquée si DFGe < 45 mL/min'],
    ['Allergie à l’iode, pacemaker ou IRM', 'Scanner sans injection pour les calculs ; IRM possible selon le pacemaker'],
   ]), 14, 3))
PTS.append(POINT(9, 'Examens complémentaires',
 P('La cystite typique de la femme ne demande aucun examen. '
   'La pyélonéphrite demande bandelette, culture et hémocultures. '
   'L’imagerie cherche un obstacle dès qu’il y a sepsis, colique ou absence d’amélioration.', 14, 105) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si la femme a des symptômes typiques de cystite sans fièvre, alors le médecin traite sans examen. '
   'Si la fièvre ou la douleur lombaire est présente, alors il demande culture et hémocultures, puis traite la pyélonéphrite. '
   'Si un sepsis ou un obstacle est présent, alors il hospitalise et fait drainer en urgence.', 14, 105) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Cystite typique, symptômes ≤ 5 jours, pas de pyélonéphrite antérieure', 'Option : AINS 48 heures et antibiotique de réserve', 'Reconsulter si fièvre'],
    ['Cystite', 'Nitrofurantoïne 5 jours ou triméthoprime/sulfaméthoxazole 3 jours', 'Culture si récidive'],
    ['Pyélonéphrite stable', 'Ciprofloxacine 7 jours', 'Contrôle à 48–72 heures'],
    ['Pyélonéphrite instable', 'Ceftriaxone 1 g/j IV', 'Adapter à l’antibiogramme'],
    ['Obstacle', 'Drainage urgent (sonde double J, néphrostomie)', 'Urologue'],
    ['Homme fébrile', 'Prostatite à envisager, traitement 2–4 semaines', 'Pas de massage prostatique'],
   ]) + P('L’option sans antibiotique a un prix : dans l’essai suisse de Kronenberg, les symptômes ont guéri à J3 chez 54 % sous diclofénac contre 80 % sous norfloxacine, avec 5 % de pyélonéphrites contre 0 %.', 101), 14, 101, 105)))
MED = F('Fiches médicamenteuses (posologies AIPS et SSI)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Nitrofurantoïne, Furadantine® retard (nitrofurane)', 'Concentrée dans l’urine, sans diffusion dans le rein : réservée à la cystite', 'Cystite : 100 mg toutes les 8 heures, 5 jours (SSI)', 'CI : DFGe < 45 mL/min, déficit en G6PD, fin de grossesse ; fibrose pulmonaire en traitement long'],
   ['Triméthoprime/sulfaméthoxazole, Nopil® forte (antifolate)', 'Bloque la synthèse de l’acide folique bactérien ; bonne diffusion tissulaire', 'Cystite : 160/800 mg toutes les 12 heures, 3 jours', 'CI : clairance < 15 mL/min, 3e trimestre, G6PD ; hyperkaliémie ; interactions : méthotrexate, warfarine'],
   ['Fosfomycine, Monuril® (antibiotique à part)', 'Bloque la paroi bactérienne ; dose unique', '3 g en une prise (2e intention)', 'Moins efficace que la nitrofurantoïne dans un essai récent'],
   ['Ciprofloxacine, Cip eco® (fluoroquinolone)', 'Inhibe l’ADN gyrase ; excellente diffusion dans le rein et la prostate', 'Pyélonéphrite simple : 500 mg toutes les 12 heures, 7 jours', 'Tendinite, anévrisme aortique ; CI : grossesse, croissance, tizanidine ; impact écologique'],
   ['Ceftriaxone, Rocephin® (céphalosporine de 3e génération)', 'Bactéricide, demi-vie longue d’où 1 dose par jour', 'Pyélonéphrite instable : 1 g/j IV jusqu’à l’antibiogramme', 'Allergie ; boue biliaire ; impact écologique'],
   ['Gentamicine (aminoside)', 'Bactéricide rapide, élimination rénale', '5 mg/kg/j IV en alternative initiale (SSI)', 'Néphrotoxicité, ototoxicité : dosages et durée courte'],
  ]) + P('Correction de l’original : Ciproxin® 500 mg 2 fois par jour reste juste pour la pyélonéphrite, mais seulement 7 jours et seulement si la patiente est stable ; la ceftriaxone sert à la forme instable.', 14, 3), 3, 5, 14)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge choisit l’antibiotique selon le site : vessie, rein ou prostate. '
   'Elle lève un obstacle en urgence, parce qu’aucun antibiotique ne stérilise une urine bloquée. '
   'Le but chiffré est l’apyrexie en 48–72 heures et une durée minimale efficace : 5 jours pour la cystite, 7 jours pour la pyélonéphrite simple.', 14, 105) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans l’urosepsis, le but est de survivre : antibiotique IV dans la première heure et drainage de l’obstacle. '
     'Dans une forme non compliquée, le but est de guérir vite avec un spectre étroit.', 105, 14), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures',
     OL(['<b>A. Forme compliquée, en urgence (urosepsis, obstacle)</b> : 144 si choc ; culture d’urine et 2 paires d’hémocultures, puis antibiotique IV dans l’heure (ceftriaxone, ou pipéracilline/tazobactam selon le risque de résistance) ; échographie et drainage urgent.',
         '<b>B. Pyélonéphrite instable</b> : ceftriaxone 1 g/j IV ou gentamicine 5 mg/kg/j jusqu’à l’antibiogramme, puis relais oral.',
         '<b>C. Forme non compliquée</b> : cystite : nitrofurantoïne ou triméthoprime/sulfaméthoxazole ; pyélonéphrite stable : ciprofloxacine 7 jours ; mesures générales (boissons, antalgique, éducation).',
         '<b>D. Homme</b> : prostatite : traitement parentéral puis oral pour un total de 2–4 semaines ; infection urinaire de l’homme non fébrile : 7 jours suffisent.']) +
     P('Chez l’homme fébrile, 7 jours de ciprofloxacine guérissent 86 % des patients contre 98 % avec 14 jours ; chez la femme, 94 % contre 93 %.', 102, 103), 14, 105, 102, 103) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail de quelques jours est habituel pour une pyélonéphrite ; rarement pour une cystite.',
            'La conduite automobile est déconseillée tant que la fièvre et les frissons persistent.',
            'Une infection liée à une sonde après un accident relève de la LAA ; une néphropathie séquellaire peut concerner la LAI.')) +
   F('Traitements non médicamenteux',
     UL(['Drainage d’un obstacle : sonde double J ou néphrostomie percutanée.', 'Sonde vésicale (ou cathéter sus-pubien) en cas de rétention.', 'Hydratation suffisante, mictions régulières.']), 105) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Traiter aussi la bactériurie asymptomatique ; éviter quinolones, nitrofurantoïne en fin de grossesse et triméthoprime/sulfaméthoxazole au 3e trimestre'],
      ['Enfant', 'Hors recommandation SSI adulte ; avis pédiatrique, quinolones contre-indiquées pendant la croissance'],
      ['Sujet âgé', 'Confusion fréquente ; ne pas traiter une bactériurie asymptomatique'],
      ['Insuffisance hépatique', 'Éviter le triméthoprime/sulfaméthoxazole en cas d’atteinte grave'],
      ['Insuffisance rénale (DFGe bas)', 'Nitrofurantoïne exclue si DFGe < 45 mL/min ; adapter ciprofloxacine et gentamicine'],
     ]), 3, 14, 67), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Température, douleur', '48–72 heures', 'Fièvre persistante : imagerie (abcès, obstacle)'],
    ['Antibiogramme', 'Dès réception', 'Passer au spectre le plus étroit'],
    ['Créatinine', 'Sous gentamicine, à J2–J3', 'Hausse : arrêt de l’aminoside'],
    ['Culture de contrôle', 'Seulement si symptômes persistants ou récidive', 'Germe résistant : adapter'],
   ]) + H4('Critères de sortie, un par un') + OL(['Apyrexie et constantes stables.', 'Prise orale possible.', 'Obstacle drainé.', 'Relais oral adapté à l’antibiogramme.']), 14, 105) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La cystite guérit spontanément dans jusqu’à la moitié des cas, mais l’antibiotique raccourcit les symptômes de 1 à 2 jours. '
     'La recherche porte sur l’épargne des antibiotiques (AINS, prescription différée) et sur le D-mannose, dont l’efficacité reste incertaine.', 14, 101), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire évite les spermicides et maintient une bonne hydratation ; le jus de canneberge a peu de preuves. '
   'La prévention secondaire repose sur le dépistage de la bactériurie pendant la grossesse. '
   'La recommandation suisse de la SSI conseille de ne pas dépister ni traiter la bactériurie en dehors de ces cas.', 14) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Pas de spermicides ; œstrogènes locaux après la ménopause (efficacité 0–30 %)'],
    ['Secondaire', 'Dépistage unique de la bactériurie au 2e trimestre de grossesse et avant une intervention urologique'],
    ['Tertiaire', 'Retrait des sondes inutiles ; traitement de l’obstacle pour éviter les récidives'],
   ]), 14, 67)))
PTS.append(POINT(13, 'Points clés',
 P('La cystite typique de la femme se traite sans examen. '
   'La fièvre signe une atteinte du rein ou de la prostate. '
   'Une bactériurie sans symptôme ne se traite pas, sauf grossesse. '
   'Le médecin n’oublie jamais de chercher un obstacle chez un patient fébrile qui ne s’améliore pas, ni de prélever les cultures avant l’antibiotique.', 14, 105)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Traiter une pyélonéphrite par nitrofurantoïne.', 'Non : elle ne diffuse pas dans le rein.'],
  ['Traiter une bactériurie asymptomatique de la personne âgée.', 'Non : pas de traitement.'],
  ['Masser la prostate pour obtenir un prélèvement.', 'Non : contre-indiqué dans la prostatite aiguë.'],
  ['Exclure une infection sur une bandelette négative chez une femme symptomatique.', 'Non : culture si doute.'],
  ['Donner 7 jours à un homme fébrile.', 'Risqué : 7 jours sont inférieurs à 14 jours chez l’homme fébrile.'],
 ]) + P('Ces pièges entraînent le raisonnement ; ils ne sont pas des questions officielles de l’examen fédéral.', 14, 102)))
CTX = {'_prefixe': 'Dans une infection urinaire',
 'ecbu': 'La culture d’urine est positive dès 10³ UFC/mL d’un uropathogène si la patiente a des symptômes (SSI).',
 'hemoc': 'Deux paires d’hémocultures sont prélevées dans toute pyélonéphrite, avant l’antibiotique.',
 'crp': 'La CRP élevée confirme une atteinte tissulaire (rein, prostate) mais ne localise pas l’infection.',
 'pct': 'La procalcitonine est corrélée à la bactériémie, mais ne prédit pas l’échec du traitement.',
 'nfs': 'Une hyperleucocytose accompagne la pyélonéphrite ; une leucopénie évoque un sepsis grave.',
 'creat': 'Une créatinine en hausse évoque un obstacle ou un sepsis et modifie les doses.',
 'echoabdo': 'L’échographie rénale cherche une dilatation des cavités, signe d’obstacle.',
 'echo': 'L’échographie rénale et vésicale cherche un obstacle ou un résidu après miction.',
 'tdm': 'Le scanner injecté cherche un abcès rénal ou un calcul si la fièvre persiste après 72 heures.',
 'lact': 'Un lactate élevé signe la gravité d’un urosepsis.',
 'iono': 'Le potassium est surveillé sous triméthoprime/sulfaméthoxazole.',
 'uree': 'L’urée augmente avec la déshydratation et l’insuffisance rénale.',
 'hcg': 'Le test de grossesse change le choix de l’antibiotique.',
 'pcr': 'La PCR chlamydia et gonocoque cherche une urétrite qui imite la cystite.',
 'irm': 'L’IRM est rarement utile ; elle remplace le scanner pendant la grossesse si nécessaire.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
