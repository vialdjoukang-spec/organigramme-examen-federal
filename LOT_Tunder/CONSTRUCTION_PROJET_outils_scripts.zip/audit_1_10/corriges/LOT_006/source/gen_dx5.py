# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.5 · Méningites et encéphalites (LOT 6, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('dx5')
M = meta('dx5', 'DX.5', 'Méningites et encéphalites', 'Méningites et encéphalites infectieuses aiguës : méningite bactérienne, encéphalite herpétique, encéphalite à tiques',
         'LOT_006_DX5_Meningites_encephalites_AUDITÉ.html')
MEN = T('méningite', 'La méningite est une inflammation des enveloppes du cerveau (méninges) et du liquide qui les baigne.')
ENC = T('encéphalite', 'L’encéphalite est une inflammation du tissu cérébral lui-même ; elle trouble la conscience, le comportement ou provoque des crises.')
LCR = T('liquide céphalo-rachidien (LCR)', 'Le LCR entoure le cerveau et la moelle ; on le prélève par ponction lombaire.')
PUR = T('purpura', 'Le purpura est une tache rouge ou violacée qui ne s’efface pas à la pression du verre ; fébrile, il évoque un méningocoque.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'La {MEN} atteint les enveloppes du cerveau, l’encéphalite le cerveau lui-même, et la méningo-encéphalite les deux. '
   'L’analyse du liquide céphalo-rachidien (LCR) distingue les causes bactériennes, virales et autres. '
   'La triade fièvre, raideur de nuque et trouble de la conscience n’est complète que dans 44 % des méningites bactériennes de l’adulte.', 19, 47, 78) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Méningite bactérienne', 'Infection purulente des méninges', 'Méningite virale, bénigne le plus souvent'],
    ['Méningite aseptique', 'Méningite sans bactérie à la culture', 'Méningite bactérienne décapitée par un antibiotique'],
    ['Encéphalite', 'Atteinte du cerveau : confusion, crises, déficit', 'Encéphalopathie septique ou métabolique, sans inflammation cérébrale'],
    ['Syndrome méningé', 'Céphalées, vomissements, photophobie, raideur', 'Hémorragie méningée (début brutal, sans fièvre au départ)'],
    ['Purpura fulminans', 'Purpura extensif avec choc', 'Purpura thrombopénique sans fièvre'],
   ]) + P('Terme : ' + ENC + '. Le LCR entoure le cerveau et la moelle ; on le prélève par ponction lombaire.', 78), 19, 78)))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, en 2025, 37 maladies invasives à méningocoques (0,4 pour 100 000) et 502 encéphalites à tiques (5,5 pour 100 000) ont été déclarées. '
   'Le chiffre de l’original « 300 à 400 méningites bactériennes par an » n’a pas été retrouvé et il est retiré. '
   'En Europe, dans une cohorte néerlandaise de 696 méningites bactériennes de l’adulte, la mortalité est de 21 %.', 25, 114, 47, 99) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Méningocoques invasifs' + PR('0,4/100 000', 25), '37 cas sur 52 semaines', 'Suisse 2025 (Bulletin OFSP 52/2025)'],
    ['Encéphalite à tiques' + PR('5,5/100 000', 114), '502 cas, record depuis 1988 ; Union européenne 0,81/100 000', 'Suisse 2025'],
    ['Mortalité de la méningite bactérienne' + PR('21 %', 47), 'Pneumocoque 30 %, méningocoque 7 %', 'Adultes, Pays-Bas'],
    ['Pneumocoques invasifs (toutes formes)', '1 079 cas (11,9/100 000)', 'Suisse 2025 ; la part des méningites n’est pas donnée'],
   ], 'Les facteurs de mauvais pronostic sont l’âge avancé, une otite ou une sinusite, un score de Glasgow bas, une tachycardie et des hémocultures positives.'), 25, 47, 114)))
PTS.append(POINT(3, 'Physiopathologie',
 P('Les bactéries colonisent le nez et la gorge, passent dans le sang puis franchissent la barrière entre sang et cerveau. '
   'Leur destruction libère des fragments qui déclenchent une inflammation intense, un œdème cérébral et une baisse du débit sanguin cérébral. '
   'Les corticoïdes réduisent cette inflammation, ce qui explique leur bénéfice dans la méningite à pneumocoque.', 40, 45) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Méninges, espace sous-arachnoïdien, LCR.'],
    ['Physiologie', 'Le LCR contient peu de cellules et un glucose proche des deux tiers du sang.'],
    ['Physiopathologie', 'Inflammation purulente, consommation du glucose, œdème cérébral.'],
    ['Clinique', 'Céphalées, fièvre, raideur, confusion ; purpura si méningocoque.'],
    ['Examens', 'Hémocultures, ponction lombaire ; scanner seulement si critères.'],
    ['Traitement', 'Antibiotique dans l’heure, dexaméthasone, aciclovir si encéphalite.'],
   ]), 19) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Infection bactérienne du LCR', 'Gram, culture, PCR du LCR', 'Ceftriaxone ± amoxicilline'],
    ['Inflammation et œdème cérébral', 'Clinique, scanner si critères', 'Dexaméthasone (pneumocoque)'],
    ['Réplication du virus herpès dans le lobe temporal', 'PCR HSV du LCR, IRM', 'Aciclovir IV'],
    ['Méningocoque dans le sang', 'Purpura, hémocultures', 'Antibiotique immédiat, isolement'],
   ]), 19, 5) +
 F('Valeurs typiques après ponction : exemple',
   TAB(['Paramètre', 'Normal', 'Bactérienne (typique)', 'Virale (typique)'], [
    ['Cellules (/µL)', '< 5', 'Souvent > 1 000, neutrophiles', 'Souvent < 1 000, lymphocytes'],
    ['Protéines (g/L)', '0,15–0,45', 'Élevées', 'Normales ou peu élevées'],
    ['Rapport glucose LCR/sang', 'Environ 0,6', 'Bas (< 0,4, seuil classique)', 'Normal'],
    ['Lactate du LCR (mmol/L)', 'Bas', '≥ 4 : très spécifique (SSI)', 'Bas'],
   ], 'Ces valeurs sont indicatives. Selon la SSI, 90 % des enfants et adultes ont plus de cellules, plus de protéines et moins de glucose ; un LCR tout à fait normal est très rare.') +
   P('Exemple de l’original : 2 400 cellules/µL dont 92 % de neutrophiles, protéines 2,1 g/L, glucose 1,2 mmol/L pour une glycémie de 6,0 mmol/L. '
     'Le rapport 1,2 / 6,0 vaut 0,20 : profil de méningite bactérienne. '
     'Le seuil de 0,4 est un repère classique dont la source précise reste à vérifier.', 19, 116), 19, 116)))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant fièvre et céphalées, le médecin cherche d’abord l’urgence : purpura, trouble de la conscience, crises ou signes focaux. '
   'Il prélève ensuite des hémocultures et donne l’antibiotique dans l’heure, sans attendre un scanner. '
   'Il pense enfin à l’encéphalite herpétique si le comportement change ou si une crise survient.', 19) +
 F('Diagnostic différentiel des germes (fréquences en exposant rouge, même population : méningites bactériennes communautaires de l’adulte, van de Beek 2004)',
   TAB(['Cause et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Streptococcus pneumoniae' + PR('51 %', 47), 'Otite, sinusite, alcoolisme, splénectomie', 'Gram, culture, antigène'],
    ['Neisseria meningitidis' + PR('37 %', 47), 'Adulte jeune, purpura', 'Gram, PCR, hémocultures'],
    ['Listeria monocytogenes', 'Âge > 50 ans, grossesse, immunosuppression', 'Culture ; amoxicilline à ajouter'],
    ['Encéphalite herpétique', 'Confusion, crises, atteinte temporale', 'PCR HSV du LCR, IRM'],
    ['Hémorragie méningée', 'Céphalée en coup de tonnerre', 'Scanner, ponction'],
   ]) + P('Seuls le pneumocoque et le méningocoque ont une fréquence dans la même population ; les autres causes sont listées sans fréquence.', 47), 47, 19)))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien, souvent mené avec l’entourage, précise le début, l’évolution en heures, les contacts malades, les voyages, les piqûres de tique, les vaccins et l’immunosuppression.', 19, 114) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis combien d’heures ?', 'Évolution rapide : bactérie.', 'Antibiotique immédiat.'],
    ['Le comportement a-t-il changé ? Une crise ?', 'Encéphalite.', 'Aciclovir, IRM.'],
    ['Avez-vous été piqué par une tique ? Êtes-vous vacciné contre la FSME ?', 'Encéphalite à tiques.', 'Recherche d’anticorps IgM et IgG anti-FSME.'],
    ['Avez-vous plus de 50 ans, une grossesse, une immunosuppression ?', 'Listeria.', 'Ajout d’amoxicilline.'],
    ['Avez-vous une otite ou une sinusite ?', 'Pneumocoque.', 'Dexaméthasone, avis d’oto-rhino-laryngologie.'],
    ['Qui vit avec vous ?', 'Contacts du méningocoque.', 'Chimioprophylaxie.'],
   ]), 19, 117) +
 U(f'<b>Drapeaux rouges (144)</b> : {PUR} fébrile, trouble de la conscience, crise convulsive, déficit focal, choc.', 19)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen recherche la raideur de nuque, l’état de conscience (score de Glasgow), un déficit focal et un purpura sur toute la peau. '
   'Une nuque souple, une conscience normale et l’absence de purpura sont l’état normal attendu. '
   'Les signes de Kernig et de Brudzinski sont peu sensibles.', 19, 77) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie', 'Valeur (sensibilité)'], [
    ['Fléchir la nuque du patient couché', 'Menton touche le sternum', 'Raideur douloureuse', '30 %'],
    ['Kernig : étendre la jambe, hanche fléchie', 'Pas de douleur', 'Résistance douloureuse', '5 %'],
    ['Brudzinski : fléchir la nuque', 'Pas de mouvement des jambes', 'Flexion réflexe des hanches', '5 %'],
    ['Inspection de toute la peau, test du verre', 'Pas de purpura', 'Purpura qui ne s’efface pas', 'Non mesurée'],
    ['Score de Glasgow', '15', '< 10 : scanner avant ponction', 'Non applicable'],
   ]) + P('Ces sensibilités viennent d’une étude d’adultes suspects de méningite : un examen normal n’exclut donc pas la méningite.', 77), 77, 19)))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la céphalée, les vomissements et la photophobie. '
   'Les signes physiques sont la fièvre, la raideur de nuque, la confusion et parfois un purpura. '
   '95 % des adultes ont au moins 2 des 4 signes : céphalée, fièvre, raideur de nuque, trouble de la conscience.', 47) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme'], [
    ['Syndrome méningé', 'Céphalée, vomissements, photophobie, raideur', 'Inflammation des méninges'],
    ['Syndrome encéphalitique', 'Confusion, troubles du comportement, crises, déficit', 'Atteinte du cerveau'],
    ['Syndrome d’hypertension intracrânienne', 'Vomissements, somnolence, œdème papillaire', 'Œdème cérébral'],
    ['Syndrome septique avec purpura', 'Choc, purpura extensif', 'Méningocoque dans le sang'],
   ]), 19) +
 F('Signe : raideur de nuque',
   P('Geste : glisser la main sous la nuque et fléchir doucement la tête. '
     'Signe : résistance douloureuse, le menton ne touche pas le sternum. '
     'Mécanisme : l’étirement des méninges inflammées est douloureux, d’où la contraction réflexe des muscles.', 77), 77) +
 F('Signe : purpura et test du verre',
   P('Geste : presser un verre transparent sur la tache. '
     'Signe : la tache reste visible sous le verre. '
     'Mécanisme : le sang est sorti des vaisseaux ; avec fièvre, il faut penser au méningocoque.', 19), 19)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le diagnostic de méningite bactérienne repose sur l’analyse du LCR selon la recommandation ESCMID de 2016, reprise par la SSI. '
   'Un lactate du LCR ≥ 4 mmol/L est très spécifique. '
   'Un examen clinique rassurant ne suffit pas à exclure la méningite.', 40, 19) +
 F('Critères',
   TAB(['Situation', 'Critères', 'Source'], [
    ['Méningite bactérienne', 'LCR : cellules élevées, protéines élevées, glucose bas ; Gram, culture ou PCR positive', 'ESCMID 2016, SSI'],
    ['Encéphalite (consensus 2013)', 'Trouble de la conscience ≥ 24 heures + au moins 2 critères : fièvre ≥ 38 °C, crises, signes focaux, LCR ≥ 5 cellules/µL, IRM ou EEG anormaux', 'International Encephalitis Consortium'],
    ['Encéphalite à tiques', 'Clinique + IgM et IgG sériques ou IgM dans le LCR', 'Définition de cas OFSP'],
    ['Scanner avant ponction', 'Signes focaux, crises, Glasgow < 10', 'SSI'],
   ]) + P('Correction de l’original : le seuil de scanner avant ponction est un Glasgow < 10 chez l’adulte selon la SSI, non < 12.', 19), 40, 78, 114, 19)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Culture du LCR', 'Germe et sensibilité', 'Spécifique ; sensibilité réduite après antibiotique', 'Délai de 24–48 heures'],
    ['Lactate du LCR', 'Origine bactérienne', 'Sensibilité 93 %, spécificité 96 %', 'Sensibilité 49 % après antibiotique'],
    ['PCR multiplex du LCR', 'Identification rapide', 'Sensibilité et spécificité à interpréter (SSI)', 'Faux positifs et négatifs possibles'],
    ['PCR HSV du LCR', 'Encéphalite herpétique', 'Référence actuelle', 'Peut être négative très tôt : répéter'],
   ]), 19, 116) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Hémocultures avant l’antibiotique', 'Toujours'],
    ['Première', 'Ponction lombaire', 'Si possible, même sous aspirine ou plaquettes > 50 G/L (SSI)'],
    ['Première', 'NFS, CRP, créatinine, glucose, coagulation', 'Toujours'],
    ['Avant la ponction, si critères', 'Scanner cérébral', 'Signes focaux, crises, Glasgow < 10 ; antibiotique avant le scanner'],
    ['Seconde', 'IRM cérébrale, EEG', 'Encéphalite'],
   ]), 19) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Les hémocultures précèdent la première dose d’antibiotique.', 'Le glucose sanguin est mesuré en même temps que le LCR.', 'Le scanner ne doit jamais retarder l’antibiotique.']), 19) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Normal', 'Seuil', 'Signification et conduite'], [
    ['Lactate du LCR', 'Bas', '≥ 4 mmol/L', 'Bactérienne très probable'],
    ['Rapport glucose LCR/sang', 'Environ 0,6', '< 0,4', 'Consommation bactérienne'],
    ['Cellules du LCR', '< 5/µL', 'Élevées', 'Méningite ; formule à interpréter'],
    ['Gram du LCR', 'Négatif', 'Diplocoques', 'Pneumocoque ou méningocoque'],
    ['Plaquettes', '150–400 G/L', '< 50 G/L', 'Ponction à discuter'],
   ]), 19) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (PCR positive isolée)', 'Confronter à la culture et à la clinique'],
    ['Résultat négatif mais clinique forte', 'Répéter la ponction ; antibiotique maintenu'],
    ['Résultat limite après antibiotique', 'PCR, lactate moins fiable'],
    ['Grossesse', 'Couvrir Listeria (amoxicilline)'],
    ['Enfant', 'Scanner si Glasgow < 13, signes focaux, œdème papillaire'],
    ['DFGe bas', 'Doses adaptées'],
    ['Allergie au produit iodé, pacemaker ou IRM impossible', 'Scanner sans injection'],
   ]), 19))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Les hémocultures et la ponction lombaire sont les examens clés. '
   'Le scanner n’est fait avant la ponction que si des critères précis sont présents. '
   'L’IRM est l’examen de l’encéphalite.', 19, 78) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une méningite bactérienne est suspectée, alors le médecin prélève des hémocultures et donne antibiotique et dexaméthasone dans l’heure. '
   'Si un critère de scanner est présent, alors il donne l’antibiotique avant le scanner. '
   'Si une encéphalite est possible, alors il ajoute l’aciclovir IV.', 19, 5) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Purpura fébrile', 'Antibiotique immédiat, même avant l’hôpital ; 144', 'Soins intensifs'],
    ['Adulte de 18–50 ans', 'Ceftriaxone 2 g toutes les 12 heures', 'Adapter au germe'],
    ['Plus de 50 ans, grossesse, immunosuppression', 'Ajouter amoxicilline 2 g toutes les 4 heures', 'Listeria'],
    ['Pneumocoque résistant possible', 'Ajouter vancomycine ou rifampicine', 'Concentration de vancomycine 15–20 µg/mL'],
    ['Pneumocoque exclu', 'Arrêter la dexaméthasone', '—'],
   ]) + P('Correction de l’original : la vancomycine n’est pas systématique ; la SSI l’ajoute seulement si un pneumocoque résistant est possible.', 19), 19)))
MED = F('Fiches médicamenteuses (posologies SSI et AIPS)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Ceftriaxone, Rocephin® (céphalosporine)', 'Bloque la paroi ; bonne diffusion dans le LCR enflammé', '2 g toutes les 12 heures IV', 'Allergie ; ne pas mélanger au calcium chez le nouveau-né'],
   ['Amoxicilline IV (pénicilline)', 'Couvre Listeria', '2 g toutes les 4 heures IV', 'Allergie aux pénicillines'],
   ['Vancomycine (glycopeptide)', 'Bloque la paroi des bactéries Gram positif', '15 mg/kg toutes les 12 heures (SSI) ; concentration cible 15–20 µg/mL', 'Atteinte rénale, surdité ; adapter au DFGe'],
   ['Dexaméthasone (corticoïde)', 'Réduit l’inflammation des méninges', '10 mg toutes les 6 heures pendant 4 jours, avec ou jusqu’à 4 heures après la première dose d’antibiotique', 'Hyperglycémie ; arrêt si pas de pneumocoque'],
   ['Aciclovir IV (antiviral)', 'Bloque la réplication du virus herpès', '10 mg/kg toutes les 8 heures, 10 jours (AIPS)', 'Atteinte rénale : hydrater, adapter au DFGe'],
  ]) + P('Correction de l’original : la dexaméthasone est 10 mg toutes les 6 heures pendant 4 jours, non une dose unique de 10 mg. '
         'La Cochrane montre une baisse de la surdité sévère (risque relatif 0,67) et de la mortalité des méningites à pneumocoque (0,84).', 19, 45, 5), 19, 5, 45)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge donne l’antibiotique dans l’heure, parce que chaque heure de retard aggrave le pronostic. '
   'Elle ajoute la dexaméthasone pour limiter l’inflammation et les séquelles. '
   'Le but est la survie sans séquelle : dans l’étude néerlandaise, la dexaméthasone a réduit la mortalité de 30 % à 20 %.', 19, 46) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans la forme compliquée (purpura fulminans, coma, choc), le but est de traiter dans la première heure et de soutenir les organes. '
     'Dans la méningite virale non compliquée, le but est de soulager les symptômes après avoir exclu une cause bactérienne.', 19), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures',
     OL(['<b>A. Urgence</b> : 144 ; hémocultures ; ceftriaxone ± amoxicilline et dexaméthasone dans l’heure ; scanner seulement si critères, après l’antibiotique.',
         '<b>B. Encéphalite</b> : aciclovir IV 10 mg/kg toutes les 8 heures dès la suspicion ; IRM, EEG.',
         '<b>C. Méningite virale non compliquée</b> : mesures générales (antalgiques, hydratation, repos) une fois la cause bactérienne exclue.',
         '<b>D. Entourage</b> : chimioprophylaxie des contacts étroits d’un méningocoque.']), 19, 117) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail de plusieurs semaines est fréquent ; la reprise dépend des séquelles (fatigue, troubles cognitifs).',
            'La conduite automobile est interdite après une crise convulsive et tant que des troubles cognitifs persistent ; l’aptitude est réévaluée selon les règles de la médecine du trafic.',
            'Une méningite contractée au laboratoire relève de la LAA ; une surdité ou un déficit durable peut ouvrir un droit à la LAI.'), 19) +
   F('Traitements non médicamenteux',
     UL(['Isolement de type gouttelettes pendant 24 heures de traitement en cas de méningocoque.', 'Surveillance neurologique rapprochée.', 'Audiogramme après une méningite bactérienne.']), 19) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Amoxicilline pour Listeria ; chimioprophylaxie par ceftriaxone 250 mg IM'],
      ['Enfant', 'Ceftriaxone 100 mg/kg/j ; dexaméthasone 0,15 mg/kg toutes les 6 heures si enfant < 5 ans non vacciné contre Haemophilus'],
      ['Sujet âgé', 'Amoxicilline dès 50 ans'],
      ['Insuffisance hépatique', 'Adapter les doses selon la SSI'],
      ['Insuffisance rénale (DFGe bas)', 'Adapter aciclovir et vancomycine'],
     ]), 19, 117), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Score de Glasgow, pupilles', 'Toutes les heures au début', 'Baisse : scanner, soins intensifs'],
    ['Température, pression', 'Continu', 'Choc : soins intensifs'],
    ['Créatinine', 'Chaque jour sous aciclovir ou vancomycine', 'Hausse : adapter'],
    ['Audition', 'Avant la sortie', 'Surdité : avis d’oto-rhino-laryngologie rapide'],
   ]) + H4('Critères de sortie, un par un') + OL(['Apyrexie stable.', 'Conscience normale.', 'Traitement complet ou relais organisé.', 'Contacts traités, audition contrôlée.']), 19) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La mortalité de la méningite bactérienne de l’adulte est de 21 %, 30 % pour le pneumocoque. '
     'L’aciclovir a fait passer la mortalité de l’encéphalite herpétique de 54 % à 28 %. '
     'La recherche 2026 porte sur la PCR multiplex et sur des traitements de l’inflammation cérébrale.', 47, 115), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur les vaccins contre le pneumocoque, le méningocoque, Haemophilus influenzae de type b et la FSME. '
   'La recommandation suisse 2026 propose la vaccination contre la FSME dès 3 ans pour les personnes vivant ou séjournant dans une zone à risque, soit toute la Suisse sauf le Tessin. '
   'La chimioprophylaxie des contacts du méningocoque est donnée dans les 24 heures.', 26, 117) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Vaccins (Plan de vaccination suisse) : pneumocoque, méningocoques B et ACWY, Haemophilus influenzae de type b, FSME'],
    ['Secondaire', 'Chimioprophylaxie : ciprofloxacine 500 mg dose unique, ou rifampicine 600 mg toutes les 12 heures pendant 2 jours'],
    ['Tertiaire', 'Dépistage de la surdité, rééducation'],
   ]), 26, 117)))
PTS.append(POINT(13, 'Points clés',
 P('Une suspicion de méningite bactérienne impose hémocultures puis antibiotique dans l’heure. '
   'Le scanner avant la ponction n’est fait que si signes focaux, crises ou Glasgow < 10, et jamais avant l’antibiotique. '
   'La dexaméthasone est donnée avec l’antibiotique. '
   'Confusion ou crise fébrile : aciclovir sans attendre.', 19, 5)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Attendre le scanner pour donner l’antibiotique.', 'Non : antibiotique d’abord.'],
  ['Exclure une méningite parce que Kernig est négatif.', 'Non : sensibilité 5 %.'],
  ['Oublier l’amoxicilline après 50 ans.', 'Ajouter amoxicilline (Listeria).'],
  ['Poursuivre la dexaméthasone si le pneumocoque est exclu.', 'Non : l’arrêter.'],
  ['Ne pas traiter les contacts d’un méningocoque.', 'Chimioprophylaxie dans les 24 heures.'],
 ]) + P('Ces pièges entraînent le raisonnement ; ils ne sont pas des questions officielles de l’examen fédéral.', 19, 77)))
CTX = {'_prefixe': 'Dans une méningite ou une encéphalite',
 'pl': 'La ponction lombaire est faite si possible, même sous aspirine ou avec des plaquettes > 50 G/L.',
 'lcr': 'Le LCR bactérien montre beaucoup de neutrophiles, des protéines élevées et un glucose bas.',
 'hemoc': 'Les hémocultures sont prélevées avant la première dose d’antibiotique.',
 'nfs': 'La NFS montre souvent une hausse des neutrophiles ; une baisse des plaquettes est de mauvais pronostic.',
 'crp': 'La CRP élevée oriente vers une cause bactérienne sans la prouver.',
 'pct': 'La procalcitonine élevée oriente vers une cause bactérienne.',
 'gly': 'La glycémie est mesurée en même temps que le LCR pour calculer le rapport.',
 'creat': 'La créatinine guide les doses d’aciclovir et de vancomycine.',
 'coag': 'La coagulation est vérifiée avant la ponction ; un purpura fulminans donne une coagulation intravasculaire.',
 'tdm': 'Le scanner cérébral avant ponction est réservé aux signes focaux, crises ou Glasgow < 10, après l’antibiotique.',
 'irm': 'L’IRM montre l’atteinte temporale de l’encéphalite herpétique.',
 'eeg': 'L’EEG montre des anomalies temporales dans l’encéphalite herpétique.',
 'lact': 'Le lactate du LCR ≥ 4 mmol/L est très spécifique d’une méningite bactérienne.',
 'pcr': 'La PCR du LCR identifie rapidement le germe ; ses résultats se discutent avec la clinique.',
 'sero': 'La sérologie FSME (IgM et IgG) confirme une encéphalite à tiques.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
