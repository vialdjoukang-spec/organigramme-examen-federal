# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.4 · Infections de la peau et des tissus mous (LOT 6, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('dx4')
M = meta('dx4', 'DX.4', 'Infections de la peau et des tissus mous', 'Infections de la peau et des tissus mous fébriles : érysipèle, cellulite, abcès et fasciite nécrosante',
         'LOT_006_DX4_Infections_peau_tissus_mous_AUDITÉ.html')
ERY = T('érysipèle', 'L’érysipèle est une infection du derme superficiel, à bords nets, due surtout au streptocoque du groupe A.')
CEL = T('cellulite', 'La cellulite infectieuse atteint le derme profond et l’hypoderme ; ses bords sont flous.')
FN = T('fasciite nécrosante', 'La fasciite nécrosante est une infection qui détruit l’enveloppe des muscles (fascia) ; elle menace la vie en quelques heures.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Les infections de la peau et des tissus mous (ICTM) vont de l’{ERY} et de la {CEL}, non purulents, aux abcès et furoncles, purulents. '
   f'La {FN} en est la forme profonde et vitale. '
   'Le chiffre « 8 % des motifs fébriles aigus » de l’original n’a été retrouvé dans aucune source et il est retiré.', 17, 18, 99) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Tissu atteint', 'Germe principal (SSI)', 'À ne pas confondre avec'], [
    ['Érysipèle', 'Derme superficiel, bords nets', 'Streptocoque β-hémolytique du groupe A (parfois C ou G)', 'Dermite de stase'],
    ['Cellulite', 'Derme profond et hypoderme, bords flous', 'Streptocoques, Staphylococcus aureus', 'Thrombose veineuse profonde'],
    ['Abcès, furoncle, anthrax', 'Collection de pus', 'Staphylococcus aureus', 'Kyste épidermoïde infecté'],
    ['Fasciite nécrosante', 'Fascia, muscles', 'Souvent plusieurs germes ; Streptococcus pyogenes après traumatisme', 'Cellulite simple'],
   ]), 17, 18, 113)))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, une série bernoise de 75 fasciites nécrosantes (2010–2022) montre une atteinte des membres inférieurs dans 52 % des cas et une mortalité hospitalière de 27 %. '
   'Au niveau international, l’incidence de la cellulite de jambe est de 199 pour 100 000 personnes-années et augmente de 43,8 % par décennie d’âge. '
   'Le facteur de risque majeur est la rupture de la barrière cutanée, en particulier l’intertrigo entre les orteils.', 113, 108, 112) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Incidence de la cellulite de jambe' + PR('199/100 000', 108), 'Hausse avec l’âge, pas de différence entre sexes', 'Population générale, Minnesota'],
    ['Mortalité de la fasciite nécrosante' + PR('27 %', 113), '99 % des patients avaient une comorbidité', 'Hôpital de l’Île, Berne'],
    ['Récidive de cellulite à 2 ans' + PR('16,7 %', 109), 'Plus fréquente si atteinte du tibia, cancer, dermatose', 'Cohorte de population'],
    ['Intertrigo interorteil', 'Risque attribuable 61 %', 'Étude cas-témoins française'],
    ['Lymphœdème', 'Rapport de cotes 71,2', 'Même étude'],
   ], 'Le pronostic de l’érysipèle est bon ; la mortalité dépend surtout de la fasciite nécrosante, de l’âge et des comorbidités.'), 108, 109, 112, 113)))
PTS.append(POINT(3, 'Physiopathologie',
 P('Les bactéries entrent par une brèche de la peau : intertrigo, plaie, ulcère ou piqûre. '
   'Le streptocoque diffuse dans le derme grâce à ses enzymes ; Staphylococcus aureus, lui, forme une collection de pus. '
   'Dans la fasciite nécrosante, les toxines et la thrombose des petits vaisseaux détruisent le fascia, ce qui explique la douleur disproportionnée puis l’insensibilité de la peau.', 17, 18) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Épiderme, derme, hypoderme, fascia, muscle.'],
    ['Physiologie', 'La peau intacte et le drainage lymphatique protègent.'],
    ['Physiopathologie', 'Brèche cutanée, lymphœdème : la bactérie s’installe.'],
    ['Clinique', 'Plaque rouge, chaude, fièvre ; douleur disproportionnée si atteinte profonde.'],
    ['Examens', 'Clinique d’abord ; imagerie si doute sur une atteinte profonde.'],
    ['Traitement', 'Pénicilline pour l’érysipèle ; drainage pour l’abcès ; chirurgie pour la fasciite.'],
   ]), 17, 18) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Diffusion streptococcique dans le derme', 'Clinique', 'Pénicilline ou amoxicilline'],
    ['Collection de pus', 'Palpation, échographie', 'Incision et drainage'],
    ['Nécrose du fascia', 'Exploration chirurgicale, scanner', 'Débridement en urgence'],
    ['Toxines streptococciques', 'Choc, défaillance d’organes', 'Clindamycine, immunoglobulines IV dans le choc toxique'],
   ]), 17) +
 F('Score LRINEC (Laboratory Risk Indicator for Necrotizing Fasciitis) : calcul et exemple corrigé',
   TAB(['Paramètre', 'Points'], [
    ['CRP (mg/L)', '< 150 : 0 ; ≥ 150 : 4'],
    ['Leucocytes (G/L)', '< 15 : 0 ; 15–25 : 1 ; > 25 : 2'],
    ['Hémoglobine (g/L)', '> 135 : 0 ; 110–135 : 1 ; < 110 : 2'],
    ['Sodium (mmol/L)', '≥ 135 : 0 ; < 135 : 2'],
    ['Créatinine (µmol/L)', '≤ 141 : 0 ; > 141 : 2'],
    ['Glucose (mmol/L)', '≤ 10 : 0 ; > 10 : 1'],
   ], 'Total de 0 à 13 ; score ≥ 6 : fasciite à rechercher activement (Wong 2004).') +
   P('Exemple de l’original : CRP 180 mg/L (4 points), leucocytes 22 G/L, sodium 130 mmol/L (2 points). '
     'Correction : 22 G/L vaut 1 point et non 2, donc le total est 7 et non 8. '
     'Dans une méta-analyse, un score ≥ 6 n’a qu’une sensibilité de 68,2 % : un score bas n’exclut pas la fasciite.', 74, 75), 74, 75)))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin élimine d’abord l’urgence vitale : fasciite nécrosante ou choc toxique. '
   'Il distingue ensuite une infection purulente, à drainer, d’une infection non purulente, à traiter par antibiotique. '
   'Il cherche enfin une fausse cellulite : près d’un patient sur trois adressé pour cellulite de jambe a un autre diagnostic.', 17, 18, 111) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même population : patients hospitalisés pour « cellulite de jambe », Raff 2017)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Vraie cellulite ou érysipèle' + PR('69,5 %', 111), 'Atteinte d’un seul côté, fièvre, leucocytose', 'Clinique ; score ALT-70'],
    ['Pseudo-cellulite' + PR('30,5 %', 111), 'Atteinte des deux jambes, pas de fièvre', 'Clinique, avis dermatologique'],
    ['Dermite de stase', 'Bilatérale, chronique, varices', 'Clinique'],
    ['Thrombose veineuse profonde', 'Œdème du mollet, facteurs de risque', 'Échographie Doppler'],
    ['Fasciite nécrosante', 'Douleur disproportionnée, bulles, choc', 'Exploration chirurgicale'],
   ]) + P('Les fréquences propres de la dermite de stase, de la thrombose et de la fasciite dans cette population ne sont pas données dans le résumé de l’étude.', 111), 111, 17)))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien recherche une porte d’entrée, la vitesse d’extension, l’intensité de la douleur, les épisodes antérieurs et les comorbidités (diabète, insuffisance veineuse, lymphœdème).', 17, 112) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['La douleur est-elle plus forte que ce que l’on voit ?', 'Fasciite nécrosante.', 'Avis chirurgical immédiat.'],
    ['La rougeur s’étend-elle d’heure en heure ?', 'Infection agressive.', 'Hospitalisation, IV.'],
    ['Avez-vous une plaie, une morsure, une piqûre ?', 'Porte d’entrée, germe.', 'Morsure : amoxicilline/acide clavulanique, hémocultures.'],
    ['Est-ce déjà arrivé ?', 'Récidive.', 'Prophylaxie si ≥ 3–4 épisodes par an.'],
    ['Avez-vous un traitement immunosuppresseur ?', 'Germes inhabituels.', 'Hémocultures, prélèvement.'],
    ['Avez-vous des démangeaisons entre les orteils ?', 'Intertrigo.', 'Traitement antifongique.'],
   ]), 17, 112) +
 U('<b>Drapeaux rouges (144 ou urgences)</b> : douleur disproportionnée, bulles violacées, nécrose, crépitation, peau insensible, extension rapide, confusion, hypotension.', 17)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen inspecte la plaque, ses bords, la porte d’entrée et les ganglions. '
   'Il palpe la chaleur, la fluctuation (pus), la crépitation (gaz) et teste la sensibilité. '
   'Le médecin trace les bords au feutre pour suivre l’évolution.', 17, 18) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Inspection des bords', 'Peau normale', 'Bords nets : érysipèle ; flous : cellulite'],
    ['Palpation', 'Souple', 'Fluctuation : abcès ; œdème dur : atteinte profonde'],
    ['Crépitation', 'Absente', 'Gaz : fasciite à germes anaérobies'],
    ['Sensibilité au toucher', 'Conservée', 'Peau insensible : nécrose des nerfs'],
    ['Espaces entre les orteils', 'Secs', 'Intertrigo : porte d’entrée'],
   ]) + P('La valeur de l’examen clinique seul pour la fasciite est limitée : dans la méta-analyse de Fernando, aucun signe isolé n’a une sensibilité suffisante ; le scanner atteint 88,5 %.', 75), 17, 75)))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la douleur, la chaleur locale et le malaise. '
   'Les signes physiques sont la plaque rouge et chaude, l’adénopathie, la fièvre et parfois une traînée lymphatique. '
   'Les signes de gravité traduisent une atteinte profonde.', 17) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme'], [
    ['Syndrome inflammatoire local', 'Plaque rouge, chaude, douloureuse, œdème', 'Infection du derme'],
    ['Syndrome septique', 'Fièvre, tachycardie, hypotension', 'Réponse générale à l’infection'],
    ['Syndrome de choc toxique streptococcique', 'Choc, défaillance rénale, éruption', 'Toxines du streptocoque'],
    ['Syndrome de nécrose', 'Bulles, peau grise, insensible', 'Thrombose et destruction du fascia'],
   ]), 17) +
 F('Signe : bourrelet périphérique de l’érysipèle',
   P('Geste : passer la pulpe des doigts du centre vers la peau saine. '
     'Signe : on sent une marche nette entre peau atteinte et peau saine. '
     'Mécanisme : l’infection et l’œdème restent dans le derme superficiel, bien limités.', 17), 17) +
 F('Signe : fluctuation d’un abcès',
   P('Geste : appuyer avec deux doigts de part et d’autre de la tuméfaction. '
     'Signe : une onde liquide se transmet d’un doigt à l’autre. '
     'Mécanisme : une poche de pus s’est formée ; elle doit être drainée, car l’antibiotique y pénètre mal.', 18), 18) +
 F('Signe : crépitation sous-cutanée',
   P('Geste : palper doucement la peau autour de la lésion. '
     'Signe : sensation de neige qui craque sous les doigts. '
     'Mécanisme : des germes anaérobies produisent du gaz dans les tissus ; c’est un signe de fasciite.', 17), 17) +
 F('Signe : hypoesthésie de la peau',
   P('Geste : toucher la peau avec un coton ou une pointe mousse, en comparant avec le côté sain. '
     'Signe : le patient sent moins ou ne sent plus, alors que la douleur profonde était intense. '
     'Mécanisme : la thrombose des vaisseaux détruit les petits nerfs cutanés ; c’est un signe d’atteinte profonde.', 17), 17) +
 F('Signe : traînée de lymphangite et adénopathie',
   P('Geste : suivre la peau du foyer vers l’aine et palper les ganglions inguinaux. '
     'Signe : une traînée rouge remonte vers un ganglion gonflé et douloureux. '
     'Mécanisme : les bactéries diffusent par les vaisseaux lymphatiques jusqu’au ganglion de drainage.', 17), 17)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le diagnostic d’érysipèle et de cellulite est clinique selon la recommandation SSI et les critères IDSA de 2014. '
   'La fasciite nécrosante est confirmée par l’exploration chirurgicale. '
   'Un LRINEC < 6 ne suffit pas pour l’exclure : la clinique prime.', 17, 73, 75) +
 F('Critères d’orientation',
   TAB(['Situation', 'Critères', 'Source'], [
    ['Érysipèle', 'Plaque rouge à bords nets, chaude, fièvre, porte d’entrée', 'SSI'],
    ['Fasciite nécrosante', 'Douleur disproportionnée, œdème sous tension, bulles, nécrose, crépitation, toxicité générale', 'SSI'],
    ['Antibiotique après drainage d’un abcès', 'Signes systémiques : température > 38 °C, fréquence cardiaque > 90/min, leucocytes > 12 G/L', 'SSI'],
    ['Score ALT-70', '0–2 points : pseudo-cellulite probable ; ≥ 5 points : cellulite probable', 'Raff 2017'],
    ['LRINEC', '≥ 6 points : fasciite à rechercher', 'Wong 2004'],
   ]), 17, 18, 111, 74)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Exploration chirurgicale', 'Fasciite nécrosante', 'Référence', 'Invasive, ne doit pas être retardée'],
    ['Scanner des parties molles', 'Gaz, collection, atteinte du fascia', 'Sensibilité 88,5 %, spécificité 93,3 %', 'Ne doit pas retarder la chirurgie'],
    ['LRINEC ≥ 6', 'Probabilité de fasciite', 'Sensibilité 68,2 %, spécificité 84,8 %', 'Ne permet pas d’exclure'],
   ]), 75) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Aucun', 'Pas d’examen', 'Érysipèle typique sans gravité'],
    ['Première', 'NFS, CRP, créatinine, glucose, sodium', 'Hospitalisation, calcul du LRINEC'],
    ['Première', 'Hémocultures', 'Immunosuppression, neutropénie, morsure, fasciite'],
    ['Première', 'Culture du pus', 'Abcès modéré à sévère ou récidivant'],
    ['Seconde', 'Échographie', 'Collection à drainer, thrombose veineuse'],
    ['Seconde', 'Scanner ou IRM', 'Doute sur une fasciite ou une ostéomyélite'],
   ]), 17, 18) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Les hémocultures ne sont pas faites en routine dans l’érysipèle (SSI).', 'Le pus est prélevé lors du drainage, avant l’antibiotique si possible.', 'L’imagerie ne doit jamais retarder l’avis chirurgical.']), 17, 18) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Normal', 'Seuil', 'Signification et conduite'], [
    ['CRP', '< 5 mg/L', '≥ 150 mg/L', '4 points LRINEC ; ne remplace pas la clinique'],
    ['Leucocytes', '4–10 G/L', '> 12 G/L', 'Réponse systémique'],
    ['Sodium', '135–145 mmol/L', '< 135 mmol/L', '2 points LRINEC'],
    ['Créatinine', '< 100 µmol/L environ', '> 141 µmol/L', '2 points LRINEC ; atteinte rénale'],
    ['Hémocultures', 'Négatives', 'Positives', 'Infection invasive : adapter l’antibiotique'],
   ]), 74, 18) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (staphylocoque de surface)', 'Interpréter avec la clinique'],
    ['Résultat négatif mais clinique inquiétante', 'Avis chirurgical malgré tout'],
    ['Résultat limite (LRINEC 6–7)', 'Imagerie et réévaluation rapprochée'],
    ['Grossesse', 'IRM sans gadolinium ou échographie'],
    ['Enfant', 'Échographie en premier'],
    ['DFGe bas', 'Scanner sans injection ou IRM'],
    ['Allergie au produit iodé, pacemaker', 'IRM ou scanner sans injection selon le cas'],
   ]), 17))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Un érysipèle typique ne demande aucun examen. '
   'La biologie et les hémocultures sont réservées aux formes sévères et aux terrains particuliers. '
   'L’imagerie aide en cas de doute, sans retarder la chirurgie.', 17) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si la douleur est disproportionnée ou s’il y a bulles, nécrose ou choc, alors le médecin appelle le chirurgien et débute pipéracilline/tazobactam plus clindamycine. '
   'Si une collection de pus est présente, alors il l’incise et la draine. '
   'Si l’érysipèle est simple, alors il prescrit amoxicilline ou pénicilline pendant 5 jours.', 17, 18) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Suspicion de fasciite', 'Chirurgie urgente, antibiotiques IV larges', 'Réexploration au bloc'],
    ['Abcès', 'Incision et drainage ; antibiotique si signes systémiques, immunosuppression, âges extrêmes, abcès multiples', 'Culture du pus'],
    ['Érysipèle sans gravité', 'Amoxicilline per os, 5 jours', 'Contrôle des bords à 48 heures'],
    ['Pas d’amélioration à 48–72 heures', 'Chercher abcès, fasciite, autre diagnostic', 'Échographie, avis'],
    ['≥ 3–4 épisodes par an', 'Prophylaxie par amoxicilline ou benzathine-pénicilline', 'Traiter lymphœdème et intertrigo'],
   ]), 17, 18)))
MED = F('Fiches médicamenteuses (posologies SSI et AIPS)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Amoxicilline, Clamoxyl® (pénicilline)', 'Bloque la paroi bactérienne ; temps-dépendant', 'Érysipèle léger : 500 mg toutes les 12 heures per os selon la SSI, 5 jours', 'Allergie aux pénicillines (CI) ; éruption'],
   ['Pénicilline G (pénicilline)', 'Même mécanisme ; demi-vie courte', '2–4 millions UI toutes les 4–6 heures IV', 'Allergie (CI) ; convulsions à forte dose si insuffisance rénale'],
   ['Céfazoline (céphalosporine)', 'Bloque la paroi', '1–2 g toutes les 8 heures IV', 'Allergie croisée rare ; adapter au DFGe'],
   ['Clindamycine, Dalacin® C (lincosamide)', 'Bloque la synthèse protéique et la production de toxines', '300–450 mg toutes les 6–8 heures per os ; 600–900 mg toutes les 8 heures IV', 'Colite à C. difficile ; diarrhée'],
   ['Amoxicilline/acide clavulanique, Augmentin® (pénicilline et inhibiteur)', 'Élargit le spectre aux germes producteurs de bêta-lactamase', '875/125 mg toutes les 12 heures per os ; 2,2 g toutes les 8 heures IV', 'Diarrhée, hépatite cholestatique'],
   ['Pipéracilline/tazobactam (pénicilline large et inhibiteur)', 'Spectre large, anaérobies compris', '4,5 g toutes les 8 heures IV', 'Allergie ; adapter au DFGe'],
  ]) + P('Correction de l’original : la SSI propose amoxicilline 500 mg toutes les 12 heures dans l’érysipèle léger, alors que l’original donnait 1 g trois fois par jour. '
         'Cette dose SSI est plus basse que celles d’autres recommandations et reste à faire vérifier. '
         'La SSI écrit « 4.5 mg » pour la pipéracilline/tazobactam ; il s’agit de 4,5 g.', 17, 18, 4), 17, 18, 4)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge sauve d’abord la vie et le membre dans la fasciite, par la chirurgie, parce que l’antibiotique seul ne pénètre pas les tissus morts. '
   'Elle draine ensuite les abcès et traite les infections non purulentes par une pénicilline. '
   'Le but chiffré est une fièvre disparue et une plaque qui régresse en 48–72 heures.', 17, 18) +
 F('11.A Buts : forme compliquée (fasciite, urgence), puis forme non compliquée',
   P('Dans la forme compliquée, la fasciite nécrosante, le but est un débridement chirurgical dans les premières heures. '
     'Dans l’érysipèle, le but est la guérison en 5 jours et la prévention des récidives.', 17), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures',
     OL(['<b>A. Urgence (fasciite, choc)</b> : 144 ; pipéracilline/tazobactam 4,5 g toutes les 8 heures plus clindamycine 600–900 mg toutes les 8 heures IV ; débridement ; immunoglobulines IV si choc toxique.',
         '<b>B. Abcès</b> : incision et drainage ; antibiotique seulement si critères SSI.',
         '<b>C. Érysipèle ou cellulite non compliqués</b> : mesures générales (repos, surélévation, soins de la porte d’entrée) puis amoxicilline per os ou pénicilline, céfazoline IV ; 5 jours ; repos, surélévation, thromboprophylaxie si alitement.',
         '<b>D. Récidives</b> : traiter œdème, eczéma et intertrigo ; prophylaxie si ≥ 3–4 épisodes par an.']), 17, 18) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail de quelques jours est fréquent pour permettre repos et surélévation de la jambe.',
            'La conduite automobile est déconseillée pendant la phase aiguë douloureuse ou après une chirurgie du membre.',
            'Une plaie de travail infectée relève de la LAA ; une amputation après fasciite peut ouvrir un droit à la LAI.'), 17) +
   F('Traitements non médicamenteux',
     UL(['Surélévation du membre et repos.', 'Contention veineuse une fois l’infection contrôlée.', 'Soins de la porte d’entrée et des pieds.']), 17) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Pénicillines et céfazoline utilisables'],
      ['Enfant', 'Doses selon le poids'],
      ['Sujet âgé', 'Seuil d’hospitalisation plus bas ; chercher une fausse cellulite'],
      ['Insuffisance hépatique', 'Prudence avec amoxicilline/acide clavulanique'],
      ['Insuffisance rénale (DFGe bas)', 'Espacer pénicilline, céfazoline, pipéracilline'],
      ['Allergie aux pénicillines', 'Clindamycine'],
     ]), 17, 4), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Bords tracés au feutre', 'Toutes les 12–24 heures', 'Extension malgré antibiotique : chercher une collection ou une fasciite'],
    ['Température, pression, pouls', 'Plusieurs fois par jour', 'Hypotension : soins intensifs'],
    ['CRP, créatinine', '48–72 heures', 'Hausse : réévaluer'],
   ]) + H4('Critères de sortie, un par un') + OL(['Plus de fièvre depuis 24 heures.', 'Plaque en régression.', 'Relais per os possible.', 'Porte d’entrée traitée.']), 17) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('L’érysipèle guérit en général ; la récidive touche 16,7 % des patients en 2 ans. '
     'La fasciite nécrosante reste grave, avec 27 % de mortalité hospitalière dans la série bernoise. '
     'La recherche porte sur des vaccins contre le streptocoque du groupe A, encore expérimentaux.', 109, 113), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur les soins des pieds, le traitement de l’intertrigo et des plaies. '
   'La recommandation suisse de la SSI demande de traiter œdème, eczéma et mycose des pieds pour éviter les récidives. '
   'La pénicilline au long cours réduit les récidives de 37 % à 22 %.', 17, 110) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Soins de la peau, traitement de l’intertrigo, vaccination antitétanique à jour en cas de plaie'],
    ['Secondaire', 'Diagnostic précoce de la fasciite ; drainage des abcès'],
    ['Tertiaire', 'Prophylaxie antibiotique des récidives, contention du lymphœdème'],
   ]), 17, 110, 26)))
PTS.append(POINT(13, 'Points clés',
 P('Une douleur disproportionnée par rapport à la peau fait suspecter une fasciite nécrosante et impose un chirurgien en urgence. '
   'Un abcès se draine ; un érysipèle se traite par une pénicilline pendant 5 jours. '
   'Un score LRINEC bas n’exclut pas une fasciite. '
   'Une rougeur des deux jambes sans fièvre est rarement une infection.', 17, 18, 75, 111)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Attendre le scanner avant d’appeler le chirurgien.', 'Non : l’imagerie ne doit pas retarder la chirurgie.'],
  ['Exclure une fasciite sur un LRINEC < 6.', 'Non : sensibilité 68,2 %.'],
  ['Traiter un abcès par antibiotique seul.', 'Non : incision et drainage.'],
  ['Appeler érysipèle une dermite de stase bilatérale.', 'Non : l’érysipèle bilatéral est exceptionnel.'],
  ['Faire des hémocultures dans chaque érysipèle.', 'Non : seulement sur terrain particulier.'],
 ]) + P('Ces pièges entraînent le raisonnement ; ils ne sont pas des questions officielles de l’examen fédéral.', 17, 75)))
CTX = {'_prefixe': 'Dans une infection de la peau et des tissus mous',
 'nfs': 'Les leucocytes entrent dans le LRINEC et dans les signes systémiques.',
 'crp': 'Une CRP ≥ 150 mg/L vaut 4 points du LRINEC.',
 'creat': 'Une créatinine > 141 µmol/L vaut 2 points du LRINEC et guide les doses.',
 'iono': 'Un sodium < 135 mmol/L vaut 2 points du LRINEC.',
 'gly': 'Un glucose > 10 mmol/L vaut 1 point du LRINEC.',
 'hemoc': 'Les hémocultures sont réservées à l’immunosuppression, la neutropénie, la morsure et la fasciite.',
 'pct': 'La procalcitonine n’est pas recommandée pour le diagnostic de l’érysipèle.',
 'lact': 'Un lactate élevé oriente vers un sepsis ou une nécrose.',
 'tdm': 'Le scanner cherche du gaz et une atteinte du fascia, sans retarder la chirurgie.',
 'irm': 'L’IRM précise l’atteinte profonde ou une ostéomyélite.',
 'echo': 'L’échographie cherche une collection à drainer.',
 'doppler': 'L’échographie Doppler exclut une thrombose veineuse profonde.',
 'rx': 'La radiographie montre parfois du gaz dans les tissus.',
 'ck': 'Les CK élevées évoquent une atteinte musculaire.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
