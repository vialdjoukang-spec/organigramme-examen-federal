#!/usr/bin/env python3
"""SSI guidelines (ssi.guidelines.ch, public reader). usage: ssi.py search <q> | ssi.py get <id> [lang]"""
import json,sys,re,html,urllib.request,os
B='https://ssi.guidelines.ch/api/reader/query/'
def post(ep,body):
    r=urllib.request.Request(B+ep,data=json.dumps(body).encode(),headers={'Content-Type':'application/json','User-Agent':'curl/8.0'})
    return json.load(urllib.request.urlopen(r,timeout=30))
def txt(s):
    s=s.replace('sanitized:','');s=re.sub(r'<(li|p|h\d|tr|br)[^>]*>','\n',s);s=re.sub(r'<t[dh][^>]*>',' | ',s)
    return re.sub(r'\n\s*\n+','\n',html.unescape(re.sub(r'<[^>]+>','',s))).strip()
if sys.argv[1]=='search':
    d=post('search',{"query":sys.argv[2],"collections":[],"metadata":None,"from":0,"size":15})
    for h in d['filteredResults']: print(h['guidelineId'],h['languages'],h['title'],'|',h['collectionSpaceTitle'])
else:
    i=sys.argv[2];l=sys.argv[3] if len(sys.argv)>3 else 'fr'
    d=post('guideline',{"id":i,"language":l})
    out=f"TITLE {d['title']}\nURL https://ssi.guidelines.ch/guideline/{i}/{l}\nVERSION {d.get('version')}\n"
    for x in d['details']: out+=f"\n### {x['title']}\n{txt(x.get('content',''))}\n"
    os.makedirs('verif/ssi',exist_ok=True);open(f'verif/ssi/{i}_{l}.txt','w').write(out);print(out)
