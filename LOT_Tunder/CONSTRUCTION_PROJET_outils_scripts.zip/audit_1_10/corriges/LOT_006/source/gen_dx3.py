# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.3 · Gastro-entérites infectieuses fébriles (LOT 6, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot6_commun import *
POINT = mkPOINT('dx3')
M = meta('dx3', 'DX.3', 'Gastro-entérites infectieuses', 'Gastro-entérites infectieuses aiguës fébriles : virales, bactériennes, toxiniques et Clostridioides difficile',
         'LOT_006_DX3_Gastroenterites_infectieuses_AUDITÉ.html')
DYS = T('dysenterie', 'La dysenterie est une diarrhée avec du sang et du mucus, parfois avec fièvre et ténesme ; elle signe une atteinte invasive du côlon.')
TEN = T('ténesme', 'Le ténesme est une envie douloureuse et répétée d’aller à selle, sans résultat, due à l’inflammation du rectum.')
SHU = T('syndrome hémolytique et urémique (SHU)', 'Le SHU associe anémie par destruction des globules rouges, chute des plaquettes et insuffisance rénale ; il complique surtout les E. coli producteurs de shigatoxine.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('La gastro-entérite infectieuse est une infection passagère du tube digestif, due à un virus, une bactérie, un parasite ou une toxine. '
   'Son symptôme principal est la diarrhée : au moins 3 selles molles ou aqueuses par 24 heures, depuis moins de 14 jours. '
   f'La {DYS} en est la forme invasive.', 15) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition (SSI)', 'À ne pas confondre avec'], [
    ['Diarrhée aiguë', '≥ 3 selles molles/24 h, durée < 14 jours', 'Diarrhée persistante (> 14 jours) ou chronique (> 30 jours)'],
    ['Diarrhée sévère', 'Les activités prévues ne sont plus possibles', 'Diarrhée grave avec choc'],
    ['Dysenterie', 'Selles glaireuses et sanglantes', 'Rectorragie d’origine non infectieuse (MICI, cancer)'],
    ['Intoxication par toxine', 'Début en quelques heures, durée < 12 heures', 'Infection bactérienne invasive'],
    ['Diarrhée du voyageur', 'Début pendant ou peu après un séjour en zone tropicale', 'Gastro-entérite acquise en Suisse'],
   ]), 15, 16)))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, en 2024, 8 280 campylobactérioses (92 pour 100 000 habitants) et 2 344 salmonelloses (26 pour 100 000) ont été déclarées. '
   'Au niveau mondial, le norovirus est trouvé dans 18 % des gastro-entérites aiguës, 24 % en communauté. '
   'Le chiffre « 12 % des consultations pour fièvre » de l’original n’a été retrouvé dans aucune source et il est retiré.', 28, 71, 99) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Campylobactériose' + PR('92/100 000', 28), '8 280 cas, pic en juillet–août, 56 % d’hommes', 'Suisse 2024 (OSAV, OFSP)'],
    ['Salmonellose' + PR('26/100 000', 28), '2 344 cas', 'Suisse 2024'],
    ['Norovirus' + PR('18 %', 71), '24 % en communauté, 17 % chez les hospitalisés', 'Méta-analyse mondiale, gastro-entérites aiguës'],
    ['Intestin irritable post-infectieux', '7–10 % des cas', 'SSI'],
   ], 'Le pronostic est bon : la maladie guérit seule le plus souvent ; la mortalité et les complications touchent surtout les âges extrêmes, les comorbidités et l’immunosuppression.') +
   P('Les facteurs de risque de complication sont l’âge avancé, la comorbidité chronique et l’immunosuppression.', 15), 28, 71, 15)))
PTS.append(POINT(3, 'Physiopathologie',
 P('Les virus détruisent les cellules qui tapissent l’intestin grêle : l’eau et les sucres ne sont plus absorbés, d’où une diarrhée aqueuse. '
   'Les bactéries invasives (Campylobacter, Salmonella, Shigella) pénètrent la paroi du côlon et déclenchent une inflammation, d’où fièvre et sang dans les selles. '
   'Les toxines préformées (Staphylococcus aureus, Bacillus cereus) agissent en quelques heures, sans fièvre durable.', 15) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Le grêle absorbe la plus grande partie de l’eau ; le côlon la termine.'],
    ['Physiologie', 'Absorption de sodium couplée au glucose : base des solutions de réhydratation orale.'],
    ['Physiopathologie', 'Destruction des villosités (virus) ou invasion de la muqueuse (bactéries).'],
    ['Clinique', 'Diarrhée aqueuse, vomissements ; ou dysenterie fébrile.'],
    ['Examens', 'Rarement utiles ; la PCR des selles est réservée aux indications de la SSI.'],
    ['Traitement', 'Réhydratation d’abord ; antibiotique seulement dans les formes graves.'],
   ]), 15) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Perte d’eau et de sel', 'Poids, pouls, pression, créatinine', 'Réhydratation orale ou IV'],
    ['Invasion du côlon', 'PCR ou culture des selles, hémocultures', 'Azithromycine 3 jours'],
    ['Toxine de C. difficile', 'Recherche de toxine dans les selles', 'Arrêt de l’antibiotique, traitement spécifique'],
    ['Shigatoxine', 'PCR des selles, NFS, créatinine', 'Pas d’antibiotique ni de lopéramide'],
   ]), 15, 72) +
 F('Déficit en eau : calcul et exemple',
   P('Le déficit approximatif se calcule à partir de la perte de poids aiguë, car 1 kg perdu correspond à environ 1 L d’eau. '
     'Exemple de l’original : adulte de 70 kg ayant perdu 7 % de son poids, 70 × 0,07 donne un déficit de 4,9 L. '
     'Les seuils de gravité 5 % et 10 % viennent d’une classification pédiatrique de l’OMS ; leur transposition à l’adulte est à faire vérifier.', 107) +
   TAB(['Signe', 'Peu ou pas de déshydratation', 'Déshydratation majeure'], [
    ['Conscience', 'Normale', 'Léthargie, confusion'],
    ['Pouls et pression', 'Normaux', 'Tachycardie, hypotension, marbrures'],
    ['Diurèse', 'Conservée', 'Oligurie'],
    ['Liquides par la bouche', 'Gardés', 'Vomissements : impossibilité de boire, donc hospitalisation'],
   ]), 107, 15)))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin cherche d’abord une urgence : choc, déshydratation majeure, sepsis ou abdomen chirurgical. '
   'Il classe ensuite la diarrhée : aqueuse ou sanglante, avec ou sans fièvre, et repère un voyage, un antibiotique récent ou une immunosuppression. '
   'Il cherche enfin les causes non infectieuses : appendicite, ischémie intestinale, maladie inflammatoire de l’intestin.', 15) +
 F('Diagnostic différentiel des causes (fréquences en exposant rouge, même unité : % des épisodes de diarrhée du voyageur, SSI)',
   TAB(['Cause et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Bactérienne' + PR('80–90 %', 16), 'Début brutal, fièvre, parfois sang', 'PCR multiplex des selles si indication'],
    ['Virale' + PR('5–10 %', 16), 'Vomissements, épidémie dans l’entourage', 'Aucun en général'],
    ['Parasitaire' + PR('5–10 %', 16), 'Durée > 14 jours, ballonnements', 'Examen parasitologique, PCR'],
    ['Colite à C. difficile', 'Antibiotique ou hospitalisation récente', 'Toxine dans les selles'],
    ['Appendicite, ischémie intestinale', 'Douleur localisée ou disproportionnée', 'Scanner abdominal'],
   ]) + P('Ces fréquences décrivent la diarrhée du voyageur ; pour la gastro-entérite acquise en Suisse, la seule fréquence retrouvée est celle du norovirus (18 % dans le monde). '
          'Aucune fréquence dans la même population n’a été retrouvée pour C. difficile, l’appendicite et l’ischémie.', 16, 71), 16, 15)))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise le nombre et l’aspect des selles, la fièvre, les vomissements, les repas partagés, les voyages, les antibiotiques récents, l’immunosuppression et le métier.', 15) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Y a-t-il du sang dans les selles ?', 'Dysenterie.', 'Examen des selles, azithromycine possible.'],
    ['D’autres personnes du repas sont-elles malades ?', 'Toxi-infection collective.', 'Déclaration, toxine préformée.'],
    ['Avez-vous pris un antibiotique ces dernières semaines ?', 'C. difficile.', 'Recherche de toxine.'],
    ['Revenez-vous d’un voyage ?', 'Diarrhée du voyageur, paludisme.', 'Recommandation dédiée ; goutte épaisse si fièvre au retour des tropiques.'],
    ['Gardez-vous les liquides ?', 'Risque de déshydratation.', 'Hospitalisation si non.'],
    ['Travaillez-vous dans l’alimentation ?', 'Risque de transmission.', 'Arrêt de travail jusqu’à 48 heures après les symptômes.'],
   ]), 15, 16) +
 U('<b>Drapeaux rouges (urgences ou 144)</b> : signes de choc, vomissements empêchant de boire, oligurie, confusion, sang abondant, douleur abdominale intense ou disproportionnée, fièvre > 38,3 °C depuis ≥ 72 heures.', 15)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen mesure le poids, le pouls, la pression couchée puis debout et la température. '
   'Il inspecte les muqueuses, palpe tout l’abdomen et cherche une défense. '
   'Un abdomen souple et un pouls normal rassurent sur l’absence de déshydratation majeure et de péritonite.', 15) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Pression et pouls debout après 1–3 minutes', 'Variation faible', 'Chute de pression, pouls qui accélère : hypovolémie'],
    ['Muqueuses, pli cutané', 'Bouche humide', 'Bouche sèche : déshydratation (pli peu fiable chez la personne âgée)'],
    ['Palpation abdominale', 'Souple, sensibilité diffuse modérée', 'Défense, contracture : péritonite, chirurgie'],
    ['Poids', 'Stable', 'Perte aiguë : estimation du déficit'],
   ]) + P('La valeur de chaque signe est limitée : la sensibilité du pli cutané et de la sécheresse buccale baisse avec l’âge ; l’ensemble des signes compte plus que chacun.', 107), 15, 107)))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la diarrhée, les vomissements, les crampes abdominales et le ténesme. '
   'Les signes physiques sont la fièvre, la tachycardie, l’hypotension et la sensibilité abdominale. '
   'L’atteinte invasive s’accompagne de sang dans les selles.', 15) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme'], [
    ['Syndrome dysentérique', 'Selles glaireuses et sanglantes, ténesme, fièvre', 'Invasion du côlon'],
    ['Syndrome cholériforme', 'Diarrhée aqueuse abondante sans sang', 'Sécrétion d’eau par l’intestin grêle'],
    ['Syndrome toxinique', 'Vomissements en quelques heures après un repas', 'Toxine préformée'],
    ['Syndrome de déshydratation', 'Soif, oligurie, tachycardie, hypotension', 'Perte d’eau et de sel'],
   ]) + P('Termes : ' + TEN + ', ' + SHU + '.', 15), 15)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le diagnostic est clinique selon la recommandation SSI 2025 : au moins 3 selles molles par 24 heures depuis moins de 14 jours. '
   'Un examen des selles n’est demandé que s’il change le traitement. '
   'Une PCR positive ne suffit pas à elle seule : elle détecte aussi des germes sans rôle clinique.', 15) +
 F('Critères d’examen microbiologique (SSI)',
   TAB(['Recommandé', 'À envisager'], [
    ['Dysenterie', 'Diarrhée ≥ 7 jours'],
    ['Immunosuppression (VIH avec CD4 < 200/mm³, chimiothérapie, greffe)', 'Âge ≥ 65 ans avec comorbidités'],
    ['Antibiotique ou hospitalisation récente', 'Raison épidémiologique, épidémie'],
    ['Fièvre > 38,3 °C pendant ≥ 72 heures, douleurs fortes, sepsis', '—'],
   ]) + P('La biologie sanguine (sodium normal 135–145 mmol/L, créatinine) ne fait pas partie de ces critères ; elle mesure seulement la déshydratation.', 15), 15)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['PCR multiplex des selles', 'Plusieurs germes en un test', 'Rapide, sensible ; ne teste pas les résistances', 'Coût ; germes sans rôle clinique'],
    ['Coproculture', 'Germe et antibiogramme', 'Moins sensible que la PCR', 'Délai de 2–3 jours'],
    ['Toxine de C. difficile', 'Colite à C. difficile', 'Selon la recommandation dédiée', 'Seulement si selles non moulées'],
   ]), 15) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Aucun', 'Pas d’examen', 'Forme non compliquée'],
    ['Première', 'PCR ou culture des selles ± hémocultures', 'Critères SSI'],
    ['Première', 'Créatinine, ionogramme (sodium, potassium), NFS', 'Déshydratation, hospitalisation'],
    ['Seconde', 'Scanner abdominal', 'Douleur intense, suspicion de complication chirurgicale'],
    ['Seconde', 'Endoscopie (rectosigmoïdoscopie)', 'Diarrhée persistante sanglante'],
   ]), 15) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La règle de la SSI : tester seulement si le résultat change le traitement, et traiter seulement après un test.',
       'Les selles sont prélevées avant tout antibiotique, dans un pot propre, et acheminées rapidement.',
       'Les hémocultures accompagnent les selles en cas de fièvre élevée ou de sepsis.']), 15) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Normal', 'Seuil', 'Signification et conduite'], [
    ['Créatinine', 'Selon l’âge', 'Hausse aiguë', 'Insuffisance rénale fonctionnelle : réhydratation IV'],
    ['Sodium', '135–145 mmol/L', '< 135 ou > 145 mmol/L', 'Trouble hydrique : correction lente'],
    ['Potassium', '3,5–5,0 mmol/L', '< 3,5 mmol/L', 'Pertes digestives : supplément'],
    ['Plaquettes et hémoglobine', 'Normales', 'Baisse avec créatinine en hausse', 'SHU : avis spécialisé urgent'],
    ['PCR shigatoxine', 'Négative', 'Positive', 'Pas d’antibiotique ni de lopéramide'],
   ]), 15, 72) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (PCR positive, patient guéri)', 'Pas de traitement'],
    ['Résultat négatif mais clinique sévère', 'Culture, recherche de C. difficile, avis spécialisé'],
    ['Résultat limite ou germe inhabituel', 'Discuter avec le laboratoire'],
    ['Grossesse', 'Listériose à envisager si fièvre ; hémocultures'],
    ['Enfant', 'Classification OMS de la déshydratation ; solutions de réhydratation orale'],
    ['DFGe bas', 'Prudence avec les AINS et les diurétiques pendant la déshydratation'],
    ['Allergie à l’iode, pacemaker ou IRM', 'Échographie ou scanner sans injection'],
   ]), 15, 107))
PTS.append(POINT(9, 'Examens complémentaires',
 P('La plupart des gastro-entérites ne demandent aucun examen. '
   'Les examens des selles suivent les critères de la SSI. '
   'La biologie sanguine sert à mesurer la déshydratation chez le patient hospitalisé.', 15) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si la diarrhée est non compliquée, sans fièvre et sans sang, alors le médecin traite les symptômes sans examen. '
   'Si un critère de la SSI est présent, alors il demande une PCR ou une culture des selles. '
   'Si le patient vomit tout ou présente des signes de choc, alors il l’hospitalise pour une réhydratation IV.', 15) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Diarrhée non compliquée', 'Boissons, alimentation selon l’appétit', 'Reconsulter si sang, fièvre, durée > 7 jours'],
    ['Dysenterie, fièvre > 38,3 °C avec douleurs, sepsis, immunosuppression', 'Azithromycine 500 mg/j pendant 3 jours après prélèvement', 'Adapter au germe'],
    ['Antibiotique récent', 'Recherche de C. difficile', 'Recommandation dédiée'],
    ['Shigatoxine ou E. coli O157', 'Ni antibiotique ni lopéramide', 'NFS et créatinine (SHU)'],
    ['Vomissements incoercibles, choc', 'Hospitalisation, réhydratation IV', 'Diurèse, créatinine'],
   ]) + P('Correction de l’original : la SSI ne recommande pas de fluoroquinolone en traitement empirique ; elle retient l’azithromycine.', 15), 15, 72)))
MED = F('Fiches médicamenteuses (posologies AIPS et SSI)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Solution de réhydratation orale, Normolytoral® (sels et glucose)', 'Le glucose entraîne le sodium et l’eau dans la cellule intestinale', 'Selon la soif et les pertes, par petites gorgées', 'Peu d’effets ; utile surtout chez les patients à risque'],
   ['Azithromycine, Zithromax® (macrolide)', 'Bloque la synthèse protéique ; demi-vie très longue, d’où 3 jours', '500 mg/j per os pendant 3 jours (SSI) ; 1 g dose unique en diarrhée du voyageur', 'Troubles digestifs, allongement du QT ; interactions avec les médicaments qui allongent le QT'],
   ['Lopéramide, Imodium® (opioïde périphérique)', 'Ralentit le transit en agissant sur les récepteurs intestinaux', '4 mg puis 2 mg après chaque selle non moulée, maximum 8 mg/j, 2 jours au plus', 'CI : sang ou mucus dans les selles, fièvre élevée, shigatoxine, enfant < 12 ans ; prudence hépatique'],
   ['Ondansétron (antiémétique)', 'Bloque les récepteurs de la sérotonine de type 3', 'Seulement si vomissements violents ; dose selon l’AIPS', 'Allongement du QT, constipation'],
   ['Paracétamol, Dafalgan® (antipyrétique)', 'Baisse le thermostat', '500–1000 mg toutes les 4–8 heures, maximum 4 g/j', 'Hépatotoxicité en surdose'],
  ]) + P('Correction de l’original : le lopéramide est contre-indiqué en cas de sang dans les selles ou de fièvre élevée (SSI, AIPS). '
         'La dose d’ondansétron n’a pas été vérifiée dans l’AIPS et reste à contrôler.', 15, 106), 1, 2, 15, 16, 106)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge réhydrate d’abord, parce que la déshydratation est la complication la plus fréquente. '
   'Elle réserve l’antibiotique aux formes graves, car la plupart des diarrhées, même bactériennes, guérissent seules. '
   'Le but chiffré est une diurèse conservée et l’absence de selles sanglantes ou de fièvre après 72 heures.', 15) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans la forme compliquée (choc, sepsis, SHU), le but est de rétablir la circulation et la fonction rénale. '
     'Dans la forme non compliquée, le but est de guérir à domicile sans médicament inutile.', 15), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures',
     OL(['<b>A. Forme compliquée, en urgence</b> : 144 si choc ; réhydratation IV par cristalloïdes ; hémocultures et selles ; azithromycine si sepsis ou dysenterie fébrile.',
         '<b>B. Forme hospitalisée sans choc</b> : réhydratation IV puis orale, correction du potassium, isolement selon le germe.',
         '<b>C. Forme non compliquée</b> : mesures générales (eau, jus, bouillons ; solution de réhydratation chez les patients à risque ; repas légers) ; lopéramide possible si diarrhée légère sans fièvre ni sang.',
         '<b>D. Suivi</b> : reconsulter si la diarrhée dure plus de 7 jours ou devient sanglante.']), 15) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Dans la restauration et le secteur alimentaire, un certificat d’arrêt de travail jusqu’à au moins 48 heures après la fin des symptômes est établi ; la règle relève des autorités cantonales.',
            'La conduite automobile est déconseillée en cas de malaise, d’hypotension ou de fatigue marquée.',
            'Une infection contractée au travail (soignant, laboratoire) peut relever de la LAA ; une arthrite réactive séquellaire peut concerner la LAI.'), 15) +
   F('Traitements non médicamenteux',
     UL(['Hygiène des mains à l’eau chaude et au savon ; serviettes personnelles ; nettoyage quotidien des toilettes.', 'Éviter les piscines 2 semaines après une cryptosporidiose.', 'Isolement à l’hôpital ou en EMS selon le germe.']), 15) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Hydratation ; fièvre : penser à la listériose'],
      ['Enfant', 'Solutions de réhydratation orale ; lopéramide contre-indiqué avant 12 ans'],
      ['Sujet âgé', 'Hospitalisation plus large ; suspendre diurétiques et IECA en cas de déshydratation'],
      ['Insuffisance hépatique', 'Lopéramide à éviter en cas d’atteinte sévère'],
      ['Insuffisance rénale (DFGe bas)', 'Surveiller créatinine et potassium ; éviter les AINS'],
     ]), 15, 106), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Poids, diurèse, pouls', 'Chaque jour', 'Oligurie : réhydratation IV'],
    ['Créatinine, potassium', '24–48 heures si hospitalisé', 'Hausse : poursuivre l’IV, avis'],
    ['Fièvre', 'Chaque jour', 'Fièvre ≥ 72 heures : examen des selles'],
    ['Lopéramide', 'Maximum 2 jours', 'Arrêt si sang, fièvre ou ballonnement'],
   ]) + H4('Critères de sortie, un par un') + OL(['Liquides gardés par la bouche.', 'Diurèse et créatinine normalisées.', 'Pas de sang dans les selles, fièvre en baisse.', 'Consignes d’hygiène comprises.']), 15, 106) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La guérison spontanée est la règle. '
     'Les complications possibles sont le SHU, l’arthrite réactive, le syndrome de Guillain-Barré et l’intestin irritable post-infectieux dans 7–10 % des cas. '
     'La recherche porte sur les vaccins contre le norovirus, encore non disponibles.', 15, 71), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur l’hygiène des mains, la cuisson suffisante des volailles et la chaîne du froid. '
   'La recommandation suisse de la SSI demande d’informer chaque patient des mesures d’hygiène. '
   'Certaines infections sont à déclaration obligatoire, ce qui permet de détecter les foyers.', 15, 28) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Hygiène des mains, cuisson des volailles, chaîne du froid ; vaccin contre le rotavirus du nourrisson (Plan de vaccination suisse)'],
    ['Secondaire', 'Déclaration des foyers ; arrêt de travail dans l’alimentation'],
    ['Tertiaire', 'Suivi de la fonction rénale après SHU'],
   ]), 15, 26)))
PTS.append(POINT(13, 'Points clés',
 P('La réhydratation est le premier traitement. '
   'La plupart des diarrhées infectieuses guérissent seules et ne demandent ni examen ni antibiotique. '
   'Sang, fièvre persistante, immunosuppression ou antibiotique récent changent la conduite. '
   'Le médecin n’oublie jamais de demander un voyage récent : une fièvre au retour des tropiques impose de chercher le paludisme.', 15, 16)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Prescrire un antibiotique pour une diarrhée aqueuse non fébrile.', 'Non : traitement des symptômes.'],
  ['Donner du lopéramide en cas de dysenterie fébrile.', 'Non : contre-indiqué.'],
  ['Traiter par antibiotique une infection à E. coli O157.', 'Non : risque de SHU (risque relatif ajusté 17,3).'],
  ['Oublier C. difficile après un antibiotique.', 'Rechercher la toxine.'],
  ['Demander une coproculture à chaque diarrhée.', 'Non : seulement selon les critères SSI.'],
 ]) + P('Ces pièges entraînent le raisonnement ; ils ne sont pas des questions officielles de l’examen fédéral.', 15, 72)))
CTX = {'_prefixe': 'Dans une gastro-entérite infectieuse',
 'copro': 'La PCR ou la culture des selles n’est demandée que selon les critères de la SSI (sang, fièvre ≥ 72 heures, immunosuppression, antibiotique récent).',
 'hemoc': 'Les hémocultures accompagnent les selles en cas de fièvre élevée ou de sepsis.',
 'iono': 'Le sodium et le potassium mesurent les pertes digestives.',
 'creat': 'Une créatinine en hausse signe une insuffisance rénale fonctionnelle par déshydratation, ou un SHU.',
 'uree': 'L’urée augmente avec la déshydratation.',
 'nfs': 'La chute des plaquettes et de l’hémoglobine avec insuffisance rénale fait suspecter un SHU.',
 'crp': 'La CRP élevée oriente vers une forme invasive mais ne remplace pas les critères cliniques.',
 'pcr': 'La PCR multiplex des selles détecte bactéries, virus et parasites, sans tester les résistances.',
 'tdm': 'Le scanner abdominal cherche une complication chirurgicale (perforation, ischémie, appendicite).',
 'echoabdo': 'L’échographie abdominale cherche une appendicite ou un épanchement.',
 'lact': 'Un lactate élevé évoque une ischémie intestinale ou un choc.',
 'endo': 'La rectosigmoïdoscopie est réservée à la diarrhée sanglante persistante.',
 'gds': 'Les gaz du sang montrent une acidose en cas de pertes digestives importantes.',
 'ecg': 'L’ECG cherche un allongement du QT avant certains antiémétiques et en cas d’hypokaliémie.',
 'tdr': 'Le test rapide du paludisme est fait en cas de fièvre au retour des tropiques.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
