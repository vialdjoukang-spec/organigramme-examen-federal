#!/usr/bin/env python3
"""ci.py <reg> [section] : imprime la section Contre-indications (ou autre) d'une AIPS (miroir ODDB) et la sauvegarde dans verif/fi/CI_<reg>.txt"""
import sys,re,html,urllib.request,os
UA={'User-Agent':'curl/8.0'}
reg=sys.argv[1]; sec=sys.argv[2] if len(sys.argv)>2 else 'Contre-indications'
t=urllib.request.urlopen(urllib.request.Request('https://ch.oddb.org/fr/gcc/fachinfo/reg/%s'%reg,headers=UA),timeout=40).read().decode('utf-8','ignore')
t=re.sub(r'<script.*?</script>|<style.*?</style>','',t,flags=re.S); t=html.unescape(re.sub(r'<[^>]+>','\n',t)); t=re.sub(r'\n\s*\n+','\n',t)
i=t.find('\n'+sec+'\n'); j=t.find('\nMises en garde',i+5) if sec=='Contre-indications' else i+3000
out='URL https://ch.oddb.org/fr/gcc/fachinfo/reg/%s\nSECTION %s\n%s'%(reg,sec,t[i:j if j>0 else i+3000][:3000])
print(out); open(os.path.join(os.path.dirname(os.path.abspath(__file__)),'verif/fi/CI_%s.txt'%reg),'a').write(out+'\n')
