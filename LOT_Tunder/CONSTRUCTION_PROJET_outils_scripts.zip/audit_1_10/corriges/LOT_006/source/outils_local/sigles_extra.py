# -*- coding: utf-8 -*-
"""Sigles ajoutés localement pour les LOT 5 et 6 (fusionnés à outils/sigles.py sans le modifier)."""
DEV_EXTRA = {
 'ACE2': 'enzyme de conversion de l’angiotensine 2, récepteur cellulaire du coronavirus de 2019', 'CMV': 'cytomégalovirus', 'COVID': 'maladie à coronavirus 2019 (COronaVIrus Disease)',
 'CRB': 'score de gravité de la pneumonie sans urée (Confusion, Respiratory rate, Blood pressure)', 'CURB': 'score de gravité de la pneumonie (Confusion, Urea, Respiratory rate, Blood pressure)',
 'CoV': 'coronavirus', 'HSV': 'virus herpès simplex', 'IECA': 'inhibiteur de l’enzyme de conversion de l’angiotensine', 'ILI': 'syndrome grippal (Influenza-Like Illness)',
 'LCR': 'liquide cérébrospinal (céphalorachidien)', 'MTB': 'Mycobacterium tuberculosis', 'NEWS2': 'score national d’alerte précoce, 2e version (National Early Warning Score 2)',
 'NS1': 'protéine non structurale 1 (antigène de la dengue)', 'PCT': 'procalcitonine', 'RIF': 'rifampicine', 'RT': 'transcription inverse (Reverse Transcription)',
 'SARS': 'syndrome respiratoire aigu sévère (Severe Acute Respiratory Syndrome)', 'SSI': 'Société suisse d’infectiologie', 'TNF': 'facteur de nécrose tumorale (Tumor Necrosis Factor)',
 'VRS': 'virus respiratoire syncytial', 'qSOFA': 'score SOFA rapide (quick Sequential Organ Failure Assessment)', 'SOFA': 'score de défaillance d’organes (Sequential Organ Failure Assessment)',
 'PAM': 'pression artérielle moyenne', 'PAS': 'pression artérielle systolique', 'PAD': 'pression artérielle diastolique', 'FC': 'fréquence cardiaque', 'FR': 'fréquence respiratoire',
 'SCA': 'syndrome coronarien aigu', 'NSTEMI': 'infarctus sans sus-décalage persistant du segment de repolarisation', 'STEMI': 'infarctus avec sus-décalage persistant du segment de repolarisation', 'ST': 'segment ST de l’électrocardiogramme',
 'ESC': 'Société européenne de cardiologie (European Society of Cardiology)', 'HEART': 'score de douleur thoracique (History, ECG, Age, Risk factors, Troponin)',
 'GRACE': 'score de risque des syndromes coronariens (Global Registry of Acute Coronary Events)', 'ISRS': 'inhibiteur sélectif de la recapture de la sérotonine',
 'IRSN': 'inhibiteur de la recapture de la sérotonine et de la noradrénaline', 'GAD': 'trouble anxieux généralisé (Generalized Anxiety Disorder)', 'PHQ': 'questionnaire de santé du patient (Patient Health Questionnaire)',
 'TCC': 'thérapie cognitivo-comportementale', 'DSM': 'Manuel diagnostique et statistique des troubles mentaux (Diagnostic and Statistical Manual)', 'CIM': 'Classification internationale des maladies',
 'SIADH': 'sécrétion inappropriée d’hormone antidiurétique', 'ADH': 'hormone antidiurétique (vasopressine)', 'PTH': 'parathormone', 'PTHrP': 'peptide apparenté à la parathormone',
 'ECG': 'électrocardiogramme', 'QTc': 'intervalle QT corrigé', 'STOPP': 'prescriptions inappropriées chez la personne âgée (Screening Tool of Older Persons’ Prescriptions)',
 'START': 'outil d’alerte pour traitements omis chez la personne âgée (Screening Tool to Alert to Right Treatment)', 'ACB': 'charge anticholinergique (Anticholinergic Cognitive Burden)',
 'PPR': 'pseudo-polyarthrite rhizomélique', 'ACG': 'artérite à cellules géantes (maladie de Horton)', 'LES': 'lupus érythémateux systémique', 'AAN': 'anticorps antinucléaires',
 'EULAR': 'Alliance européenne des associations de rhumatologie (European Alliance of Associations for Rheumatology)', 'ACR': 'Collège américain de rhumatologie (American College of Rheumatology)',
 'CAM': 'méthode d’évaluation de la confusion (Confusion Assessment Method)', '4AT': 'test de dépistage du delirium en 4 items (4 « A » Test)', 'CFS': 'échelle clinique de fragilité (Clinical Frailty Scale)',
 'HbCO': 'carboxyhémoglobine', 'CO': 'monoxyde de carbone', 'OHB': 'oxygénothérapie hyperbare', 'ETT': 'échocardiographie transthoracique', 'ETO': 'échocardiographie transœsophagienne',
 'TEP': 'tomographie par émission de positons', 'FDG': 'fluorodésoxyglucose', 'EURO': 'registre européen', 'ENDO': 'endocardite', 'AIPS': 'information professionnelle des médicaments (Arzneimittel-Informations-Publikations-System)',
 'OAC': 'ordonnance réglant l’admission à la circulation routière', 'LPTh': 'loi fédérale sur les produits thérapeutiques', 'ElViS': 'système électronique d’annonce de vigilance de Swissmedic (Electronic Vigilance System)',
 'SSAD': 'Société suisse des troubles anxieux et de la dépression', 'SSMIG': 'Société suisse de médecine interne générale', 'CEMV': 'Comité d’experts en médecine des voyages', 'CFV': 'Commission fédérale pour les vaccinations',
 'Obsan': 'Observatoire suisse de la santé', 'MNT': 'maladies non transmissibles', 'KDIGO': 'organisation internationale de recommandations en néphrologie (Kidney Disease: Improving Global Outcomes)',
 'IRA': 'insuffisance rénale aiguë', 'DFG': 'débit de filtration glomérulaire', 'OMS': 'Organisation mondiale de la santé', 'ERC': 'Conseil européen de réanimation (European Resuscitation Council)',
 'SSC': 'campagne internationale contre le sepsis (Surviving Sepsis Campaign)', 'HELP': 'programme de prévention du delirium (Hospital Elder Life Program)', 'FINISH': 'symptômes de sevrage (Flu-like, Insomnia, Nausea, Imbalance, Sensory, Hyperarousal)',
 'BZD': 'benzodiazépine', 'GiACTA': 'essai du tocilizumab dans l’artérite à cellules géantes', 'IL': 'interleukine', 'IFN': 'interféron', 'TLR': 'récepteur de type Toll (Toll-Like Receptor)',
 'ARN': 'acide ribonucléique', 'ADN': 'acide désoxyribonucléique', 'MAP': 'pression artérielle moyenne (Mean Arterial Pressure)', 'POCUS': 'échographie au lit du patient (Point-Of-Care UltraSound)',
 'SGLT2': 'cotransporteur sodium-glucose de type 2', 'HbA1c': 'hémoglobine glyquée', 'DFGe': 'débit de filtration glomérulaire estimé',
 'CYP2D6': 'cytochrome P450 2D6', 'CYP2C19': 'cytochrome P450 2C19', 'CYP3A4': 'cytochrome P450 3A4', 'GABA': 'acide gamma-aminobutyrique', 'HT2A': 'récepteur 2A de la sérotonine (5-hydroxytryptamine)',
 'IGSLI': 'groupe international d’étude du lithium (International Group for the Study of Lithium-treated patients)', 'ISBD': 'Société internationale des troubles bipolaires (International Society for Bipolar Disorders)',
 'LAGH': 'loi fédérale sur l’analyse génétique humaine', 'NF1': 'neurofibromatose de type 1', 'RET': 'proto-oncogène RET (REarranged during Transfection)', 'SDHx': 'gènes de la succinate déshydrogénase',
 'THRB': 'gène du récepteur bêta des hormones thyroïdiennes', 'VHL': 'maladie de von Hippel-Lindau', 'IMAO': 'inhibiteur de la monoamine oxydase', 'CYP': 'cytochrome P450',
 'CG113': 'recommandation clinique numéro 113 (Clinical Guideline 113)', 'CO2': 'dioxyde de carbone', 'FEU': 'unités d’équivalent fibrinogène (Fibrinogen Equivalent Units)',
 'NICE': 'National Institute for Health and Care Excellence (Royaume-Uni)', 'OPAS': 'ordonnance sur les prestations de l’assurance des soins', 'TAG': 'trouble anxieux généralisé', 'TR': 'texte révisé',
 'IPP': 'inhibiteur de la pompe à protons', 'MGUS': 'gammapathie monoclonale de signification indéterminée (Monoclonal Gammopathy of Undetermined Significance)', 'NaCl': 'chlorure de sodium',
 'RANKL': 'ligand du récepteur activateur du facteur nucléaire kappa B', 'UK': 'Royaume-Uni (United Kingdom)',
 'AI': 'assurance-invalidité', 'FiO2': 'fraction inspirée en oxygène', 'JJ': 'sonde urétérale double J', 'PaO2': 'pression partielle artérielle en oxygène',
 'SIRS': 'syndrome de réponse inflammatoire systémique (Systemic Inflammatory Response Syndrome)',
 'AMIS': 'registre suisse de l’infarctus aigu (Acute Myocardial Infarction in Switzerland)', 'IVA': 'artère interventriculaire antérieure',
 'NRMI': 'registre national américain de l’infarctus (National Registry of Myocardial Infarction)',
 'CCP': 'peptides citrullinés cycliques (anticorps anti-CCP)', 'RoActemra': 'nom commercial suisse du tocilizumab',
 'SpCO': 'saturation en carboxyhémoglobine mesurée au doigt par un oxymètre à plusieurs longueurs d’onde', 'OPair': 'ordonnance sur la protection de l’air', 'OSAV': 'Office fédéral de la sécurité alimentaire et des affaires vétérinaires', 'OFEV': 'Office fédéral de l’environnement', 'GTÜM': 'Société germanophone de médecine subaquatique et hyperbare', 'DAN': 'réseau d’alerte des plongeurs (Divers Alert Network)', 'BPCO': 'bronchopneumopathie chronique obstructive',
 'AEG': 'altération de l’état général', 'BANC': 'étude bâloise sur les plaintes non spécifiques (Basel Non-specific Complaints)',
 'AMT4': 'test mental abrégé en 4 questions (Abbreviated Mental Test 4)', 'AMTS': 'test mental abrégé en 10 questions (Abbreviated Mental Test Score)', 'EMS': 'établissement médico-social',
}
# Surcharges locales (prioritaires sur outils/sigles.py) : définitions sans autre sigle, car le glossaire précède le texte.
DEV_OVERRIDE = {
 'NSTEMI': 'infarctus sans sus-décalage persistant du segment de repolarisation',
 'STEMI': 'infarctus avec sus-décalage persistant du segment de repolarisation',
}

# Ajouts LOT 6 (fièvre)
DEV_EXTRA.update({
 'CI': 'contre-indication', 'EPIC': 'étude étiologique des pneumonies communautaires aux États-Unis (Etiology of Pneumonia in the Community)',
 'HRP2': 'protéine riche en histidine 2 de Plasmodium falciparum (antigène des tests rapides)', 'McIsaac': 'score de Centor modifié par McIsaac (ajoute l’âge)',
 'PAC': 'pneumonie acquise en communauté', 'PCV20': 'vaccin conjugué antipneumococcique 20-valent', 'PCV21': 'vaccin conjugué antipneumococcique 21-valent',
 'PCV': 'vaccin conjugué antipneumococcique', 'TDR': 'test de diagnostic rapide', 'IU': 'infection urinaire', 'ECBU': 'examen cytobactériologique des urines',
 'GEA': 'gastro-entérite aiguë', 'SRO': 'solution de réhydratation orale', 'SHU': 'syndrome hémolytique et urémique', 'ICTM': 'infection cutanée et des tissus mous',
 'LRINEC': 'score de laboratoire du risque de fasciite nécrosante (Laboratory Risk Indicator for Necrotizing Fasciitis)', 'SARM': 'Staphylococcus aureus résistant à la méticilline',
 'MRSA': 'Staphylococcus aureus résistant à la méticilline (Methicillin-Resistant Staphylococcus aureus)', 'PVL': 'leucocidine de Panton-Valentine', 'EEG': 'électroencéphalogramme',
 'HSV1': 'virus herpès simplex de type 1', 'VZV': 'virus varicelle-zona', 'FSME': 'méningo-encéphalite verno-estivale à tiques (Frühsommer-Meningoenzephalitis)',
 'TBE': 'encéphalite à tiques (Tick-Borne Encephalitis)', 'MIM': 'maladie invasive à méningocoque', 'MenB': 'vaccin contre le méningocoque du sérogroupe B',
 'MCV': 'vaccin conjugué antiméningococcique', 'ACWY': 'sérogroupes A, C, W et Y du méningocoque', 'ETT': 'échocardiographie transthoracique', 'ETO': 'échocardiographie transœsophagienne',
 'TEP': 'tomographie par émission de positons', 'TEMP': 'tomographie par émission monophotonique', 'HACEK': 'groupe de bacilles à croissance lente (Haemophilus, Aggregatibacter, Cardiobacterium, Eikenella, Kingella)',
 'EURO': 'registre européen', 'IOA': 'infection ostéo-articulaire', 'OVIVA': 'essai oral versus intraveineux pour les infections osseuses et articulaires (Oral Versus IntraVenous Antibiotics)',
 'FR': 'facteur rhumatoïde', 'CCP': 'peptides cycliques citrullinés', 'ANCA': 'anticorps anti-cytoplasme des polynucléaires neutrophiles', 'ADN': 'acide désoxyribonucléique',
 'Sm': 'antigène Smith', 'ACR': 'Collège américain de rhumatologie (American College of Rheumatology)', 'EULAR': 'Alliance européenne des associations de rhumatologie',
 'SLE': 'lupus érythémateux systémique (Systemic Lupus Erythematosus)', 'AINS': 'anti-inflammatoire non stéroïdien', 'FUO': 'fièvre d’origine inconnue (Fever of Unknown Origin)',
 'FOI': 'fièvre d’origine inconnue', 'MASCC': 'score de risque de la neutropénie fébrile (Multinational Association for Supportive Care in Cancer)', 'IDSA': 'Société américaine des maladies infectieuses (Infectious Diseases Society of America)',
 'ESMO': 'Société européenne d’oncologie médicale', 'PNN': 'polynucléaires neutrophiles', 'G-CSF': 'facteur de croissance des granulocytes', 'CAR': 'récepteur antigénique chimérique (Chimeric Antigen Receptor)',
 'TPH': 'Institut tropical et de santé publique suisse (Tropical and Public Health)', 'OMS': 'Organisation mondiale de la santé', 'WHO': 'Organisation mondiale de la santé (World Health Organization)',
 'G6PD': 'glucose-6-phosphate déshydrogénase', 'HUG': 'Hôpitaux universitaires de Genève', 'CHUV': 'Centre hospitalier universitaire vaudois', 'ATS': 'Société américaine de thoracologie (American Thoracic Society)',
 'ESCMID': 'Société européenne de microbiologie clinique et des maladies infectieuses', 'EPOS': 'position européenne sur la rhinosinusite (European Position paper on Rhinosinusitis)',
 'POET': 'essai partiel oral pour l’endocardite (Partial Oral Endocarditis Treatment)', 'MIP': 'maladie invasive à pneumocoque', 'BU': 'Bulletin de l’OFSP',
 'LAI': 'loi fédérale sur l’assurance-invalidité', 'LAA': 'loi fédérale sur l’assurance-accidents', 'LAMal': 'loi fédérale sur l’assurance-maladie', 'CO': 'Code des obligations',
 'UI': 'unités internationales', 'IV': 'intraveineux', 'IM': 'intramusculaire', 'CYP3A4': 'cytochrome P450 3A4', 'QT': 'intervalle QT de l’électrocardiogramme',
 'COX': 'cyclo-oxygénase', 'IL': 'interleukine', 'SpO2': 'saturation pulsée en oxygène', 'PaO2': 'pression partielle artérielle en oxygène', 'DFGe': 'débit de filtration glomérulaire estimé',
 'TMP': 'triméthoprime', 'SMX': 'sulfaméthoxazole', 'BLSE': 'bêta-lactamase à spectre élargi', 'ASP': 'abdomen sans préparation', 'PCR': 'amplification génique (Polymerase Chain Reaction)',
 'mNGS': 'séquençage métagénomique de nouvelle génération', 'LDH': 'lactate déshydrogénase', 'VS': 'vitesse de sédimentation', 'NFS': 'numération formule sanguine',
 'AOS': 'assurance obligatoire des soins', 'EMS': 'établissement médico-social', 'BPCO': 'bronchopneumopathie chronique obstructive', 'HLA': 'antigène des leucocytes humains',
 'SAM': 'syndrome d’activation macrophagique', 'HLH': 'lymphohistiocytose hémophagocytaire', 'PET': 'tomographie par émission de positons (Positron Emission Tomography)',
})
DEV_OVERRIDE.update({'QT': 'intervalle QT de l’électrocardiogramme'})
DEV_EXTRA.update({'EAU': 'Association européenne d’urologie (European Association of Urology)', 'IST': 'infection sexuellement transmissible', 'UFC': 'unités formant colonies'})

DEV_EXTRA.update({'STEC': 'Escherichia coli producteur de shigatoxine', 'MICI': 'maladie inflammatoire chronique de l’intestin', 'EHEC': 'Escherichia coli entérohémorragique', 'VTEC': 'Escherichia coli producteur de vérotoxine'})
DEV_EXTRA.update({'EI': 'endocardite infectieuse', 'EURO': 'EURO-ENDO, registre européen de l’endocardite (European Endocarditis)', 'ICE': 'ICE-PCS, cohorte prospective internationale de l’endocardite (International Collaboration on Endocarditis–Prospective Cohort Study)', 'PCS': 'étude de cohorte prospective (Prospective Cohort Study)', 'ISCVID': 'Société internationale des maladies infectieuses cardiovasculaires', 'TAVI': 'implantation de valve aortique par cathéter', 'POET': 'essai POET, traitement oral partiel de l’endocardite (Partial Oral Endocarditis Treatment)'})
DEV_EXTRA.update({'EBJIS': 'Société européenne des infections osseuses et articulaires (European Bone and Joint Infection Society)', 'JAMA': 'Journal of the American Medical Association'})
DEV_EXTRA.update({'SCQM': 'registre suisse Swiss Clinical Quality Management in Rheumatic Diseases', 'SSR': 'Société suisse de rhumatologie', 'HEp': 'lignée de cellules épithéliales humaines HEp-2', 'MPO': 'myéloperoxydase', 'PR3': 'protéinase 3'})
DEV_EXTRA.update({'HPV': 'papillomavirus humains', 'HLH': 'lymphohistiocytose hémophagocytaire (hemophagocytic lymphohistiocytosis)', 'MASCC': 'Multinational Association for Supportive Care in Cancer', 'SAKK': 'Groupe suisse de recherche clinique sur le cancer'})
DEV_EXTRA.update({'ECTM': 'Comité suisse d’experts en médecine des voyages', 'QTc': 'intervalle entre le début de l’onde Q et la fin de l’onde T de l’électrocardiogramme, corrigé selon la fréquence cardiaque'})
DEV_OVERRIDE.update({'QTc': 'durée de l’onde Q à la fin de l’onde T à l’électrocardiogramme, corrigée selon la fréquence'})
DEV_EXTRA.update({'HEAT': 'essai randomisé du paracétamol contre placebo en soins intensifs'})
