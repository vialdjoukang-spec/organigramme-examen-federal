#!/bin/bash
# Évaluation déterministe d'un LOT corrigé (outils partagés en lecture seule ; résultats dans corriges/$L/source/work/)
L=${1:-LOT_006}; cd /workspace/audit_1_10; PY=venv/bin/python
$PY corriges/$L/source/outils_local/audit_local.py ${L}_AUDITE | grep -E "^(SSP|DX|SCORE)" | grep -v phrases
$PY outils/verif_v7.py corriges/$L/*AUDITÉ*.html | tail -15
$PY outils/contraste.py $(ls -d $PWD/corriges/$L/*AUDITÉ*.html) | tail -5
