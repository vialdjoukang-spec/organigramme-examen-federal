# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.10 · Phéochromocytome et paragangliome (LOT 1, Appel B, Partie 4b, r1 → audit du 24.10.2026).
Sources S12–S23 = original 4b ; S24–S29 ajoutées à l’audit."""
import sys; sys.path.insert(0, '/workspace/audit_1_10/outils')
from gen_v7 import *
from src_P4b import SOURCES_ORIG as SB
POINT = mkPOINT('dx10')
M = dict(pref='dx10', dx='DX.10', court='Phéochromocytome', long='Phéochromocytome et paragangliome (PPGL)', dossier='corriges/LOT_001',
         fichier='LOT_001_DX10_Pheochromocytome_AUDITÉ.html', lot_titre='LOT 1 · G1 · Transpiration anormale',
         sous_titre='PROFILES 2023 · SSP G1 · LOT 1 · Appel B · V7 · version AUDITÉE',
         statut='Cette version corrige la monographie DX.10 du LOT 1 (Appel B, V7, Partie 4b, révision r1) après audit médical et linguistique ; les doses proviennent des informations professionnelles suisses (AIPS).')
CATE = T('catécholamines', 'Les catécholamines (adrénaline, noradrénaline, dopamine) sont les hormones du stress : elles accélèrent le cœur, resserrent les vaisseaux et font transpirer.')
METAN = T('métanéphrines', 'Les métanéphrines (métanéphrine et normétanéphrine) sont les produits de dégradation des catécholamines, fabriqués en continu dans la tumeur ; leur dosage ne dépend donc pas d’une crise.')
ALPHA = T('blocage alpha', 'Le blocage alpha bloque les récepteurs alpha-1 des vaisseaux, qui les resserrent sous l’effet de la noradrénaline ; il fait baisser la pression et prépare l’opération.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Le phéochromocytome est une tumeur de la médullosurrénale (le centre de la glande surrénale) qui produit en excès des {CATE}. '
   'Le paragangliome est la même tumeur hors de la surrénale, le long de la chaîne sympathique ou dans la tête et le cou. '
   'Le sigle PPGL (phéochromocytome et paragangliome) désigne l’ensemble, qui comprend aussi des tumeurs peu ou non sécrétantes.', 16, 17) +
 F('Terminologie',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Phéochromocytome', 'Paragangliome de la médullosurrénale', 'Adénome de la corticosurrénale'],
    ['Paragangliome sympathique', 'Tumeur abdominale ou thoracique, souvent sécrétante', 'Paragangliome tête et cou, souvent non sécrétant'],
    ['PPGL fonctionnel', 'Production excessive de catécholamines', 'Simple masse'],
    ['PPGL métastatique', 'Tissu tumoral dans un site sans paraganglion (os, foie, poumon)', 'Tumeur multifocale'],
    ['Triade classique', 'Céphalée, sueurs, palpitations', 'Une preuve diagnostique'],
   ]) + P('L’examen histologique ne distingue pas à lui seul une tumeur bénigne d’une tumeur à potentiel métastatique.', 16))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('Aucune incidence suisse récente n’est publiée, et le consensus européen de l’ESH (European Society of Hypertension) cite 0,46 phéochromocytome pour 100 000 personnes par an aux Pays-Bas. '
   'La tumeur touche 0,2 à 0,6 % des hypertendus suivis en consultation et environ 5 % des masses surrénaliennes découvertes par hasard.', 16, 24) +
 P('Les facteurs de risque sont surtout génétiques, avec un contexte héréditaire dans environ 40 % des cas, sans prédominance de sexe et à tout âge. '
   'Le pronostic est bon après exérèse, mais une crise non reconnue peut entraîner une mortalité cardiovasculaire.', 17, 16) +
 F('Chiffres, terrain et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Incidence du phéochromocytome', '0,46 / 100 000 par an' + S(16), 'Données néerlandaises citées par l’ESH 2020, non suisses'],
    ['Paragangliome sympathique', '0,11 / 100 000 par an' + S(16), 'Même source'],
    ['Prévalence chez l’hypertendu', '0,2–0,6 %' + S(24), 'Consultation ambulatoire'],
    ['Incidentalome surrénalien', '≈ 5 % sont des phéochromocytomes' + S(24), 'Masse découverte par hasard'],
    ['Contexte héréditaire', '≈ 40 %' + S(17), 'Enquête génétique systématique'],
   ]) + P('Ces chiffres étrangers ne sont pas une incidence suisse ; ils situent la rareté de la maladie.', 16))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Les cellules chromaffines de la médullosurrénale fabriquent normalement l’adrénaline en réponse au stress, sur ordre des nerfs sympathiques. '
   'Dans la tumeur, cette production devient autonome et se libère par décharges, d’où des accès de sueurs, de céphalée et de palpitations. '
   'La noradrénaline resserre les vaisseaux par les récepteurs alpha, et l’adrénaline accélère le cœur par les récepteurs bêta. '
   'Le traitement bloque donc d’abord les récepteurs alpha, puis seulement les bêta, avant d’enlever la tumeur.', 16, 17) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'La surrénale coiffe le rein ; sa partie centrale, la médullosurrénale, fait partie du système nerveux sympathique, comme les paraganglions le long de l’aorte.'],
    ['Physiologie', 'Pourquoi on transpire sous stress : les catécholamines activent les glandes sudoripares, accélèrent le cœur et resserrent les vaisseaux.'],
    ['Physiopathologie', 'La tumeur produit les catécholamines sans contrôle et en continu, avec des décharges brutales ; elle les dégrade en métanéphrines.'],
    ['Clinique', 'D’où les accès de sueurs, de céphalée, de palpitations, l’hypertension parfois permanente et, en cas de crise, l’infarctus ou le choc.'],
    ['Examens', 'Les métanéphrines plasmatiques libres prouvent la sécrétion ; l’imagerie localise ensuite la tumeur.'],
    ['Traitement', 'Le blocage alpha relâche les vaisseaux, le bêtabloquant vient après contre la tachycardie, puis la chirurgie enlève la source.'],
   ]), 16, 17) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme (lésion)', 'Exploration qui le montre', 'Cible thérapeutique'], [
    ['Sécrétion de noradrénaline', 'Normétanéphrine plasmatique', 'Blocage alpha (doxazosine, phénoxybenzamine)'],
    ['Sécrétion d’adrénaline', 'Métanéphrine plasmatique', 'Bêtabloquant après le blocage alpha'],
    ['Masse surrénalienne', 'TDM ou IRM', 'Surrénalectomie mini-invasive'],
    ['Variant génétique (SDHx, VHL, RET, NF1)', 'Analyse génétique', 'Suivi des apparentés, surveillance prolongée'],
   ]) + P('Le mécanisme explique pourquoi un bêtabloquant seul peut déclencher une crise : il laisse la vasoconstriction alpha sans opposition.', 16, 17))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant des accès de sueurs, de céphalée et de palpitations, le médecin cherche d’abord une urgence : douleur thoracique, dyspnée, arythmie, confusion ou choc. '
   'Il demande ensuite les métanéphrines plasmatiques libres, puis l’imagerie, parce que la triade ne prouve rien. '
   'Il évite tout bêtabloquant isolé, toute biopsie et toute palpation appuyée d’une masse suspecte.', 16, 17) +
 F('Diagnostic différentiel des accès de sueurs et de palpitations (fréquence sourcée en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Phéochromocytome' + PR('0,46 / 100 000 par an ; 0,2–0,6 % des hypertendus', 16, 24), 'Triade, hypertension paroxystique, contexte familial', 'Métanéphrines plasmatiques libres'],
    ['Trouble panique' + PR('≈ 1,7 % (vie entière)', 25), 'Peur intense, sans hypertension franche', 'Métanéphrines normales, avis psychiatrique'],
    ['Hyperthyroïdie' + PR('≈ 0,75 % (Europe)', 26), 'Tremblement, perte de poids, tachycardie permanente', 'TSH'],
    ['Hypoglycémie sous traitement du diabète' + PR('≈ 5 % de diabétiques (Suisse)', 27), 'Insuline ou sulfamide, faim, correction par le sucre', 'Glycémie pendant l’accès'],
    ['Symptômes vasomoteurs de la ménopause' + PR('≈ 80 % des femmes en transition', 28), 'Bouffées de chaleur, femme de 45 à 55 ans', 'Clinique, FSH si doute'],
    ['Hypertension essentielle' + PR('30–45 % des adultes (Europe)', 29), 'Pression élevée permanente, sans accès', 'Métanéphrines si signes évocateurs'],
    ['Cocaïne, amphétamines, sevrage' + PR('fréquence non chiffrée', 16), 'Prise de substances, sevrage d’alcool', 'Anamnèse, toxicologie urinaire'],
   ]) + P('Ces chiffres sont des incidences ou des prévalences dans la population ; ils ne sont pas des probabilités devant un patient donné. Le phéochromocytome reste rare même devant la triade, d’où l’importance d’un dosage bien préparé.', 16))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise les accès, les produits qui faussent le dosage, un parent atteint, une grossesse et une anesthésie prévue.', 16, 17) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Les accès surviennent-ils avec céphalée, sueurs et palpitations ?', 'La triade oriente sans prouver.', 'Dosage des métanéphrines.'],
    ['Prenez-vous un antidépresseur, un décongestionnant, de la cocaïne ?', 'Ces produits augmentent les valeurs.', 'Interprétation prudente, contrôle préparé.'],
    ['Un parent a-t-il eu une tumeur surrénalienne ou un paragangliome ?', 'Contexte héréditaire dans 40 % des cas.', 'Conseil génétique.'],
    ['Une opération ou une anesthésie est-elle prévue ?', 'Le geste peut déclencher une crise.', 'Report jusqu’au bilan.'],
    ['Êtes-vous enceinte ?', 'La grossesse change l’imagerie et le traitement.', 'Centre expert et maternité adaptée.'],
   ])) +
 U('<b>Drapeaux rouges et urgence (appel du 144)</b> : douleur thoracique, dyspnée, arythmie, confusion, hypotension ou choc pendant un accès ; crise après un bêtabloquant isolé.', 16, 17)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure la pression aux deux bras, couché puis debout, la fréquence cardiaque, la température et la glycémie capillaire. '
   'Il examine le cou, la peau et l’abdomen sans palpation appuyée d’une masse suspecte. '
   'Un examen normal entre les accès est fréquent et n’exclut pas la maladie.', 16, 17) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Pression couchée puis debout', '< 140/90 mmHg, sans chute debout', 'Hypertension paroxystique ; hypotension orthostatique'],
    ['Fréquence cardiaque', '60–100/min, régulière', 'Tachycardie, arythmie pendant l’accès'],
    ['Peau', 'Normale', 'Pâleur pendant l’accès ; taches café au lait (neurofibromatose)'],
    ['Cou', 'Pas de masse', 'Masse latérale : paragangliome tête et cou'],
    ['Fond d’œil', 'Normal', 'Rétinopathie hypertensive'],
   ]) + P('L’examen oriente le bilan ; il ne remplace pas le dosage.', 16))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont les sueurs, la céphalée, les palpitations, l’anxiété et la pâleur par accès. '
   'Les signes physiques sont l’hypertension paroxystique ou permanente, la tachycardie et parfois l’hypotension orthostatique. '
   'Ils dessinent un syndrome adrénergique et, en cas de crise, un syndrome de défaillance cardiovasculaire.', 16) +
 F('Signes et syndromes définis',
   TAB(['Signe ou syndrome', 'Description', 'Mécanisme'], [
    ['Syndrome adrénergique', 'Sueurs, céphalée, palpitations, pâleur, tremblement', 'Décharge de catécholamines'],
    ['Hypertension paroxystique', 'Pics tensionnels pendant les accès', 'Vasoconstriction alpha'],
    ['Crise catécholaminergique', 'Douleur thoracique, œdème pulmonaire, choc', 'Cardiomyopathie de stress, vasoconstriction'],
    ['Syndrome tumoral cervical', 'Masse, acouphène pulsatile, dysphonie, dysphagie', 'Paragangliome tête et cou'],
    ['Hypotension orthostatique', 'Chute de pression debout', 'Hypovolémie par vasoconstriction chronique'],
   ]) + P('Termes : ' + METAN + ', ' + T('incidentalome', 'Un incidentalome est une masse surrénalienne découverte par hasard sur une imagerie faite pour une autre raison.') + ', '
          + T('médullosurrénale', 'La médullosurrénale est la partie centrale de la surrénale ; elle sécrète l’adrénaline.') + ', '
          + T('acouphène pulsatile', 'Un acouphène pulsatile est un bruit rythmé avec le pouls, entendu dans l’oreille.') + ', '
          + T('dysphagie', 'La dysphagie est une difficulté à avaler.') + '.', 16))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le consensus ESH 2020 et le protocole national français de 2021 retiennent comme critère une hausse des métanéphrines bien préparées, puis une imagerie concordante. '
   'Une hausse d’un métabolite plasmatique de plus de 2 fois la limite supérieure (ESH) ou de plus de 4 fois (protocole français) justifie l’imagerie, avec une valeur prédictive négative > 99 %. '
   'Une hausse modérée isolée ne suffit pas et impose un contrôle préparé.', 16, 17) +
 F('Catégories et règles',
   TAB(['Situation', 'Critère', 'Conséquence'], [
    ['Valeur dans la référence (bonnes conditions)', 'Métanéphrines normales', 'Forme sécrétante très peu probable'],
    ['Hausse franche', '> 2 fois (ESH) ou > 4 fois (protocole français) la limite', 'Imagerie de localisation'],
    ['Hausse modérée', '1 à 4 fois la limite', 'Contrôle préparé, recherche d’interférences'],
    ['Masse sans sécrétion', 'Métanéphrines normales, masse évocatrice', 'Centre expert, imagerie fonctionnelle'],
   ]) + P('Les seuils de deux sources ne sont jamais fusionnés en un seuil intermédiaire.', 16, 17))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Métanéphrines plasmatiques libres', 'Gold standard biochimique : sécrétion tumorale', 'Valeur prédictive négative > 99 %' + S(16), 'Posture, stress, médicaments'],
    ['Métanéphrines urinaires des 24 heures', 'Confirmation', 'Inférieure en insuffisance rénale' + S(17), 'Recueil incomplet'],
    ['TDM ou IRM', 'Localisation', 'Sensible pour les tumeurs surrénaliennes', 'Ne prouve pas la sécrétion'],
    ['Histologie après exérèse', 'Nature de la tumeur', 'Ne prédit pas seule le risque métastatique', 'Jamais de biopsie avant'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Métanéphrines plasmatiques libres, couché', 'Suspicion clinique, incidentalome, génétique'],
    ['Seconde', 'Métanéphrines totales ou urinaires', 'Confirmation selon le laboratoire'],
    ['Après preuve', 'TDM ou IRM abdominale', 'Hausse franche'],
    ['Après localisation', 'Imagerie fonctionnelle (TEP spécifique)', 'Tumeur multiple, génétique, métastase'],
    ['Systématique', 'Analyse génétique avec consentement', 'Tout PPGL confirmé'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La fiche du CHUV (version 15, 2025) demande 24 heures sans café, thé, chocolat, banane, alcool ni cigarette, puis un <b>prélèvement à jeun, couché</b>, 15 minutes après la pose de la voie veineuse.',
       'Le tube part <b>sur glace</b>, sans pneumatique, et arrive au laboratoire dans les 30 minutes.',
       'Le prélèvement n’a pas besoin de coïncider avec une crise, car la tumeur produit les métanéphrines en continu.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Négatif', 'Dans la référence', 'Forme sécrétante très peu probable', 'Chercher une autre cause'],
    ['Positif franc', '> 2 fois (ESH) ou > 4 fois (protocole)', 'Forte probabilité', 'Imagerie, centre expert'],
    ['Limite', '1 à 4 fois', 'Interférence possible', 'Contrôle bien préparé'],
    ['Discordant (masse, dosage normal)', '—', 'Tumeur non sécrétante', 'Imagerie fonctionnelle, génétique'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Échographie puis IRM sans gadolinium ; médecine nucléaire contre-indiquée'],
    ['Enfant', 'Références adaptées à l’âge, centre pédiatrique (EXPeRT 2025)'],
    ['DFGe < 30 mL/min/1,73 m²', 'Métanéphrines plasmatiques libres préférées ; pas de produit de contraste iodé sans nécessité'],
    ['Allergie aux produits iodés', 'IRM'],
    ['Stimulateur cardiaque', 'Vérification de compatibilité avant IRM'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Les métanéphrines plasmatiques libres, prélevées couché et à jeun, sont l’examen de première intention. '
   'L’imagerie vient seulement après une hausse franche, pour localiser la tumeur. '
   'Toute tumeur confirmée conduit à une analyse génétique, et aucune biopsie n’est faite avant l’exérèse.', 12, 16, 17) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si des accès évocateurs ou un incidentalome sont présents, alors le médecin demande des métanéphrines bien préparées. '
   'Si la hausse est franche, alors il fait localiser la tumeur et adresse à un centre expert, mais une hausse modérée impose d’abord un contrôle. '
   'Si une crise survient, il hospitalise en soins intensifs.', 16, 17) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Métanéphrines normales, bonnes conditions', 'Autre cause des accès', 'Clinique'],
    ['Hausse modérée', 'Contrôle préparé, arrêt des produits interférents', 'Nouveau dosage'],
    ['Hausse franche', 'TDM ou IRM, génétique, centre expert', 'Blocage alpha'],
    ['Tumeur localisée', 'Blocage alpha 7 à 14 jours, puis chirurgie', 'Métanéphrines 2 à 6 semaines après'],
    ['Crise, choc, douleur thoracique', 'Soins intensifs', 'Équipe expérimentée'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Dose et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Cardura CR®, doxazosine à libération prolongée 4 ou 8 mg (alphabloquant alpha-1 sélectif), autorisation 54617', 'Indication AIPS : hypertension essentielle, 4 mg 1×/j, au maximum 8 mg/j ; comprimé avalé entier, jamais fractionné', 'Hypotension orthostatique, vertiges ; prudence avec les inhibiteurs de la PDE5 ; PPGL hors indication de la notice'],
   ['Bêtabloquant (classe)', 'Seulement après installation du blocage alpha, contre la tachycardie ; dose selon l’équipe', 'Jamais seul ni en premier : crise hypertensive ; labétalol non recommandé en préparation'],
   ['Welireg®, belzutifan, autorisation 68531', 'Pas d’indication PPGL dans la notice suisse', 'Aucune dose PPGL à prescrire'],
  ]) + P('Pharmacodynamie : la doxazosine bloque sélectivement et de façon compétitive les récepteurs alpha-1 et abaisse la résistance vasculaire. Pharmacocinétique : le pic survient vers 8 à 9 heures, la demi-vie est d’environ 22 heures et l’élimination est surtout hépatique (moins de 5 % inchangés par le rein).', 18) + P('Les doses de la préparation chirurgicale du PPGL sont fixées par le centre expert ; la notice suisse ne les fournit pas.', 16, 18, 20))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge vise l’exérèse de la tumeur sans crise, parce que la chirurgie supprime la source des catécholamines. '
   'Un blocage alpha de 7 à 14 jours précède l’opération, avec une cible assise < 130/80 mmHg et une systolique debout > 90 mmHg. '
   'Le bêtabloquant n’est ajouté qu’après, et le suivi est prolongé, souvent à vie.', 15, 16) +
 F('11.A Buts : formes compliquées et non compliquées',
   P('Forme compliquée (crise, choc, œdème pulmonaire, douleur thoracique) : c’est une urgence, avec soins intensifs dans l’heure et équipe expérimentée.', 16) +
   P('Dans la forme non compliquée, le but est l’exérèse préparée, sans crise peropératoire, puis la surveillance des récidives.', 15, 16)) +
 F('11.B Moyens',
   F('Mesures générales et ordre (forme non compliquée, préparation ambulatoire)',
     OL(['Centre expert multidisciplinaire.',
         'Blocage alpha de 7 à 14 jours, apports en eau et en sel.',
         'Bêtabloquant seulement après le blocage alpha si la tachycardie persiste.',
         'Surrénalectomie mini-invasive ; préservation corticale discutée dans les formes bilatérales.',
         'Analyse génétique et conseil aux apparentés.']), 15, 16, 17) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal (art. 25 et 32) prend en charge le bilan et la chirurgie ; la LAA (art. 6 et 9) ne s’applique pas ; la LAI (art. 7, 8 et 28) intervient si l’incapacité dure.',
         'L’arrêt de travail couvre la préparation et la convalescence ; aucun délai suisse universel de reprise professionnelle n’est publié.',
         'La conduite automobile est déconseillée pendant les accès et au début de l’alphabloquant (vertiges, notice).']), 21, 22, 23, 18) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Centre expert et maternité adaptée ; doxazosine seulement si nécessité absolue ; allaitement discuté'],
      ['Personne âgée', 'Hypotension orthostatique et chutes surveillées'],
      ['Enfant', 'Centre pédiatrique ; doxazosine non étudiée chez l’enfant (notice)'],
      ['Insuffisance hépatique', 'Doxazosine avec prudence (métabolisme hépatique)'],
      ['Insuffisance rénale (DFGe bas)', 'Métanéphrines plasmatiques libres ; doxazosine sans ajustement rénal'],
     ]), 17, 18, 19), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Pression couchée et debout, fréquence', 'Chaque jour pendant la préparation', 'Systolique debout < 90 mmHg : réduire'],
    ['Glycémie', 'Après l’exérèse', 'Hypoglycémie post-opératoire : traiter'],
    ['Métanéphrines', '2 à 6 semaines après l’exérèse', 'Hausse : tumeur résiduelle'],
    ['Métanéphrines, imagerie selon la génétique', 'Chaque année, souvent à vie', 'Récidive ou nouvelle tumeur'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['La pression et la glycémie sont stables.', 'La douleur est contrôlée et le patient mange.', 'Le patient connaît les signes d’alerte et le suivi endocrinien est fixé.'])) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic est bon après exérèse complète, mais une récidive ou une métastase reste possible, surtout avec un variant SDHB. Le suivi est donc prolongé et adapté à la génétique. La recherche 2026 évalue les thérapies ciblées comme le belzutifan, non autorisé en Suisse pour le PPGL.', 15, 16, 20))))
PTS.append(POINT(12, 'Prévention',
 P('Il n’existe pas de prévention primaire de la tumeur. '
   'La prévention secondaire repose en Suisse sur le dosage chez les personnes à risque et la surveillance des porteurs d’un variant génétique, selon les centres universitaires. '
   'La prévention tertiaire évite les crises par le blocage alpha et suit les récidives.', 14, 15, 17) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Aucune mesure validée'],
    ['Secondaire', 'Dépistage des apparentés porteurs d’un variant, bilan des incidentalomes'],
    ['Tertiaire', 'Blocage alpha avant geste, pas de bêtabloquant isolé, suivi annuel'],
   ]))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin sait que la triade et une hypertension isolée ne confirment pas un PPGL. '
   'Il dose les métanéphrines plasmatiques libres, couché et à jeun, sans attendre une crise. '
   'Il ne fusionne pas les seuils de 2 et 4 fois et ne biopsie jamais une masse suspecte. '
   'Il installe le blocage alpha avant tout bêtabloquant. '
   'Il propose une analyse génétique et un suivi prolongé.', 12, 16, 17)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Il faut prélever pendant une crise.', 'Non : la production de métanéphrines est continue.'],
  ['Un bêtabloquant d’abord pour la tachycardie.', 'Non : risque de crise par stimulation alpha non opposée.'],
  ['Biopsier la masse surrénalienne.', 'Non : le geste peut déclencher une crise.'],
  ['Une hausse modérée prouve la tumeur.', 'Non : contrôle préparé et recherche d’interférences.'],
  ['Fractionner Cardura CR® 4 mg pour 1 mg.', 'Non : le comprimé à libération prolongée ne se fractionne pas.'],
  ['Pas d’histoire familiale, donc pas de génétique.', 'Non : l’enquête génétique est systématique.'],
 ]) + P('Ces pièges reprennent l’ESH 2020, le protocole français 2021 et les AIPS.', 16, 17, 18)))
SOURCES = sorted([(k, v) for k, v in SB.items() if k >= 12]) + [
 (24, 'Lenders JWM et al. Pheochromocytoma and paraganglioma: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab 2014;99:1915–1942. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (25, 'de Jonge P et al. Cross-national epidemiology of panic disorder and panic attacks in the World Mental Health Surveys. Depress Anxiety 2016;33:1155–1177. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (26, 'Garmendia Madariaga A et al. The incidence and prevalence of thyroid dysfunction in Europe: a meta-analysis. J Clin Endocrinol Metab 2014;99:923–931. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (27, 'Office fédéral de la statistique (OFS). Enquête suisse sur la santé 2022 : diabète. Neuchâtel : OFS. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (28, 'The Menopause Society. The 2023 nonhormone therapy position statement. Menopause 2023;30:573–590. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (29, 'Mancia G et al. 2023 ESH Guidelines for the management of arterial hypertension. J Hypertens 2023;41:1874–2071. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
]
CTX = {'_prefixe': 'Dans le phéochromocytome',
 'meta': 'Les métanéphrines plasmatiques libres, prélevées couché et à jeun, sont l’examen de première intention ; une hausse > 2 fois (ESH) ou > 4 fois (protocole français) la limite justifie l’imagerie.',
 'tdm': 'La TDM abdominale localise la tumeur après une preuve biochimique.',
 'irm': 'L’IRM localise la tumeur sans irradiation, notamment pendant la grossesse.',
 'tep': 'La TEP spécifique cherche une tumeur multiple ou métastatique.',
 'scinti': 'L’imagerie fonctionnelle complète la localisation selon la génétique.',
 'gen': 'L’analyse génétique est proposée pour tout PPGL confirmé, avec information et consentement (LAGH).',
 'gly': 'La glycémie est surveillée après l’exérèse (hypoglycémie).',
 'tsh': 'La TSH écarte une hyperthyroïdie devant des accès de palpitations.',
 'ecg': 'L’ECG recherche une arythmie ou une ischémie pendant un accès.',
 'echocoeur': 'L’échocardiographie cherche une cardiomyopathie de stress.',
 'creat': 'En insuffisance rénale, les métanéphrines plasmatiques libres sont préférées.',
 'cort': 'Le bilan d’un incidentalome recherche aussi un hypercortisolisme.',
 'hcg': 'Le test de grossesse précède l’imagerie et le traitement.',
 'tox': 'La toxicologie recherche cocaïne ou amphétamines devant des accès adrénergiques.',
 'mapa': 'La mesure ambulatoire de pression documente les pics tensionnels.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
