# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.3 · Endocardite infectieuse (LOT 1, Appel B, Partie 2, r1 → audit du 24.10.2026)."""
import sys; sys.path.insert(0, '/workspace/audit_1_10/outils')
from gen_v7 import *
from src_P2 import SOURCES_ORIG
POINT = mkPOINT('dx3')
M = dict(pref='dx3', dx='DX.3', court='Endocardite', long='Endocardite infectieuse', dossier='corriges/LOT_001',
         fichier='LOT_001_DX3_Endocardite_infectieuse_AUDITÉ.html', lot_titre='LOT 1 · G1 · Transpiration anormale',
         sous_titre='PROFILES 2023 · SSP G1 · LOT 1 · Appel B · V7 · version AUDITÉE',
         statut='Cette version corrige la monographie DX.3 du LOT 1 (Appel B, V7, Partie 2, révision r1) après audit médical et linguistique ; elle rétablit l’ordre des points 8 et 9 et le titre du point 10.')
VEG = T('végétation', 'La végétation est une masse oscillante de fibrine, de plaquettes et de bactéries fixée sur l’endocarde valvulaire ou sur un matériel ; elle se mesure en millimètres à l’échocardiographie, car sa taille prédit le risque embolique.')
HACEK = T('groupe HACEK', 'Le groupe HACEK réunit des bacilles à Gram négatif de la flore buccale à croissance lente : Haemophilus, Aggregatibacter, Cardiobacterium, Eikenella, Kingella.')
BCNEG = T('endocardite à hémocultures négatives', 'L’endocardite à hémocultures négatives survient surtout après une antibiothérapie préalable ; sinon elle évoque Coxiella burnetii, Bartonella, Tropheryma whipplei, Brucella ou des champignons, recherchés par sérologie et PCR sur la valve.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'L’endocardite infectieuse est une infection de l’endocarde, le plus souvent valvulaire, qui forme une {VEG} et détruit le tissu. '
   'Elle peut toucher une valve native, une prothèse valvulaire ou un dispositif intracardiaque (stimulateur, défibrillateur), et cette distinction change les germes, la durée du traitement et la chirurgie. '
   'Elle explique des sueurs nocturnes et une fièvre prolongée, car la bactériémie est continue.', 5) +
 F('Terminologie',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Endocardite sur valve native', 'Infection d’une valve sans matériel prothétique', 'Endocardite sur prothèse, plus grave'],
    ['Endocardite précoce sur prothèse', 'Survenue < 12 mois après la chirurgie : germes nosocomiaux (staphylocoques)', 'Endocardite tardive (≥ 12 mois), proche de l’endocardite native'],
    ['Infection de dispositif', 'Atteinte des sondes ou du boîtier d’un stimulateur ou d’un défibrillateur', 'Infection superficielle de la loge'],
    ['Endocardite du cœur droit', 'Atteinte tricuspide, typique chez la personne qui s’injecte des drogues', 'Pneumonie : les emboles septiques pulmonaires imitent une pneumonie'],
    ['Endocardite à hémocultures négatives', 'Hémocultures stériles malgré une endocardite', 'Absence d’endocardite'],
    ['Endocardite non infectieuse', 'Végétation stérile liée à un cancer, un lupus ou un syndrome des antiphospholipides', 'Endocardite à germe difficile à cultiver ; dans l’endocardite de Libman-Sacks (lupus), les hémocultures restent stériles'],
   ]) + P(f'Le terme {BCNEG} appelle une enquête microbiologique spécifique.', 5))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, une cohorte nationale a recensé 15 255 hospitalisations pour endocardite de 2012 à 2021, avec une hausse de 1361 à 1636 par an, et la part de Staphylococcus aureus est passée de 19,8 % à 30,0 %. '
   'En Europe, l’incidence est estimée à 3–10 cas pour 100 000 habitants par an selon l’ESC 2023, et la mortalité hospitalière atteint environ 17 % dans le registre EURO-ENDO (European Endocarditis Registry). '
   'Les facteurs de terrain sont l’âge, les prothèses valvulaires et les dispositifs intracardiaques, l’hémodialyse, l’injection de drogues et les soins invasifs. '
   'Dans le sous-groupe suisse à S. aureus, la mortalité est de 19,9 % à l’hôpital et de 30,3 % à six mois.', 8, 5) +
 F('Chiffres, terrain et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Hospitalisations en Suisse (2012–2021)', '15 255 ; de 1361 à 1636 par an', 'Séjours, pas des personnes uniques (Buergler 2025)'],
    ['Part de S. aureus en Suisse', 'de 19,8 % à 30,0 %', 'Premier germe actuel'],
    ['Part des streptocoques en Suisse', 'de 17,6 % à 24,4 %', 'Origine buccale ou digestive'],
    ['S. aureus en Suisse : mortalité hospitalière, à 6 mois, soins intensifs', '19,9 %, 30,3 %, 44,2 %', 'Sous-groupe le plus grave'],
    ['Récidive chez les survivants', 'environ 2–9 %', 'Études citées par l’ESC 2023'],
   ]) + P('Sans traitement, l’endocardite est presque toujours mortelle ; avec antibiotiques et chirurgie au bon moment, la survie à un an dépasse 70 %. Le profil a changé : la maladie touche aujourd’hui surtout des personnes âgées avec matériel et soins invasifs, plus seulement des valvulopathies rhumatismales.', 5, 8))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Une lésion de l’endocarde (valvulopathie, prothèse, sonde, jet de régurgitation) se couvre d’un dépôt de plaquettes et de fibrine stérile. '
   'Lors d’une bactériémie, même transitoire, des germes adhérents (S. aureus, streptocoques oraux, entérocoques) colonisent ce dépôt et forment une végétation protégée des défenses. '
   'La végétation détruit la valve, provoque des abcès, embolise vers le cerveau, la rate, les reins ou les poumons et déclenche des complexes immuns. '
   'Le traitement repose donc sur des antibiotiques bactéricides à forte dose et prolongés, et la chirurgie retire le foyer lorsque les antibiotiques ne suffisent pas.', 5) +
F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'L’endocarde est la fine couche lisse qui tapisse l’intérieur du cœur et les valves ; les valves n’ont pas de vaisseaux propres.'],
    ['Physiologie', 'Pourquoi le cœur sain résiste : un endothélium intact et lisse empêche les bactéries de s’accrocher, même lors des petites bactériémies quotidiennes (brossage des dents).'],
    ['Physiopathologie', 'Une valve abîmée ou un matériel se couvre de plaquettes et de fibrine ; les bactéries s’y fixent et forment une végétation, à l’abri des globules blancs puisque la valve n’est pas vascularisée.'],
    ['Clinique', 'D’où trois familles de signes : infection (fièvre, sueurs), destruction de la valve (souffle, insuffisance cardiaque), fragments qui partent dans le sang (embolies).'],
    ['Examens', 'La bactériémie est continue : les hémocultures sont positives sans attendre un pic fébrile ; la végétation se voit à l’échocardiographie.'],
    ['Traitement', 'Les antibiotiques diffusent mal dans une végétation non vascularisée : il faut des doses fortes, bactéricides et longues, et la chirurgie quand la valve est détruite.'],
   ]), 5) +
 F('Lésion, exploration et cible thérapeutique',
   TAB(['Lésion', 'Exploration', 'Cible thérapeutique'], [
    ['Végétation infectée', 'Hémocultures, échocardiographie transthoracique puis transœsophagienne', 'Antibiotique bactéricide prolongé'],
    ['Destruction valvulaire (perforation, rupture de cordage)', 'Échocardiographie, NT-proBNP', 'Chirurgie en urgence si insuffisance cardiaque'],
    ['Abcès péri-annulaire, fistule', 'Échocardiographie transœsophagienne, TDM cardiaque, TEP-TDM au FDG', 'Chirurgie urgente'],
    ['Emboles septiques', 'IRM cérébrale, TDM thoraco-abdominale', 'Antibiotique ; chirurgie si végétation ≥ 10 mm avec embolie'],
    ['Complexes immuns', 'Sédiment urinaire, créatinine, facteur rhumatoïde', 'Contrôle de l’infection'],
    ['Anévrisme mycotique', 'Angio-TDM ou angio-IRM cérébrale', 'Traitement endovasculaire ou chirurgical'],
   ]))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin recherche d’abord un sepsis, une insuffisance cardiaque aiguë ou un déficit neurologique, qui imposent une prise en charge immédiate. '
   'Il prélève ensuite les hémocultures avant tout antibiotique et demande une échocardiographie, puis il applique les critères ESC 2023 et les réévalue pendant l’hospitalisation. '
   'Des hémocultures stériles ou une échocardiographie initiale normale ne suffisent pas à exclure le diagnostic lorsque la suspicion reste forte.', 5, 11) +
 F('Diagnostic différentiel d’une fièvre prolongée avec sueurs (fréquence sourcée en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Endocardite infectieuse' + PR('≈ 1600 hospitalisations par an en Suisse', 8) + PR('3–10 / 100 000 par an (Europe)', 5), 'Souffle nouveau, matériel cardiaque, embolies, bactériémie à germe typique', 'Hémocultures, échocardiographie'],
    ['Tuberculose' + PR('≈ 5 / 100 000 par an (Suisse)', 34), 'Toux, perte de poids, exposition', 'Radiographie thoracique, recherche de mycobactéries'],
    ['Lymphome non hodgkinien' + PR('≈ 20 / 100 000 par an (Suisse)', 35), 'Adénopathies, prurit, sueurs nocturnes', 'Biopsie ganglionnaire'],
    ['Spondylodiscite' + PR('0,4–2,4 / 100 000 par an', 36), 'Douleur rachidienne ; elle accompagne souvent l’endocardite', 'IRM rachidienne'],
    ['Infection de stimulateur ou de défibrillateur' + PR('≈ 1–2 % des porteurs', 37), 'Sonde, loge inflammatoire', 'Hémocultures, ETO, TEP-TDM'],
    ['Lupus érythémateux systémique' + PR('≈ 30–70 / 100 000 (Europe)', 38), 'Arthralgies, éruption, atteinte multisystémique', 'Bilan immunologique ; hémocultures négatives'],
    ['Myxome de l’oreillette' + PR('tumeurs cardiaques primitives ≈ 0,02 % (autopsies)', 39), 'Embolies, signes généraux, masse pédiculée', 'Échocardiographie'],
   ]) + P('Ces fréquences sont des incidences ou des prévalences en population, pas des probabilités devant un patient : avec un souffle nouveau et des hémocultures positives à germe typique, l’endocardite devient le premier diagnostic.', 5, 8))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’anamnèse précise la durée de la fièvre, le matériel cardiaque, les soins récents, l’injection de drogues et une antibiothérapie déjà prise, puis elle recherche des symptômes d’emboles et d’insuffisance cardiaque. '
   'Un drapeau rouge impose l’appel du 144 ou un transfert vers un centre disposant de chirurgie cardiaque.', 5, 9) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis quand avez-vous de la fièvre et des sueurs ?', 'Une forme subaiguë évolue sur des semaines.', 'Elle oriente vers des streptocoques ; une forme aiguë vers S. aureus.'],
    ['Avez-vous une valve artificielle, un stimulateur ou une maladie valvulaire connue ?', 'Le matériel est le premier terrain.', 'Échocardiographie transœsophagienne d’emblée ; TEP-TDM.'],
    ['Avez-vous eu des soins dentaires, une coloscopie, un cathéter récemment ?', 'Ils indiquent la porte d’entrée.', 'Germe attendu et bilan de la porte d’entrée.'],
    ['Vous injectez-vous des drogues ?', 'Endocardite tricuspide à S. aureus.', 'Radiographie thoracique et dépistage du VIH et des hépatites.'],
    ['Avez-vous déjà pris des antibiotiques pour cette fièvre ?', 'Ils stérilisent les hémocultures.', 'Sérologies et PCR ; prudence d’interprétation.'],
    ['Avez-vous eu une faiblesse d’un membre, un trouble de la vue, une douleur du flanc ?', 'Emboles cérébraux, rétiniens, rénaux ou spléniques.', 'IRM cérébrale, TDM abdominale.'],
    ['Êtes-vous essoufflé couché ?', 'Insuffisance valvulaire aiguë.', 'Chirurgie urgente.'],
   ])) +
 U('<b>Drapeaux rouges (144, avis de chirurgie cardiaque)</b> : choc septique, œdème pulmonaire ou choc cardiogénique, déficit neurologique, bloc auriculoventriculaire nouveau (abcès), prothèse valvulaire infectée, hémocultures persistantes sous traitement.', 5)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen débute par la séquence ABCDE (Airway, Breathing, Circulation, Disability, Exposure) et mesure la température. '
   'Il ausculte le cœur à la recherche d’un souffle nouveau, puis il cherche les signes emboliques et immunologiques sur la peau, les ongles et le fond d’œil. '
   'Un examen normal n’exclut pas l’endocardite, mais un souffle nouveau chez un patient fébrile impose des hémocultures.', 4, 5) +
 F('Normal, anomalie, valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Auscultation cardiaque aux quatre foyers, en décubitus latéral gauche et penché en avant', 'B1, B2 sans souffle', 'Souffle nouveau de régurgitation (environ 85 % des cas) : atteinte valvulaire'],
    ['Inspection des ongles et des doigts', 'Lit unguéal rose', 'Hémorragies en flammèches sous-unguéales ; hippocratisme dans les formes anciennes'],
    ['Palpation de la pulpe des doigts et des orteils', 'Pulpe indolore', 'Nodules d’Osler douloureux (phénomène immunologique)'],
    ['Inspection des paumes et des plantes', 'Peau normale', 'Lésions de Janeway indolores (emboles)'],
    ['Conjonctives, fond d’œil', 'Sans lésion', 'Pétéchies conjonctivales ; taches de Roth'],
    ['Palpation de la rate', 'Rate non palpable', 'Splénomégalie dans les formes subaiguës'],
    ['Examen neurologique', 'Normal', 'Déficit focal : embolie cérébrale'],
   ]) + P('Les signes cutanés sont spécifiques mais peu sensibles (présents chez moins de 10 à 20 % des patients) ; leur absence ne change pas la conduite.', 5))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Le syndrome infectieux associe fièvre (environ 90 % des cas), sueurs, frissons, amaigrissement et asthénie. '
   'Le syndrome cardiaque associe un souffle nouveau et, en cas de destruction valvulaire, une insuffisance cardiaque, tandis que le syndrome embolique et le syndrome immunologique traduisent la dissémination. '
   'Les signes fonctionnels (sueurs, dyspnée, douleurs) se distinguent des signes physiques (fièvre mesurée, souffle, nodules, splénomégalie).', 5) +
 F('Signes définis',
   TAB(['Signe ou syndrome', 'Description', 'Mécanisme'], [
    ['Fièvre et sueurs nocturnes', 'Fièvre > 38 °C prolongée, sueurs profuses', 'Bactériémie continue et cytokines'],
    ['Souffle nouveau', 'Régurgitation mitrale ou aortique', 'Perforation ou destruction valvulaire'],
    ['Insuffisance cardiaque', 'Dyspnée, orthopnée, râles crépitants', 'Régurgitation aiguë'],
    ['Syndrome embolique', 'Déficit neurologique, douleur splénique ou lombaire, ischémie de membre, lésions de Janeway', 'Fragments de végétation'],
    ['Syndrome immunologique', 'Nodules d’Osler, taches de Roth, glomérulonéphrite, facteur rhumatoïde positif', 'Complexes immuns'],
    ['Bloc auriculoventriculaire', 'Allongement du PR à l’ECG', 'Abcès de l’anneau aortique'],
    ['Emboles pulmonaires septiques', 'Toux, douleur pleurale, nodules excavés', 'Endocardite tricuspide'],
   ]))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Les critères de Duke modifiés par l’ESC en 2023 combinent des critères majeurs, microbiologiques et d’imagerie, et des critères mineurs, cliniques et microbiologiques. '
   'L’endocardite est certaine avec deux majeurs, un majeur et trois mineurs, ou cinq mineurs, et possible avec un majeur et un ou deux mineurs, ou trois à quatre mineurs. '
   'Un critère isolé ne suffit pas, et la classification se réévalue avec les résultats successifs.', 5, 6, 7) +
 F('Critères ESC 2023 détaillés',
   TAB(['Catégorie', 'Critère', 'Seuil'], [
    ['Majeur microbiologique', f'Germe typique (streptocoques oraux, S. gallolyticus, {HACEK}, S. aureus, E. faecalis) dans au moins 2 hémocultures séparées', 'Ou hémocultures persistantes, ou Coxiella : 1 hémoculture ou IgG de phase I > 1/800'],
    ['Majeur d’imagerie', 'Végétation, abcès, pseudo-anévrisme, perforation, fistule, désinsertion nouvelle de prothèse', 'Échocardiographie ou TDM cardiaque'],
    ['Majeur d’imagerie nucléaire', 'Fixation anormale autour d’une prothèse ou d’un dispositif', 'TEP-TDM au FDG > 3 mois après l’implantation'],
    ['Mineurs', 'Prédisposition, fièvre > 38 °C, emboles (même asymptomatiques à l’imagerie), phénomènes immunologiques, microbiologie non majeure', '—'],
    ['Exclusion', 'Autre diagnostic ferme, guérison sous ≤ 4 jours d’antibiotique, absence de lésion à la chirurgie ou à l’autopsie', '—'],
   ]) + P('Exemple : deux hémocultures à S. aureus (un majeur), une fièvre et une prothèse (deux mineurs) donnent une endocardite possible ; une végétation à l’échocardiographie la rend certaine.', 5))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Hémocultures (3 séries)', 'Germe et sensibilité', 'Positives dans environ 85–90 % des cas sans antibiotique préalable', 'Stérilisées par un antibiotique antérieur'],
    ['Échocardiographie transthoracique', 'Végétation, régurgitation, fonction', 'Sensibilité d’environ 70 % sur valve native, 50 % sur prothèse', 'Fenêtre acoustique, petites végétations'],
    ['Échocardiographie transœsophagienne', 'Végétation, abcès, perforation', 'Sensibilité d’environ 96 % (native) et 92 % (prothèse), spécificité d’environ 90 %', 'Invasive, sédation'],
    ['Histologie et culture de la valve opérée', 'Preuve définitive : examen de référence (gold standard)', 'Référence', 'Seulement si chirurgie'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Hémocultures : 3 séries à 30 min d’intervalle, veine périphérique, avant antibiotique', 'Toujours ; sans attendre un pic fébrile'],
    ['Première', 'Échocardiographie transthoracique', 'Dès la suspicion'],
    ['Première', 'Formule sanguine, CRP, créatinine, sédiment urinaire, ECG', 'Bilan de retentissement'],
    ['Seconde', 'Échocardiographie transœsophagienne', 'ETT négative avec forte suspicion, prothèse ou dispositif, ETT positive (recherche d’abcès) ; à répéter à 5–7 jours si négative'],
    ['Seconde', 'TEP-TDM au FDG, TDM cardiaque', 'Endocardite sur prothèse ou dispositif possible'],
    ['Seconde', 'IRM cérébrale, TDM thoraco-abdominale', 'Recherche d’emboles, avant la chirurgie'],
    ['Seconde', 'Sérologies Coxiella et Bartonella, PCR sur valve', 'Hémocultures négatives'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Les <b>hémocultures</b> se prélèvent avant tout antibiotique, avec désinfection cutanée, 10 mL par flacon aérobie et anaérobie ; en sepsis, on prélève deux paires puis on donne l’antibiotique dans l’heure sans attendre (procédure HUG 2025).',
       'L’<b>échocardiographie transœsophagienne</b> exige un jeûne de 6 heures, une anesthésie locale du pharynx et souvent une sédation.',
       'La <b>TEP-TDM</b> exige un jeûne d’au moins 6 heures et un régime pauvre en glucides la veille ; elle n’est pas interprétable dans les 3 mois après l’implantation d’une prothèse.',
       'Le <b>produit de contraste iodé</b> se donne après vérification du DFGe ; l’IRM vérifie la compatibilité d’un stimulateur.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['2 hémocultures positives à germe typique', '≥ 2 séries', 'Critère majeur', 'Échocardiographie, antibiotique ciblé'],
    ['Hémocultures positives à 48–72 h de traitement', 'Persistance', 'Infection non contrôlée', 'Recherche d’abcès, discussion chirurgicale'],
    ['Végétation', '≥ 10 mm', 'Risque embolique élevé', 'Chirurgie si embolie ou valvulopathie sévère'],
    ['Végétation mobile', '> 30 mm', 'Risque très élevé', 'Chirurgie à discuter même sans embolie'],
    ['Résultat négatif (ETT et ETO normales)', '—', 'Diagnostic moins probable', 'Répéter l’ETO à 5–7 jours si la suspicion persiste'],
    ['Résultat limite ou discordant (hémocultures négatives, végétation)', '—', 'Germe difficile ou endocardite non infectieuse', 'Sérologies, PCR, bilan immunologique'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Échocardiographies sans restriction ; IRM sans gadolinium ; TEP-TDM évitée'],
    ['Enfant', 'Échocardiographie transthoracique souvent suffisante ; volumes d’hémoculture adaptés au poids'],
    ['DFGe abaissé', 'TDM avec contraste après pesée du bénéfice (ESUR), car la chirurgie dépend de l’imagerie'],
    ['Stimulateur ou défibrillateur', 'ETO et TEP-TDM ; IRM seulement si le système est compatible'],
    ['Allergie à l’iode rapportée', 'Préciser la réaction ; elle ne contre-indique pas l’échocardiographie ni la TEP'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Les hémocultures et l’échocardiographie sont les deux examens de première intention, et l’histologie de la valve opérée reste le gold standard. '
   'L’échocardiographie transœsophagienne, plus sensible que la transthoracique, s’impose en seconde intention en cas de prothèse, de dispositif ou de doute. '
   'La TEP-TDM et la TDM cardiaque complètent le diagnostic sur prothèse, et l’imagerie cérébrale recherche les emboles.', 5, 11) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si le patient est en sepsis ou en insuffisance cardiaque, alors le médecin prélève deux paires d’hémocultures, débute l’antibiotique empirique dans l’heure et appelle l’équipe de chirurgie cardiaque. '
   'S’il est stable, il prélève trois séries d’hémocultures avant l’antibiotique et demande une échocardiographie. '
   'Une indication chirurgicale se discute ensuite en équipe pluridisciplinaire (endocarditis team).', 5, 11) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Choc ou œdème pulmonaire par régurgitation aiguë', 'Chirurgie en urgence (< 24 h)', 'Soins intensifs'],
    ['Abcès, fistule, germe multirésistant ou fongique, hémocultures positives > 7 jours de traitement adapté', 'Chirurgie urgente (3–5 jours)', 'ETO, TEP-TDM'],
    ['Végétation ≥ 10 mm avec embolie ou avec valvulopathie sévère', 'Chirurgie urgente (3–5 jours)', 'IRM cérébrale'],
    ['Patient stable, ETT négative et forte suspicion', 'ETO', 'Répétée à 5–7 jours si négative'],
    ['Hémocultures négatives', 'Sérologies, PCR, réévaluation d’une antibiothérapie préalable', 'Avis infectiologique'],
    ['Patient stable après ≥ 10 jours IV, cultures négatives, pas d’abcès', 'Relais oral possible (étude POET)', 'Suivi ambulatoire rapproché'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS et ESC 2023)',
  TAB(['Médicament (classe)', 'Dose et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Amoxicilline, Amoxicillin Delbert® (pénicilline A)', 'Endocardite à streptocoque ou à E. faecalis : 100–200 mg/kg/j IV en 4–6 doses (ESC corrigé) ; enfant > 3 mois et < 40 kg : jusqu’à 200 mg/kg/j, au plus 50 mg/kg par dose ; 4 à 6 semaines', 'Allergie (anaphylaxie), éruption, diarrhée à Clostridioides difficile ; allaitement déconseillé ; interactions : méthotrexate (toxicité accrue), antivitamines K (contrôle de l’INR)'],
   ['Flucloxacilline, Flucloxacilline Stragen® (pénicilline antistaphylococcique)', 'S. aureus sensible à la méticilline : 12 g/j IV en 4–6 doses, 4–6 semaines (valve native) ; demi-vie de 53 min ; liaison protéique de 95 %', 'Hépatite cholestatique ; contre-indiquée après un ictère lié à la flucloxacilline ; DFGe < 10 mL/min : au plus 1 g/8–12 h ; interactions : tacrolimus, voriconazole, paracétamol (acidose à trou anionique élevé) ; l’ESC déconseille d’y ajouter un aminoside sur valve native, contrairement à la notice'],
   ['Vancomycine, Vancomycine Sandoz® (glycopeptide)', '15–20 mg/kg/8–12 h, au plus 2 g par dose ; charge de 25–30 mg/kg chez le patient critique ; perfusion ≥ 60 min et ≤ 10 mg/min ; ClCr 20–49 mL/min : 15–20 mg/kg/24 h', 'Demi-vie de 4–6 h (rein normal) ; néphrotoxicité, ototoxicité, hypotension et réaction à la perfusion trop rapide ; surveillance des concentrations'],
   ['Ceftriaxone, Ceftriaxon Labatec® (céphalosporine de 3e génération)', 'Streptocoque : 2 g/j IV ; E. faecalis : 2 g/12 h en association à l’amoxicilline ; 4 à 6 semaines', 'Précipitation avec le calcium chez le nouveau-né, lithiase biliaire ; indication formelle pendant la grossesse'],
   ['Gentamicine, Gentamicine AApot® (aminoside)', 'AIPS adulte : 3 mg/kg/j en 3 doses (jusqu’à 5 mg/kg/j si menace vitale) ; en endocardite, seulement dans des indications précises (prothèse précoce, avis infectiologique)', 'Néphrotoxicité et ototoxicité cumulatives ; interaction avec la vancomycine et les diurétiques de l’anse'],
   ['Rifampicine (rifamycine)', 'Ajoutée seulement en présence de matériel, après 3–5 jours de traitement efficace et contrôle de la bactériémie', 'Inducteur enzymatique puissant (anticoagulants, contraceptifs) ; urines orangées'],
  ]) + P('Le traitement empirique d’une endocardite communautaire sur valve native associe, selon l’ESC 2023, l’amoxicilline (ou l’ampicilline) à la ceftriaxone ou à la flucloxacilline ; une endocardite nosocomiale ou précoce sur prothèse reçoit de la vancomycine avec de la gentamicine, puis de la rifampicine. La durée se compte à partir du premier jour de traitement efficace avec cultures négatives : 2 à 6 semaines sur valve native, au moins 6 semaines sur prothèse.', 5, 6, 7, 12, 13, 14, 15, 16))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge traite d’abord le sepsis et l’insuffisance cardiaque, puis elle éradique l’infection par des antibiotiques bactéricides prolongés et par la chirurgie si ceux-ci ne suffisent pas. '
   'Les décisions se prennent en équipe pluridisciplinaire (cardiologue, infectiologue, chirurgien cardiaque), parce que le moment de la chirurgie conditionne la survie. '
   'L’endocardite n’est pas en elle-même une indication à un antiagrégant ou à un anticoagulant.', 5) +
 F('11.A Buts : traiter l’urgence compliquée, puis stériliser et réparer',
   P('Dans la forme compliquée, le but immédiat est de restaurer l’hémodynamique et d’opérer dans les 24 heures en cas d’œdème pulmonaire ou de choc. Ensuite, le but est des hémocultures négatives en moins de 72 heures, une absence d’embolie nouvelle et une valve fonctionnelle. À distance, le but est zéro récidive grâce à l’hygiène bucco-dentaire et à la prophylaxie ciblée.', 5), 'fenetre') +
 F('11.B Moyens',
   F('Forme compliquée : chronologie de l’urgence',
     TAB(['Temps', 'Geste'], [
      ['Heure 0', 'Deux paires d’hémocultures, antibiotique empirique dans l’heure, remplissage, noradrénaline si choc'],
      ['< 24 h', 'Chirurgie en urgence si œdème pulmonaire ou choc cardiogénique par régurgitation'],
      ['3–5 jours', 'Chirurgie urgente si infection non contrôlée ou prévention embolique'],
      ['AVC ischémique', 'La chirurgie n’est pas retardée si l’hémorragie est exclue et le coma absent ; une hémorragie intracrânienne la fait différer'],
     ]), 5) +
   F('Forme non compliquée : mesures générales et ordre',
     OL(['Hémocultures puis antibiotique empirique adapté au terrain, relayé par l’antibiotique ciblé dès l’antibiogramme.',
         'Recherche et traitement de la porte d’entrée (soins dentaires, cathéter, lésion cutanée, côlon pour S. gallolyticus).',
         'Retrait de tout dispositif intracardiaque infecté.',
         'Surveillance de l’infection, des concentrations d’antibiotiques et des fonctions rénale et auditive.',
         'Relais oral après au moins 10 jours IV chez des patients stables sélectionnés (ESC 2023, classe IIa).']), 5) +
   MED +
   F('Traitement non médicamenteux et chirurgie',
     P('La chirurgie valvulaire (réparation ou remplacement) est nécessaire chez environ la moitié des patients ; elle retire le tissu infecté et corrige la régurgitation. L’extraction complète du stimulateur ou du défibrillateur s’impose en cas d’infection de dispositif. L’assainissement dentaire fait partie du traitement.', 5)) +
   F('Volets social et professionnel',
     UL(['La LAMal (art. 25 et 32) couvre l’hospitalisation et l’antibiothérapie ambulatoire ; les soins dentaires ne sont couverts que s’ils sont nécessaires au traitement d’une maladie grave (art. 31 LAMal), par exemple l’assainissement avant une chirurgie valvulaire.',
         'La LAA intervient seulement en cas d’accident ou de maladie professionnelle reconnue (soignant exposé) ; la LAI (art. 7, 8 et 28) soutient la réadaptation si une séquelle neurologique ou cardiaque persiste.',
         'L’arrêt de travail couvre au moins la durée du traitement IV puis la convalescence, souvent plusieurs semaines après une chirurgie.',
         'La conduite automobile est suspendue après une embolie cérébrale ou une chirurgie cardiaque, selon l’annexe 1 de l’OAC et l’avis du médecin.']), 2, 3, 33) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Pénicillines et ceftriaxone préférées ; aminosides et vancomycine avec surveillance stricte ; décision cardiaque et obstétricale commune ; allaitement suspendu sous amoxicilline selon l’AIPS.'],
      ['Personne âgée', 'Présentation peu fébrile, néphrotoxicité accrue ; chirurgie discutée selon la fragilité.'],
      ['Enfant', 'Doses par kilo de l’AIPS (amoxicilline jusqu’à 200 mg/kg/j) ; cardiopathie congénitale fréquente ; avis de cardiologie pédiatrique.'],
      ['Insuffisance hépatique', 'Flucloxacilline à surveiller (cholestase) ; rifampicine à éviter si l’atteinte est sévère.'],
      ['Insuffisance rénale (DFGe)', 'Vancomycine et gentamicine adaptées aux concentrations ; ceftriaxone sans adaptation habituelle.'],
     ]), 12, 13, 14, 15, 16), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Hémocultures de contrôle', 'À 48–72 h de traitement, puis jusqu’à négativation', 'Positives : recherche d’abcès, discussion chirurgicale'],
    ['Température, CRP', 'Quotidiennement puis 2 fois par semaine', 'Fièvre > 7 jours : complication, foyer, allergie médicamenteuse'],
    ['Vancomycine (concentration résiduelle ou AUC)', 'Avant la 4e dose puis 1–2 fois par semaine', 'Hors cible : adaptation'],
    ['Créatinine, audition (gentamicine, vancomycine)', '2 fois par semaine', 'Hausse de créatinine, vertige, baisse d’audition : réévaluation'],
    ['ECG', 'Régulièrement', 'Allongement du PR : abcès'],
    ['Échocardiographie', 'En cas de changement clinique et à la fin du traitement', 'Progression : chirurgie'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Apyrexie et hémocultures négatives.', 'Absence d’abcès ou de complication non traitée à l’ETO.', 'Au moins 10 jours d’antibiotique IV (dont 7 jours après une chirurgie) avant un relais ambulatoire.',
       'Relais oral ou parentéral ambulatoire organisé avec suivi rapproché.', 'Porte d’entrée traitée et soins dentaires planifiés.', 'Patient informé des signes de rechute et de la prophylaxie future.']), 5, 11) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La mortalité hospitalière reste d’environ 15–20 %, plus élevée avec S. aureus, une prothèse, une insuffisance cardiaque ou un AVC. Les survivants gardent un risque de récidive de 2–9 % et souvent une valvulopathie séquellaire. La recherche 2026 évalue la TEP-TDM, les relais oraux plus précoces et les antibiotiques à longue demi-vie (dalbavancine) pour raccourcir l’hospitalisation.', 5, 8), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur une bonne hygiène bucco-dentaire, l’asepsie des cathéters et la réduction des risques chez les personnes qui s’injectent des drogues. '
   'La prophylaxie antibiotique est réservée, selon les recommandations suisses de 2021 et 2025, aux patients à haut risque avant un soin dentaire qui manipule la gencive ou la région périapicale. '
   'La prévention secondaire et tertiaire comporte un suivi dentaire semestriel et l’éducation à consulter vite en cas de fièvre.', 9, 10) +
 F('Prophylaxie et niveaux de prévention',
   TAB(['Niveau', 'Mesure', 'Détail'], [
    ['Primaire', 'Hygiène bucco-dentaire, contrôle dentaire 2 fois par an', 'Pour tout patient avec valvulopathie'],
    ['Primaire', 'Asepsie des voies veineuses, programmes d’échange de seringues', 'Réduit les endocardites nosocomiales et tricuspides'],
    ['Secondaire (haut risque)', 'Amoxicilline 2 g per os (enfant 50 mg/kg, au plus 2 g) une heure avant le soin dentaire', 'Prothèse valvulaire (y compris TAVI), endocardite antérieure, cardiopathie congénitale cyanogène, assistance ventriculaire'],
    ['Secondaire', 'Allergie à la pénicilline : alternative selon la recommandation suisse 2025', 'La clindamycine n’est plus recommandée (ESC 2023)'],
    ['Tertiaire', 'Carte de prophylaxie, consultation rapide en cas de fièvre', 'Hémocultures avant tout antibiotique'],
   ]) + P('La dose de 2 g provient de la recommandation suisse ; l’AIPS de l’Amoxicilline Sandoz® en donne une autre (3 g), et la prescription doit suivre la recommandation suisse actuelle.', 9, 17))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin pense à l’endocardite devant une fièvre avec sueurs et un souffle, une prothèse, un dispositif ou une injection de drogues. '
   'Il prélève trois séries d’hémocultures avant l’antibiotique, sauf en sepsis où l’antibiotique part dans l’heure. '
   'Il demande une ETT puis une ETO, et il applique les critères ESC 2023. '
   'Il traite par antibiotiques bactéricides de 2 à 6 semaines et discute la chirurgie en équipe dès une complication. '
   'Il réserve la prophylaxie à l’amoxicilline aux patients à haut risque avant un soin dentaire.', 5, 9)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Attendre un pic fébrile pour prélever', 'Les hémocultures se prélèvent sans attendre : la bactériémie est continue.'],
  ['Donner un antibiotique avant les hémocultures chez un patient stable', 'Il stérilise les cultures et retarde le diagnostic.'],
  ['Exclure l’endocardite sur une ETT normale', 'L’ETO est indiquée si la suspicion persiste.'],
  ['Anticoaguler pour prévenir les embolies', 'L’endocardite n’est pas une indication à l’anticoagulation.'],
  ['Ajouter de la gentamicine à la flucloxacilline sur valve native', 'L’ESC 2023 le déconseille.'],
  ['Compter la durée du traitement depuis l’admission', 'Elle se compte depuis le premier jour de traitement efficace avec cultures négatives.'],
  ['Prescrire une prophylaxie avant une gastroscopie', 'La prophylaxie concerne les soins dentaires à risque chez les patients à haut risque.'],
  ['Perfuser 1 g de vancomycine en 30 minutes', 'Il faut au moins 100 minutes (≤ 10 mg/min).'],
  ['Oublier la coloscopie après une endocardite à S. gallolyticus', 'Ce germe impose la recherche d’un cancer colorectal.'],
  ['Croire qu’une seule hémoculture à staphylocoque blanc suffit', 'Il faut des hémocultures répétées et un contexte de matériel.'],
 ]) + P('Ces pièges reprennent les recommandations ESC 2023 et suisses.', 5, 9, 14)))
SOURCES = sorted(SOURCES_ORIG.items()) + [
 (34, 'Office fédéral de la santé publique (OFSP). La tuberculose en Suisse : situation épidémiologique (rapport annuel). Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (35, 'OFS, NICER, Registre du cancer de l’enfant. Rapport suisse sur le cancer 2021 : lymphomes. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (36, 'Gouliouris T, Aliyu SH, Brown NM. Spondylodiscitis: update on diagnosis and management. J Antimicrob Chemother 2010;65 Suppl 3:iii11–24. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (37, 'Blomström-Lundqvist C et al. European Heart Rhythm Association international consensus document on how to prevent, diagnose, and treat cardiac implantable electronic device infections. Europace 2020;22:515–549. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (38, 'Rees F, Doherty M, Grainge MJ, Lanyon P, Zhang W. The worldwide incidence and prevalence of systemic lupus erythematosus: a systematic review of epidemiological studies. Rheumatology 2017;56:1945–1961. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (39, 'Reynen K. Cardiac myxomas. N Engl J Med 1995;333:1610–1617. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (33, 'Fedlex. Ordonnance réglant l’admission des personnes et des véhicules à la circulation routière (OAC, RS 741.51), annexe 1 ; LAMal art. 31 (soins dentaires). Référence ajoutée lors de l’audit du 24 octobre 2026.'),
]
CTX = {'_prefixe': 'Dans l’endocardite',
 'hemoc': 'Trois séries d’hémocultures à 30 min d’intervalle se prélèvent avant tout antibiotique ; deux séries positives à germe typique forment un critère majeur.',
 'echocoeur': 'L’ETT se fait dès la suspicion ; l’ETO, plus sensible, s’impose si l’ETT est négative avec forte suspicion, sur prothèse ou pour chercher un abcès.',
 'tep': 'La TEP-TDM au FDG apporte un critère majeur sur prothèse ou dispositif implanté depuis plus de 3 mois.',
 'tdm': 'La TDM cardiaque montre abcès et pseudo-anévrismes ; la TDM thoraco-abdominale cherche les emboles spléniques, rénaux ou pulmonaires.',
 'irm': 'L’IRM cérébrale cherche des emboles et des anévrismes mycotiques avant la chirurgie.',
 'crp': 'La CRP suit la réponse au traitement ; une remontée fait chercher une complication.',
 'pct': 'La procalcitonine aide au tri du sepsis mais n’exclut pas une endocardite subaiguë.',
 'vs': 'Une VS accélérée accompagne souvent la forme subaiguë, sans spécificité.',
 'nfs': 'L’anémie inflammatoire et la leucocytose sont fréquentes ; une thrombopénie évoque un sepsis grave.',
 'creat': 'La créatinine dépiste une glomérulonéphrite ou une toxicité de la vancomycine et de la gentamicine.',
 'ecbu': 'Le sédiment urinaire cherche une hématurie de glomérulonéphrite.',
 'sero': 'Les sérologies Coxiella (IgG de phase I > 1/800) et Bartonella s’imposent si les hémocultures restent négatives.',
 'pcr': 'La PCR sur la valve opérée identifie un germe quand les cultures sont stériles.',
 'ecg': 'Un allongement du PR ou un bloc auriculoventriculaire nouveau fait suspecter un abcès de l’anneau aortique.',
 'radio': 'La radiographie thoracique cherche une congestion ou des emboles septiques pulmonaires.',
 'bnp': 'Le NT-proBNP précise une insuffisance cardiaque par régurgitation.',
 'biopsie': 'L’histologie et la culture de la valve opérée sont le gold standard du diagnostic.',
 'vih': 'Le dépistage du VIH s’impose chez la personne qui s’injecte des drogues.',
 'hep': 'Les tests hépatiques se surveillent sous flucloxacilline et rifampicine.',
 'iono': 'Les électrolytes se surveillent sous aminoside et diurétique.',
 'tropo': 'Une troponine élevée signale une atteinte myocardique ou un embole coronaire.',
 'endo': 'La coloscopie recherche un cancer colorectal après une endocardite à Streptococcus gallolyticus.',
 'echo': 'L’échographie abdominale cherche un infarctus splénique ou rénal.',
 'gds': 'Les gaz du sang et le lactate évaluent un choc septique ou cardiogénique.',
 'lact': 'Un lactate > 2 mmol/L signe une hypoperfusion dans le sepsis.',
 'hcg': 'Le test de grossesse précède la TDM et la TEP chez la femme en âge de procréer.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
