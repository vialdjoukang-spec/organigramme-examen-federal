# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.1 · Syndrome coronarien aigu (LOT 1, Appel B, Partie 1, r1 → audit du 24.10.2026)."""
import sys; sys.path.insert(0, '/workspace/audit_1_10/outils')
from gen_v7 import *
from src_P1 import SOURCES_ORIG
POINT = mkPOINT('dx1')
M = dict(pref='dx1', dx='DX.1', court='SCA', long='Syndrome coronarien aigu', dossier='corriges/LOT_001',
         fichier='LOT_001_DX1_Syndrome_coronarien_aigu_AUDITÉ.html', lot_titre='LOT 1 · G1 · Transpiration anormale',
         sous_titre='PROFILES 2023 · SSP G1 · LOT 1 · Appel B · V7 · version AUDITÉE',
         statut='Cette version corrige la monographie DX.1 du LOT 1 (Appel B, V7, Partie 1, révision r1) après audit médical et linguistique.')

STEMI = T('STEMI', 'Le STEMI (ST-elevation myocardial infarction) est un infarctus avec sus-décalage persistant du segment ST ; c’est d’abord un diagnostic de travail électrique et clinique qui déclenche la reperfusion sans attendre la troponine.')
NSTE = T('SCA sans sus-décalage (NSTE-ACS)', 'Le NSTE-ACS regroupe l’infarctus sans sus-décalage (NSTEMI : troponine qui monte ou baisse au-dessus du 99e percentile) et l’angor instable (ischémie de repos sans lésion myocardique démontrée).')
DAPT = T('double antiagrégation plaquettaire (DAPT)', 'La DAPT associe l’acide acétylsalicylique (AAS) à un inhibiteur du récepteur P2Y12 (ticagrelor, prasugrel ou clopidogrel) ; elle dure par défaut 12 mois après un SCA.')
GRACE = T('score GRACE', 'Le score GRACE estime la mortalité hospitalière et à 6 mois. Il combine l’âge, la fréquence cardiaque, la pression systolique, la créatinine, la classe Killip, un arrêt cardiaque, le sous-décalage ST et la troponine ; un score > 140 classe le patient à haut risque.')
KILLIP = T('classe Killip', 'La classe Killip grade l’insuffisance cardiaque à la phase aiguë : I sans signe, II râles crépitants ou B3, III œdème pulmonaire, IV choc cardiogénique ; la mortalité augmente de I à IV.')
MINOCA = T('MINOCA', 'Le MINOCA (myocardial infarction with non-obstructive coronary arteries) est un infarctus sans sténose coronaire ≥ 50 % ; c’est un diagnostic de travail qui impose de chercher une myocardite, un syndrome de Takotsubo, une dissection coronaire spontanée, un spasme ou une embolie.')
PTS = []
# ---------- 1
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Le syndrome coronarien aigu (SCA) désigne une ischémie myocardique aiguë suspectée, avec ou sans lésion des cardiomyocytes. '
   f'L’électrocardiogramme (ECG) sépare d’emblée le {STEMI}, qui impose une reperfusion immédiate, et le {NSTE}. '
   'L’infarctus exige une troponine qui monte ou baisse au-dessus du 99e percentile et une ischémie, faute de quoi il s’agit d’une simple lésion myocardique. '
   'La décharge adrénergique de l’ischémie explique les sueurs froides, d’où la place du SCA en tête du diagnostic différentiel d’une transpiration anormale aiguë.', 1, 2) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['STEMI', 'Le contexte ischémique s’accompagne d’un sus-décalage ST persistant ou d’un équivalent d’occlusion (bloc de branche gauche avec ischémie, infarctus postérieur).', 'Péricardite (sus-décalage diffus concave), repolarisation précoce, anévrisme ventriculaire'],
    ['NSTEMI', 'La troponine dépasse le 99e percentile avec une cinétique, sans sus-décalage persistant.', 'Lésion myocardique non ischémique (sepsis, embolie pulmonaire, myocardite)'],
    ['Angor instable', 'L’ischémie survient au repos ou s’aggrave, sans lésion myocardique démontrée par la troponine ultrasensible.', 'Angor stable, qui cède au repos et se reproduit à un effort comparable'],
    ['Infarctus de type 1 (primaire)', 'Une rupture ou une érosion de plaque déclenche une thrombose coronaire.', 'Type 2 : un déséquilibre apport–besoin dû à une autre affection (anémie, tachyarythmie, choc)'],
    ['Lésion myocardique', 'La troponine dépasse le 99e percentile ; elle est aiguë si elle varie, chronique si elle reste stable.', 'Infarctus, qui exige en plus une ischémie'],
    ['MINOCA', 'Un infarctus survient sans sténose coronaire ≥ 50 %.', 'Diagnostic final : il faut nommer la cause'],
   ]) + P(f'La définition universelle de l’infarctus, révisée en 2026, classe les infarctus en primaires, secondaires et liés à une procédure ; le terme {MINOCA} reste un diagnostic de travail.', 2))))
# ---------- 2
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, l’Office fédéral de la statistique (OFS) a recensé en 2023 19 634 personnes hospitalisées pour un infarctus aigu du myocarde, dont 66 % d’hommes, et 2181 décès par infarctus. '
   'En Europe, la Société européenne de cardiologie (ESC) estime à 5,8 millions les nouveaux cas de cardiopathie ischémique en 2019 dans ses 57 pays membres, où elle reste la première cause de décès. '
   'La mortalité hospitalière du STEMI, de 4 à 12 %, augmente avec l’âge et dépend surtout du délai de reperfusion et du choc.', 3, 1) +
 F('Chiffres utiles, terrain et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Infarctus hospitalisés en Suisse (2023)', '19 634 (12 909 hommes, 6725 femmes)', 'La série concerne l’infarctus, pas tous les SCA (OFS).'],
    ['Décès par infarctus en Suisse (2023)', '2181', 'La statistique des causes de décès ne donne pas une létalité de cohorte.'],
    ['Nouveaux cas de cardiopathie ischémique (pays ESC, 2019)', '5,8 millions', 'Le champ est plus large que le SCA.'],
    ['Mortalité hospitalière du STEMI', 'environ 4 à 12 %', 'Elle augmente avec l’âge, la classe Killip et le délai (ESC 2023).'],
    ['Choc cardiogénique au cours d’un STEMI', 'environ 5 à 10 %', 'Il domine la mortalité précoce.'],
   ]) + P('Le risque augmente avec l’âge, le sexe masculin, le tabac, l’hypertension, le diabète, la dyslipidémie et l’hérédité. Les femmes, les personnes âgées et les diabétiques présentent plus souvent une forme atypique (dyspnée, malaise, sueurs isolées) ; ils sont donc diagnostiqués plus tard. Sans reperfusion, l’occlusion coronaire détruit le myocarde de l’endocarde vers l’épicarde en quelques heures : « le temps, c’est du muscle ».', 1))))
# ---------- 3
PTS.append(POINT(3, 'Physiopathologie',
 P('Dans l’infarctus de type 1, une plaque d’athérome se rompt ou s’érode, les plaquettes adhèrent et s’activent, puis la coagulation forme un thrombus qui réduit ou interrompt le flux coronaire. '
   'L’ischémie altère la relaxation, la contraction puis l’activité électrique, et la nécrose débute après environ 20 minutes d’occlusion, tandis que la décharge sympathique provoque sueurs, tachycardie et pâleur. '
   'Chaque traitement vise un maillon, car la reperfusion rouvre l’artère, les antiagrégants et les anticoagulants freinent le thrombus, les bêtabloquants réduisent la demande et les statines stabilisent la plaque.', 1, 2) +
F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Deux artères coronaires (gauche et droite) naissent de l’aorte et nourrissent le muscle cardiaque ; chaque territoire correspond à des dérivations ECG.'],
    ['Physiologie', 'Pourquoi le cœur est fragile : il extrait déjà presque tout l’oxygène au repos, donc il ne peut augmenter son apport qu’en augmentant le débit coronaire.'],
    ['Physiopathologie', 'Une plaque d’athérome se rompt, un caillot (plaquettes puis fibrine) bouche l’artère, et le muscle privé d’oxygène meurt en quelques heures, de l’intérieur vers l’extérieur.'],
    ['Clinique', 'D’où la douleur constrictive (nerfs du cœur), les sueurs (décharge d’adrénaline) et parfois le choc ou l’arythmie (muscle qui ne se contracte plus ou devient électriquement instable).'],
    ['Examens', 'L’ECG voit l’ischémie en direct ; la troponine, libérée par les cellules qui meurent, prouve la nécrose ; la coronarographie montre l’artère bouchée.'],
    ['Traitement', 'Puisque le temps c’est du muscle : rouvrir l’artère (angioplastie), empêcher un nouveau caillot (antiagrégants, anticoagulant), puis stabiliser la plaque (statine).'],
   ]), 1) +
 F('Lésion, exploration et cible thérapeutique',
   TAB(['Lésion ou mécanisme', 'Exploration qui la montre', 'Cible thérapeutique'], [
    ['Plaque rompue et thrombus occlusif', 'ECG (sus-décalage), coronarographie', 'Angioplastie primaire ou fibrinolyse ; AAS + inhibiteur P2Y12 ; anticoagulant'],
    ['Thrombus non occlusif, emboles distaux', 'Troponine ultrasensible sériée, ECG (sous-décalage)', 'Stratégie invasive selon le risque ; antithrombotiques'],
    ['Nécrose des cardiomyocytes', 'Troponine (cinétique), IRM cardiaque (rehaussement tardif)', 'Reperfusion précoce : chaque minute gagnée limite la nécrose'],
    ['Instabilité électrique', 'ECG continu (monitorage)', 'Défibrillation, correction du potassium et du magnésium, revascularisation'],
    ['Dysfonction ventriculaire', 'Échocardiographie, NT-proBNP', 'Diurétique, IEC, bêtabloquant après stabilisation, antagoniste minéralocorticoïde'],
    ['Athérosclérose diffuse', 'Bilan lipidique, glycémie, HbA1c', 'Statine haute intensité, sevrage tabagique, réadaptation'],
   ]) +
 F('Mécanisme d’action des médicaments clés',
   UL(['L’<b>AAS</b> inhibe irréversiblement la cyclo-oxygénase 1 et donc la synthèse plaquettaire de thromboxane A2.',
       'Le <b>ticagrelor</b> bloque le récepteur P2Y12 de façon réversible et directe ; le <b>clopidogrel</b> et le <b>prasugrel</b> sont des prodrogues dont le métabolite actif le bloque de façon irréversible.',
       'L’<b>héparine non fractionnée</b> potentialise l’antithrombine contre les facteurs IIa et Xa ; l’<b>énoxaparine</b> agit surtout sur le Xa ; le <b>fondaparinux</b> inhibe sélectivement le Xa et ne suffit pas seul pendant une angioplastie.',
       'La <b>ténectéplase</b> active le plasminogène lié à la fibrine et dissout le thrombus, au prix d’un risque hémorragique.',
       'La <b>nitroglycérine</b> dilate les veines, réduit la précharge et la demande en oxygène, mais peut effondrer la pression.',
       'L’<b>atorvastatine</b> inhibe l’HMG-CoA réductase et augmente la clairance hépatique du LDL.']) + P('', 6, 7, 8, 9, 10, 11, 12, 13, 14, 15)), 'fenetre')))
# ---------- 4
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin reconnaît d’abord une urgence vitale : arrêt cardiaque, choc, arythmie ventriculaire, œdème pulmonaire ou occlusion coronaire présumée à l’ECG. '
   'Il obtient ensuite un ECG dans les 10 minutes, puis une troponine ultrasensible, et intègre la clinique au lieu de juger sur les seules sueurs. '
   'Enfin, il exclut les autres urgences dont le traitement diffère : dissection aortique, embolie pulmonaire, tamponnade, pneumothorax compressif et hypoglycémie.', 1) +
 F('Diagnostic différentiel des sueurs avec douleur ou malaise thoracique (fréquence sourcée en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Piège thérapeutique'], [
    ['Occlusion coronaire (STEMI)' + PR('5–10 % des douleurs thoraciques aux urgences', 57), 'Douleur constrictive, sus-décalage ST systématisé', 'Attendre la troponine retarde la reperfusion.'],
    ['NSTEMI et angor instable' + PR('15–20 % et ≈ 10 % des douleurs thoraciques aux urgences', 57), 'Douleur de repos, troponine hs dynamique, ECG sans sus-décalage', 'Une troponine unique normale trop précoce ne l’exclut pas.'],
    ['Dissection aortique' + PR('3–6 / 100 000 par an', 58), 'Douleur dorsale migratrice, asymétrie tensionnelle, souffle d’insuffisance aortique', 'Une fibrinolyse ou une anticoagulation peut être mortelle ; l’angio-TDM tranche.'],
    ['Embolie pulmonaire' + PR('39–115 / 100 000 par an', 59), 'Dyspnée, tachycardie, facteurs de risque thromboembolique, surcharge droite', 'Une troponine élevée ne prouve pas une thrombose coronaire.'],
    ['Péricardite, myocardite' + PR('≈ 5 % des douleurs thoraciques aux urgences (péricardite)', 60), 'Douleur positionnelle, frottement, sus-décalage diffus, contexte viral', 'L’IRM cardiaque confirme la myocardite.'],
    ['Syndrome de Takotsubo' + PR('≈ 1–3 % des suspicions de SCA', 61), 'Stress émotionnel ou physique, femme ménopausée, ballonnisation apicale', 'La coronarographie est normale ; le pronostic n’est pas toujours bénin.'],
    ['Hypoglycémie (diabète traité)' + PR('diabète ≈ 5 % des adultes en Suisse', 64), 'Diabète traité, sueurs, confusion, glycémie basse', 'La glycémie capillaire immédiate corrige une cause réversible.'],
    ['Thyrotoxicose' + PR('≈ 0,75 % (Europe)', 62) + ', phéochromocytome' + PR('≈ 0,8 / 100 000 par an', 63), 'Palpitations, tremblement, poussées hypertensives', 'Ils peuvent aussi provoquer un infarctus de type 2.'],
    ['Cause non cardiaque (pariétale, digestive, anxieuse)' + PR('≈ 50 % des douleurs thoraciques aux urgences', 57), 'Douleur reproduite à la palpation, reflux, contexte anxieux', 'Ce diagnostic ne se pose qu’après exclusion des urgences vitales.'],
   ]) + P(f'Un {MINOCA} n’est pas une conclusion : l’IRM cardiaque cherche la myocardite, le Takotsubo ou un infarctus non obstructif.', 2))))
# ---------- 5
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’anamnèse date le début des symptômes, décrit la douleur, recherche les équivalents (dyspnée, malaise, sueurs, nausées) et recense facteurs de risque, antécédents coronaires, traitements antithrombotiques et risque hémorragique. '
   'Le patient qui présente un drapeau rouge est monitoré, et le médecin appelle le 144 hors de l’hôpital ou la filière de cardiologie interventionnelle à l’hôpital.', 1, 31) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison physiopathologique', 'Ce que la réponse change'], [
    ['À quelle heure la douleur a-t-elle commencé ? Persiste-t-elle ?', 'Le myocarde ischémique se nécrose progressivement.', 'Le délai décide de la reperfusion (≤ 12 h) et de la fibrinolyse.'],
    ['La douleur serre-t-elle ? Irradie-t-elle au bras, à la mâchoire ou au dos ?', 'L’ischémie se projette par les dermatomes C8–T4.', 'Une irradiation dorsale migratrice oriente vers une dissection.'],
    ['Avez-vous transpiré, vomi, perdu connaissance ?', 'La décharge adrénergique et vagale accompagne l’ischémie ; la syncope évoque une arythmie.', 'Une syncope renforce le monitorage.'],
    ['Avez-vous un stent, un pontage, un infarctus ancien ? Prenez-vous vos antiagrégants ?', 'L’arrêt précoce d’une DAPT expose à la thrombose de stent.', 'Le mécanisme et le risque changent.'],
    ['Avez-vous eu un AVC, une hémorragie, une opération récente ? Prenez-vous un anticoagulant ?', 'Le risque hémorragique limite la fibrinolyse et le prasugrel.', 'Les contre-indications sont vérifiées avant prescription.'],
    ['Avez-vous pris du sildénafil, du tadalafil ou de la cocaïne ?', 'L’inhibiteur de phosphodiestérase potentialise l’hypotension des nitrés ; la cocaïne provoque spasme et thrombose.', 'Le nitré est contre-indiqué dans les 24–48 h.'],
    ['Êtes-vous enceinte ? Avez-vous une maladie rénale ou hépatique ?', 'La dissection coronaire spontanée survient surtout chez la femme jeune et en péripartum.', 'Les doses et l’imagerie s’adaptent.'],
   ])) +
 U('<b>Drapeaux rouges, conduite immédiate (144, monitorage, défibrillateur à portée)</b> : douleur persistante malgré le traitement, choc ou pression systolique < 90 mmHg, œdème pulmonaire, arythmie ventriculaire ou arrêt cardiaque, sus-décalage ST, syncope, signes neurologiques ou douleur dorsale migratrice, qui imposent dans un NSTE-ACS une coronarographie dans les 2 heures.', 1)))
# ---------- 6
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen débute par la séquence ABCDE (Airway, Breathing, Circulation, Disability, Exposure) : voies aériennes, respiration, circulation, état neurologique et exposition. '
   'Il mesure fréquence, pression aux deux bras, saturation, température et glycémie, ausculte cœur et poumons et palpe les pouls. '
   'Un examen normal est fréquent et n’exclut pas un SCA ; l’examen sert surtout à détecter une complication ou un diagnostic concurrent.', 1, 27, 28) +
 F('Normal, anomalie, valeur diagnostique',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Inspection de la peau, temps de recoloration', 'Peau chaude, recoloration < 2 s', 'Sueurs froides, marbrures, recoloration > 3 s : hypoperfusion, choc'],
    ['Pression artérielle aux deux bras', 'Différence < 20 mmHg', 'Différence > 20 mmHg : dissection aortique à exclure avant tout antithrombotique'],
    ['Auscultation pulmonaire', 'Murmure vésiculaire sans bruit surajouté', 'Râles crépitants : congestion (classe Killip II–III)'],
    ['Auscultation cardiaque', 'B1, B2, pas de souffle', 'Souffle holosystolique nouveau : insuffisance mitrale ou rupture septale ; frottement : péricardite'],
    ['Veines jugulaires, en position demi-assise à 45°', 'Turgescence absente', 'Turgescence avec poumons clairs et hypotension : infarctus du ventricule droit ou tamponnade'],
    ['Pouls périphériques', 'Pouls symétriques', 'Asymétrie : dissection ; abolition : ischémie de membre'],
   ]) + P(f'La {KILLIP} classe la défaillance cardiaque à l’entrée et prédit la mortalité. Les signes physiques ont une sensibilité faible pour le SCA ; leur valeur tient surtout à leur spécificité pour une complication (un souffle nouveau en choc impose une échocardiographie immédiate).', 1))))
# ---------- 7
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Le syndrome ischémique associe une douleur rétrosternale constrictive de repos de plus de 20 minutes, souvent irradiée, et des signes adrénergiques. '
   'Le syndrome de bas débit et le syndrome congestif traduisent une défaillance ventriculaire, et le syndrome rythmique traduit une instabilité électrique. '
   'Les signes fonctionnels (douleur, dyspnée, palpitations) se distinguent des signes physiques (sueurs, souffle, râles, hypotension).', 1, 31) +
 F('Signes et syndromes définis',
   TAB(['Signe ou syndrome', 'Comment le chercher', 'Mécanisme'], [
    ['Douleur angineuse typique (signe fonctionnel)', 'Le patient montre la poitrine du plat de la main ; la douleur serre, dure plus de 20 minutes et résiste au repos.', 'L’ischémie stimule les afférences sympathiques cardiaques.'],
    ['Équivalents angineux (signe fonctionnel)', 'Dyspnée, épigastralgie, malaise ou fatigue brutale, surtout chez la femme, la personne âgée et le diabétique.', 'La neuropathie autonome et la dysfonction ventriculaire modifient la perception.'],
    ['Sueurs froides (signe physique)', 'La peau est moite et froide au toucher.', 'Les catécholamines activent les glandes sudoripares et la vasoconstriction cutanée.'],
    ['Syndrome de bas débit', 'Hypotension, extrémités froides, oligurie, confusion, lactate élevé.', 'La perte de myocarde contractile réduit le débit cardiaque.'],
    ['Syndrome congestif', 'Dyspnée, orthopnée, râles crépitants, B3.', 'La pression de remplissage gauche augmente.'],
    ['Infarctus du ventricule droit', 'Hypotension, turgescence jugulaire, poumons clairs, sus-décalage en V4R.', 'Le ventricule droit ischémique ne remplit plus le gauche ; les nitrés sont dangereux.'],
    ['Syndrome vagal de l’infarctus inférieur', 'Bradycardie, hypotension, nausées.', 'Le réflexe de Bezold-Jarisch part de la paroi inférieure.'],
   ]))))
# ---------- 8
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Selon l’ESC 2023, le STEMI se diagnostique sur un sus-décalage ST nouveau au point J dans au moins deux dérivations contiguës : ≥ 1 mm hors V2–V3 et, en V2–V3, ≥ 2,5 mm chez l’homme de moins de 40 ans, ≥ 2 mm chez l’homme de 40 ans ou plus et ≥ 1,5 mm chez la femme. '
   'L’infarctus exige une troponine qui monte ou baisse avec au moins une valeur au-dessus du 99e percentile propre au sexe, plus un argument ischémique : symptômes, ECG, onde Q ou imagerie. '
   'Un élément isolé ne suffit pas à poser le diagnostic, qu’il s’agisse d’une douleur typique, d’une troponine élevée ou de la réponse à la nitroglycérine.', 1, 2) +
 F('Critères, seuils et conséquences',
   TAB(['Situation', 'Critère (source, année)', 'Conséquence'], [
    ['STEMI', 'Sus-décalage ST selon les seuils ci-dessus (ESC 2023)', 'Reperfusion sans attendre la troponine'],
    ['Équivalents d’occlusion', 'Bloc de branche gauche ou rythme électro-entraîné avec ischémie ; sous-décalage V1–V3 avec sus-décalage V7–V9 ≥ 0,5 mm (infarctus postérieur) ; sus-décalage aVR avec sous-décalage diffus', 'Même filière que le STEMI après lecture experte'],
    ['Lésion myocardique aiguë', 'Troponine > 99e percentile avec variation (définition universelle 2026)', 'Chercher l’ischémie ou une autre cause'],
    ['Infarctus primaire confirmé', 'Lésion aiguë + ischémie, puis imagerie montrant un thrombus ou une nouvelle anomalie de contraction', 'Nommer la cause et classer le type'],
    ['Angor instable', 'Ischémie clinique sans troponine au-dessus du 99e percentile', 'Évaluation du risque et de l’anatomie selon la clinique'],
   ]) + P('Une troponine constamment élevée et stable signe une lésion chronique (insuffisance rénale, insuffisance cardiaque) ; seul un delta significatif signe une lésion aiguë.', 2))))
# ---------- 9
P9a = TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
 ['ECG 12 dérivations', 'Occlusion coronaire, territoire, arythmie', 'Sensibilité du premier tracé pour l’infarctus d’environ 50 % ; spécificité élevée du sus-décalage systématisé', 'Un tracé normal n’exclut rien ; il se répète.'],
 ['Troponine ultrasensible sériée (0 h/1 h)', 'Lésion myocardique aiguë', 'Valeur prédictive négative > 99 % pour l’exclusion ; valeur prédictive positive d’environ 70 % pour l’inclusion (ESC 2023)', 'Elle ne dit pas le mécanisme ; les seuils dépendent du réactif.'],
 ['Coronarographie', 'Anatomie coronaire : examen de référence (gold standard) des sténoses, avec traitement dans le même temps', 'Référence anatomique', 'Elle ne montre ni la myocardite ni le Takotsubo ; elle est invasive et iodée.'],
 ['IRM cardiaque', 'Caractérisation tissulaire : nécrose, œdème, myocardite', 'Référence tissulaire du MINOCA', 'Elle est non urgente et exige un dispositif compatible.'],
])
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le SCA n’a pas d’examen de référence unique, car l’ECG décide de la reperfusion, la troponine prouve la lésion et la coronarographie, gold standard anatomique, traite la sténose. '
   'En première intention, le médecin enregistre un ECG dans les 10 minutes et dose la troponine ultrasensible à 0 h puis à 1 h ou 2 h selon l’algorithme validé du réactif. '
   'En seconde intention, il demande une échocardiographie, une coronarographie selon le risque, et une IRM cardiaque ou un coroscanner devant un résultat discordant. '
   'Le choix tient compte d’une grossesse, de la fonction rénale (DFGe) et des dispositifs implantés.', 1, 2, 5) +
 F('9.a Examens de référence (gold standard)', P9a, 'fenetre') +
 F('9.b Première intention, seconde intention et critère de passage',
   TAB(['Intention', 'Examen et moment', 'Critère de passage'], [
    ['Première', 'ECG dans les 10 minutes du premier contact ; répété à chaque récidive douloureuse ; V3R–V4R et V7–V9 si besoin', 'Sus-décalage ou équivalent : filière de reperfusion immédiate'],
    ['Première', 'Troponine ultrasensible à 0 h puis 1 h (ou 2 h) ; formule sanguine, créatinine, électrolytes, glycémie, coagulation, bilan lipidique', 'Branche d’inclusion ou critère de risque : stratégie invasive'],
    ['Seconde', 'Échocardiographie transthoracique', 'Instabilité, souffle, doute diagnostique : immédiate ; sinon avant la sortie'],
    ['Seconde', 'Coronarographie', 'STEMI : immédiate ; NSTE-ACS : < 2 h, < 24 h ou sélective selon le risque'],
    ['Seconde', 'Coroscanner (angio-TDM coronaire) ou épreuve de stress', 'Branche d’observation ou faible risque, troponine non concluante'],
    ['Seconde', 'IRM cardiaque', 'MINOCA, suspicion de myocardite ou de Takotsubo'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Le <b>prélèvement de troponine</b> se fait à l’arrivée puis exactement 1 h ou 2 h plus tard, sur le même réactif ; aucune préparation n’est nécessaire.',
       'La <b>coronarographie urgente</b> n’attend ni le jeûne ni l’arrêt d’un traitement ; en électif, le centre vérifie la fonction rénale, une réaction antérieure au produit de contraste, les anticoagulants, le consentement et l’abord radial.',
       'Après injection de produit de contraste iodé chez un patient à risque (DFGe < 30 mL/min/1,73 m² pour une injection coronaire), l’ESUR recommande une hydratation adaptée et une créatinine de contrôle à 48 heures.',
       'L’<b>IRM cardiaque</b> exige la vérification de chaque implant ; un stimulateur cardiaque compatible n’est pas une contre-indication.']), 'fenetre') +
 F('9.d Interprétation de la troponine T ultrasensible (Roche Elecsys, schéma ESC 0 h/1 h)',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Valeur à 0 h très basse', '< 5 ng/L si la douleur date de plus de 3 h', 'Branche d’exclusion', 'Sortie possible si la clinique et l’ECG concordent'],
    ['Valeur basse et stable', '0 h < 12 ng/L et delta 1 h < 3 ng/L', 'Branche d’exclusion', 'Évaluation ambulatoire selon le risque'],
    ['Valeur élevée ou delta important', '0 h ≥ 52 ng/L ou delta 1 h ≥ 5 ng/L', 'Branche d’inclusion : lésion aiguë probable', 'Hospitalisation et coronarographie selon le risque'],
    ['Résultat intermédiaire (zone grise)', 'Ni exclusion ni inclusion', 'Branche d’observation', 'Troisième dosage à 3 h, échocardiographie, réévaluation'],
    ['Résultat discordant', 'Troponine négative avec douleur récidivante ou ECG dynamique', 'La clinique prime', 'Stratégie invasive malgré la biologie'],
   ]) + P('La limite d’orientation de l’Inselspital pour ce réactif est de 14 ng/L ; le 99e percentile propre au sexe doit être demandé au laboratoire. Un résultat positif ne dit pas la cause, un résultat négatif précoce (< 3 h) ne suffit pas seul.', 5, 1), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation', 'Piège évité'], [
    ['Grossesse', 'ECG, troponine et échocardiographie d’abord ; la coronarographie reste indiquée pour un STEMI, avec protection abdominale', 'Retarder la reperfusion maternelle'],
    ['Enfant ou adolescent', 'Le SCA est rare : rechercher une myocardite, une anomalie coronaire congénitale, une maladie de Kawasaki ou une cocaïne', 'Transposer les seuils et doses adultes'],
    ['DFGe < 30 mL/min/1,73 m²', 'Coronarographie si indiquée, avec contraste iso-osmolaire en volume minimal et créatinine à 48 h', 'Renoncer à une stratégie invasive indiquée'],
    ['Allergie à l’iode rapportée', 'Préciser le produit et la réaction ; prémédication ou autre produit selon l’allergologue', 'Assimiler « allergie à l’iode » à une contre-indication absolue'],
    ['Stimulateur cardiaque ou défibrillateur', 'IRM seulement si le système est compatible ; sinon échocardiographie ou scintigraphie', 'Exclure l’IRM par principe'],
   ]), 'fenetre')))
# ---------- 10
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si le patient est instable, le médecin le stabilise et organise une coronarographie immédiate. '
   'Si l’ECG montre un sus-décalage ou un équivalent, il active la filière de reperfusion ; sinon, la troponine sériée et le score de risque décident de la stratégie. '
   'Chaque récidive douloureuse ou modification électrique fait remonter le patient dans l’arbre.', 1) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Arrêt cardiaque, choc, arythmie ventriculaire, douleur réfractaire', 'Réanimation, 144 ou équipe d’urgence, coronarographie immédiate', 'Complication mécanique à l’échocardiographie'],
    ['STEMI et angioplastie possible < 120 min après le diagnostic', 'Angioplastie primaire', 'Délai porte-ballon, DAPT'],
    ['STEMI, angioplastie impossible < 120 min, symptômes ≤ 12 h, pas de contre-indication', 'Fibrinolyse dans les 10 minutes, puis transfert immédiat vers un centre interventionnel', 'Résolution du sus-décalage < 50 % à 60–90 min : angioplastie de sauvetage ; sinon coronarographie à 2–24 h'],
    ['NSTE-ACS à très haut risque', 'Coronarographie < 2 h', 'Monitorage'],
    [f'NSTEMI confirmé, ECG dynamique ou {GRACE} > 140', 'Coronarographie < 24 h', 'Antithrombotiques'],
    ['Branche d’observation', 'Troponine à 3 h, échocardiographie, réévaluation', 'Imagerie non invasive si doute'],
    ['Branche d’exclusion et faible suspicion clinique', 'Sortie avec consignes ; bilan ambulatoire selon le risque', 'Diagnostic alternatif nommé'],
   ]))))
# ---------- 11
A = F('11.A Buts : traiter l’urgence vitale, puis rouvrir l’artère et prévenir la récidive',
   P('Dans une forme compliquée (choc, arrêt, arythmie), le premier but est de restaurer une circulation efficace en quelques minutes. '
     'Dans le STEMI, le but est un délai diagnostic–angioplastie < 120 minutes (idéalement < 60 minutes dans un centre interventionnel) ou une fibrinolyse dans les 10 minutes si l’angioplastie est impossible dans ce délai. '
     'Les cibles chiffrées sont une saturation ≥ 90 % (oxygène seulement en dessous), une douleur soulagée, un LDL < 1,4 mmol/L avec une baisse d’au moins 50 % et une pression < 130/80 mmHg à distance.', 1), 'fenetre')
URG = F('Forme compliquée : chronologie de l’urgence',
   TAB(['Temps', 'Geste', 'Pourquoi'], [
    ['Minute 0', 'Appel du 144 ou de l’équipe d’urgence, défibrillateur, monitorage, voie veineuse', 'La fibrillation ventriculaire survient surtout dans la première heure.'],
    ['≤ 10 minutes', 'ECG 12 dérivations transmis au cardiologue ; AAS si pas de contre-indication', 'Le diagnostic de STEMI déclenche la filière.'],
    ['≤ 60–120 minutes', 'Angioplastie primaire (ou fibrinolyse dans les 10 minutes si l’angioplastie est impossible < 120 min)', 'Chaque minute réduit la nécrose.'],
    ['Heures', 'Choc : revascularisation, noradrénaline, assistance circulatoire selon l’équipe ; œdème pulmonaire : diurétique, ventilation non invasive', 'La revascularisation de l’artère coupable améliore la survie du choc.'],
    ['Jours 2–7', 'Surveillance des complications mécaniques (rupture septale, de pilier, de paroi libre), du thrombus ventriculaire et de la péricardite', 'Un souffle nouveau ou un choc tardif impose une échocardiographie immédiate.'],
   ]) + P('Arrêt cardiaque : l’algorithme suisse BLS-AED-SRC 2025 prévoit 30 compressions pour 2 insufflations, 100–120 compressions par minute sur 5–6 cm, et le défibrillateur dès son arrivée.', 30))
GEN = F('Forme non compliquée : mesures générales puis ordre des traitements',
   OL(['Mesures générales : repos, monitorage ECG ≥ 24 h, voie veineuse, oxygène seulement si la saturation est < 90 %, antalgie (morphine titrée si nécessaire), éducation du patient.',
       'AAS dès le diagnostic, puis inhibiteur P2Y12 selon la stratégie (prétraitement non systématique dans le NSTE-ACS avec coronarographie précoce).',
       'Anticoagulation parentérale jusqu’à la revascularisation.',
       'Revascularisation (angioplastie avec stent, rarement pontage) selon l’anatomie.',
       'Statine haute intensité dès l’hospitalisation ; bêtabloquant si FEVG ≤ 40 % ; IEC si insuffisance cardiaque, FEVG ≤ 40 %, diabète, hypertension ou maladie rénale ; antagoniste minéralocorticoïde si FEVG ≤ 40 % avec insuffisance cardiaque ou diabète.',
       'Réadaptation cardiaque, sevrage tabagique et prévention secondaire.']) + P('Cet ordre suit le mécanisme : on bloque le thrombus avant de rouvrir l’artère, puis on prévient la récidive et le remodelage.', 1))
MED = F('Fiches médicamenteuses (posologies AIPS)',
   TAB(['Médicament (classe)', 'Dose AIPS et durée', 'Effets indésirables, contre-indications, interactions'], [
    ['Acide acétylsalicylique, Aspirine Cardio® (antiagrégant, inhibiteur de COX-1)', 'Infarctus aigu : 200–300 mg en forme à résorption rapide ou IV, puis 100 mg/j au long cours', 'Saignement, ulcère ; contre-indiqué au 3e trimestre ; interaction avec le méthotrexate ≥ 15 mg/semaine et les AINS'],
    ['Ticagrelor, Brilique® (inhibiteur P2Y12 réversible)', 'Charge 180 mg puis 90 mg 2×/j avec AAS 75–150 mg/j, au moins 12 mois ; demi-vie d’environ 7 h', 'Dyspnée, saignement ; contre-indiqué après hémorragie intracrânienne, en insuffisance hépatique sévère et avec un inhibiteur puissant du CYP3A4 ; pas d’allaitement'],
    ['Prasugrel, Efient® (prodrogue, inhibiteur P2Y12 irréversible)', 'Charge 60 mg puis 10 mg/j (5 mg/j si < 60 kg ; généralement déconseillé ≥ 75 ans) ; durée conseillée 15 mois ; dans le NSTE-ACS, charge au moment de l’angioplastie', 'Contre-indiqué après AVC ou AIT et en Child-Pugh C ; arrêt ≥ 7 jours avant une chirurgie'],
    ['Clopidogrel, Plavix® (prodrogue, inhibiteur P2Y12 irréversible)', 'NSTE-ACS : charge 300 mg puis 75 mg/j ; après fibrinolyse : 75 mg/j avec ou sans charge', 'Réponse variable selon le CYP2C19 ; contre-indiqué en insuffisance hépatique sévère ; ne pas allaiter'],
    ['Énoxaparine, Clexane® (héparine de bas poids moléculaire)', 'NSTE-ACS : 1 mg/kg SC/12 h, 2 à 8 jours ; STEMI < 75 ans : 30 mg IV puis 1 mg/kg SC/12 h (2 premières doses ≤ 100 mg) ; ≥ 75 ans : pas de bolus, 0,75 mg/kg SC/12 h (≤ 75 mg) ; ClCr < 30 mL/min : 1 mg/kg/24 h', 'Saignement, thrombopénie induite par l’héparine (arrêt si chute de 30–50 % des plaquettes) ; demi-vie anti-Xa de 4 à 7 h'],
    ['Héparine non fractionnée, Liquémine® (héparine)', 'Bolus 5000–10 000 UI puis 20 000–30 000 UI/j, adaptés au TCA (1,5–2,5 × la norme ; contrôles à 1–2, 6, 12 et 24 h)', 'Thrombopénie immune (arrêt si plaquettes < 100 G/L ou chute > 50 %) ; demi-vie de 30 à 120 min'],
    ['Fondaparinux, Arixtra® (anti-Xa indirect)', '2,5 mg SC/j (1re dose IV dans le STEMI), 8 jours au maximum', 'Contre-indiqué si ClCr < 20 mL/min ; anticoagulation procédurale supplémentaire pendant l’angioplastie'],
    ['Ténectéplase, Metalyse® (fibrinolytique)', 'Bolus IV unique selon le poids : 30 mg (< 60 kg) à 50 mg (≥ 90 kg)', 'Hémorragie, notamment intracrânienne ; contre-indiquée après AVC hémorragique, en cas de saignement actif, de dissection aortique ou d’anticoagulant oral efficace'],
    ['Nitroglycérine, Nitrolingual® (dérivé nitré)', '1–2 pulvérisations sublinguales de 0,4 mg à 30 s d’intervalle si la douleur persiste', 'Céphalées, hypotension ; contre-indiquée si PAS < 90 mmHg, infarctus du ventricule droit, inhibiteur de phosphodiestérase ou riociguat'],
    ['Atorvastatine, Sortis® (statine)', '10 à 80 mg/j ; dose élevée dès l’hospitalisation selon l’ESC ; demi-vie d’environ 14 h', 'Myalgies (arrêt si CK > 5 × la norme), hépatite (transaminases > 3 × la norme) ; contre-indiquée pendant la grossesse et l’allaitement'],
    ['Métoprolol, Beloc ZOK® (bêtabloquant β1)', 'Insuffisance cardiaque stable : 12,5–25 mg/j, à doubler toutes les 2 semaines jusqu’à 200 mg/j', 'Contre-indiqué si FC < 45/min, PR > 0,24 s, PAS < 100 mmHg, choc ou décompensation ; ne pas arrêter brutalement'],
    ['Ramipril, Triatec® (IEC)', 'Après infarctus avec insuffisance cardiaque, dès le 3e jour : 2,5 mg 2×/j, entretien 5 mg 2×/j ; ClCr 20–50 mL/min : 1,25 mg/j, au maximum 5 mg/j', 'Toux, hyperkaliémie, insuffisance rénale, angio-œdème ; contre-indiqué pendant la grossesse ; 36 h d’intervalle avec le sacubitril'],
    ['Éplérénone, Inspra® (antagoniste minéralocorticoïde)', 'FEVG ≤ 40 % avec insuffisance cardiaque, entre J3 et J14 : 25 mg/j puis 50 mg/j selon la kaliémie', 'Hyperkaliémie : ne pas débuter si K > 5,0 mmol/L, arrêter si K ≥ 6,0 mmol/L ; contre-indiquée si DFGe < 30'],
   ]) + P('La pharmacocinétique explique la surveillance : l’effet plaquettaire du clopidogrel et du prasugrel dure la vie de la plaquette (7 à 10 jours), bien au-delà de leur demi-vie plasmatique ; l’énoxaparine et le fondaparinux s’accumulent en insuffisance rénale. La DAPT dure 12 mois par défaut selon l’ESC, plus courte si le risque hémorragique est élevé.', 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 19, 20, 21, 1))
SOC = F('Volets social et professionnel',
   UL(['L’assurance obligatoire des soins (LAMal, art. 25 et 32) prend en charge les traitements et la réadaptation cardiaque prescrite selon les critères d’efficacité, d’adéquation et d’économicité.',
       'L’assurance-accidents (LAA) n’intervient pas, sauf maladie professionnelle reconnue ; l’assurance-invalidité (LAI, art. 7, 8 et 28) soutient la réadaptation professionnelle si l’incapacité de travail se prolonge.',
       'L’arrêt de travail se décide selon la fonction ventriculaire et le poste : souvent 2 à 6 semaines pour un travail sédentaire, davantage pour un travail physique.',
       'La conduite automobile reprend après une pause fixée par la médecine du trafic (annexe 1 de l’OAC). Le premier groupe reprend en général après quelques jours à quelques semaines selon la FEVG et les arythmies ; les chauffeurs professionnels sont évalués plus strictement.']) + P('', 16, 17, 54))
SPE = F('Situations spéciales',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse et allaitement', 'Penser à la dissection coronaire spontanée ; l’angioplastie primaire reste le traitement du STEMI ; statine et IEC contre-indiqués ; ticagrelor et clopidogrel seulement si nécessaires et pas d’allaitement sous ticagrelor.'],
    ['Personne âgée', 'L’âge seul ne contre-indique pas la reperfusion ; énoxaparine sans bolus et dose réduite dès 75 ans ; prasugrel généralement déconseillé ; risque hémorragique et fragilité évalués.'],
    ['Enfant', 'Le SCA est exceptionnel ; une équipe pédiatrique recherche une cause congénitale, inflammatoire ou toxique.'],
    ['Insuffisance rénale (DFGe)', 'Énoxaparine 1 mg/kg/24 h si ClCr < 30 mL/min ; fondaparinux contre-indiqué si ClCr < 20 mL/min ; éplérénone contre-indiquée si DFGe < 30 ; contraste en volume minimal.'],
    ['Insuffisance hépatique', 'Ticagrelor et clopidogrel contre-indiqués si elle est sévère ; prasugrel contre-indiqué en Child-Pugh C ; statine contre-indiquée si la maladie est active.'],
   ]) + P('', 1, 7, 8, 11, 13, 15, 21))
C = F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Rythme (monitorage) et ECG', 'Continu ≥ 24 h, puis à chaque symptôme', 'Arythmie ventriculaire ou récidive du sus-décalage : réévaluation immédiate'],
    ['Saignement, hémoglobine, plaquettes, créatinine', 'Quotidiennement sous antithrombotiques', 'Chute des plaquettes de 30–50 % : arrêt de l’héparine et recherche d’une thrombopénie immune'],
    ['TCA sous héparine non fractionnée', '1–2, 6, 12 et 24 h après le début', 'Hors cible 1,5–2,5 × la norme : ajustement'],
    ['Kaliémie sous IEC ou éplérénone', 'Avant, à 1 semaine, à 1 mois puis selon le risque', 'K ≥ 6,0 mmol/L : arrêt de l’éplérénone'],
    ['FEVG à l’échocardiographie', 'Avant la sortie, puis 6–12 semaines plus tard si ≤ 40 %', 'FEVG ≤ 35 % persistante : discussion d’un défibrillateur implantable'],
    ['LDL, transaminases, CK', '4–6 semaines après chaque adaptation de la statine', 'LDL ≥ 1,4 mmol/L : intensification (ézétimibe, puis inhibiteur de PCSK9)'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Aucune douleur ni ischémie depuis au moins 24 heures.', 'Hémodynamique stable, sans insuffisance cardiaque non contrôlée.', 'Aucune arythmie significative depuis 24 heures.',
       'Pas de complication du point de ponction ni de saignement.', 'FEVG mesurée et traitement adapté.', 'DAPT, statine et autres traitements compris ; le patient reformule la conduite à tenir devant une douleur (nitroglycérine puis 144).',
       'Réadaptation cardiaque et rendez-vous de cardiologie organisés.', 'Retour possible à domicile dès 48–72 h chez un patient à faible risque (âge < 70 ans, FEVG > 45 %, atteinte d’un ou deux vaisseaux, angioplastie réussie, pas d’arythmie persistante).']) + P('', 1, 8, 9, 13, 21))
Dp = F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic dépend de l’étendue de la nécrose, de la FEVG, de la classe Killip, de l’âge, de la fonction rénale et des saignements ; la reperfusion précoce et la prévention secondaire l’améliorent fortement. '
     'La récidive est surtout précoce et justifie la DAPT, la statine et la réadaptation. '
     'La définition universelle de 2026 ouvre des pistes de recherche sur les seuils sexués de troponine, l’imagerie et l’intelligence artificielle ; ces outils ne sont pas encore validés pour la décision individuelle.', 1, 2), 'fenetre')
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge lève d’abord la menace vitale, rouvre ensuite l’artère coupable, puis prévient la récidive et le remodelage. '
   'Le médecin choisit les antithrombotiques selon la stratégie, l’âge, le poids, la fonction rénale et le risque hémorragique, avec les doses de l’information professionnelle suisse (AIPS). '
   'La réadaptation, l’éducation et le suivi font partie du traitement parce que l’arrêt prématuré de la DAPT expose à la thrombose de stent.', 1) +
 A + F('11.B Moyens', URG + GEN + MED + SOC + SPE, 'fenetre') + C + Dp))
# ---------- 12
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repère et traite le tabac, l’hypertension, la dyslipidémie, le diabète, l’obésité et la sédentarité selon le risque cardiovasculaire estimé (SCORE2). '
   'La prévention secondaire associe sevrage tabagique, DAPT, statine haute intensité, activité physique, alimentation méditerranéenne et vaccination contre la grippe. '
   'La prévention tertiaire limite le handicap par la réadaptation cardiaque, le soutien psychologique et le retour au travail.', 1, 55) +
 F('Les trois niveaux en pratique',
   TAB(['Niveau', 'Mesure', 'Contrôle'], [
    ['Primaire', 'Arrêt du tabac, pression < 140/90 puis < 130/80 mmHg si toléré, statine selon le risque SCORE2', 'Risque réévalué tous les 5 ans ou selon les facteurs'],
    ['Primaire', 'Pas d’AAS systématique sans maladie cardiovasculaire', 'Le risque hémorragique dépasse le bénéfice.'],
    ['Secondaire', 'LDL < 1,4 mmol/L et baisse ≥ 50 % ; HbA1c < 7 % chez le diabétique', 'LDL à 4–6 semaines'],
    ['Secondaire', 'Vaccination annuelle contre la grippe (plan de vaccination suisse, OFSP)', 'Elle réduit les événements cardiovasculaires.'],
    ['Tertiaire', 'Réadaptation cardiaque ambulatoire ou hospitalière, soutien psychologique', 'Capacité d’effort, anxiété, dépression, reprise du travail'],
   ]) + P('', 56))))
# ---------- 13
PTS.append(POINT(13, 'Points clés',
 P('Le médecin enregistre un ECG dans les 10 minutes devant des sueurs avec malaise ou douleur thoracique. '
   'Un STEMI se reperfuse sans attendre la troponine, idéalement par angioplastie dans les 120 minutes. '
   'Une troponine élevée prouve une lésion et non une thrombose, et une troponine normale précoce n’exclut pas un SCA. '
   'Les doses d’énoxaparine, de prasugrel et de fondaparinux dépendent de l’âge, du poids et du rein. '
   'La sortie exige une DAPT comprise, une statine haute intensité, une FEVG mesurée et une réadaptation organisée.', 1, 2)))
# ---------- 14
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Attendre la troponine devant un sus-décalage ST', 'La reperfusion se décide sur l’ECG et la clinique.'],
  ['Conclure à un infarctus sur une troponine élevée', 'Il faut une cinétique et un argument ischémique ; sinon il s’agit d’une lésion myocardique.'],
  ['Considérer la réponse à la nitroglycérine comme diagnostique', 'Le soulagement est non spécifique (spasme œsophagien, par exemple).'],
  ['Donner de l’oxygène à tous', 'L’oxygène est indiqué seulement si la saturation est < 90 %.'],
  ['Donner un nitré dans un infarctus inférieur avec hypotension', 'Il faut exclure un infarctus du ventricule droit (V4R) et ne pas donner de nitré si la PAS est < 90 mmHg.'],
  ['Prescrire du prasugrel après un AIT', 'Le prasugrel est contre-indiqué après AVC ou AIT.'],
  ['Faire le bolus IV d’énoxaparine à 78 ans', 'Dès 75 ans, on omet le bolus et on donne 0,75 mg/kg SC/12 h.'],
  ['Fibrinolyser une douleur thoracique non caractérisée', 'Une dissection aortique doit être exclue ; la fibrinolyse exige un STEMI.'],
  ['Arrêter la DAPT avant une extraction dentaire', 'On maintient l’AAS et on discute l’inhibiteur P2Y12 avec le cardiologue.'],
  ['Confondre la durée de 12 mois (ESC, Brilique) et de 15 mois (Efient)', 'Les deux libellés coexistent ; la prescription précise la stratégie retenue.'],
  ['Clore le bilan d’un MINOCA', 'L’IRM cardiaque cherche la cause.'],
 ]) + P('Ces pièges reprennent les erreurs fréquentes aux examens fédéraux et dans les recommandations ESC.', 1, 8, 11)))

SOURCES = sorted(SOURCES_ORIG.items()) + [
 (54, 'Fedlex. Ordonnance réglant l’admission des personnes et des véhicules à la circulation routière (OAC, RS 741.51), annexe 1 : exigences médicales minimales. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (55, 'Visseren FLJ et al. 2021 ESC Guidelines on cardiovascular disease prevention in clinical practice. Eur Heart J. 2021;42:3227–3337. Référence ajoutée lors de l’audit.'),
 (56, 'Office fédéral de la santé publique (OFSP). Plan de vaccination suisse 2026 : vaccination contre la grippe des personnes atteintes de maladies cardiovasculaires. Référence ajoutée lors de l’audit.'),
 (57, 'Collet JP et al. 2020 ESC Guidelines for the management of acute coronary syndromes in patients presenting without persistent ST-segment elevation. Eur Heart J 2021;42:1289–1367 (répartition des diagnostics finaux des douleurs thoraciques aiguës). Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (58, 'Erbel R et al. 2014 ESC Guidelines on the diagnosis and treatment of aortic diseases. Eur Heart J 2014;35:2873–2926. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (59, 'Konstantinides SV et al. 2019 ESC Guidelines for the diagnosis and management of acute pulmonary embolism. Eur Heart J 2020;41:543–603. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (60, 'Adler Y et al. 2015 ESC Guidelines for the diagnosis and management of pericardial diseases. Eur Heart J 2015;36:2921–2964. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (61, 'Ghadri JR et al. International Expert Consensus Document on Takotsubo Syndrome (Part I). Eur Heart J 2018;39:2032–2046. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (62, 'Garmendia Madariaga A et al. The incidence and prevalence of thyroid dysfunction in Europe: a meta-analysis. J Clin Endocrinol Metab 2014;99:923–931. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (64, 'Office fédéral de la statistique (OFS). Enquête suisse sur la santé 2022 : diabète déclaré. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (63, 'Lenders JWM et al. Pheochromocytoma and paraganglioma: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab 2014;99:1915–1942. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
]
CTX = {'_prefixe': 'Dans le SCA',
 'ecg': 'L’ECG est enregistré dans les 10 minutes et répété à chaque récidive ; un sus-décalage ST systématisé déclenche la reperfusion sans attendre la troponine.',
 'tropo': 'La troponine ultrasensible se dose à 0 h puis 1 h (ou 2 h) sur le même réactif ; elle prouve une lésion, pas sa cause.',
 'nfs': 'L’hémoglobine et les plaquettes conditionnent le risque hémorragique et la surveillance d’une thrombopénie sous héparine.',
 'creat': 'Le DFGe et la clairance adaptent l’énoxaparine, le fondaparinux et l’éplérénone et guident la prévention de l’atteinte rénale au contraste.',
 'iono': 'Le potassium et le magnésium se corrigent pour prévenir les arythmies ventriculaires ; la kaliémie conditionne IEC et éplérénone.',
 'gly': 'La glycémie se mesure d’emblée : une hypoglycémie imite le SCA, une hyperglycémie aggrave le pronostic.',
 'hba1c': 'L’HbA1c dépiste un diabète méconnu, fréquent après un SCA.',
 'lip': 'Le bilan lipidique initial sert de référence pour viser un LDL < 1,4 mmol/L avec une baisse ≥ 50 %.',
 'coag': 'La coagulation se vérifie avant fibrinolyse et anticoagulation ; un INR > 1,3 sous anticoagulant oral contre-indique la ténectéplase.',
 'echocoeur': 'L’échocardiographie mesure la FEVG, cherche une complication mécanique et un diagnostic concurrent ; elle ne retarde pas une reperfusion.',
 'coro': 'La coronarographie est l’examen de référence anatomique et permet l’angioplastie dans le même temps.',
 'irm': 'L’IRM cardiaque caractérise un MINOCA : myocardite, Takotsubo ou infarctus non obstructif.',
 'tdm': 'L’angio-TDM exclut une dissection aortique ou une embolie pulmonaire ; le coroscanner sert aux patients à faible risque.',
 'radio': 'La radiographie thoracique cherche une congestion, un élargissement médiastinal ou un pneumothorax, sans retarder la reperfusion.',
 'bnp': 'Le NT-proBNP précise une insuffisance cardiaque et le pronostic.',
 'crp': 'La CRP élevée oriente vers une péricardite ou une myocardite ; elle ne change pas la filière d’un STEMI.',
 'ck': 'Les CK se dosent devant des myalgies sous statine (arrêt si > 5 × la norme).',
 'hep': 'Les transaminases se contrôlent sous statine (arrêt si > 3 × la norme de façon durable).',
 'ddim': 'Les D-dimères servent à exclure une embolie pulmonaire de faible probabilité, pas une dissection.',
 'gds': 'Les gaz du sang et le lactate évaluent un choc ou une détresse respiratoire.',
 'lact': 'Un lactate > 2 mmol/L avec hypotension signe un choc cardiogénique.',
 'effort': 'L’épreuve d’effort est contre-indiquée à la phase aiguë ; elle sert à distance ou en cas de faible risque.',
 'holter': 'Le Holter cherche une arythmie après la phase aiguë si des palpitations ou une syncope persistent.',
 'tsh': 'La TSH cherche une thyrotoxicose à l’origine d’un infarctus de type 2.',
 'hcg': 'Le test de grossesse précède l’imagerie irradiante chez la femme en âge de procréer, sans retarder une reperfusion.',
 'scinti': 'La scintigraphie myocardique évalue ischémie et viabilité en situation stable.',
 'tep': 'La TEP au FDG évalue la viabilité myocardique en situation stable.',
 'tox': 'Le dépistage de la cocaïne s’impose devant un SCA du sujet jeune.',
 'echo': 'L’échographie au lit (POCUS) cherche une tamponnade, une dilatation droite ou une hypokinésie.',
 'doppler': 'Le Doppler artériel évalue une ischémie de membre ou un hématome au point de ponction.',
 'oxy': 'L’oxygène est donné seulement si la SpO₂ est < 90 %.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
