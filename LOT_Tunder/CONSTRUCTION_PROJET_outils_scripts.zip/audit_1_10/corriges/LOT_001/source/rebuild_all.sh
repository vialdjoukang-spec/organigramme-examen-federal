#!/bin/bash
# Reconstruit tous les cours AUDITÉS du LOT 1 (déterministe, local), puis relance les outils d'audit et les contrôles V7.
set -e
cd /workspace/audit_1_10
PY=./venv/bin/python
bash corriges/LOT_001/source/rebuild.sh >/dev/null
for g in corriges/LOT_001/source/gen_dx[0-9]*.py corriges/LOT_001/source/gen_ssp*.py; do
  [ -e "$g" ] || continue; case "$g" in *gen_dx6_part*) continue;; esac
  (cd corriges/LOT_001/source && ../../../venv/bin/python "$(basename "$g")" | tail -1)
done
$PY outils/decoupe.py LOT_001_AUDITE >/dev/null && $PY outils/examens.py LOT_001_AUDITE | tail -1 && $PY outils/style.py LOT_001_AUDITE | grep -v "^ " && $PY outils/score.py LOT_001_AUDITE
$PY outils/verif_v7.py corriges/LOT_001/*AUDITÉ*.html
