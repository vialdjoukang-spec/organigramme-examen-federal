# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.9 · Lymphome de Hodgkin (LOT 1, Appel B, Partie 4a/4b, r1 → audit du 24.10.2026).
Numérotation unifiée : S1–S11 et S21–S23 = sources de l’original 4b ; S12 = OFS/ONEC (original 4a, S12) ; S13–S18 ajoutées à l’audit."""
import sys; sys.path.insert(0, '/workspace/audit_1_10/outils')
from gen_v7 import *
from src_P4b import SOURCES_ORIG as SB
from src_P4a import SOURCES_ORIG as SA
POINT = mkPOINT('dx9')
M = dict(pref='dx9', dx='DX.9', court='Lymphome de Hodgkin', long='Lymphome de Hodgkin', dossier='corriges/LOT_001',
         fichier='LOT_001_DX9_Lymphome_de_Hodgkin_AUDITÉ.html', lot_titre='LOT 1 · G1 · Transpiration anormale',
         sous_titre='PROFILES 2023 · SSP G1 · LOT 1 · Appel B · V7 · version AUDITÉE',
         statut='Cette version corrige la monographie DX.9 du LOT 1 (Appel B, V7, Partie 4, révision r1) après audit médical et linguistique ; les doses proviennent des informations professionnelles suisses (AIPS).')
RS = T('cellules de Reed-Sternberg', 'Les cellules de Hodgkin et de Reed-Sternberg sont de grandes cellules tumorales dérivées de lymphocytes B, souvent à deux noyaux, qui expriment CD30 et CD15 ; elles ne forment que 1 à 2 % de la masse du ganglion.')
SYB = T('symptômes B', 'Les symptômes B sont trois signes définis : fièvre inexpliquée > 38 °C, sueurs nocturnes imposant de changer de linge, perte involontaire de plus de 10 % du poids en 6 mois.')
DEAU = T('score de Deauville', 'Le score de Deauville (1 à 5) compare la fixation du traceur sur la TEP au médiastin et au foie ; un score ≤ 3 signifie une rémission métabolique complète.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('Le lymphome de Hodgkin est un cancer des ganglions lymphatiques, formé à partir de lymphocytes B. '
   f'La forme classique, environ 95 % des cas, se reconnaît aux {RS} au sein d’un ganglion inflammatoire. '
   'La forme nodulaire à prédominance lymphocytaire est une entité distincte, et un ganglion ou des sueurs ne suffisent jamais à poser le diagnostic.', 2, 3) +
 F('Terminologie',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Lymphome de Hodgkin classique', 'Cellules de Reed-Sternberg CD30 positives, 95 % des cas', 'Lymphome non hodgkinien'],
    ['Forme nodulaire à prédominance lymphocytaire', 'Cellules CD20 positives, évolution lente', 'Forme classique, traitement différent'],
    ['Symptômes B', 'Fièvre > 38 °C, sueurs nocturnes, perte > 10 % du poids en 6 mois', 'Fatigue ou prurit seuls'],
    ['Stade', 'Localisation anatomique (Ann Arbor)', 'Groupe de risque'],
    ['Rémission métabolique complète', 'Deauville ≤ 3 sur la TEP', 'Guérison certaine'],
   ]) + P('Le prurit et la fatigue sont fréquents et gênants, mais ils ne comptent pas parmi les symptômes B.', 3))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, l’OFS et l’ONEC comptent environ 290 nouveaux cas par an (2018–2022), soit 3,7 pour 100 000 hommes et 2,7 pour 100 000 femmes, avec 28 décès annuels. '
   'L’âge médian au diagnostic est de 41 à 45 ans, avec un pic chez l’adulte jeune et un second après 55 ans.', 12, 1) +
 P('Les facteurs de risque sont l’infection antérieure par le virus d’Epstein-Barr, l’immunodépression (VIH) et les antécédents familiaux. Le pronostic est excellent, avec une mortalité faible sous traitement moderne.', 1, 2) +
 F('Chiffres, terrain et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Nouveaux cas en Suisse', '≈ 290 par an (166 hommes, 124 femmes)' + S(12), 'Moyenne 2018–2022'],
    ['Taux annuel', '3,7 / 100 000 (hommes), 2,7 / 100 000 (femmes)' + S(12), 'OFS et ONEC'],
    ['Décès annuels', '16 hommes, 12 femmes' + S(12), 'Mortalité faible'],
    ['Europe', '≈ 2–3 / 100 000 par an' + S(2), 'Recommandation EHA 2026'],
    ['Survie globale à 5 ans (stade avancé, adulte jeune)', '98 %' + S(2), 'Essai européen BrECADD'],
   ]) + P('Aucun pourcentage de lymphome de Hodgkin parmi les personnes consultant pour des sueurs n’est publié en Suisse.', 12))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Un lymphocyte B du centre germinatif perd son programme normal et survit grâce à des signaux anormaux, notamment la voie NF-kB et l’amplification de PD-L1. '
   'Les cellules tumorales, peu nombreuses, attirent un infiltrat de lymphocytes, de polynucléaires et de fibroblastes par des cytokines, ce qui forme la masse ganglionnaire. '
   'Ces cytokines expliquent les sueurs, la fièvre et la perte de poids, et la masse peut comprimer le médiastin. '
   'Le traitement cible ce mécanisme : chimiothérapie, brentuximab contre CD30 et nivolumab contre PD-1.', 2, 4, 5) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les ganglions cervicaux, sus-claviculaires et médiastinaux, reliés par les vaisseaux lymphatiques, sont les sites les plus souvent atteints ; la maladie s’étend de proche en proche.'],
    ['Physiologie', 'Pourquoi le ganglion grossit normalement : les lymphocytes B prolifèrent dans le centre germinatif puis meurent s’ils ne sont pas utiles.'],
    ['Physiopathologie', 'Les cellules de Reed-Sternberg échappent à cette mort, expriment CD30 et PD-L1 et entretiennent une inflammation qui paralyse l’immunité locale.'],
    ['Clinique', 'D’où l’adénopathie indolore, la masse médiastinale, les symptômes B (cytokines) et le prurit.'],
    ['Examens', 'Seule la biopsie prouve le lymphome ; la TEP-TDM donne le stade et la réponse ; VS et albumine reflètent l’inflammation.'],
    ['Traitement', 'La polychimiothérapie tue les cellules tumorales, le brentuximab vise CD30, le nivolumab lève le frein PD-1, la radiothérapie traite le site atteint.'],
   ]), 2, 3, 4, 5) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme (lésion)', 'Exploration qui le montre', 'Cible thérapeutique'], [
    ['Cellules CD30 positives', 'Immunohistochimie sur biopsie', 'Brentuximab védotine'],
    ['Surexpression de PD-L1', 'Histologie spécialisée', 'Nivolumab (anti-PD-1)'],
    ['Masse médiastinale', 'Radiographie, TEP-TDM', 'Chimiothérapie, radiothérapie si TEP de fin positive'],
    ['Inflammation systémique', 'VS, albumine, hémogramme', 'Disparaît avec la rémission'],
   ]) + P('Le mécanisme explique pourquoi la disparition des sueurs ne prouve pas la guérison.', 2))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant des sueurs nocturnes avec adénopathie, le médecin cherche d’abord une urgence : compression respiratoire par une masse médiastinale ou fièvre sous traitement. '
   'Il caractérise le ganglion persistant et le fait biopsier, parce que seule l’histologie distingue lymphome, infection et autre tumeur. '
   'Il garde en tête la tuberculose, le VIH et le lymphome non hodgkinien, qui donnent les mêmes sueurs.', 1, 2) +
 F('Diagnostic différentiel des sueurs nocturnes avec adénopathie (fréquence sourcée en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Lymphome de Hodgkin' + PR('≈ 3,2 / 100 000 par an (Suisse, 2018–2022)', 12), 'Adulte jeune, ganglion cervical ou médiastinal, prurit', 'Biopsie d’exérèse ganglionnaire'],
    ['Lymphome non hodgkinien' + PR('≈ 20 / 100 000 par an (Suisse)', 13), 'Âge plus élevé, adénopathies diffuses', 'Biopsie ganglionnaire'],
    ['Tuberculose ganglionnaire ou pulmonaire' + PR('6,0 / 100 000 par an (Suisse, 2025)', 14), 'Migration, contact, ganglion fistulisé', 'Biopsie avec culture, test moléculaire'],
    ['Infection par le VIH (nouveaux diagnostics)' + PR('≈ 4 / 100 000 par an (Suisse)', 15), 'Exposition, adénopathies diffuses', 'Test combiné de 4e génération'],
    ['Sarcoïdose' + PR('1–15 / 100 000 par an', 17), 'Adénopathies hilaires bilatérales, érythème noueux', 'Biopsie : granulome sans nécrose'],
    ['Mononucléose (virus d’Epstein-Barr)' + PR('fréquence suisse non publiée', 1), 'Adolescent, angine, splénomégalie', 'Sérologie EBV'],
    ['Hyperthyroïdie' + PR('≈ 0,75 % (Europe)', 16), 'Palpitations, tremblement, sans adénopathie', 'TSH'],
   ]) + P('Ces chiffres sont des incidences annuelles ou des prévalences dans la population ; ils ne sont pas des probabilités devant un patient donné. Un ganglion ferme, indolore, qui persiste plus de quelques semaines rend un lymphome plus probable.', 1))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P(f'L’entretien caractérise les sueurs et recherche les {SYB}, la durée de l’adénopathie, le prurit et la douleur des ganglions après l’alcool. '
   'Il précise le terrain avant le traitement (cœur, poumons, fertilité, grossesse, VIH) et les moyens de suivre les soins.', 1, 3) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Changez-vous de linge la nuit à cause des sueurs ?', 'C’est la définition d’une sueur B.', 'Le stade reçoit la mention B.'],
    ['Avez-vous perdu plus de 10 % de votre poids en 6 mois ?', 'Symptôme B défini.', 'Groupe de risque.'],
    ['Depuis quand ce ganglion est-il là ?', 'Un ganglion persistant doit être exploré.', 'Biopsie plutôt que surveillance.'],
    ['Êtes-vous essoufflé couché ? Toussez-vous ?', 'Une masse médiastinale peut comprimer.', 'Urgence d’imagerie et d’anesthésie.'],
    ['Avez-vous un projet d’enfant ?', 'La chimiothérapie menace la fertilité.', 'Préservation de la fertilité avant traitement.'],
   ])) +
 U('<b>Drapeaux rouges et urgence (appel du 144 si détresse respiratoire)</b> : orthopnée, stridor ou œdème du visage (compression médiastinale), fièvre sous chimiothérapie (neutropénie fébrile), déficit neurologique.', 2, 3)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure température, poids, fréquence respiratoire et saturation, puis il palpe toutes les aires ganglionnaires, le foie et la rate. '
   'Il décrit chaque ganglion (siège, taille, consistance, mobilité, douleur) sans lui attribuer un diagnostic à la palpation. '
   'L’absence de ganglion superficiel n’exclut pas une masse médiastinale ou abdominale.', 1, 2) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Palpation cervicale et sus-claviculaire', 'Ganglions < 1 cm, souples, mobiles', 'Ganglion ferme, indolore, > 1,5 cm : biopsie'],
    ['Palpation axillaire et inguinale', 'Petits ganglions mobiles', 'Adénopathies multiples : extension'],
    ['Palpation de la rate et du foie', 'Non palpables', 'Splénomégalie : atteinte splénique possible'],
    ['Inspection du cou et des veines', 'Pas de turgescence', 'Œdème en pèlerine : compression de la veine cave supérieure'],
    ['Peau', 'Intacte', 'Lésions de grattage : prurit'],
   ]) + P('Ces signes orientent la biopsie et le bilan ; aucun ne prouve le lymphome.', 1))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont les sueurs nocturnes, la fièvre, la perte de poids, le prurit, la toux et la dyspnée. '
   'Les signes physiques sont les adénopathies indolores, la splénomégalie et les signes de compression. '
   'Ils dessinent un syndrome tumoral ganglionnaire, un syndrome général et parfois un syndrome cave supérieur.', 1, 3) +
 F('Signes et syndromes définis',
   TAB(['Signe ou syndrome', 'Description', 'Mécanisme'], [
    ['Syndrome tumoral ganglionnaire', 'Adénopathies fermes, indolores, persistantes', 'Infiltrat inflammatoire autour des cellules tumorales'],
    ['Symptômes B', 'Fièvre > 38 °C, sueurs nocturnes, perte > 10 % en 6 mois', 'Cytokines tumorales'],
    ['Syndrome médiastinal', 'Toux, dyspnée, douleur thoracique', 'Masse médiastinale'],
    ['Syndrome cave supérieur', 'Œdème du visage et du cou, circulation veineuse collatérale', 'Compression de la veine cave'],
    ['Prurit', 'Démangeaisons diffuses', 'Cytokines, éosinophiles'],
   ]) + P('Termes : ' + T('adénopathie', 'Une adénopathie est un ganglion augmenté de volume, palpable sous la peau.') + ', '
          + T('splénomégalie', 'La splénomégalie est une augmentation de volume de la rate, palpable sous les côtes gauches.') + ', '
          + T('médiastin', 'Le médiastin est l’espace entre les deux poumons, qui contient le cœur, les gros vaisseaux et des ganglions.') + ', '
          + T('prurit', 'Le prurit est une démangeaison ; dans ce lymphome, il est fréquent mais ne compte pas comme symptôme B.') + ', '
          + T('orthopnée', 'L’orthopnée est un essoufflement qui apparaît en position couchée.') + '.', 1, 3))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('La recommandation de l’European Hematology Association (EHA) 2026 retient comme critère l’histologie d’un ganglion ou d’un site adéquat, avec cellules de Reed-Sternberg CD30 positives. '
   'Le stade d’Ann Arbor et les facteurs de risque du GHSG fixent le groupe, par exemple une VS > 50 mm/h sans symptôme B ou une masse médiastinale ≥ 1/3 du thorax. '
   'Une TEP positive ne suffit pas, car une fixation n’est pas une histologie.', 2, 3) +
 F('Stades et groupes de risque',
   TAB(['Catégorie', 'Critère', 'Conséquence'], [
    ['Stade I', 'Une seule région ganglionnaire', 'Groupe précoce si aucun facteur de risque'],
    ['Stade II', 'Plusieurs régions du même côté du diaphragme', 'Précoce ou intermédiaire selon les facteurs'],
    ['Stade III', 'Régions des deux côtés du diaphragme', 'Groupe avancé'],
    ['Stade IV', 'Atteinte extraganglionnaire diffuse', 'Groupe avancé'],
    ['Facteurs de risque GHSG (EHA 2026)', 'Masse médiastinale ≥ 1/3, atteinte extranodale, VS > 50 mm/h sans B ou > 30 mm/h avec B, ≥ 3 aires', 'Un stade IIB avec grosse masse rejoint le groupe avancé'],
   ]) + P('Le stade et le groupe de risque répondent à deux questions distinctes.', 2, 3))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Biopsie d’exérèse ganglionnaire', 'Gold standard : type de lymphome', 'Valeur globale non publiée ; architecture et phénotype nécessaires' + S(2), 'Geste chirurgical'],
    ['Microbiopsie', 'Diagnostic si exérèse impossible', 'Inférieure à l’exérèse', 'Échantillon parfois insuffisant'],
    ['Cytoponction fine', 'Orientation seulement', 'Insuffisante pour confirmer', 'Pas d’architecture'],
    ['TEP-TDM au FDG', 'Stade et réponse', 'Remplace la biopsie médullaire si TEP initiale' + S(2), 'Fixation non spécifique'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Biopsie d’exérèse du ganglion le plus accessible', 'Ganglion suspect persistant'],
    ['Première', 'TEP-TDM au FDG', 'Lymphome confirmé'],
    ['Bilan préthérapeutique', 'Hémogramme, VS, albumine, créatinine, tests hépatiques, VIH, hépatites B et C', 'Avant chimiothérapie'],
    ['Bilan préthérapeutique', 'Échocardiographie, fonction respiratoire, TSH, test de grossesse', 'Doxorubicine, bléomycine, irradiation'],
    ['Seconde', 'TEP intermédiaire après 2 cycles', 'Protocole adapté à la réponse'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La <b>biopsie</b> part fraîche au laboratoire d’hématopathologie, avec une demande d’immunohistochimie.',
       'La <b>TEP</b> se prépare selon le service (jeûne, glycémie) ; ces seuils restent à confirmer localement.',
       'La <b>préservation de la fertilité</b> est proposée avant le premier cycle.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['TEP de fin', 'Deauville ≤ 3', 'Rémission métabolique complète', 'Surveillance clinique'],
    ['TEP de fin', 'Deauville 4–5', 'Maladie résiduelle possible', 'Radiothérapie ou biopsie selon protocole'],
    ['TEP après 2 cycles (BrECADD)', 'Négative ou positive', 'Réponse précoce', '4 ou 6 cycles'],
    ['VS', '> 50 mm/h sans B', 'Facteur de risque', 'Groupe intermédiaire'],
    ['Fixation isolée sans histologie', '—', 'Non spécifique', 'Confronter, biopsier si besoin'],
    ['Résultat limite ou discordant (TEP et clinique)', 'Deauville 4 isolé', 'Inflammation possible', 'Biopsie avant tout changement'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'IRM sans gadolinium plutôt que TEP ; avis spécialisé'],
    ['Enfant et adolescent', 'Protocoles pédiatriques ; réduction de l’irradiation'],
    ['DFGe < 30 mL/min/1,73 m²', 'Pas de produit de contraste iodé sans nécessité ; brentuximab en monothérapie évité'],
    ['Allergie aux produits iodés', 'TDM sans contraste ou IRM'],
    ['Stimulateur cardiaque', 'Vérification de compatibilité avant IRM'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('La biopsie d’exérèse d’un ganglion prouve le lymphome et précise sa forme. '
   'La TEP-TDM au FDG établit le stade, puis guide le traitement selon la réponse. '
   'Le bilan préthérapeutique vérifie le cœur, les poumons, le rein, le foie, le VIH, les hépatites et la grossesse.', 2, 3) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une adénopathie persiste ou s’accompagne de symptômes B, alors le médecin demande une biopsie d’exérèse. '
   'Si le lymphome est confirmé, alors la TEP-TDM et les facteurs de risque définissent le groupe, et l’équipe choisit le parcours selon l’âge et l’aptitude. '
   'Si une compression médiastinale apparaît, il hospitalise en urgence.', 2) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Stade précoce favorable', '2 cycles ABVD puis radiothérapie du site atteint à 20 Gy', 'TEP de fin'],
    ['Stade intermédiaire', '2 cycles intensifiés puis 2 ABVD ; 30 Gy seulement si TEP de fin positive', 'TEP de fin'],
    ['Stade avancé, adulte apte ≤ 60 ans', 'BrECADD, 4 ou 6 cycles selon la TEP après 2 cycles', 'TEP intermédiaire'],
    ['Stade avancé, alternative ou > 60 ans', 'Nivolumab et AVD, 6 cycles', 'TEP de fin'],
    ['Patient fragile ou rechute', 'Décision individualisée, rattrapage ou greffe', 'Réunion multidisciplinaire'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Dose et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Adcetris®, brentuximab védotine (anticorps anti-CD30 conjugué), autorisation 62132', 'BrECADD : 1,8 mg/kg toutes les 3 semaines, maximum 180 mg, jusqu’à 6 cycles ; avec AVD : 1,2 mg/kg, maximum 120 mg, jours 1 et 15, 6 cycles', 'Neuropathie (grade 2–3 : pause puis 1,2 mg/kg ; grade 4 : arrêt), neutropénie ; bléomycine contre-indiquée ; G-CSF dès le jour 5 en BrECADD'],
   ['Opdivo®, nivolumab (anticorps anti-PD-1), autorisation 65660', '240 mg IV toutes les 2 semaines si ≥ 50 kg, 3 mg/kg si adolescent < 50 kg, avec AVD, 6 cycles', 'Pneumopathie, colite, hépatite, myocardite, atteintes endocriniennes ; contraception jusqu’à 5 mois après'],
   ['AVD dans N-AVD : doxorubicine (Adriblastin®), vinblastine (Velbe®), dacarbazine (Dacin®)', 'Doxorubicine 25 mg/m², vinblastine 6 mg/m², dacarbazine 375 mg/m² toutes les 2 semaines', 'Doxorubicine : dose cumulée maximale 550 mg/m² (400 mg/m² après irradiation médiastinale) ; vinblastine mortelle par voie intrathécale'],
  ]) + P('Pharmacodynamie : le brentuximab se lie à CD30 et libère la MMAE (monométhylauristatine E), qui inhibe les microtubules ; le nivolumab bloque PD-1 et lève le frein immunitaire. Pharmacocinétique : la demi-vie est de 4 à 6 jours pour le conjugué et d’environ 25 jours pour le nivolumab, et l’élimination de la MMAE passe par le CYP3A4.', 4, 5) + P('Les doses viennent des AIPS suisses ; le calendrier complet est validé par l’oncologue et la pharmacie d’oncologie.', 4, 5, 6, 8, 9, 11))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge vise la guérison, parce que la plupart des patients guérissent, tout en limitant les toxicités tardives (cœur, poumon, fertilité, cancers secondaires). '
   'Une équipe d’hématologie et de radiothérapie choisit le parcours selon le stade, le groupe de risque, l’âge et l’aptitude. '
   'La préservation de la fertilité et les soins de support précèdent le premier cycle.', 2, 4, 5) +
 F('11.A Buts : formes compliquées et non compliquées',
   P('Forme compliquée (compression médiastinale, neutropénie fébrile) : c’est une urgence, avec hospitalisation dans les heures qui suivent et antibiothérapie dans l’heure en cas de fièvre sous chimiothérapie.', 2, 5) +
   P('Dans la forme non compliquée, le but est la rémission complète durable avec le moins de séquelles possible.', 2)) +
 F('11.B Moyens',
   F('Mesures générales et ordre (forme non compliquée, traitement ambulatoire en hôpital de jour)',
     OL(['Annonce, information et réunion multidisciplinaire.',
         'Préservation de la fertilité et bilan préthérapeutique.',
         'Chimiothérapie selon le groupe, guidée par la TEP.',
         'Radiothérapie du site atteint si le protocole l’exige.',
         'Soins de support : G-CSF, antibioprophylaxie, vaccinations, soutien psychologique.']), 2, 5) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal (art. 25 et 32) prend en charge le traitement ; la LAA (art. 6 et 9) ne s’applique pas sauf origine accidentelle ; la LAI (art. 7, 8 et 28) intervient si l’incapacité dure.',
         'L’arrêt de travail couvre la chimiothérapie ; la reprise professionnelle est progressive, avec la Ligue suisse contre le cancer.',
         'La conduite automobile est déconseillée pendant les perfusions sédatives et en cas de neuropathie.']), 21, 22, 23, 1) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Décision spécialisée (Onkopedia 2025) ; nivolumab sauf nécessité absolue proscrit ; allaitement interrompu'],
      ['Personne âgée (> 60 ans)', 'Nivolumab et AVD ; bléomycine limitée à 2 cycles, omise après 70 ans'],
      ['Enfant et adolescent', 'Protocoles pédiatriques ; nivolumab dès 12 ans ; brentuximab non établi avant 18 ans'],
      ['Insuffisance hépatique', 'Brentuximab : Child-Pugh A à 1,2 mg/kg, B et C évitées'],
      ['Insuffisance rénale (DFGe < 30 mL/min)', 'Brentuximab en monothérapie évité'],
     ]), 5, 4, 10), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Hémogramme', 'Avant chaque cycle', 'Neutropénie : G-CSF, report'],
    ['Neuropathie', 'Chaque cycle', 'Grade 2–3 : pause du brentuximab'],
    ['TSH', 'Chaque année après irradiation cervicale', 'Hypothyroïdie : substitution'],
    ['Cœur, poumon, seins', 'Selon les doses reçues', 'Dépistage des séquelles'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Le patient est apyrétique et les polynucléaires sont remontés.', 'La douleur et la respiration sont contrôlées.', 'Le prochain cycle et la personne à joindre en cas de fièvre sont fixés.'])) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Dans l’essai européen chez l’adulte jeune au stade avancé, la survie sans progression à 5 ans atteint 93,6 % avec BrECADD contre 90,6 % avec le comparateur, et la survie globale 98 %. Ces chiffres de groupe ne prédisent pas la guérison individuelle. La recherche 2026 évalue l’immunothérapie plus précoce et la réduction de la radiothérapie.', 2))))
PTS.append(POINT(12, 'Prévention',
 P('Il n’existe pas de prévention primaire ni de dépistage validé de ce lymphome selon la Ligue suisse contre le cancer. '
   'La prévention secondaire consiste à faire explorer tout ganglion persistant et des symptômes B. '
   'La prévention tertiaire protège la fertilité, surveille le cœur, la thyroïde et les cancers secondaires.', 1, 2) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Aucune mesure validée'],
    ['Secondaire', 'Biopsie d’un ganglion persistant'],
    ['Tertiaire', 'Fertilité, TSH annuelle après irradiation, dépistage cardiovasculaire et mammaire'],
   ]))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin sait que les sueurs ne confirment pas un lymphome et que fatigue ou prurit ne sont pas des symptômes B. '
   'Il prouve le diagnostic par une biopsie d’exérèse. '
   'Il fixe le groupe avec le stade, les facteurs de risque et la TEP. '
   'Il connaît BrECADD et nivolumab–AVD comme standards 2026 du stade avancé. '
   'Il sait que la disparition des sueurs ne prouve pas la guérison.', 2, 3, 4, 5)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Le prurit est un symptôme B.', 'Non : seuls fièvre > 38 °C, sueurs nocturnes et perte > 10 % du poids comptent.'],
  ['Une cytoponction suffit au diagnostic.', 'Non : il faut une biopsie d’exérèse ou une microbiopsie.'],
  ['Un stade IIB est toujours précoce.', 'Non : avec une grosse masse, il rejoint le groupe avancé.'],
  ['Une fixation à la TEP prouve le lymphome.', 'Non : une fixation n’est pas une histologie.'],
  ['Brentuximab et bléomycine peuvent être associés.', 'Non : l’association est contre-indiquée.'],
  ['Une TEP de surveillance s’impose chaque année.', 'Non : pas d’imagerie systématique après rémission sans symptôme.'],
 ]) + P('Ces pièges reprennent l’EHA 2026 et les AIPS suisses.', 2, 4, 5)))
SOURCES = sorted([(k, v) for k, v in SB.items() if k <= 11 or k >= 21]) + [
 (12, SA[12]),
 (13, 'OFS, NICER, Registre du cancer de l’enfant. Rapport suisse sur le cancer 2021. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (14, '<a href="https://www.bag.admin.ch/dam/fr/sd-web/KgDGxmnGvfis/Bulletin-2026-Tuberculose.pdf">OFSP · Tuberculose en Suisse et au Liechtenstein en 2025</a>. Bulletin du 21 septembre 2026. Référence ajoutée lors de l’audit du 24 octobre 2026 (source du cours DX.7).'),
 (15, 'Office fédéral de la santé publique (OFSP). VIH, syphilis, gonorrhée et chlamydiose en Suisse : situation épidémiologique 2023. Bulletin OFSP. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (16, 'Garmendia Madariaga A et al. The incidence and prevalence of thyroid dysfunction in Europe: a meta-analysis. J Clin Endocrinol Metab 2014;99:923–931. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (17, 'Grunewald J et al. Sarcoidosis. Nat Rev Dis Primers 2019;5:45. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
]
SOURCES = sorted(SOURCES)
CTX = {'_prefixe': 'Dans le lymphome de Hodgkin',
 'biopsie': 'La biopsie d’exérèse ganglionnaire prouve le lymphome ; une cytoponction ne suffit pas.',
 'tep': 'La TEP-TDM au FDG établit le stade et guide le traitement selon la réponse (Deauville ≤ 3 : rémission métabolique).',
 'tdm': 'La TDM thoracique et abdominale complète le bilan anatomique.',
 'radio': 'La radiographie du thorax mesure la masse médiastinale (rapport au thorax).',
 'nfs': 'L’hémogramme est contrôlé avant chaque cycle (neutropénie).',
 'vs': 'Une VS > 50 mm/h sans symptôme B ou > 30 mm/h avec B est un facteur de risque GHSG.',
 'ldh': 'Les LDH reflètent la masse tumorale.',
 'crp': 'La CRP suit l’inflammation mais ne prouve pas le lymphome.',
 'hep': 'Les tests hépatiques précèdent la chimiothérapie et le brentuximab.',
 'creat': 'La créatinine précède la chimiothérapie ; DFGe < 30 mL/min : brentuximab en monothérapie évité.',
 'vih': 'Le test VIH fait partie du bilan préthérapeutique.',
 'sero': 'Les sérologies des hépatites B et C précèdent l’immunochimiothérapie.',
 'hcg': 'Le test de grossesse précède tout traitement.',
 'echocoeur': 'L’échocardiographie précède la doxorubicine.',
 'tsh': 'La TSH est mesurée chaque année après irradiation cervicale.',
 'bom': 'La biopsie médullaire n’est pas de routine si une TEP initiale est faite.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
