# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.8 · Infection par le VIH (LOT 1, Appel B, Partie 4a, r1 → audit du 24.10.2026)."""
import sys; sys.path.insert(0, '/workspace/audit_1_10/outils')
from gen_v7 import *
from src_P4a import SOURCES_ORIG
POINT = mkPOINT('dx8')
M = dict(pref='dx8', dx='DX.8', court='Infection par le VIH', long='Infection par le virus de l’immunodéficience humaine (VIH)', dossier='corriges/LOT_001',
         fichier='LOT_001_DX8_VIH_AUDITÉ.html', lot_titre='LOT 1 · G1 · Transpiration anormale',
         sous_titre='PROFILES 2023 · SSP G1 · LOT 1 · Appel B · V7 · version AUDITÉE',
         statut='Cette version corrige la monographie DX.8 du LOT 1 (Appel B, V7, Partie 4a, révision r1) après audit médical et linguistique ; les doses proviennent des informations professionnelles suisses (AIPS).')
PRIMO = T('primo-infection', 'La primo-infection est la phase des premières semaines après la contamination. Le virus se multiplie très vite et peut donner fièvre, angine, éruption et ganglions, avant que tous les anticorps apparaissent.')
FEN = T('fenêtre diagnostique', 'La fenêtre diagnostique est le délai entre la contamination et le moment où un test devient positif ; pour le test combiné de 4e génération, un résultat négatif n’est définitif qu’à 6 semaines de l’exposition.')
CD4 = T('lymphocytes T CD4', 'Les lymphocytes T CD4 sont les globules blancs « chefs d’orchestre » de l’immunité ; le VIH les infecte et les détruit, et leur nombre par microlitre mesure le niveau d’immunodépression.')
CV = T('charge virale', 'La charge virale compte les copies d’ARN (acide ribonucléique) du VIH par millilitre de plasma ; elle mesure la vitesse de multiplication du virus et l’efficacité du traitement.')
TAR = T('traitement antirétroviral', 'Le traitement antirétroviral associe en général trois (parfois deux) médicaments qui bloquent des étapes différentes de la multiplication du virus, pour éviter la sélection de résistances.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('L’infection par le virus de l’immunodéficience humaine (VIH) est une infection virale persistante qui détruit progressivement les défenses immunitaires. '
   'Le sida (syndrome de l’immunodéficience acquise) désigne seulement un stade avancé, défini par certaines infections ou tumeurs, et ne se confond pas avec la séropositivité. '
   f'Le {TAR} contrôle le virus et restaure l’immunité, mais il ne guérit pas l’infection.', 6, 3, 4) +
 F('Terminologie',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Infection par le VIH', 'Présence du virus prouvée par l’algorithme suisse en deux étapes', 'Un test réactif isolé'],
    ['Primo-infection', 'Premières semaines après la contamination, virus très abondant', 'Une infection ancienne découverte tard'],
    ['Sida', 'Stade défini par une maladie opportuniste ou tumorale', 'Toute séropositivité'],
    ['Suppression virale', 'Charge virale sous le seuil de quantification sous traitement', 'Une guérison'],
    ['VIH-1 et VIH-2', 'Deux types viraux ; le VIH-2 exige des tests adaptés et résiste à certaines classes', 'Un seul virus interchangeable'],
   ]) + P('La distinction évite d’annoncer un « sida » à toute personne nouvellement diagnostiquée.', 2, 6))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, l’OFSP recense chaque année des nouveaux diagnostics de VIH à un taux d’environ 4 pour 100 000 habitants, dont une part découverte au stade d’immunodépression. '
   'L’Europe de l’Union et de l’Espace économique européen déclare environ 5 nouveaux diagnostics pour 100 000 habitants par an.', 21, 22) +
 P('Les facteurs de risque sont les rapports non protégés, le partage de seringues et la transmission de la mère à l’enfant, et non l’âge, le sexe ou l’apparence. '
   'Sans traitement, la mortalité est élevée au stade sida, alors que le pronostic sous traitement efficace se rapproche de celui de la population générale.', 6, 7, 3) +
 F('Chiffres, terrain et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Nouveaux diagnostics en Suisse', '≈ 4 / 100 000 par an' + S(21), 'Surveillance OFSP ; ne mesure pas les transmissions de l’année'],
    ['Nouveaux diagnostics UE/EEE', '≈ 5 / 100 000 par an' + S(22), 'ECDC et OMS Europe, données 2023'],
    ['Patients ayant seulement des sueurs', 'Proportion suisse non publiée', 'Aucune donnée représentative pour le SSP G1' + S(6, 8)],
    ['Histoire naturelle sans traitement', 'Primo-infection, phase silencieuse de plusieurs années, puis sida', 'Le traitement interrompt cette évolution' + S(6, 7)],
   ]) + P('Un nombre de diagnostics d’une année inclut des infections anciennes ; il ne s’agit donc pas d’une incidence de transmission.', 6, 8))))
PTS.append(POINT(3, 'Physiopathologie',
 P(f'Le VIH entre dans les {CD4}, recopie son ARN en ADN (acide désoxyribonucléique) et l’intègre dans le génome de la cellule. '
   'Sa multiplication détruit ces lymphocytes, et les infections opportunistes apparaissent quand leur nombre baisse. '
   'Les sueurs viennent des cytokines de la primo-infection, d’une infection associée (tuberculose, pneumocystose) ou d’un lymphome, et non du virus seul. '
   'Le traitement bloque l’intégration ou la transcription inverse, ce qui fait chuter la charge virale et remonter les CD4.', 6, 7, 3) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les muqueuses génitale et rectale et le sang sont les portes d’entrée ; les ganglions et l’intestin hébergent la majorité des lymphocytes CD4.'],
    ['Physiologie', 'Pourquoi les CD4 comptent : ils coordonnent les lymphocytes B (anticorps) et T cytotoxiques et contrôlent les germes intracellulaires.'],
    ['Physiopathologie', 'Le virus s’intègre dans l’ADN des CD4 (réservoir définitif), se multiplie et détruit ces cellules ; l’immunité cellulaire s’effondre progressivement.'],
    ['Clinique', 'D’où le syndrome de primo-infection, puis une phase silencieuse, puis les infections opportunistes et les tumeurs du stade sida.'],
    ['Examens', 'Le test combiné détecte anticorps et antigène p24 ; la charge virale mesure la multiplication ; les CD4 mesurent les dégâts immunitaires.'],
    ['Traitement', 'Trois médicaments bloquent l’intégrase et la transcriptase inverse ; le réservoir persiste, d’où un traitement à vie.'],
   ]), 2, 3, 4, 6) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme (lésion)', 'Exploration qui le montre', 'Cible thérapeutique'], [
    ['Multiplication virale', 'Charge virale (copies/mL)', 'Inhibiteurs de l’intégrase et de la transcriptase inverse'],
    ['Destruction des CD4', 'Numération des lymphocytes T CD4', 'Traitement antirétroviral, prophylaxies selon le niveau'],
    ['Infection opportuniste', 'Imagerie, prélèvements ciblés', 'Traitement propre, calendrier antirétroviral adapté'],
    ['Résistance virale', 'Génotypage de résistance', 'Schéma actif choisi par l’équipe'],
   ]) + P('Le mécanisme explique pourquoi une suppression virale n’efface pas le réservoir et pourquoi l’arrêt du traitement fait rebondir le virus.', 3, 4))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant des sueurs avec syndrome général, le médecin recherche d’abord une détresse respiratoire, une atteinte neurologique ou visuelle et une réaction médicamenteuse sévère. '
   'Il précise ensuite les expositions et propose le test VIH, parce qu’aucun signe clinique ne prouve ni n’exclut l’infection. '
   'Il garde en tête les autres causes de sueurs, surtout la tuberculose et le lymphome, qui peuvent aussi compliquer le VIH.', 1, 3, 5) +
 F('Diagnostic différentiel des sueurs avec signes généraux (fréquence sourcée en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Infection par le VIH (nouveaux diagnostics)' + PR('≈ 4 / 100 000 par an (Suisse)', 21), 'Exposition, angine fébrile, éruption, candidose', 'Test combiné de 4e génération, charge virale'],
    ['Tuberculose' + PR('6,0 / 100 000 par an (Suisse, 2025)', 26), 'Toux > 2–3 semaines, migration, contact', 'Expectorations : test moléculaire, culture'],
    ['Lymphome non hodgkinien' + PR('≈ 20 / 100 000 par an (Suisse)', 24), 'Adénopathies, sueurs profuses, perte de poids', 'Biopsie ganglionnaire'],
    ['Lymphome de Hodgkin' + PR('≈ 3,2 / 100 000 par an (Suisse, 2018–2022)', 12), 'Adulte jeune, adénopathie, prurit', 'Biopsie ganglionnaire'],
    ['Endocardite infectieuse' + PR('3–10 / 100 000 par an (Europe)', 25), 'Fièvre, souffle, injection de drogues', 'Hémocultures, échocardiographie'],
    ['Hyperthyroïdie' + PR('≈ 0,75 % (Europe)', 23), 'Palpitations, tremblement, sans fièvre', 'TSH'],
    ['Mononucléose (virus d’Epstein-Barr)' + PR('fréquence suisse non publiée', 7), 'Angine, adénopathies chez l’adolescent', 'Sérologie EBV, test VIH en parallèle'],
   ]) + P('Ces chiffres sont des incidences annuelles ou des prévalences dans la population ; ils ne sont pas des probabilités devant un patient donné. Une exposition récente avec angine fébrile et éruption rend la primo-infection beaucoup plus probable.', 7))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien, confidentiel et non jugeant, précise les symptômes, les expositions sexuelles ou sanguines et leur date, les tests antérieurs et les prophylaxies. '
   'Le médecin explique pourquoi il propose le test et ce que signifie un résultat réactif, négatif ou douteux.', 1, 2, 5) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Quand a eu lieu l’exposition la plus récente ?', 'La fenêtre du test combiné dure 6 semaines.', 'Moins de 72 heures : prophylaxie post-exposition en urgence.'],
    ['Avez-vous eu fièvre, angine, éruption après cette exposition ?', 'Ce tableau évoque une primo-infection.', 'Test combiné et charge virale en parallèle.'],
    ['Prenez-vous une prophylaxie avant ou après exposition, et à quelles dates ?', 'Une infection sous prophylaxie peut être résistante.', 'Avis spécialisé, génotypage.'],
    ['Avez-vous une hépatite, une maladie du rein ou du foie ?', 'Le VHB et le rein orientent le choix du schéma.', 'Bithérapie ou combinaison fixe parfois exclues.'],
    ['Un projet de grossesse ou un allaitement ?', 'La sécurité des médicaments diffère.', 'Schéma adapté par l’équipe.'],
   ])) +
 U('<b>Drapeaux rouges et urgence (appel du 144 si détresse respiratoire ou trouble de conscience)</b> : dyspnée avec hypoxie, céphalée avec fièvre ou confusion, baisse visuelle, éruption fébrile sous traitement.', 3, 4, 5)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure température, poids, fréquence respiratoire et saturation, puis il examine la peau, la bouche, les ganglions et les poumons. '
   'Il recherche une raideur de nuque, un déficit neurologique et une baisse visuelle, signes d’une infection opportuniste. '
   'Un examen normal est fréquent et n’exclut pas l’infection, car aucun aspect physique ne remplace le test virologique.', 1, 3, 4, 7) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Inspection de la bouche', 'Muqueuse rose, sans dépôt', 'Muguet (candidose) ou leucoplasie chevelue : immunodépression'],
    ['Palpation ganglionnaire', 'Ganglions < 1 cm, mobiles', 'Adénopathies diffuses : primo-infection ; ganglion asymétrique : tuberculose ou lymphome'],
    ['Peau', 'Sans lésion', 'Éruption maculopapuleuse (primo-infection), zona, lésions violacées (sarcome de Kaposi)'],
    ['Auscultation, saturation', 'Murmure normal, saturation ≥ 95 %', 'Désaturation à l’effort : pneumocystose'],
    ['Fond d’œil, vision', 'Normaux', 'Rétinite à cytomégalovirus : urgence ophtalmologique'],
   ]) + P('Ces signes orientent les examens ; leur absence ne rassure pas.', 7))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fièvre, les sueurs, l’asthénie, l’angine, la diarrhée et la perte de poids. '
   'Les signes physiques sont les adénopathies, l’éruption, le muguet et la désaturation. '
   'Ils dessinent un syndrome de primo-infection ou un syndrome d’immunodépression, sans jamais confirmer le diagnostic.', 7, 3, 4) +
 F('Signes et syndromes définis',
   TAB(['Signe ou syndrome', 'Description', 'Mécanisme'], [
    ['Syndrome de primo-infection', 'Fièvre, angine, éruption, adénopathies, 2 à 4 semaines après l’exposition', 'Multiplication massive et réponse immunitaire'],
    ['Syndrome général', 'Sueurs nocturnes, fièvre prolongée, perte de poids', 'Cytokines, infection ou tumeur associée'],
    ['Immunodépression', 'Muguet, zona, infections répétées', 'Baisse des CD4'],
    ['Pneumocystose', 'Toux sèche, dyspnée d’effort, désaturation', 'Champignon Pneumocystis jirovecii, CD4 bas'],
    ['Syndrome de restauration immunitaire', 'Aggravation paradoxale après le début du traitement', 'Immunité qui « se réveille » contre un germe'],
   ]) + P('Termes : ' + PRIMO + ', ' + T('muguet', 'Le muguet est une candidose de la bouche : dépôts blancs qui se décollent, signe d’immunité affaiblie.') + ', '
          + T('infection opportuniste', 'Une infection opportuniste est causée par un germe peu dangereux pour une immunité normale, qui profite de l’immunodépression.') + ', '
          + T('sarcome de Kaposi', 'Le sarcome de Kaposi est une tumeur vasculaire liée au virus HHV-8 ; ses taches violacées de la peau font partie du stade sida.') + ', '
          + T('adénopathie', 'Une adénopathie est un ganglion augmenté de volume, palpable sous la peau.') + '.', 7, 3))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('La recommandation de l’OFSP (directive 2025, version 4 de 2026) retient comme critère un algorithme en au moins deux étapes et deux techniques différentes. '
   'Le test combiné de 4e génération (anticorps et antigène p24) dépiste avec une sensibilité > 99 % hors fenêtre, puis une autre technique confirme. '
   'Un test réactif isolé ne suffit pas, et un test négatif dans la fenêtre de 6 semaines n’exclut pas l’infection.', 1, 27) +
 F('Catégories et règles',
   TAB(['Situation', 'Critère', 'Conséquence'], [
    ['Infection confirmée', 'Test combiné réactif et confirmation par une autre technique', 'Déclaration, bilan initial, second prélèvement'],
    ['Primo-infection suspectée', 'Test moléculaire (charge virale) et test combiné en parallèle', 'Un test rapide seul n’est pas adapté'],
    ['Résultat négatif dans la fenêtre', 'Exposition de moins de 6 semaines', 'Nouveau test à 6 semaines'],
    ['Stade sida', 'Maladie définissant le sida', 'Classement de gravité, pas de diagnostic'],
   ]) + P('La directive vise les personnes de plus de 18 mois ; le diagnostic du nourrisson et les expositions professionnelles ont leurs textes propres.', 1))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Algorithme suisse en deux étapes', 'Gold standard : diagnostic confirmé', 'Aucune valeur universelle publiée pour tout l’algorithme' + S(1), 'Dépend de la fenêtre et du respect des étapes'],
    ['Test combiné de 4e génération', 'Anticorps et antigène p24', 'Sensibilité > 99 % hors fenêtre' + S(27), 'Négatif possible avant 6 semaines'],
    ['Charge virale (ARN VIH)', 'Multiplication virale, primo-infection', 'Seuil de quantification indiqué sur le compte rendu', 'Ne remplace pas la confirmation'],
    ['Test rapide', 'Orientation hors laboratoire', 'Inférieur au test combiné en primo-infection', 'Toujours confirmé'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Test combiné de 4e génération', 'Toute indication de dépistage'],
    ['Première', 'Charge virale en parallèle', 'Suspicion de primo-infection'],
    ['Bilan initial', 'Charge virale, CD4, génotypage, sérologies VHB, VHC, syphilis', 'Infection confirmée'],
    ['Bilan initial', 'Créatinine, DFGe, tests hépatiques, protéinurie', 'Choix et sécurité du schéma'],
    ['Seconde', 'Imagerie, ponction lombaire, biopsie', 'Infection opportuniste ou tumeur suspectée'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Le médecin obtient l’accord du patient après lui avoir expliqué le test ; un seul envoi initial suffit en général pour les deux étapes.',
       'Après confirmation, un <b>second prélèvement</b> vérifie rapidement la présence du virus dans le bilan initial.',
       'Le compte rendu de <b>charge virale</b> mentionne la limite de quantification de la méthode.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Test combiné non réactif', 'Exposition ≥ 6 semaines', 'Infection exclue', 'Conseils de prévention'],
    ['Test combiné non réactif', 'Exposition < 6 semaines', 'Fenêtre : non conclusif', 'Nouveau test à 6 semaines'],
    ['Test réactif, confirmation positive', '—', 'Infection', 'Déclaration, bilan, traitement rapide'],
    ['Charge virale indétectable sous traitement', 'Sous le seuil de quantification', 'Suppression, pas guérison', 'Poursuite du traitement'],
    ['Résultat discordant', '—', 'Primo-infection ou faux positif', 'Avis du laboratoire, nouveau prélèvement'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Dépistage proposé à chaque grossesse ; imagerie nécessaire non interdite'],
    ['Enfant de moins de 18 mois', 'Test moléculaire : les anticorps maternels faussent la sérologie'],
    ['DFGe < 30 mL/min/1,73 m²', 'Pas de produit de contraste iodé sans nécessité ; combinaisons fixes souvent exclues'],
    ['Allergie aux produits iodés', 'TDM sans contraste ou IRM'],
    ['Stimulateur cardiaque', 'Vérification de compatibilité avant IRM'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le test combiné de 4e génération dépiste, et une autre technique confirme l’infection. '
   'Si une primo-infection est suspectée, la charge virale est demandée en même temps, car le test combiné peut encore être négatif. '
   'Le bilan initial mesure charge virale, CD4 et résistance, et il recherche les hépatites B et C, la syphilis et l’état du rein.', 1, 5) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une exposition date de moins de 72 heures, alors le médecin organise immédiatement l’évaluation d’une prophylaxie post-exposition. '
   'Si le test est réactif, alors il fait confirmer, déclare et adresse rapidement à une équipe expérimentée, mais il traite d’abord une complication grave. '
   'Si le test est négatif dans la fenêtre, il le répète à 6 semaines.', 1, 10) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Exposition < 72 heures', 'Prophylaxie post-exposition en urgence', 'Test à 6 semaines'],
    ['Angine fébrile, éruption, exposition récente', 'Test combiné et charge virale', 'Résultat en 24–48 heures'],
    ['Infection confirmée, sans complication', 'Bilan initial, traitement rapide', 'Charge virale à 1 mois'],
    ['Méningite tuberculeuse ou cryptococcique', 'Traiter l’infection, différer les antirétroviraux selon l’équipe', 'Neurologique rapproché'],
    ['Résultat discordant', 'Avis du laboratoire, nouveau prélèvement', 'Algorithme complet'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Dose et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Biktarvy®, bictégravir 50 mg + emtricitabine 200 mg + ténofovir alafénamide 25 mg (inhibiteur de l’intégrase et deux inhibiteurs nucléosidiques), autorisation 66834', '1 comprimé 1×/j, avec ou sans repas, à vie ; adulte seulement selon la notice suisse', 'Contre-indications : rifampicine, millepertuis ; arrêt si clairance < 30 mL/min (hors hémodialyse) ; à jeun 2 heures avant magnésium ou aluminium'],
   ['Dovato®, dolutégravir 50 mg + lamivudine 300 mg (bithérapie), autorisation 67313', '1 comprimé 1×/j dès 12 ans et 40 kg, à vie', 'Exclu si antigène HBs positif, charge > 500 000 copies/mL, clairance < 30 mL/min ; 2 heures avant ou 6 heures après calcium ou fer ; cotrimoxazole à forte dose contre-indiqué ; arrêt si éruption fébrile'],
  ]) + P('Pharmacodynamie : le bictégravir et le dolutégravir inhibent l’intégrase, et l’emtricitabine, le ténofovir et la lamivudine bloquent la transcriptase inverse. Pharmacocinétique : la demi-vie est de 17,3 heures pour le bictégravir et d’environ 14 heures pour le dolutégravir, avec élimination surtout rénale pour l’emtricitabine et la lamivudine.', 3, 4) + P('Une dose de Biktarvy® oubliée se prend dans les 18 heures, sinon elle est omise. Les doses viennent des AIPS suisses ; le choix du schéma revient à l’équipe spécialisée.', 3, 4, 11))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge vise une charge virale durablement indétectable, parce que le contrôle du virus restaure l’immunité et empêche la transmission sexuelle. '
   'Le traitement débute rapidement après le diagnostic, avec une équipe expérimentée, mais une méningite tuberculeuse ou cryptococcique impose d’en discuter le moment. '
   'Le suivi contrôle l’observance, la tolérance, le rein et les interactions, et le médecin déclare le cas.', 2, 3, 4, 5) +
 F('11.A Buts : formes compliquées et non compliquées',
   P('Forme compliquée (pneumocystose avec hypoxie, méningite, rétinite) : c’est une urgence, avec hospitalisation dans les heures qui suivent et traitement de l’infection avant le calendrier antirétroviral.', 2, 5) +
   P('Dans la forme non compliquée, le but est la suppression virale durable, la restauration des CD4, la qualité de vie et la prévention de la transmission.', 5)) +
 F('11.B Moyens',
   F('Mesures générales et ordre (forme non compliquée, ambulatoire)',
     OL(['Annonce du diagnostic, soutien psychologique et social, confidentialité.',
         'Bilan initial complet, puis choix du schéma avec le patient.',
         'Traitement antirétroviral à vie, un comprimé par jour dans la plupart des cas.',
         'Prophylaxies selon les CD4 (par exemple cotrimoxazole si CD4 < 200/µL) et vaccinations.',
         'Déclaration et proposition de dépistage aux partenaires.']), 2, 5, 8) +
   MED +
   F('Volets social et professionnel',
     UL(['Le médecin déclare l’infection confirmée dans la semaine (ordonnance RS 818.101.126, annexe 1) ; la directive vise au plus 2 jours ouvrables.',
         'La LAMal (art. 25 et 32) prend en charge le traitement ; la LAA (art. 6 et 9) peut intervenir après une exposition professionnelle ; la LAI (art. 7, 8 et 28) ne concerne que les incapacités durables.',
         'L’arrêt de travail ne concerne que les phases de maladie ; le statut VIH n’a pas à être communiqué à l’employeur et ne limite pas l’activité professionnelle.',
         'La conduite automobile n’est limitée qu’en cas de confusion, d’atteinte neurologique ou visuelle.']), 8, 9, 18, 19, 20) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Traitement indispensable pour protéger l’enfant ; schéma vérifié par l’équipe ; allaitement discuté au cas par cas'],
      ['Personne âgée', 'Interactions et fonction rénale vérifiées'],
      ['Enfant et adolescent', 'Biktarvy® non autorisé avant 18 ans selon la notice suisse ; Dovato® dès 12 ans et 40 kg'],
      ['Insuffisance hépatique', 'Pas d’ajustement en Child-Pugh A ou B pour Dovato® ; atteinte sévère : avis'],
      ['Insuffisance rénale (clairance < 30 mL/min)', 'Combinaisons fixes exclues ; composantes séparées'],
      ['Co-infection par le VHB', 'Schéma actif sur le VHB (ténofovir) ; bithérapie exclue'],
     ]), 3, 4, 2), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Charge virale', '1, 3 et 6 mois, puis tous les 6 mois', 'Non indétectable à 6 mois : observance, interactions, résistance'],
    ['CD4', 'Au bilan initial puis selon le niveau', 'Bas : prophylaxies'],
    ['Créatinine, glucosurie, protéinurie', 'Avant puis régulièrement sous Biktarvy®', 'Clairance < 30 mL/min : arrêt'],
    ['Hémogramme', 'Sous Dovato® si clairance 30–49 mL/min', 'Anémie ou neutropénie : séparer les composantes'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['La complication est contrôlée et le patient est conscient et bien oxygéné.', 'Le patient dispose de ses comprimés et comprend les horaires et les interactions.', 'Le rendez-vous de suivi et la personne à joindre sont fixés.'])) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Les antirétroviraux ne guérissent pas l’infection, mais une suppression maintenue réduit fortement les complications et empêche la transmission sexuelle. Cette conclusion ne s’applique pas automatiquement à l’allaitement. La recherche 2026 évalue les traitements injectables à longue durée d’action et les stratégies de guérison fonctionnelle.', 2, 3, 4))))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur le préservatif, le matériel d’injection stérile, la prophylaxie préexposition chez les personnes exposées et la prophylaxie post-exposition dans les 72 heures. '
   'La prévention secondaire suit la directive suisse de dépistage de l’OFSP, tient compte de la fenêtre et traite rapidement. '
   'La prévention tertiaire maintient la suppression virale, prévient les infections opportunistes et soutient la santé mentale et sociale.', 6, 1, 2, 10) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Préservatif, prophylaxie préexposition, prophylaxie post-exposition, matériel stérile'],
    ['Secondaire', 'Dépistage, test des partenaires, traitement rapide'],
    ['Tertiaire', 'Observance, prophylaxies, vaccinations, suivi rénal'],
   ]))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin sait que les sueurs n’identifient ni le VIH ni un sida. '
   'Il demande test combiné et charge virale en parallèle si une primo-infection est suspectée. '
   'Il fait confirmer tout test réactif par une seconde technique. '
   'Il choisit le schéma selon la notice suisse, le VHB, les résistances, le rein et les interactions. '
   'Il sait qu’une suppression virale n’est pas une guérison et il déclare le cas dans la semaine.', 1, 2, 3, 4, 8)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Un test réactif prouve l’infection.', 'Non : il faut une confirmation par une autre technique.'],
  ['Un test négatif 3 semaines après l’exposition exclut l’infection.', 'Non : la fenêtre dure 6 semaines.'],
  ['Biktarvy® convient à une adolescente de 40 kg.', 'Non : la notice suisse le réserve à l’adulte.'],
  ['Rifampicine et Biktarvy® peuvent être associés.', 'Non : l’association est contre-indiquée.'],
  ['Cotrimoxazole à forte dose et Dovato® sont compatibles.', 'Non : la notice suisse les contre-indique.'],
  ['Charge virale indétectable signifie guérison.', 'Non : le réservoir persiste ; l’arrêt fait rebondir le virus.'],
  ['Il faut toujours débuter les antirétroviraux immédiatement.', 'Non : une méningite tuberculeuse ou cryptococcique impose de discuter le délai.'],
 ]) + P('Ces pièges reprennent la directive OFSP et les AIPS suisses.', 1, 3, 4)))
SOURCES = sorted(SOURCES_ORIG.items()) + [
 (21, 'Office fédéral de la santé publique (OFSP). VIH, syphilis, gonorrhée et chlamydiose en Suisse : situation épidémiologique 2023. Bulletin OFSP. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (22, 'European Centre for Disease Prevention and Control (ECDC), OMS Europe. HIV/AIDS surveillance in Europe 2024 – 2023 data. Stockholm : ECDC ; 2024. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (23, 'Garmendia Madariaga A et al. The incidence and prevalence of thyroid dysfunction in Europe: a meta-analysis. J Clin Endocrinol Metab 2014;99:923–931. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (24, 'OFS, NICER, Registre du cancer de l’enfant. Rapport suisse sur le cancer 2021. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (25, 'Delgado V et al. 2023 ESC Guidelines for the management of endocarditis. Eur Heart J 2023;44:3948–4042. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (26, '<a href="https://www.bag.admin.ch/dam/fr/sd-web/KgDGxmnGvfis/Bulletin-2026-Tuberculose.pdf">OFSP · Tuberculose en Suisse et au Liechtenstein en 2025</a>. Bulletin du 21 septembre 2026. Référence ajoutée lors de l’audit du 24 octobre 2026 (source du cours DX.7).'),
 (27, 'Branson BM et al. Laboratory testing for the diagnosis of HIV infection: updated recommendations. CDC and APHL ; 2014. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
]
CTX = {'_prefixe': 'Dans l’infection par le VIH',
 'vih': 'Le test combiné de 4e génération détecte anticorps et antigène p24 ; un résultat réactif exige une confirmation par une autre technique, et un négatif n’est définitif qu’à 6 semaines.',
 'cv': 'La charge virale mesure l’ARN du VIH en copies/mL ; elle aide au diagnostic de primo-infection et juge l’efficacité du traitement.',
 'cd4': 'Les lymphocytes T CD4 mesurent l’immunodépression et orientent les prophylaxies.',
 'sero': 'Les sérologies des hépatites B et C et de la syphilis font partie du bilan initial.',
 'creat': 'Une clairance < 30 mL/min exclut Biktarvy® et Dovato® en comprimé fixe.',
 'hep': 'Les tests hépatiques font partie du bilan initial et du suivi de tolérance.',
 'nfs': 'L’hémogramme surveille l’anémie et la neutropénie, surtout sous lamivudine si la clairance baisse.',
 'radio': 'La radiographie du thorax cherche une pneumocystose ou une tuberculose.',
 'tdm': 'La TDM thoracique précise une atteinte pulmonaire peu visible.',
 'pl': 'La ponction lombaire cherche une méningite cryptococcique ou tuberculeuse.',
 'irm': 'L’IRM cérébrale cherche une toxoplasmose, un lymphome ou une leucoencéphalopathie.',
 'biopsie': 'La biopsie d’un ganglion asymétrique cherche une tuberculose ou un lymphome.',
 'hcg': 'Le test de grossesse précède le choix du schéma.',
 'igra': 'L’IGRA dépiste une infection tuberculeuse chez la personne vivant avec le VIH.',
 'pcr': 'Les tests moléculaires ciblés recherchent les germes opportunistes.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
