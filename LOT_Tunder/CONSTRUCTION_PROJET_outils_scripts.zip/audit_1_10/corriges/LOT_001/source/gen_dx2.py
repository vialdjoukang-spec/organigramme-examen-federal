# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.2 · Hypoglycémie (LOT 1, Appel B, Partie 1, r1 → audit du 24.10.2026)."""
import sys; sys.path.insert(0, '/workspace/audit_1_10/outils')
from gen_v7 import *
from src_P1 import SOURCES_ORIG
POINT = mkPOINT('dx2')
M = dict(pref='dx2', dx='DX.2', court='Hypoglycémie', long='Hypoglycémie', dossier='corriges/LOT_001',
         fichier='LOT_001_DX2_Hypoglycemie_AUDITÉ.html', lot_titre='LOT 1 · G1 · Transpiration anormale',
         sous_titre='PROFILES 2023 · SSP G1 · LOT 1 · Appel B · V7 · version AUDITÉE',
         statut='Cette version corrige la monographie DX.2 du LOT 1 (Appel B, V7, Partie 1, révision r1) après audit médical et linguistique.')
WHIP = T('triade de Whipple', 'La triade de Whipple associe des symptômes compatibles, une glycémie veineuse basse mesurée au même moment et la disparition des symptômes après correction ; elle est exigée avant toute enquête étiologique chez la personne non diabétique.')
NEURO = T('neuroglucopénie', 'La neuroglucopénie désigne la souffrance cérébrale par manque de glucose : confusion, troubles du comportement, troubles visuels, déficit focal, convulsion, coma.')
UNAW = T('hypoglycémies non ressenties', 'Après des épisodes répétés, le seuil de déclenchement de la contre-régulation s’abaisse et les signes d’alerte adrénergiques disparaissent ; le patient passe directement à la neuroglucopénie. Éviter toute hypoglycémie pendant 2 à 3 semaines restaure souvent la perception.')
INSUL = T('insulinome', 'L’insulinome est une tumeur neuroendocrine pancréatique, le plus souvent bénigne et unique, qui sécrète de l’insuline de façon autonome ; il provoque des hypoglycémies à jeun ou d’effort. Environ 10 % sont multiples, notamment dans la néoplasie endocrinienne multiple de type 1 (NEM1).')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'L’hypoglycémie est une baisse du glucose plasmatique suffisante pour provoquer des symptômes ou exposer le cerveau à une {NEURO}. '
   'Chez la personne diabétique traitée, toute glycémie < 4,0 mmol/L impose une correction immédiate, tandis que la sévérité se définit par le besoin d’une aide extérieure et non par un chiffre. '
   f'Chez la personne non diabétique, le diagnostic exige la {WHIP} avec une glycémie veineuse ≤ 2,75–3,0 mmol/L. '
   'Elle figure parmi les causes de sueurs aiguës, car la réponse adrénergique précède souvent la neuroglucopénie.', 32, 33, 40, 57) +
 F('Terminologie et niveaux de gravité',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Niveau 1 (alerte)', 'Glycémie < 3,9–4,0 mmol/L chez la personne diabétique', 'Une maladie hypoglycémiante, qui exige la triade de Whipple'],
    ['Niveau 2 (cliniquement significative)', 'Glycémie < 3,0 mmol/L', 'Une hypoglycémie sévère, qui se définit cliniquement'],
    ['Niveau 3 (sévère)', 'Épisode qui exige l’aide d’un tiers, quel que soit le chiffre', 'Un coma : la sévérité commence avant la perte de conscience'],
    ['Hypoglycémie à jeun', 'Survient après une période sans apport ou à l’effort', 'Forme postprandiale, survenant 1 à 5 h après un repas'],
    ['Hypoglycémie postprandiale', 'Survient après un repas, typiquement après chirurgie gastrique ou bariatrique', 'Malaise vagal ou anxiété sans glycémie basse documentée'],
    ['Pseudo-hypoglycémie', 'Glycémie faussement basse : mesure capillaire en vasoconstriction, glycolyse dans un tube sans fluorure, leucocytose majeure', 'Une vraie hypoglycémie : vérifier la glycémie veineuse'],
   ]) + P('La correction se décide sur la glycémie capillaire, alors que l’enquête étiologique repose sur une glycémie veineuse contemporaine des symptômes.', 32, 40, 56))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, environ 5 % des adultes déclarent un diabète, soit près de 500 000 personnes, mais aucune statistique nationale ne recense les hypoglycémies. '
   'En Europe, la Fédération internationale du diabète estime à 61 millions le nombre d’adultes diabétiques, et les séries britanniques rapportent 30 à 40 % d’hypoglycémies sévères par an dans le diabète de type 1. '
   'Le risque concerne surtout l’insuline, les sulfonylurées et les glinides, et il augmente avec l’âge, l’insuffisance rénale, l’alcool et la dénutrition. '
   'Une hypoglycémie sévère s’associe à une mortalité accrue, environ doublée dans les grands essais du diabète de type 2.', 54, 55, 33) +
 F('Chiffres, terrains et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Diabète déclaré en Suisse', 'environ 5 % des adultes', 'Enquête suisse sur la santé (OFS), donnée déclarative'],
    ['Adultes diabétiques en Europe (IDF 2021)', '61 millions', 'Le dénominateur n’est pas celui des hypoglycémies.'],
    ['Hypoglycémie sévère, diabète de type 1', '30 à 40 % par an', 'Revue JBDS 2023, populations non sélectionnées'],
    ['Épisodes légers, diabète de type 1', 'environ 2 par semaine', 'JBDS 2023'],
    ['Patients hospitalisés diabétiques avec glycémie < 3,0 mmol/L', '7,0 %', 'Audit britannique 2019 (JBDS)'],
    ['Insulinome', 'environ 1 à 4 cas par million d’habitants et par an', 'Cause endogène rare, explorée seulement après preuve biologique'],
   ]) + P('Les sulfonylurées provoquent des hypoglycémies prolongées et récidivantes, surtout chez la personne âgée ou insuffisante rénale. Les épisodes répétés installent des hypoglycémies non ressenties, qui multiplient par six environ le risque d’épisode sévère.', 33, 38, 39, 40, 48))))
PTS.append(POINT(3, 'Physiopathologie',
 P('L’hypoglycémie résulte d’un excès d’insuline (exogène, sulfonylurée, insulinome), d’une production hépatique de glucose insuffisante (alcool, insuffisance hépatique ou surrénalienne) ou d’un manque de substrats (jeûne, dénutrition). '
   'Sous 3,6–3,9 mmol/L, l’organisme libère glucagon et adrénaline, ce qui provoque sueurs, tremblements, palpitations et faim. '
   'Sous 2,8–3,0 mmol/L environ, le manque de glucose cérébral provoque une neuroglucopénie, d’autant plus tôt que la répétition des épisodes a émoussé les alertes. '
   'Le traitement apporte du glucose ou mobilise le glycogène hépatique par le glucagon, puis supprime la cause.', 40, 33) +
F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Le pancréas endocrine (îlots de Langerhans) contient les cellules β, qui sécrètent l’insuline, et α, qui sécrètent le glucagon ; le foie stocke le glucose sous forme de glycogène.'],
    ['Physiologie', 'Pourquoi la glycémie est protégée : le cerveau consomme du glucose sans pouvoir le stocker ; dès qu’elle baisse, l’insuline s’arrête, puis le glucagon et l’adrénaline font libérer le glucose du foie.'],
    ['Physiopathologie', 'L’hypoglycémie survient quand l’insuline reste présente malgré la baisse (injection, sulfonylurée, insulinome) ou quand le foie ne peut plus produire de glucose (alcool, jeûne, insuffisance surrénalienne).'],
    ['Clinique', 'D’où deux familles de signes : l’alarme adrénergique (sueurs, tremblements, palpitations, faim), puis le manque de glucose au cerveau (confusion, convulsion, coma).'],
    ['Examens', 'Il faut prouver la glycémie basse au moment des symptômes ; l’insuline et le peptide C dosés à ce moment disent si l’insuline vient de l’extérieur ou du pancréas.'],
    ['Traitement', 'On redonne du glucose (bouche, veine) ou on fait libérer celui du foie (glucagon), puis on supprime la cause pour éviter la récidive.'],
   ]), 40, 57) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration qui le montre', 'Cible thérapeutique'], [
    ['Excès d’insuline exogène', 'Insuline élevée, peptide C effondré', 'Revoir la dose ; chercher une erreur ou une administration cachée'],
    ['Sulfonylurée ou glinide', 'Insuline et peptide C élevés, dépistage toxicologique positif', 'Glucose prolongé, surveillance ≥ 24–48 h, avis de Tox Info Suisse (145)'],
    ['Insulinome', 'Insuline, peptide C et pro-insuline inappropriés pendant l’hypoglycémie ; β-hydroxybutyrate bas', 'Exérèse chirurgicale'],
    ['Défaut de production (alcool, foie, cortisol)', 'Insuline basse, β-hydroxybutyrate élevé, cortisol bas', 'Glucose, thiamine chez l’alcoolique, hydrocortisone si insuffisance surrénalienne'],
    ['Tumeur non insulaire (IGF-2)', 'Insuline et peptide C bas, rapport IGF-2/IGF-1 élevé', 'Traitement de la tumeur'],
    ['Hypoglycémie postprandiale après chirurgie bariatrique', 'Glycémie basse 1 à 3 h après un repas', 'Fractionnement, réduction des sucres rapides'],
   ]) + P('Le glucagon stimule la glycogénolyse hépatique ; il échoue si les réserves sont vides (jeûne prolongé, alcool, insuffisance surrénalienne) et il peut aggraver un insulinome en stimulant l’insuline.', 34, 36, 40, 48))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant des sueurs, un malaise, un comportement inhabituel ou une altération de conscience, le médecin vérifie d’abord les fonctions vitales et mesure aussitôt la glycémie. '
   'Il corrige ensuite une hypoglycémie sans attendre le bilan étiologique, puis il recherche le déclencheur. '
   'Chez la personne non diabétique, il exige la triade de Whipple avant d’explorer et il sépare formes à jeun et postprandiales.', 32, 33, 40) +
 F('Diagnostic différentiel et causes (fréquence sourcée en exposant rouge)',
   TAB(['Situation et fréquence', 'Éléments d’orientation', 'Conduite'], [
    ['Diabète traité par insuline ou sulfonylurée' + PR('hypoglycémie sévère : 30–40 % par an dans le diabète de type 1', 33), 'Repas sauté, effort, alcool, erreur de dose, insuffisance rénale', 'Correction, puis adaptation du traitement'],
    ['Intoxication ou administration cachée' + PR('rare, non chiffrée', 57), 'Soignant, proche d’un diabétique, discordance insuline–peptide C', 'Dépistage des sulfonylurées, enquête délicate'],
    ['Maladie critique' + PR('glycémie < 3,0 mmol/L chez 7,0 % des diabétiques hospitalisés', 33), 'Sepsis, insuffisance hépatique ou rénale, dénutrition', 'Traitement de l’affection'],
    ['Insuffisance surrénalienne primaire' + PR('8–14 / 100 000', 60), 'Hypotension, hyponatrémie, mélanodermie', 'Cortisol et ACTH, hydrocortisone'],
    ['Insulinome' + PR('0,1–0,4 / 100 000 par an', 61), 'Hypoglycémies à jeun ou d’effort, prise de poids, personne non diabétique', 'Épreuve de jeûne hospitalière, puis localisation'],
    ['Diagnostics qui imitent les sueurs de l’hypoglycémie : thyrotoxicose' + PR('≈ 0,75 % (Europe)', 62) + ', phéochromocytome' + PR('≈ 0,8 / 100 000 par an', 63) + ', SCA, crise d’angoisse, sevrage alcoolique', 'Glycémie normale pendant les symptômes', 'Chercher ailleurs : la triade de Whipple n’est pas remplie'],
    ['AVC ou épilepsie' + PR('épilepsie active ≈ 0,6 % de la population', 64), 'Déficit focal, convulsion', 'Toujours mesurer la glycémie : l’hypoglycémie peut imiter un AVC'],
   ]))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’anamnèse précise le traitement exact, la dernière dose, les apports, l’effort, l’alcool, les maladies intercurrentes et la perception habituelle des épisodes. '
   'Le médecin demande qui a dû aider, si les épisodes récidivent, et si le patient vit seul ou conduit. '
   'Un drapeau rouge impose l’appel du 144 et l’hospitalisation.', 33, 40, 45) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Quel traitement prenez-vous ? À quelle dose et à quelle heure ?', 'Une sulfonylurée ou une insuline lente prolonge le risque.', 'La surveillance passe à ≥ 24–48 h.'],
    ['Avez-vous mangé, fait un effort, bu de l’alcool ?', 'Ils expliquent un épisode isolé.', 'L’éducation suffit si la cause est claire.'],
    ['Avez-vous eu besoin de quelqu’un pour vous resucrer ?', 'C’est la définition de l’épisode sévère.', 'Glucagon prescrit, réévaluation de la conduite.'],
    ['Sentez-vous venir vos hypoglycémies ?', 'Les alertes s’émoussent avec la répétition.', 'Capteur de glucose, objectifs assouplis.'],
    ['Les malaises surviennent-ils à jeun ou après les repas ?', 'Le mécanisme diffère.', 'Épreuve de jeûne ou évaluation postprandiale.'],
    ['Avez-vous accès à de l’insuline ou à des antidiabétiques sans être diabétique ?', 'Une administration cachée est possible.', 'Dépistage toxicologique.'],
    ['Avez-vous perdu du poids, êtes-vous fatigué, avez-vous des vertiges en vous levant ?', 'Ils évoquent une insuffisance surrénalienne.', 'Cortisol.'],
   ])) +
 U('<b>Drapeaux rouges (144, hospitalisation)</b> : coma, convulsion, impossibilité d’avaler, récupération incomplète, récidive, sulfonylurée ou insuline lente en surdosage, intoxication volontaire, enfant ou personne seule sans surveillance possible.', 32, 33, 38)))
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen débute par la séquence ABCDE (Airway, Breathing, Circulation, Disability, Exposure) et la glycémie capillaire. '
   'Le médecin décrit ensuite la vigilance avec le score de Glasgow, les signes adrénergiques et neurologiques, et cherche une cause associée. '
   'Il répète le même examen après correction, car un patient « réveillé » n’a pas forcément récupéré.', 27, 32, 40) +
 F('Normal, anomalie, valeur diagnostique',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Vigilance (Glasgow), orientation', 'Glasgow 15, orientation complète', 'Confusion, Glasgow < 15 : neuroglucopénie, voie orale interdite'],
    ['Peau', 'Sèche, chaude', 'Sueurs froides, pâleur : réponse adrénergique ; leur absence n’exclut rien'],
    ['Mains tendues', 'Pas de tremblement', 'Tremblement fin : réponse adrénergique'],
    ['Examen neurologique', 'Pas de déficit', 'Déficit focal : peut être hypoglycémique mais impose une réévaluation après correction'],
    ['Fréquence cardiaque, pression', 'FC 60–100/min', 'Tachycardie, pression différentielle large'],
    ['Recherche de cause', 'Pas de signe associé', 'Mélanodermie et hypotension (insuffisance surrénalienne), ictère (foie), sites d’injection lipodystrophiques'],
   ]) + P('La technique de mesure capillaire exige des mains propres et sèches. Les signes physiques ont une sensibilité faible : la glycémie capillaire, pratiquée en premier, a une valeur décisive, et un déficit persistant après normalisation impose une imagerie cérébrale.', 40, 42))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P(f'Le syndrome adrénergique associe sueurs, tremblements, palpitations, faim et anxiété, et le syndrome neuroglucopénique associe confusion, troubles visuels, déficit focal, convulsion et coma. '
   f'Les signes fonctionnels (faim, palpitations, vision trouble) se distinguent des signes physiques (sueurs, tremblement, confusion constatée). '
   f'Des {UNAW} font disparaître le syndrome adrénergique, et le premier signe devient alors la confusion.', 40, 42, 33) +
 F('Signes définis et mécanisme',
   TAB(['Signe', 'Comment le reconnaître', 'Mécanisme'], [
    ['Sueurs (signe physique)', 'Peau moite, souvent froide', 'Activation cholinergique sympathique des glandes sudoripares'],
    ['Tremblement (signe physique)', 'Tremblement fin des mains tendues', 'Adrénaline'],
    ['Palpitations (signe fonctionnel)', 'Le patient ressent des battements rapides', 'Stimulation β-adrénergique'],
    ['Faim (signe fonctionnel)', 'Fringale soudaine', 'Réponse cholinergique et hypothalamique'],
    ['Confusion, trouble du comportement (signe physique)', 'Discours incohérent, agressivité, ivresse apparente', 'Neuroglucopénie corticale'],
    ['Déficit focal, convulsion, coma', 'Hémiparésie, crise, Glasgow bas', 'Neuroglucopénie profonde'],
    ['Cauchemars, céphalées matinales', 'Rapportés par le patient ou le partenaire', 'Hypoglycémie nocturne'],
   ]))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Chez la personne diabétique, l’International Hypoglycaemia Study Group (2017) et l’ADA définissent le niveau 1 sous 3,9 mmol/L, le niveau 2 sous 3,0 mmol/L et le niveau 3 par le besoin d’une aide extérieure. '
   'Chez la personne non diabétique, l’Endocrine Society (2009) exige la triade de Whipple. Pendant une hypoglycémie < 3,0 mmol/L, une insuline ≥ 3 µU/mL, un peptide C ≥ 0,6 ng/mL et une pro-insuline ≥ 5 pmol/L signent un hyperinsulinisme endogène. '
   'Un chiffre bas sans symptôme ou un malaise sans glycémie basse ne suffit pas à poser le diagnostic d’une maladie hypoglycémiante.', 56, 57, 40) +
 F('Critères, seuils et conséquences',
   TAB(['Question', 'Critère (source, année)', 'Conséquence'], [
    ['Faut-il corriger ?', 'Glycémie < 4,0 mmol/L chez le diabétique traité (HUG 2022)', 'Correction immédiate'],
    ['L’épisode est-il sévère ?', 'Aide d’un tiers nécessaire (IHSG 2017, ADA 2026)', 'Glucagon prescrit, réévaluation du traitement et de la conduite'],
    ['Existe-t-il une maladie hypoglycémiante ?', 'Triade de Whipple, glycémie veineuse ≤ 2,75–3,0 mmol/L (SFE, Endocrine Society 2009)', 'Enquête étiologique'],
    ['L’hypoglycémie est-elle insulinodépendante ?', 'Insuline ≥ 3 µU/mL, peptide C ≥ 0,6 ng/mL, pro-insuline ≥ 5 pmol/L, β-hydroxybutyrate ≤ 2,7 mmol/L, hausse de glycémie ≥ 1,4 mmol/L après glucagon', 'Dépistage des sulfonylurées, puis localisation d’un insulinome'],
    ['Insuline exogène ?', 'Insuline élevée avec peptide C bas', 'Administration d’insuline (accidentelle ou cachée)'],
   ]) + P('Les seuils de l’hyperinsulinisme dépendent de la méthode : le laboratoire précise la réactivité de son dosage aux analogues de l’insuline, qu’une méthode peut ne pas détecter.', 49, 50, 57))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Glycémie veineuse au laboratoire (tube fluoré)', 'Référence de la valeur glycémique', 'Méthode de référence', 'La glycolyse in vitro abaisse la valeur si le tube attend.'],
    ['Épreuve de jeûne de 72 h hospitalière', 'Référence du diagnostic d’insulinome', 'Sensibilité d’environ 95–99 % à 72 h ; spécificité élevée avec les dosages contemporains', 'Lourde, spécialisée'],
    ['Glycémie capillaire', 'Décision d’urgence', 'Rapide ; erreur de 10–15 % aux valeurs basses', 'À confirmer par une glycémie veineuse pour l’enquête'],
    ['Échoendoscopie pancréatique', 'Localisation d’un petit insulinome', 'Sensibilité d’environ 80–90 % entre des mains expertes', 'Dépend de l’opérateur ; peut manquer la queue'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Glycémie capillaire immédiate', 'Toujours, avant tout autre geste'],
    ['Première', 'Glycémie veineuse avec, pendant l’épisode, insuline, peptide C, pro-insuline, β-hydroxybutyrate, dépistage des sulfonylurées (personne non diabétique)', 'Prélevée avant le resucrage seulement si cela ne le retarde pas'],
    ['Première', 'Créatinine (DFGe), tests hépatiques, électrolytes, HbA1c, alcoolémie, cortisol', 'Cause iatrogène, rénale, hépatique ou surrénalienne'],
    ['Seconde', 'Épreuve de jeûne hospitalière de 72 h', 'Triade de Whipple sans cause évidente et sans prélèvement spontané'],
    ['Seconde', 'TDM pancréatique multiphasique ou IRM, puis échoendoscopie', 'Hyperinsulinisme endogène prouvé'],
    ['Seconde', 'TEP aux analogues du GLP-1 ou stimulation artérielle calcique', 'Preuve biologique avec localisation négative (centre expert)'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Le <b>prélèvement critique</b> se fait pendant l’hypoglycémie, sur tube fluoré acheminé rapidement ; il ne doit jamais retarder la correction d’une neuroglucopénie.',
       'L’<b>épreuve de jeûne</b> se fait à l’hôpital, au maximum 72 h, avec consentement, arrêt des médicaments non indispensables, voie veineuse et heure du dernier repas notée ; le patient boit de l’eau et des boissons sans calories.',
       'Pendant le jeûne, le centre mesure la glycémie toutes les 6 h, puis toutes les 1–2 h sous 3,3 mmol/L ; il fait le prélèvement critique et arrête l’épreuve sous 2,5 mmol/L avec neuroglucopénie ou à 72 h.',
       'Les <b>dosages hormonaux</b> sont faussés après resucrage : un prélèvement après perfusion de glucose n’a plus de valeur étiologique.']), 'fenetre') +
 F('9.d Interprétation du profil pendant l’hypoglycémie',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Insuline et peptide C élevés, dépistage négatif', 'Insuline ≥ 3 µU/mL, peptide C ≥ 0,6 ng/mL', 'Insulinome ou hypoglycémie auto-immune', 'Imagerie pancréatique'],
    ['Insuline et peptide C élevés, dépistage positif', 'Sulfonylurée détectée', 'Prise de sulfonylurée', 'Surveillance prolongée, enquête'],
    ['Insuline élevée, peptide C bas', 'Peptide C < 0,6 ng/mL', 'Insuline exogène', 'Enquête, protection du patient'],
    ['Insuline basse, β-hydroxybutyrate élevé', 'β-hydroxybutyrate > 2,7 mmol/L', 'Hypoglycémie non insulinique (jeûne, alcool, cortisol)', 'Cortisol, foie, rein'],
    ['Insuline basse, β-hydroxybutyrate bas', '—', 'IGF-2 tumoral ou trouble de l’oxydation des acides gras', 'IGF-2, avis spécialisé'],
    ['Glycémie veineuse normale pendant les symptômes', '> 3,0 mmol/L', 'Pas d’hypoglycémie : le résultat est négatif', 'Chercher un autre diagnostic'],
   ]) + P('Un résultat discordant (capillaire bas, veineux normal) fait suspecter une pseudo-hypoglycémie ou un capteur décalé.', 40, 48, 57), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Enfant hors diabète (PEDLAUS 2025)', 'Prélèvement critique si glucose < 2,8 mmol/L : glucose de laboratoire, cétones, lactate, gazométrie, insuline, peptide C, cortisol, hormone de croissance, urines de la première miction'],
    ['Grossesse', 'Échographie ou IRM sans gadolinium plutôt que TDM ; l’épreuve de jeûne n’est pas faite'],
    ['DFGe abaissé', 'Contraste iodé selon l’ESUR ; insuline et peptide C s’élèvent en insuffisance rénale (interprétation prudente)'],
    ['Contre-indication à l’IRM (stimulateur non compatible)', 'TDM multiphasique et échoendoscopie'],
    ['Après chirurgie bariatrique', 'Évaluation postprandiale avec glycémie contemporaine ; pas d’épreuve de jeûne systématique'],
   ]) + P('', 26, 51, 52, 53), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('La glycémie capillaire décide de l’urgence, mais la glycémie veineuse au laboratoire est la référence et l’épreuve de jeûne de 72 h le gold standard de l’insulinome. '
   'En première intention, le médecin mesure la glycémie capillaire puis, chez la personne non diabétique, il prélève pendant l’épisode glycémie veineuse, insuline, peptide C et β-hydroxybutyrate. '
   'En seconde intention, il organise l’épreuve de jeûne puis l’imagerie pancréatique, uniquement après preuve biologique.', 32, 40, 48) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si le patient est conscient et avale sans risque, alors il reçoit du sucre par voie orale, sinon il reçoit du glucose IV ou du glucagon. '
   'Lorsque la glycémie reste < 4,0 mmol/L au contrôle, le médecin répète la correction. '
   'Si la cause est prolongée ou inconnue, il hospitalise et oriente l’enquête.', 32, 33) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Conscient, déglutition sûre, glycémie < 4,0 mmol/L', '15 g de glucides rapides (4 morceaux de sucre ou 1,5 dL de boisson sucrée non allégée) ; 30 g si < 2,5 mmol/L', 'Glycémie à 20–30 min'],
    ['Glycémie toujours < 4,0 mmol/L au contrôle', 'Nouvelle correction', 'Recontrôle, recherche de la cause'],
    ['Glycémie ≥ 4,0 mmol/L', 'Collation glucidique lente ou repas', 'Surveillance selon le traitement'],
    ['Conscience altérée, voie veineuse disponible', 'Glucose 40 % : 32 g (8 ampoules de 4 g/10 mL) IV lent en 3–5 min (protocole HUG 2022)', 'Glycémie à 10 min'],
    ['Conscience altérée, pas de voie veineuse', 'Glucagon 1 mg SC ou IM, ou 3 mg par voie nasale', 'Sans réponse en 10 min : glucose IV'],
    ['Sulfonylurée ou insuline lente en surdosage', 'Hospitalisation, perfusion de glucose', 'Glycémie toutes les 1–2 h, surveillance ≥ 24–48 h'],
    ['Personne non diabétique avec triade de Whipple', 'Bilan pendant l’épisode', 'Épreuve de jeûne si nécessaire'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Dose AIPS et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Glucose 40 %, Glucosum Bichsel® (soluté hypertonique)', 'Protocole HUG 2022 : 32 g IV lent en 3–5 min, puis glucose 10 % et glycémie toutes les 2–3 h ; perfusion AIPS ≤ 0,5 g/kg/h, voie centrale conseillée pour 20–50 %', 'Phlébite et nécrose en cas d’extravasation ; hyperglycémie, hypokaliémie'],
   ['Glucagon, GlucaGen® (hormone hyperglycémiante)', 'Adulte et enfant > 25 kg ou > 6–8 ans : 1 mg SC ou IM ; enfant < 25 kg ou < 6–8 ans : 0,5 mg ; réponse en 10 min ; demi-vie de 3–6 min', 'Nausées, vomissements ; contre-indiqué en cas de phéochromocytome ; inefficace si le glycogène est épuisé ; pas en perfusion IV ; potentialise la warfarine'],
   ['Glucagon nasal, Baqsimi® (hormone hyperglycémiante)', 'Dès 1 an : 3 mg dans une narine, dose unique ; pic à 15 min ; demi-vie de 35 min', 'Nausées, céphalées, irritation nasale ; contre-indiqué en cas de phéochromocytome ; utilisable pendant la grossesse et l’allaitement'],
   ['Thiamine (vitamine B1)', 'Avant ou avec le glucose chez la personne alcoolique ou dénutrie, selon le protocole local', 'Prévient l’encéphalopathie de Gayet-Wernicke'],
  ]) + P('Mécanisme d’action et durée : le glucose agit en quelques minutes mais pas plus longtemps que la perfusion, alors que le glucagon libère le glycogène hépatique pendant 20 à 30 minutes ; une collation de glucides lents doit donc suivre. Interaction : les bêtabloquants masquent les signes adrénergiques, et l’indométacine réduit l’effet du glucagon. Après une hypoglycémie sévère sous insuline dégludec (Tresiba®), le protocole HUG fait sauter l’injection suivante et réduit la dose ; sous gliclazide (Diamicron® MR), la surveillance dure au moins 48 h, et sous glimépiride (Glimeryl®) au moins 24 h, car la baisse peut survenir de 12 à 72 h. Un analogue de la somatostatine (octréotide) se discute avec le centre d’information toxicologique (Tox Info Suisse, 145) en cas de surdosage de sulfonylurée.', 32, 34, 35, 36, 38, 39, 58))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge corrige d’abord la glycémie et la neuroglucopénie, puis elle prévient la récidive et traite la cause. '
   'La voie orale exige une conscience et une déglutition sûres, et le glucose IV ou le glucagon la remplacent dans les autres cas. '
   'La durée de surveillance dépend du médicament en cause, parce qu’une sulfonylurée ou une insuline lente agit bien plus longtemps que la correction.', 32, 33, 34, 36) +
 F('11.A Buts : corriger l’urgence vitale, puis prévenir la récidive',
   P('Dans la forme compliquée, le but immédiat est un retour de conscience en quelques minutes. Au contrôle, l’objectif est une glycémie ≥ 4,0 mmol/L avec une récupération neurologique complète. À distance, le capteur doit montrer moins de 4 % du temps sous 3,9 mmol/L et moins d’1 % sous 3,0 mmol/L.', 32, 46), 'fenetre') +
 F('11.B Moyens',
   F('Forme compliquée (coma, convulsion, impossibilité d’avaler) : urgence',
     TAB(['Temps', 'Geste'], [
      ['Minute 0', 'Position latérale de sécurité, appel du 144, rien par la bouche'],
      ['Minutes 1–5', 'Glucose 40 % 32 g IV lent ou glucagon 1 mg SC/IM (3 mg par voie nasale)'],
      ['Minute 10', 'Glycémie ; si < 4,0 mmol/L ou réveil incomplet, nouvelle dose de glucose IV'],
      ['Heures suivantes', 'Glucose 10 % en perfusion si la cause persiste, glycémie toutes les 1–2 h, kaliémie'],
     ]) + P('Une convulsion hypoglycémique se traite par le glucose, pas d’abord par un antiépileptique.', 32, 34)) +
   F('Forme non compliquée : mesures générales et ordre',
     OL(['15 g de glucides rapides (30 g si < 2,5 mmol/L), contrôle à 20–30 min, répétition si nécessaire.',
         'Collation de glucides lents ou repas, pour reconstituer les réserves.',
         'Recherche du déclencheur et adaptation du traitement ; pas de suppression automatique de la dose suivante, sauf règle propre au produit.',
         'Éducation : signes d’alerte, « règle des 15 », glucagon pour l’entourage, sucre toujours sur soi, capteur de glucose si épisodes répétés.']), 32, 33) +
   MED +
   F('Traitement non médicamenteux et chirurgie',
     P('L’insulinome localisé se traite par exérèse, avec épargne du pancréas lorsque c’est possible (énucléation). En attente de chirurgie, des repas fractionnés et un traitement freinateur (diazoxide ou analogue de la somatostatine) se discutent en centre spécialisé. L’hypoglycémie postprandiale après chirurgie bariatrique se traite d’abord par le fractionnement et la réduction des sucres rapides.', 40, 48)) +
   F('Volets social et professionnel',
     UL(['La LAMal (art. 25 et 32) couvre le traitement, le glucagon et le capteur de glucose selon la liste des moyens et appareils (LiMA).',
         'La LAA n’intervient qu’en cas d’accident causé par l’hypoglycémie ; l’assurance-invalidité (LAI, art. 7 et 8) soutient l’adaptation d’un poste à risque (travail en hauteur, conduite professionnelle).',
         'Un arrêt de travail court se justifie après un épisode sévère, le temps d’adapter le traitement ; un poste de sécurité se réévalue.',
         'Conduite automobile (directive SSED/SSML 2025) : après une hypoglycémie au volant, le conducteur s’arrête, se resucre et attend 45 minutes ; à risque élevé, il ne conduit pas sous 5 mmol/L ; après une hypoglycémie sévère, il s’abstient jusqu’à la réévaluation, avec des exigences plus strictes pour le groupe professionnel.']) + P('', 16, 17, 45)) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Les objectifs serrés exposent aux hypoglycémies ; glucagon GlucaGen® et Baqsimi® utilisables ; suivi en diabétologie obstétricale.'],
      ['Personne âgée', 'Hypoglycémies peu symptomatiques, chutes, confusion ; éviter les sulfonylurées ; objectifs d’HbA1c assouplis (< 8 %).'],
      ['Enfant', 'Glucagon 0,5 mg si < 25 kg, Baqsimi® dès 1 an ; le protocole adulte de 32 g IV n’est jamais transposé ; filière pédiatrique.'],
      ['Insuffisance hépatique', 'Néoglucogenèse réduite : glucagon moins efficace, surveillance prolongée.'],
      ['Insuffisance rénale (DFGe)', 'L’insuline et les sulfonylurées s’accumulent : surveillance prolongée et réduction des doses.'],
     ]) + P('', 34, 36, 38, 40, 51)), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Glycémie après correction orale', 'À 20–30 min', '< 4,0 mmol/L : nouvelle correction'],
    ['Glycémie et conscience après glucose IV', 'À 10 min, puis toutes les 2–3 h', 'Persistance ou réveil incomplet : poursuite du secours et de l’enquête'],
    ['Surdosage de gliclazide', 'Pendant au moins 48 h', 'Toute récidive prolonge la surveillance.'],
    ['Surdosage de glimépiride', 'Pendant au moins 24 h, baisse possible de 12 à 72 h', 'Idem'],
    ['Kaliémie sous perfusion de glucose', 'Toutes les 6–12 h', 'K < 3,5 mmol/L : supplémentation'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Conscience et examen neurologique revenus à l’état habituel.', 'Glycémie stable au-dessus de 4,0 mmol/L après un repas.', 'Cause identifiée et compatible avec un retour sûr ; durée d’action du médicament en cause dépassée.',
       'Traitement adapté, matériel d’autosurveillance et glucagon prescrits.', 'Patient et entourage capables de reconnaître et de traiter un épisode ; personne présente à domicile.',
       'Consignes de conduite remises ; rendez-vous de diabétologie fixé.']) + P('', 32, 33, 38, 39, 43, 44), 'fenetre') +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Un épisode iatrogène corrigé guérit sans séquelle dans la grande majorité des cas, mais une neuroglucopénie prolongée peut laisser des lésions cérébrales. Après exérèse radicale d’un insulinome bénin, la guérison est habituelle et l’ENETS prévoit un seul contrôle à 3–6 mois. La recherche 2026 porte sur les systèmes automatisés capteur–pompe, qui réduisent le temps passé en hypoglycémie, et sur les traitements des hypoglycémies post-bariatriques.', 40, 46, 48), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire choisit un traitement peu hypoglycémiant et des objectifs adaptés à l’âge. '
   'La prévention secondaire repose sur l’éducation, le glucagon pour l’entourage, le capteur de glucose et la révision du traitement après chaque épisode sévère. '
   'La prévention tertiaire protège la conduite, le travail et l’autonomie selon la directive suisse.', 33, 45, 46) +
 F('Les trois niveaux en pratique',
   TAB(['Niveau', 'Mesure', 'Contrôle'], [
    ['Primaire', 'Préférer metformine, inhibiteur du SGLT2 ou agoniste du GLP-1 aux sulfonylurées, surtout chez la personne âgée', 'HbA1c et épisodes à chaque consultation'],
    ['Secondaire', 'Capteur avec alarmes (SSED 2025), glucagon prescrit et enseigné, sucre toujours sur soi', 'Temps sous 3,9 mmol/L < 4 %'],
    ['Secondaire', 'Adaptation de l’insuline à l’effort, à l’alcool et aux repas', 'Journal ou données du capteur'],
    ['Tertiaire', 'Évaluation de l’aptitude à conduire et du poste de travail', 'Selon la directive SSED/SSML 2025'],
   ]) + P('L’Office fédéral de la santé publique soutient la prévention du diabète dans la stratégie nationale des maladies non transmissibles (MNT).', 59))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin mesure la glycémie devant toute sueur inexpliquée, tout malaise ou toute altération de conscience. '
   'Il corrige sous 4,0 mmol/L par 15 g de sucre si le patient avale, sinon par du glucose IV ou du glucagon. '
   'Une sulfonylurée ou une insuline lente impose une surveillance prolongée, parce que la récidive est fréquente. '
   'Chez la personne non diabétique, rien ne s’explore sans triade de Whipple ni prélèvement pendant l’épisode. '
   'Avant la sortie, le traitement, l’éducation, le glucagon et la conduite automobile sont revus.', 32, 33, 40, 45)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Donner à boire à un patient confus', 'La voie orale exige une déglutition sûre ; sinon glucose IV ou glucagon.'],
  ['Attendre un chiffre très bas pour traiter', 'Le diabétique traité se corrige dès 4,0 mmol/L.'],
  ['Explorer un malaise postprandial sans glycémie contemporaine', 'La triade de Whipple est exigée.'],
  ['Doser insuline et peptide C après la perfusion de glucose', 'Les dosages n’ont de valeur que pendant l’hypoglycémie.'],
  ['Renvoyer à domicile après le réveil un patient sous sulfonylurée', 'La surveillance dure au moins 24–48 h.'],
  ['Répéter le glucagon chez un alcoolique à jeun', 'Le glycogène est épuisé : il faut du glucose (et de la thiamine).'],
  ['Conclure à un insulinome sur une image pancréatique', 'La preuve biologique précède l’imagerie.'],
  ['Insuline élevée, peptide C bas : penser insulinome', 'C’est une insuline exogène.'],
  ['Le Baqsimi® est réservé aux enfants de 4 ans ou plus', 'L’AIPS de mars 2026 l’autorise dès 1 an.'],
  ['Traiter une convulsion hypoglycémique par une benzodiazépine d’abord', 'Le glucose est le traitement.'],
 ]) + P('Ces pièges reprennent les erreurs fréquentes aux examens et dans les protocoles hospitaliers.', 32, 34, 36, 40)))
SOURCES = sorted(SOURCES_ORIG.items()) + [
 (54, 'Office fédéral de la statistique (OFS). Enquête suisse sur la santé 2022 : diabète déclaré. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (55, 'International Diabetes Federation. IDF Diabetes Atlas, 10e édition, 2021 : région Europe. Référence ajoutée lors de l’audit.'),
 (56, 'American Diabetes Association. Standards of Care in Diabetes 2026, section 6 (Glycemic goals and hypoglycemia) ; International Hypoglycaemia Study Group, Diabetes Care 2017;40:155–157. Référence ajoutée lors de l’audit.'),
 (57, 'Cryer PE et al. Evaluation and management of adult hypoglycemic disorders: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab. 2009;94:709–728. Référence ajoutée lors de l’audit.'),
 (58, 'Tox Info Suisse. Centre suisse d’information toxicologique, numéro d’urgence 145. Référence ajoutée lors de l’audit.'),
 (59, 'Office fédéral de la santé publique (OFSP). Stratégie nationale Prévention des maladies non transmissibles (MNT) 2017–2028. Référence ajoutée lors de l’audit.'),
 (60, 'Bornstein SR et al. Diagnosis and treatment of primary adrenal insufficiency: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab 2016;101:364–389. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (61, 'Service FJ et al. Functioning insulinoma: incidence, recurrence, and long-term survival of patients. Mayo Clin Proc 1991;66:711–719. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (62, 'Garmendia Madariaga A et al. The incidence and prevalence of thyroid dysfunction in Europe: a meta-analysis. J Clin Endocrinol Metab 2014;99:923–931. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (63, 'Lenders JWM et al. Pheochromocytoma and paraganglioma: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab 2014;99:1915–1942. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (64, 'Fiest KM et al. Prevalence and incidence of epilepsy: a systematic review and meta-analysis of international studies. Neurology 2017;88:296–303. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
]
CTX = {'_prefixe': 'Dans l’hypoglycémie',
 'gly': 'La glycémie capillaire décide de la correction (< 4,0 mmol/L chez le diabétique) ; la glycémie veineuse sur tube fluoré, prélevée pendant l’épisode, sert à l’enquête étiologique.',
 'peptc': 'Le peptide C se dose pendant l’hypoglycémie : élevé, il signe une insuline endogène (insulinome, sulfonylurée) ; bas avec insuline élevée, une insuline exogène.',
 'cort': 'Un cortisol bas pendant l’hypoglycémie oriente vers une insuffisance surrénalienne, qui se confirme par un test au Synacthen.',
 'hba1c': 'L’HbA1c mesure l’équilibre moyen ; une HbA1c très basse chez un diabétique traité signale un excès de traitement.',
 'creat': 'Le DFGe abaissé prolonge l’effet de l’insuline et des sulfonylurées.',
 'hep': 'Une insuffisance hépatique réduit la néoglucogenèse et l’efficacité du glucagon.',
 'tox': 'Le dépistage des sulfonylurées et des glinides se demande devant un hyperinsulinisme endogène.',
 'iono': 'La kaliémie se surveille sous perfusion de glucose, qui fait entrer le potassium dans les cellules.',
 'nfs': 'Une leucocytose majeure peut abaisser faussement la glycémie in vitro.',
 'crp': 'Une CRP élevée oriente vers un sepsis, cause d’hypoglycémie chez le patient fragile.',
 'tdm': 'La TDM pancréatique multiphasique localise un insulinome après la preuve biologique ; la TDM cérébrale s’impose si un déficit persiste après correction.',
 'irm': 'L’IRM pancréatique localise un insulinome ; l’IRM cérébrale explore un déficit persistant.',
 'echoabdo': 'L’échographie externe ne suffit pas à exclure un petit insulinome.',
 'endo': 'L’échoendoscopie localise les petits insulinomes, surtout de la tête du pancréas.',
 'tep': 'La TEP aux analogues du GLP-1 se discute en centre expert lorsque la localisation conventionnelle échoue.',
 'ecg': 'L’ECG cherche une arythmie ou une ischémie déclenchée par l’hypoglycémie, notamment chez le patient coronarien.',
 'lact': 'Le lactate et la gazométrie font partie du prélèvement critique pédiatrique.',
 'gds': 'La gazométrie cherche une acidose métabolique dans le bilan pédiatrique ou toxique.',
 'tsh': 'La TSH ne fait pas partie du bilan de première intention de l’hypoglycémie.',
 'hcg': 'Le test de grossesse précède l’imagerie irradiante chez la femme en âge de procréer.',
 'ecbu': 'L’ECBU cherche une infection urinaire déclenchante chez la personne âgée diabétique.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
