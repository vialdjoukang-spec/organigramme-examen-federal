# -*- coding: utf-8 -*-
"""Générateur du cours corrigé DX.6 (partie 3 : point 11)."""
from gen_dx6_part2 import *

CBZ = T('carbimazole (Néo-Mercazole®)', 'Antithyroïdien de synthèse de la classe des thionamides (autres principes actifs : thiamazole, propylthiouracile) ; promédicament transformé en thiamazole, qui inhibe la thyroperoxydase. Le détail figure dans la fiche du point 11.B.')
PTU = T('propylthiouracile (Propycil®)', 'Thionamide qui inhibe la thyroperoxydase et, en plus, la conversion périphérique de T4 en T3 ; son hépatotoxicité le réserve au premier trimestre de grossesse, à la crise et à l’intolérance non grave au carbimazole.')
PROP = T('propranolol (Inderal®)', 'Bêtabloquant non sélectif ; il contrôle tachycardie, tremblement et anxiété et, à forte dose, freine la conversion de T4 en T3.')

A = F('<em>11.A Buts : lever l’urgence vitale, puis rétablir l’euthyroïdie</em>',
  P('Dans une forme compliquée, le premier but est de lever la menace vitale en quelques heures. '
    'Le traitement vise une T4 libre et une T3 libre dans les références du laboratoire, puis une TSH normalisée, qui reste souvent freinée plusieurs mois. '
    'Il vise aussi une fréquence cardiaque de repos inférieure à 90/min, seuil qui fait introduire le bêtabloquant selon l’ATA, et une récupération du poids. '
    'Il prévient enfin les complications cardiaques, osseuses, orbitaires et obstétricales, ainsi que la rechute.', 22, 1))

URG = F('Urgence — crise aiguë thyrotoxique : conduite heure par heure',
  TAB(['Moment', 'Action', 'Pourquoi'], [
   ['H0 (premières minutes)', 'Appel du 144 ou des soins intensifs ; voies veineuses, scope, oxygène si SpO₂ basse ; prélèvements (TSH, T4L, T3L, NFS, ionogramme, glycémie, créatinine, bilan hépatique, troponine, lactate, hémocultures, hCG)', 'La défaillance d’organe tue avant l’excès hormonal ; le bilan cherche aussi le déclencheur.'],
   ['H0', 'Refroidissement externe, paracétamol, remplissage prudent avec apport glucosé ; pas d’aspirine', 'L’aspirine déplace la T4 de ses protéines porteuses et augmente la fraction libre.'],
   ['H0', 'ATS : propylthiouracile 500–1000 mg en charge puis 250 mg toutes les 4 h, ou thiamazole 60–80 mg/j (ATA 2016, hors AIPS), per os ou par sonde', 'L’ATS bloque la synthèse ; le propylthiouracile freine aussi la conversion de T4 en T3.'],
   ['H0', 'Bêtabloquant : propranolol 60–80 mg toutes les 4 h per os, ou esmolol IV titré si la tolérance est incertaine (500 µg/kg/min pendant 1 min, puis 50 µg/kg/min, augmenté par paliers selon l’AIPS)', 'Le blocage bêta contrôle la fréquence ; l’esmolol, de demi-vie très courte, s’arrête vite en cas d’hypotension.'],
   ['H0', 'Hydrocortisone 300 mg IV puis 100 mg toutes les 8 h (ATA 2016, hors AIPS)', 'Le glucocorticoïde freine la conversion de T4 en T3 et couvre une insuffisance surrénalienne relative.'],
   ['H + 1 au moins', 'Iodure : solution saturée d’iodure de potassium, 5 gouttes (≈ 250 mg) toutes les 6 h (ATA 2016, hors AIPS)', 'L’iode bloque la libération des hormones ; donné avant l’ATS, il alimenterait la synthèse.'],
   ['H1–H24', 'Traitement du déclencheur (antibiotiques si sepsis), anticoagulation d’une fibrillation atriale selon le risque, surveillance de la glycémie et de la kaliémie', 'Le déclencheur entretient la crise.'],
   ['H24–H72', 'Absence d’amélioration : plasmaphérèse ou thyroïdectomie en urgence discutées', 'La thyroïdectomie supprime la source quand les médicaments échouent.'],
   ['J3 et suite', 'Décroissance de l’iodure et de l’hydrocortisone, relais par carbimazole, planification d’un traitement définitif', 'La crise récidive si la cause persiste.'],
  ]) +
  P('Le bêtabloquant peut précipiter un choc lorsque la fraction d’éjection est effondrée ; l’échocardiographie précoce guide alors son usage. Les doses de propylthiouracile, de thiamazole, d’hydrocortisone et d’iodure suivent l’ATA 2016 et le consensus européen 2026, et non une information professionnelle suisse.', 2, 22, 6), cls='fenetre urgence')

COMPL = F('Autres formes compliquées : conduite immédiate',
  TAB(['Complication', 'Conduite d’urgence', 'Suite chronologique'], [
   ['Agranulocytose (neutrophiles < 0,5 G/L)', 'Arrêt définitif de l’ATS ; hospitalisation et antibiothérapie à large spectre si fièvre', 'Pas de passage à l’autre thionamide (réaction croisée) ; bêtabloquant, puis iode radioactif ou chirurgie après récupération'],
   ['Hépatite au propylthiouracile ou cholestase au carbimazole', 'Arrêt de l’ATS ; bilan hépatique et TP', 'Traitement définitif ; avis hépatologique si insuffisance hépatique'],
   ['Vascularite à ANCA sous propylthiouracile', 'Arrêt ; bilan rénal et pulmonaire', 'Avis spécialisé ; traitement définitif'],
   ['Fibrillation atriale', 'Contrôle de la fréquence par bêtabloquant ; anticoagulation selon CHA₂DS₂-VASc', 'Le rythme sinusal revient souvent avec l’euthyroïdie ; la cardioversion attend l’euthyroïdie'],
   ['Insuffisance cardiaque', 'Diurétique, bêtabloquant prudent ou esmolol titré', 'Traitement définitif rapide'],
   ['Orbitopathie menaçant la vision', 'Méthylprednisolone IV à forte dose et décompression orbitaire si échec en 1 à 2 semaines (EUGOGO 2021)', 'Suivi ophtalmologique rapproché'],
   ['Orbitopathie active modérée à sévère', 'Méthylprednisolone IV 4,5 g cumulés sur 12 semaines, associée au mycophénolate (EUGOGO 2021)', 'Chirurgie de réhabilitation après inactivation'],
   ['Paralysie périodique thyrotoxique', 'Potassium prudent, propranolol', 'Traitement de la thyrotoxicose ; risque d’hyperkaliémie de rebond'],
  ]), cls='fenetre urgence')

GEN = F('Formes non compliquées : mesures générales, puis ordre',
  P('Au début, le médecin explique la maladie, la différence entre frein de synthèse et traitement définitif, et les signes qui imposent d’arrêter l’ATS ; il remet une consigne écrite sur la fièvre et l’angine. '
    'Il conseille l’arrêt du tabac, car il aggrave l’orbitopathie et la rechute, il évite les surcharges iodées et il vérifie une contraception efficace pendant l’ATS et après l’iode radioactif. '
    'La prise en charge reste ambulatoire en l’absence de défaillance ; un arrêt de travail se justifie selon les symptômes, notamment pour un poste exposé à la chaleur ou de sécurité.', 1, 22, 25) +
  TAB(['Ordre', 'Mesure', 'Pourquoi'], [
   ['1', f'Bêtabloquant dès le diagnostic, par exemple {PROP} 10–40 mg 3 à 4 fois par jour, sauf contre-indication', 'Il soulage en quelques heures, quel que soit le mécanisme.'],
   ['2', f'Basedow : {ATS} en première intention en Europe, {CBZ} en schéma de titration pendant 12 à 18 mois', 'Une rémission survient chez environ la moitié des patients (ETA 2018).'],
   ['2', 'Thyroïdite subaiguë : AINS, ou prednisone 40 mg/j pendant 1–2 semaines puis décroissance sur 2–4 semaines (ATA 2016)', 'L’inflammation cause la fuite hormonale ; l’ATS est inutile.'],
   ['2', 'Thyroïdite silencieuse ou du post-partum : bêtabloquant seul', 'La phase thyrotoxique est transitoire.'],
   ['2', 'Adénome ou goitre toxique : ATS jusqu’à l’euthyroïdie, puis iode radioactif ou chirurgie', 'L’autonomie ne guérit pas sous ATS.'],
   ['2', 'Amiodarone : type 1 par ATS à forte dose (± perchlorate), type 2 par prednisone 0,5–0,7 mg/kg/j pendant environ 3 mois (ETA 2018)', 'Le mécanisme diffère ; l’amiodarone se poursuit souvent après décision cardiologique.'],
   ['3', 'Traitement définitif en cas de rechute, d’effet indésirable grave, de goitre compressif ou de nodule suspect', 'Il supprime la source et prévient les récidives.'],
  ]))

def DRUG(nom, rows):
    return F(nom, TAB(['Rubrique', 'Contenu'], rows))
MED = (
 DRUG('Fiche médicament — carbimazole (Néo-Mercazole®, AIPS 21037)', [
  ['Classe', 'Thionamide ; autres principes actifs : thiamazole, propylthiouracile.'],
  ['Pharmacodynamie', 'Le thiamazole inhibe la thyroperoxydase et bloque l’organification de l’iode et le couplage des iodotyrosines ; il n’agit pas sur les hormones déjà stockées.'],
  ['Pharmacocinétique', 'Le carbimazole est transformé en thiamazole ; le pic survient en 1–2 h, la demi-vie plasmatique est de 4–12 h et le séjour intrathyroïdien d’environ 20 h, ce qui permet une prise unique en entretien.'],
  ['Dose AIPS adulte', 'Le traitement initial est de 20–60 mg/j en 2 à 3 prises, puis l’entretien de 5–20 mg/j.'],
  ['Dose AIPS enfant', 'La dose initiale est de 0,7–0,8 mg/kg/j en 2 à 3 prises, au maximum 60 mg/j.'],
  ['Durée', 'Le traitement dure 12 à 18 mois dans le Basedow de l’adulte (ETA 2018) et au moins 3 ans chez l’enfant (ETA 2022).'],
  ['Effets indésirables à expliquer', 'Agranulocytose (≈ 0,2–0,5 %, surtout les 3 premiers mois), éruption et prurit, arthralgies, cholestase, perte du goût ; embryopathie en cas d’exposition entre 6 et 10 semaines de gestation (aplasia cutis, atrésie des choanes ou de l’œsophage, omphalocèle).'],
  ['Contre-indications', 'Antécédent d’agranulocytose ou d’hépatite sous thionamide, insuffisance hépatique Child-Pugh C (AIPS), premier trimestre de grossesse sauf absence d’alternative.'],
  ['Interactions', 'L’effet des antivitamines K, de la digoxine et des bêtabloquants change avec le retour à l’euthyroïdie ; les doses sont réévaluées.'],
  ['Surveillance', 'NFS et bilan hépatique avant le traitement ; NFS immédiate en cas de fièvre ou d’angine ; NFS régulière les premières semaines selon l’AIPS.'],
 ]) +
 DRUG('Fiche médicament — propylthiouracile (Propycil® 50, AIPS 56300)', [
  ['Classe', 'Thionamide.'],
  ['Pharmacodynamie', 'Il inhibe la thyroperoxydase et, en plus, la désiodase de type 1 qui convertit la T4 en T3.'],
  ['Pharmacocinétique', 'La demi-vie est de 1–2 h, d’où 3 prises par jour ; l’élimination est surtout rénale, sans adaptation rénale selon l’AIPS, y compris en dialyse.'],
  ['Dose AIPS', 'L’adulte et l’enfant dès 10 ans reçoivent 75–100 mg trois fois par jour ; la dose de crise (ATA 2016) est hors AIPS.'],
  ['Indications préférentielles', 'Premier trimestre de grossesse, crise aiguë thyrotoxique, intolérance non grave au carbimazole.'],
  ['Effets indésirables à expliquer', 'Hépatite cytolytique parfois fulminante, vascularite à ANCA, agranulocytose.'],
  ['Contre-indications', 'Antécédent d’hépatite ou d’agranulocytose sous thionamide ; usage de première intention chez l’enfant déconseillé.'],
 ]) +
 DRUG('Fiche médicament — propranolol (Inderal®, AIPS 31706) et esmolol (Esmolol OrPha®, AIPS 57413)', [
  ['Classe', 'Bêtabloquants ; le propranolol est non sélectif, l’esmolol bêta-1 sélectif ; autres principes actifs : bisoprolol, métoprolol, aténolol.'],
  ['Pharmacodynamie', 'Le blocage bêta réduit tachycardie, tremblement et anxiété ; le propranolol à forte dose freine aussi la conversion de T4 en T3.'],
  ['Pharmacocinétique', 'Le propranolol atteint son pic en 1–2 h, subit un fort premier passage hépatique et a une demi-vie de 3–6 h ; l’esmolol a une demi-vie d’environ 9 min (estérases érythrocytaires).'],
  ['Doses', 'Propranolol 10–40 mg 3 à 4 fois par jour (ATA 2016) ; esmolol 500 µg/kg/min pendant 1 min, puis 50 µg/kg/min pendant 4 min, puis, si l’effet manque à 5 min, nouvelle charge et 100 µg/kg/min (AIPS).'],
  ['Contre-indications', 'Asthme ou bronchospasme, bradycardie, bloc auriculo-ventriculaire de haut degré, choc cardiogénique, insuffisance cardiaque décompensée.'],
  ['Effets indésirables à expliquer', 'Fatigue, bradycardie, hypotension, masquage d’une hypoglycémie.'],
  ['Alternative', 'Le diltiazem ou le vérapamil contrôle la fréquence si le bêtabloquant est contre-indiqué.'],
 ]) +
 DRUG('Fiche médicament — iodure, glucocorticoïdes, sélénium, lévothyroxine', [
  ['Iodure de potassium (solution saturée ou Lugol)', 'L’iode à forte dose bloque l’organification (effet Wolff-Chaikoff) et la libération des hormones ; il se donne au moins 1 h après l’ATS, pendant la crise ou environ 10 jours avant une thyroïdectomie pour Basedow (ATA 2016).'],
  ['Hydrocortisone', 'Elle freine la conversion de T4 en T3 et couvre une insuffisance surrénalienne relative dans la crise (300 mg IV puis 100 mg toutes les 8 h, ATA 2016).'],
  ['Prednisone', 'Elle traite la thyroïdite subaiguë, l’amiodarone de type 2 et protège l’orbite après iode radioactif (0,3–0,5 mg/kg/j débuté 1 à 3 jours après, décroissance sur environ 3 mois, EUGOGO 2021).'],
  ['Sélénium', 'Le sélénite de sodium 100 µg deux fois par jour pendant 6 mois améliore l’orbitopathie légère (Marcocci 2011, EUGOGO 2021).'],
  ['Lévothyroxine', 'Elle substitue l’hypothyroïdie après iode radioactif ou thyroïdectomie, à environ 1,6 µg/kg/j après une thyroïdectomie totale.'],
 ]) +
 P('Les posologies des fiches proviennent des informations professionnelles suisses (AIPS) ; les doses de crise et de bêtabloquant oral suivent l’ATA 2016, et le sélénium suit l’essai de Marcocci 2011.', 3, 4, 5, 6, 22, 30))

DEF = F('Traitements définitifs : iode radioactif et thyroïdectomie',
  TAB(['Rubrique', 'Iode radioactif (iode 131)', 'Thyroïdectomie totale'], [
   ['Indications', 'Rechute de Basedow, adénome ou goitre toxique, intolérance aux ATS', 'Goitre volumineux ou compressif, nodule suspect, orbitopathie modérée à sévère, désir de grossesse proche, échec des autres moyens'],
   ['Contre-indications', 'Grossesse, allaitement, projet de grossesse dans les 6 mois, orbitopathie active modérée à sévère ou menaçant la vision', 'Risque opératoire majeur'],
   ['Préparation', 'Test de grossesse dans les 72 h ; arrêt de l’ATS quelques jours avant ; bêtabloquant poursuivi', 'Euthyroïdie sous ATS ; iodure environ 10 jours avant (Basedow) ; vitamine D et calcium vérifiés'],
   ['Protection orbitaire', 'Prednisone 0,3–0,5 mg/kg/j débutée 1 à 3 jours après, décroissance sur environ 3 mois en cas d’orbitopathie légère active ou de tabagisme', 'Aucune aggravation propre de l’orbitopathie'],
   ['Suites', 'Hypothyroïdie attendue en 2 à 6 mois ; T4 libre et TSH toutes les 4 à 6 semaines pendant 6 mois ; contraception d’au moins 6 mois', 'Calcémie et PTH à J1 (hypoparathyroïdie) ; voix (nerf récurrent) ; hématome compressif à ouvrir en urgence ; lévothyroxine et TSH à 6–8 semaines'],
  ]) + P('Le choix se fait avec le patient selon la cause, l’orbite, le goitre, la grossesse et la préférence ; les deux options aboutissent en général à une hypothyroïdie substituée.', 1, 22, 25))

SOC = F('Volets social et professionnel',
  P('La LAMal prend en charge le diagnostic et le traitement de la maladie selon son article 25, alinéa 1, à condition que les prestations soient efficaces, appropriées et économiques selon l’article 32. '
    'La LAA ne s’applique que si une origine professionnelle est démontrée selon son article 9, ce qui reste exceptionnel ; la LAI intervient par des mesures de réadaptation selon l’article 8 si la capacité de gain est durablement atteinte. '
    'L’incapacité de travail se décrit par tâche et par durée ; l’aptitude à la conduite est réévaluée en cas de syncope, d’arythmie symptomatique ou de diplopie.', 19, 20, 21))

SPE = F('Situations spéciales',
  TAB(['Situation', 'Que prescrire', 'Risques et alternative'], [
   ['Grossesse', 'Propylthiouracile au premier trimestre, puis carbimazole discuté au deuxième ; dose minimale qui maintient la T4 libre à la limite supérieure ; contrôle toutes les 4 semaines', 'Embryopathie au carbimazole entre 6 et 10 semaines ; TRAb au diagnostic puis à 18–22 semaines ; surveillance fœtale si TRAb > 3 × la limite supérieure ; iode radioactif contre-indiqué ; chirurgie au deuxième trimestre si nécessaire (ATA 2017)'],
   ['Thyrotoxicose gestationnelle', 'Bêtabloquant court et réhydratation', 'L’hCG stimule le récepteur ; l’ATS n’est pas indiqué'],
   ['Allaitement', 'Carbimazole jusqu’à 20 mg/j (AIPS) ou propylthiouracile', 'Prise après la tétée ; iode radioactif contre-indiqué'],
   ['Sujet âgé', 'Bêtabloquant à faible dose ; iode radioactif souvent préféré pour l’autonomie ; traitement de l’hyperthyroïdie infraclinique de grade 2', 'Forme apathique, fibrillation atriale, ostéoporose, chute'],
   ['Enfant', 'Carbimazole 0,7–0,8 mg/kg/j (AIPS), au moins 3 ans (ETA 2022)', 'Propylthiouracile évité (hépatotoxicité) ; iode radioactif évité chez le jeune enfant'],
   ['Insuffisance hépatique', 'Carbimazole contre-indiqué en Child-Pugh C (AIPS) ; propylthiouracile évité ; traitement définitif privilégié', 'Le bilan hépatique de base distingue l’atteinte thyrotoxique de la toxicité médicamenteuse'],
   ['Insuffisance rénale', 'Propylthiouracile sans adaptation selon l’AIPS ; esmolol prudent en perfusion prolongée si DFGe < 30 mL/min/1,73 m² (accumulation du métabolite)', 'Produit de contraste iodé à éviter'],
  ]) + P('Ces choix suivent l’ETA 2018, l’ATA 2016, l’ATA 2017 pour la grossesse et l’ETA 2022 pour l’enfant.', 1, 11, 22, 26, 3, 5))

C = F('<em>11.C Surveillance et critères de sortie</em>',
  TAB(['Quoi', 'Quand', 'Pourquoi', 'Seuil d’action'], [
   ['T4 libre et T3 libre', '3–4 semaines après le début, puis toutes les 4–8 semaines, puis tous les 2–3 mois', 'Elles guident la dose, car la TSH reste freinée', 'Hypothyroïdie : réduire l’ATS'],
   ['NFS', 'Avant le traitement, puis immédiatement si fièvre ou angine', 'L’agranulocytose est brutale ; le dépistage systématique ne la prévient pas toujours', 'Neutrophiles < 0,5 G/L : arrêt définitif ; 0,5–1,5 G/L : avis spécialisé'],
   ['Bilan hépatique', 'Avant le traitement, puis si ictère, prurit ou douleurs', 'Le propylthiouracile est hépatotoxique', 'Ictère ou cytolyse franche : arrêt'],
   ['TRAb', 'À 12–18 mois, avant l’arrêt', 'Ils prédisent la rechute', 'TRAb élevés : poursuivre ou traitement définitif'],
   ['TSH après arrêt de l’ATS', 'Tous les 1–3 mois pendant la première année', 'La rechute survient surtout la première année', 'TSH basse : réévaluer'],
   ['Orbite (CAS, vision)', 'À chaque consultation', 'L’orbitopathie évolue indépendamment des hormones', 'CAS ≥ 3/7 ou baisse visuelle : avis ophtalmologique'],
   ['INR sous antivitamine K', 'Plus souvent pendant le retour à l’euthyroïdie', 'La sensibilité aux AVK diminue quand la thyrotoxicose se corrige', 'INR hors cible : adapter la dose'],
  ]) +
  P('Après une crise ou une hospitalisation, le patient peut rentrer à domicile lorsque chacun des critères suivants est rempli.', 2) +
  '<ol><li>La température est normale sans antipyrétique depuis au moins 24 h.</li>'
  '<li>La fréquence cardiaque et la pression artérielle sont stables sous traitement oral.</li>'
  '<li>L’état neurologique est revenu à la normale.</li>'
  '<li>Le patient mange, boit et tolère ses médicaments par voie orale.</li>'
  '<li>Le facteur déclenchant est contrôlé.</li>'
  '<li>La NFS et le bilan hépatique sous ATS sont acceptables.</li>'
  '<li>Le patient connaît les signes qui imposent d’arrêter l’ATS et de consulter.</li>'
  '<li>Un contrôle clinique et biologique est fixé dans les 1 à 2 semaines et le traitement définitif est planifié.</li></ol>\n')

Dp = F('<em>11.D Pronostic, guérison et recherche 2026</em>',
  P('Après 12 à 18 mois d’ATS, environ la moitié des patients atteints de Basedow restent en rémission ; des TRAb élevés à l’arrêt, un goitre volumineux, le tabac, le jeune âge et une T4 libre initiale élevée prédisent la rechute (score GREAT). '
    'Après iode radioactif ou thyroïdectomie, la guérison correspond à une euthyroïdie sous lévothyroxine ; l’ETA admet aussi un ATS à faible dose au long cours. '
    'La thyroïdite guérit en général spontanément, mais une hypothyroïdie définitive peut suivre ; la recherche 2026 évalue les anticorps anti-récepteur de l’IGF-1 pour l’orbitopathie, les inhibiteurs du FcRn et les antagonistes du récepteur de la TSH.', 1, 25, 2))

PTS.append(POINT(11, 'Prise en charge',
 P('Le médecin traite d’abord une forme compliquée, crise, agranulocytose, insuffisance cardiaque ou orbitopathie menaçante, puis il soulage les symptômes par un bêtabloquant. '
   'Il traite ensuite la cause selon le mécanisme : ATS pour le Basedow, anti-inflammatoire pour la thyroïdite, traitement définitif pour l’autonomie. '
   'Il surveille enfin l’efficacité, la toxicité et l’orbite, puis il discute un traitement définitif en cas de rechute.', 1, 2, 22) +
 A + F('<em>11.B Moyens</em>', URG + COMPL + GEN + MED + DEF + SOC + SPE) + C + Dp))
