# -*- coding: utf-8 -*-
"""Générateur du cours corrigé DX.6 (partie 1 : aides + points 1 à 6)."""
def S(*n): return ' <span class="s">' + ' '.join(f'<a href="#source-S{i}">[S{i}]</a>' for i in n) + '</span>'
def P(txt, *src): return f'<div class="p">{txt}{S(*src) if src else ""}</div>\n'
def T(mot, definition):  # fenêtre de terme, en ligne
    return f'<details class="terme"><summary>{mot}</summary><div class="exw">{definition}</div></details>'
def TAB(cols, rows):
    h = ''.join(f'<th>{c}</th>' for c in cols)
    b = '\n'.join('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>' for r in rows)
    return f"<div class=\"t\" style='overflow-x:auto;'><table><thead><tr>{h}</tr></thead><tbody>\n{b}\n</tbody></table></div>\n"
def F(summary, body, cls='fenetre'):
    return f'<details class="{cls}"><summary>{summary}</summary>\n{body}</details>\n'
def PR(val, *src):
    assert src, 'PR sans source'
    return f'<sup class="proba">{val}</sup>' + S(*src)
def POINT(n, titre, body):
    return f'<section class="point" id="dx6-p{n}"><h3><strong>{n}. {titre}</strong></h3>\n{body}</section>\n'

BASEDOW = T('maladie de Basedow', 'La maladie de Basedow (Graves’ disease) est une maladie auto-immune où des anticorps stimulent le récepteur de la TSH ; elle associe une thyrotoxicose, souvent un goitre diffus et parfois une orbitopathie ou une dermopathie.')
ATS = T('antithyroïdien de synthèse (ATS)', 'Les antithyroïdiens de synthèse sont les thionamides : carbimazole (Néo-Mercazole®), son métabolite actif le thiamazole, et le propylthiouracile (Propycil®). Ils inhibent la thyroperoxydase et freinent donc la synthèse des hormones, sans agir sur une fuite d’hormones déjà formées.')
CRISE = T('crise aiguë thyrotoxique', 'La crise aiguë thyrotoxique (thyroid storm) est une thyrotoxicose avec défaillance d’organe : fièvre, atteinte neurologique, insuffisance cardiaque ou atteinte digestive et hépatique. Elle se diagnostique cliniquement, car les taux hormonaux ne la distinguent pas d’une thyrotoxicose sévère simple.')

PTS = []
# ---------------- POINT 1
PTS.append(POINT(1, 'Définition et sémantique',
 P('L’hyperthyroïdie désigne une synthèse et une sécrétion excessives d’hormones par la thyroïde, alors que la thyrotoxicose désigne les effets tissulaires d’un excès d’hormones thyroïdiennes, quelle qu’en soit la source. '
   'Toute hyperthyroïdie entraîne donc une thyrotoxicose, mais une thyroïdite destructrice ou une prise d’hormones provoque une thyrotoxicose sans hyperthyroïdie. '
   f'L’hyperthyroïdie est manifeste lorsque la TSH est basse avec une T4 libre ou une T3 libre élevée, et infraclinique lorsque la TSH est basse avec des hormones libres normales. '
   f'La {BASEDOW} en constitue la cause principale, devant l’autonomie nodulaire, et la thyrotoxicose explique une hypersudation généralisée par excès de thermogenèse.', 22, 1, 23) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Thyrotoxicose', 'L’excès d’hormones thyroïdiennes agit sur les tissus, quelle que soit sa source.', 'Hyperthyroïdie, qui suppose une glande hyperproductrice'],
    ['Hyperthyroïdie', 'La glande synthétise et sécrète trop d’hormones ; la fixation scintigraphique est normale ou augmentée.', 'Thyroïdite, où la fixation est nulle'],
    ['Hyperthyroïdie infraclinique', 'La TSH est basse et les hormones libres sont normales ; l’ETA distingue le grade 1 (TSH 0,1–0,39 mUI/L) et le grade 2 (TSH < 0,1 mUI/L).', 'TSH basse d’une maladie aiguë, des corticoïdes ou du premier trimestre de grossesse'],
    ['Maladie de Basedow', 'Des anticorps stimulants anti-récepteur de la TSH (TRAb) activent toute la glande.', 'Thyroïdite auto-immune (Hashimoto), dont les anticorps anti-TPO ne stimulent pas'],
    ['Adénome toxique', 'Un nodule unique produit des hormones de façon autonome et éteint le reste de la glande.', 'Nodule froid, qui doit faire discuter une cytoponction'],
    ['Goitre multinodulaire toxique (maladie de Plummer)', 'Plusieurs nodules autonomes coexistent, souvent chez la personne âgée.', 'Goitre multinodulaire euthyroïdien'],
    ['Thyroïdite destructrice', 'L’inflammation détruit des follicules qui libèrent leur stock ; la phase thyrotoxique dure quelques semaines puis une hypothyroïdie peut suivre.', 'Basedow, car un ATS y est inutile'],
    ['Thyrotoxicose factice', 'Le patient prend des hormones thyroïdiennes, parfois en secret ; la thyroglobuline est basse.', 'Thyroïdite silencieuse, où la thyroglobuline est élevée'],
    ['Crise aiguë thyrotoxique', 'Une thyrotoxicose s’accompagne d’une défaillance d’organe et met la vie en jeu.', 'Thyrotoxicose sévère sans défaillance'],
   ]) + P('Les recommandations utilisent « hyperthyroïdie » pour les causes à fixation conservée et « thyrotoxicose » pour l’ensemble ; le traitement dépend de cette distinction.', 22, 1))))

# ---------------- POINT 2
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, où le sel est iodé depuis 1922, l’hyperthyroïdie manifeste touche selon les études européennes de 0,2 à 1,3 % de la population, et la forme infraclinique davantage. '
   'La maladie de Basedow représente environ 70 à 80 % des cas en zone iodée, avec 20 à 30 nouveaux cas pour 100 000 habitants par an, une prédominance féminine nette et un pic entre 30 et 60 ans. '
   'L’autonomie nodulaire augmente après 60 ans et chez les personnes nées avant la correction de la carence iodée. '
   'Les enjeux tiennent aux complications cardiaques, osseuses et obstétricales, ainsi qu’à la crise aiguë thyrotoxique, rare mais grave.', 31, 1) +
 F('Chiffres utiles, facteurs de risque et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Prévalence de l’hyperthyroïdie manifeste (Europe, zones iodées)', '0,2 à 1,3 %', 'La valeur varie selon l’âge et l’apport iodé (Taylor 2018).'],
    ['Incidence de Basedow', '20 à 30 / 100 000 / an', 'Le pic se situe entre 30 et 60 ans (ETA 2018).'],
    ['Fibrillation atriale lors d’une hyperthyroïdie manifeste', 'environ 5 à 15 %', 'Le risque augmente avec l’âge (ATA 2016).'],
    ['Orbitopathie cliniquement visible au cours d’un Basedow', 'environ un quart à un tiers', 'Les formes modérées à sévères restent minoritaires (EUGOGO 2021).'],
    ['Rémission après 12 à 18 mois d’ATS', 'environ 50 à 55 %', 'Le taux ne prédit pas l’individu (ETA 2018).'],
    ['Agranulocytose sous ATS', 'environ 0,2 à 0,5 %', 'Elle survient surtout dans les 3 premiers mois (ATA 2016).'],
    ['Mortalité d’une crise admise en soins intensifs (cohorte française de 92 patients)', '17 % en réanimation, 22 % à 6 mois', 'La population est sélectionnée et ne décrit pas l’hyperthyroïdie ambulatoire.'],
   ]) +
   P('Les facteurs de risque de Basedow comprennent le sexe féminin, les antécédents familiaux d’auto-immunité thyroïdienne, le post-partum et le tabac, qui aggrave surtout l’orbitopathie. '
     'Une surcharge iodée (produit de contraste, amiodarone), le lithium, l’interféron alpha et les inhibiteurs de points de contrôle immunitaire déclenchent aussi des thyrotoxicoses. '
     'Sans traitement, le Basedow évolue par poussées, l’adénome toxique persiste et la thyroïdite guérit spontanément en quelques semaines à quelques mois.', 31, 1, 22, 2))))

# ---------------- POINT 3
PTS.append(POINT(3, 'Physiopathologie',
 P('Dans la maladie de Basedow, les TRAb stimulent le récepteur de la TSH et provoquent l’hypersécrétion et la croissance diffuse de la glande, tandis que la TSH s’effondre par rétrocontrôle. '
   'Dans l’autonomie nodulaire, une mutation activatrice du récepteur rend le nodule indépendant de la TSH, alors que la thyroïdite libère un stock préformé sans synthèse nouvelle. '
   'L’excès de T3 active ses récepteurs nucléaires, augmente la thermogenèse et la sensibilité aux catécholamines, ce qui explique sueurs, tachycardie, tremblement, amaigrissement et perte osseuse. '
   'L’orbitopathie résulte de l’activation des fibroblastes orbitaires par les TRAb et le récepteur de l’IGF-1, qui gonflent la graisse et les muscles oculomoteurs.', 1, 22, 25) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'La thyroïde, glande en papillon devant la trachée, est faite de follicules qui stockent la thyroglobuline ; l’hypophyse la commande par la TSH.'],
    ['Physiologie', 'Pourquoi un thermostat : la thyroïde capte l’iode, fabrique T4 et T3, et la T3 règle la vitesse du métabolisme ; quand T4 et T3 montent, l’hypophyse baisse la TSH (rétrocontrôle).'],
    ['Physiopathologie', 'Dans la thyrotoxicose, la glande produit trop (anticorps TRAb qui imitent la TSH, nodule autonome) ou libère son stock (thyroïdite) ; la TSH s’effondre parce que le thermostat est saturé.'],
    ['Clinique', 'Le métabolisme et la sensibilité à l’adrénaline s’emballent : chaleur et sueurs, cœur rapide, tremblement, perte de poids malgré l’appétit.'],
    ['Examens', 'La TSH basse avec T4 libre ou T3 élevée prouve la thyrotoxicose ; les TRAb, l’échographie ou la scintigraphie disent pourquoi la glande produit trop.'],
    ['Traitement', 'On freine l’effet sur le cœur (bêtabloquant), on bloque la fabrication (antithyroïdien de synthèse), puis on traite la cause (iode radioactif ou chirurgie si besoin).'],
   ])) +
 F('Tableau de corrélation : perturbation → exploration → traitement qui la corrige',
   TAB(['Perturbation', 'Exploration qui la montre', 'Traitement qui la corrige (mécanisme)'], [
    ['Les TRAb stimulent le récepteur de la TSH.', 'Les TRAb sont positifs ; l’échographie montre une glande hypervascularisée.', 'L’ATS freine la synthèse pendant que l’auto-immunité s’apaise ; l’iode radioactif ou la chirurgie suppriment la cible.'],
    ['La thyroperoxydase organifie l’iode et couple les iodotyrosines en excès.', 'La T4 libre et la T3 libre sont élevées ; la fixation est augmentée.', 'Le carbimazole et le propylthiouracile inhibent la thyroperoxydase.'],
    ['La désiodase convertit la T4 en T3, plus active.', 'La T3 libre est très élevée.', 'Le propylthiouracile, les glucocorticoïdes et le propranolol à forte dose freinent cette conversion.'],
    ['Les follicules détruits libèrent leur stock hormonal.', 'La fixation est nulle ; la thyroglobuline et la VS sont élevées.', 'Les anti-inflammatoires ou la prednisone calment l’inflammation ; l’ATS est inutile.'],
    ['Une surcharge iodée alimente une glande autonome (effet Jod-Basedow).', 'L’anamnèse révèle l’iode ; la fixation est basse malgré l’hyperproduction.', 'L’ATS à forte dose bloque l’organification ; le perchlorate peut limiter la captation de l’iode.'],
    ['La sensibilité adrénergique augmente.', 'La fréquence cardiaque et l’ECG objectivent la tachycardie.', 'Le bêtabloquant bloque les récepteurs bêta et soulage en quelques heures.'],
    ['La thermogenèse augmente.', 'La température et la sudation augmentent.', 'Le refroidissement et le paracétamol corrigent la fièvre ; l’aspirine est évitée car elle libère la T4 de ses protéines porteuses.'],
    ['Le remodelage osseux s’accélère.', 'L’ostéodensitométrie montre une perte minérale.', 'Le retour à l’euthyroïdie, le calcium et la vitamine D limitent la perte.'],
    ['Les fibroblastes orbitaires s’activent.', 'Le score d’activité clinique et l’IRM des orbites mesurent l’inflammation.', 'L’arrêt du tabac, le sélénium dans les formes légères et la méthylprednisolone intraveineuse dans les formes actives modérées à sévères réduisent l’inflammation.'],
   ])) +
 F('Pourquoi une crise aiguë thyrotoxique survient',
   P('La crise survient lorsqu’un facteur déclenchant s’ajoute à une thyrotoxicose non contrôlée : infection, chirurgie, accouchement, traumatisme, acidocétose, iode radioactif, surcharge iodée ou arrêt d’un ATS. '
     'La réponse aux catécholamines, l’inflammation et l’augmentation brutale de la fraction libre des hormones expliquent la défaillance, alors que les taux hormonaux chevauchent ceux d’une thyrotoxicose sévère simple. '
     'Le cœur décompense par tachycardie, fibrillation atriale et insuffisance à haut débit, puis le choc peut devenir cardiogénique.', 2, 22))))

# ---------------- POINT 4
PTS.append(POINT(4, 'Démarche diagnostique',
 P(f'Le médecin exclut d’abord une urgence vitale : {CRISE}, fibrillation atriale mal tolérée, orbitopathie menaçant la vision ou, chez un patient sous ATS, agranulocytose fébrile. '
   'Il confirme ensuite la thyrotoxicose par la TSH puis la T4 libre, et il vérifie qu’une interférence analytique ou une cause non thyroïdienne n’explique pas une TSH basse. '
   'Il établit enfin le mécanisme, hyperproduction ou fuite hormonale, par les TRAb, l’échographie thyroïdienne avec Doppler et, si nécessaire, la scintigraphie, car seul le mécanisme décide du traitement.', 1, 2, 10, 22) +
 F('Causes classées par mécanisme et par fixation scintigraphique',
   TAB(['Cause', 'Mécanisme', 'Fixation', 'Indice qui tranche', 'Traitement de la cause'], [
    ['Maladie de Basedow', 'Stimulation par les TRAb', 'Diffuse et augmentée', 'TRAb positifs, orbitopathie, souffle thyroïdien', 'ATS, iode radioactif ou thyroïdectomie'],
    ['Adénome toxique', 'Autonomie d’un nodule', 'Nodule chaud, reste éteint', 'Nodule unique palpable', 'Iode radioactif ou lobectomie'],
    ['Goitre multinodulaire toxique', 'Autonomie de plusieurs nodules', 'Hétérogène, foyers chauds', 'Personne âgée, goitre ancien', 'Iode radioactif ou thyroïdectomie'],
    ['Hyperthyroïdie induite par l’iode, dont l’amiodarone de type 1', 'Excès d’iode sur glande autonome ou Basedow latent', 'Basse à normale', 'Produit iodé récent ; Doppler conservé', 'ATS à forte dose, perchlorate selon avis'],
    ['Thyrotoxicose à l’amiodarone de type 2', 'Thyroïdite destructrice médicamenteuse', 'Nulle', 'Glande normale, Doppler sans flux', 'Prednisone'],
    ['Thyroïdite subaiguë de De Quervain', 'Inflammation post-virale', 'Nulle', 'Cou douloureux, VS et CRP élevées', 'AINS ou prednisone ; pas d’ATS'],
    ['Thyroïdite silencieuse ou du post-partum', 'Destruction auto-immune indolore', 'Nulle', 'Moins de 12 mois après un accouchement, anti-TPO positifs', 'Bêtabloquant seul ; surveiller l’hypothyroïdie'],
    ['Thyroïdite médicamenteuse', 'Lithium, interféron alpha, inhibiteurs de points de contrôle immunitaire', 'Nulle', 'Chronologie du traitement', 'Symptomatique ; avis oncologique'],
    ['Thyrotoxicose factice', 'Apport exogène de lévothyroxine ou de T3', 'Nulle', 'Thyroglobuline basse, absence de goitre', 'Arrêt ou adaptation de l’apport'],
    ['Thyrotoxicose gestationnelle ou môle', 'Stimulation du récepteur par l’hCG', 'Non réalisée (grossesse)', 'Premier trimestre, vomissements incoercibles, TRAb négatifs', 'Symptomatique ; évacuation d’une môle'],
    ['Adénome thyréotrope', 'Sécrétion hypophysaire de TSH', 'Diffuse', 'TSH normale ou élevée avec T4 libre élevée', 'Chirurgie hypophysaire'],
    ['Goitre ovarien (struma ovarii)', 'Tissu thyroïdien ovarien', 'Basse au cou, fixation pelvienne', 'Masse ovarienne', 'Chirurgie'],
   ]) + P('Ce tableau sépare les causes à fixation conservée, que l’ATS freine, des causes à fixation nulle, où l’ATS est inutile.', 22, 1, 24)) +
 F('Diagnostic différentiel dangereux : ce qui tranche et le piège (fréquence sourcée en exposant rouge)',
   TAB(['Hypothèse et fréquence', 'Signe ou examen qui tranche', 'Piège'], [
    ['Hyperthyroïdie avérée (diagnostic principal)' + PR('0,2–1,3 % (zones sans carence iodée)', 31), 'TSH basse, T4 libre ou T3 élevée', 'Oublier de chercher la cause'],
    ['Crise aiguë thyrotoxique' + PR('≈ 0,2 / 100 000 par an', 27), 'Défaillance d’organe et score de Burch-Wartofsky ≥ 45', 'Attendre un taux hormonal « critique » qui n’existe pas'],
    ['Sepsis' + PR('≈ 680 / 100 000 par an (monde)', 34), 'Foyer infectieux, hémocultures, lactate', 'Le sepsis déclenche souvent la crise : les deux coexistent'],
    ['Phéochromocytome' + PR('≈ 0,8 / 100 000 par an', 35), 'Accès paroxystiques, hypertension, métanéphrines plasmatiques', 'Une TSH normale avec accès adrénergiques fait doser les métanéphrines.'],
    ['Intoxication sympathomimétique ou sevrage alcoolique' + PR('fréquence en population non publiée', 7), 'Anamnèse, toxicologie, mydriase', 'Ne pas ignorer une thyrotoxicose associée'],
    ['Trouble anxieux ou attaque de panique' + PR('trouble panique ≈ 1,7 % sur la vie', 36), 'TSH normale', 'Conclure à l’anxiété sans doser la TSH'],
    ['Bouffées vasomotrices de la ménopause' + PR('jusqu’à 80 % des femmes en transition', 37), 'Âge, cycles, TSH normale', 'Attribuer une perte de poids à la ménopause'],
    ['TSH basse non thyroïdienne' + PR('TSH basse isolée, toutes causes : 0,7–1,8 % de la population', 23), 'T4 libre normale ou basse, contexte aigu, corticoïdes, dopamine, premier trimestre', 'Traiter un chiffre isolé'],
   ])) +
 F('Profils hormonaux et interférences analytiques',
   TAB(['Profil', 'Interprétation', 'Conduite'], [
    ['TSH basse, T4 libre élevée', 'La thyrotoxicose est manifeste.', 'Chercher la cause par TRAb et échographie.'],
    ['TSH basse, T4 libre normale, T3 libre élevée', 'La T3-toxicose est fréquente au début d’un Basedow ou d’une autonomie.', 'Traiter comme une hyperthyroïdie manifeste.'],
    ['TSH basse, T4 et T3 libres normales', 'L’hyperthyroïdie est infraclinique, de grade 1 ou 2.', 'Contrôler à 6–12 semaines, puis décider selon le grade et le terrain.'],
    ['TSH normale ou élevée, T4 libre élevée', 'La TSH n’est pas freinée.', 'Exclure une interférence, puis chercher un adénome thyréotrope ou une résistance aux hormones thyroïdiennes.'],
    ['Profil « Basedow » complet sans clinique chez un patient sous biotine (≥ 5 mg/j)', 'La biotine fausse les immunodosages à streptavidine : TSH faussement basse, T4 libre, T3 libre et TRAb faussement élevés.', 'Arrêter la biotine au moins 48 h (davantage après de fortes doses), puis redoser.'],
    ['Anticorps hétérophiles ou anti-T4', 'Les résultats ne concordent pas avec la clinique.', 'Redoser par une autre méthode.'],
   ]) + P('La stratégie suisse dose d’abord la TSH, puis la T4 libre seulement si la TSH est anormale ; elle ne s’applique pas telle quelle à la grossesse ni à une atteinte hypophysaire suspectée.', 10, 33))))

# ---------------- POINT 5
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise le début et la topographie des sueurs, l’intolérance à la chaleur, l’amaigrissement malgré un appétit conservé, les palpitations, le transit, le sommeil et la faiblesse musculaire. '
   'Le médecin recherche ensuite les causes et déclencheurs : antécédents thyroïdiens, accouchement récent, douleur cervicale, iode, amiodarone, lithium, immunothérapie, hormones thyroïdiennes et biotine. '
   'Il demande enfin, sans délai, s’il existe une confusion, une dyspnée, une douleur thoracique, une syncope, une baisse visuelle, une grossesse ou, sous ATS, une fièvre ou une angine.', 1, 2, 7, 22) +
 F('Questions ciblées et leur raison',
   TAB(['Question', 'Raison physiopathologique', 'Ce que la réponse change'], [
    ['Avez-vous perdu du poids sans manger moins ?', 'Le métabolisme de base augmente.', 'La perte de poids mesurée soutient la thyrotoxicose ; un tableau atypique garde un différentiel tumoral.'],
    ['Supportez-vous mal la chaleur et transpirez-vous partout ?', 'La thermogenèse augmente et la sudation dissipe la chaleur.', 'Une hypersudation généralisée oriente vers une cause générale plutôt qu’une hyperhidrose primaire focale.'],
    ['Vos palpitations sont-elles régulières ou irrégulières ?', 'La fibrillation atriale complique l’hyperthyroïdie.', 'Un rythme irrégulier impose un ECG et l’évaluation de l’anticoagulation.'],
    ['Avez-vous du mal à monter les escaliers ?', 'La myopathie thyrotoxique touche les muscles proximaux.', 'La faiblesse oriente vers une forme sévère ou ancienne.'],
    ['Vos yeux piquent-ils, voyez-vous double, la vision baisse-t-elle ?', 'L’orbitopathie peut comprimer le nerf optique.', 'Une baisse visuelle ou une diplopie impose un avis ophtalmologique rapide.'],
    ['Avez-vous mal au cou ou avez-vous eu une infection virale récente ?', 'La thyroïdite subaiguë suit souvent une virose.', 'Une douleur cervicale exclut l’ATS et oriente vers les anti-inflammatoires.'],
    ['Avez-vous accouché dans l’année ?', 'La thyroïdite du post-partum survient dans les 12 mois.', 'Le mécanisme destructeur est probable si les TRAb sont négatifs.'],
    ['Avez-vous reçu un produit de contraste iodé, de l’amiodarone, du lithium ou une immunothérapie ?', 'Ces produits induisent une hyperproduction ou une thyroïdite.', 'Le type de thyrotoxicose et le traitement changent.'],
    ['Prenez-vous des hormones thyroïdiennes, des produits amaigrissants ou de la biotine ?', 'Un apport exogène ou une interférence peuvent imiter la maladie.', 'La thyroglobuline ou un redosage après arrêt de la biotine tranche.'],
    ['Une grossesse est-elle possible ou souhaitée ?', 'Les médicaments et l’iode radioactif ont des risques fœtaux.', 'Un test de grossesse précède tout traitement ; le choix de l’ATS change.'],
    ['Fumez-vous ?', 'Le tabac aggrave l’orbitopathie et favorise la rechute.', 'Le sevrage devient une priorité thérapeutique.'],
    ['Sous ATS : avez-vous de la fièvre, une angine ou des aphtes ?', 'Une agranulocytose peut survenir brutalement.', 'Le patient arrête l’ATS et fait une formule sanguine le jour même.'],
    ['Sous ATS : vos urines sont-elles foncées, votre peau jaune ?', 'Le propylthiouracile peut causer une hépatite grave et le carbimazole une cholestase.', 'L’ATS est arrêté et le bilan hépatique est fait en urgence.'],
   ])) +
 F('Drapeaux rouges et conduite immédiate',
   TAB(['Drapeau rouge', 'Pourquoi', 'Conduite immédiate'], [
    ['Confusion, agitation ou somnolence avec fièvre', 'Une crise aiguë thyrotoxique est probable.', 'Appel du 144 ou transfert en soins intensifs ; score de Burch-Wartofsky.'],
    ['Dyspnée, orthopnée, œdèmes', 'L’insuffisance cardiaque à haut débit ou une cardiomyopathie décompense.', 'Urgences ; ECG, échocardiographie, prudence avec le bêtabloquant.'],
    ['Palpitations irrégulières, syncope, douleur thoracique', 'Une arythmie ou une ischémie de demande est possible.', 'ECG immédiat et surveillance du rythme.'],
    ['Fièvre ou angine sous ATS', 'Une agranulocytose est possible.', 'Arrêt de l’ATS et formule sanguine le jour même ; hospitalisation si neutrophiles < 0,5 G/L avec fièvre.'],
    ['Ictère ou douleurs abdominales sous ATS', 'Une hépatotoxicité est possible.', 'Arrêt de l’ATS et bilan hépatique en urgence.'],
    ['Baisse de l’acuité, désaturation des couleurs, diplopie récente', 'Une neuropathie optique compressive menace la vision.', 'Avis ophtalmologique sans délai.'],
    ['Paralysie brutale des membres avec hypokaliémie', 'La paralysie périodique thyrotoxique transfère le potassium dans les cellules.', 'Surveillance du rythme, potassium prudent (risque de rebond), propranolol.'],
    ['Grossesse en cours', 'Le traitement et la surveillance fœtale changent.', 'Coordination endocrinologique et obstétricale rapide.'],
   ]))))

# ---------------- POINT 6
PTS.append(POINT(6, 'Examen physique ciblé',
 P('Le médecin vérifie d’abord la conscience, la respiration, la circulation et la température. Il examine ensuite la peau, les mains, le cou, les yeux, le cœur et les muscles, en décrivant le normal avant l’anomalie. '
   'Un examen pauvre n’exclut pas la thyrotoxicose, notamment chez la personne âgée, où la forme apathique se limite parfois à une fibrillation atriale et un amaigrissement. '
   'Le souffle thyroïdien, l’orbitopathie et le myxœdème prétibial orientent vers la maladie de Basedow, alors qu’un cou douloureux oriente vers une thyroïdite.', 15, 16, 7, 22) +
 F('Examen région par région : normal, technique, anomalie et valeur',
   TAB(['Région', 'Normal', 'Technique', 'Anomalie', 'Valeur diagnostique'], [
    ['Constantes', 'Fréquence 60–100/min, température < 37,5 °C, poids stable', 'Pouls sur une minute, température, pesée comparée', 'Tachycardie, fièvre, perte de poids', 'La fièvre avec confusion fait rechercher une crise.'],
    ['Peau et mains', 'Peau tiède et sèche, ongles normaux', 'Toucher la paume ; bras tendus, doigts écartés, une feuille posée sur les doigts', f'Peau chaude et moite, {T("tremblement fin", "Le tremblement fin des extrémités est rapide et de faible amplitude ; il augmente bras tendus et traduit l’hypersensibilité adrénergique.")}, {T("onycholyse", "L’onycholyse est un décollement distal de l’ongle de son lit, classique dans la thyrotoxicose (ongles de Plummer).")}', 'Ces signes soutiennent la thyrotoxicose sans en indiquer la cause.'],
    ['Cou', 'Thyroïde non visible, souple, indolore, mobile à la déglutition', 'Inspection pendant que le patient avale ; palpation par derrière ; auscultation des lobes', f'Goitre diffus élastique, nodule, douleur exquise, {T("souffle thyroïdien", "Le souffle continu ou systolique perçu au stéthoscope sur la glande, parfois avec un frémissement palpable (thrill), traduit l’hypervascularisation du Basedow.")}', 'Le souffle et le frémissement sont très évocateurs de Basedow ; la douleur oriente vers une thyroïdite subaiguë.'],
    ['Yeux', 'Paupière supérieure couvrant le limbe, motilité indolore, vision normale', 'Regarder en face puis vers le bas ; motilité dans 9 directions ; acuité et vision des couleurs ; exophtalmomètre de Hertel', f'{T("Rétraction palpébrale", "La paupière supérieure découvre la sclère au-dessus de l’iris ; l’hyperactivité adrénergique du muscle de Müller l’explique, quelle que soit la cause.")}, {T("asynergie oculo-palpébrale", "Signe de von Graefe : au regard vers le bas, la paupière supérieure suit l’œil avec retard.")}, {T("exophtalmie", "L’œil avance hors de l’orbite ; une asymétrie > 2 mm à l’exophtalmomètre est pathologique.")}, diplopie', 'L’exophtalmie et la diplopie signent l’orbitopathie basedowienne ; la rétraction seule ne l’est pas.'],
    ['Activité orbitaire', 'Absence de rougeur et de douleur', f'{T("Score d’activité clinique (CAS)", "Un point pour chacun des 7 items : douleur rétro-oculaire spontanée, douleur aux mouvements oculaires, rougeur des paupières, rougeur conjonctivale, œdème palpébral, chémosis, œdème de la caroncule. Un score ≥ 3/7 définit une orbitopathie active (EUGOGO).")}', 'CAS ≥ 3/7', 'Le score sélectionne les orbitopathies qui répondent aux anti-inflammatoires.'],
    ['Cœur', 'Rythme régulier, pas de souffle, pas de signe congestif', 'Auscultation, pouls et fréquence comparés à l’ECG ; bases pulmonaires, œdèmes', 'Tachycardie, rythme irrégulier, souffle systolique éjectionnel, râles crépitants', 'Ces signes classent la gravité et la sécurité du bêtabloquant.'],
    ['Muscles et réflexes', 'Force proximale normale, réflexes normaux', 'Se lever d’une chaise sans les mains, réflexes ostéotendineux', 'Faiblesse proximale, réflexes vifs à relaxation rapide', 'La myopathie traduit une thyrotoxicose sévère ou ancienne.'],
    ['Peau prétibiale et doigts', 'Peau souple', 'Inspection et palpation des faces antérieures des jambes', f'{T("Myxœdème prétibial", "La dermopathie basedowienne forme des plaques infiltrées en « peau d’orange », sans godet, sur les faces antérieures des jambes ; elle accompagne presque toujours une orbitopathie.")}, acropachie', 'Ces signes, rares, sont quasi spécifiques de Basedow.'],
   ]) + P('Le score d’activité clinique compte 7 items ; un score ≥ 3/7 définit une orbitopathie active.', 32, 25))))
