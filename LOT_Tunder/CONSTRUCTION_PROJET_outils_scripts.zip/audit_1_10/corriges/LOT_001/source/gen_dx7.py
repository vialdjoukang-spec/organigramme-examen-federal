# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.7 · Tuberculose (LOT 1, Appel B, Partie 3b, r2 → audit du 24.10.2026)."""
import sys; sys.path.insert(0, '/workspace/audit_1_10/outils')
from gen_v7 import *
from src_P3b import SOURCES_ORIG
POINT = mkPOINT('dx7')
M = dict(pref='dx7', dx='DX.7', court='Tuberculose', long='Tuberculose', dossier='corriges/LOT_001',
         fichier='LOT_001_DX7_Tuberculose_AUDITÉ.html', lot_titre='LOT 1 · G1 · Transpiration anormale',
         sous_titre='PROFILES 2023 · SSP G1 · LOT 1 · Appel B · V7 · version AUDITÉE',
         statut='Cette version corrige la monographie DX.7 du LOT 1 (Appel B, V7, Partie 3b, révision r2) après audit médical et linguistique ; les doses proviennent des informations professionnelles suisses (AIPS).')
ITB = T('infection tuberculeuse', 'L’infection tuberculeuse est une réponse immunitaire persistante aux antigènes du bacille, sans maladie clinique ; la personne n’est ni malade ni contagieuse, mais elle peut progresser vers une maladie.')
GRAN = T('granulome', 'Le granulome est un amas de macrophages, de cellules géantes et de lymphocytes qui entoure le bacille pour le contenir ; son centre peut se nécroser (nécrose caséeuse).')
HRZE = T('schéma 2HRZE/4HR', 'Le schéma 2HRZE/4HR signifie deux mois d’isoniazide (H), rifampicine (R), pyrazinamide (Z) et éthambutol (E), puis quatre mois d’isoniazide et de rifampicine.')
ISOL = T('isolement aéroporté', 'L’isolement aéroporté place le patient en chambre individuelle ventilée ; le personnel porte un masque FFP2 (filtering facepiece) et le patient un masque chirurgical quand il sort de la chambre.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('La tuberculose est une maladie causée par une bactérie du complexe Mycobacterium tuberculosis, qui atteint surtout les poumons mais aussi les ganglions, la plèvre, les méninges et les os. '
   f'Le guide suisse distingue la maladie de l’{ITB}, qui n’a pas de manifestation clinique. '
   'Un test immunologique positif ne suffit donc pas à attribuer des sueurs nocturnes à une tuberculose active.', 4) +
 F('Terminologie',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Maladie tuberculeuse', 'Atteinte d’organe prouvée par microbiologie du site', 'Infection sans maladie'],
    ['Infection tuberculeuse', 'Réponse immunitaire sans maladie, non contagieuse', 'Ancien terme « latente », trop simplificateur'],
    ['Contagiosité', 'Capacité d’une forme respiratoire à transmettre par aérosols', 'Le mot « porteur », trompeur'],
    ['Tuberculose multirésistante', 'Résistance au moins à l’isoniazide et à la rifampicine', 'Résistance isolée à un médicament'],
    ['Mycobactérie non tuberculeuse', 'Mycobactérie de l’environnement, non transmise entre humains', 'Complexe M. tuberculosis'],
   ]) + P('La distinction évite de traiter un résultat de laboratoire plutôt qu’une maladie.', 4))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse et au Liechtenstein, l’OFSP a reçu 544 déclarations en 2025, soit 6,0 cas pour 100 000 habitants, dont 67,3 % d’hommes. '
   'Les adultes de 20 à 39 ans représentent le groupe le plus nombreux, alors que les adolescents de 15 à 19 ans ont le taux le plus élevé, à 22,3 pour 100 000.', 4, 5) +
 P('L’infection récente, le jeune âge et l’immunosuppression (surtout le VIH) favorisent la progression, et la mortalité élevée sans traitement contraste avec un bon pronostic sous traitement complet.', 4, 5) +
 F('Chiffres, terrain et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Déclarations en Suisse et au Liechtenstein, 2025', '544 (6,0 / 100 000)', 'Bulletin OFSP du 21 septembre 2026'],
    ['Proportion d’hommes', '67,3 %', 'Même bulletin'],
    ['Taux le plus élevé', '22,3 / 100 000 (15–19 ans)', 'Même bulletin'],
    ['Incidence mondiale', '≈ 10,8 millions de cas en 2023', 'OMS, Global Tuberculosis Report 2024'],
    ['Région européenne de l’OMS', '≈ 25 / 100 000 par an', 'OMS, Global Tuberculosis Report 2024'],
   ]) + P('Les pourcentages de succès thérapeutique portent sur une autre cohorte que les cas 2025 et ne se déduisent pas de ces chiffres.', 5, 28))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Le bacille, inhalé dans des gouttelettes, est capté par les macrophages alvéolaires, qui ne parviennent pas toujours à le détruire. '
   f'L’immunité cellulaire (lymphocytes T, interféron gamma) l’enferme dans un {GRAN}, ce qui explique l’infection sans maladie et la positivité de l’IGRA. '
   'Si l’immunité faiblit, le granulome se nécrose et forme une caverne riche en bacilles, d’où la toux, la contagiosité et les sueurs liées aux cytokines. '
   'Le traitement associe plusieurs antibiotiques longtemps, parce que les bacilles se divisent lentement et qu’un seul médicament sélectionne des mutants résistants.', 4, 18) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les alvéoles pulmonaires, surtout des sommets bien ventilés, reçoivent l’air et donc le bacille ; les ganglions du hile drainent ce territoire.'],
    ['Physiologie', 'Pourquoi le corps contient souvent le bacille : les macrophages le présentent aux lymphocytes T, qui libèrent l’interféron gamma et organisent un granulome.'],
    ['Physiopathologie', 'Quand l’immunité baisse (VIH, âge, médicaments), le granulome se ramollit, se vide dans une bronche et forme une caverne pleine de bacilles.'],
    ['Clinique', 'D’où la toux qui dure plus de 2 à 3 semaines, les crachats parfois sanglants, la fièvre et les sueurs nocturnes (cytokines) et la perte de poids.'],
    ['Examens', 'La radiographie montre la caverne ; les crachats montrent le bacille (microscopie, test moléculaire, culture) ; l’IGRA prouve seulement le contact immunitaire.'],
    ['Traitement', 'Quatre antibiotiques pendant 2 mois tuent vite la masse de bacilles, puis deux pendant 4 mois stérilisent les bacilles lents ; l’isolement protège l’entourage au début.'],
   ]), 4, 6) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme (lésion)', 'Exploration qui le montre', 'Cible thérapeutique'], [
    ['Caverne pulmonaire riche en bacilles', 'Radiographie ou TDM, expectorations', 'Phase intensive HRZE, isolement aéroporté'],
    ['Résistance à la rifampicine', 'Test moléculaire rapide', 'Schéma spécialisé, jamais simple retrait de la rifampicine'],
    ['Infection sans maladie', 'IGRA, radiographie normale', 'Traitement préventif après exclusion d’une maladie active'],
    ['Méningite tuberculeuse', 'Ponction lombaire, IRM', '12 mois de traitement, corticoïdes au début'],
    ['Épanchement pleural', 'Échographie, ponction, biopsie', 'Même schéma, drainage si besoin'],
   ]) + P('Le mécanisme explique pourquoi l’amélioration des sueurs ne signifie ni guérison ni fin de contagiosité.', 4))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Devant des sueurs nocturnes, le médecin recherche d’abord une toux prolongée, une hémoptysie, une perte de poids et une exposition (contact, migration, immunosuppression). '
   'Il protège immédiatement l’entourage par un masque si une forme respiratoire est possible, puis il prouve la maladie par la microbiologie du site. '
   'Il garde en tête les autres causes de sueurs nocturnes, surtout le lymphome et le VIH.', 4) +
 F('Diagnostic différentiel des sueurs nocturnes avec signes généraux (fréquence sourcée en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Tuberculose' + PR('6,0 / 100 000 par an (Suisse, 2025)', 5), 'Toux > 2–3 semaines, exposition, migration', 'Expectorations : test moléculaire, culture'],
    ['Cancer du poumon' + PR('≈ 50 / 100 000 par an (Suisse)', 29), 'Tabac, âge > 50 ans, hémoptysie', 'TDM thoracique, biopsie'],
    ['Lymphome non hodgkinien' + PR('≈ 20 / 100 000 par an (Suisse)', 29), 'Adénopathies, prurit, sueurs profuses', 'Biopsie ganglionnaire'],
    ['Infection par le VIH (nouveaux diagnostics)' + PR('≈ 4 / 100 000 par an (Suisse)', 30), 'Exposition, candidose, infections répétées', 'Test VIH'],
    ['Endocardite infectieuse' + PR('3–10 / 100 000 par an (Europe)', 31), 'Fièvre, souffle, matériel cardiaque', 'Hémocultures, échocardiographie'],
    ['Sarcoïdose' + PR('1–15 / 100 000 par an', 32), 'Adénopathies hilaires bilatérales, érythème noueux', 'Biopsie : granulome sans nécrose'],
    ['Mycobactérie non tuberculeuse' + PR('fréquence suisse non publiée', 4), 'Bronchectasies, terrain pulmonaire', 'Culture et identification moléculaire'],
    ['Hyperthyroïdie' + PR('≈ 0,75 % (Europe)', 33), 'Palpitations, tremblement, sans fièvre', 'TSH'],
   ]) + P('Les fréquences décrivent une incidence annuelle ou une prévalence, comme indiqué ; elles ne sont pas des probabilités devant un patient donné. Une toux prolongée chez une personne exposée rend la tuberculose beaucoup plus probable que dans la population générale.', 4))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise la durée de la toux, les crachats et le sang, la fièvre, les sueurs et la perte de poids chiffrée. '
   'Il recherche un contact, un séjour ou une origine dans une région de forte incidence, une immunosuppression, les médicaments et la contraception, avec un interprète professionnel si la langue gêne.', 4) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis quand toussez-vous ? Crachez-vous du sang ?', 'Une toux > 2–3 semaines évoque une forme pulmonaire.', 'Masque et prélèvements rapides.'],
    ['Combien de kilos avez-vous perdus ?', 'La perte de poids traduit une maladie évolutive.', 'Elle renforce la suspicion.'],
    ['Avez-vous côtoyé un malade de la tuberculose ?', 'Le contact est le premier facteur de risque.', 'Il oriente vers une infection récente.'],
    ['Avez-vous vécu dans une région de forte incidence ?', 'La migration récente concentre les cas suisses.', 'Elle augmente la probabilité.'],
    ['Avez-vous le VIH ou prenez-vous un immunosuppresseur ?', 'L’immunité cellulaire contient le bacille.', 'Forme atypique, test VIH proposé.'],
    ['Prenez-vous une contraception hormonale ou d’autres médicaments ?', 'La rifampicine induit les enzymes du foie.', 'Contraception non hormonale, interactions à vérifier.'],
   ])) +
 U('<b>Drapeaux rouges et urgence (appel du 144 si hémoptysie abondante ou détresse respiratoire)</b> : hémoptysie, dyspnée, confusion ou raideur de nuque (méningite), ictère sous traitement.', 4, 17, 23)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure température, poids, fréquence respiratoire et saturation, puis il ausculte et percute le thorax. '
   'Il palpe les aires ganglionnaires, recherche une raideur de nuque et des signes neurologiques, et examine le foie avant le traitement. '
   'Un examen normal est fréquent et n’exclut pas la maladie, car aucun signe n’est spécifique du bacille.', 2, 3, 24) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Percussion thoracique', 'Sonorité normale', 'Matité : épanchement ou condensation'],
    ['Auscultation pulmonaire', 'Murmure vésiculaire symétrique', 'Diminution : épanchement ; crépitants : atteinte parenchymateuse'],
    ['Aires ganglionnaires cervicales', 'Pas d’adénopathie', 'Adénopathie ferme, parfois fistulisée : forme ganglionnaire'],
    ['Raideur de nuque, nerfs crâniens', 'Absentes, normaux', 'Raideur, paralysie : méningite tuberculeuse'],
    ['Poids et IMC (indice de masse corporelle)', 'Stables', 'Perte de poids : maladie évolutive, dénutrition'],
   ]) + P('Ces signes ont une sensibilité et une spécificité faibles pour la tuberculose ; leur valeur est d’orienter les prélèvements.', 3))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la toux, les expectorations, l’hémoptysie, la douleur pleurale, les sueurs nocturnes et l’asthénie. '
   'Les signes physiques sont la fièvre, la perte de poids, la matité, la diminution du murmure et les adénopathies. '
   'Ils dessinent un syndrome de condensation, un syndrome pleural ou un syndrome méningé.', 3, 4, 23) +
 F('Signes et syndromes définis',
   TAB(['Signe ou syndrome', 'Description', 'Mécanisme'], [
    ['Syndrome infectieux chronique', 'Fièvre vespérale, sueurs nocturnes, amaigrissement', 'Cytokines (TNF, interleukines)'],
    ['Syndrome de condensation', 'Matité, souffle tubaire, crépitants', 'Alvéoles remplies d’inflammation'],
    ['Syndrome pleural', 'Matité, abolition du murmure, douleur respiratoire', 'Épanchement inflammatoire'],
    ['Syndrome méningé', 'Céphalées, raideur de nuque, confusion', 'Inflammation des méninges, surtout à la base du crâne'],
    ['Hémoptysie', 'Crachat de sang', 'Érosion d’un vaisseau dans une caverne'],
   ]) + P('Termes : ' + T('hémoptysie', 'L’hémoptysie est un crachat de sang venant des voies respiratoires ; abondante, elle menace par asphyxie.') + ', '
          + T('matité', 'La matité est un son de percussion atténué, signe de liquide ou de tissu dense sous la paroi.') + ', '
          + T('caverne', 'La caverne est une cavité pulmonaire formée par la nécrose d’un granulome, riche en bacilles.') + ', '
          + T('miliaire', 'La miliaire est une dissémination sanguine de petits nodules dans tout le poumon et d’autres organes.') + ', '
          + T('ictère', 'L’ictère colore en jaune la peau et les sclères ; sous traitement, il fait suspecter une hépatite médicamenteuse.') + '.', 3, 4, 17))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('La recommandation suisse OFSP et Ligue pulmonaire 2024 retient comme critère la preuve de Mycobacterium tuberculosis dans un prélèvement approprié, par culture ou méthode moléculaire. '
   'Le guide de déclaration OFSP 2026 classe comme cas confirmé une culture positive, ou un test d’amplification positif avec microscopie positive. '
   'Un IGRA positif ne suffit pas et un IGRA négatif n’exclut pas la maladie, alors que la culture, spécifique à ≈ 100 %, mesure la sensibilité en 2 à 6 semaines.', 4, 9) +
 F('Catégories de cas et règles',
   TAB(['Catégorie', 'Critère', 'Conséquence'], [
    ['Cas confirmé', 'Culture positive, ou amplification positive avec microscopie positive', 'Déclaration et traitement'],
    ['Cas probable', 'Amplification positive isolée', 'Interprétation avec la clinique'],
    ['Cas clinique', 'Décision de traiter sans preuve microbiologique', 'Traitement complet, suivi rapproché'],
    ['Infection tuberculeuse', 'IGRA positif, pas de maladie', 'Pas de déclaration de maladie ; prévention discutée'],
   ]) + P('Ces catégories servent à la surveillance ; elles ne remplacent pas la décision clinique.', 9))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Culture des mycobactéries', 'Gold standard : maladie et sensibilité aux antibiotiques', 'Référence ; spécificité ≈ 100 %', '2 à 6 semaines'],
    ['Test moléculaire rapide (Xpert MTB/RIF Ultra)', 'Complexe tuberculosis et résistance à la rifampicine', 'Sensibilité ≈ 91 %, spécificité ≈ 96 % (expectorations)' + S(34), 'Reste positif après la mort des bacilles'],
    ['Microscopie (recherche de BAAR)', 'Bacilles visibles, contagiosité', 'Sensibilité ≈ 50–60 %' + S(35), 'Ne distingue pas les mycobactéries non tuberculeuses'],
    ['IGRA', 'Contact immunitaire avec le bacille', 'Ne distingue pas infection et maladie', 'Faux négatifs si immunodépression'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Radiographie du thorax', 'Toute suspicion'],
    ['Première', 'Expectorations : test moléculaire, microscopie, culture', 'Suspicion pulmonaire'],
    ['Seconde', 'Expectoration induite, fibroscopie avec lavage', 'Pas de crachat spontané'],
    ['Seconde', 'TDM thoracique à faible dose', 'Radiographie peu contributive'],
    ['Formes extrapulmonaires', 'Ponction ou biopsie du site, ponction lombaire, IRM', 'Ganglion, plèvre, méninges, os'],
    ['Bilan avant traitement', 'Test VIH, tests hépatiques, créatinine, vision', 'Sécurité des médicaments'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Le premier <b>échantillon d’expectoration</b> de qualité se fait sur place avec un test moléculaire rapide, puis un second environ une heure plus tard ; jamais dans une salle d’attente commune.',
       'Le patient distingue salive et expectoration ; le recueil se fait idéalement avant le traitement.',
       'Une <b>biopsie</b> ne doit pas être entièrement fixée au formol : une fraction fraîche part en culture.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Test moléculaire positif', 'Détection', 'Maladie probable', 'Traitement, recherche de résistance'],
    ['Test moléculaire négatif', '—', 'N’exclut pas une maladie paucibacillaire', 'Culture, autres prélèvements'],
    ['Résultat limite (traces)', '—', 'Charge bacillaire faible', 'Interpréter avec la clinique'],
    ['Culture positive à 2 mois de traitement', '—', 'Réponse lente ou résistance', 'Contrôle mensuel jusqu’à négativation'],
    ['Résultat discordant (PCR positive, culture négative)', '—', 'Bacilles morts ou faible charge', 'Avis spécialisé'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Radiographie avec protection, imagerie nécessaire non interdite'],
    ['Enfant', 'Tubage gastrique ou expectoration induite ; IGRA négatif peu rassurant'],
    ['DFGe < 30 mL/min/1,73 m²', 'Pas de produit de contraste iodé sans nécessité ; Rimstar® contre-indiqué'],
    ['Allergie aux produits iodés', 'TDM sans contraste ou IRM'],
    ['Stimulateur cardiaque', 'Vérification de compatibilité avant IRM'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('La radiographie du thorax oriente, mais seule la microbiologie du site prouve la maladie. '
   'Le test moléculaire rapide détecte le bacille et la résistance à la rifampicine en quelques heures, et la culture confirme et mesure la sensibilité. '
   'Avant le traitement, le bilan comprend un test VIH, les fonctions hépatique et rénale et un examen de la vision.', 4, 13, 14, 15, 16) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une forme pulmonaire est suspectée, alors le médecin isole, prélève les expectorations et demande un test moléculaire rapide. '
   'Si la maladie est prouvée et sensible, alors il débute le schéma standard, mais il adresse toute résistance à la rifampicine à une équipe spécialisée. '
   'Si seule une infection est présente, il exclut une maladie active avant tout traitement préventif.', 4) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Toux prolongée, sueurs, exposition', 'Masque, radiographie, expectorations', 'Résultat moléculaire en quelques heures'],
    ['Test moléculaire positif, rifampicine sensible', 'Schéma 2HRZE/4HR, déclaration', 'Expectorations à 2 mois'],
    ['Résistance à la rifampicine', 'Équipe spécialisée, schéma de réserve', 'Culture et sensibilités complètes'],
    ['Méningite tuberculeuse', '12 mois de traitement, corticoïdes au début', 'Neurologique rapproché'],
    ['IGRA positif sans maladie', 'Traitement préventif discuté selon le risque', 'Tests hépatiques'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Dose et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Rimstar®, rifampicine 150 mg + isoniazide 75 mg + pyrazinamide 400 mg + éthambutol 275 mg (antituberculeux), autorisation 56768', 'Phase intensive de 2 mois, 1×/j à jeun : 2 comprimés (30–37 kg), 3 (38–54 kg), 4 (55–70 kg), 5 (≥ 71 kg)', 'Contre-indications : clairance < 30 mL/min, névrite périphérique, porphyrie, goutte, ictère, atteinte oculaire ; grossesse selon la notice ; hépatite, névrite optique'],
   ['Rimactazid® 150/75, rifampicine 150 mg + isoniazide 75 mg, autorisation 56769', 'Continuation de 4 mois, 1×/j à jeun au moins une heure avant un repas, mêmes tranches de poids', 'Hépatite ; urines et larmes orange ; induction enzymatique majeure (contraception hormonale inefficace)'],
   ['Pyridoxine (vitamine B6)', '10 mg/j dès le début dans les groupes à risque des notices', 'Prévient la neuropathie de l’isoniazide (âge, dénutrition, VIH, grossesse, insuffisance rénale, diabète)'],
  ]) + P('Pharmacodynamie : la rifampicine inhibe l’ARN polymérase bactérienne et l’isoniazide bloque la synthèse des acides mycoliques. Pharmacocinétique : l’élimination biliaire et l’induction enzymatique de la rifampicine rendent les interactions majeures.', 6, 7) + P('Les doses sont celles des AIPS suisses ; les schémas des résistances (bédaquiline, prétomanide, linézolide, moxifloxacine) relèvent de l’équipe spécialisée et ne sont pas chiffrés ici. Le guide suisse recommande le schéma standard pendant la grossesse, alors que la notice de Rimstar® le déconseille : la décision est spécialisée.', 4, 6, 7))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge guérit le patient et interrompt la transmission, parce qu’une forme respiratoire non traitée contamine l’entourage. '
   f'Le traitement standard d’une maladie sensible est le {HRZE}, pris chaque jour, et l’{ISOL} protège l’entourage au début. '
   'Le suivi contrôle l’observance, la tolérance et les expectorations, et le médecin déclare le cas.', 4, 6, 7) +
 F('11.A Buts : formes compliquées et non compliquées',
   P('Forme compliquée (hémoptysie abondante, méningite, miliaire) : c’est une urgence, avec prise en charge hospitalière dans les heures qui suivent et traitement débuté sans attendre la culture.', 4, 17, 23) +
   P('Dans la forme non compliquée, le but est la guérison sans rechute ni résistance, la fin de la contagiosité et la protection des contacts.', 4)) +
 F('11.B Moyens',
   F('Mesures générales et ordre (forme non compliquée, souvent ambulatoire après la phase contagieuse)',
     OL(['Isolement aéroporté à l’hôpital si une forme pulmonaire contagieuse est suspectée, jusqu’à un premier test moléculaire respiratoire négatif.',
         'Éducation du patient : prise quotidienne, durée complète, effets indésirables ; interprète si nécessaire.',
         'Phase intensive de 2 mois (HRZE), puis continuation de 4 mois (HR).',
         'Pyridoxine dans les groupes à risque ; contraception non hormonale.',
         'Déclaration au médecin cantonal et enquête d’entourage.']), 4, 8, 9) +
   MED +
   F('Volets social et professionnel',
     UL(['Le médecin déclare dans la semaine le cas au médecin cantonal (par voie électronique à l’OFSP) ; le laboratoire déclare dans les 24 heures.',
         'La LAMal (art. 25 et 32) prend en charge le traitement ; la LAA (art. 6 et 9) peut intervenir si l’origine est professionnelle (soignant exposé) ; la LAI (art. 7, 8 et 28) ne concerne que les incapacités durables.',
         'L’arrêt de travail couvre la période contagieuse ; la reprise professionnelle est décidée avec le médecin cantonal.',
         'La conduite automobile est réévaluée si l’éthambutol trouble la vision ou si une confusion apparaît (AIPS Rimstar®).']), 6, 8, 9, 19, 20, 21) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Schéma standard selon le guide suisse ; Rimstar® déconseillé par sa notice : décision spécialisée, pyridoxine'],
      ['Personne âgée ou dénutrie', 'Pyridoxine, surveillance hépatique rapprochée'],
      ['Enfant', 'Doses pédiatriques spécialisées ; Rimstar® seulement dès 8 ans et 30 kg'],
      ['Insuffisance hépatique', 'Tests hépatiques toutes les 2 à 4 semaines ; ictère : arrêt et avis'],
      ['Insuffisance rénale (clairance < 30 mL/min)', 'Rimstar® contre-indiqué ; composants séparés et contrôle ophtalmologique hebdomadaire'],
      ['Infection par le VIH', 'Interactions avec les antirétroviraux ; rifabutine discutée par l’équipe'],
     ]), 4, 6, 7), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Toux, fièvre, poids, observance', 'Chaque visite', 'Aggravation : rechercher résistance ou non-observance'],
    ['ALAT, ASAT, bilirubine', 'Avant, puis toutes les 2 à 4 semaines', 'Ictère ou hausse importante : arrêt et avis'],
    ['Vision (acuité, couleurs)', 'Avant, puis toutes les 4 semaines sous Rimstar®', 'Trouble : arrêt de l’éthambutol'],
    ['Expectorations', 'À 2 mois', 'Positives : contrôle mensuel jusqu’à négativation'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['L’état clinique est stable et les médicaments sont bien tolérés.', 'L’isolement peut se poursuivre à domicile si les conditions sociales le permettent (la période initiale dure souvent 5 à 15 jours).', 'Le suivi, la prise quotidienne et l’enquête d’entourage sont organisés.'])) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La guérison pulmonaire documentée exige une preuve initiale, un traitement complet et deux microscopies négatives à 7 jours d’intervalle ; le résultat est collecté à 12 mois (24 mois si multirésistance). Une PCR encore positive ne prouve pas l’échec. La recherche 2026 évalue des schémas plus courts et la rifampicine à forte dose.', 4, 9, 12))))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose en Suisse sur l’isolement des formes contagieuses, l’enquête d’entourage et le BCG, réservé aux nourrissons de moins de 12 mois qui vivront durablement dans un pays d’incidence > 50 / 100 000. '
   'La prévention secondaire dépiste et traite l’infection chez les contacts et les personnes immunodéprimées, après exclusion d’une maladie active. '
   'La prévention tertiaire assure un traitement complet pour éviter rechute et résistance.', 4, 10, 11) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Isolement aéroporté, masque FFP2, BCG ciblé'],
    ['Secondaire', 'Enquête d’entourage, IGRA, traitement préventif'],
    ['Tertiaire', 'Observance, surveillance de la tolérance, déclaration du résultat'],
   ]))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin distingue l’infection tuberculeuse, non contagieuse, de la maladie prouvée par la microbiologie. '
   'Il isole et prélève les expectorations dès qu’une forme pulmonaire est possible. '
   'Il traite une maladie sensible par 2HRZE/4HR, selon le poids, avec pyridoxine si nécessaire. '
   'Il surveille foie et vision et vérifie les interactions de la rifampicine. '
   'Il déclare le cas dans la semaine et organise l’enquête d’entourage.', 4, 6, 7, 8)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Un IGRA positif prouve une tuberculose active.', 'Non : il prouve un contact immunitaire.'],
  ['Les sueurs ont disparu, donc le patient est guéri.', 'Non : la guérison exige un traitement complet et une preuve microbiologique.'],
  ['Une PCR positive à 2 mois signe l’échec.', 'Non : le matériel génétique persiste ; la culture tranche.'],
  ['Résistance à la rifampicine : retirer la rifampicine du schéma.', 'Non : schéma spécialisé de réserve.'],
  ['Contraception orale maintenue sous rifampicine.', 'Non : induction enzymatique, contraception non hormonale.'],
  ['Clairance < 30 mL/min : 3 comprimés de Rimstar® au lieu de 4.', 'Non : Rimstar® est contre-indiqué.'],
  ['Le jeune enfant malade est la source.', 'Il est souvent peu contagieux ; l’adulte qui l’accompagne doit être évalué.'],
 ]) + P('Ces pièges reprennent le guide suisse 2024 et les AIPS.', 4, 6, 7)))
SOURCES = sorted(SOURCES_ORIG.items()) + [
 (28, 'Organisation mondiale de la santé (OMS). Global Tuberculosis Report 2024. Genève : OMS ; 2024. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (29, 'OFS, NICER, Registre du cancer de l’enfant. Rapport suisse sur le cancer 2021. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (30, 'Office fédéral de la santé publique (OFSP). VIH, syphilis, gonorrhée et chlamydiose en Suisse : situation épidémiologique 2023. Bulletin OFSP. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (31, 'Delgado V et al. 2023 ESC Guidelines for the management of endocarditis. Eur Heart J 2023;44:3948–4042. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (32, 'Grunewald J et al. Sarcoidosis. Nat Rev Dis Primers 2019;5:45. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (33, 'Garmendia Madariaga A et al. The incidence and prevalence of thyroid dysfunction in Europe: a meta-analysis. J Clin Endocrinol Metab 2014;99:923–931. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (34, 'Zifodya JS et al. Xpert Ultra versus Xpert MTB/RIF for pulmonary tuberculosis and rifampicin resistance in adults with presumptive pulmonary tuberculosis. Cochrane Database Syst Rev 2021;2:CD009593. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (35, 'Steingart KR et al. Sputum processing methods to improve the sensitivity of smear microscopy for tuberculosis: a systematic review. Lancet Infect Dis 2006;6:664–674. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
]
CTX = {'_prefixe': 'Dans la tuberculose',
 'radio': 'La radiographie du thorax cherche caverne, infiltrat des sommets, épanchement ou miliaire ; elle oriente mais ne prouve pas.',
 'tdm': 'La TDM thoracique à faible dose précise des lésions peu visibles à la radiographie.',
 'expecto': 'Les expectorations de qualité, recueillies hors salle d’attente, servent au test moléculaire, à la microscopie et à la culture.',
 'pcr': 'Le test moléculaire rapide détecte le complexe tuberculosis et la résistance à la rifampicine en quelques heures ; il peut rester positif après la mort des bacilles.',
 'igra': 'L’IGRA prouve un contact immunitaire ; il ne distingue pas infection et maladie.',
 'vih': 'Le test VIH est proposé à toute personne atteinte de tuberculose.',
 'hep': 'Les tests hépatiques se font avant puis toutes les 2 à 4 semaines sous antituberculeux.',
 'creat': 'Une clairance < 30 mL/min contre-indique Rimstar®.',
 'nfs': 'L’hémogramme fait partie du bilan initial et du suivi de tolérance.',
 'crp': 'La CRP suit l’inflammation mais ne prouve pas la tuberculose.',
 'biopsie': 'La biopsie du site garde une fraction fraîche pour la culture, sans formol.',
 'pl': 'La ponction lombaire cherche une méningite tuberculeuse (lymphocytes, protéines élevées, glucose bas).',
 'irm': 'L’IRM cérébrale cherche une atteinte de la base du crâne ou des tuberculomes.',
 'hcg': 'Le test de grossesse précède le choix du schéma.',
 'hemoc': 'Les hémocultures recherchent un diagnostic différentiel bactérien.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
