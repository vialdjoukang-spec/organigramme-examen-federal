#!/bin/bash
# Reconstruit le cours AUDITÉ DX.6 (a/b), insère les fenêtres d'examens, relance les outils d'audit.
set -e
cd /workspace/audit_1_10
PY=./venv/bin/python
(cd corriges/LOT_001/source && python3 gen_dx6_part4.py DX6_source.html)
for x in a b; do
  $PY bibliotheque_examens/inserer_fenetres.py corriges/LOT_001/source/DX6_source_$x.html "corriges/LOT_001/LOT_001_DX6_Hyperthyroidie_AUDITÉ_$x.html" --ctx corriges/LOT_001/source/ctx_DX6.json --portee point --max-octets 195000 --prefixe-uid $x
done
$PY outils/mobile.py corriges/LOT_001/LOT_001_DX6_Hyperthyroidie_AUDITÉ_a.html corriges/LOT_001/LOT_001_DX6_Hyperthyroidie_AUDITÉ_b.html
$PY outils/sigles.py corriges/LOT_001/LOT_001_DX6_Hyperthyroidie_AUDITÉ_a.html corriges/LOT_001/LOT_001_DX6_Hyperthyroidie_AUDITÉ_b.html
$PY outils/charte_v7plus.py corriges/LOT_001/LOT_001_DX6_Hyperthyroidie_AUDITÉ_a.html corriges/LOT_001/LOT_001_DX6_Hyperthyroidie_AUDITÉ_b.html
$PY outils/decoupe.py LOT_001_AUDITE && $PY outils/examens.py LOT_001_AUDITE | tail -1 && $PY outils/style.py LOT_001_AUDITE "$@" | tail -1 && $PY outils/score.py LOT_001_AUDITE | tail -2
