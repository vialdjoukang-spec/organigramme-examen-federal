# -*- coding: utf-8 -*-
"""Générateur du cours corrigé DX.6 (partie 4 : points 12 à 14, sources, assemblage)."""
import os, sys, json
from gen_dx6_part3 import *

PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose en Suisse sur le sel iodé, sur l’arrêt du tabac et sur l’évitement des surcharges iodées non justifiées chez la personne porteuse d’un goitre nodulaire. '
   'La prévention secondaire dose la TSH devant une fibrillation atriale, une ostéoporose, un amaigrissement inexpliqué, et avant puis pendant un traitement par amiodarone, lithium ou immunothérapie ; elle ne recommande pas de dépistage général. '
   'La prévention tertiaire prévient la crise, l’agranulocytose grave, l’orbitopathie et la perte osseuse par l’éducation, l’observance et le traitement définitif au bon moment.', 10, 1, 22, 24, 25) +
 F('Les trois niveaux en pratique',
   TAB(['Niveau', 'Mesure', 'Pourquoi'], [
    ['Primaire', 'Sel iodé (mesure fédérale) ; TSH avant un produit de contraste chez la personne âgée porteuse d’un goitre nodulaire si le risque est élevé', 'La carence iodée favorise l’autonomie ; l’iode en excès la démasque.'],
    ['Primaire', 'Arrêt du tabac', 'Le tabac favorise la maladie de Basedow et aggrave l’orbitopathie.'],
    ['Secondaire', 'TSH avant amiodarone puis régulièrement pendant et après le traitement (ETA 2018)', 'L’amiodarone libère de l’iode et peut causer une thyroïdite des mois après l’arrêt.'],
    ['Secondaire', 'TSH sous immunothérapie par inhibiteurs de points de contrôle', 'Une thyroïdite survient fréquemment.'],
    ['Tertiaire', 'Consigne écrite « fièvre ou angine : arrêt de l’ATS et NFS le jour même »', 'L’agranulocytose précoce se traite mieux.'],
    ['Tertiaire', 'Euthyroïdie avant une chirurgie, un accouchement ou un iode radioactif', 'Ces situations déclenchent la crise.'],
    ['Tertiaire', 'Sélénium dans l’orbitopathie légère ; prednisone autour de l’iode radioactif à risque', 'L’orbitopathie s’aggrave moins.'],
    ['Tertiaire', 'Calcium, vitamine D, ostéodensitométrie selon le risque ; anticoagulation d’une fibrillation atriale selon CHA₂DS₂-VASc', 'L’os et le cerveau sont protégés.'],
   ]))))

PTS.append(POINT(13, 'Points clés',
 P('La thyrotoxicose ne signifie pas toujours une hyperthyroïdie, car la fixation scintigraphique sépare l’hyperproduction de la fuite hormonale. '
   'La TSH se dose en premier, puis la T4 libre, et les TRAb confirment la maladie de Basedow. '
   'Une fièvre ou une angine sous ATS impose l’arrêt du traitement et une NFS le jour même. '
   'La crise aiguë thyrotoxique se diagnostique cliniquement et se traite dans l’ordre : ATS, bêtabloquant, hydrocortisone, puis iodure au moins une heure plus tard. '
   'L’orbitopathie, l’os et le cœur se surveillent même quand les hormones se normalisent.', 1, 2, 22)))

PTS.append(POINT(14, 'Pièges et questions d’examen',
 P('Les questions d’examen portent surtout sur le mécanisme, l’ordre des traitements de la crise et les toxicités des ATS. '
   'Chaque piège ci-dessous donne la bonne réponse attendue.', 1, 2, 22) +
 F('Pièges classiques et bonne réponse',
   TAB(['Piège', 'Bonne réponse'], [
    ['Prescrire un ATS dans une thyroïdite subaiguë', 'Faux : la fuite hormonale ne dépend pas de la synthèse ; il faut un bêtabloquant et un anti-inflammatoire.'],
    ['Passer au propylthiouracile après une agranulocytose au carbimazole', 'Faux : la réaction croisée l’interdit ; il faut un traitement définitif.'],
    ['Compter sur la NFS systématique pour prévenir l’agranulocytose', 'Faux : elle survient brutalement ; la consigne « fièvre ou angine → NFS le jour même » est essentielle.'],
    ['Donner l’iodure en premier dans la crise', 'Faux : l’iodure se donne au moins 1 h après l’ATS, sinon il alimente la synthèse.'],
    ['Traiter la fièvre de la crise par aspirine', 'Faux : l’aspirine augmente la T4 libre ; il faut du paracétamol.'],
    ['Attendre un taux hormonal très élevé pour parler de crise', 'Faux : la crise est clinique (BWPS ≥ 45 ou critères japonais).'],
    ['Conclure à une hyperthyroïdie devant une TSH basse au premier trimestre', 'Faux : l’hCG abaisse physiologiquement la TSH ; il faut la T4 libre et des références de grossesse.'],
    ['Adapter l’ATS sur la TSH au début', 'Faux : la TSH reste freinée des mois ; il faut adapter sur la T4 libre et la T3 libre.'],
    ['Diagnostiquer un Basedow chez un patient sous biotine avec TSH basse, T4 libre et TRAb élevés mais sans symptôme', 'Il faut arrêter la biotine au moins 48 h et redoser : l’interférence imite le Basedow.'],
    ['Faire une scintigraphie pendant la grossesse', 'Faux : elle est contre-indiquée ; il faut les TRAb et l’échographie.'],
    ['Donner l’iode radioactif à une orbitopathie active modérée à sévère', 'Faux : il l’aggrave ; il faut traiter l’orbite d’abord et préférer l’ATS ou la chirurgie.'],
    ['Traiter une thyrotoxicose à l’amiodarone de type 2 par ATS seul', 'Faux : c’est une thyroïdite ; il faut de la prednisone.'],
    ['Ponctionner un nodule chaud', 'Faux : un nodule hyperfonctionnel est presque toujours bénin ; la cytoponction n’est pas indiquée.'],
    ['Surveiller sans traiter une hyperthyroïdie infraclinique de grade 2 après 65 ans', 'Faux : l’ETA 2015 recommande de la traiter (risque de fibrillation atriale et de fracture).'],
    ['Utiliser le propylthiouracile en première intention chez l’enfant', 'Faux : il est hépatotoxique ; il faut le carbimazole.'],
    ['Contre-indiquer l’allaitement sous ATS', 'Faux : le carbimazole jusqu’à 20 mg/j reste compatible.'],
    ['Corriger massivement le potassium dans une paralysie périodique thyrotoxique', 'Faux : le potassium revient des cellules ; il faut un apport prudent et du propranolol.'],
    ['Croire que l’orbitopathie suit les hormones', 'Faux : elle évolue pour son compte et peut apparaître en euthyroïdie ou après iode radioactif.'],
    ['Cardiovertir une fibrillation atriale avant l’euthyroïdie', 'Faux : le rythme sinusal revient souvent avec l’euthyroïdie ; la cardioversion vient ensuite.'],
   ]))))

SOURCES = [
 (1, 'Kahaly GJ et al. 2018 European Thyroid Association Guideline for the Management of Graves’ Hyperthyroidism. Eur Thyroid J. 2018;7:167–186. Document consulté le 23 octobre 2026.'),
 (2, 'ETA, British Thyroid Association, Society for Endocrinology, Welsh Endocrine and Diabetes Society. Management of thyroid emergencies: thyroid storm. Consensus européen publié le 5 août 2026 ; ses posologies ne sont pas des posologies AIPS. Document consulté le 23 octobre 2026.'),
 (3, 'AIPS (Swissmedic). Néo-Mercazole®, carbimazole, autorisation 21037 ; information professionnelle d’août 2020. Document consulté le 23 octobre 2026.'),
 (4, 'AIPS (Swissmedic). Inderal®, propranolol, autorisation 31706 ; information professionnelle de janvier 2023. Document consulté le 23 octobre 2026.'),
 (5, 'AIPS (Swissmedic). Propycil® 50, propylthiouracile, autorisation 56300 ; information professionnelle de septembre 2024. Document consulté le 23 octobre 2026.'),
 (6, 'AIPS (Swissmedic). Esmolol OrPha®, autorisation 57413 ; information professionnelle de septembre 2013. Document consulté le 23 octobre 2026.'),
 (7, 'Collège des enseignants d’endocrinologie (SFE). Hyperthyroïdie. Document consulté le 23 octobre 2026.'),
 (8, 'Luzerner Kantonsspital. Freies T4, valeurs de référence adultes dépendantes de la méthode. Document consulté le 23 octobre 2026.'),
 (9, 'Luzerner Kantonsspital. Freies T3, valeurs de référence adultes dépendantes de la méthode. Document consulté le 23 octobre 2026.'),
 (10, 'Société suisse de chimie clinique, approuvée par la Société suisse d’endocrinologie et de diabétologie. Bilan thyroïdien initial : test réflexe. Octobre 2025. Document consulté le 23 octobre 2026.'),
 (11, 'Mooij CF et al. 2022 European Thyroid Association Guideline for the management of pediatric Graves’ disease. Eur Thyroid J. 2022. Document consulté le 23 octobre 2026.'),
 (12, 'Luzerner Kantonsspital. TSH, référence adulte 0,27–4,20 mUI/L dépendante de la méthode. Document consulté le 23 octobre 2026.'),
 (13, 'Centre hospitalier universitaire vaudois. Scintigraphie de la thyroïde, fiche de préparation. Document consulté le 23 octobre 2026.'),
 (14, 'Hôpitaux universitaires de Genève. Scintigraphies thyroïdiennes, traceurs et préparation. Document consulté le 23 octobre 2026.'),
 (15, 'University Hospitals Coventry and Warwickshire. Clinical Skills Workbook 2022–2023, examen de la thyroïde, des yeux et du cœur. Document consulté le 23 octobre 2026.'),
 (16, 'Collège des enseignants d’endocrinologie (SFE). Item 242, Hyperthyroïdie. Document consulté le 23 octobre 2026.'),
 (19, 'Fedlex. Loi fédérale sur l’assurance-maladie (LAMal), état au 1er juillet 2026, art. 25 al. 1 et 32. Document consulté le 23 octobre 2026.'),
 (20, 'Fedlex. Loi fédérale sur l’assurance-accidents (LAA), état au 1er janvier 2026, art. 6 al. 1 et 9. Document consulté le 23 octobre 2026.'),
 (21, 'Fedlex. Loi fédérale sur l’assurance-invalidité (LAI), état au 1er janvier 2026, art. 7, 8 al. 1 et 28. Document consulté le 23 octobre 2026.'),
 (22, 'Ross DS et al. 2016 American Thyroid Association Guidelines for Diagnosis and Management of Hyperthyroidism and Other Causes of Thyrotoxicosis. Thyroid. 2016;26:1343–1421. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (23, 'Biondi B et al. 2015 European Thyroid Association Guidelines on Diagnosis and Treatment of Endogenous Subclinical Hyperthyroidism. Eur Thyroid J. 2015;4:149–163. Référence ajoutée lors de l’audit.'),
 (24, 'Bartalena L et al. 2018 European Thyroid Association Guidelines for the Management of Amiodarone-Associated Thyroid Dysfunction. Eur Thyroid J. 2018;7:55–66. Référence ajoutée lors de l’audit.'),
 (25, 'Bartalena L et al. The 2021 European Group on Graves’ Orbitopathy (EUGOGO) Clinical Practice Guidelines for the Medical Management of Graves’ Orbitopathy. Eur J Endocrinol. 2021;185:G43–G67. Référence ajoutée lors de l’audit.'),
 (26, 'Alexander EK et al. 2017 Guidelines of the American Thyroid Association for the Diagnosis and Management of Thyroid Disease During Pregnancy and the Postpartum. Thyroid. 2017;27:315–389. Référence ajoutée lors de l’audit.'),
 (27, 'Akamizu T et al. Diagnostic criteria, clinical features, and incidence of thyroid storm based on nationwide surveys. Thyroid. 2012;22:661–679. Référence ajoutée lors de l’audit.'),
 (28, 'Burch HB, Wartofsky L. Life-threatening thyrotoxicosis: thyroid storm. Endocrinol Metab Clin North Am. 1993;22:263–277. Référence ajoutée lors de l’audit.'),
 (29, 'Russ G et al. European Thyroid Association Guidelines for Ultrasound Malignancy Risk Stratification of Thyroid Nodules in Adults: the EU-TIRADS. Eur Thyroid J. 2017;6:225–237. Référence ajoutée lors de l’audit.'),
 (30, 'Marcocci C et al. Selenium and the course of mild Graves’ orbitopathy. N Engl J Med. 2011;364:1920–1931. Référence ajoutée lors de l’audit.'),
 (31, 'Taylor PN et al. Global epidemiology of hyperthyroidism and hypothyroidism. Nat Rev Endocrinol. 2018;14:301–316. Référence ajoutée lors de l’audit.'),
 (32, 'Mourits MP et al. Clinical activity score as a guide in the management of patients with Graves’ ophthalmopathy. Clin Endocrinol. 1997;47:9–14. Référence ajoutée lors de l’audit.'),
 (33, 'U.S. Food and Drug Administration. Safety communication: biotin (vitamin B7) can interfere with laboratory tests, 2017, mise à jour 2019. Référence ajoutée lors de l’audit.'),
 (34, 'Rudd KE et al. Global, regional, and national sepsis incidence and mortality, 1990–2017. Lancet 2020;395:200–211. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (35, 'Lenders JWM et al. Pheochromocytoma and paraganglioma: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab 2014;99:1915–1942. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (36, 'de Jonge P et al. Cross-national epidemiology of panic disorder and panic attacks in the World Mental Health Surveys. Depress Anxiety 2016;33:1155–1177. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (37, 'The Menopause Society. The 2023 nonhormone therapy position statement. Menopause 2023;30:573–590. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
]

CSS = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'base.css')).read().strip()
def build(pts=None, suffixe='', titre_suite=''):
    pts = PTS if pts is None else pts
    import re as _re
    nums = [int(_re.search(r'id="dx6-p(\d+)"', x).group(1)) for x in pts]
    body = ''.join(pts)
    cites = {int(x) for x in _re.findall(r'#source-S(\d+)', body)}
    src = '\n'.join(f'<li id="source-S{n}">[S{n}] {t}</li>' for n, t in SOURCES if n in cites)   # seules les sources citées dans ce fichier
    html = ('<!DOCTYPE html>\n<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
      '<title>LOT 1 · G1 · Transpiration anormale · DX.6 Hyperthyroïdie · version AUDITÉE' + suffixe + '</title><style>' + CSS + '</style></head><body>\n'
      '<section class="limite" role="note" aria-label="Statut du fichier"><strong>Version AUDITÉE (pilote) du 24 octobre 2026.</strong> '
      'Cette version corrige la monographie DX.6 du LOT 1 (Appel B, V7, Partie 3, révision r2) après audit médical et linguistique ; elle n’est pas validée cliniquement par un médecin. '
      'Les posologies marquées « hors AIPS », c’est-à-dire absentes de l’information professionnelle suisse, proviennent de recommandations internationales et doivent être vérifiées avant toute prescription.</section>\n'
      '<header><h2>LOT 1 · G1 · Transpiration anormale · DX.6 Hyperthyroïdie et thyrotoxicose</h2><p>PROFILES 2023 · SSP G1 · LOT 1 · Appel B · V7 · version AUDITÉE</p></header><main>\n'
      '<nav aria-label="Navigation">' + ''.join(f'<a href="#dx6-p{i}">{i}</a>' for i in nums) + '<a href="#sources">Sources</a></nav>\n'
      '<details class="monographie" open><summary>DX.6 · Hyperthyroïdie et thyrotoxicose' + titre_suite + '</summary>\n' + ''.join(pts) + '</details>\n'
      '<section id="sources"><h2>Sources</h2><ol class="s">' + src + '</ol>'
      '<p class="s">Contenu produit par IA à partir des sources citées ; non validé cliniquement par un médecin.</p></section>\n'
      '</main>\n<!-- FIN_FICHIER -->\n</body></html>\n')
    return html

if __name__ == '__main__':
    base = sys.argv[1]
    for suf, pts, ts in [('_a', PTS[:8], ' (partie a : points 1 à 8)'), ('_b', PTS[8:], ' (partie b : points 9 à 14)')]:
        out = base.replace('.html', suf + '.html')
        open(out, 'w', encoding='utf-8').write(build(pts, ' · ' + suf[1:], ts))
        print(out, len(open(out, 'rb').read()), 'octets')
