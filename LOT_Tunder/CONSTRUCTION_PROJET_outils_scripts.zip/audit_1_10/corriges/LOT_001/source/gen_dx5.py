# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.5 · Ménopause et symptômes vasomoteurs (LOT 1, Appel B, Partie 2, r1 → audit du 24.10.2026)."""
import sys; sys.path.insert(0, '/workspace/audit_1_10/outils')
from gen_v7 import *
from src_P2 import SOURCES_ORIG
POINT = mkPOINT('dx5')
M = dict(pref='dx5', dx='DX.5', court='Ménopause', long='Ménopause et symptômes vasomoteurs', dossier='corriges/LOT_001',
         fichier='LOT_001_DX5_Menopause_symptomes_vasomoteurs_AUDITÉ.html', lot_titre='LOT 1 · G1 · Transpiration anormale',
         sous_titre='PROFILES 2023 · SSP G1 · LOT 1 · Appel B · V7 · version AUDITÉE',
         statut='Cette version corrige la monographie DX.5 du LOT 1 (Appel B, V7, Partie 2, révision r1) après audit médical et linguistique ; les doses proviennent des informations professionnelles suisses (AIPS).')
SVM = T('symptômes vasomoteurs (SVM)', 'Les symptômes vasomoteurs sont les bouffées de chaleur et les sueurs nocturnes : une sensation brutale de chaleur du haut du corps, avec rougeur et sueur, qui dure quelques minutes.')
KNDY = T('neurones KNDy', 'Les neurones KNDy (kisspeptine, neurokinine B, dynorphine) sont des neurones de l’hypothalamus qui règlent la pulsatilité des gonadotrophines et touchent le centre de la température ; sans œstrogènes, ils deviennent hyperactifs.')
IOP = T('insuffisance ovarienne prématurée (IOP)', 'L’insuffisance ovarienne prématurée est l’arrêt du fonctionnement ovarien avant 40 ans, avec aménorrhée et FSH élevée à deux reprises ; elle impose un traitement hormonal jusqu’à l’âge habituel de la ménopause.')
THM = T('traitement hormonal de la ménopause (THM)', 'Le traitement hormonal de la ménopause remplace l’estradiol ; chez la femme qui a encore son utérus, on y ajoute toujours un progestatif pour protéger l’endomètre.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('La ménopause est l’arrêt définitif des règles par épuisement des follicules ovariens ; on la date rétrospectivement après 12 mois sans règles. '
   'La périménopause (transition ménopausique) est la période de cycles irréguliers qui la précède, et la postménopause commence après les 12 mois. '
   f'Les {SVM} en sont le symptôme le plus fréquent et la principale cause de sueurs chez la femme de 45 à 55 ans.', 25, 26) +
 F('Terminologie',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Ménopause naturelle', '12 mois consécutifs sans règles, sans autre cause, vers 51 ans en moyenne', 'Aménorrhée sous contraception ou après hystérectomie'],
    ['Ménopause anticipée', 'Ménopause entre 40 et moins de 45 ans', 'Insuffisance ovarienne prématurée'],
    [f'{IOP}', 'Arrêt ovarien avant 40 ans', 'Ménopause anticipée (après 40 ans)'],
    ['Ménopause chirurgicale ou iatrogène', 'Ablation des deux ovaires, chimiothérapie, traitement endocrinien du cancer du sein', 'Hystérectomie seule (ovaires conservés)'],
    ['Syndrome génito-urinaire de la ménopause', 'Sécheresse vaginale, dyspareunie, urgences mictionnelles par carence œstrogénique locale', 'Infection urinaire ou vaginale'],
   ]) + P('Le diagnostic de ménopause est clinique ; un dosage hormonal ne sert que dans des situations précises (âge < 45 ans, hystérectomie, contraception).', 25, 26))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, l’âge moyen de la ménopause est d’environ 51 ans, et l’avis d’experts de la SSGO estime la ménopause anticipée à 5–10 % et l’IOP à environ 1 % des femmes. '
   'En Europe, l’ESE 2025 décrit une IOP de 1–3 % selon les populations et des bouffées chez jusqu’à 80 % des femmes en transition. '
   'Les symptômes durent en moyenne 7,4 ans, plus longtemps quand ils commencent tôt, et le tabac, l’obésité et l’origine afro-américaine en sont des facteurs de risque.', 25, 26, 27, 39, 40) +
 F('Chiffres, terrain et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Âge moyen de la ménopause (Suisse)', '≈ 51 ans', 'HUG, brochure institutionnelle'],
    ['Ménopause anticipée (40 à < 45 ans)', '5–10 %', 'Avis d’experts SSGO 90'],
    ['Insuffisance ovarienne prématurée (< 40 ans)', '≈ 1 % (SSGO) ; 1–3 % (ESE)', 'Populations de référence différentes'],
    ['Bouffées pendant la transition', 'Jusqu’à 80 % des femmes', 'The Menopause Society 2023'],
    ['Durée médiane des bouffées', '7,4 ans', 'Cohorte SWAN, États-Unis'],
    ['Incidence par canton', 'Non disponible', 'Aucune source suisse trouvée'],
   ]) + P('Le pronostic vital n’est pas en jeu, mais la ménopause précoce non traitée augmente la mortalité cardiovasculaire et le risque d’ostéoporose ; c’est pourquoi l’âge de survenue est le premier facteur pronostique.', 25, 26))))
PTS.append(POINT(3, 'Physiopathologie',
 P('L’ovaire épuise son stock de follicules, si bien que l’estradiol et l’inhibine chutent et que l’hypophyse augmente la FSH par rétrocontrôle. '
   f'Le manque d’œstrogènes rend hyperactifs les {KNDY} de l’hypothalamus, qui rétrécissent la zone de confort thermique. '
   'Une petite hausse de température déclenche alors une vasodilatation cutanée et une sueur, ce qui explique la bouffée. '
   'Le traitement agit sur ce mécanisme : l’estradiol restaure le signal, et les antagonistes des récepteurs de la neurokinine bloquent les neurones KNDy.', 26, 30, 31) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les ovaires contiennent à la naissance un stock fixe de follicules ; l’hypothalamus et l’hypophyse les commandent par la GnRH, la FSH et la LH (hormone lutéinisante).'],
    ['Physiologie', 'Pourquoi le cycle tient : les follicules produisent estradiol et inhibine, qui freinent la FSH ; l’estradiol agit aussi sur le thermostat de l’hypothalamus.'],
    ['Physiopathologie', 'Quand le stock est épuisé, l’estradiol tombe, la FSH monte, et les neurones KNDy s’emballent : le thermostat devient trop sensible.'],
    ['Clinique', 'D’où les bouffées et les sueurs nocturnes, les troubles du sommeil, puis la sécheresse vaginale et, à long terme, la perte osseuse.'],
    ['Examens', 'Après 45 ans, la clinique suffit ; la FSH ne sert qu’avant 45 ans ou quand les règles ne sont pas interprétables, parce qu’elle fluctue beaucoup en périménopause.'],
    ['Traitement', 'On remplace l’estradiol (patch), on protège l’utérus par la progestérone, ou on bloque directement les neurones KNDy (fézolinétant, élinzanétant).'],
   ]), 25, 26, 30) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme (lésion fonctionnelle)', 'Exploration', 'Cible thérapeutique'], [
    ['Épuisement folliculaire', 'Anamnèse des cycles ; FSH si âge < 45 ans', 'Estradiol transdermique (Estradot®)'],
    ['Hyperactivité des neurones KNDy', 'Fréquence des bouffées (journal)', 'Fézolinétant (Veoza®), élinzanétant (Lynkuet®)'],
    ['Prolifération de l’endomètre sous estradiol seul', 'Saignement anormal, échographie endovaginale', 'Progestérone micronisée (Utrogestan®)'],
    ['Perte osseuse', 'Ostéodensitométrie (DXA) selon le risque', 'THM, calcium, vitamine D, activité physique'],
    ['Atrophie génito-urinaire', 'Examen gynécologique', 'Œstrogène vaginal local'],
   ]) + P('Cette chaîne explique pourquoi un antidépresseur ou un bêtabloquant ne corrige pas la cause et pourquoi le progestatif est indispensable si l’utérus est en place.', 25, 26))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Chez une femme de plus de 45 ans aux cycles irréguliers, des bouffées typiques suffisent au diagnostic, sans dosage hormonal. '
   'Une présentation atypique (avant 40 ans, fièvre, perte de poids, palpitations, crises hypertensives, sueurs sans bouffées) fait rechercher une autre cause. '
   'Le médecin écarte enfin une grossesse tant que la ménopause n’est pas confirmée.', 25, 26) +
 F('Diagnostic différentiel des sueurs et bouffées (fréquence sourcée en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Symptômes vasomoteurs de la ménopause' + PR('jusqu’à 80 % des femmes en transition', 39), 'Âge 45–55 ans, cycles irréguliers, bouffées brèves', 'Clinique ; FSH seulement avant 45 ans'],
    ['Insuffisance ovarienne prématurée' + PR('≈ 1 % des femmes', 25), 'Âge < 40 ans, aménorrhée', 'FSH élevée à deux reprises, βhCG négative'],
    ['Hyperthyroïdie' + PR('≈ 0,75 % (Europe)', 33), 'Perte de poids, palpitations, tremblement', 'TSH'],
    ['Diabète traité (hypoglycémies)' + PR('≈ 5 % des adultes (Suisse)', 34), 'Sueurs avec faim et confusion, traitement hypoglycémiant', 'Glycémie'],
    ['Sueurs médicamenteuses (antidépresseurs)' + PR('4–22 % des traités', 37), 'Début lié au traitement', 'Anamnèse médicamenteuse'],
    ['Trouble panique' + PR('≈ 1,7 % sur la vie', 41), 'Peur intense, palpitations, sans lien avec la chaleur', 'Clinique, TSH normale'],
    ['Tuberculose' + PR('≈ 5 / 100 000 par an (Suisse)', 35), 'Fièvre, sueurs nocturnes, toux', 'Radiographie thoracique'],
    ['Lymphome non hodgkinien' + PR('≈ 20 / 100 000 par an (Suisse)', 36), 'Sueurs nocturnes, perte de poids, adénopathies', 'Hémogramme, biopsie'],
    ['Phéochromocytome' + PR('≈ 0,8 / 100 000 par an', 38), 'Crises : céphalées, palpitations, hypertension', 'Métanéphrines'],
   ]) + P('Les fréquences décrivent une prévalence ou une incidence annuelle, comme indiqué ; elles ne sont pas des probabilités devant une patiente donnée. Devant des bouffées typiques d’une femme de 50 ans, la ménopause reste l’hypothèse de loin la plus probable.', 25, 26))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien date les dernières règles, décrit les bouffées (fréquence, nuit, retentissement) et recherche sommeil, humeur, sécheresse vaginale, troubles urinaires et antécédents qui changent le traitement (cancer du sein, thrombose, foie).', 25, 26, 28) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Quand avez-vous eu vos dernières règles ?', 'La ménopause se date après 12 mois sans règles.', 'Elle sépare périménopause et postménopause.'],
    ['Combien de bouffées par jour, et la nuit ?', 'La fréquence mesure la sévérité.', 'Elle fixe l’objectif et l’indication des traitements.'],
    ['Avez-vous eu un cancer du sein, une thrombose ou un AVC ?', 'L’estradiol est contre-indiqué dans ces situations.', 'Elle oriente vers un traitement non hormonal.'],
    ['Avez-vous encore votre utérus ?', 'L’estradiol seul fait proliférer l’endomètre.', 'Elle impose ou non un progestatif.'],
    ['Avez-vous des saignements après la ménopause ?', 'Un saignement post-ménopausique peut révéler un cancer de l’endomètre.', 'Il impose une exploration avant tout THM.'],
    ['Quels médicaments prenez-vous ?', 'Antidépresseurs, tamoxifène, inhibiteurs du CYP1A2 ou du CYP3A4.', 'Ils changent le choix entre fézolinétant et élinzanétant.'],
   ])) +
 U('<b>Drapeaux rouges et urgence</b> : sous THM, une douleur thoracique, une dyspnée brutale ou un déficit neurologique imposent l’appel immédiat du 144. Imposent un bilan rapide : saignement après la ménopause, aménorrhée avant 40 ans, fièvre ou perte de poids, crises hypertensives, jaunisse sous fézolinétant, douleur et gonflement d’un mollet.', 25, 28, 30)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure la pression artérielle, le poids, l’IMC (indice de masse corporelle) et le tour de taille, parce que le risque cardiovasculaire guide le choix du traitement. '
   'Il palpe la thyroïde et les seins et réalise un examen gynécologique si des symptômes génito-urinaires ou un saignement sont présents. '
   'L’examen est souvent normal : il ne confirme pas la ménopause mais cherche une contre-indication ou un autre diagnostic.', 25, 26) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Pression artérielle aux deux bras', '< 140/90 mmHg', 'Hypertension : risque cardiovasculaire à intégrer ; crises : phéochromocytome'],
    ['Poids, IMC, tour de taille', 'IMC 18,5–25 kg/m²', 'Obésité : bouffées plus fréquentes, risque de thrombose'],
    ['Palpation thyroïdienne', 'Pas de goitre ni de nodule', 'Goitre, tremblement : hyperthyroïdie'],
    ['Examen des seins', 'Pas de masse', 'Masse : imagerie avant tout THM'],
    ['Examen vulvo-vaginal', 'Muqueuse rosée et humide', 'Muqueuse pâle, fine et sèche : syndrome génito-urinaire'],
   ]) + P('Aucun signe physique n’a de sensibilité ou de spécificité validée pour la ménopause.', 26))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Le syndrome vasomoteur réunit des signes fonctionnels (bouffées, sueurs nocturnes, palpitations, réveils), et le syndrome génito-urinaire réunit sécheresse vaginale, dyspareunie et urgences mictionnelles. '
   'Les signes physiques sont rares : rougeur et sueur pendant la bouffée, muqueuse vaginale pâle et fine, ce qui explique pourquoi l’examen est souvent normal.', 25, 26) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    ['Bouffée de chaleur', 'Chaleur brutale du visage et du thorax, rougeur, 1 à 5 minutes', 'Vasodilatation déclenchée par l’hypothalamus'],
    ['Sueurs nocturnes', 'Réveil trempé, parfois changement de linge', 'Même mécanisme pendant le sommeil'],
    ['Palpitations', 'Cœur rapide pendant la bouffée', 'Activation sympathique'],
    ['Sécheresse vaginale, dyspareunie', 'Douleur aux rapports', 'Atrophie de la muqueuse sans œstrogènes'],
    ['Urgences mictionnelles, infections récidivantes', 'Besoin pressant, cystites', 'Atrophie urétrale et changement de la flore'],
   ]) + P('Termes : ' + T('dyspareunie', 'La dyspareunie est une douleur pendant les rapports sexuels ; à la ménopause, elle vient surtout de la sécheresse et de l’amincissement de la muqueuse vaginale.') + ', '
          + T('atrophie vulvo-vaginale', 'L’atrophie vulvo-vaginale est l’amincissement et l’assèchement de la muqueuse par manque d’œstrogènes ; elle se traite par un œstrogène vaginal local.') + ', '
          + T('syndrome génito-urinaire de la ménopause', 'Ce syndrome regroupe les signes vulvo-vaginaux et urinaires liés à la carence œstrogénique ; il ne régresse pas spontanément.') + ', '
          + T('postménopause', 'La postménopause commence 12 mois après les dernières règles et dure le reste de la vie.') + ', '
          + T('périménopause', 'La périménopause couvre la transition aux cycles irréguliers et l’année qui suit les dernières règles.') + '.', 25, 26))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le diagnostic est clinique : 12 mois sans règles chez une femme de plus de 45 ans, sans autre cause. '
   'Les critères STRAW+10 (2012) définissent la transition tardive par une aménorrhée d’au moins 60 jours et une FSH > 25 UI/L, et l’ESE 2025 ne recommande pas de dosage après 45 ans ; une FSH isolée ne suffit pas à poser le diagnostic. '
   'Avant 40 ans, l’IOP se pose sur une aménorrhée de 4 mois et une FSH > 25 UI/L (25 mU/mL) à deux reprises.', 25, 26, 42) +
 F('Stades STRAW+10 et seuils',
   TAB(['Stade', 'Critère', 'Seuil'], [
    ['Transition précoce', 'Durée des cycles qui varie de ≥ 7 jours', 'FSH variable'],
    ['Transition tardive', 'Aménorrhée ≥ 60 jours', 'FSH > 25 UI/L'],
    ['Ménopause', '12 mois sans règles', 'Diagnostic rétrospectif'],
    ['IOP (ESE)', 'Aménorrhée ≥ 4 mois avant 40 ans', 'FSH > 25 UI/L à 2 reprises, à ≥ 4 semaines'],
   ]) + P('Ces seuils supposent l’absence de contraception hormonale ; après hystérectomie, seuls les symptômes et, avant 45 ans, la FSH guident le diagnostic.', 25, 26, 42))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Diagnostic clinique (12 mois sans règles)', 'Gold standard : la référence reste clinique', 'Aucune sensibilité ni spécificité chiffrée', 'Inapplicable après hystérectomie ou sous contraception'],
    ['FSH', 'Insuffisance ovarienne si élevée', 'Sensibilité faible en périménopause car la FSH fluctue', 'Ne pas l’utiliser après 45 ans'],
    ['βhCG', 'Exclut une grossesse', 'Sensibilité et spécificité élevées', 'Obligatoire avant 12 mois d’aménorrhée'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Aucun examen après 45 ans si le tableau est typique', 'ESE 2025'],
    ['Première (avant 45 ans)', 'FSH, βhCG, TSH, prolactine', 'Aménorrhée ou bouffées précoces'],
    ['Seconde (cause secondaire)', 'TSH, glycémie, hémogramme, métanéphrines', 'Présentation atypique'],
    ['Avant traitement', 'Bilan lipidique, glycémie, mammographie selon le dépistage', 'Évaluation du risque'],
    ['Avant fézolinétant', 'ALAT, ASAT, bilirubine', 'AIPS Veoza®'],
    ['Selon le risque osseux', 'Ostéodensitométrie (DXA)', 'Facteurs de risque de fracture'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La <b>FSH</b> se dose entre le 2e et le 5e jour du cycle ou après plus de 40 jours d’aménorrhée, hors contraception hormonale.',
       'La <b>βhCG</b> se demande avant tout traitement tant que la ménopause n’est pas confirmée.',
       'Les <b>tests hépatiques</b> précèdent le fézolinétant, puis se répètent chaque mois pendant 3 mois.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['FSH positive (élevée)', '> 25 UI/L', 'Insuffisance ovarienne', 'Avant 40 ans : contrôle à ≥ 4 semaines'],
    ['FSH négative (normale) en périménopause', '< 25 UI/L', 'N’exclut pas la transition', 'Se fier à la clinique'],
    ['FSH limite', 'Proche de 25 UI/L', 'Fluctuation', 'Répéter ou ne pas doser après 45 ans'],
    ['TSH basse', '< 0,4 mU/L', 'Hyperthyroïdie', 'Bilan thyroïdien'],
    ['Transaminases > 2× LSN (limite supérieure de la normale)', 'Avant fézolinétant', 'Contre-indication au début', 'Autre traitement'],
    ['Résultat discordant (FSH élevée, règles régulières)', '—', 'Prélèvement mal daté', 'Reprendre la date du cycle'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse possible', 'βhCG avant tout traitement'],
    ['Après hystérectomie', 'Diagnostic sur les symptômes ; FSH seulement avant 45 ans'],
    ['Enfant ou adolescente (aménorrhée)', 'Bilan d’aménorrhée, pas un bilan de ménopause'],
    ['Allergie à l’iode', 'Aucun produit de contraste iodé n’est nécessaire au diagnostic'],
    ['DFGe < 30 mL/min/1,73 m²', 'Fézolinétant contre-indiqué ; élinzanétant non recommandé'],
    ['Stimulateur cardiaque, IRM', 'Aucun examen d’imagerie nécessaire au diagnostic'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Après 45 ans, un tableau typique ne demande aucun examen, parce que la FSH fluctue et ne change pas la conduite. '
   'Avant 45 ans, la FSH, la βhCG, la TSH et la prolactine cherchent une IOP ou une autre cause d’aménorrhée. '
   'Avant un traitement, le bilan évalue le risque (lipides, glycémie, foie avant fézolinétant), et la mammographie suit le dépistage habituel.', 25, 26, 30) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si la patiente a moins de 40 ans, alors le médecin explore une IOP et traite par hormones jusqu’à l’âge habituel de la ménopause. '
   'Si les bouffées gênent une femme sans contre-indication, alors il propose un THM individualisé ; si l’estradiol est contre-indiqué, il propose un antagoniste de la neurokinine. '
   'Il réévalue chaque année la dose, la durée et le bénéfice-risque.', 25, 26, 30, 31) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Âge < 40 ans et aménorrhée', 'FSH à 2 reprises, βhCG ; THM jusqu’à ≈ 51 ans', 'Suivi spécialisé'],
    ['Bouffées gênantes, pas de contre-indication, < 60 ans ou < 10 ans après la ménopause', 'Estradiol transdermique + progestérone si utérus', 'À 3 mois, puis chaque année'],
    ['Cancer du sein, thrombose ou AVC', 'Fézolinétant ou élinzanétant ; thérapie cognitivo-comportementale', 'Tests hépatiques (fézolinétant)'],
    ['Seulement des symptômes génito-urinaires', 'Œstrogène vaginal local', 'À 3 mois'],
    ['Saignement post-ménopausique', 'Échographie endovaginale, avis gynécologique', 'Avant tout THM'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Dose et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Estradiol, Estradot® patch (œstrogène transdermique), autorisation 55976', '25, 37,5, 50, 75 ou 100 µg/24 h, patch changé tous les 3–4 jours ; dose minimale efficace, augmentée après 3 mois si nécessaire ; demi-vie ≈ 1 h', 'Contre-indications : cancer du sein, tumeur hormonodépendante, saignement inexpliqué, thrombose veineuse ou artérielle, maladie hépatique grave (Child-Pugh C)'],
   ['Progestérone micronisée, Utrogestan® (progestatif)', '200 mg par voie orale au coucher, 12–14 jours par cycle, avec l’estradiol si l’utérus est en place ; demi-vie ≈ 6 h', 'Somnolence (prise le soir) ; métabolisme par le CYP3A4'],
   ['Fézolinétant, Veoza® (antagoniste du récepteur NK3), autorisation 69232', '45 mg 1×/j ; réévaluer après 12 mois ; demi-vie 9,6 h', 'Contre-indiqué avec tout inhibiteur du CYP1A2, si Child-Pugh B ou C ou DFGe < 30 ; ne pas débuter si ALAT ou ASAT > 2× LSN ; arrêt si > 5× LSN, ou > 3× LSN avec bilirubine > 2× LSN'],
   ['Élinzanétant, Lynkuet® (antagoniste NK1 et NK3), autorisation 69917', '120 mg (2 × 60 mg) au coucher ; 60 mg avec un inhibiteur modéré du CYP3A4 ; demi-vie ≈ 45 h', 'Inhibiteurs puissants du CYP3A4 et Child-Pugh C contre-indiqués ; DFGe < 30 non recommandé ; contraception pendant le traitement et 2 semaines après ; risque de convulsions'],
  ]) + P('Les doses sont celles des AIPS suisses ; les traitements non hormonaux hors indication (ISRS, IRSN, gabapentine) relèvent d’une décision spécialisée et ne sont pas chiffrés ici. La paroxétine et la fluoxétine sont à éviter sous tamoxifène.', 28, 29, 30, 31, 39))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge soulage les symptômes qui gênent la patiente, parce que la ménopause n’est pas une maladie à traiter chez toutes. '
   'Le THM individualisé est le traitement le plus efficace des bouffées selon la SSGO, et les antagonistes de la neurokinine conviennent si l’estradiol est contre-indiqué. '
   'Le suivi réévalue chaque année le bénéfice, les risques et la dose.', 25, 26) +
 F('11.A Buts : formes non compliquées et compliquées',
   P('Forme compliquée sous traitement (thrombose, AVC, atteinte hépatique) : c’est une urgence, avec arrêt immédiat du traitement et appel du 144 dans la première heure si un déficit ou une dyspnée apparaît.', 28, 30) +
   P(f'Dans la forme non compliquée, il n’y a pas d’urgence ; le but est de réduire les bouffées à un niveau tolérable et de restaurer le sommeil, mesurés par un journal des bouffées. À long terme, le {THM} vise aussi la protection osseuse et, dans l’IOP, la prévention cardiovasculaire jusqu’à l’âge habituel de la ménopause.', 25, 26)) +
 F('11.B Moyens',
   F('Mesures générales et ordre (forme non compliquée, suivi ambulatoire)',
     OL(['Information sur la nature transitoire des bouffées ; vêtements en couches, chambre fraîche, arrêt du tabac, activité physique.',
         'Thérapie cognitivo-comportementale (TCC), qui réduit la détresse liée aux bouffées (ESE).',
         'THM individualisé : estradiol transdermique et, si l’utérus est en place, progestérone micronisée.',
         'Estradiol contre-indiqué ou refusé : fézolinétant ou élinzanétant.',
         'Symptômes génito-urinaires isolés : œstrogène vaginal local.']), 25, 26) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal (art. 25 et 32) prend en charge les prestations efficaces, appropriées et économiques ; le remboursement de chaque spécialité suit la liste des spécialités, à vérifier.',
         'La LAA n’intervient pas (processus physiologique) ; la LAI (art. 7, 8 et 28) ne concerne pas la ménopause habituelle.',
         'Les bouffées et l’insomnie peuvent gêner le travail professionnel : un poste aéré et des horaires adaptés aident, et un arrêt de travail est exceptionnel.',
         'La conduite automobile reste possible ; la somnolence sous progestérone le soir justifie une prise au coucher.']), 2, 3, 29) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Antécédent de cancer du sein', 'Estradiol contre-indiqué ; élinzanétant (indication liée au traitement endocrinien adjuvant) ou fézolinétant ; avis oncologique'],
      ['Antécédent de thrombose', 'Estradot® contre-indiqué ; traitement non hormonal'],
      ['IOP', 'THM jusqu’à ≈ 51 ans, à dose suffisante'],
      ['Insuffisance hépatique', 'Fézolinétant contre-indiqué si Child-Pugh B ou C ; estradiol contre-indiqué si maladie grave'],
      ['Insuffisance rénale', 'Fézolinétant contre-indiqué si DFGe < 30 mL/min/1,73 m² ; élinzanétant non recommandé'],
      ['Grossesse et allaitement', 'THM et antagonistes de la neurokinine non indiqués ; contraception pendant l’élinzanétant et 2 semaines après'],
      ['Enfant et adolescente', 'Non concernées ; une aménorrhée demande un bilan spécifique'],
      ['Femme âgée (> 60 ans ou > 10 ans après la ménopause)', 'Bénéfice-risque du THM moins favorable ; décision individualisée'],
     ]), 25, 28, 30, 31), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Bouffées (journal), sommeil', 'À 3 mois, puis chaque année', 'Pas d’amélioration : ajuster la dose ou changer de classe'],
    ['Saignement sous THM', 'À chaque visite', 'Saignement anormal : échographie endovaginale'],
    ['ALAT, ASAT, bilirubine sous fézolinétant', 'Chaque mois pendant 3 mois', '> 5× LSN, ou > 3× LSN avec bilirubine > 2× LSN : arrêt'],
    ['Pression artérielle, signes de thrombose', 'Chaque année', 'Thrombose : arrêt de l’estradiol'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['La patiente connaît les signes qui imposent une consultation (saignement, jaunisse, douleur de mollet).', 'Les tests hépatiques sont planifiés si elle prend du fézolinétant.', 'La réévaluation annuelle est fixée.'])) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Les bouffées diminuent avec le temps chez la plupart des femmes, mais peuvent durer plus de 10 ans ; le syndrome génito-urinaire, lui, persiste sans traitement. La recherche 2026 évalue les antagonistes de la neurokinine au long cours, dont la sécurité hépatique du fézolinétant suivie par le plan de gestion des risques suisse.', 26, 32, 40))))
PTS.append(POINT(12, 'Prévention',
 P('Aucune prévention primaire n’empêche la ménopause, mais l’arrêt du tabac et le contrôle du poids réduisent les bouffées. '
   'La prévention secondaire repère tôt l’IOP et la ménopause précoce, qui exposent à l’ostéoporose et aux maladies cardiovasculaires. '
   'La prévention tertiaire suit en Suisse les recommandations de la SSGO : dépistage osseux selon le risque, activité physique, calcium, vitamine D et réévaluation du THM.', 25, 26) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Arrêt du tabac, activité physique, poids'],
    ['Secondaire', 'Diagnostic de l’IOP avant 40 ans ; ostéodensitométrie selon le risque'],
    ['Tertiaire', 'THM dans l’IOP, prévention des fractures, traitement local du syndrome génito-urinaire'],
   ]))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin diagnostique la ménopause cliniquement après 12 mois sans règles, sans dosage après 45 ans. '
   'Il recherche une IOP avant 40 ans et une autre cause si la présentation est atypique. '
   'Il propose un THM individualisé, avec progestatif si l’utérus est en place, après avoir cherché les contre-indications. '
   'Il choisit un antagoniste de la neurokinine si l’estradiol est contre-indiqué, en surveillant le foie sous fézolinétant. '
   'Il réévalue le traitement chaque année.', 25, 26, 28, 30)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Doser la FSH pour confirmer la ménopause à 52 ans.', 'Inutile après 45 ans : le diagnostic est clinique.'],
  ['Prescrire l’estradiol seul chez une femme non hystérectomisée.', 'Il faut ajouter un progestatif pour protéger l’endomètre.'],
  ['La voie transdermique lève la contre-indication après thrombose.', 'Non : Estradot® reste contre-indiqué après une thrombose.'],
  ['Le fézolinétant ne demande aucune surveillance.', 'Tests hépatiques chaque mois pendant 3 mois.'],
  ['Associer fézolinétant et fluvoxamine.', 'Contre-indiqué : la fluvoxamine inhibe le CYP1A2.'],
  ['Une IOP à 35 ans se traite comme une ménopause habituelle, sans hormones.', 'Non : THM jusqu’à l’âge habituel de la ménopause.'],
  ['Un saignement post-ménopausique est banal sous THM.', 'Il impose une exploration de l’endomètre.'],
 ]) + P('Ces pièges reprennent l’avis SSGO 90, l’ESE 2025 et les AIPS.', 25, 26, 28, 30)))
SOURCES = sorted(SOURCES_ORIG.items()) + [
 (33, 'Garmendia Madariaga A, Santos Palacios S, Guillén-Grima F, Galofré JC. The incidence and prevalence of thyroid dysfunction in Europe: a meta-analysis. J Clin Endocrinol Metab 2014;99:923–931. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (34, 'Office fédéral de la statistique (OFS). Enquête suisse sur la santé 2022 : diabète. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (35, 'Office fédéral de la santé publique (OFSP). La tuberculose en Suisse : situation épidémiologique (rapport annuel). Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (36, 'OFS, NICER, Registre du cancer de l’enfant. Rapport suisse sur le cancer 2021 : lymphomes. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (37, 'Marcy TR, Britton ML. Antidepressant-induced sweating. Ann Pharmacother 2005;39:748–752. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (38, 'Lenders JWM et al. Pheochromocytoma and paraganglioma: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab 2014;99:1915–1942. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (39, 'The Menopause Society. The 2023 nonhormone therapy position statement. Menopause 2023;30:573–590. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (40, 'Avis NE et al. Duration of menopausal vasomotor symptoms over the menopause transition (SWAN). JAMA Intern Med 2015;175:531–539. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (41, 'de Jonge P et al. Cross-national epidemiology of panic disorder and panic attacks in the World Mental Health Surveys. Depress Anxiety 2016;33:1155–1177. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (42, 'Harlow SD et al. Executive summary of the Stages of Reproductive Aging Workshop + 10 (STRAW+10). Menopause 2012;19:387–395. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
]
CTX = {'_prefixe': 'Dans la ménopause',
 'gonado': 'La FSH > 25 UI/L à deux reprises avant 40 ans confirme une IOP ; après 45 ans, elle n’est pas utile.',
 'hcg': 'La βhCG exclut une grossesse tant que 12 mois d’aménorrhée ne sont pas atteints.',
 'tsh': 'Une TSH basse oriente vers une hyperthyroïdie, qui imite les bouffées.',
 'prl': 'La prolactine se dose devant une aménorrhée avant 45 ans.',
 'gly': 'La glycémie recherche une hypoglycémie ou un diabète devant des sueurs atypiques.',
 'lip': 'Le bilan lipidique évalue le risque cardiovasculaire avant un THM.',
 'hep': 'Les tests hépatiques précèdent le fézolinétant puis se répètent chaque mois pendant 3 mois.',
 'creat': 'Le DFGe < 30 mL/min/1,73 m² contre-indique le fézolinétant.',
 'dxa': 'L’ostéodensitométrie évalue le risque de fracture après une ménopause précoce ou des facteurs de risque.',
 'mammo': 'La mammographie suit le dépistage habituel avant et pendant un THM.',
 'meta': 'Les métanéphrines se dosent si les sueurs surviennent en crises hypertensives.',
 'nfs': 'L’hémogramme cherche une hémopathie si les sueurs nocturnes s’accompagnent de signes généraux.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
