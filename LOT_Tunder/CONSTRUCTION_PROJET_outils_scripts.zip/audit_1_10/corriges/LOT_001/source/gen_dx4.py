# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.4 · Hyperhidrose focale primaire (LOT 1, Appel B, Partie 2, r1 → audit du 24.10.2026)."""
import sys; sys.path.insert(0, '/workspace/audit_1_10/outils')
from gen_v7 import *
from src_P2 import SOURCES_ORIG
POINT = mkPOINT('dx4')
M = dict(pref='dx4', dx='DX.4', court='Hyperhidrose', long='Hyperhidrose focale primaire', dossier='corriges/LOT_001',
         fichier='LOT_001_DX4_Hyperhidrose_focale_primaire_AUDITÉ.html', lot_titre='LOT 1 · G1 · Transpiration anormale',
         sous_titre='PROFILES 2023 · SSP G1 · LOT 1 · Appel B · V7 · version AUDITÉE',
         statut='Cette version corrige la monographie DX.4 du LOT 1 (Appel B, V7, Partie 2, révision r1) après audit médical et linguistique ; les doses proviennent des informations professionnelles suisses (AIPS).')
ECC = T('glande eccrine', 'La glande eccrine est la glande sudoripare répartie sur tout le corps, très dense aux paumes, aux plantes et aux aisselles ; elle produit une sueur aqueuse sous commande sympathique cholinergique.')
COMP = T('sudation compensatrice', 'La sudation compensatrice est une augmentation de la sueur dans d’autres territoires (dos, abdomen, cuisses) après une sympathectomie ; elle peut être plus gênante que l’hyperhidrose initiale.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('L’hyperhidrose est une sudation qui dépasse les besoins de la thermorégulation et altère les activités ou la qualité de vie. '
   'La forme focale primaire touche de façon bilatérale et symétrique les aisselles, les paumes, les plantes ou la région craniofaciale, sans maladie, médicament ou autre cause identifiée. '
   'Son diagnostic est clinique et se rouvre si le tableau devient atypique.', 20, 21) +
 F('Terminologie',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Hyperhidrose focale primaire', 'Sudation excessive localisée, idiopathique, à début précoce', 'Hyperhidrose secondaire, souvent généralisée ou nocturne'],
    ['Hyperhidrose secondaire', 'Sudation due à une maladie (hyperthyroïdie, infection, lymphome) ou à un médicament', 'Forme primaire'],
    ['Bromhidrose', 'Odeur désagréable liée à la transformation bactérienne des sécrétions', 'Excès de quantité de sueur'],
    ['Anhidrose', 'Absence de sudation dans une zone', 'Objectif thérapeutique : supprimer toute sueur n’en est pas un'],
    ['Antitranspirant', 'Produit qui réduit la sécrétion (sels d’aluminium)', 'Déodorant, qui ne masque que l’odeur'],
   ]) + P(f'La sueur de la forme primaire provient de la {ECC} et non de glandes apocrines, qui produisent surtout l’odeur.', 20, 21))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, l’Hôpital universitaire de Zurich estime que 2–4 % de la population est concernée, et les HUG évoquent environ 3 %. '
   'En Europe, la ligne directrice allemande AWMF 2023 décrit une prévalence de même ordre, et les deux sexes sont touchés. '
   'Le début se situe souvent entre 6 et 16 ans, avec une histoire familiale fréquente, alors qu’un début tardif fait rechercher une cause secondaire.', 18, 19, 20) +
 F('Chiffres, terrain et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Prévalence suisse estimée', '2–4 % (USZ) ; environ 3 % (HUG)', 'Estimations hospitalières, pas une enquête nationale'],
    ['Âge de début', 'Souvent 6–16 ans ; mains parfois avant la puberté', 'Repère, pas un critère d’exclusion'],
    ['Histoire familiale', 'Fréquente', 'Composante héréditaire sans risque chiffré'],
    ['Incidence suisse, répartition cantonale', 'Non disponibles', 'Aucune source suisse trouvée'],
   ]) + P('L’évolution est chronique, parfois atténuée à l’âge adulte ; la gêne sociale et professionnelle justifie un traitement même sans danger vital. Le pronostic vital n’est pas engagé (aucune mortalité propre), et le pronostic fonctionnel dépend de la sévérité ; cette atténuation possible compte avant un geste irréversible.', 18, 20))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Dans la forme primaire, les glandes eccrines sont surstimulées sans augmentation démontrée de leur nombre ou de leur taille. '
   'Leur commande est sympathique, mais la terminaison libère de l’acétylcholine sur des récepteurs muscariniques de la glande. '
   'Chaque traitement agit sur un maillon : les sels d’aluminium obstruent le canal, le glycopyrronium bloque le récepteur, la toxine botulique empêche la libération d’acétylcholine et la sympathectomie interrompt la commande.', 20, 21, 22, 23) +
F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les glandes eccrines (2 à 4 millions) sont très denses aux paumes, aux plantes et aux aisselles ; elles s’ouvrent à la peau par un canal.'],
    ['Physiologie', 'Pourquoi on transpire : la sueur refroidit le corps en s’évaporant. L’hypothalamus commande la glande par un nerf sympathique qui libère de l’acétylcholine.'],
    ['Physiopathologie', 'Dans la forme primaire, cette commande est trop active, surtout lors d’émotions, alors que la glande est normale.'],
    ['Clinique', 'D’où une sueur aqueuse, symétrique, diurne, aux zones les plus riches en glandes.'],
    ['Examens', 'Comme la glande est normale, aucun examen ne « prouve » la maladie : le diagnostic est clinique, le test de Minor ne sert qu’à cartographier.'],
    ['Traitement', 'On agit sur un maillon : boucher le canal (aluminium), bloquer le récepteur (glycopyrronium), bloquer la libération d’acétylcholine (toxine) ou couper le nerf (chirurgie).'],
   ]), 20, 21) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme (lésion fonctionnelle)', 'Exploration', 'Cible thérapeutique'], [
    ['Canal excréteur', 'Inspection, test de Minor', 'Sels d’aluminium (obstruction)'],
    ['Récepteur muscarinique', 'Interrogatoire des effets anticholinergiques', 'Glycopyrronium topique (Axhidrox®)'],
    ['Libération d’acétylcholine', 'Cartographie par test de Minor', 'Toxine botulique de type A'],
    ['Glande et derme', 'Gravimétrie', 'Thermolyse par micro-ondes, curetage-aspiration'],
    ['Chaîne sympathique thoracique', 'Bilan préopératoire', 'Sympathectomie thoracoscopique (dernier recours)'],
   ]) + P('Cette surstimulation explique la sueur aqueuse abondante, qui entraîne macération et infections cutanées. Le bêtabloquant n’agit pas sur cette synapse cholinergique et n’est donc pas un traitement de la forme primaire.', 20))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin distingue d’abord une sudation aiguë inquiétante, avec fièvre, douleur thoracique ou altération générale, d’un tableau chronique focal typique. '
   'Une sudation généralisée, nocturne, asymétrique ou de début tardif oriente vers une cause secondaire et impose une exploration ciblée. '
   'Dans un tableau primaire typique, la ligne directrice AWMF ne recommande ni biologie ni imagerie systématiques.', 18, 20, 21) +
 F('Diagnostic différentiel (fréquence sourcée en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Hyperhidrose focale primaire' + PR('2000–4000 / 100 000 (2–4 %)', 18), 'Début précoce, bilatérale, symétrique, absente la nuit', 'Clinique ; HDSS'],
    ['Hyperthyroïdie' + PR('≈ 750 / 100 000 (0,75 %, Europe)', 33), 'Perte de poids, palpitations, tremblement', 'TSH'],
    ['Diabète (hypoglycémies sous traitement)' + PR('≈ 5000 / 100 000 (≈ 5 %, Suisse)', 34), 'Sueurs avec faim et confusion, traitement hypoglycémiant', 'Glycémie'],
    ['Tuberculose' + PR('≈ 5 / 100 000 par an (Suisse)', 35), 'Fièvre, sueurs nocturnes, toux, exposition', 'Radiographie thoracique, recherche de mycobactéries'],
    ['Endocardite infectieuse' + PR('≈ 1600 hospitalisations par an en Suisse', 8), 'Fièvre, souffle, matériel cardiaque', 'Hémocultures, échocardiographie'],
    ['Lymphome non hodgkinien' + PR('≈ 20 / 100 000 par an (Suisse)', 36), 'Sueurs nocturnes, perte de poids, adénopathies', 'Hémogramme, biopsie'],
    ['Sueurs médicamenteuses (antidépresseurs)' + PR('4–22 % des patients traités', 37), 'Début lié au traitement', 'Anamnèse médicamenteuse'],
    ['Symptômes vasomoteurs de la ménopause' + PR('jusqu’à 80 % des femmes en transition', 26), 'Bouffées de chaleur, âge 45–55 ans, cycles irréguliers', 'Contexte clinique'],
    ['Phéochromocytome' + PR('≈ 0,8 / 100 000 par an', 38), 'Crises : céphalées, palpitations, hypertension', 'Métanéphrines'],
    ['Cause neurologique (lésion médullaire, syndrome de Frey)' + PR('rare, fréquence non publiée', 20), 'Distribution asymétrique ou segmentaire', 'Examen neurologique, test de Minor'],
   ]) + P('Les fréquences décrivent la population générale (prévalence) ou l’incidence annuelle, comme indiqué ; elles ne sont pas des probabilités devant un patient donné. Devant une sudation focale, bilatérale et ancienne d’un adulte jeune, la forme primaire est de loin la plus fréquente.', 18, 20))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise l’âge de début, les régions, la symétrie, la fréquence, les déclencheurs, le sommeil et l’histoire familiale. '
   'Il mesure le retentissement personnel et professionnel avec des exemples concrets et recherche des médicaments et des signes généraux.', 18, 20, 21) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['À quel âge cela a-t-il commencé ?', 'Le début avant 25 ans est typique.', 'Un début tardif fait chercher une cause secondaire.'],
    ['Quelles régions transpirent, des deux côtés ?', 'La symétrie est typique.', 'Une asymétrie oriente vers une cause neurologique.'],
    ['Transpirez-vous la nuit ?', 'La forme primaire épargne le sommeil.', 'Des sueurs nocturnes rouvrent le diagnostic.'],
    ['Combien de fois par semaine ?', 'Au moins un épisode par semaine est attendu.', 'Elle documente la sévérité.'],
    ['Un proche est-il concerné ?', 'L’histoire familiale est fréquente.', 'Elle soutient la forme primaire.'],
    ['Que vous empêche-t-elle de faire ?', 'Papier illisible, outils qui glissent, lésions des pieds.', 'Objectif de traitement et score HDSS.'],
    ['Quels médicaments prenez-vous ?', 'Antidépresseurs, opioïdes, insuline.', 'Cause secondaire médicamenteuse.'],
   ])) +
 U('<b>Drapeaux rouges, qui imposent un bilan rapide (appel immédiat du 144 si douleur thoracique, syncope ou confusion)</b> : fièvre persistante, perte de poids, sueurs nocturnes, dyspnée, sudation généralisée récente ou asymétrique, début après 25 ans, qui font abandonner l’hypothèse primaire.', 18, 21)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin inspecte les sites décrits, compare les côtés et décrit l’humidité, les perles ou l’écoulement de sueur, puis il examine la peau à la recherche de macération et d’infection. '
   'Il recherche ensuite une distribution généralisée et les signes d’une cause secondaire (goitre, tremblement, adénopathies, fièvre). '
   'Aucune manœuvre n’a de sensibilité ou de spécificité validée, et un examen sans sueur visible n’exclut pas des épisodes bien décrits.', 20, 21) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Inspection des aisselles, des paumes et des plantes', 'Peau sèche ou à peine humide au repos', 'Humidité, perles ou écoulement : sudation excessive'],
    ['Comparaison des deux côtés', 'Sudation symétrique', 'Asymétrie : cause neurologique'],
    ['Examen de la peau des pieds', 'Peau intacte', 'Macération, kératolyse ponctuée, mycose, érythrasma'],
    ['Palpation de la thyroïde et des aires ganglionnaires', 'Pas de goitre ni d’adénopathie', 'Goitre : hyperthyroïdie ; adénopathies : lymphome'],
    ['Température, fréquence cardiaque', 'Normales', 'Fièvre, tachycardie : cause secondaire'],
   ]) + P('La valeur de l’examen tient à la description de la distribution, pas à un seuil chiffré.', 20))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Le symptôme fonctionnel est une sueur excessive, imprévisible, déclenchée par l’émotion ou la chaleur, et gênante pour écrire, serrer la main ou travailler. '
   'Les signes physiques sont l’humidité visible, les perles ou l’écoulement et leurs conséquences cutanées. '
   'Le retentissement psychosocial (gêne sociale, anxiété) fait partie du tableau mais n’en est pas la cause.', 20, 21) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    ['Humidité, perles, écoulement', 'Degrés visibles croissants de sudation', 'Hyperactivité eccrine'],
    ['Macération', 'Peau blanchâtre et ramollie', 'Contact prolongé avec l’eau'],
    ['Kératolyse ponctuée', 'Petites cupules plantaires malodorantes', 'Infection à corynébactéries favorisée par l’humidité'],
    ['Dermatite de contact, eczéma dyshidrosique', 'Vésicules, prurit des mains', 'Irritation et terrain'],
    ['Taches de sueur sur les vêtements', 'Auréoles axillaires', 'Volume sécrété'],
    ['Syndrome de Frey (diagnostic différentiel)', 'Sudation et rougeur de la joue en mangeant, après une chirurgie parotidienne', 'Réinnervation aberrante des glandes sudoripares'],
    ['Syndrome de Horner (complication)', 'Ptosis, myosis, anhidrose d’une hémiface après sympathectomie', 'Lésion de la chaîne sympathique cervicale'],
   ]) + P('Termes : ' + T('kératolyse ponctuée', 'La kératolyse ponctuée est une infection superficielle de la couche cornée plantaire par des corynébactéries ; elle se traite par un antibiotique topique et le contrôle de l’humidité.') + ', ' + T('eczéma dyshidrosique', 'L’eczéma dyshidrosique est une éruption de vésicules prurigineuses des faces latérales des doigts, aggravée par la sueur.') + ', ' + T('macération', 'La macération est un ramollissement blanchâtre de la peau exposée à l’humidité ; elle ouvre la porte aux infections.') + ', ' + T('érythrasma', 'L’érythrasma est une infection à Corynebacterium minutissimum des plis, brun-rouge, fluorescente rouge corail à la lampe de Wood.') + ', ' + T('bromhidrose', 'La bromhidrose est une odeur désagréable de la sueur liée à sa dégradation bactérienne.') + '.', 20, 21))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('L’AWMF 2023 pose un diagnostic clinique sur des éléments typiques, sans test biologique de référence. '
   'La revue suisse de 2017 retient une sudation focale excessive depuis plus de six mois avec au moins quatre critères sur sept. '
   'Un seul critère ne suffit pas, et la gravimétrie (≥ 50 mg par aisselle en 5 min dans les études) reste une aide et non une recommandation diagnostique.', 20, 21) +
 F('Règle suisse 2017 (4 critères sur 7) et score HDSS',
   TAB(['Critère', 'Ce que le médecin vérifie'], [
    ['Régions classiques touchées', 'Aisselles, paumes, plantes, région craniofaciale'],
    ['Atteinte bilatérale et relativement symétrique', 'Comparaison des deux côtés'],
    ['Épisodes au moins une fois par semaine', 'Fréquence habituelle'],
    ['Pas de sudation pendant le sommeil', 'Question précise sur la nuit'],
    ['Début avant 25 ans', 'Âge de début, pas âge actuel'],
    ['Histoire familiale positive', 'Proches concernés'],
    ['Gêne des activités quotidiennes', 'Exemple concret'],
   ], 'Préalable : sudation focale dépassant les besoins thermiques depuis plus de 6 mois.') +
   TAB(['HDSS (Hyperhidrosis Disease Severity Scale)', 'Description'], [
    ['1', 'Sudation non remarquée, ne gêne jamais les activités'],
    ['2', 'Tolérable, gêne parfois les activités'],
    ['3', 'À peine tolérable, gêne fréquemment les activités'],
    ['4', 'Intolérable, gêne toujours les activités'],
   ]) + P('Un HDSS de 3 ou 4 définit la forme sévère étudiée pour Axhidrox® et la toxine botulique ; une baisse d’un point traduit une amélioration cliniquement nette.', 20, 22))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Diagnostic clinique (critères, HDSS)', 'Gold standard : le diagnostic reste clinique', 'Aucune sensibilité ni spécificité validée', 'Dépend de l’entretien'],
    ['Gravimétrie', 'Quantité de sueur (mg par 5 min) sur un site', 'Seuil d’étude : ≥ 50 mg par aisselle en 5 min', 'Variable selon la chaleur et le stress ; pas un seuil de maladie'],
    ['Test iode-amidon de Minor', 'Cartographie de la zone active', 'Qualitatif', 'Ne quantifie pas la sévérité'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Aucun examen dans une forme primaire typique', 'AWMF 2023'],
    ['Première (cartographie)', 'Test de Minor', 'Avant une injection de toxine'],
    ['Seconde (cause secondaire)', 'TSH, glycémie, hémogramme, CRP', 'Sudation généralisée, nocturne ou début tardif'],
    ['Seconde', 'Radiographie thoracique', 'Toux, fièvre, perte de poids'],
    ['Seconde', 'Gravimétrie, test QSART', 'Suivi quantitatif ou étude ; neuropathie autonome'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Le <b>test de Minor</b> se fait sur peau propre et sèche, sans antitranspirant depuis 24 heures ; on vérifie l’absence d’allergie à l’iode avant l’application.',
       'La <b>gravimétrie</b> se fait au repos, à température ambiante stable, avec un papier filtre pesé avant et après 5 minutes.',
       'Les <b>examens sanguins</b> ne se demandent qu’en cas de suspicion de cause secondaire.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Zone foncée au test de Minor', 'Qualitatif', 'Territoire actif', 'Répartition des injections'],
    ['Gravimétrie', '≥ 50 mg/5 min par aisselle', 'Critère d’inclusion des études', 'Ne décide pas seul du traitement'],
    ['Résultat négatif (gravimétrie < 50 mg un jour calme)', '—', 'N’exclut pas des épisodes importants', 'Se fier à l’histoire clinique'],
    ['TSH basse', '< 0,4 mU/L', 'Hyperthyroïdie', 'Bilan thyroïdien ; forme secondaire'],
    ['Résultat limite (CRP modérément élevée)', '—', 'Cause secondaire possible', 'Réévaluation clinique'],
    ['Résultat positif au test de Minor mais discordant avec la plainte', '—', 'Zone active différente du site gênant', 'Reprendre la cartographie et l’histoire'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Allergie à l’iode', 'Variante à l’amidon et à un autre indicateur, ou cartographie clinique'],
    ['Grossesse', 'Pas d’examen nécessaire dans une forme primaire ; TSH si suspicion de thyroïdite'],
    ['Enfant', 'Diagnostic clinique ; pas de bilan systématique'],
    ['Personne âgée (début tardif)', 'Bilan secondaire ciblé indispensable'],
    ['DFGe < 30 mL/min/1,73 m²', 'Examens sans contraste ; Axhidrox® avec prudence'],
    ['Stimulateur cardiaque', 'Ionophorèse contre-indiquée (courant électrique) ; IRM selon la compatibilité'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le diagnostic de la forme primaire typique est clinique et ne demande aucun examen de routine. '
   'Le test de Minor cartographie la zone avant une injection, et la gravimétrie quantifie la sueur dans les études. '
   'Les examens sanguins et l’imagerie ne se demandent que si un drapeau rouge oriente vers une cause secondaire.', 20, 21) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si un drapeau rouge ou un profil secondaire est présent, alors le médecin lance l’enquête étiologique ciblée. '
   'Si le tableau primaire est typique, alors il documente les sites et le HDSS, puis il choisit un traitement local selon le site. '
   'Avant chaque escalade, il vérifie l’application, la tolérance, les objectifs et le diagnostic.', 18, 20, 21) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Sueurs nocturnes, fièvre, perte de poids ou début tardif', 'Enquête secondaire (TSH, glycémie, hémogramme, CRP, radiographie)', 'Selon la cause'],
    ['Forme axillaire', 'Sels d’aluminium, puis glycopyrronium topique ou toxine botulique', 'HDSS à 4 semaines'],
    ['Forme palmaire ou plantaire', 'Sels d’aluminium et ionophorèse à l’eau du robinet', 'HDSS à 4–6 semaines'],
    ['Forme craniofaciale', 'Glycopyrronium hors indication ou anticholinergique oral, avis dermatologique', 'Tolérance'],
    ['Échec des traitements locaux et gêne majeure', 'Avis dermatologique ; anticholinergique oral hors indication ; chirurgie en dernier recours', 'Information sur la sudation compensatrice'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Dose et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Glycopyrronium, Axhidrox® crème (antimuscarinique topique), autorisation 69243', 'Hyperhidrose axillaire primaire sévère de l’adulte : 2 pressions par aisselle (540 mg de crème, 4,4 mg de glycopyrronium) le soir, 1 fois par jour pendant 4 semaines, puis 2 fois par semaine dès la 5e semaine ; flacon jeté après 31 traitements ; équilibre pharmacocinétique en 7–14 jours, élimination surtout rénale, demi-vie non établie', 'Sécheresse buccale, oculaire et nasale, constipation, vision trouble, rétention urinaire (arrêt immédiat) ; contre-indiqué en cas de glaucome, d’iléus paralytique, de myasthénie, de syndrome de Sjögren, de mégacôlon toxique ; interactions avec les autres anticholinergiques (antihistaminiques sédatifs, tricycliques, neuroleptiques, opioïdes)'],
   ['Toxine botulique A, BOTOX® (inhibiteur de la libération d’acétylcholine), autorisation 52433', '50 unités Allergan par aisselle en intradermique, reconstitution 100 U pour 4,0 mL, sites espacés de 1–2 cm ; pas avant 16 semaines ; effet en 1 semaine, durée 4–7 mois', 'Diffusion de l’effet (faiblesse, dysphagie, dyspnée) imposant une prise en charge immédiate ; contre-indiquée en cas d’infection au site ; interaction avec les aminosides et les myorelaxants'],
   ['Toxine botulique A, Dysport® (inhibiteur de la libération d’acétylcholine), autorisation 55057', '100 unités Dysport par aisselle, 10 sites de 10 U après test de Minor ; pas avant 12 semaines ; effet maximal vers 2 semaines', 'Mêmes risques ; troubles de la coagulation : précautions ; unités non interchangeables avec celles de Botox®'],
   ['Chlorure d’aluminium hexahydraté (sel métallique antitranspirant)', 'Topique de première intention, 10–30 % selon le site (AWMF), le soir sur peau sèche, puis espacé ; préparation magistrale ou cosmétique à préciser', 'Irritation, prurit ; pas sur peau lésée'],
   ['Oxybutynine (anticholinergique oral)', 'Hors indication suisse pour l’hyperhidrose ; réservée à une décision spécialisée', 'Effets anticholinergiques systémiques, confusion chez la personne âgée'],
  ]) + P('Les doses chiffrées sont celles des AIPS suisses ; aucune dose hors indication (paumes, plantes, visage) n’est extrapolée. Les unités de Botox® et de Dysport® n’ont pas de facteur de conversion.', 1, 20, 22, 23, 24))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge réduit la gêne et améliore les activités par une stratégie graduée selon le site, parce qu’une suppression totale de la sueur n’est ni possible ni souhaitable. '
   'Les topiques précèdent les injections et les procédures, et l’ionophorèse convient surtout aux mains et aux pieds. '
   'Le suivi réévalue l’efficacité, la peau et les effets indésirables.', 19, 20) +
 F('11.A Buts : objectif concret, sans urgence ni forme compliquée',
   P('Il n’y a ni urgence ni forme compliquée vitale ; le but est un objectif concret partagé (écrire, tenir un outil, limiter les lésions des pieds), mesuré par une baisse du HDSS d’au moins un point. À distance, le but est de maintenir l’effet avec un entretien tolérable et d’éviter un geste irréversible mal informé.', 20, 21), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Vêtements amples en fibres naturelles, chaussettes changées, semelles absorbantes ; soins de la peau des pieds.',
         'Sels d’aluminium en première intention, quel que soit le site.',
         'Aisselles : glycopyrronium topique (Axhidrox®) ou toxine botulique si la forme est sévère.',
         'Paumes et plantes : ionophorèse à l’eau du robinet, 20–30 minutes plusieurs fois par semaine, puis 1 à 2 fois par semaine en entretien.',
         'Formes réfractaires : avis dermatologique, anticholinergique oral hors indication, thermolyse par micro-ondes ou chirurgie axillaire locale.',
         f'Dernier recours : sympathectomie thoracoscopique pour la forme palmaire sévère, après information sur la {COMP}.']), 19, 20) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal (art. 25 et 32) prend en charge les prestations efficaces, appropriées et économiques ; le remboursement d’une toxine ou d’Axhidrox® suit la liste des spécialités et ses limitations, à vérifier pour chaque produit.',
         'La LAA n’intervient pas (maladie) ; la LAI (art. 7, 8 et 28) ne concerne que les rares atteintes avec incapacité de gain durable.',
         'L’arrêt de travail n’est habituel qu’après une chirurgie (quelques jours) ; des adaptations du poste (gants, outils antidérapants) aident le travail professionnel.',
         'La conduite automobile est déconseillée si Axhidrox® provoque une vision trouble ou des vertiges (AIPS).']), 2, 3, 22) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Axhidrox® envisageable si nécessaire (faible exposition) ; l’enfant allaité ne touche pas la zone traitée ; toxines seulement en cas de nécessité absolue, non recommandées pendant l’allaitement.'],
      ['Personne âgée', 'Axhidrox® non étudié après 65 ans ; anticholinergiques oraux à éviter (confusion, chute).'],
      ['Enfant et adolescent', 'Axhidrox® non établi avant 18 ans ; sels d’aluminium et ionophorèse en premier.'],
      ['Insuffisance hépatique', 'Pas d’ajustement d’Axhidrox® prévu par l’AIPS.'],
      ['Insuffisance rénale', 'Axhidrox® à dose usuelle si l’atteinte est légère ou modérée ; DFGe < 30 mL/min/1,73 m² ou dialyse : bénéfice-risque et surveillance étroite.'],
     ]), 22, 23, 24), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['HDSS et activité cible', 'À 4 semaines puis à chaque séance', 'Pas de baisse d’au moins 1 point : changer de traitement'],
    ['Effets anticholinergiques', 'À chaque visite sous Axhidrox®', 'Rétention urinaire, vision trouble : arrêt'],
    ['Faiblesse, dysphagie, dyspnée après toxine', 'Heures à semaines après l’injection', 'Prise en charge médicale immédiate'],
    ['Peau (irritation, macération)', 'À chaque visite', 'Lésion : traitement suspendu jusqu’à guérison'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Après une injection ambulatoire : absence de réaction immédiate et information sur les signes de diffusion.', 'Après une chirurgie : douleur contrôlée, plaie propre, consignes du centre comprises.', 'Rendez-vous de suivi fixé avec le score HDSS de référence.']), 20, 23, 24) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('L’affection est bénigne mais chronique ; les traitements la contrôlent sans la guérir, et l’effet des toxines dure plusieurs mois. La sympathectomie expose à une sudation compensatrice parfois invalidante et à un syndrome de Horner. La recherche 2026 évalue de nouveaux anticholinergiques topiques et la thermolyse par micro-ondes à long terme.', 19, 20), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('Aucune prévention primaire ni dépistage de la forme primaire n’existe, et aucune recommandation suisse n’en propose. '
   'La prévention secondaire repère les présentations atypiques et les causes traitables, comme une hyperthyroïdie ou un lymphome. '
   'La prévention tertiaire protège la peau (kératolyse, mycoses), maintient l’activité et sécurise les traitements par une information complète avant tout geste irréversible.', 18, 20, 21) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Aucune mesure validée'],
    ['Secondaire', 'Rechercher une cause secondaire dès un drapeau rouge'],
    ['Tertiaire', 'Soins des pieds, traitement des surinfections, soutien psychosocial, information sur la sudation compensatrice'],
   ]))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin reconnaît la forme primaire par un début précoce, une atteinte focale bilatérale et l’absence de sueurs nocturnes. '
   'Il recherche une cause secondaire devant une sudation généralisée, nocturne ou tardive. '
   'Il documente le site et le HDSS avant de traiter. '
   'Il commence par les sels d’aluminium, puis il choisit le glycopyrronium ou la toxine pour l’aisselle et l’ionophorèse pour les mains. '
   'Il respecte les doses et les unités propres à chaque produit suisse.', 20, 21, 22, 23, 24)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['La règle suisse 2017 exige deux critères sur six.', 'Elle exige quatre critères sur sept, après six mois de sudation focale.'],
  ['Une gravimétrie < 50 mg en 5 minutes exclut l’hyperhidrose.', 'Non : ce seuil sert aux études et le diagnostic reste clinique.'],
  ['Axhidrox® s’applique aux paumes à la même dose.', 'Non : son indication suisse est axillaire.'],
  ['La grossesse interdit toujours Axhidrox®.', 'Non : il peut être envisagé si nécessaire selon l’AIPS.'],
  ['100 unités Dysport® équivalent à 100 unités Botox®.', 'Non : les unités ne sont pas interchangeables.'],
  ['Prescrire un bêtabloquant pour une hyperhidrose primaire.', 'La synapse glandulaire est cholinergique ; le bêtabloquant n’est pas indiqué.'],
  ['Demander un bilan sanguin systématique.', 'Une forme primaire typique ne demande aucun examen.'],
  ['Proposer une sympathectomie en premier.', 'C’est un dernier recours à cause de la sudation compensatrice.'],
 ]) + P('Ces pièges reprennent l’AWMF 2023, la revue suisse 2017 et les AIPS.', 20, 21, 22, 23, 24)))
SOURCES = sorted(SOURCES_ORIG.items()) + [
 (33, 'Garmendia Madariaga A, Santos Palacios S, Guillén-Grima F, Galofré JC. The incidence and prevalence of thyroid dysfunction in Europe: a meta-analysis. J Clin Endocrinol Metab 2014;99:923–931. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (34, 'Office fédéral de la statistique (OFS). Enquête suisse sur la santé 2022 : diabète. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (35, 'Office fédéral de la santé publique (OFSP). La tuberculose en Suisse : situation épidémiologique (rapport annuel). Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (36, 'OFS, NICER, Registre du cancer de l’enfant. Rapport suisse sur le cancer 2021 : lymphomes. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (37, 'Marcy TR, Britton ML. Antidepressant-induced sweating. Ann Pharmacother 2005;39:748–752. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
 (38, 'Lenders JWM et al. Pheochromocytoma and paraganglioma: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab 2014;99:1915–1942. Référence ajoutée lors de l’audit du 24 octobre 2026.'),
]
CTX = {'_prefixe': 'Dans l’hyperhidrose',
 'minor': 'Le test iode-amidon de Minor cartographie la zone active avant une injection de toxine ; il ne mesure pas la sévérité.',
 'grav': 'La gravimétrie quantifie la sueur sur un site ; le seuil de 50 mg par aisselle en 5 minutes sert d’inclusion aux études.',
 'qsart': 'Le test QSART explore la fonction sudorale autonome si une neuropathie est suspectée.',
 'tsh': 'Une TSH basse oriente vers une hyperthyroïdie, cause de sudation secondaire.',
 'gly': 'La glycémie recherche une hypoglycémie ou un diabète devant des sueurs généralisées.',
 'nfs': 'L’hémogramme cherche des signes d’infection ou d’hémopathie si la sudation est secondaire.',
 'crp': 'Une CRP élevée oriente vers une cause inflammatoire ou infectieuse.',
 'radio': 'La radiographie thoracique cherche une tuberculose ou un lymphome devant des sueurs nocturnes.',
 'hemoc': 'Les hémocultures se demandent si la fièvre fait suspecter une endocardite.',
 'meta': 'Les métanéphrines se dosent si les sueurs surviennent en crises avec hypertension.',
 'biopsie': 'La biopsie ganglionnaire s’impose si des adénopathies font suspecter un lymphome.',
 'hcg': 'Le test de grossesse précède les traitements dont l’usage est limité pendant la grossesse.',
 'creat': 'Le DFGe guide l’usage d’Axhidrox® : prudence sous 30 mL/min/1,73 m².',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
