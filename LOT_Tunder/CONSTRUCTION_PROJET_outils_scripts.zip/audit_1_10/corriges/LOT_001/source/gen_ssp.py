# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ de l’Appel A du LOT 1 : SSP G1 « Transpiration anormale » (14 points) + bloc 2 (liste des dix diagnostics).
Sources S1–S104 = originaux Appel A V9 a/b (src_A.py, numérotation conservée) ; S105–S115 ajoutées à l’audit du 24.10.2026."""
import sys; sys.path.insert(0, '/workspace/audit_1_10/outils')
import gen_v7
from gen_v7 import *
from src_A import SOURCES_ORIG as SA
POINT = mkPOINT('ssp')
M = dict(pref='ssp', dx='SSP G1', court='Transpiration anormale', long='Transpiration anormale (situation clinique de départ)', dossier='corriges/LOT_001',
         fichier='LOT_001_Appel_A_SSP_G1_Transpiration_anormale_AUDITÉ.html', lot_titre='LOT 1 · G1 · Transpiration anormale',
         sous_titre='PROFILES 2023 · SSP G1 · LOT 1 · Appel A · V7 · version AUDITÉE (14 points et liste des dix diagnostics)',
         statut='Cette version corrige l’Appel A du LOT 1 (plan V7 et liste V9, pièces a et b) après audit médical et linguistique ; les doses proviennent des informations professionnelles suisses (AIPS).')
_build = gen_v7.build
def _build_ssp(*a, **k):
    return _build(*a, **k).replace('<a href="#ssp-p15">15</a>', '<a href="#ssp-p15">Dix DX</a>')
gen_v7.build = _build_ssp

ECCR = T('glande eccrine', 'La glande eccrine est la petite glande à sueur de toute la peau ; elle fabrique une sueur aqueuse qui refroidit le corps en s’évaporant.')
SYMP = T('système sympathique', 'Le système sympathique est la partie automatique du système nerveux qui prépare le corps à l’effort ; il commande les glandes à sueur.')
ACH = T('acétylcholine', 'L’acétylcholine est le messager chimique libéré par le nerf sur la glande à sueur ; il agit sur des récepteurs dits muscariniques.')
CONS = T('consigne thermique', 'La consigne thermique est la température « visée » par l’hypothalamus, le thermostat du cerveau ; la fièvre élève cette consigne.')
HDSS = T('HDSS', 'L’échelle HDSS (Hyperhidrosis Disease Severity Scale) note de 1 à 4 la gêne due à la transpiration dans la vie quotidienne.')
PTS = []

# ---------- 1
b1 = (P(f'Transpirer, c’est produire de la sueur par les {ECCR}s pour refroidir le corps. '
        'La transpiration devient anormale quand sa quantité, sa répartition, son horaire, son odeur ou sa couleur dépassent le besoin de refroidissement. '
        'Le terme exact décrit l’anomalie, sans nommer sa cause.', 3, 5, 6) +
  F('Terminologie : mot courant et terme exact',
    TAB(['Mot courant', 'Terme exact', 'Définition', 'À ne pas confondre avec'], [
     ['Transpirer trop', 'Hyperhidrose', 'Sudation qui dépasse le besoin de refroidissement', 'Sudation normale à la chaleur ou à l’effort'],
     ['Transpiration primaire', 'Hyperhidrose focale primaire', 'Forme sans cause, bilatérale, aux aisselles, paumes, plantes ou visage', 'Forme secondaire à une maladie ou à un médicament'],
     ['Suer à grosses gouttes', 'Diaphorèse', 'Sudation profuse visible, souvent aiguë', 'Un diagnostic : c’est un signe'],
     ['Sueurs la nuit', 'Sueurs nocturnes', 'Draps ou vêtements mouillés pendant le sommeil', 'Chambre surchauffée'],
     ['Transpirer peu', 'Hypohidrose', 'Sudation diminuée', 'Peau simplement sèche'],
     ['Ne plus transpirer', 'Anhidrose', 'Absence de sudation, danger de surchauffe', 'Signe rassurant'],
     ['Mauvaise odeur', 'Bromhidrose', 'Odeur anormale de la sueur', 'Quantité de sueur'],
     ['Sueur colorée', 'Chromhidrose', 'Coloration de la sueur, à distinguer d’un textile ou d’un produit', 'Pseudochromhidrose (colorant externe)'],
    ]) + P('La DDG (Deutsche Dermatologische Gesellschaft) sépare une forme primaire sans cause et une forme secondaire due à une cause interne ou externe.', 3, 82, 84)) +
  F('Pourquoi ces mots changent la décision',
    UL(['Une diaphorèse avec pâleur et confusion fait d’abord mesurer la glycémie.',
        'Une anhidrose étendue à la chaleur fait craindre un coup de chaleur.',
        'Des sueurs nocturnes font chercher fièvre, toux, ganglions et perte de poids, sans conclure à un cancer.']), 5, 14, 18, 24))
PTS.append(POINT(1, 'Définition et sémantique', b1))

# ---------- 2
b2 = (P('En Suisse, les HUG estiment que l’hyperhidrose touche environ 3 % de la population, et l’OFSP compte 6,0 cas de tuberculose pour 100 000 habitants en 2025. '
        'Aucune étude suisse ne chiffre la part de chaque cause chez les patients qui transpirent.', 4, 19) +
  P('Le terrain change le pronostic : l’âge, le sexe, le diabète ou une valvulopathie orientent vers des causes à forte mortalité. '
    'La forme primaire débute souvent avant 25 ans et altère surtout la vie sociale.', 3, 45, 105) +
  F('Chiffres comparables (Suisse, puis Europe)',
    TAB(['Indicateur', 'Valeur', 'Population et portée'], [
     ['Hyperhidrose (HUG)', '≈ 3 %' + S(4), 'Population générale, ordre de grandeur suisse'],
     ['Hyperhidrose primaire (Suède)', '5,5 % ; forme sévère HDSS 3–4 : 1,4 %' + S(26), '1 353 répondants de 18 à 60 ans'],
     ['Hyperhidrose autodéclarée (Danemark)', '9,07 % ; diagnostic hospitalier 0,23 %' + S(27), 'Donneurs de sang ; définitions différentes'],
     ['Tuberculose (Suisse, 2025)', '544 cas, 6,0 / 100 000' + S(19), 'Incidence, pas une probabilité devant des sueurs'],
     ['Diabète déclaré (Suisse)', '≈ 5 % des adultes' + S(105), 'Terrain des hypoglycémies traitées'],
     ['Nouveaux diagnostics de VIH (Suisse)', '≈ 4 / 100 000 par an' + S(107), 'Incidence déclarée'],
     ['Lymphome de Hodgkin (Suisse, 2018–2022)', '≈ 3,2 / 100 000 par an' + S(108), 'Incidence'],
     ['Endocardite infectieuse (Europe)', '3–10 / 100 000 par an' + S(110), 'Mortalité hospitalière élevée'],
     ['Ménopause naturelle (Europe)', 'vers 51 ans' + S(21), 'Symptômes vasomoteurs chez ≈ 80 % des femmes en transition' + S(112)],
    ]) + P('Ces chiffres ont des dénominateurs différents : une incidence de maladie ne dit pas la probabilité qu’un patient qui transpire en soit atteint.', 4, 19, 26, 27)) +
  F('Histoire naturelle et pronostic',
    UL(['La forme primaire commence dans l’enfance ou l’adolescence et persiste souvent ; elle limite l’écriture, les poignées de main et le travail manuel.',
        'Une forme secondaire suit le pronostic de sa cause : bon pour une ménopause, grave sans traitement pour un SCA, une endocardite ou une tuberculose.',
        'Une anhidrose étendue expose au coup de chaleur, surtout chez la personne âgée, lors des canicules.']), 3, 5, 30))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)', b2))

# ---------- 3
b3 = (P('Le système sympathique commande les glandes eccrines par l’acétylcholine ; l’évaporation de la sueur évacue la chaleur. '
        'Dans la forme primaire, des glandes normales sont trop stimulées, alors qu’une forme secondaire dérègle la commande, le métabolisme ou la consigne thermique, et le traitement suit ce mécanisme.', 3, 5, 9) +
  F('Termes du mécanisme', P('Termes : ' + SYMP + ', ' + ACH + ', ' + CONS + '.', 3, 50)) +
  F('Chaîne logique : de l’anatomie au traitement',
    TAB(['Étape', 'Ce qu’il faut comprendre'], [
     ['Anatomie', 'Environ deux à quatre millions de glandes eccrines couvrent la peau, plus denses aux paumes, aux plantes et aux aisselles ; elles reçoivent des fibres sympathiques.'],
     ['Physiologie', 'Pourquoi on transpire : l’hypothalamus compare la température à sa consigne et ordonne la sueur quand il fait trop chaud ; l’émotion active surtout paumes et aisselles.'],
     ['Physiopathologie', 'Excès de commande (forme primaire), décharge d’adrénaline (hypoglycémie, ischémie, phéochromocytome), consigne élevée (infection), thermogenèse accrue (hyperthyroïdie), instabilité hypothalamique (ménopause), défaut de sueur (anhidrose).'],
     ['Clinique', 'D’où des sueurs focales et diurnes, aiguës et froides, fébriles et nocturnes, ou une peau sèche et brûlante.'],
     ['Examens', 'La glycémie, l’ECG, la TSH ou les hémocultures prouvent le mécanisme ; le test de Minor cartographie la zone.'],
     ['Traitement', 'Glucose, revascularisation, antibiotique, antithyroïdien ou refroidissement traitent la cause ; glycopyrronium et toxine botulique bloquent la voie cholinergique.'],
    ]), 3, 5, 53, 57) +
  F('Mécanisme, exploration et cible thérapeutique',
    TAB(['Mécanisme (lésion)', 'Exploration qui le montre', 'Cible thérapeutique'], [
     ['Commande focale disproportionnée', 'Anamnèse, test de Minor', 'Antitranspirant, glycopyrronium, toxine botulique'],
     ['Récepteur muscarinique de la glande', 'Territoire axillaire confirmé', 'Glycopyrronium topique (antagoniste)'],
     ['Libération d’acétylcholine', 'Zone délimitée avant injection', 'Toxine botulique A (clive une protéine de l’exocytose)'],
     ['Manque de glucose', 'Glycémie immédiate', 'Glucose, glucagon'],
     ['Cytokines et prostaglandines (fièvre)', 'CRP, hémocultures, imagerie', 'Traitement de l’infection'],
     ['Baisse des œstrogènes (neurokinine B)', 'Clinique, âge, cycles', 'Traitement hormonal ou fézolinétant'],
     ['Excès d’hormones thyroïdiennes', 'TSH, T4 libre', 'Antithyroïdien'],
     ['Anhidrose étendue', 'Exposition, étendue de la sécheresse', 'Refroidissement externe, éviction de la chaleur'],
    ]) + P('Le mécanisme explique pourquoi un antitranspirant ne traite jamais une cause secondaire.', 3, 8, 9, 12, 53)))
PTS.append(POINT(3, 'Physiopathologie', b3))

# ---------- 4
def PRb(v, *s): return PR(v, *s)
b4 = (P('Le médecin recherche d’abord une urgence vitale : hypoglycémie, ischémie myocardique, infection grave ou coup de chaleur avec peau sèche. '
        'Il précise ensuite la répartition, l’horaire et les signes associés, puis sépare la forme primaire typique d’une forme secondaire. '
        'La décision est guidée par l’instabilité, et non par la quantité de sueur.', 5, 14, 22, 29) +
  F('Diagnostic différentiel (fréquence sourcée en exposant rouge)',
    TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
     ['Syndrome coronarien aigu' + PRb('STEMI 5–10 %, NSTEMI 15–20 % des douleurs thoraciques aux urgences', 111), 'Sueurs froides, oppression, dyspnée', 'ECG, troponine'],
     ['Hypoglycémie (diabète traité)' + PRb('diabète ≈ 5 % des adultes en Suisse', 105), 'Insuline ou sulfamide, faim, tremblement, confusion', 'Glycémie immédiate'],
     ['Endocardite infectieuse' + PRb('3–10 / 100 000 par an (Europe)', 110), 'Fièvre, prothèse valvulaire, souffle', 'Hémocultures, échocardiographie'],
     ['Hyperhidrose focale primaire' + PRb('≈ 3 % (HUG)', 4), 'Jeune, bilatérale, focale, arrêt pendant le sommeil', 'Clinique, test de Minor'],
     ['Symptômes vasomoteurs de la ménopause' + PRb('≈ 80 % des femmes en transition', 112), 'Bouffées de chaleur, 45–55 ans, cycles modifiés', 'Clinique ; FSH si doute'],
     ['Hyperthyroïdie' + PRb('≈ 0,75 % (Europe)', 106), 'Thermophobie, perte de poids, tachycardie', 'TSH'],
     ['Tuberculose' + PRb('6,0 / 100 000 par an (Suisse, 2025)', 19), 'Toux > 2–3 semaines, fièvre, migration', 'Radiographie, PCR et culture'],
     ['Infection par le VIH' + PRb('≈ 4 / 100 000 par an (Suisse)', 107), 'Exposition, fièvre, éruption', 'Test de 4e génération'],
     ['Lymphome de Hodgkin' + PRb('≈ 3,2 / 100 000 par an (Suisse)', 108), 'Adénopathie indolore, symptômes B', 'Biopsie ganglionnaire'],
     ['Phéochromocytome' + PRb('0,2–0,6 % des hypertendus', 109), 'Accès de céphalée, palpitations, sueurs', 'Métanéphrines plasmatiques libres'],
     ['Sueurs médicamenteuses (antidépresseurs)' + PRb('4–22 % des patients traités', 114), 'Début après un nouveau traitement', 'Chronologie'],
     ['Trouble panique' + PRb('≈ 1,7 % sur la vie', 113), 'Peur intense, crises brèves', 'Diagnostic après exclusion des urgences'],
     ['Lymphome non hodgkinien' + PRb('≈ 20 / 100 000 par an (Suisse)', 115), 'Adénopathies, symptômes B', 'Biopsie'],
    ]) + P('Ces chiffres sont des incidences ou des prévalences dans la population ; ils ne sont pas des probabilités devant un patient donné.', 4, 19)) +
  F('Hiérarchie des urgences : danger, discriminant, action',
    TAB(['Danger', 'Discriminant', 'Action immédiate'], [
     ['Hypoglycémie', 'Glycémie < 4,0 mmol/L', 'Correction selon le protocole, sans attendre si la mesure est impossible'],
     ['Ischémie myocardique', 'ECG, symptômes, troponine dans sa cinétique', 'Filière urgente (144), surveillance'],
     ['Infection grave ou endocardite', 'Défaillance, prothèse, souffle', 'Hémocultures avant antibiotique, hôpital'],
     ['Coup de chaleur, anhidrose', 'Peau sèche et chaude, confusion', 'Arrêt de l’exposition, refroidissement, 144'],
     ['Tuberculose, lymphome', 'Toux, adénopathies, perte de poids', 'Prélèvements respiratoires ou biopsie rapides'],
    ]), 5, 14, 18, 22, 24, 29))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel', b4))

# ---------- 5
b5 = (P('L’entretien précise le début, l’étendue, la symétrie, l’horaire, les déclencheurs, les médicaments, les expositions et la gêne au quotidien.', 3, 5, 7) +
  F('Questions et ce que la réponse change',
    TAB(['Question', 'Raison', 'Ce que la réponse change'], [
     ['Depuis quand, et cela a-t-il changé ?', 'Un début précoce et stable évoque la forme primaire.', 'Un changement récent fait chercher une cause acquise.'],
     ['Les deux côtés sont-ils atteints ?', 'Une lésion nerveuse modifie un seul territoire.', 'Une asymétrie impose un examen neurologique.'],
     ['La sueur cesse-t-elle pendant le sommeil ?', 'C’est un trait de la forme primaire.', 'Des sueurs nocturnes nouvelles font chercher une cause générale.'],
     ['Faim, tremblement, confusion, insuline ?', 'La baisse du glucose déclenche une décharge d’adrénaline.', 'Glycémie et correction immédiates.'],
     ['Oppression, dyspnée, nausées, malaise ?', 'Une ischémie peut être peu douloureuse.', 'ECG et filière urgente.'],
     ['Fièvre, toux, ganglions, perte de poids ?', 'Ces signes évoquent une infection ou un lymphome.', 'Examens dirigés, pas de traitement sudoral seul.'],
     ['Bouffées de chaleur, cycles modifiés ?', 'La baisse des œstrogènes dérègle le thermostat.', 'Bilan selon l’âge et le contexte hormonal.'],
     ['Médicament commencé, arrêté ou modifié ?', 'Antidépresseurs, opioïdes ou sevrages font transpirer.', 'Discussion avec le prescripteur.'],
     ['Exposition à la tuberculose ou au VIH ?', 'Une entrée infectieuse est possible.', 'Test adapté et confidentiel.'],
     ['La peau reste-t-elle sèche à la chaleur ?', 'Une anhidrose empêche le refroidissement.', 'Éviction de la chaleur, recherche de surchauffe.'],
     ['Que ne pouvez-vous plus faire ?', 'Le handicap guide le traitement.', 'Score HDSS et objectif fonctionnel.'],
    ]), 3, 5, 7, 14, 18, 20, 22, 53) +
  U('<b>Drapeaux rouges et urgence (appel du 144)</b> : confusion, perte de connaissance, oppression thoracique, dyspnée, fièvre avec défaillance, peau sèche et brûlante à la chaleur.', 5, 14, 22))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges', b5))

# ---------- 6
b6 = (P('Le médecin mesure la température avec son site, le pouls, la pression et la glycémie capillaire, puis compare les territoires sudoraux. '
        'Il examine le cou, la thyroïde, les aires ganglionnaires, le cœur, les poumons et l’abdomen, en décrivant le normal avant l’anomalie. '
        'Un examen sec au repos n’annule pas une histoire typique.', 3, 6, 50) +
  F('Technique, normal, anomalie et valeur',
    TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
     ['Peau des aisselles, paumes, plantes', 'Humidité modérée', 'Taches axillaires de 5–10 cm (léger), 10–20 cm (modéré), > 20 cm (important) selon la DDG' + S(3)],
     ['Température (site noté)', 'Selon la référence du site', 'Fièvre ; hyperthermie avec confusion : coup de chaleur' + S(50)],
     ['Pouls et mains tendues', 'Régulier, sans tremblement', 'Tachycardie, arythmie, tremblement : glycémie, ECG ou TSH' + S(59, 60)],
     ['Pression artérielle (5 min de repos, assis)', 'Moyenne des deux dernières mesures', 'Pics pendant les accès : phéochromocytome' + S(79)],
     ['Thyroïde (inspection, déglutition, palpation)', 'Pas de goitre', 'Goitre ou nodule : bilan thyroïdien ; l’absence de goitre n’exclut rien' + S(94)],
     ['Aires ganglionnaires cervicales, axillaires, inguinales', 'Pas de tuméfaction suspecte', 'Ganglion dur, fixe ou > 1,5–2 cm : biopsie' + S(62, 49)],
     ['Auscultation cardiaque', 'Deux bruits, pas de souffle', 'Souffle nouveau : endocardite ; une auscultation normale n’exclut pas' + S(29, 36)],
     ['Auscultation pulmonaire', 'Murmure vésiculaire symétrique', 'Crépitants, diminution focale' + S(96)],
     ['Abdomen', 'Souple, sans masse', 'Splénomégalie : lymphome ou endocardite' + S(48)],
     ['Conscience et déglutition', 'Réponses adaptées', 'Altération : pas de voie orale, glycémie' + S(14)],
    ]) + P('Termes : ' + T('crépitants', 'Les crépitants sont des bruits respiratoires ajoutés, brefs et non musicaux, entendus à l’inspiration.') + ', '
           + T('splénomégalie', 'La splénomégalie est une rate augmentée de volume, palpable sous les côtes gauches.') + ', '
           + T('goitre', 'Le goitre est une augmentation de volume de la thyroïde ; il ne prouve pas un excès d’hormones.') + '.', 94, 96)))
PTS.append(POINT(6, 'Examen clinique', b6))

# ---------- 7
b7 = (P('Les signes fonctionnels sont rapportés par le patient : sueurs, faim, oppression, fatigue, bouffées de chaleur. '
        'Les signes physiques sont constatés : fièvre, tachycardie, souffle, ganglion, goitre, peau sèche. '
        'Ils se regroupent en syndromes, chacun avec son discriminant.', 14, 22, 96) +
  F('Syndromes et signes définis',
    TAB(['Syndrome', 'Signes', 'Mécanisme', 'Discriminant'], [
     ['Syndrome hypoglycémique', 'Sueurs, tremblement, faim, puis confusion', 'Décharge d’adrénaline, manque de glucose cérébral', 'Glycémie' + S(14, 74)],
     ['Syndrome ischémique', 'Oppression, dyspnée, nausées, sueurs froides', 'Manque d’oxygène du myocarde', 'ECG, troponine' + S(22, 37)],
     ['Syndrome infectieux', 'Fièvre, frissons, sueurs nocturnes, toux', 'Consigne thermique élevée', 'Foyer, prélèvements' + S(18, 50)],
     ['Syndrome lymphoïde', 'Adénopathies, splénomégalie, symptômes B', 'Prolifération lymphoïde', 'Histologie' + S(24, 62)],
     ['Syndrome vasomoteur', 'Bouffées de chaleur, rougeur, réveils', 'Thermostat instable par baisse des œstrogènes', 'Âge, cycles' + S(53)],
     ['Syndrome thyrotoxique', 'Thermophobie, tremblement, perte de poids', 'Thermogenèse accrue', 'TSH' + S(57)],
     ['Syndrome adrénergique paroxystique', 'Céphalée, palpitations, sueurs par accès', 'Décharge de catécholamines', 'Métanéphrines' + S(23)],
     ['Syndrome de défaut thermique', 'Peau sèche, chaleur, céphalée, confusion', 'Anhidrose', 'Exposition, étendue' + S(5)],
    ]) + P('Les ' + T('symptômes B', 'Les symptômes B sont la fièvre inexpliquée > 38 °C, les sueurs nocturnes profuses et une perte de plus de 10 % du poids en 6 mois.') + ' orientent sans prouver un lymphome.', 24)))
PTS.append(POINT(7, 'Syndromes et signes cliniques', b7))

# ---------- 8
b8 = (P('La SSP G1 n’a pas de critère unique : chaque cause garde ses critères propres. '
        'Pour l’hyperhidrose focale primaire, la règle reprise en Suisse en 2017 exige plus de 6 mois de sudation focale et au moins 4 critères sur 7. '
        'La recommandation DDG de 2023 n’impose aucun seuil universel de débit, et la gravimétrie de 50 mg par 5 minutes reste un seuil d’étude.', 3, 4, 45) +
  F('Critères de l’hyperhidrose focale primaire (au moins 4 sur 7, depuis plus de 6 mois)',
    OL(['Atteinte bilatérale et à peu près symétrique.', 'Gêne dans les activités quotidiennes.', 'Au moins un épisode par semaine.',
        'Début avant 25 ans.', 'Antécédent familial.', 'Arrêt de la sudation pendant le sommeil.', 'Absence de cause secondaire.']), 3, 45) +
  F('Échelle HDSS et règles d’interprétation',
    TAB(['Score HDSS', 'Description', 'Conséquence'], [
     ['1', 'Sudation jamais gênante', 'Pas de traitement'],
     ['2', 'Tolérable, parfois gênante', 'Mesures locales'],
     ['3', 'Peu tolérable, souvent gênante', 'Traitement local renforcé'],
     ['4', 'Intolérable, toujours gênante', 'Glycopyrronium, toxine, avis spécialisé'],
    ]) + P('Un score isolé ne suffit pas à poser le diagnostic. Une baisse d’au moins 2 points est le critère d’efficacité des essais d’Axhidrox® ; les critères d’une cause secondaire (ESC, OMS, ESE) se trouvent dans sa monographie.', 3, 8)))
PTS.append(POINT(8, 'Critères diagnostiques', b8))

# ---------- 9
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Question', 'Examen de référence (gold standard)', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Où transpire-t-on ?', 'Test de Minor (iode-amidon)', 'Cartographie, non quantitatif' + S(3), 'Ne mesure pas la sévérité'],
    ['Combien transpire-t-on ?', 'Gravimétrie', 'Seuil d’étude 50 mg par aisselle en 5 min' + S(3), 'Contexte reproductible exigé'],
    ['Hypoglycémie ?', 'Glycémie veineuse', 'Seuil d’action < 4,0 mmol/L' + S(14), 'Lecteur capillaire moins exact'],
    ['Hyperthyroïdie ?', 'TSH puis T4 libre (test réflexe)', 'Stratégie suisse 2025' + S(17), 'Valeurs liées à la méthode'],
    ['Infarctus ?', 'Troponine ultrasensible et ECG', 'Cinétique 0 h / 1 h' + S(22), 'Un premier résultat isolé ne suffit pas'],
    ['Tuberculose active ?', 'Culture des expectorations ; PCR Xpert', 'Xpert : sensibilité ≈ 91 %, spécificité ≈ 96 % contre la culture' + S(116), 'Le test IGRA ne prouve pas la maladie'],
    ['VIH ?', 'Test de 4e génération puis confirmation', 'La sensibilité dépasse 99 % après la fenêtre (algorithme OFSP 2025)' + S(117, 20), 'Fenêtre après exposition'],
    ['Lymphome ?', 'Biopsie ganglionnaire', 'Seule preuve' + S(24), 'Pas de diagnostic sans histologie'],
    ['Phéochromocytome ?', 'Métanéphrines plasmatiques libres', 'Préparation, posture couchée 20 min' + S(64, 65), 'Interférences médicamenteuses'],
   ]), 'fenetre') +
  F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Aucun bilan', 'Forme primaire typique', 'Profil focal, bilatéral, jeune, sans signe général' + S(3)],
    ['Première, devant une forme secondaire', 'Glycémie, NFS, CRP, TSH', 'Sueurs généralisées, nocturnes ou récentes' + S(33, 34, 35)],
    ['Selon le contexte', 'ECG et troponine ; hémocultures ; radiographie du thorax', 'Oppression ; fièvre avec prothèse ; toux'],
    ['Seconde', 'Échocardiographie, PCR, test VIH, métanéphrines', 'Hypothèse précise ou première anomalie' + S(18, 20, 29)],
    ['Troisième', 'TDM, TEP, biopsie', 'Adénopathie, masse, bilan d’extension' + S(24)],
   ]), 'fenetre') +
  F('9.c Prescription : indication, moment, préparation',
   UL(['La glycémie se mesure pendant l’épisode, avant tout sucre si c’est possible sans retard.',
       'Les hémocultures (2 à 3 paires) se prélèvent avant l’antibiotique, selon la technique HUG 2025.',
       'Les métanéphrines se prélèvent après 20 minutes couché, selon les consignes du laboratoire.',
       'Les expectorations pour tuberculose suivent le guide suisse 2024 et les précautions de transmission.']), 14, 18, 65, 89) +
  F('9.d Interprétation',
   TAB(['Résultat', 'Signification', 'Conduite'], [
    ['Négatif dans les bonnes conditions', 'Hypothèse peu probable', 'Autre branche, selon la clinique'],
    ['Positif', 'Hypothèse confirmée ou très probable', 'Monographie correspondante'],
    ['Limite ou intermédiaire (zone grise)', 'Interférence ou stade précoce', 'Contrôle préparé ou répété'],
    ['Discordant avec la clinique', 'Méthode ou moment inadapté', 'Ne pas clore l’hypothèse ; examen de référence'],
   ]) + P('Un examen négatif ne ferme une hypothèse que dans les conditions validées de sa méthode.', 22, 29), 'fenetre') +
  F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Test de grossesse d’abord ; échographie et IRM sans gadolinium préférées'],
    ['DFGe < 30 mL/min/1,73 m²', 'Pas de produit de contraste iodé sans nécessité (ESUR 2025)' + S(67)],
    ['Allergie au produit iodé', 'IRM ou échographie'],
    ['Enfant', 'Références adaptées à l’âge'],
    ['Stimulateur cardiaque', 'Compatibilité vérifiée avant IRM'],
   ]), 'fenetre'))
b9 = (P('Une forme primaire typique ne demande ni biologie ni imagerie systématique. '
        'Devant une forme secondaire, le médecin demande d’abord glycémie, NFS, CRP et TSH, puis des examens orientés par l’hypothèse. '
        'Il interprète chaque valeur avec la référence du laboratoire.', 3, 17, 33) + P9)
PTS.append(POINT(9, 'Examens complémentaires', b9))

# ---------- 10
b10 = (P('Si le patient est instable, confus ou en douleur thoracique, alors le médecin traite l’urgence avant toute autre question. '
         'Si la sueur est focale, bilatérale, jeune et cesse la nuit, alors il retient une forme primaire probable, mais une sueur généralisée ou nocturne impose un bilan. '
         'Si un examen est négatif hors de ses conditions, alors la branche reste ouverte.', 3, 14, 22) +
  F('Embranchements et décisions',
    TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
     ['Glycémie < 4,0 mmol/L', 'Correction, recherche de la cause', 'Glycémie à 15 min'],
     ['Oppression, ECG anormal ou troponine élevée', 'Filière SCA', 'Troponine répétée'],
     ['Fièvre et prothèse ou souffle', 'Hémocultures, échocardiographie', 'Résultats et ETO'],
     ['Peau sèche, chaleur, confusion', 'Refroidissement, 144', 'Température'],
     ['Toux > 2–3 semaines, sueurs nocturnes', 'Radiographie, expectorations', 'PCR, culture'],
     ['Adénopathie persistante', 'Biopsie', 'Histologie'],
     ['Accès de céphalée et palpitations', 'Métanéphrines', 'Imagerie si positif'],
     ['Femme de 45–55 ans, bouffées', 'Symptômes vasomoteurs probables', 'Réévaluation si signes généraux'],
     ['Forme primaire typique', 'Traitement local par paliers', 'HDSS à 4–8 semaines'],
    ]) + P('La disparition des sueurs ne ferme pas seule une branche dangereuse.', 3, 5)))
PTS.append(POINT(10, 'Arbre décisionnel', b10))

# ---------- 11
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Dose et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Glycopyrronium, Axhidrox® crème (antimuscarinique topique)', 'Hyperhidrose axillaire primaire sévère de l’adulte : 2 pressions par aisselle le soir, 1 fois par jour pendant 4 semaines, puis 2 fois par semaine', 'Sécheresse buccale, vision trouble, rétention urinaire ; contre-indiqué en cas de glaucome, de myasthénie, d’iléus ; interaction avec les autres anticholinergiques'],
   ['Toxine botulique A, BOTOX® (inhibiteur de la libération d’acétylcholine)', '50 unités par aisselle en intradermique ; pas avant 16 semaines ; effet de 4 à 7 mois', 'Diffusion de l’effet (faiblesse, dysphagie, dyspnée) ; contre-indiquée en cas d’infection au site ; interaction avec les aminosides'],
   ['Toxine botulique A, Dysport® (même classe)', '100 unités par aisselle ; pas avant 12 semaines', 'Mêmes risques ; unités non interchangeables avec celles de BOTOX®'],
   ['Glucagon, GlucaGen® (hormone hyperglycémiante)', 'Adulte et enfant > 25 kg : 1 mg SC ou IM ; < 25 kg : 0,5 mg', 'Nausées ; contre-indiqué en cas de phéochromocytome ; inefficace si le glycogène est épuisé'],
   ['Glucose 40 %, Glucosum Bichsel® (soluté hypertonique)', 'Protocole HUG 2022 : 32 g IV lent en 3–5 min, puis relais', 'Nécrose en cas d’extravasation ; hyperglycémie'],
   ['Oxybutynine (anticholinergique oral)', 'Hors indication suisse pour l’hyperhidrose', 'Confusion chez la personne âgée'],
  ]) + P('Pharmacodynamie : le glycopyrronium inhibe les récepteurs muscariniques de la glande, et la toxine bloque la libération d’acétylcholine. '
         'Pharmacocinétique : le glycopyrronium atteint l’équilibre en 7 à 14 jours, avec une élimination surtout rénale ; la demi-vie du glucagon est de 3 à 6 minutes.', 8, 9, 10, 11, 12, 13, 14))
b11 = (P('La prise en charge traite d’abord l’urgence et la cause secondaire, parce qu’un antitranspirant masquerait la maladie. '
         'Dans la forme primaire, elle réduit la gêne par paliers, du topique à la toxine, puis à la chirurgie. '
         'Le choix dépend de la région, du score HDSS, des contre-indications et de l’autorisation suisse.', 3, 8, 9, 14) +
  F('11.A Buts : formes compliquées et non compliquées',
    P('Forme compliquée (hypoglycémie sévère, SCA, sepsis, coup de chaleur) : c’est une urgence vitale, avec appel du 144 et traitement de la cause.', 5, 14, 22) +
    P('Dans la forme non compliquée, le but est un objectif fonctionnel, par exemple écrire sans mouiller la feuille, avec une baisse du HDSS d’au moins 2 points.', 3, 8)) +
  F('11.B Moyens',
    F('Mesures générales et ordre (forme primaire)',
      OL(['Vêtements respirants, changes, soins de la peau.', 'Chlorure d’aluminium le soir sur peau sèche.',
          'Glycopyrronium topique (aisselles, adulte).', 'Ionophorèse pour les paumes et les plantes.',
          'Toxine botulique A après test de Minor.', 'Sympathectomie thoracique en dernier recours, après information sur la sudation compensatrice.']), 3, 4, 8, 9) +
    MED +
    F('Volets social et professionnel',
      UL(['La LAMal (art. 25 et 32) prend en charge les prestations efficaces, appropriées et économiques ; la LAA (art. 6 et 9) s’applique à une maladie professionnelle ; la LAI (art. 7, 8 et 28) intervient si la capacité de gain baisse.',
          'Le certificat d’arrêt de travail suit le guide ASSM/FMH ; l’OFAS propose une détection précoce en cas d’arrêt prolongé.',
          'La conduite automobile est déconseillée après une hypoglycémie sévère (SSED/SSML 2025).']), 25, 40, 41, 42, 43, 44) +
    F('Situations spéciales',
      TAB(['Situation', 'Adaptation'], [
       ['Grossesse et allaitement', 'Toxine et glycopyrronium évités sans nécessité ; ménopause hors sujet'],
       ['Personne âgée', 'Anticholinergiques évités (confusion, chute), anhidrose à la chaleur surveillée'],
       ['Enfant et adolescent', 'Axhidrox® non autorisé avant 18 ans (étude 2026 exploratoire)'],
       ['Insuffisance rénale (DFGe < 30)', 'Glycopyrronium avec prudence'],
       ['Insuffisance hépatique', 'Données limitées : avis spécialisé avant tout anticholinergique oral'],
       ['Travail à la chaleur', 'Pauses, boissons, prévention Suva'],
      ]), 8, 32, 47), 'fenetre') +
  F('11.C Surveillance et critères de sortie',
    TAB(['Quoi', 'Quand', 'Seuil d’action'], [
     ['Score HDSS', '4 à 8 semaines après chaque palier', 'Baisse < 2 points : palier suivant'],
     ['Effets anticholinergiques', 'À chaque visite', 'Rétention urinaire, vision trouble : arrêt'],
     ['Glycémie après hypoglycémie', 'Toutes les 2–3 h, 48 h sous gliclazide', 'Récidive : hospitalisation'],
     ['Signes généraux', 'À chaque visite', 'Sueurs nocturnes, perte de poids : bilan'],
    ]) + H4('Critères de sortie, un par un') +
    OL(['La cause urgente est traitée.', 'La glycémie, la température et l’hémodynamique sont stables.', 'Le patient connaît les signes d’alerte et le suivi est fixé.']), 14, 97) +
  F('11.D Pronostic, guérison et recherche 2026',
    P('Le pronostic suit la cause : une forme primaire est contrôlée mais rarement guérie, et le traitement est répété. La recherche 2026 étend l’étude du glycopyrronium aux adolescents, sans étendre l’indication suisse.', 3, 47)))
PTS.append(POINT(11, 'Prise en charge', b11))

# ---------- 12
b12 = (P('La prévention primaire limite l’exposition à la chaleur et protège les personnes qui transpirent peu, selon les conseils suisses de canicule. '
         'La prévention secondaire reconnaît tôt une cause traitable par des tests ciblés, comme le dépistage du VIH selon l’OFSP. '
         'La prévention tertiaire réduit les complications cutanées, les récidives d’hypoglycémie et l’impact professionnel.', 5, 20, 30) +
  F('Niveaux de prévention',
    TAB(['Niveau', 'Mesure', 'Source'], [
     ['Primaire', 'Plan canicule, pauses au travail, hydratation, vêtements adaptés', 'Canton de Vaud, Suva' + S(30, 32)],
     ['Secondaire', 'Dépistage ciblé du VIH et de la tuberculose, glycémie chez le diabétique', 'OFSP' + S(18, 20)],
     ['Tertiaire', 'Soins de peau, éducation à l’hypoglycémie, réinsertion', 'JBDS, OFAS' + S(15, 40)],
    ])))
PTS.append(POINT(12, 'Prévention', b12))

# ---------- 13
b13 = P('Le médecin cherche d’abord une hypoglycémie, une ischémie, une infection grave ou un coup de chaleur. '
        'Il sait qu’une peau sèche à la chaleur est un danger, pas un signe rassurant. '
        'Il retient une forme primaire sur la clinique, sans bilan systématique. '
        'Il demande des examens orientés devant une forme généralisée, nocturne ou récente. '
        'Il respecte les doses et les unités propres à chaque spécialité suisse. '
        'Il suit le score HDSS et rouvre le diagnostic si le profil change.', 3, 5, 8, 9, 14, 22)
PTS.append(POINT(13, 'Points clés', b13))

# ---------- 14
b14 = (TAB(['Piège', 'Bonne réponse'], [
   ['Prescrire un antitranspirant à un patient pâle et confus.', 'Non : glycémie et évaluation vitale d’abord.'],
   ['Une peau sèche rassure.', 'Non : une anhidrose à la chaleur expose au coup de chaleur.'],
   ['Des sueurs nocturnes signent un lymphome.', 'Non : seule la biopsie le prouve.'],
   ['Un test IGRA positif prouve une tuberculose active.', 'Non : il faut la PCR et la culture.'],
   ['100 unités de BOTOX® égalent 100 unités de Dysport®.', 'Non : les unités ne sont pas interchangeables.'],
   ['Une ETT normale exclut l’endocardite.', 'Non : l’ETO est souvent nécessaire.'],
   ['Donner du glucagon en cas de phéochromocytome.', 'Non : c’est une contre-indication de l’AIPS.'],
  ]) + P('Ces pièges entraînent le raisonnement et ne sont pas des questions officielles de l’examen fédéral.', 1, 9, 10, 12, 18, 24, 29))
PTS.append(POINT(14, 'Pièges d’examen', b14))

# ---------- Bloc 2 : liste des dix diagnostics
L = lambda f, t: f'<a href="{f}">{t}</a>'
DXL = [
 ('DX.1', 'Syndrome coronarien aigu', 'LOT_001_DX1_Syndrome_coronarien_aigu_AUDITÉ.html', PR('STEMI 5–10 % des douleurs thoraciques aux urgences', 111), 'Urgence : la diaphorèse peut accompagner une ischémie sans douleur, surtout chez la personne âgée ou diabétique.', (22, 111)),
 ('DX.2', 'Hypoglycémie', 'LOT_001_DX2_Hypoglycemie_AUDITÉ.html', PR('diabète ≈ 5 % des adultes en Suisse', 105), 'Urgence immédiatement vérifiable par une glycémie et corrigée en quelques minutes.', (14, 15, 105)),
 ('DX.3', 'Endocardite infectieuse', 'LOT_001_DX3_Endocardite_infectieuse_AUDITÉ.html', PR('3–10 / 100 000 par an (Europe)', 110), 'Infection grave des valves, à rechercher par hémocultures avant tout antibiotique.', (29, 110)),
 ('DX.4', 'Hyperhidrose focale primaire', 'LOT_001_DX4_Hyperhidrose_focale_primaire_AUDITÉ.html', PR('≈ 3 % (HUG)', 4), 'Cause la plus fréquente, retenue seulement après exclusion d’une cause secondaire.', (3, 4)),
 ('DX.5', 'Symptômes vasomoteurs de la ménopause', 'LOT_001_DX5_Menopause_symptomes_vasomoteurs_AUDITÉ.html', PR('≈ 80 % des femmes en transition', 112), 'Bouffées de chaleur et sueurs nocturnes vers 51 ans, sans exclure une autre cause.', (21, 53, 112)),
 ('DX.6', 'Hyperthyroïdie', 'LOT_001_DX6_Hyperthyroidie_AUDITÉ_a.html', PR('≈ 0,75 % (Europe)', 106), 'Thermogenèse accrue, confirmée par la TSH et le test réflexe.', (17, 106)),
 ('DX.7', 'Tuberculose', 'LOT_001_DX7_Tuberculose_AUDITÉ.html', PR('6,0 / 100 000 par an (Suisse, 2025)', 19), 'Sueurs nocturnes avec toux et perte de poids ; confirmation microbiologique et isolement.', (18, 19)),
 ('DX.8', 'Infection par le VIH', 'LOT_001_DX8_VIH_AUDITÉ.html', PR('≈ 4 / 100 000 par an (Suisse)', 107), 'Primo-infection fébrile ou stade avancé ; test de 4e génération selon l’OFSP.', (20, 107)),
 ('DX.9', 'Lymphome de Hodgkin', 'LOT_001_DX9_Lymphome_de_Hodgkin_AUDITÉ.html', PR('≈ 3,2 / 100 000 par an (Suisse)', 108), 'Adénopathie indolore et symptômes B ; histologie obligatoire.', (24, 108)),
 ('DX.10', 'Phéochromocytome et paragangliome', 'LOT_001_DX10_Pheochromocytome_AUDITÉ.html', PR('0,2–0,6 % des hypertendus', 109), 'Accès de céphalée, palpitations et sueurs ; métanéphrines avant imagerie.', (12, 23, 109)),
]
b15 = (P('Les dix diagnostics suivent un ordre de sécurité : les urgences d’abord, puis les causes focales, hormonales, infectieuses, lymphoïdes et catécholaminergiques. '
         'Le rang est pédagogique et ne classe pas la fréquence, car aucune étude suisse ne chiffre la part de chaque cause.', 3, 7) +
  TAB(['Rang', 'Diagnostic et fréquence', 'Pourquoi il figure dans la liste'],
      [[d, L(f, n) + pr, j + S(*s)] for d, n, f, pr, j, s in DXL]) +
  F('Tableau comparatif : signe, examen, mécanisme, décision',
    TAB(['Diagnostic', 'Signe clé', 'Examen clé', 'Mécanisme', 'Décision immédiate'], [
     ['SCA', 'Sueurs froides et oppression', 'ECG, troponine', 'Ischémie', 'Filière urgente'],
     ['Hypoglycémie', 'Sueurs, faim, confusion', 'Glycémie', 'Décharge d’adrénaline', 'Sucre ou glucagon'],
     ['Endocardite', 'Fièvre et souffle', 'Hémocultures, échocardiographie', 'Infection valvulaire', 'Hôpital'],
     ['Hyperhidrose primaire', 'Sueur focale, cesse la nuit', 'Clinique, test de Minor', 'Commande cholinergique', 'Paliers locaux'],
     ['Ménopause', 'Bouffées de chaleur', 'Clinique', 'Thermostat instable', 'Traitement selon la balance'],
     ['Hyperthyroïdie', 'Thermophobie, tachycardie', 'TSH', 'Thermogenèse', 'Bilan de la cause'],
     ['Tuberculose', 'Toux et sueurs nocturnes', 'PCR, culture', 'Infection mycobactérienne', 'Isolement, prélèvements'],
     ['VIH', 'Fièvre après exposition', 'Test de 4e génération', 'Infection virale', 'Test et conseil'],
     ['Hodgkin', 'Adénopathie, symptômes B', 'Biopsie', 'Prolifération lymphoïde', 'Avis hématologique'],
     ['PPGL', 'Accès adrénergiques', 'Métanéphrines', 'Catécholamines', 'Pas de bêtabloquant seul'],
    ]), 3, 14, 18, 20, 22, 23, 24) +
  F('Algorithme discriminant',
    OL(['Instabilité, confusion, oppression ? Urgence : glycémie, ECG, 144.',
        'Fièvre ? Endocardite, tuberculose, VIH, autre infection.',
        'Sueurs nocturnes avec ganglions ou perte de poids ? Lymphome, tuberculose.',
        'Accès avec céphalée et palpitations ? Phéochromocytome, hyperthyroïdie, panique.',
        'Femme de 45–55 ans avec bouffées ? Ménopause.',
        'Sueur focale, bilatérale, jeune, nulle la nuit ? Hyperhidrose primaire.']) +
    P('Plusieurs branches peuvent coexister, et une amélioration sous traitement sudoral ne valide pas une cause primaire.', 3, 5, 7, 14, 22)))
PTS.append(f'<section class="point" id="ssp-p15"><h3><strong>Bloc 2 · Liste des dix diagnostics du LOT 1</strong></h3>\n{b15}</section>\n')

AJ = ' Référence ajoutée lors de l’audit du 24 octobre 2026.'
SOURCES = sorted(SA.items()) + [
 (105, 'Office fédéral de la statistique (OFS). Enquête suisse sur la santé 2022 : diabète déclaré.' + AJ),
 (106, 'Garmendia Madariaga A et al. The incidence and prevalence of thyroid dysfunction in Europe: a meta-analysis. J Clin Endocrinol Metab 2014;99:923–931.' + AJ),
 (107, 'Office fédéral de la santé publique (OFSP). VIH, syphilis, gonorrhée et chlamydiose en Suisse : situation épidémiologique 2023. Bulletin OFSP.' + AJ),
 (108, '<a href="https://cancer-monitorage.bfs.admin.ch/fr/detail/C81/">OFS et ONEC · Monitorage du cancer en Suisse, lymphome de Hodgkin C81</a>. Moyennes annuelles 2018–2022.' + AJ),
 (109, 'Lenders JWM et al. Pheochromocytoma and paraganglioma: an Endocrine Society clinical practice guideline. J Clin Endocrinol Metab 2014;99:1915–1942.' + AJ),
 (110, 'Delgado V et al. 2023 ESC Guidelines for the management of endocarditis. Eur Heart J 2023;44:3948–4042.' + AJ),
 (111, 'Collet JP et al. 2020 ESC Guidelines for the management of acute coronary syndromes in patients presenting without persistent ST-segment elevation. Eur Heart J 2021;42:1289–1367 (répartition des diagnostics finaux des douleurs thoraciques aiguës).' + AJ),
 (112, 'The Menopause Society. The 2023 nonhormone therapy position statement. Menopause 2023;30:573–590.' + AJ),
 (113, 'de Jonge P et al. Cross-national epidemiology of panic disorder and panic attacks in the World Mental Health Surveys. Depress Anxiety 2016;33:1155–1177.' + AJ),
 (114, 'Marcy TR, Britton ML. Antidepressant-induced sweating. Ann Pharmacother 2005;39:748–752.' + AJ),
 (116, 'Zifodya JS et al. Xpert Ultra versus Xpert MTB/RIF for pulmonary tuberculosis and rifampicin resistance in adults with presumptive pulmonary tuberculosis. Cochrane Database Syst Rev 2021;2:CD009593.' + AJ),
 (117, 'Branson BM et al. Laboratory testing for the diagnosis of HIV infection: updated recommendations. CDC et APHL ; 2014.' + AJ),
 (115, 'OFS, NICER, Registre du cancer de l’enfant. Rapport suisse sur le cancer 2021 : lymphomes.' + AJ),
]
CTX = {'_prefixe': 'Devant une transpiration anormale',
 'minor': 'Le test iode-amidon de Minor cartographie la zone qui transpire ; il ne mesure pas la sévérité.',
 'grav': 'La gravimétrie quantifie la sueur ; le seuil de 50 mg par aisselle en 5 minutes est un seuil d’étude.',
 'gly': 'La glycémie se mesure immédiatement devant des sueurs avec malaise ; < 4,0 mmol/L impose la correction.',
 'ecg': 'L’ECG recherche une ischémie devant des sueurs froides avec oppression.',
 'tropo': 'La troponine ultrasensible s’interprète dans sa cinétique, avec l’ECG.',
 'nfs': 'L’hémogramme cherche une infection ou une hémopathie devant des sueurs secondaires.',
 'crp': 'Une CRP élevée oriente vers une cause inflammatoire ou infectieuse.',
 'tsh': 'La TSH, avec test réflexe, écarte ou confirme une hyperthyroïdie.',
 't4t3': 'La T4 libre est ajoutée par le laboratoire si la TSH est basse.',
 'hemoc': 'Les hémocultures se prélèvent avant l’antibiotique si une endocardite est possible.',
 'echocoeur': 'L’échocardiographie recherche une végétation ; une ETT normale n’exclut pas.',
 'radio': 'La radiographie du thorax cherche une tuberculose ou une masse médiastinale.',
 'igra': 'Le test IGRA montre une infection tuberculeuse mais ne prouve pas une maladie active.',
 'pcr': 'La PCR des expectorations confirme une tuberculose active.',
 'vih': 'Le test VIH de 4e génération suit l’algorithme OFSP 2025.',
 'biopsie': 'La biopsie ganglionnaire est la seule preuve d’un lymphome.',
 'meta': 'Les métanéphrines plasmatiques libres se dosent devant des accès adrénergiques.',
 'tdm': 'La TDM fait le bilan d’une masse ou d’une adénopathie profonde.',
 'tep': 'La TEP-TDM fait le bilan d’extension d’un lymphome.',
 'gonado': 'La FSH n’est utile qu’en cas de doute sur la ménopause.',
 'creat': 'Le DFGe guide le produit de contraste et le glycopyrronium.',
 'hcg': 'Le test de grossesse précède l’imagerie et les traitements.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
