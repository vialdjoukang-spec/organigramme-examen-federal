# -*- coding: utf-8 -*-
"""Générateur du cours corrigé DX.6 (partie 2 : points 7 à 10)."""
from gen_dx6_part1 import *

# ---------------- POINT 7
PTS.append(POINT(7, 'Approche syndromique',
 P('Le tableau associe quatre syndromes : la thyrotoxicose, commune à toutes les causes, le syndrome thyroïdien local, l’orbitopathie et la défaillance d’organes de la crise aiguë thyrotoxique. '
   'Chaque syndrome réunit des signes fonctionnels rapportés par le patient et des signes physiques recherchés par un geste précis. '
   'Le syndrome de thyrotoxicose affirme l’excès hormonal, alors que les syndromes thyroïdien et orbitaire en désignent la cause.', 7, 16, 22) +
 F('<em>7.1 Syndrome de thyrotoxicose</em>',
   TAB(['Signes fonctionnels', 'Signes physiques (geste)', 'Mécanisme'], [
    ['Hypersudation généralisée, intolérance à la chaleur', 'Peau chaude et moite (toucher la paume)', 'La thermogenèse augmente.'],
    ['Palpitations, dyspnée d’effort', 'Tachycardie, rythme irrégulier (pouls, auscultation)', 'La sensibilité adrénergique et la contractilité augmentent.'],
    ['Amaigrissement malgré une polyphagie', 'Perte de poids mesurée', 'Le catabolisme dépasse les apports.'],
    ['Nervosité, insomnie, irritabilité', 'Tremblement fin des extrémités (bras tendus)', 'Le tonus adrénergique central et périphérique augmente.'],
    ['Faiblesse à la montée des escaliers', 'Déficit proximal (lever de chaise)', 'La protéolyse musculaire augmente.'],
    ['Selles fréquentes', '—', 'Le transit intestinal s’accélère.'],
    ['Oligoménorrhée', '—', 'La SHBG et les œstrogènes circulants augmentent.'],
   ]) + P('Chez la personne âgée, la forme apathique associe asthénie, amaigrissement et fibrillation atriale sans nervosité ni sueurs marquées.', 22)) +
 F('<em>7.2 Syndrome thyroïdien local</em>',
   TAB(['Signes fonctionnels', 'Signes physiques (geste)', 'Mécanisme'], [
    ['Gêne cervicale, dysphagie, dyspnée en décubitus', 'Goitre diffus ou nodulaire à la palpation ; signe de Pemberton (bras levés : congestion du visage)', 'La glande augmente de volume et comprime.'],
    ['Douleur cervicale irradiant à l’oreille', 'Thyroïde ferme et très douloureuse', 'L’inflammation folliculaire distend la capsule.'],
    ['—', 'Souffle ou frémissement thyroïdien (auscultation)', 'Le débit sanguin glandulaire augmente.'],
   ])) +
 F('<em>7.3 Syndrome orbitaire basedowien</em>',
   TAB(['Signes fonctionnels', 'Signes physiques (geste)', 'Mécanisme'], [
    ['Sensation de sable, larmoiement, photophobie', 'Rougeur conjonctivale, chémosis (inspection)', 'La surface oculaire s’expose et s’enflamme.'],
    ['Douleur rétro-oculaire, douleur aux mouvements', 'CAS ≥ 3/7', 'Les tissus orbitaires s’enflamment.'],
    ['Diplopie', 'Limitation de la motilité, surtout en élévation', 'Les muscles droits inférieurs et médiaux s’épaississent puis se fibrosent.'],
    ['Baisse de vision, couleurs ternes', 'Acuité diminuée, déficit pupillaire afférent, vision des couleurs altérée', 'Le nerf optique est comprimé à l’apex orbitaire.'],
   ]) + P('L’EUGOGO classe l’orbitopathie en légère, modérée à sévère, ou menaçant la vision ; seule la dernière impose un traitement en urgence.', 25)) +
 F('<em>7.4 Syndrome de défaillance de la crise aiguë thyrotoxique</em>',
   TAB(['Signes fonctionnels', 'Signes physiques (geste)', 'Mécanisme'], [
    ['Agitation, confusion, délire', 'Score de Glasgow, orientation', 'L’excès hormonal et la fièvre altèrent le fonctionnement cérébral.'],
    ['Nausées, vomissements, diarrhée, douleurs abdominales', 'Ictère, hépatomégalie', 'L’hypermotilité et la congestion hépatique s’installent.'],
    ['Dyspnée', 'Fièvre souvent > 38,5 °C, tachycardie > 130/min, fibrillation atriale, râles crépitants', 'Le cœur à haut débit décompense.'],
   ])) +
 F('<em>7.5 Formes cliniques particulières</em>',
   P(f'Chez la personne âgée, la {T("cardiothyréose", "La cardiothyréose regroupe la fibrillation atriale et l’insuffisance cardiaque à haut débit induites par la thyrotoxicose, surtout chez la personne âgée ou cardiaque.")} domine, souvent sans signe adrénergique marqué. '
     f'De plus, la {T("paralysie périodique thyrotoxique", "Des accès de paralysie flasque avec hypokaliémie surviennent après un repas riche en glucides ou un effort ; ils touchent surtout des hommes d’origine asiatique.")} provoque des paralysies brutales avec hypokaliémie. '
     'Enfin, la myopathie thyrotoxique entraîne une faiblesse proximale, tandis que l’hypercalcémie modérée accompagne parfois une thyrotoxicose sévère.', 22, 16))))

# ---------------- POINT 8
PTS.append(POINT(8, 'Diagnostic positif et critères',
 P('Le diagnostic d’hyperthyroïdie manifeste est biologique : la TSH est inférieure à la référence du laboratoire et la T4 libre ou la T3 libre est élevée (ETA 2018, ATA 2016). '
   'Le diagnostic de maladie de Basedow est certain lorsque la thyrotoxicose s’associe à des TRAb positifs ou à une orbitopathie typique ; la crise se pose sur un score de Burch-Wartofsky ≥ 45 ou sur les critères japonais de 2012. '
   'Une TSH basse isolée, un goitre, des symptômes adrénergiques ou des anticorps anti-TPO positifs ne suffisent pas à poser le diagnostic ni à en désigner la cause.', 1, 22, 27, 28) +
 F('Critères diagnostiques par entité',
   TAB(['Entité', 'Critère (société, année)', 'Seuil', 'Ce qui ne suffit pas'], [
    ['Hyperthyroïdie manifeste', 'TSH basse avec T4 libre ou T3 libre élevée (ETA 2018, ATA 2016)', 'Références locales, par exemple TSH 0,27–4,20 mUI/L, T4 libre 12,0–22,0 pmol/L, T3 libre 3,1–6,8 pmol/L', 'Une TSH basse seule'],
    ['Hyperthyroïdie infraclinique', 'TSH basse, hormones libres normales, confirmée à 6–12 semaines (ETA 2015)', 'Grade 1 : TSH 0,1–0,39 mUI/L ; grade 2 : < 0,1 mUI/L', 'Un dosage unique pendant une maladie aiguë'],
    ['Maladie de Basedow', 'Thyrotoxicose et TRAb positifs, ou orbitopathie typique (ETA 2018)', 'TRAb au-dessus du seuil de la trousse', 'Des anti-TPO positifs'],
    ['Adénome ou goitre toxique', 'Thyrotoxicose et nodule(s) chaud(s) à la scintigraphie', 'Fixation focale avec extinction du reste', 'Un nodule à l’échographie'],
    ['Thyroïdite subaiguë', 'Cou douloureux, VS ou CRP élevée, fixation nulle', '—', 'Une fièvre isolée'],
    ['Thyrotoxicose à l’amiodarone', 'Type 1 : hyperproduction, Doppler conservé ; type 2 : destruction, Doppler sans flux et fixation nulle (ETA 2018)', '—', 'Une T4 libre élevée avec TSH normale, fréquente sous amiodarone'],
    ['Crise aiguë thyrotoxique', 'Score de Burch-Wartofsky (1993) ou critères de la Japan Thyroid Association (2012)', 'BWPS < 25 improbable, 25–44 imminente, ≥ 45 très probable', 'Un taux hormonal très élevé sans défaillance'],
    ['Orbitopathie active', 'Score d’activité clinique (Mourits 1997, EUGOGO 2021)', 'CAS ≥ 3/7', 'Une rétraction palpébrale isolée'],
   ])) +
 F('Score de Burch-Wartofsky (BWPS)',
   TAB(['Critère', 'Points'], [
    ['Température 37,2–37,7 / 37,8–38,2 / 38,3–38,8 / 38,9–39,3 / 39,4–39,9 / ≥ 40,0 °C', '5 / 10 / 15 / 20 / 25 / 30'],
    ['Système nerveux central : agitation légère / délire, psychose, léthargie / convulsions, coma', '10 / 20 / 30'],
    ['Digestif et hépatique : diarrhée, nausées, vomissements, douleurs / ictère inexpliqué', '10 / 20'],
    ['Fréquence cardiaque 90–109 / 110–119 / 120–129 / 130–139 / ≥ 140 par minute', '5 / 10 / 15 / 20 / 25'],
    ['Insuffisance cardiaque : œdèmes / râles des bases / œdème pulmonaire', '5 / 10 / 15'],
    ['Fibrillation atriale', '10'],
    ['Facteur déclenchant identifié', '10'],
   ]) + P('Un total ≥ 45 rend la crise très probable, 25 à 44 la fait considérer comme imminente et < 25 la rend improbable ; le score reste sensible mais peu spécifique.', 28, 2)) +
 F('Critères de la Japan Thyroid Association (2012)',
   P('La crise est certaine (TS1) lorsque la thyrotoxicose associe une atteinte du système nerveux central à au moins un critère : fièvre ≥ 38 °C, tachycardie ≥ 130/min, insuffisance cardiaque, atteinte digestive ou hépatique. '
     'Elle est aussi certaine sans atteinte neurologique lorsque trois de ces quatre critères sont présents. '
     'Elle est suspectée (TS2) lorsque deux de ces critères accompagnent la thyrotoxicose.', 27))))

# ---------------- POINT 9
PTS.append(POINT(9, 'Examens complémentaires',
 P('L’hyperthyroïdie n’a pas d’examen de référence unique : le couple TSH et T4 libre la définit, et les TRAb servent de référence pour la maladie de Basedow, avec une sensibilité d’environ 97 % et une spécificité d’environ 98 %. '
   'En première intention, le médecin dose la TSH, puis la T4 libre, et la T3 libre si la T4 libre est normale. '
   'En deuxième intention, il dose les TRAb et demande une échographie thyroïdienne avec Doppler, puis une scintigraphie si les TRAb sont négatifs ou si des nodules sont présents. '
   'Avant tout ATS, il complète le bilan de retentissement par un ECG, une NFS et un bilan hépatique.', 1, 10, 22, 13, 14) +
 F('<em>9.a Examens de référence (gold standard)</em>',
   TAB(['Question', 'Examen de référence', 'Performance', 'Limite'], [
    ['Y a-t-il une thyrotoxicose ?', 'TSH puis T4 libre (± T3 libre)', 'La TSH est l’indicateur le plus sensible de l’excès hormonal.', 'Une maladie aiguë, des corticoïdes ou le premier trimestre abaissent la TSH.'],
    ['Est-ce une maladie de Basedow ?', 'TRAb de 2e ou 3e génération', 'Sensibilité ≈ 97 %, spécificité ≈ 98 %', 'La biotine donne de faux positifs.'],
    ['Est-ce une hyperproduction ou une fuite ?', 'Scintigraphie thyroïdienne (99mTc ou 123I)', 'La fixation nulle sépare les thyroïdites des hyperthyroïdies.', 'La grossesse, l’allaitement et la surcharge iodée l’empêchent.'],
    ['Y a-t-il une crise ?', 'Aucun examen : le diagnostic est clinique (BWPS, JTA)', '—', 'Les taux hormonaux ne distinguent pas la crise.'],
   ])) +
 F('<em>9.b Première intention : prescrire et interpréter</em>',
   P('L’indication est une suspicion clinique, une fibrillation atriale, une ostéoporose inexpliquée, un traitement par amiodarone ou lithium, ou une grossesse symptomatique. '
     'Le prélèvement ne demande pas de jeûne et peut se faire à tout moment de la journée ; la biotine doit être arrêtée au moins 48 h avant. '
     'Sous ATS, le contrôle se fait sur la T4 libre et la T3 libre, car la TSH reste freinée plusieurs semaines à plusieurs mois après l’euthyroïdie.', 10, 22, 33) +
   TAB(['Résultat', 'Normal (SI, adulte, LUKS)', 'Seuil', 'Signification', 'Conduite'], [
    ['TSH', '0,27–4,20 mUI/L', '< 0,1 mUI/L : freinage complet', 'Un excès hormonal ou une cause non thyroïdienne freine la TSH.', 'La T4 libre est dosée en réflexe.'],
    ['T4 libre', '12,0–22,0 pmol/L', 'Au-dessus de la référence', 'La thyrotoxicose est manifeste.', 'Les TRAb et l’échographie recherchent la cause.'],
    ['T3 libre', '3,1–6,8 pmol/L', 'Au-dessus de la référence avec T4 libre normale', 'La T3-toxicose est présente.', 'La conduite est celle d’une hyperthyroïdie manifeste.'],
   ]) +
   P('Les valeurs normales sont celles du laboratoire du LUKS ; elles dépendent de la méthode, et chaque laboratoire publie les siennes.', 8, 9, 12) +
   TAB(['Cas de figure', 'Interprétation', 'Décision'], [
    ['Positif : TSH basse, T4 libre élevée', 'La thyrotoxicose est confirmée.', 'Les TRAb sont dosés.'],
    ['Négatif : TSH normale', 'La thyrotoxicose est exclue, sauf atteinte hypophysaire ou interférence.', 'Une autre cause de sueurs est recherchée.'],
    ['Limite : TSH 0,1–0,39 mUI/L, hormones normales', 'L’hyperthyroïdie infraclinique de grade 1 ou une cause transitoire est possible.', 'Le dosage est répété à 6–12 semaines.'],
    ['Discordant : TSH normale, T4 libre élevée', 'Une interférence, un adénome thyréotrope ou une résistance hormonale est possible.', 'Le dosage est refait par une autre méthode, puis la sous-unité alpha et l’IRM hypophysaire sont discutées.'],
   ])) +
 F('<em>9.c Alternatives selon le terrain</em>',
   TAB(['Situation', 'Ce qui change', 'Alternative'], [
    ['Grossesse', 'La scintigraphie et l’iode radioactif sont contre-indiqués ; la TSH est physiologiquement basse au premier trimestre.', 'TRAb, échographie, références hormonales propres à la grossesse'],
    ['Allaitement', 'La scintigraphie impose une interruption temporaire de l’allaitement.', 'TRAb et échographie ; scintigraphie seulement si elle change la conduite'],
    ['Enfant', 'Les références hormonales dépendent de l’âge.', 'TRAb et échographie ; scintigraphie rarement nécessaire'],
    ['Produit de contraste iodé récent ou amiodarone', 'La surcharge iodée bloque la captation pendant 1 à 2 mois.', 'Échographie avec Doppler, iodurie, thyroglobuline'],
    ['DFGe < 30 mL/min/1,73 m²', 'La scintigraphie n’est pas contre-indiquée ; le produit de contraste iodé est à éviter.', 'Échographie et scintigraphie'],
    ['Stimulateur cardiaque non compatible IRM', 'L’IRM orbitaire devient impossible.', 'Scanner orbitaire sans injection'],
   ])) +
 F('<em>9.d Deuxième intention et bilan de retentissement</em>',
   TAB(['Examen', 'Indication', 'Résultat attendu', 'Décision'], [
    ['TRAb', 'Toute thyrotoxicose dont la cause n’est pas évidente', 'Positifs dans le Basedow', 'Un TRAb positif dispense de la scintigraphie.'],
    ['Échographie thyroïdienne avec Doppler', 'Goitre, nodule ou TRAb négatifs', 'Hypervascularisation diffuse dans le Basedow ; flux absent dans la thyroïdite', 'Les nodules sont classés EU-TIRADS.'],
    ['Scintigraphie thyroïdienne', 'TRAb négatifs, nodules, doute sur une thyroïdite', 'Diffuse, nodulaire ou nulle', 'Le résultat choisit entre ATS, iode radioactif et abstention.'],
    ['Thyroglobuline', 'Fixation nulle sans douleur ni prise de médicament connue', 'Basse dans la thyrotoxicose factice', 'Une valeur basse confirme l’apport exogène.'],
    ['VS et CRP', 'Cou douloureux', 'Élevées dans la thyroïdite subaiguë', 'L’ATS est inutile.'],
    ['ECG', 'Toute thyrotoxicose', 'Tachycardie sinusale ou fibrillation atriale', 'Le bêtabloquant et l’anticoagulation sont discutés.'],
    ['NFS et bilan hépatique', 'Avant tout ATS, puis devant fièvre, angine ou ictère', 'Neutrophiles et transaminases de référence', 'Une anomalie initiale fait discuter une alternative.'],
    ['Échocardiographie', 'Dyspnée, insuffisance cardiaque, crise', 'Fonction ventriculaire, débit', 'La fraction d’éjection conditionne le choix du bêtabloquant.'],
    ['Ostéodensitométrie', 'Thyrotoxicose prolongée, femme ménopausée, hyperthyroïdie infraclinique de grade 2', 'Perte minérale', 'Le traitement de l’hyperthyroïdie est accéléré.'],
    ['IRM des orbites', 'Orbitopathie modérée à sévère ou doute diagnostique', 'Muscles épaissis, hypersignal STIR', 'Le traitement anti-inflammatoire est discuté.'],
    ['Cytoponction', 'Nodule froid ou non fonctionnel selon EU-TIRADS', 'Classification Bethesda', 'Un nodule chaud ne se ponctionne pas.'],
   ]) + P('Le classement échographique des nodules suit l’EU-TIRADS ; l’activité orbitaire se cote par le score d’activité clinique.', 29, 32, 25))))

# ---------------- POINT 10
PTS.append(POINT(10, 'Arbre décisionnel',
 P('L’arbre commence par la gravité, puis il confirme l’excès hormonal, puis il identifie le mécanisme, puis il choisit le traitement. '
   'Une fièvre avec confusion ou une agranulocytose fébrile impose d’agir avant tout résultat ; une TSH normale exclut la thyrotoxicose, et des TRAb positifs concluent au Basedow sans scintigraphie.', 1, 2, 10, 22) +
 F('Arbre décisionnel étape par étape',
   TAB(['Étape', 'Si…', 'Alors…'], [
    ['1. Gravité', 'Fièvre avec confusion, insuffisance cardiaque ou atteinte digestive', 'Le médecin calcule le BWPS et traite une crise en soins intensifs sans attendre la biologie.'],
    ['1. Gravité', 'Fièvre ou angine sous ATS', 'Il arrête l’ATS et demande une NFS le jour même.'],
    ['1. Gravité', 'Baisse visuelle ou diplopie récente', 'Il adresse le patient en ophtalmologie sans délai.'],
    ['2. Confirmation', 'TSH normale', 'La thyrotoxicose est exclue ; il cherche une autre cause de sueurs.'],
    ['2. Confirmation', 'TSH basse', 'Il dose la T4 libre, puis la T3 libre si la T4 libre est normale.'],
    ['2. Confirmation', 'TSH normale ou haute avec T4 libre élevée', 'Il exclut une interférence (biotine) puis un adénome thyréotrope.'],
    ['3. Mécanisme', 'TRAb positifs', 'Le diagnostic est une maladie de Basedow.'],
    ['3. Mécanisme', 'TRAb négatifs et nodule(s)', 'La scintigraphie recherche un adénome ou un goitre toxique.'],
    ['3. Mécanisme', 'Fixation nulle et cou douloureux', 'Le diagnostic est une thyroïdite subaiguë.'],
    ['3. Mécanisme', 'Fixation nulle, indolore, thyroglobuline basse', 'Le diagnostic est une thyrotoxicose factice.'],
    ['3. Mécanisme', 'Patient sous amiodarone', 'Le Doppler et la fixation séparent le type 1 du type 2.'],
    ['4. Traitement', 'Basedow', 'Il débute un bêtabloquant et un ATS pour 12 à 18 mois, puis il discute un traitement définitif en cas de rechute.'],
    ['4. Traitement', 'Autonomie nodulaire', 'Il prépare un traitement définitif par iode radioactif ou chirurgie après retour à l’euthyroïdie.'],
    ['4. Traitement', 'Thyroïdite', 'Il prescrit un bêtabloquant et un anti-inflammatoire, sans ATS, puis il surveille l’hypothyroïdie.'],
    ['4. Traitement', 'Hyperthyroïdie infraclinique', 'Il traite le grade 2 après 65 ans ou en présence de comorbidités ; sinon il surveille.'],
   ]))))
