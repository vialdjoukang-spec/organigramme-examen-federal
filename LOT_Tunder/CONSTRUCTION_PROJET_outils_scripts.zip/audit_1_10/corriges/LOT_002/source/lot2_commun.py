# -*- coding: utf-8 -*-
"""lot2_commun.py — éléments communs aux générateurs AUDITÉS du LOT 2 (G2 · Tuméfaction, masse et adénopathie).
Importe outils/gen_v7.py (non modifié) ; remplace seulement l'étape d'insertion des fenêtres par la copie locale
outils_local/inserer_fenetres_local.py, qui charge aussi bib_extra/ (calcitonine, Monotest, p16, MDM2)."""
import sys, os, subprocess, re
sys.path.insert(0, '/workspace/audit_1_10/outils')
import gen_v7
from gen_v7 import *
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from src_ALL import SOURCES_ORIG

def pipeline_local(src_html, out, ctx_path, uid):
    r = subprocess.run([gen_v7.PY, os.path.join(HERE, 'outils_local/inserer_fenetres_local.py'), src_html, out, '--ctx', ctx_path,
                        '--portee', 'point', '--max-octets', '100000000', '--prefixe-uid', uid], capture_output=True, text=True)
    if r.returncode: raise SystemExit(r.stderr)
    for tool in (f'{gen_v7.ROOT}/outils/mobile.py', os.path.join(HERE, 'outils_local/sigles_local.py'), f'{gen_v7.ROOT}/outils/charte_v7plus.py'):
        r2 = subprocess.run([gen_v7.PY, tool, out], capture_output=True, text=True)
        if r2.returncode: raise SystemExit(r2.stderr)
        if 'inconnus' in r2.stdout: print('   ', r2.stdout.strip()[-300:])
    return os.path.getsize(out)
gen_v7.pipeline = pipeline_local

LOT = dict(dossier='corriges/LOT_002', lot_titre='LOT 2 · G2 · Tuméfaction, masse et adénopathie')
def META(pref, dx, court, long, fichier, partie, extra=''):
    return dict(LOT, pref=pref, dx=dx, court=court, long=long, fichier=fichier,
        sous_titre=f'PROFILES 2023 · SSP G2 · LOT 2 · Appel B · V7 · Partie {partie} · version AUDITÉE',
        statut=f'Cette version corrige la monographie {dx} du LOT 2 (Appel B, V7, Partie {partie}, révision AUDIT_CORRIGE r2) après audit médical et linguistique selon la charte du 24 octobre 2026. ' + extra)

AJ = ' Référence ajoutée lors de l’audit du 24 octobre 2026.'
# Sources de l'Appel A (numérotation propre à l'Appel A, renumérotée 31–48 pour éviter les collisions)
SOURCES_A = {
 31: 'SMIFK–CIMS. PROFILES 2023 — situations de départ (SSP) G2. <a href="https://smifk-cims.ch/profiles-2023/ssps">smifk-cims.ch</a>. Document consulté le 23 octobre 2026.',
 32: 'Craig A, Emonet S, Junod Perron N. Adénopathie au cabinet. Primary and Hospital Care 2020. <a href="https://archive-ouverte.unige.ch/unige:144612">archive-ouverte.unige.ch</a>. Document consulté le 23 octobre 2026.',
 33: 'CHUV, Service d’hématologie. Lymphomes : diagnostic et traitements. <a href="https://www.chuv.ch/fr/hematologie/hem-home/personnel-de-la-sante/maladies-et-traitements/lymphomes">chuv.ch</a>. Document consulté le 23 octobre 2026.',
 34: 'Swiss Sarcoma Network. Minimal Workup Requirements — Soft Tissue Tumors. <a href="https://www.swiss-sarcoma.net/pdf/GCP_1_minimal_workup_requirements.pdf">swiss-sarcoma.net</a>. Document consulté le 23 octobre 2026.',
 35: 'OFSP. Dépistages et conseils du VIH et des autres IST. <a href="https://www.bag.admin.ch/fr/depistages-et-conseils-du-vih-et-des-autre-ist">bag.admin.ch</a>. Document consulté le 23 octobre 2026.',
 36: 'CHUV, radiologie interventionnelle. Cytoponction de la thyroïde. <a href="https://www.chuv.ch/fr/rad/rad-home/patients-et-familles/nos-interventions/ponctions-drainages/cytoponction-de-la-thyroide">chuv.ch</a>. Document consulté le 23 octobre 2026.',
 37: 'NICE. NG12 — Suspected cancer: recognition and referral (mise à jour 2025). <a href="https://www.nice.org.uk/guidance/ng12/chapter/Recommendations-organised-by-site-of-cancer">nice.org.uk</a>. Document consulté le 23 octobre 2026.',
 38: 'CHUV, lymphologie. Consultation de lymphologie. <a href="https://www.chuv.ch/fr/offre-en-soins/portail-des-medecins-installes/medchuv/adresser-un-e-patient-e/consultation/medchuv_prest_253/consultation-de-lymphologie">chuv.ch</a>. Document consulté le 23 octobre 2026.',
 39: 'NHS Tayside, Right Decisions. Lump in neck — referral guide (2025). <a href="https://www.rightdecisions.scot.nhs.uk/nhs-tayside-refguide/specialist-surgery-and-specialist-services/ent/lump-in-neck/">rightdecisions.scot.nhs.uk</a>. Document consulté le 23 octobre 2026.',
 44: 'European Society of Musculoskeletal Radiology (ESSR). Soft tissue tumour imaging in adults: guidelines 2023. <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC11213759/">pmc.ncbi.nlm.nih.gov</a>. Document consulté le 23 octobre 2026.',
 46: 'La Revue du Praticien. S’orienter devant une adénopathie superficielle (algorithme 2025). <a href="https://www.larevuedupraticien.fr/article/sorienter-devant-une-adenopathie-superficielle">larevuedupraticien.fr</a>. Document consulté le 23 octobre 2026.',
 48: 'Durante C et al. 2023 European Thyroid Association clinical practice guidelines for thyroid nodule management. Eur Thyroid J 2023;12:e230067. <a href="https://pmc.ncbi.nlm.nih.gov/articles/PMC10448590/">pmc.ncbi.nlm.nih.gov</a>. Document consulté le 23 octobre 2026.',
}
SOURCES_AUDIT = {
 60: 'Ligue suisse contre le cancer, d’après la Nationale Krebsregistrierungsstelle (NKRS). Krebs in der Schweiz: wichtige Zahlen, période 2018–2022, mise à jour de novembre 2025. <a href="https://www.krebsliga.ch/ueber-krebs/zahlen-fakten/-dl-/fileadmin/downloads/sheets/zahlen-krebs-in-der-schweiz.pdf">krebsliga.ch</a>.' + AJ,
 61: 'OFSP. Bulletin 44/2025 : infections sexuellement transmissibles et hépatites B/C en Suisse et au Liechtenstein, évaluation 2024. <a href="https://www.bag.admin.ch/dam/fr/sd-web/jB29Qf2x7Jme/BU_44_25_FR.pdf">bag.admin.ch</a>.' + AJ,
 62: 'OFSP. La tuberculose en Suisse et dans la Principauté de Liechtenstein en 2025 (Bulletin 2026). <a href="https://www.bag.admin.ch/dam/it/sd-web/KgDGxmnGvfis/Bulletin-2026-Tuberculose.pdf">bag.admin.ch</a>.' + AJ,
 63: 'Ligue pulmonaire suisse. Rapport 2024 de lutte contre la tuberculose. <a href="https://www.liguepulmonaire.ch/sites/default/files/documents/fr_tb-bericht_2024_final_0.pdf">liguepulmonaire.ch</a>.' + AJ,
 64: 'Ferrer R. Lymphadenopathy: differential diagnosis and evaluation. Am Fam Physician 1998;58:1313–1320.' + AJ,
 65: 'Fijten GH, Blijham GH. Unexplained lymphadenopathy in family practice: an evaluation of the probability of malignant causes and the effectiveness of physicians’ workup. J Fam Pract 1988;27:373–376.' + AJ,
 66: 'Gaddey HL, Riegel AM. Unexplained lymphadenopathy: evaluation and differential diagnosis. Am Fam Physician 2016;94:896–903.' + AJ,
 67: 'Ebell MH, Call M, Shinholser J, Gardner J. Does this patient have infectious mononucleosis? The Rational Clinical Examination systematic review. JAMA 2016;315:1502–1509.' + AJ,
 68: 'Dunmire SK, Verghese PS, Balfour HH Jr. Primary Epstein–Barr virus infection. J Clin Virol 2018;102:84–92.' + AJ,
 69: 'Stevens DL et al. Practice guidelines for the diagnosis and management of skin and soft tissue infections: 2014 update by the Infectious Diseases Society of America (IDSA). Clin Infect Dis 2014;59:e10–e52.' + AJ,
 70: 'Fontanilla JM, Barnes A, von Reyn CF. Current diagnosis and management of peripheral tuberculous lymphadenitis. Clin Infect Dis 2011;53:555–562.' + AJ,
 71: 'OMS. WHO consolidated guidelines on tuberculosis. Module 4: treatment — drug-susceptible tuberculosis treatment. Genève : OMS ; 2022.' + AJ,
 72: 'Cheson BD et al. Recommendations for initial evaluation, staging, and response assessment of Hodgkin and non-Hodgkin lymphoma: the Lugano classification. J Clin Oncol 2014;32:3059–3068.' + AJ,
 73: 'Alaggio R et al. The 5th edition of the World Health Organization Classification of Haematolymphoid Tumours: lymphoid neoplasms. Leukemia 2022;36:1720–1748.' + AJ,
 74: 'Gronchi A et al. Soft tissue and visceral sarcomas: ESMO–EURACAN–GENTURIS Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol 2021;32:1348–1365.' + AJ,
 75: 'Haugen BR et al. 2015 American Thyroid Association management guidelines for adult patients with thyroid nodules and differentiated thyroid cancer. Thyroid 2016;26:1–133.' + AJ,
 76: 'Russ G et al. European Thyroid Association guidelines for ultrasound malignancy risk stratification of thyroid nodules in adults: the EU-TIRADS. Eur Thyroid J 2017;6:225–237.' + AJ,
 77: 'Ali SZ, Baloch ZW, Cochand-Priollet B, Schmitt FC, Vielh P, VanderLaan PA. The 2023 Bethesda System for Reporting Thyroid Cytopathology. Thyroid 2023;33:1039–1044.' + AJ,
 78: 'Machiels JP et al. Squamous cell carcinoma of the oral cavity, larynx, oropharynx and hypopharynx: EHNS–ESMO–ESTRO Clinical Practice Guidelines. Ann Oncol 2020;31:1462–1475.' + AJ,
 79: 'Krämer A et al. Cancer of unknown primary: ESMO Clinical Practice Guideline for diagnosis, treatment and follow-up. Ann Oncol 2023;34:228–246.' + AJ,
 80: 'Eichenauer DA et al. Hodgkin lymphoma: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol 2018;29(Suppl 4):iv19–iv29.' + AJ,
 81: 'Tilly H et al. Diffuse large B-cell lymphoma (DLBCL): ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol 2015;26(Suppl 5):v116–v125.' + AJ,
 82: 'Swissmedicinfo. Informations professionnelles suisses (AIPS) des spécialités citées dans ce chapitre ; posologies à revérifier dans la version en vigueur le jour de la prescription. <a href="https://www.swissmedicinfo.ch">swissmedicinfo.ch</a>.' + AJ,
 83: 'Kransdorf MJ. Benign soft-tissue tumors in a large referral population: distribution of specific diagnoses by age, sex, and location. AJR Am J Roentgenol 1995;164:395–402.' + AJ,
 84: 'Chovel-Sella A et al. Incidence of rash after amoxicillin treatment in children with infectious mononucleosis. Pediatrics 2013;131:e1424–e1427.' + AJ,
 85: 'Becker JA, Smith JA. Return to play after infectious mononucleosis. Sports Health 2014;6:232–238.' + AJ,
 86: 'Bass JW et al. Prospective randomized double blind placebo-controlled evaluation of azithromycin for treatment of cat-scratch disease. Pediatr Infect Dis J 1998;17:447–452.' + AJ,
 87: 'European AIDS Clinical Society (EACS). Guidelines, version 12.0, octobre 2023.' + AJ,
 88: 'Singer M et al. The Third International Consensus Definitions for Sepsis and Septic Shock (Sepsis-3). JAMA 2016;315:801–810.' + AJ,
 89: 'Balfour HH Jr et al. Behavioral, virologic, and immunologic factors associated with acquisition and severity of primary Epstein-Barr virus infection in university students. J Infect Dis 2013;207:80–88.' + AJ,
 90: 'Ebell MH. Epstein-Barr virus infectious mononucleosis. Am Fam Physician 2004;70:1279–1287.' + AJ,
 92: 'Womack J, Jimenez M. Common questions about infectious mononucleosis. Am Fam Physician 2015;91:372–376.' + AJ,
 93: 'Rosenberg ES, Caliendo AM, Walker BD. Acute HIV infection among patients tested for mononucleosis. N Engl J Med 1999;340:969.' + AJ,
 91: 'OFSP et Commission fédérale pour les vaccinations. Plan de vaccination suisse, édition en vigueur (2026).' + AJ,
}
SOURCES = sorted({**SOURCES_ORIG, **SOURCES_A, **SOURCES_AUDIT}.items())

# Banque de différentiels : même unité (nouveaux cas par an pour 100 000 habitants, Suisse) quand une donnée existe.
# Population suisse ≈ 9 millions : taux = cas annuels ÷ 90 (arrondi ; calcul de l'audit).
DDX = {
 'react': ('Adénopathie réactionnelle bénigne', 'cause la plus fréquente ; non chiffrée', 65),
 'nhl': ('Lymphome non hodgkinien', '≈ 19 / 100 000 par an', 60),
 'hl': ('Lymphome de Hodgkin', '≈ 3 / 100 000 par an', 60),
 'orl': ('Métastase d’un carcinome de la bouche, du pharynx ou du larynx', '≈ 16 / 100 000 par an (cancers primitifs)', 60),
 'mel': ('Métastase ganglionnaire de mélanome', '≈ 39 / 100 000 par an (mélanomes primitifs)', 60),
 'thy': ('Cancer de la thyroïde', '≈ 9 / 100 000 par an', 60),
 'sarc': ('Sarcome des tissus mous', '≈ 4 / 100 000 par an', 60),
 'tb': ('Tuberculose (toutes formes)', '4,8 / 100 000 en 2024 ; 6,0 en 2025', 62),
 'vih': ('Infection par le VIH (nouveaux diagnostics)', '3,5 / 100 000 en 2024', 61),
}
def DDXROW(k, orient, exam, nom=None):
    n, v, s = DDX[k]
    return [(nom or n) + PR(v, s), orient, exam]
UNITE = ('Les valeurs en rouge sont des incidences annuelles suisses pour 100 000 habitants (NKRS 2018–2022, OFSP 2024–2025), calculées sur environ 9 millions d’habitants ; '
         'elles décrivent la population générale et non la probabilité devant un patient donné.')
