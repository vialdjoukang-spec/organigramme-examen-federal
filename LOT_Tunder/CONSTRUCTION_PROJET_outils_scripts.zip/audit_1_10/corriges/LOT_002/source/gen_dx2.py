# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.2 · Lymphadénite bactérienne et adénite suppurée (LOT 2, Partie 1)."""
from lot2_commun import *
POINT = mkPOINT('dx2')
M = META('dx2', 'DX.2', 'Lymphadénite bactérienne', 'Lymphadénite bactérienne et adénite suppurée', 'LOT_002_DX2_Lymphadenite_bacterienne_AUDITÉ.html', 1,
         'Les doses d’antibiotiques reprennent l’AIPS suisse et le guide d’antibiothérapie du CHUV ; elles restent à vérifier par un médecin.')
LA = T('lymphadénite', 'La lymphadénite est l’inflammation d’un ganglion envahi par des bactéries ; le ganglion devient chaud, rouge et très douloureux.')
AB = T('adénite suppurée', 'L’adénite suppurée (ou abcédée) est une lymphadénite dont le centre s’est nécrosé en pus ; elle se reconnaît à la fluctuation et à l’échographie.')
LEM = T('syndrome de Lemierre', 'Le syndrome de Lemierre est une thrombophlébite septique de la veine jugulaire interne, due surtout à Fusobacterium necrophorum, avec des emboles pulmonaires septiques.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'La {LA} est l’infection bactérienne d’un ou de plusieurs ganglions, le plus souvent cervicaux, venue d’une porte d’entrée du territoire de drainage. '
   f'L’{AB} en est le stade collecté, où le ganglion contient du pus. '
   'La distinction compte, car un abcès se draine alors qu’une lymphadénite non collectée se traite par antibiotique seul.', 69, 21, 66) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Lymphadénite aiguë', 'Ganglion infecté depuis moins de 2 semaines, chaud et douloureux', 'Adénopathie réactionnelle (DX.1), peu douloureuse et sans rougeur'],
    ['Adénite suppurée', 'Ganglion collecté, fluctuant', 'Abcès cutané superficiel'],
    ['Lymphangite', 'Traînée rouge le long d’un vaisseau lymphatique', 'Érysipèle ou cellulite (placard)'],
    ['Lymphadénite subaiguë ou chronique', 'Évolution > 2 semaines, peu inflammatoire', 'Tuberculose (DX.5), mycobactérie atypique, maladie des griffes du chat'],
    ['Abcès profond du cou', 'Collection rétro- ou parapharyngée', 'Adénite superficielle'],
   ]) + P('Le mot « suppuré » signifie qu’il y a du pus ; il implique un geste de drainage, en plus de l’antibiotique.', 69, 21))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('Aucune incidence suisse ou européenne de la lymphadénite bactérienne n’est publiée ; elle est surtout décrite chez l’enfant de 1 à 4 ans. En Suisse, la tuberculose, diagnostic différentiel des adénites chroniques, touchait 4,8 pour 100 000 habitants en 2024. '
   'Les germes dominants sont Staphylococcus aureus et le streptocoque du groupe A, venus de la peau, des dents ou du pharynx. '
   'Chez l’enfant de 1 à 5 ans, une adénite subaiguë peu douloureuse évoque une mycobactérie non tuberculeuse.', 66, 69, 84, 62) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Source et portée'], [
    ['Incidence en Suisse', 'Non publiée', 'Aucune source trouvée ; aucun chiffre n’est donné'],
    ['Âge typique', '1–4 ans (cervicale aiguë)', 'Revues pédiatriques'],
    ['Germes principaux', 'S. aureus, streptocoque du groupe A', 'Recommandation IDSA 2014'],
    ['Staphylococcus aureus résistant (SARM) en Suisse', 'Rare en ville ; à suspecter après hospitalisation ou en cas d’échec', 'Guide d’antibiothérapie du CHUV 2025'],
    ['Maladie des griffes du chat', 'Contact avec un chaton dans la grande majorité des cas', 'Bass 1998'],
   ]) + P('Les facteurs de risque sont une porte d’entrée cutanée, dentaire ou pharyngée, l’eczéma, le diabète et l’immunodépression. Le pronostic est bon sous traitement ; la mortalité vient des complications profondes, rares.', 69, 11))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Des bactéries pénètrent par une porte d’entrée, gagnent le ganglion par la lymphe et y prolifèrent. '
   'Les polynucléaires affluent, libèrent des enzymes et nécrosent le centre du ganglion, ce qui forme du pus. '
   'L’inflammation dépasse ensuite la capsule et gagne la peau, d’où la rougeur, l’œdème et l’adhérence cutanée.', 69, 66) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les ganglions cervicaux drainent la bouche, les dents, le pharynx et le cuir chevelu ; les axillaires le membre supérieur ; les inguinaux le membre inférieur et le périnée.'],
    ['Physiologie', 'Le ganglion filtre et retient normalement les bactéries, qui sont détruites par les macrophages.'],
    ['Physiopathologie', 'Quand l’inoculum dépasse ces défenses, les bactéries prolifèrent ; les polynucléaires forment un abcès central.'],
    ['Clinique', 'D’où un ganglion chaud, rouge, très douloureux, puis fluctuant, avec fièvre.'],
    ['Examens', 'L’échographie distingue l’inflammation (phlegmon) de la collection ; la ponction identifie le germe.'],
    ['Traitement', 'Un antibiotique actif sur S. aureus et le streptocoque suffit au stade non collecté ; une collection impose le drainage.'],
   ]), 69, 66) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Inoculation par une porte d’entrée', 'Examen de la peau, des dents, du pharynx', 'Traitement de la porte d’entrée'],
    ['Prolifération bactérienne', 'CRP, hémogramme, culture du pus', 'Antibiotique ciblé'],
    ['Nécrose centrale (abcès)', 'Échographie', 'Ponction ou incision-drainage'],
    ['Extension profonde', 'Scanner cervical injecté', 'Drainage chirurgical'],
    ['Dissémination (sepsis)', 'Hémocultures, lactate', 'Antibiotique intraveineux urgent'],
   ]) + P('Cette chaîne explique pourquoi l’antibiotique seul échoue devant un abcès : il diffuse mal dans le pus, qui n’est pas vascularisé.', 69, 21))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin recherche d’abord les signes d’urgence vitale : sepsis, stridor, trismus, torticolis, dysphagie. '
   'Il recherche ensuite la porte d’entrée et la collection, puis il élimine les causes subaiguës, comme la tuberculose et la maladie des griffes du chat. '
   'Une masse qui ne répond pas après 48–72 heures d’antibiotique doit faire revoir le diagnostic.', 69, 66) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Lymphadénite bactérienne aiguë' + PR('incidence non publiée', 69), 'Ganglion chaud, rouge, douloureux, porte d’entrée', 'CRP, échographie'],
    DDXROW('react', 'Ganglion souple, peu douloureux, sans rougeur', 'Évolution'),
    ['Abcès cutané ou kyste surinfecté' + PR('incidence non publiée', 21), 'Collection dermique, orifice d’un kyste', 'Échographie'],
    ['Kyste branchial ou du tractus thyréoglosse surinfecté' + PR('incidence non publiée', 66), 'Récidive, siège latéral ou médian', 'Échographie, scanner'],
    DDXROW('tb', 'Ganglion froid, fistule, migration', 'IGRA, biopsie avec culture'),
    ['Mycobactérie non tuberculeuse' + PR('incidence suisse non publiée', 84), 'Enfant de 1–5 ans, peau violacée, peu douloureux', 'Culture, exérèse'],
    ['Maladie des griffes du chat' + PR('incidence suisse non publiée', 86), 'Contact avec un chat, papule d’inoculation', 'Sérologie, PCR Bartonella'],
    DDXROW('nhl', 'Masse persistante après traitement', 'Biopsie-exérèse'),
    DDXROW('orl', 'Fumeur de plus de 40 ans, masse « kystique » cervicale', 'Examen ORL, p16'),
   ]) + P(UNITE + ' Une adénite kystique chez l’adulte de plus de 40 ans doit faire chercher une métastase d’un cancer ORL lié au HPV.', 60, 62, 78))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise le début, la vitesse d’extension, la fièvre et la porte d’entrée. '
   'Il recherche les contacts animaux, les antibiotiques déjà pris, l’immunodépression et les antécédents de tuberculose.', 69, 66) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis quand la masse est-elle rouge et douloureuse ?', 'Moins de 2 semaines : aiguë.', 'Plus de 2 semaines : chercher tuberculose, griffes du chat'],
    ['Avez-vous mal aux dents, à la gorge, une plaie ?', 'Porte d’entrée.', 'Traitement associé'],
    ['Avez-vous de la peine à avaler, à ouvrir la bouche, à respirer ?', 'Abcès profond.', 'Urgences'],
    ['Avez-vous un chat ou un chaton ?', 'Bartonella henselae.', 'Sérologie, azithromycine'],
    ['Avez-vous déjà pris un antibiotique ?', 'Échec : collection ou germe résistant.', 'Échographie, culture'],
    ['Êtes-vous diabétique ou immunodéprimé ?', 'Risque de forme grave.', 'Seuil d’hospitalisation bas'],
   ])) +
 U('<b>Drapeaux rouges</b> : sepsis, stridor, trismus, dysphagie avec hypersalivation, torticolis, douleur thoracique (médiastinite), extension rapide de la rougeur, nourrisson ou immunodéprimé ; appel du 144 ou adresse immédiate aux urgences.', 69, 11)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure d’abord les signes vitaux, puis il inspecte la peau en regard. '
   'Il palpe doucement le ganglion pour noter sa taille, sa chaleur, sa fluctuation et sa mobilité, puis il examine la bouche, les dents, le pharynx et la peau du territoire. '
   'La fluctuation a une sensibilité imparfaite : son absence n’exclut pas une collection, d’où l’échographie.', 69, 21) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal', 'Anomalie et signification'], [
    ['Signes vitaux', 'Température < 38 °C, pouls < 100/min', 'Fièvre, tachycardie, hypotension : sepsis'],
    ['Inspection cutanée', 'Peau normale', 'Rougeur, œdème, peau violacée (mycobactérie atypique)'],
    ['Palpation bidigitale', 'Ganglion souple, ferme', 'Fluctuation : abcès'],
    ['Examen endobuccal et dentaire', 'Muqueuse saine', 'Carie, abcès dentaire, angine'],
    ['Ouverture de bouche et mobilité du cou', 'Ouverture > 3 cm, cou libre', 'Trismus, torticolis : abcès profond'],
    ['Recherche d’une lymphangite', 'Absence', 'Traînée rouge vers le ganglion'],
   ]) + P('Une masse chaude chez un patient de plus de 40 ans qui ne répond pas au traitement est réexaminée par un spécialiste ORL.', 69, 78))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la douleur, la fièvre, la gêne à la mobilisation du cou ou du membre. '
   'Les signes physiques sont la tuméfaction chaude et rouge, la fluctuation et la porte d’entrée. '
   'Ils forment un syndrome infectieux local, parfois un syndrome septique général.', 69) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    ['Tuméfaction chaude et rouge', 'Peau inflammatoire en regard', 'Vasodilatation inflammatoire'],
    ['Fluctuation', 'Sensation d’onde liquidienne entre deux doigts', 'Collection de pus'],
    ['Adhérence cutanée', 'Peau fixée au ganglion', 'Extension périganglionnaire'],
    ['Fistulisation', 'Écoulement de pus à la peau', 'Rupture de l’abcès ; tuberculose si chronique'],
    ['Trismus', 'Limitation de l’ouverture de la bouche', 'Inflammation des muscles masticateurs (abcès profond)'],
    [LEM, 'Fièvre, douleur cervicale, emboles pulmonaires', 'Thrombose veineuse infectée'],
   ]), 69)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Il n’existe pas de critères formels publiés ; le diagnostic est clinique, confirmé par l’échographie et la culture, et l’aspect clinique seul ne suffit pas. '
   'Le sepsis se définit selon le consensus Sepsis-3 de 2016 par une dysfonction d’organe liée à l’infection, dépistée par un qSOFA ≥ 2 (fréquence respiratoire ≥ 22/min, confusion, pression systolique ≤ 100 mmHg). '
   'La collection est affirmée par l’échographie ou par la ponction de pus.', 69, 88) +
 F('Éléments qui soutiennent ou réfutent l’hypothèse',
   TAB(['Soutient', 'Réfute ou fait revoir'], [
    ['Début aigu < 2 semaines', 'Évolution > 2 semaines, peu inflammatoire'],
    ['Porte d’entrée identifiée', 'Aucune porte d’entrée'],
    ['CRP élevée, polynucléose', 'Biologie normale'],
    ['Réponse en 48–72 heures', 'Absence de réponse : collection, germe inhabituel, tumeur'],
   ]) + P('La réponse au traitement est un critère d’évolution, pas une preuve du germe : la culture reste nécessaire en cas de ponction.', 69))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Culture du pus (ponction ou drainage)', 'Germe et antibiogramme', 'Référence microbiologique', 'Négative si un antibiotique a été donné'],
    ['Échographie', 'Collection ou phlegmon', 'Sensibilité et spécificité élevées pour les collections superficielles (valeurs chiffrées variables selon les séries)', 'Opérateur-dépendante, peu fiable en profondeur'],
    ['Scanner cervical injecté', 'Abcès profond, extension, thrombose jugulaire', 'Référence pour les espaces profonds', 'Irradiation, produit de contraste'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'CRP, hémogramme', 'Fièvre ou doute sur la gravité'],
    ['Première', 'Échographie', 'Doute sur une collection'],
    ['Première (sepsis)', 'Hémocultures, lactate, créatinine', 'Signes de sepsis'],
    ['Seconde', 'Scanner cervical injecté', 'Trismus, dysphagie, échec à 48–72 heures'],
    ['Seconde', 'Sérologie Bartonella, IGRA, culture mycobactérienne', 'Évolution subaiguë'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La <b>culture</b> se prélève avant le premier antibiotique si cela ne retarde pas un sepsis.',
       'Le pus destiné aux mycobactéries est envoyé frais, sans formol ; une partie séparée va en histologie.',
       'Le <b>scanner injecté</b> demande la créatinine et la recherche d’une allergie au produit de contraste.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['CRP', 'Normal < 5 mg/L', 'Élevée : infection bactérienne probable', 'Antibiotique ; suivi de la décroissance'],
    ['Polynucléaires neutrophiles', 'Normal 1,5–7,5 G/L', '> 7,5 G/L : infection bactérienne', 'Contexte'],
    ['Échographie : zone anéchogène avec paroi', '—', 'Abcès', 'Drainage'],
    ['Résultat positif : culture à S. aureus', '—', 'Germe confirmé', 'Adapter à l’antibiogramme'],
    ['Résultat négatif : culture stérile', '—', 'Antibiotique préalable, germe exigeant', 'Rechercher mycobactérie, Bartonella'],
    ['Résultat limite ou discordant : CRP normale avec masse chaude', '—', 'Cause non bactérienne possible', 'Réévaluer, biopsie si persistance'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Échographie ; IRM sans gadolinium si une imagerie profonde est nécessaire'],
    ['Enfant', 'Échographie en première intention ; scanner seulement si suspicion d’abcès profond'],
    ['DFGe < 30 mL/min/1,73 m²', 'IRM ou scanner sans injection ; adapter les antibiotiques'],
    ['Allergie à l’iode', 'IRM'],
    ['Stimulateur cardiaque', 'Scanner ; IRM si le dispositif est compatible'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Une lymphadénite non compliquée de l’adulte peut se traiter sans examen ; la culture reste la référence microbiologique. '
   'La CRP et l’hémogramme évaluent la gravité, l’échographie recherche une collection et la culture identifie le germe. '
   'Le scanner injecté est réservé aux suspicions d’abcès profond.', 69, 11) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si des signes de sepsis ou d’atteinte des voies aériennes sont présents, alors le patient est adressé aux urgences. '
   'Si la lymphadénite n’est pas collectée, alors le médecin prescrit un antibiotique oral et revoit le patient à 48–72 heures. '
   'Si une collection est présente, alors il organise une ponction ou un drainage avec culture.', 69, 11) +
 F('Embranchements',
   TAB(['Si…', 'Alors…', 'Contrôle'], [
    ['Sepsis, stridor, trismus', 'Urgences, antibiotique intraveineux, scanner', 'Hospitalisation'],
    ['Non collectée, état général conservé', 'Co-amoxicilline orale', 'Contrôle à 48–72 heures'],
    ['Collection à l’échographie', 'Ponction ou incision-drainage, culture', 'Contrôle à 48 heures'],
    ['Pas de réponse à 72 heures', 'Échographie, avis ORL ou chirurgical', 'Scanner si profond'],
    ['Évolution subaiguë, enfant, peau violacée', 'Mycobactérie atypique : avis ORL, exérèse', 'Culture'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Amoxicilline et acide clavulanique, AUGMENTIN® ou génériques (pénicilline avec inhibiteur de bêta-lactamases)', 'Adulte : 625 mg 3 fois par jour ou 1 g 2 fois par jour, par voie orale, 7–10 jours ; absorption orale bonne, élimination rénale, demi-vie d’environ 1 heure', 'Diarrhée, candidose, hépatite cholestatique ; contre-indiquée en cas d’allergie aux pénicillines ; adapter si clairance < 30 mL/min ; interaction : méthotrexate, antivitamines K'],
   ['Clindamycine, DALACIN C® (lincosamide)', 'Adulte : 300–450 mg 3 à 4 fois par jour, 7–10 jours ; bonne diffusion tissulaire, métabolisme hépatique', 'Diarrhée, colite à Clostridioides difficile ; alternative en cas d’allergie aux pénicillines'],
   ['Azithromycine, ZITHROMAX® (macrolide)', 'Maladie des griffes du chat (≥ 45 kg) : 500 mg le jour 1 puis 250 mg les jours 2–5 ; demi-vie longue (≈ 68 heures)', 'Troubles digestifs, allongement du QT ; interactions avec les médicaments qui allongent le QT'],
   ['Amoxicilline-clavulanate intraveineuse', 'Adulte hospitalisé : 2,2 g 3 fois par jour', 'Mêmes précautions ; relais oral dès l’amélioration'],
   ['Paracétamol, DAFALGAN®', '500–1000 mg toutes les 4–8 heures, maximum 4 g par jour', 'Hépatotoxicité en surdosage'],
  ]) + P('Ces doses proviennent de l’AIPS (Swissmedicinfo) et du guide du CHUV ; le médecin les vérifie dans l’AIPS du produit prescrit.', 82, 11, 86, 10))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est de guérir l’infection, de drainer une collection et d’éviter les complications profondes. '
   'Le traitement ambulatoire suffit pour une forme non collectée chez un patient sans signe de gravité. '
   'L’hospitalisation est indiquée en cas de sepsis, d’abcès profond, d’échec ou d’impossibilité de prendre un traitement oral.', 69, 11) +
 F('11.A Buts : urgence ou non',
   P('La forme compliquée (sepsis, abcès profond) est une urgence : antibiotique intraveineux dans l’heure. La forme simple ne l’est pas ; le but chiffré est l’apyrexie et une diminution de la douleur en 48–72 heures.', 69, 11), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Évaluer la gravité et prélever (culture, hémocultures si fièvre).', 'Commencer l’antibiotique.', 'Drainer une collection (ponction à l’aiguille ou incision).', 'Traiter la porte d’entrée (dent, plaie).', 'Soulager la douleur.', 'Revoir à 48–72 heures.']), 69, 21) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal prend en charge le traitement ; la LAA intervient si la porte d’entrée est une plaie accidentelle ou une morsure.', 'Un arrêt de travail de quelques jours est souvent nécessaire en cas de fièvre ou de drainage.', 'La conduite automobile est déconseillée sous fièvre ou en cas de torticolis ; la LAI n’est pas concernée.']), 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Co-amoxicilline et clindamycine utilisables ; éviter les tétracyclines et les fluoroquinolones.'],
      ['Personne âgée', 'Seuil d’hospitalisation bas ; vérifier la fonction rénale.'],
      ['Enfant', 'Co-amoxicilline selon le poids (AIPS) ; avis ORL pédiatrique si collection.'],
      ['Insuffisance hépatique', 'Prudence avec la co-amoxicilline (hépatite cholestatique).'],
      ['Insuffisance rénale (DFGe < 30)', 'Réduire la dose ou espacer la co-amoxicilline selon l’AIPS.'],
      ['Diabète, immunodépression', 'Formes graves plus fréquentes ; culture systématique.'],
     ]), 82, 11), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Température, douleur, taille', 'À 48–72 heures', 'Pas d’amélioration : échographie, drainage'],
    ['CRP (hospitalisé)', 'À 48–72 heures', 'Pas de baisse : rechercher une collection'],
    ['Ganglion résiduel', 'À 4–6 semaines', 'Persistance : biopsie (tumeur, tuberculose)'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Apyrexie depuis 24 heures.', 'Collection drainée ou absente.', 'Relais oral toléré.', 'Contrôle fixé à 48–72 heures et consignes de retour.']), 69, 11) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La guérison sans séquelle est la règle ; une cicatrice ou une fistule est possible après une mycobactérie atypique. La recherche 2026 évalue les durées courtes d’antibiothérapie dans les infections des tissus mous.', 69, 84), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur les soins dentaires, l’hygiène des plaies et la prudence avec les chatons. '
   'La prévention secondaire consiste à revoir le patient à 48–72 heures et à drainer tôt une collection. '
   'La prévention tertiaire vise la récidive et l’antibiorésistance.', 69, 86) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Hygiène dentaire, désinfection des plaies, lavage des mains après une griffure'],
    ['Secondaire', 'Contrôle précoce, échographie en cas d’échec'],
    ['Tertiaire', 'Traitement d’un kyste congénital récidivant, bon usage des antibiotiques (stratégie suisse StAR)'],
   ]), 69, 11)))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin évalue d’abord les signes de sepsis et d’abcès profond. '
   'Il traite une lymphadénite non collectée par la co-amoxicilline et revoit le patient à 48–72 heures. '
   'Il draine toute collection et envoie le pus en culture, sans formol si une tuberculose est possible. '
   'Il évoque Bartonella en cas de contact avec un chat. '
   'Il biopsie un ganglion qui persiste 4–6 semaines après la guérison clinique.', 69, 11, 86)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['L’absence de fluctuation exclut un abcès.', 'Faux : l’échographie le recherche.'],
  ['Changer d’antibiotique en cas d’échec sans imagerie.', 'Erreur : chercher d’abord une collection.'],
  ['Mettre tout le prélèvement dans le formol.', 'Erreur : la culture mycobactérienne exige un prélèvement frais.'],
  ['Une masse kystique cervicale de l’adulte est une adénite.', 'Attention : chercher une métastase d’un cancer ORL lié au HPV.'],
  ['Inciser une adénite à mycobactérie atypique de l’enfant.', 'Erreur : risque de fistule ; l’exérèse complète est préférée.'],
 ]) + P('Ces pièges reprennent l’IDSA 2014 et les revues pédiatriques.', 69, 84)))
CTX = {'_prefixe': 'Devant une lymphadénite bactérienne',
 'echo': 'L’échographie montre une collection anéchogène qui impose un drainage, ou un phlegmon qui se traite par antibiotique seul.',
 'echogg': 'Une collection intraganglionnaire signe l’adénite suppurée.',
 'crp': 'Une CRP élevée soutient l’origine bactérienne et sa décroissance montre l’efficacité du traitement.',
 'nfs': 'Une polynucléose neutrophile soutient l’origine bactérienne.',
 'hemoc': 'Des hémocultures positives signent une bactériémie et imposent un traitement intraveineux.',
 'tdm': 'Le scanner injecté recherche un abcès profond, une médiastinite ou une thrombose jugulaire.',
 'irm': 'L’IRM remplace le scanner pendant la grossesse ou en cas d’allergie au produit iodé.',
 'sero': 'La sérologie Bartonella confirme une maladie des griffes du chat.',
 'pcr': 'La PCR sur le pus identifie Bartonella ou une mycobactérie quand la culture est négative.',
 'igra': 'Un IGRA positif fait évoquer une tuberculose devant une adénite subaiguë.',
 'biopsie': 'La biopsie d’un ganglion persistant après guérison recherche une tuberculose ou une tumeur.',
 'creat': 'La créatinine guide la dose de co-amoxicilline et l’injection de contraste.',
 'lact': 'Un lactate ≥ 2 mmol/L signale une hypoperfusion au cours d’un sepsis.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
