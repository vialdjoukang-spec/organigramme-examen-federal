# -*- coding: utf-8 -*-
# Sources extraites des originaux LOT 2 (outils_local/sources_orig_lot2.py).
SOURCES_ORIG = {
 3: '<a href="https://www.chuv.ch/fr/hematologie/hem-home/personnel-de-la-sante/maladies-et-traitements/lymphomes">CHUV — Lymphomes, information professionnelle</a>. Version : Page institutionnelle ; date non établie. Document consulté le 23 octobre 2026.',
 5: '<a href="https://www.bag.admin.ch/fr/depistages-et-conseils-du-vih-et-des-autre-ist">OFSP — Dépistages et conseils du VIH et des autres IST</a>. Version : Page d’accès à la directive actuelle. Document consulté le 23 octobre 2026.',
 6: '<a href="https://www.nhs.uk/symptoms/swollen-glands/">NHS — Swollen glands</a>. Version : Révision du 29 septembre 2023. Document consulté le 23 octobre 2026.',
 9: '<a href="https://www.bag.admin.ch/dam/fr/sd-web/fPW7HAdyOiZ0/tuberkulose-handbuch.pdf">Ligue pulmonaire suisse et OFSP — Tuberculose en Suisse</a>. Version : V1.2024. Document consulté le 23 octobre 2026.',
 10: '<a href="https://www.swissmedicinfo-pro.ch/showText.aspx?authNr=47503&amp;lang=FR&amp;supportMultipleResults=1&amp;textType=FI">Swissmedic/AIPS — DAFALGAN®, information professionnelle</a>. Version : Septembre 2025. Document consulté le 23 octobre 2026.',
 11: '<a href="https://www.chuv.ch/fr/min/min-home/personnel-de-la-sante/guide-dantibiotherapie">CHUV — Guide d’antibiothérapie</a>. Version : Mise à jour du 18 décembre 2025. Document consulté le 23 octobre 2026.',
 21: '<a href="https://www.nhs.uk/conditions/skin-abscess/">NHS — Skin abscess</a>. Version : Révision du 2 juin 2023. Document consulté le 23 octobre 2026.',
 22: '<a href="https://www.nhs.uk/conditions/cellulitis/">NHS — Cellulitis</a>. Version : Révision du 18 avril 2024. Document consulté le 23 octobre 2026.',
}
