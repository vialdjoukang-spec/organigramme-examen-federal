# -*- coding: utf-8 -*-
# Sources extraites des originaux LOT 2 (outils_local/sources_orig_lot2.py).
SOURCES_ORIG = {
 2: '<a href="https://www.swiss-sarcoma.net/pdf/GCP_1_minimal_workup_requirements.pdf">Swiss Sarcoma Network — Minimal workup requirements</a>. Version : Document non daté. Document consulté le 23 octobre 2026.',
 17: '<a href="https://www.nhs.uk/conditions/lipoma/">NHS — Lipoma</a>. Version : Révision du 25 juillet 2023. Document consulté le 23 octobre 2026.',
 18: '<a href="https://www.onkopedia.com/de/onkopedia/guidelines/weichgewebssarkome-maligne-weichgewebstumoren-des-erwachsenen">Onkopedia — Sarcomes des tissus mous de l’adulte</a>. Version : Avril 2019, date affichée. Document consulté le 23 octobre 2026.',
 19: '<a href="https://www.eurothyroid.com/guidelines/eta_guidelines.html">European Thyroid Association — index officiel des recommandations</a>. Version : Index consulté en octobre 2026. Document consulté le 23 octobre 2026.',
 20: '<a href="https://www.nhs.uk/conditions/thyroid-cancer/tests-and-next-steps/">NHS — Thyroid cancer, tests and next steps</a>. Version : Révision du 18 mai 2023. Document consulté le 23 octobre 2026.',
}
