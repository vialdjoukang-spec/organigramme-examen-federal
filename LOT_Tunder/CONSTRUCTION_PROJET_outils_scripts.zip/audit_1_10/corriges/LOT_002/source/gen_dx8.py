# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.8 · Lipome superficiel (LOT 2, Partie 4)."""
from lot2_commun import *
POINT = mkPOINT('dx8')
M = META('dx8', 'DX.8', 'Lipome superficiel', 'Lipome superficiel', 'LOT_002_DX8_Lipome_superficiel_AUDITÉ.html', 4,
         'Les doses maximales de lidocaïne proviennent de l’AIPS ; elles restent à vérifier par un médecin.')
LIP = T('lipome', 'Le lipome est une tumeur bénigne faite d’adipocytes matures, entourée d’une fine capsule ; il ne devient pratiquement jamais malin.')
TLA = T('tumeur lipomateuse atypique', 'La tumeur lipomateuse atypique (ou liposarcome bien différencié) est une tumeur graisseuse à malignité locale, qui récidive sans métastaser ; elle se distingue du lipome par l’amplification du gène MDM2.')
GLI = T('signe du glissement', 'Le signe du glissement : sous une pression douce du doigt, le bord du lipome glisse et fuit ; il traduit une masse molle, encapsulée et non adhérente.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Le {LIP} superficiel est une tumeur bénigne du tissu graisseux sous-cutané, molle, mobile et indolore. '
   'C’est la tumeur des tissus mous la plus fréquente. '
   f'Le mot « superficiel » signifie au-dessus du fascia ; une masse graisseuse profonde ou volumineuse fait évoquer une {TLA}.', 17, 83, 44) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Lipome superficiel', 'Sous-cutané, au-dessus du fascia', 'Lipome profond (intramusculaire)'],
    ['Angiolipome', 'Petit lipome vascularisé, douloureux, souvent multiple', 'Lipome simple, indolore'],
    ['Lipomatose symétrique (Madelung)', 'Masses graisseuses du cou et des épaules, alcool', 'Lipomes multiples'],
    ['Tumeur lipomateuse atypique', 'MDM2 amplifié, malignité locale', 'Lipome'],
    ['Kyste épidermoïde', 'Kyste à point central, contenu sébacé', 'Lipome'],
   ]) + P('Le mot « lipome » ne doit être retenu que si la masse a tous les caractères d’une lésion superficielle bénigne ; sinon, on parle de « masse des tissus mous » à caractériser.', 44, 2))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('Aucune incidence suisse du lipome n’est publiée, car cette tumeur bénigne n’est pas enregistrée par les registres des cancers. '
   'Dans une grande série américaine de tumeurs des tissus mous adressées pour expertise, les lipomes représentaient 16 % des tumeurs bénignes. '
   'En Europe, l’ESMO estime que les tumeurs bénignes dépassent largement les sarcomes, sans incidence européenne du lipome. '
   'En Suisse, le sarcome des tissus mous touche environ 340 personnes par an, soit environ 4 pour 100 000 habitants.', 83, 60) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Lipomes parmi les tumeurs bénignes des tissus mous', '16 %', 'Série de Kransdorf 1995 (centre de référence)'],
    ['Rapport tumeurs bénignes / sarcomes', 'Environ 100 pour 1', 'Ordre de grandeur de la littérature (à vérifier par un médecin)'],
    ['Sarcomes des tissus mous en Suisse', '≈ 340 par an (≈ 4 / 100 000)', 'NKRS 2018–2022'],
    ['Âge habituel', '40–60 ans', 'NHS, Kransdorf'],
    ['Incidence du lipome en Suisse', 'Non publiée', 'Aucune source'],
   ]) + P('Les facteurs de risque sont rares : antécédents familiaux (lipomatose familiale), alcool (Madelung). Le pronostic est excellent ; la récidive après exérèse complète est rare.', 17, 83, 74))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Un clone d’adipocytes matures prolifère lentement dans l’hypoderme et s’entoure d’une fine capsule fibreuse. '
   'Des remaniements du chromosome 12 (gène HMGA2) sont fréquents dans le lipome, sans amplification de MDM2. '
   'Le lipome refoule les tissus sans les envahir, ce qui explique sa mobilité et l’absence de douleur.', 83, 44) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'L’hypoderme se situe entre le derme et le fascia superficiel ; il contient des lobules graisseux.'],
    ['Physiologie', 'Les adipocytes stockent les triglycérides ; leur renouvellement est lent.'],
    ['Physiopathologie', 'Un clone adipocytaire bénin (souvent un réarrangement HMGA2) croît lentement et s’encapsule.'],
    ['Clinique', 'D’où une masse molle, mobile, indolore, à croissance lente, sous une peau normale.'],
    ['Examens', 'L’échographie montre une masse hyperéchogène homogène, sans vascularisation interne ; l’IRM et le MDM2 servent au moindre doute.'],
    ['Traitement', 'Une masse bénigne et non gênante se surveille ; sa capsule permet une exérèse complète si elle gêne.'],
   ]), 83, 44) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Prolifération adipocytaire bénigne', 'Échographie', 'Surveillance'],
    ['Encapsulation', 'Palpation (glissement)', 'Exérèse par énucléation'],
    ['Croissance lente', 'Mesures répétées', 'Réévaluation si croissance'],
    ['Amplification de MDM2 (tumeur atypique)', 'FISH MDM2 sur biopsie', 'Exérèse en centre de référence'],
    ['Compression nerveuse (rare)', 'Examen neurologique', 'Exérèse'],
   ]) + P('Cette chaîne explique pourquoi la profondeur et la taille comptent plus que la consistance : elles séparent le lipome des tumeurs à risque.', 44, 74))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin vérifie d’abord qu’il n’existe aucune urgence, ce qui est la règle. '
   'Il cherche ensuite les drapeaux rouges d’un sarcome : taille > 5 cm, siège profond, croissance, douleur, récidive. '
   'Enfin, il retient le lipome seulement si la masse est superficielle, molle, mobile, < 5 cm et stable.', 2, 44, 37) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Lipome' + PR('16 % des tumeurs bénignes des tissus mous', 83), 'Masse molle, mobile, superficielle, stable', 'Échographie'],
    ['Toutes tumeurs bénignes contre sarcomes' + PR('≈ 100 pour 1 (à vérifier)', 74), 'Ordre de grandeur', 'Drapeaux rouges'],
    DDXROW('sarc', 'Masse > 5 cm, profonde, croissante', 'IRM, biopsie au trocart en centre'),
    ['Kyste épidermoïde' + PR('incidence non publiée', 17), 'Point central, inflammation', 'Échographie'],
    ['Angiolipome' + PR('incidence non publiée', 83), 'Petit, douloureux, multiple', 'Échographie'],
    DDXROW('react', 'Masse aux sites ganglionnaires', 'Échographie (hile graisseux)', 'Adénopathie'),
    DDXROW('nhl', 'Masse ganglionnaire ferme', 'Biopsie'),
   ]) + P('Les deux premières lignes sont des proportions parmi les tumeurs des tissus mous ; les lignes « / 100 000 » sont des incidences suisses annuelles, d’une autre unité, et ne se comparent pas directement.', 83, 74, 60))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien date la masse, précise sa croissance, sa douleur et la gêne qu’elle cause.', 17, 2) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis quand la masse est-elle là ?', 'Ancienneté et stabilité rassurent.', 'Surveillance'],
    ['A-t-elle grossi ces derniers mois ?', 'Croissance : drapeau rouge.', 'IRM'],
    ['Est-elle douloureuse ?', 'Douleur : angiolipome ou sarcome.', 'Imagerie'],
    ['Avez-vous déjà eu une masse enlevée au même endroit ?', 'Récidive : drapeau rouge.', 'Centre de référence'],
    ['Avez-vous d’autres masses ?', 'Lipomatose.', 'Examen complet'],
    ['Prenez-vous un anticoagulant ?', 'Exérèse.', 'Plan opératoire'],
   ])) +
 U('<b>Drapeaux rouges</b> (Swiss Sarcoma Network, ESSR 2023) : masse > 5 cm, profonde sous le fascia, croissante, douloureuse, dure ou récidivante ; ils imposent une IRM et l’adresse à un centre sarcome avant toute exérèse.', 2, 44, 18)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure la masse avec une règle, puis il apprécie sa consistance, sa mobilité et sa profondeur par la contraction du muscle sous-jacent. '
   f'Un lipome superficiel reste mobile pendant la contraction et présente un {GLI}. '
   'L’examen ne suffit pas pour une masse > 5 cm ou profonde.', 44, 17) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal (lipome)', 'Anomalie et signification'], [
    ['Mesure à la règle', '< 5 cm', '> 5 cm : drapeau rouge'],
    ['Palpation', 'Molle, élastique', 'Dure : sarcome possible'],
    ['Mobilité pendant la contraction musculaire', 'Masse mobile, superficielle', 'Masse fixée ou disparaissant : profonde'],
    ['Peau en regard', 'Normale', 'Point central : kyste ; rougeur : abcès'],
    ['Examen des aires ganglionnaires', 'Normal', 'Adénopathie : autre diagnostic'],
   ]) + P('La transillumination n’a pas de valeur pour le lipome ; elle concerne les masses liquidiennes.', 44))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Le lipome n’a habituellement aucun signe fonctionnel, en dehors de la gêne esthétique. '
   'Ses signes physiques sont une masse molle, lobulée, mobile, indolore. '
   'Il ne donne pas de syndrome général ni de syndrome compressif, sauf rare contact nerveux.', 17) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    [GLI, 'Le bord fuit sous le doigt', 'Masse molle encapsulée'],
    ['Lobulation', 'Surface bosselée', 'Lobules graisseux'],
    ['Douleur', 'Rare ; fréquente dans l’angiolipome', 'Microthromboses vasculaires'],
    ['Compression', 'Paresthésies', 'Contact nerveux (rare)'],
   ]) + P('Termes : ' + TLA + '.', 74))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Selon la recommandation ESSR 2023, le critère d’un lipome est une masse superficielle < 5 cm à l’aspect échographique typique. '
   'L’IRM seule ne suffit pas à exclure une tumeur atypique ; l’absence d’amplification de MDM2 tranche.', 44, 74) +
 F('Éléments qui confirment ou réfutent',
   TAB(['Confirme', 'Réfute ou fait revoir'], [
    ['Échographie : masse hyperéchogène homogène, sans flux', 'Flux interne, zones solides'],
    ['IRM : signal identique à la graisse, septa fins < 2 mm', 'Septa épais, nodules, prise de contraste'],
    ['FISH MDM2 non amplifiée', 'MDM2 amplifié : tumeur lipomateuse atypique'],
    ['Taille < 5 cm, superficielle', 'Taille > 5 cm ou profonde'],
   ]) + P('Ces critères sont tirés de l’ESSR 2023 et de l’ESMO 2021.', 44, 74))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Échographie', 'Caractère graisseux superficiel', 'Bonne sensibilité pour une masse superficielle typique ; spécificité limitée', 'Opérateur-dépendante'],
    ['IRM avec et sans gadolinium', 'Profondeur, septa, nodules', 'Référence d’imagerie', 'Ne distingue pas toujours lipome et tumeur atypique'],
    ['Histologie avec FISH MDM2', 'Diagnostic définitif', 'Gold standard', 'Biopsie au trocart en centre'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Aucun examen', 'Masse < 5 cm, superficielle, typique, stable'],
    ['Première', 'Échographie', 'Doute clinique'],
    ['Seconde', 'IRM', '> 5 cm, profonde, échographie atypique'],
    ['Seconde', 'Biopsie au trocart en centre sarcome', 'IRM suspecte'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['L’<b>échographie</b> ne demande aucune préparation.', 'L’<b>IRM</b> demande la créatinine si le gadolinium est injecté, et la recherche d’un dispositif métallique.', 'La <b>biopsie</b> se fait dans le centre qui opérera, selon un trajet planifié.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Aspect normal du lipome : graisse homogène', '< 5 cm', 'Rassurant', 'Surveillance'],
    ['Septa à l’IRM', '< 2 mm', 'Lipome probable', 'Surveillance'],
    ['Résultat positif : MDM2 amplifié', '—', 'Tumeur lipomateuse atypique', 'Centre sarcome'],
    ['Résultat négatif : MDM2 non amplifié', '—', 'Lipome', 'Exérèse simple si gêne'],
    ['Résultat limite : IRM équivoque', '—', 'Incertitude', 'Biopsie'],
    ['Résultat discordant : imagerie rassurante, croissance clinique', '—', 'Revoir', 'IRM, centre'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Échographie ; IRM sans gadolinium ; exérèse différée'],
    ['Enfant', 'Le lipome est rare : toute masse des tissus mous est caractérisée'],
    ['DFGe < 30 mL/min/1,73 m²', 'IRM sans gadolinium'],
    ['Allergie à l’iode', 'Sans objet : l’IRM utilise le gadolinium'],
    ['Stimulateur cardiaque', 'Échographie ; IRM selon la compatibilité'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Une masse superficielle typique de moins de 5 cm ne demande aucun examen. '
   'L’échographie est l’examen de première intention en cas de doute. '
   'L’IRM et la biopsie avec recherche d’amplification de MDM2 sont réservées aux masses à drapeau rouge.', 44, 74) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si la masse est superficielle, < 5 cm, molle et stable, alors le médecin rassure et propose une surveillance ou une exérèse simple si elle gêne. '
   'Si elle est > 5 cm, profonde, croissante ou douloureuse, alors il demande une IRM et adresse à un centre sarcome. '
   'Si l’histologie après exérèse est inattendue, alors il adresse au centre sans délai.', 2, 44) +
 F('Embranchements',
   TAB(['Si…', 'Alors…', 'Contrôle'], [
    ['Masse typique < 5 cm', 'Surveillance', 'Revoir si changement'],
    ['Gêne esthétique ou fonctionnelle', 'Exérèse sous anesthésie locale', 'Histologie systématique'],
    ['> 5 cm, profonde, croissante', 'IRM, centre sarcome', 'Avant toute exérèse'],
    ['Histologie : MDM2 amplifié', 'Centre sarcome', 'Reprise chirurgicale'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Lidocaïne 1 %, RAPIDOCAIN® ou XYLOCAINE® (anesthésique local amide, bloque les canaux sodiques)', 'Sans adrénaline : maximum ≈ 4,5 mg/kg (300 mg) ; avec adrénaline : maximum ≈ 7 mg/kg (500 mg) ; demi-vie ≈ 1,5–2 heures ; métabolisme hépatique ; dose unique', 'Toxicité systémique (goût métallique, convulsions, troubles du rythme) ; contre-indiquée en cas d’allergie aux amides ; interactions avec les antiarythmiques'],
   ['Paracétamol, DAFALGAN®', '500–1000 mg toutes les 4–8 heures, maximum 4 g par jour, 1–3 jours', 'Hépatotoxicité en surdosage'],
   ['Ibuprofène (AINS)', '400 mg jusqu’à 3 fois par jour avec un repas, 1–3 jours', 'Saignement, gastrique, rénal'],
  ]) + P('Les doses maximales de lidocaïne sont celles de l’AIPS ; le médecin les vérifie pour la spécialité utilisée.', 82, 10))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est de confirmer la bénignité, puis de choisir avec le patient entre surveillance et exérèse. '
   'L’abstention est légitime pour un lipome typique non gênant. '
   'L’exérèse sous anesthésie locale est indiquée en cas de gêne, de croissance ou de doute, avec une histologie systématique.', 17, 44) +
 F('11.A Buts : urgence ou non',
   P('Le lipome non compliqué n’est jamais une urgence ; une forme compliquée (hématome postopératoire compressif) se revoit dans l’heure. Le but chiffré est une exérèse complète, avec une capsule intacte.', 17), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Expliquer la bénignité et les signes qui doivent faire revenir.', 'Mesurer et photographier la masse.', 'Proposer la surveillance ou l’exérèse.', 'En cas d’exérèse : anesthésie locale, énucléation, hémostase, histologie.', 'Lire et transmettre le compte rendu histologique.']), 17, 44) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal prend en charge l’exérèse si elle est médicalement indiquée ; une exérèse purement esthétique peut ne pas être remboursée.', 'Un arrêt de travail de quelques jours est possible après exérèse d’un gros lipome ou d’un travail physique.', 'La LAA et la LAI ne sont pas concernées ; la conduite automobile est possible le jour même après une anesthésie locale.']), 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Exérèse différée ; lidocaïne possible si nécessaire.'],
      ['Personne âgée', 'Seuil d’IRM bas si croissance.'],
      ['Enfant', 'Masse rare : imagerie systématique.'],
      ['Insuffisance hépatique', 'Dose de lidocaïne réduite.'],
      ['Insuffisance rénale (DFGe)', 'Éviter les AINS ; IRM sans gadolinium si DFGe < 30.'],
      ['Anticoagulants', 'Plan selon le risque hémorragique et thrombotique.'],
     ]), 82, 44), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Taille', 'À 3–6 mois si surveillance', 'Croissance : IRM'],
    ['Plaie opératoire', 'À 7–14 jours', 'Infection, hématome'],
    ['Histologie', 'À réception', 'Lésion atypique : centre'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Hémostase contrôlée.', 'Douleur contrôlée.', 'Consignes de soins de plaie.', 'Rendez-vous de résultat histologique fixé.']), 17) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La guérison est la règle après exérèse complète, et la récidive est rare. La recherche 2026 évalue l’intelligence artificielle appliquée à l’IRM pour séparer lipome et tumeur atypique.', 83, 44), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('Aucune prévention primaire du lipome n’est connue. '
   'La prévention secondaire consiste à reconnaître les drapeaux rouges d’un sarcome. '
   'La prévention tertiaire évite les exérèses inadaptées (« whoops procedure ») qui compromettent le traitement d’un sarcome.', 2, 74) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Aucune ; réduire l’alcool dans la lipomatose de Madelung'],
    ['Secondaire', 'IRM et centre pour toute masse à drapeau rouge (recommandation suisse du Swiss Sarcoma Network)'],
    ['Tertiaire', 'Histologie systématique de toute pièce opératoire'],
   ]), 2)))
PTS.append(POINT(13, 'Points clés',
 P('Le lipome superficiel est une masse molle, mobile, indolore, de moins de 5 cm. '
   'Le médecin cherche toujours les drapeaux rouges : taille > 5 cm, profondeur, croissance, douleur, récidive. '
   'Il demande une IRM et adresse à un centre sarcome devant un drapeau rouge, avant toute exérèse. '
   'Il fait analyser toute pièce opératoire. '
   'Il sait que l’amplification de MDM2 distingue la tumeur lipomateuse atypique du lipome.', 2, 44, 74)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Une masse molle est forcément un lipome.', 'Faux : la profondeur et la taille priment.'],
  ['Enlever une masse de 8 cm au cabinet.', 'Erreur : IRM et centre sarcome d’abord.'],
  ['Jeter la pièce opératoire.', 'Erreur : histologie systématique.'],
  ['L’IRM exclut toujours la malignité.', 'Faux : MDM2 au moindre doute.'],
  ['Un angiolipome douloureux est un sarcome.', 'Pas forcément : il est typiquement douloureux.'],
 ]) + P('Ces pièges reprennent l’ESSR 2023 et le Swiss Sarcoma Network.', 44, 2)))
CTX = {'_prefixe': 'Devant un lipome superficiel',
 'echo': 'Une masse hyperéchogène homogène, superficielle, sans flux, < 5 cm est typique d’un lipome.',
 'irm': 'L’IRM d’un lipome montre un signal identique à la graisse avec des septa fins ; des nodules ou des septa épais font suspecter une tumeur atypique.',
 'mdm2': 'L’amplification de MDM2 en FISH distingue la tumeur lipomateuse atypique du lipome.',
 'biopsie': 'La biopsie au trocart d’une masse suspecte se fait dans le centre sarcome qui opérera.',
 'tdm': 'Le scanner est moins performant que l’IRM pour caractériser une masse graisseuse.',
 'creat': 'Le DFGe décide de l’injection de gadolinium.',
 'echogg': 'Une adénopathie à hile graisseux ne doit pas être confondue avec un lipome.',
 'radio': 'La radiographie est inutile pour un lipome superficiel.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
