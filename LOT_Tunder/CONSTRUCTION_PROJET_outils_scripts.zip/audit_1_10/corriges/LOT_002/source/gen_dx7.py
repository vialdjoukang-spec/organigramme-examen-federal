# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.7 · Métastase ganglionnaire d’un carcinome (LOT 2, Partie 3)."""
from lot2_commun import *
POINT = mkPOINT('dx7')
M = META('dx7', 'DX.7', 'Métastase ganglionnaire', 'Métastase ganglionnaire d’un carcinome', 'LOT_002_DX7_Metastase_ganglionnaire_carcinome_AUDITÉ.html', 3,
         'Les doses de cisplatine et de cétuximab sont des doses standard publiées (EHNS-ESMO-ESTRO 2020) ; elles sont prescrites par l’oncologue.')
CUP = T('cancer de site primitif inconnu', 'Le cancer de site primitif inconnu (CUP) est une métastase prouvée histologiquement dont le primitif reste introuvable après un bilan complet et standardisé.')
P16 = T('p16', 'La protéine p16 est surexprimée quand l’oncoprotéine E7 du papillomavirus humain (HPV) inactive la protéine Rb ; son immunohistochimie sert de marqueur indirect d’un cancer de l’oropharynx lié au HPV.')
TRO = T('ganglion de Troisier', 'Le ganglion de Troisier est une adénopathie sus-claviculaire gauche, au débouché du canal thoracique ; il révèle souvent un cancer digestif ou pelvien.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('Une métastase ganglionnaire de carcinome est l’envahissement d’un ganglion par des cellules épithéliales malignes venues d’une tumeur primitive de son territoire de drainage. '
   'Au cou, le primitif est le plus souvent un carcinome épidermoïde des voies aérodigestives supérieures ; en sus-claviculaire, il est souvent thoracique ou abdominal. '
   f'Si le primitif reste introuvable après un bilan complet, on parle de {CUP}.', 16, 15, 79) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Carcinome épidermoïde', 'Cancer des épithéliums malpighiens (bouche, pharynx, larynx, peau)', 'Adénocarcinome (glandes)'],
    ['Adénocarcinome', 'Cancer d’un épithélium glandulaire (poumon, sein, tube digestif, thyroïde)', 'Carcinome épidermoïde'],
    ['N+ (TNM)', 'Atteinte ganglionnaire régionale', 'M1 : métastase à distance'],
    ['CUP', 'Primitif non retrouvé après bilan', 'Primitif non encore cherché'],
    ['Extension extracapsulaire', 'Tumeur au-delà de la capsule du ganglion', 'Ganglion simplement augmenté'],
   ]) + P(f'Le marqueur {P16} sépare deux maladies de pronostic différent dans l’oropharynx.', 16, 78))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, environ 1200 cancers de la bouche et du pharynx et 260 cancers du larynx sont diagnostiqués chaque année (NKRS 2018–2022), soit environ 16 pour 100 000 habitants. '
   'La part des cancers de l’oropharynx liés au HPV augmente en Europe. '
   'Le CUP représente environ 1–2 % de tous les cancers selon l’ESMO 2023.', 60, 78, 79) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Cancers de la bouche et du pharynx en Suisse', '≈ 1200 par an', 'NKRS 2018–2022'],
    ['Cancers du larynx en Suisse', '≈ 260 par an', 'NKRS 2018–2022'],
    ['Mélanome en Suisse', '≈ 3500 par an', 'NKRS 2018–2022'],
    ['CUP parmi les cancers', '≈ 1–2 %', 'ESMO 2023 (Europe)'],
    ['Malignité d’une adénopathie sus-claviculaire', '34–50 %', 'Gaddey 2016'],
   ]) + P('Les facteurs de risque sont le tabac, l’alcool, le HPV (oropharynx), l’EBV (nasopharynx) et l’exposition solaire (peau). Le pronostic dépend du primitif ; les cancers de l’oropharynx liés au HPV ont un meilleur pronostic que les cancers liés au tabac.', 60, 78, 66))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Des cellules tumorales se détachent du primitif, entrent dans les vaisseaux lymphatiques et sont arrêtées dans le premier ganglion de drainage. '
   'Elles y prolifèrent, remplacent le tissu lymphoïde et finissent par franchir la capsule. '
   'La masse devient alors dure, indolore puis fixée aux tissus voisins.', 16, 78) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Le cou est divisé en niveaux ganglionnaires I à VI ; chaque niveau draine des sites précis (niveau II : oropharynx, cavité buccale ; niveau IV et sus-claviculaire : thorax, abdomen).'],
    ['Physiologie', 'Le ganglion filtre la lymphe et arrête les cellules venues de son territoire.'],
    ['Physiopathologie', 'Les cellules tumorales s’implantent dans le sinus sous-capsulaire, puis remplacent le ganglion ; une nécrose centrale lui donne parfois un aspect kystique (HPV).'],
    ['Clinique', 'D’où une masse dure, indolore, croissante, parfois kystique, avec des signes du primitif (dysphonie, dysphagie, otalgie).'],
    ['Examens', 'La cytoponction échoguidée prouve le carcinome ; l’immunohistochimie, la p16 et l’EBV orientent vers le primitif ; la TEP-TDM et la panendoscopie le cherchent.'],
    ['Traitement', 'On traite le primitif et le cou ensemble : chirurgie avec curage, ou radiochimiothérapie.'],
   ]), 16, 78, 79) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Drainage lymphatique du primitif', 'Niveau ganglionnaire, examen ORL', 'Curage ganglionnaire'],
    ['Carcinome épidermoïde', 'Cytoponction, immunohistochimie (p40, p63)', 'Radiothérapie, cisplatine'],
    ['Oncogenèse HPV (E6, E7)', 'p16, ADN du HPV tumoral', 'Désescalade étudiée'],
    ['Oncogenèse EBV (nasopharynx)', 'ARN de l’EBV (EBER)', 'Radiochimiothérapie'],
    ['Récepteur EGFR surexprimé', 'Immunohistochimie', 'Cétuximab'],
    ['Échappement immunitaire (PD-L1)', 'Score CPS', 'Pembrolizumab en récidive'],
   ]) + P('Cette chaîne explique pourquoi une biopsie chirurgicale ouverte d’un ganglion épidermoïde est à éviter : elle disperse les cellules et complique le traitement du cou.', 78, 16))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin recherche d’abord une urgence : dyspnée, stridor, dysphagie totale ou hémorragie. '
   'Il considère ensuite toute masse cervicale persistante de l’adulte de plus de 40 ans comme une métastase jusqu’à preuve du contraire. '
   'Enfin, il fait examiner les voies aérodigestives supérieures avant toute biopsie ganglionnaire.', 37, 16, 78) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    DDXROW('orl', 'Fumeur, alcool, dysphonie, otalgie, masse niveau II–III', 'Examen ORL, cytoponction, p16'),
    DDXROW('mel', 'Lésion pigmentée, cuir chevelu', 'Examen cutané, SOX10'),
    DDXROW('thy', 'Masse thyroïdienne, niveau VI', 'Échographie, calcitonine, thyroglobuline'),
    DDXROW('nhl', 'Adénopathies multiples, symptômes B', 'Biopsie-exérèse'),
    DDXROW('hl', 'Adulte jeune, médiastin', 'Biopsie-exérèse'),
    DDXROW('tb', 'Migration, nécrose caséeuse', 'Culture, IGRA'),
    ['Kyste de la deuxième fente branchiale' + PR('incidence non publiée', 66), 'Adulte jeune, masse kystique latérale', 'Cytoponction ; méfiance après 40 ans (métastase HPV kystique)'],
   ]) + P(UNITE + ' Ces valeurs mesurent le cancer primitif, et non la seule présentation ganglionnaire.', 60, 62))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien recherche le tabac, l’alcool, les signes ORL et les antécédents de cancer. '
   'Il recherche aussi la perte de poids et les symptômes d’un primitif thoracique, mammaire ou digestif.', 16, 37) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Fumez-vous, combien de paquets-années ?', 'Risque de carcinome épidermoïde.', 'Panendoscopie'],
    ['Avez-vous la voix enrouée depuis plus de 3 semaines ?', 'Cancer du larynx.', 'Laryngoscopie urgente'],
    ['Avez-vous mal à l’oreille, de la peine à avaler ?', 'Otalgie réflexe, cancer du pharynx.', 'Examen ORL'],
    ['Avez-vous eu un cancer, un grain de beauté enlevé ?', 'Récidive, mélanome.', 'Comparer l’histologie'],
    ['Avez-vous perdu du poids ?', 'Maladie avancée.', 'Bilan d’extension'],
    ['Avez-vous des saignements dans la bouche ?', 'Lésion ulcérée.', 'Examen buccal'],
   ])) +
 U('<b>Drapeaux rouges</b> : stridor ou dyspnée (urgences), hémorragie buccale, masse cervicale inexpliquée persistante après 45 ans, dysphonie > 3 semaines, dysphagie progressive ; ils imposent un avis ORL urgent selon NICE NG12.', 37, 16)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin palpe les niveaux I à VI et les creux sus-claviculaires, puis il inspecte la bouche, palpe la langue et le plancher buccal. '
   'Il examine la peau du visage et du cuir chevelu, les seins, la thyroïde et l’abdomen. '
   'L’examen ORL par nasofibroscopie est indispensable et relève du spécialiste.', 16, 78) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal', 'Anomalie et signification'], [
    ['Palpation par niveau', 'Ganglions < 1 cm', 'Masse dure, fixée, niveau II–III : ORL'],
    ['Palpation sus-claviculaire', 'Aucun ganglion', TRO + ' : primitif abdominal'],
    ['Inspection et palpation buccales', 'Muqueuse lisse', 'Ulcération indurée, leucoplasie'],
    ['Examen de la peau', 'Pas de lésion suspecte', 'Lésion pigmentée asymétrique : mélanome'],
    ['Palpation thyroïdienne', 'Thyroïde souple', 'Nodule dur'],
    ['Nasofibroscopie (ORL)', 'Muqueuse normale', 'Lésion du cavum, du pharynx, du larynx'],
   ]) + P('Un ganglion dur et fixé a une valeur prédictive de malignité élevée, mais sa mobilité n’exclut pas une métastase.', 66, 64))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la masse, la dysphonie, la dysphagie, l’otalgie et la perte de poids. '
   'Les signes physiques sont la masse dure, la lésion muqueuse et la fixation. '
   'Ils forment un syndrome tumoral cervical, parfois un syndrome d’envahissement local.', 16) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    ['Adénopathie dure et fixée', 'Masse pierreuse adhérente', 'Rupture capsulaire'],
    ['Adénopathie kystique', 'Masse liquidienne de l’adulte', 'Nécrose d’une métastase HPV'],
    ['Otalgie réflexe', 'Douleur d’oreille sans otite', 'Nerfs glossopharyngien et vague'],
    ['Dysphonie', 'Voix rauque persistante', 'Atteinte laryngée ou récurrentielle'],
    ['Trismus', 'Limitation d’ouverture buccale', 'Envahissement des muscles masticateurs'],
   ]) + P('Termes : ' + CUP + '.', 79))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le diagnostic repose sur la cytologie ou l’histologie du ganglion, complétée par l’immunohistochimie. '
   'Le critère de CUP selon l’ESMO 2023 exige un bilan standardisé négatif : examen clinique complet, scanner thoraco-abdomino-pelvien, TEP-TDM et panendoscopie pour le cou. '
   'Une adénopathie > 1 cm ronde à l’échographie ne suffit pas : la preuve est cytologique ou histologique.', 79, 78) +
 F('Éléments qui confirment ou réfutent',
   TAB(['Confirme', 'Réfute ou fait revoir'], [
    ['Cytoponction : cellules carcinomateuses', 'Population lymphoïde polymorphe : réactionnel ou lymphome'],
    ['p16 positive : primitif oropharyngé probable', 'p16 négative : primitif lié au tabac ou autre'],
    ['EBER positif : nasopharynx probable', 'Thyroglobuline positive : cancer thyroïdien'],
    ['TTF-1 positif : poumon ou thyroïde', 'CK7 et CK20 orientent vers d’autres primitifs'],
   ]) + P('La classification TNM 8e édition (UICC 2017) distingue les cancers oropharyngés p16 positifs et négatifs.', 78))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Cytoponction échoguidée', 'Carcinome dans le ganglion', 'Sensibilité et spécificité élevées pour le carcinome (valeurs variables selon les séries)', 'Insuffisante pour le lymphome'],
    ['Histologie (biopsie au trocart ou pièce de curage)', 'Type et marqueurs', 'Référence', 'Biopsie ouverte à éviter avant le bilan ORL'],
    ['TEP-TDM au FDG', 'Primitif, extension', 'Trouve un primitif dans une partie des CUP', 'Faux positifs inflammatoires'],
    ['Panendoscopie sous anesthésie', 'Primitif ORL', 'Référence ORL avec biopsies', 'Anesthésie générale'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Examen ORL avec nasofibroscopie', 'Masse cervicale persistante'],
    ['Première', 'Échographie et cytoponction échoguidée', 'Masse > 1 cm, suspecte'],
    ['Première', 'p16 et ADN du HPV tumoral, EBER', 'Carcinome épidermoïde cervical'],
    ['Seconde', 'TEP-TDM puis panendoscopie avec biopsies', 'Primitif non vu'],
    ['Seconde', 'Scanner ou IRM cervicale', 'Extension locale'],
    ['Seconde', 'Scanner thoraco-abdomino-pelvien', 'Adénocarcinome ou siège sus-claviculaire'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La <b>TEP-TDM</b> se fait avant la panendoscopie, car les biopsies créent une inflammation qui fixe le traceur.', 'La <b>cytoponction</b> ne demande pas d’arrêt de l’aspirine.', 'Le <b>scanner</b> injecté demande la créatinine.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Échographie normale : ganglion ovale à hile graisseux', 'Petit axe < 10 mm', 'Rassurant', 'Surveillance'],
    ['Échographie : ganglion rond, sans hile, nécrotique', 'Petit axe > 10 mm', 'Suspect', 'Cytoponction'],
    ['Résultat positif : carcinome épidermoïde p16+', '—', 'Oropharynx probable', 'TEP, panendoscopie'],
    ['Résultat négatif : cytologie non contributive', '—', 'Prélèvement insuffisant', 'Nouvelle cytoponction ou trocart'],
    ['Résultat limite : atypies', '—', 'Incertain', 'Histologie'],
    ['Résultat discordant : cytologie bénigne, clinique très suspecte', '—', 'Faux négatif possible', 'Biopsie au trocart'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Échographie, cytoponction, IRM sans gadolinium ; TEP différée'],
    ['Enfant', 'Masse cervicale rarement carcinomateuse : lymphome et sarcome d’abord'],
    ['DFGe < 30 mL/min/1,73 m²', 'IRM sans gadolinium ou TEP ; cisplatine contre-indiqué'],
    ['Allergie à l’iode', 'IRM, TEP sans contraste'],
    ['Stimulateur cardiaque', 'Scanner ; IRM selon la compatibilité'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('L’examen ORL et la cytoponction échoguidée sont les premiers examens d’une masse cervicale suspecte. '
   'La p16, l’ADN du HPV tumoral et l’EBER orientent vers le primitif. '
   'La TEP-TDM puis la panendoscopie cherchent un primitif non visible.', 16, 78, 79) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une masse cervicale persiste plus de 3 semaines chez un adulte, alors le médecin l’adresse à un ORL. '
   'Si la cytoponction montre un carcinome épidermoïde, alors l’ORL fait une TEP-TDM et une panendoscopie. '
   'Si le primitif est trouvé, alors le traitement est celui du cancer primitif avec le cou ; sinon, celui d’un CUP cervical.', 37, 78, 79) +
 F('Embranchements',
   TAB(['Si…', 'Alors…', 'Contrôle'], [
    ['Stridor, hémorragie', 'Urgences', 'Hospitalisation'],
    ['Masse cervicale persistante > 3 semaines', 'Avis ORL', 'Dans les 2 semaines'],
    ['Carcinome épidermoïde', 'p16, TEP-TDM, panendoscopie', 'RCP'],
    ['Adénocarcinome', 'Immunohistochimie, scanner thoraco-abdomino-pelvien', 'RCP'],
    ['Primitif non trouvé (CUP cervical)', 'Curage et radiothérapie ou radiochimiothérapie', 'Suivi ORL'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Cisplatine (sel de platine, pontages de l’ADN)', '100 mg/m² aux jours 1, 22 et 43 de la radiothérapie, ou 40 mg/m² par semaine ; élimination rénale', 'Néphrotoxicité, ototoxicité, neuropathie, vomissements ; contre-indiqué si clairance basse ou surdité ; hydratation obligatoire'],
   ['Cétuximab, ERBITUX® (anticorps anti-EGFR)', '400 mg/m² puis 250 mg/m² par semaine pendant la radiothérapie', 'Éruption acnéiforme, réaction à la perfusion, hypomagnésémie ; alternative si cisplatine contre-indiqué'],
   ['Pembrolizumab, KEYTRUDA® (anticorps anti-PD-1)', '200 mg toutes les 3 semaines ou 400 mg toutes les 6 semaines ; récidive ou métastases si CPS ≥ 1', 'Effets immunologiques (thyroïdite, colite, pneumopathie)'],
   ['Ondansétron (antagoniste 5-HT3)', '8 mg avant la chimiothérapie', 'Constipation, allongement du QT'],
  ]) + P('Ces doses sont celles de l’EHNS-ESMO-ESTRO 2020 ; le schéma est prescrit par l’oncologue après vérification de l’AIPS.', 78, 82))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est de guérir le cancer en traitant ensemble le primitif et le cou, tout en préservant la parole et la déglutition. '
   'Le traitement est décidé en réunion de concertation pluridisciplinaire. '
   'Il associe chirurgie avec curage ganglionnaire, radiothérapie et souvent cisplatine.', 78, 16) +
 F('11.A Buts : urgence ou non',
   P('La forme compliquée (stridor, hémorragie) est une urgence à traiter dans l’heure. La forme non compliquée n’est pas une urgence vitale, mais le bilan doit être fait en 2–4 semaines ; le but chiffré est un traitement débuté dans les 6 semaines après le diagnostic.', 37, 78), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Arrêter le tabac et l’alcool.', 'Faire le bilan dentaire avant la radiothérapie.', 'Évaluer la nutrition (gastrostomie si besoin).', 'Traiter selon la RCP : chirurgie et curage, ou radiochimiothérapie.', 'Organiser la rééducation de la déglutition et de la voix.']), 78) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal prend en charge le traitement ; les soins dentaires liés à la radiothérapie peuvent être pris en charge.', 'Un arrêt de travail prolongé est fréquent ; la LAI intervient en cas d’incapacité durable.', 'La LAA est concernée seulement si une exposition professionnelle est reconnue ; la conduite automobile est déconseillée pendant la radiochimiothérapie.']), 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Centre spécialisé ; radiothérapie et chimiothérapie souvent différées.'],
      ['Personne âgée', 'Évaluation gériatrique ; cétuximab ou radiothérapie seule si cisplatine impossible.'],
      ['Enfant', 'Exceptionnel : centre pédiatrique.'],
      ['Insuffisance hépatique', 'Peu d’effet sur le cisplatine ; prudence avec les opioïdes.'],
      ['Insuffisance rénale (DFGe < 50–60)', 'Cisplatine contre-indiqué ; alternatives.'],
      ['Surdité', 'Cisplatine déconseillé.'],
     ]), 78), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Examen ORL', 'Tous les 2–3 mois pendant 2 ans, puis espacé jusqu’à 5 ans', 'Récidive'],
    ['TEP-TDM', '12 semaines après la radiochimiothérapie', 'Fixation résiduelle : curage'],
    ['TSH', 'Tous les 6–12 mois après irradiation du cou', 'Hypothyroïdie'],
    ['Nutrition, poids', 'À chaque visite', 'Perte > 10 % : soutien'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Déglutition ou alimentation entérale assurée.', 'Douleur contrôlée.', 'Plan de suivi ORL fixé.', 'Arrêt du tabac soutenu.']), 78) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic dépend du primitif, du stade et du statut HPV ; les cancers p16 positifs ont une meilleure survie. La recherche 2026 évalue la désescalade thérapeutique des cancers HPV et l’ADN tumoral circulant du HPV pour le suivi.', 78), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur l’arrêt du tabac, la modération de l’alcool, la protection solaire et la vaccination contre le HPV. '
   'La prévention secondaire consiste à adresser sans délai toute masse cervicale persistante. '
   'La prévention tertiaire comprend l’arrêt du tabac après traitement et la surveillance des seconds cancers.', 91, 37, 78) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Vaccination HPV des filles et des garçons de 11–14 ans selon le plan suisse, rattrapage jusqu’à 26 ans ; arrêt du tabac'],
    ['Secondaire', 'Avis ORL pour toute masse cervicale persistante > 3 semaines'],
    ['Tertiaire', 'Sevrage tabagique, examen ORL régulier'],
   ]), 91, 37)))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin considère toute masse cervicale persistante de l’adulte comme une métastase jusqu’à preuve du contraire. '
   'Il fait examiner les voies aérodigestives supérieures avant toute biopsie. '
   'Il préfère la cytoponction échoguidée à la biopsie chirurgicale ouverte. '
   'Il fait rechercher la p16 et l’ADN du HPV tumoral sur un carcinome épidermoïde. '
   'Il demande la TEP-TDM avant la panendoscopie.', 16, 78, 79)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Une masse kystique du cou de l’adulte est un kyste branchial.', 'Faux : penser à une métastase HPV.'],
  ['Faire d’emblée une biopsie-exérèse du ganglion.', 'Erreur : examen ORL et cytoponction d’abord.'],
  ['Faire la panendoscopie avant la TEP.', 'Erreur : faux positifs.'],
  ['Prescrire un antibiotique et attendre 2 mois.', 'Erreur : avis ORL après 3 semaines.'],
  ['Oublier le ganglion de Troisier.', 'Erreur : il révèle un cancer abdominal.'],
 ]) + P('Ces pièges reprennent l’EHNS-ESMO-ESTRO 2020, l’ESMO 2023 et NICE NG12.', 78, 79, 37)))
CTX = {'_prefixe': 'Devant une métastase ganglionnaire',
 'p16': 'Une p16 positive avec ADN du HPV tumoral oriente vers un cancer de l’oropharynx et améliore le pronostic.',
 'echogg': 'Un ganglion rond, sans hile, nécrotique ou kystique est suspect de métastase.',
 'echo': 'L’échographie guide la cytoponction.',
 'biopsie': 'La biopsie au trocart ou la pièce de curage confirme le type de carcinome ; la biopsie ouverte est évitée avant le bilan ORL.',
 'tep': 'La TEP-TDM recherche un primitif inconnu ; elle se fait avant la panendoscopie.',
 'endo': 'La panendoscopie sous anesthésie avec biopsies cherche un primitif ORL.',
 'tdm': 'Le scanner cervical et thoraco-abdomino-pelvien mesure l’extension.',
 'irm': 'L’IRM précise l’extension locale (base de langue, cavum).',
 'tg': 'Une thyroglobuline dans le liquide de cytoponction signe une métastase de cancer thyroïdien.',
 'calcito': 'Une calcitonine élevée oriente vers un cancer médullaire de la thyroïde.',
 'creat': 'La créatinine décide de la possibilité du cisplatine.',
 'tsh': 'La TSH dépiste une hypothyroïdie après irradiation du cou.',
 'pcr': 'La PCR de l’ADN du HPV confirme l’origine virale.',
 'radio': 'La radiographie du thorax recherche un primitif pulmonaire ou des métastases.',
 'nfs': 'L’hémogramme précède la chimiothérapie.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
