# -*- coding: utf-8 -*-
# Sources extraites des originaux LOT 2 (outils_local/sources_orig_lot2.py).
SOURCES_ORIG = {
}
