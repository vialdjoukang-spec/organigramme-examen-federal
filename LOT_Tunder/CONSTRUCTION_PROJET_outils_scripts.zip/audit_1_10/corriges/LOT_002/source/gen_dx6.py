# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.6 · Lymphome hodgkinien ou non hodgkinien (LOT 2, Partie 3)."""
from lot2_commun import *
POINT = mkPOINT('dx6')
M = META('dx6', 'DX.6', 'Lymphome', 'Lymphome hodgkinien ou non hodgkinien', 'LOT_002_DX6_Lymphome_hodgkinien_ou_non_hodgkinien_AUDITÉ.html', 3,
         'Les doses du protocole R-CHOP sont des doses standard publiées ; la chimiothérapie est toujours prescrite par un oncologue-hématologue.')
RS = T('cellule de Reed-Sternberg', 'La cellule de Reed-Sternberg est un grand lymphocyte B tumoral à deux noyaux, CD30 et CD15 positifs ; rare dans le ganglion, elle attire un abondant infiltrat inflammatoire qui forme la masse du lymphome de Hodgkin.')
SB = T('symptômes B', 'Les symptômes B sont une fièvre > 38 °C inexpliquée, des sueurs nocturnes profuses et une perte de poids > 10 % en 6 mois ; ils traduisent les cytokines tumorales et aggravent le pronostic.')
DV = T('score de Deauville', 'Le score de Deauville classe en 5 niveaux la fixation résiduelle du FDG à la TEP par rapport au médiastin et au foie ; les scores 1 à 3 signent une réponse métabolique complète.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('Un lymphome est un cancer des lymphocytes B, T ou NK, qui prolifèrent surtout dans les ganglions et les organes lymphoïdes. '
   f'Le lymphome de Hodgkin se définit par la présence de rares {RS} au sein d’un infiltrat inflammatoire. '
   'Tous les autres lymphomes sont dits non hodgkiniens ; le plus fréquent est le lymphome diffus à grandes cellules B (DLBCL).', 73, 13, 14) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Lymphome de Hodgkin', 'Cellules de Reed-Sternberg CD30+, CD15+', 'Hyperplasie réactionnelle'],
    ['Lymphome non hodgkinien agressif', 'Croissance en semaines (DLBCL, Burkitt)', 'Lymphome indolent'],
    ['Lymphome indolent', 'Croissance en mois ou années (folliculaire)', 'Adénopathie réactionnelle persistante'],
    ['Leucémie lymphoïde chronique', 'Lymphocytose clonale sanguine', 'Lymphocytose virale'],
    ['Stade de Lugano', 'Extension I à IV selon la TEP-TDM', 'Grade histologique'],
   ]) + P(f'Les {SB} sont un élément de stadification, pas un critère diagnostique.', 72, 73))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, environ 1700 nouveaux lymphomes non hodgkiniens et 290 lymphomes de Hodgkin sont diagnostiqués chaque année (NKRS 2018–2022). '
   'Cela correspond à environ 19 et 3 cas pour 100 000 habitants par an. '
   'Le lymphome de Hodgkin touche surtout l’adulte jeune, et le non hodgkinien surtout la personne de plus de 60 ans.', 60, 13, 14) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Lymphomes non hodgkiniens en Suisse', '≈ 1700 cas par an (≈ 19 / 100 000)', 'NKRS 2018–2022'],
    ['Lymphome de Hodgkin en Suisse', '≈ 290 cas par an (≈ 3 / 100 000)', 'NKRS 2018–2022'],
    ['DLBCL parmi les lymphomes non hodgkiniens', 'Environ un tiers', 'Europe, Onkopedia et ESMO'],
    ['Guérison du lymphome de Hodgkin', '> 80 % tous stades confondus', 'ESMO 2018'],
    ['Guérison du DLBCL sous R-CHOP', '≈ 60–70 %', 'ESMO 2015, Onkopedia'],
   ]) + P('Les facteurs de risque sont l’immunodépression (VIH, transplantation), l’EBV, certaines infections chroniques (Helicobacter pylori pour le lymphome du MALT) et les maladies auto-immunes. Le pronostic dépend du type histologique, du stade et de l’index pronostique.', 60, 14, 80, 81))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Un lymphocyte B ou T accumule des anomalies génétiques au moment où il se différencie dans le centre germinatif du ganglion. '
   'Ces anomalies bloquent sa mort programmée ou accélèrent sa division, et le clone remplace progressivement l’architecture normale du ganglion. '
   'La masse, les cytopénies et les cytokines expliquent les adénopathies, l’infiltration médullaire et les symptômes B.', 73, 14) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les ganglions, la rate, l’anneau de Waldeyer et la moelle contiennent les lymphocytes ; le médiastin est fréquemment atteint dans le Hodgkin.'],
    ['Physiologie', 'Les lymphocytes B mûrissent dans le centre germinatif, avec des réarrangements et des mutations normaux de leurs gènes d’immunoglobulines.'],
    ['Physiopathologie', 'Une erreur génétique (par exemple t(14;18) avec BCL2 dans le lymphome folliculaire) crée un clone qui ne meurt plus et détruit l’architecture.'],
    ['Clinique', 'D’où des adénopathies fermes, indolores, persistantes, parfois des symptômes B, une splénomégalie ou une compression.'],
    ['Examens', 'Seule la biopsie-exérèse montre l’architecture et le phénotype ; la TEP-TDM mesure l’extension.'],
    ['Traitement', 'Le clone est sensible à la chimiothérapie, aux anticorps (anti-CD20 rituximab, anti-CD30 brentuximab) et à la radiothérapie.'],
   ]), 73, 72) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Clone B CD20+', 'Immunohistochimie', 'Rituximab (anti-CD20)'],
    ['Cellules de Reed-Sternberg CD30+', 'Immunohistochimie', 'Brentuximab védotine (anti-CD30)'],
    ['Prolifération rapide', 'Ki-67, LDH', 'Chimiothérapie (anthracyclines)'],
    ['Métabolisme glucidique élevé', 'TEP au FDG', 'Évaluation de la réponse (Deauville)'],
    ['Lyse tumorale', 'Potassium, phosphate, acide urique, créatinine', 'Hydratation, allopurinol, rasburicase'],
    ['Immunodépression liée à l’EBV ou au VIH', 'Sérologies, charge virale', 'Restauration immunitaire'],
   ]) + P('Cette chaîne explique pourquoi une cytoponction ne suffit pas : elle donne des cellules isolées sans architecture.', 72, 81))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin recherche d’abord les urgences : compression de la veine cave supérieure, compression médullaire, syndrome de lyse et hypercalcémie. '
   'Il évoque ensuite un lymphome devant une adénopathie ferme, indolore, persistante plus de 4 semaines, surtout avec des symptômes B. '
   'Enfin, il obtient une biopsie-exérèse avant tout corticoïde.', 72, 64, 66) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    DDXROW('nhl', 'Plus de 60 ans, adénopathies multiples, LDH élevée', 'Biopsie-exérèse'),
    DDXROW('hl', 'Adulte jeune, médiastin, prurit, douleur à l’alcool', 'Biopsie-exérèse'),
    DDXROW('orl', 'Fumeur, ganglion cervical dur', 'Examen ORL, cytoponction'),
    DDXROW('mel', 'Lésion cutanée, ganglion de drainage', 'Examen cutané, biopsie'),
    DDXROW('tb', 'Migration, granulome', 'Culture, IGRA'),
    DDXROW('vih', 'Adénopathies diffuses', 'Test VIH'),
    DDXROW('react', 'Foyer récent, régression', 'Évolution'),
   ]) + P(UNITE, 60, 61, 62))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien date l’apparition des adénopathies et recherche les symptômes B, le prurit et la douleur provoquée par l’alcool. '
   'Il recherche une immunodépression, des antécédents de chimiothérapie et les signes de compression.', 72, 13) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis quand avez-vous ces ganglions ?', 'Plus de 4 semaines : suspect.', 'Biopsie'],
    ['Avez-vous de la fièvre, des sueurs la nuit, perdu du poids ?', 'Symptômes B.', 'Stade B, pronostic'],
    ['Avez-vous des démangeaisons ? Mal aux ganglions en buvant de l’alcool ?', 'Évocateurs du Hodgkin.', 'Orientation'],
    ['Avez-vous le visage gonflé, une toux, des veines dilatées ?', 'Compression de la veine cave supérieure.', 'Urgences'],
    ['Avez-vous mal au dos, une faiblesse des jambes ?', 'Compression médullaire.', 'IRM urgente'],
    ['Souhaitez-vous avoir des enfants ?', 'Toxicité gonadique.', 'Préservation de la fertilité'],
   ])) +
 U('<b>Drapeaux rouges</b> : syndrome cave supérieur, stridor, compression médullaire, oligurie avec hyperkaliémie (lyse tumorale), confusion (hypercalcémie), fièvre sous chimiothérapie (neutropénie fébrile : urgences dans l’heure).', 72, 81)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin palpe toutes les aires ganglionnaires, l’anneau de Waldeyer, le foie et la rate. '
   'Il mesure les ganglions, recherche une compression veineuse et évalue l’état général par le score ECOG. '
   'Un ganglion lymphomateux est typiquement ferme, élastique, indolore et mobile ; l’examen seul ne suffit jamais au diagnostic.', 72, 64) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal', 'Anomalie et signification'], [
    ['Palpation de toutes les aires', 'Ganglions < 1 cm', 'Ganglions fermes, « caoutchouteux », indolores'],
    ['Palpation de la rate', 'Non palpable', 'Splénomégalie : atteinte splénique'],
    ['Examen de l’oropharynx', 'Amygdales symétriques', 'Asymétrie : atteinte de l’anneau de Waldeyer'],
    ['Inspection du cou et du thorax', 'Veines normales', 'Circulation collatérale : compression cave'],
    ['Score ECOG', '0 : activité normale', '≥ 2 : facteur pronostique défavorable (IPI)'],
   ]) + P('Le score ECOG fait partie de l’index pronostique international (IPI) des lymphomes agressifs.', 81))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont les symptômes B, le prurit, la fatigue et les signes de compression. '
   'Les signes physiques sont les adénopathies, la splénomégalie et les atteintes extraganglionnaires. '
   'Ils forment un syndrome tumoral ganglionnaire, un syndrome général et parfois un syndrome compressif.', 72) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    [SB, 'Fièvre, sueurs, perte de poids', 'Cytokines (interleukine 6, TNF)'],
    ['Prurit', 'Démangeaisons diffuses', 'Cytokines (Hodgkin)'],
    ['Douleur à l’alcool', 'Douleur ganglionnaire après la prise d’alcool', 'Mécanisme inconnu ; rare mais évocatrice du Hodgkin'],
    ['Syndrome cave supérieur', 'Œdème du visage, circulation collatérale', 'Masse médiastinale'],
    ['Bulky (masse volumineuse)', 'Masse ≥ 10 cm ou > 1/3 du diamètre thoracique', 'Charge tumorale élevée'],
   ]) + P('Termes : ' + DV + '.', 72))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le diagnostic repose sur la classification OMS 2022 (WHO-HAEM5), qui combine morphologie, immunohistochimie et génétique sur une biopsie. '
   'La stadification suit le critère de Lugano 2014 : stade I = un territoire, II = plusieurs d’un même côté du diaphragme, III = des deux côtés, IV = atteinte extraganglionnaire diffuse ; une masse ≥ 10 cm est dite volumineuse. '
   'Une cytoponction ne suffit pas à classer un lymphome.', 73, 72) +
 F('Éléments qui confirment ou réfutent',
   TAB(['Confirme', 'Réfute ou fait revoir'], [
    ['Biopsie : clone lymphoïde avec perte de l’architecture', 'Hyperplasie folliculaire réactionnelle'],
    ['Immunohistochimie : CD20+ (B) ou CD30+ et CD15+ (Hodgkin)', 'Cytokératine+ : carcinome'],
    ['Clonalité (PCR, cytométrie)', 'Population polyclonale'],
    ['Réponse métabolique complète : Deauville 1–3', 'Deauville 4–5 : maladie résiduelle'],
   ]) + P('L’IPI compte 5 facteurs : âge > 60 ans, LDH élevée, ECOG ≥ 2, stade III–IV, plus d’un site extraganglionnaire.', 81))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Biopsie-exérèse ganglionnaire avec immunohistochimie', 'Diagnostic et type', 'Gold standard (OMS 2022)', 'Geste chirurgical'],
    ['TEP-TDM au FDG', 'Stade et réponse', 'Sensibilité et spécificité supérieures au scanner pour les lymphomes avides de FDG', 'Faux positifs inflammatoires'],
    ['Biopsie au trocart guidée', 'Alternative si l’exérèse est difficile', 'Sensibilité inférieure à l’exérèse', 'Parfois non contributive'],
    ['Cytoponction', 'Orientation', 'Insuffisante pour classer', 'À ne pas utiliser seule'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Hémogramme, LDH, créatinine, calcium, acide urique', 'Suspicion'],
    ['Première', 'Échographie ganglionnaire', 'Choix du ganglion'],
    ['Première', 'Biopsie-exérèse', 'Adénopathie suspecte'],
    ['Après diagnostic', 'TEP-TDM, sérologies VIH, hépatites B et C', 'Stadification, avant rituximab'],
    ['Seconde', 'Biopsie ostéomédullaire', 'TEP non conclusive ou cytopénies'],
    ['Avant anthracyclines', 'Échocardiographie', 'Fonction ventriculaire'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La <b>biopsie</b> se fait avant tout corticoïde ; le ganglion le plus gros ou le plus fixant est choisi.', 'Le tissu est envoyé frais au laboratoire d’hématopathologie (cytométrie, génétique).', 'La <b>TEP-TDM</b> demande un jeûne de 6 heures et une glycémie contrôlée.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['LDH', 'Normal < 250 U/L (selon le laboratoire)', 'Élevée : charge tumorale, facteur de l’IPI', 'Pronostic'],
    ['Deauville', '1–3', 'Réponse métabolique complète', 'Fin du traitement prévu'],
    ['Résultat positif : biopsie avec clone B CD20+', '—', 'Lymphome B', 'Stadification'],
    ['Résultat négatif : hyperplasie réactionnelle', '—', 'Pas de lymphome sur ce ganglion', 'Surveillance, nouvelle biopsie si croissance'],
    ['Résultat limite : biopsie au trocart insuffisante', '—', 'Diagnostic incertain', 'Biopsie-exérèse'],
    ['Résultat discordant : TEP fixante, biopsie négative', '—', 'Inflammation ou erreur d’échantillonnage', 'Nouvelle biopsie'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'TEP déconseillée ; IRM sans gadolinium, échographie ; avis d’un centre spécialisé'],
    ['Enfant', 'Centre d’onco-hématologie pédiatrique'],
    ['DFGe < 30 mL/min/1,73 m²', 'TEP possible ; adapter la chimiothérapie et le contraste'],
    ['Allergie à l’iode', 'TEP avec scanner sans injection'],
    ['Stimulateur cardiaque', 'TEP-TDM possible ; IRM selon la compatibilité'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('La biopsie-exérèse avec immunohistochimie est l’examen diagnostique indispensable. '
   'La TEP-TDM stadifie et évalue la réponse selon Lugano 2014. '
   'Le bilan biologique (hémogramme, LDH, fonction rénale, sérologies VIH et hépatites) prépare le traitement.', 72, 73) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une compression ou une lyse tumorale est présente, alors le patient est hospitalisé en urgence. '
   'Si une adénopathie est suspecte, alors le médecin organise une biopsie-exérèse avant tout corticoïde. '
   'Si le lymphome est confirmé, alors une TEP-TDM et une réunion de concertation pluridisciplinaire définissent le traitement.', 72, 81) +
 F('Embranchements',
   TAB(['Si…', 'Alors…', 'Contrôle'], [
    ['Syndrome cave, compression médullaire', 'Urgences, corticoïdes après la biopsie si possible', 'Hospitalisation'],
    ['Adénopathie suspecte', 'Biopsie-exérèse', 'Résultat en 1–2 semaines'],
    ['Hodgkin stade limité', 'ABVD puis radiothérapie selon la TEP', 'TEP intermédiaire'],
    ['Hodgkin avancé', 'BrECADD (ou BEACOPP escaladé) selon l’âge', 'TEP après 2 cycles'],
    ['DLBCL', 'R-CHOP ou Pola-R-CHP, 6 cycles', 'TEP de fin de traitement'],
    ['Lymphome indolent asymptomatique', 'Surveillance active', 'Contrôle tous les 3–6 mois'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Rituximab, MABTHERA® (anticorps monoclonal anti-CD20, lyse des lymphocytes B)', '375 mg/m² intraveineux au jour 1 de chaque cycle, 6 cycles ; demi-vie de plusieurs semaines', 'Réaction à la perfusion, réactivation de l’hépatite B (dépistage obligatoire), infections'],
   ['Cyclophosphamide (alkylant)', '750 mg/m² intraveineux au jour 1 (R-CHOP)', 'Cytopénie, cystite hémorragique, infertilité'],
   ['Doxorubicine (anthracycline, intercalant de l’ADN)', '50 mg/m² intraveineux au jour 1 (R-CHOP) ; élimination hépatique', 'Cardiotoxicité cumulative (dose totale limitée), alopécie ; contre-indiquée si fraction d’éjection basse'],
   ['Vincristine (poison du fuseau)', '1,4 mg/m² au jour 1, maximum 2 mg', 'Neuropathie, constipation ; interaction avec les azolés'],
   ['Prednisone (glucocorticoïde)', '100 mg par jour aux jours 1–5', 'Hyperglycémie, insomnie'],
   ['Allopurinol (inhibiteur de la xanthine oxydase)', '300 mg par jour, débuté avant la chimiothérapie', 'Éruption, syndrome DRESS ; interaction avec l’azathioprine'],
  ]) + P('Ces doses sont celles du protocole R-CHOP publié (ESMO 2015, Onkopedia) ; le schéma est prescrit par l’oncologue-hématologue après vérification de l’AIPS.', 81, 14, 82))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est de guérir le lymphome agressif ou le Hodgkin, et de contrôler un lymphome indolent, en limitant les toxicités tardives. '
   'Le traitement est décidé en réunion de concertation pluridisciplinaire selon le type, le stade et l’âge. '
   'Il associe chimiothérapie, immunothérapie et parfois radiothérapie.', 80, 81, 13, 14) +
 F('11.A Buts : urgence ou non',
   P('La forme compliquée (compression, lyse tumorale, neutropénie fébrile) est une urgence à traiter dans l’heure. La forme non compliquée n’est pas une urgence vitale, mais le traitement d’un lymphome agressif débute dans les 1–2 semaines ; le but chiffré est une réponse Deauville 1–3.', 72, 81), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Annoncer le diagnostic et proposer un soutien.', 'Faire le bilan d’extension et les sérologies (VIH, hépatites B et C).', 'Proposer une préservation de la fertilité.', 'Prévenir la lyse tumorale (hydratation, allopurinol).', 'Commencer le protocole décidé en RCP.', 'Vacciner contre la grippe et le pneumocoque selon le plan suisse.']), 80, 81, 91) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal prend en charge le traitement selon les indications reconnues.', 'Un arrêt de travail est souvent nécessaire pendant la chimiothérapie ; la LAI peut intervenir en cas d’incapacité prolongée.', 'La LAA n’est pas concernée ; la conduite automobile est déconseillée les jours de perfusion et en cas de fatigue ou de neuropathie.']), 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Centre spécialisé ; certaines chimiothérapies sont possibles après le 1er trimestre.'],
      ['Personne âgée', 'R-mini-CHOP au-delà de 80 ans ; évaluation gériatrique.'],
      ['Enfant', 'Protocoles pédiatriques.'],
      ['Insuffisance hépatique', 'Réduction de la doxorubicine et de la vincristine.'],
      ['Insuffisance rénale (DFGe)', 'Adapter le cyclophosphamide ; prévenir la lyse.'],
      ['VIH', 'Traitement antirétroviral poursuivi, interactions vérifiées.'],
     ]), 81, 14), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Hémogramme', 'Avant chaque cycle et à J10–14', 'Neutrophiles < 0,5 G/L avec fièvre : urgences'],
    ['TEP-TDM', 'Intermédiaire et fin de traitement', 'Deauville 4–5 : avis spécialisé'],
    ['Fonction cardiaque', 'Selon la dose cumulée d’anthracyclines', 'Baisse de la fraction d’éjection'],
    ['Suivi au long cours', 'Tous les 3–6 mois pendant 2 ans', 'Récidive, effets tardifs'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Absence de fièvre et de lyse tumorale.', 'Hémogramme acceptable.', 'Consignes écrites sur la fièvre sous chimiothérapie.', 'Prochain cycle programmé.']), 72, 81) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Plus de 80 % des lymphomes de Hodgkin et environ 60–70 % des DLBCL guérissent. La recherche 2026 évalue les cellules CAR-T et les anticorps bispécifiques dès la première rechute ou en première ligne.', 80, 81), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('Aucune prévention primaire spécifique n’existe, en dehors de la prévention du VIH et de l’éradication d’Helicobacter pylori. '
   'La prévention secondaire consiste à biopsier sans retard une adénopathie persistante. '
   'La prévention tertiaire comprend le dépistage des effets tardifs : cancers secondaires, atteinte cardiaque, hypothyroïdie après radiothérapie.', 80, 81) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Prévention du VIH (OFSP), traitement d’Helicobacter pylori'],
    ['Secondaire', 'Biopsie d’une adénopathie persistante > 4 semaines'],
    ['Tertiaire', 'Dépistage du cancer du sein après irradiation thoracique, suivi cardiaque, vaccinations du plan suisse'],
   ]), 80, 91)))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin biopsie une adénopathie ferme, indolore et persistante plus de 4 semaines. '
   'Il demande une biopsie-exérèse, et non une simple cytoponction. '
   'Il ne donne pas de corticoïde avant la biopsie, sauf urgence vitale. '
   'Il fait stadifier par TEP-TDM selon Lugano 2014 et dépister l’hépatite B avant le rituximab. '
   'Il connaît les urgences : compression, lyse tumorale, neutropénie fébrile.', 72, 81)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Une cytoponction suffit au diagnostic.', 'Faux : biopsie-exérèse.'],
  ['Donner des corticoïdes avant la biopsie.', 'Erreur : diagnostic masqué.'],
  ['Les symptômes B sont nécessaires au diagnostic.', 'Faux : ils servent au stade et au pronostic.'],
  ['Oublier l’hépatite B avant le rituximab.', 'Erreur : risque de réactivation fulminante.'],
  ['Biopsie ostéomédullaire systématique dans le Hodgkin.', 'Faux : la TEP la remplace le plus souvent.'],
 ]) + P('Ces pièges reprennent Lugano 2014 et les recommandations ESMO.', 72, 80, 81)))
CTX = {'_prefixe': 'Devant un lymphome',
 'biopsie': 'La biopsie-exérèse permet la classification OMS 2022 par morphologie, immunohistochimie et génétique.',
 'tep': 'La TEP-TDM au FDG stadifie selon Lugano 2014 et évalue la réponse par le score de Deauville.',
 'ldh': 'Une LDH élevée reflète la charge tumorale et fait partie de l’IPI.',
 'nfs': 'Des cytopénies évoquent une infiltration médullaire ; une lymphocytose clonale une leucémie lymphoïde chronique.',
 'cyto': 'La cytométrie en flux démontre la clonalité d’une population lymphocytaire.',
 'bom': 'La biopsie ostéomédullaire est réservée aux cas où la TEP ne conclut pas.',
 'echogg': 'Un ganglion rond, hypoéchogène, sans hile, à vascularisation périphérique est suspect de lymphome.',
 'tdm': 'Le scanner injecté complète la TEP pour mesurer les masses.',
 'vih': 'Un test VIH est systématique avant le traitement d’un lymphome.',
 'sero': 'La sérologie de l’hépatite B est obligatoire avant le rituximab.',
 'hep': 'Les tests hépatiques guident les doses de doxorubicine et de vincristine.',
 'creat': 'La créatinine et l’acide urique dépistent une lyse tumorale.',
 'echocoeur': 'L’échocardiographie mesure la fraction d’éjection avant les anthracyclines.',
 'radio': 'La radiographie du thorax recherche une masse médiastinale.',
 'iono': 'Le potassium et le phosphate dépistent une lyse tumorale.',
 'hcg': 'Un test de grossesse est fait avant toute chimiothérapie.',
 'frottis': 'Le frottis sanguin recherche des cellules lymphomateuses circulantes.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
