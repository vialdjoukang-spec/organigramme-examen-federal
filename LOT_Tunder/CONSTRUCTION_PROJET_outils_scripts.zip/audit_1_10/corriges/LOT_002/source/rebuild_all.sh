#!/usr/bin/env bash
# Reconstruit tous les fichiers AUDITÉS du LOT 2, puis note et vérifie (lancer depuis n'importe où).
set -e
cd /workspace/audit_1_10/corriges/LOT_002/source
for g in ssp dx1 dx2 dx3 dx4 dx5 dx6 dx7 dx8 dx9 dx10; do ../../../venv/bin/python gen_$g.py; done
cd /workspace/audit_1_10
for t in decoupe examens style score; do ./venv/bin/python outils/$t.py LOT_002_AUDITE >/dev/null; done
./venv/bin/python outils/verif_v7.py corriges/LOT_002/*_AUDITÉ*.html
