# -*- coding: utf-8 -*-
# Sources extraites des originaux LOT 2 (outils_local/sources_orig_lot2.py).
SOURCES_ORIG = {
 4: '<a href="https://www.bag.admin.ch/dam/fr/sd-web/UDsk16pv0TsC/D%C3%A9pistage-du-VIH-directive_2025-v4-avec-annexe-fr.pdf">OFSP — Dépistage du VIH, directive 2025, version 4</a>. Version : 10 juillet 2026. Document consulté le 23 octobre 2026.',
 5: '<a href="https://www.bag.admin.ch/fr/depistages-et-conseils-du-vih-et-des-autre-ist">OFSP — Dépistages et conseils du VIH et des autres IST</a>. Version : Page d’accès à la directive actuelle. Document consulté le 23 octobre 2026.',
 7: '<a href="https://www.nhs.uk/conditions/glandular-fever/">NHS — Glandular fever</a>. Version : Révision du 20 décembre 2023. Document consulté le 23 octobre 2026.',
 8: '<a href="https://www.ouh.nhs.uk/microbiology/a-z/ebv/">Oxford University Hospitals — EBV, microbiologie</a>. Version : Révision du 2 décembre 2025. Document consulté le 23 octobre 2026.',
 9: '<a href="https://www.bag.admin.ch/dam/fr/sd-web/fPW7HAdyOiZ0/tuberkulose-handbuch.pdf">Ligue pulmonaire suisse et OFSP — Tuberculose en Suisse</a>. Version : V1.2024. Document consulté le 23 octobre 2026.',
 10: '<a href="https://www.swissmedicinfo-pro.ch/showText.aspx?authNr=47503&amp;lang=FR&amp;supportMultipleResults=1&amp;textType=FI">Swissmedic/AIPS — DAFALGAN®, information professionnelle</a>. Version : Septembre 2025. Document consulté le 23 octobre 2026.',
 12: '<a href="https://www.has-sante.fr/jcms/p_3545694/fr/initiation-d-un-premier-traitement-antiretroviral-chez-l-adulte-vivant-avec-le-vih">HAS — Initiation d’un premier traitement antirétroviral chez l’adulte</a>. Version : Recommandation en ligne consultée en octobre 2026. Document consulté le 23 octobre 2026.',
 24: '<a href="https://www.eacsociety.org/guidelines/eacs-guidelines/">EACS — page officielle des recommandations</a>. Version : Version 13.0 annoncée en 2025. Document consulté le 23 octobre 2026.',
 25: '<a href="https://www.nhs.uk/conditions/hiv-and-aids/">NHS — HIV and AIDS</a>. Version : Révision du 9 juillet 2025. Document consulté le 23 octobre 2026.',
}
