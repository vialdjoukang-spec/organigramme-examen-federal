# -*- coding: utf-8 -*-
# Sources extraites des originaux LOT 2 (outils_local/sources_orig_lot2.py).
SOURCES_ORIG = {
 3: '<a href="https://www.chuv.ch/fr/hematologie/hem-home/personnel-de-la-sante/maladies-et-traitements/lymphomes">CHUV — Lymphomes, information professionnelle</a>. Version : Page institutionnelle ; date non établie. Document consulté le 23 octobre 2026.',
 13: '<a href="https://www.onkopedia.com/de/onkopedia/guidelines/hodgkin-lymphom">Onkopedia — Hodgkin Lymphom</a>. Version : Date affichée : décembre 2023. Document consulté le 23 octobre 2026.',
 14: '<a href="https://www.onkopedia.com/de/onkopedia/guidelines/diffuses-grosszelliges-b-zell-lymphom">Onkopedia — Diffuses großzelliges B-Zell-Lymphom</a>. Version : Décembre 2025. Document consulté le 23 octobre 2026.',
 15: '<a href="https://www.onkopedia.com/de/onkopedia/guidelines/cup-syndrom-krebserkrankungen-mit-unbekanntem-primaertumor">Onkopedia — CUP, cancers de primitif inconnu</a>. Version : Septembre 2025. Document consulté le 23 octobre 2026.',
 16: '<a href="https://www.onkopedia.com/de/onkopedia/guidelines/kopf-hals-plattenepithelkarzinome">Onkopedia — Kopf-Hals-Plattenepithelkarzinome</a>. Version : Juin 2026. Document consulté le 23 octobre 2026.',
}
