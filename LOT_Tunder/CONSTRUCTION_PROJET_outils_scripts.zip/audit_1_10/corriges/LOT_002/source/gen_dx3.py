# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.3 · Mononucléose infectieuse (EBV) (LOT 2, Partie 2)."""
from lot2_commun import *
POINT = mkPOINT('dx3')
M = META('dx3', 'DX.3', 'Mononucléose infectieuse', 'Mononucléose infectieuse (EBV)', 'LOT_002_DX3_Mononucleose_infectieuse_EBV_AUDITÉ.html', 2,
         'Les rapports de vraisemblance proviennent de la revue JAMA 2016 (Ebell) ; ils restent à vérifier par un médecin.')
LC = T('lymphocytes activés', 'Les lymphocytes activés (ou « atypiques ») sont des lymphocytes T CD8 grands et basophiles, qui attaquent les lymphocytes B infectés ; ils dépassent souvent 10 % des leucocytes dans la mononucléose.')
HET = T('anticorps hétérophiles', 'Les anticorps hétérophiles sont des IgM produits par les lymphocytes B stimulés par l’EBV ; ils agglutinent des globules rouges d’animaux, ce que détecte le Monotest.')
RV = T('rapport de vraisemblance', 'Le rapport de vraisemblance positif (RV+) indique combien un signe présent multiplie la cote de la maladie ; un RV+ > 10 change fortement la probabilité.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('La mononucléose infectieuse est la forme symptomatique de la primo-infection par le virus d’Epstein-Barr (EBV). Ce herpèsvirus infecte les lymphocytes B. '
   'Elle associe classiquement fièvre, angine et adénopathies cervicales, avec une lymphocytose faite de lymphocytes activés. '
   'Le terme « syndrome mononucléosique » désigne ce tableau biologique, quelle que soit sa cause (EBV, CMV, VIH, toxoplasmose).', 68, 92) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Primo-infection EBV', 'Premier contact avec le virus, souvent asymptomatique chez l’enfant', 'Réactivation chez l’immunodéprimé'],
    ['Mononucléose infectieuse', 'Primo-infection symptomatique, surtout entre 15 et 24 ans', 'Angine streptococcique isolée'],
    ['Syndrome mononucléosique', 'Lymphocytose avec lymphocytes activés', 'Leucémie (cellules blastiques)'],
    ['Latence', 'Persistance à vie du virus dans les lymphocytes B mémoire', 'Infection chronique active à EBV, rare'],
   ]) + P(f'Les {LC} sont la signature biologique de la réponse immunitaire, et non des cellules malignes.', 68, 90))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('Aucune incidence suisse de la mononucléose n’est publiée, car elle n’est pas à déclaration obligatoire. '
   'Plus de 90 % des adultes ont été infectés par l’EBV ; l’infection survient tôt et sans symptôme dans l’enfance, ou plus tard sous forme de mononucléose. '
   'Dans une cohorte d’étudiants américains, 77 % des primo-infections ont été symptomatiques ; les séroprévalences européennes de l’adulte sont du même ordre (> 90 %).', 68, 89) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Séroprévalence de l’adulte', '> 90 %', 'Monde, revue Dunmire 2018'],
    ['Primo-infections symptomatiques chez l’étudiant', '77 %', 'Cohorte américaine (Balfour 2013)'],
    ['Part de l’EBV parmi les mononucléoses', '≈ 90 %', 'Revue AFP 2015'],
    ['Incubation', '30–50 jours', 'Dunmire 2018'],
    ['Rupture splénique', '0,1–0,5 %', 'Becker 2014'],
    ['Incidence en Suisse', 'Non publiée', 'Maladie non déclarée'],
   ]) + P('La transmission se fait par la salive, d’où le nom de « maladie du baiser ». Le pronostic est excellent ; la fatigue peut durer plusieurs semaines, et l’EBV est associé à un risque accru de lymphome de Hodgkin et de sclérose en plaques.', 68, 85))))
PTS.append(POINT(3, 'Physiopathologie',
 P('L’EBV se réplique d’abord dans l’épithélium de l’oropharynx, puis il infecte les lymphocytes B des amygdales par le récepteur CD21. '
   'Les lymphocytes B infectés prolifèrent et diffusent dans tous les organes lymphoïdes ; les lymphocytes T CD8 répondent massivement pour les détruire. '
   'Cette réponse T, bien plus que le virus, explique la fièvre, les adénopathies, la splénomégalie et la fatigue.', 68) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'L’anneau de Waldeyer (amygdales) est la porte d’entrée ; la rate et les ganglions cervicaux postérieurs sont les organes lymphoïdes atteints.'],
    ['Physiologie', 'Les lymphocytes T CD8 contrôlent normalement les cellules infectées par un virus.'],
    ['Physiopathologie', 'Les lymphocytes B infectés se multiplient ; la riposte T CD8 produit des lymphocytes activés et des cytokines.'],
    ['Clinique', 'D’où une angine, des adénopathies cervicales postérieures, une splénomégalie fragile et une fièvre prolongée.'],
    ['Examens', f'L’hémogramme montre les {LC} ; le Monotest détecte les {HET} ; la sérologie spécifique date l’infection.'],
    ['Traitement', 'Aucun antiviral n’est efficace ; on soulage, on protège la rate et on traite les complications.'],
   ]), 68, 90) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Réplication oropharyngée', 'Examen de la gorge', 'Antalgie'],
    ['Prolifération B et anticorps hétérophiles', 'Monotest', 'Aucune'],
    ['Riposte T CD8', 'Hémogramme (lymphocytes activés)', 'Repos, antalgie'],
    ['Infiltration splénique', 'Palpation, échographie', 'Arrêt du sport de contact'],
    ['Hypertrophie amygdalienne obstructive', 'Examen ORL', 'Corticoïdes, hospitalisation'],
    ['Hépatite cytolytique', 'Transaminases', 'Éviter l’alcool et les hépatotoxiques'],
   ]) + P('La capsule splénique distendue et infiltrée devient fragile, ce qui explique le risque de rupture au cours des premières semaines.', 85))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin recherche d’abord les urgences vitales : obstruction des voies aériennes et rupture de rate. '
   'Il distingue ensuite la mononucléose d’une angine streptococcique et d’un autre syndrome mononucléosique, notamment la primo-infection VIH. '
   'Un test VIH est proposé à tout patient avec un syndrome mononucléosique et un Monotest négatif.', 68, 93, 4) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Mononucléose à EBV' + PR('≈ 90 % des mononucléoses', 92), '15–24 ans, angine, adénopathies postérieures, fatigue', 'Monotest, VCA-IgM'],
    ['Cytomégalovirus' + PR('≈ 10 % des mononucléoses, toutes autres causes réunies', 92), 'Adulte, fièvre prolongée, peu d’angine', 'Sérologie CMV'],
    ['Primo-infection VIH' + PR('≈ 1 % des patients testés pour une mononucléose', 93), 'Exposition, éruption, ulcérations buccales', 'Test VIH de 4e génération, charge virale'],
    ['Toxoplasmose' + PR('incluse dans les ≈ 10 % non EBV', 92), 'Contact avec un chat, adénopathies peu douloureuses', 'Sérologie toxoplasmose'],
    ['Angine streptococcique' + PR('non comparable : autre population (maux de gorge)', 67), 'Exsudat, fièvre, pas de toux', 'Test rapide streptococcique'],
    DDXROW('hl', 'Adénopathies persistantes > 4 semaines', 'Biopsie-exérèse'),
    DDXROW('nhl', 'Cytopénies, blastes, signes B', 'Frottis, cytométrie'),
   ]) + P('Les quatre premières lignes sont des proportions parmi les syndromes mononucléosiques, donc comparables entre elles. Les lymphomes sont exprimés en incidence suisse pour 100 000 habitants par an.', 92, 60))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise l’âge, la durée de la fièvre, la fatigue, les contacts et la prise récente d’amoxicilline. '
   'Il recherche les expositions au VIH et les signes de complication.', 68, 84) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis quand avez-vous de la fièvre et mal à la gorge ?', 'Le Monotest est souvent négatif la première semaine.', 'Répéter le test ou demander VCA-IgM'],
    ['Avez-vous pris de l’amoxicilline ?', 'Éruption fréquente sous amoxicilline.', 'Ne pas étiqueter une allergie'],
    ['Avez-vous eu un rapport à risque ?', 'Primo-infection VIH.', 'Test VIH'],
    ['Avez-vous mal au ventre à gauche ou à l’épaule gauche ?', 'Rupture de rate.', 'Urgences'],
    ['Avez-vous de la peine à avaler la salive ou à respirer ?', 'Obstruction amygdalienne.', 'Urgences, corticoïdes'],
    ['Pratiquez-vous un sport de contact ?', 'Risque splénique.', 'Arrêt du sport'],
   ])) +
 U('<b>Drapeaux rouges</b> : douleur abdominale gauche brutale ou à l’épaule gauche avec malaise (rupture de rate, appel du 144). Stridor ou incapacité d’avaler la salive. Ictère, pâleur avec dyspnée (hémolyse), purpura (thrombopénie), signes neurologiques.', 85, 68)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin examine la gorge, palpe les ganglions cervicaux antérieurs et postérieurs, puis la rate et le foie. '
   'Il recherche des pétéchies du palais, un œdème des paupières et une éruption. '
   f'Selon la revue JAMA 2016, aucun signe isolé n’est suffisant ; le {RV} le plus élevé est celui des pétéchies du palais, autour de 5.', 67) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal', 'Anomalie et valeur diagnostique'], [
    ['Palpation cervicale postérieure', 'Pas de ganglion > 1 cm', 'Adénopathie postérieure : RV+ ≈ 3,1'],
    ['Palpation axillaire et inguinale', 'Pas d’adénopathie', 'Adénopathie : RV+ ≈ 3'],
    ['Inspection du palais', 'Muqueuse rose', 'Pétéchies du palais : RV+ ≈ 5,3'],
    ['Palpation de la rate (décubitus latéral droit)', 'Rate non palpable', 'Splénomégalie : RV+ ≈ 1,9–6,6'],
    ['Examen des amygdales', 'Amygdales sans exsudat', 'Exsudat grisâtre, hypertrophie'],
    ['Peau et conjonctives', 'Normales', 'Éruption sous amoxicilline, ictère'],
   ]) + P('Ces rapports de vraisemblance viennent d’une revue systématique ; l’absence d’adénopathie cervicale rend la mononucléose moins probable (RV− ≈ 0,4–0,6).', 67))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fièvre, le mal de gorge, la fatigue intense et parfois la douleur abdominale. '
   'Les signes physiques sont l’angine, les adénopathies, la splénomégalie et l’hépatomégalie. '
   'Ils forment le syndrome mononucléosique clinique, avec un syndrome biologique associé.', 68) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    ['Angine', 'Amygdales rouges, souvent avec exsudat', 'Réplication virale et infiltrat lymphoïde'],
    ['Adénopathies cervicales postérieures', 'Ganglions symétriques, sensibles', 'Prolifération B et T'],
    ['Splénomégalie', 'Rate palpable sous le rebord costal', 'Infiltration lymphocytaire'],
    ['Pétéchies du palais', 'Petites taches rouges à la jonction palais dur-mou', 'Fragilité capillaire'],
    ['Éruption sous amoxicilline', 'Éruption maculopapuleuse', 'Réaction immunologique transitoire, non allergique'],
    ['Fatigue post-infectieuse', 'Peut durer des semaines', 'Cytokines'],
   ]) + P('Termes : ' + HET + '.', 68, 90))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Aucune société savante ne publie de critères formels ; le diagnostic repose sur un tableau clinique compatible, confirmé par des anticorps hétérophiles ou par la sérologie spécifique de l’EBV. '
   'Des lymphocytes ≥ 50 % avec ≥ 10 % de lymphocytes activés donnent un RV+ ≈ 54 selon la revue JAMA 2016. '
   'Une sérologie VCA-IgM positive avec EBNA négatif signe la primo-infection, alors qu’un tableau clinique seul ne suffit pas.', 67, 68) +
 F('Éléments qui soutiennent ou réfutent l’hypothèse',
   TAB(['Soutient', 'Réfute ou fait revoir'], [
    ['Lymphocytes activés ≥ 10 % (RV+ ≈ 11)', 'Polynucléose neutrophile'],
    ['Lymphocytes activés ≥ 40 % (RV+ ≈ 50)', 'Blastes au frottis'],
    ['Monotest positif', 'Monotest négatif après 2 semaines et VCA-IgM négative'],
    ['VCA-IgM positive, EBNA négatif', 'EBNA positif : infection ancienne'],
   ]) + P('Ces seuils sont tirés de la revue JAMA 2016 ; ils s’appliquent à l’adolescent et à l’adulte jeune.', 67))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Sérologie EBV (VCA-IgM, VCA-IgG, EBNA-IgG)', 'Primo-infection, infection ancienne', 'Référence sérologique (sensibilité et spécificité > 95 % selon les trousses)', 'Coût, délai'],
    ['Monotest (anticorps hétérophiles)', 'Diagnostic rapide', 'Sensibilité ≈ 87 %, spécificité ≈ 91 %', 'Faux négatifs la 1re semaine et avant 4 ans'],
    ['Hémogramme avec frottis', 'Lymphocytes activés', 'RV+ ≈ 11 à ≥ 10 %', 'Non spécifique de l’EBV'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Hémogramme, Monotest', 'Adolescent ou adulte jeune avec angine et adénopathies'],
    ['Première', 'Transaminases', 'Tableau typique'],
    ['Seconde', 'Sérologie EBV', 'Monotest négatif ou enfant < 4 ans'],
    ['Seconde', 'Sérologies CMV, toxoplasmose, test VIH de 4e génération', 'EBV négatif'],
    ['Seconde', 'Échographie abdominale', 'Douleur abdominale, doute sur la rate'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Le <b>Monotest</b> se fait de préférence après le 7e jour de symptômes ; s’il est négatif plus tôt, il se répète.', 'La <b>sérologie EBV</b> ne demande aucune préparation ; elle est utile si le Monotest est négatif.', 'Le <b>test VIH</b> se demande avec l’accord du patient, selon la directive de l’OFSP.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['VCA-IgM +, VCA-IgG +, EBNA −', '—', 'Primo-infection récente', 'Mononucléose confirmée'],
    ['VCA-IgG +, EBNA +, VCA-IgM −', '—', 'Infection ancienne', 'Chercher une autre cause'],
    ['Lymphocytes activés', '≥ 10 % des leucocytes', 'Syndrome mononucléosique', 'Monotest, sérologies'],
    ['ALAT', 'Normal < 45 U/L (homme)', 'Élévation modérée fréquente', 'Contrôle, éviter l’alcool'],
    ['Résultat positif : Monotest positif avec tableau typique', '—', 'Mononucléose probable', 'Pas d’autre test'],
    ['Résultat négatif : Monotest négatif', '—', 'Phase précoce ou autre cause', 'Sérologie EBV, test VIH'],
    ['Résultat limite ou discordant : Monotest positif sans tableau', '—', 'Faux positif possible (lymphome, lupus)', 'Sérologie spécifique'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Sérologies EBV, CMV et toxoplasmose ; une primo-infection CMV ou toxoplasmique a des conséquences fœtales'],
    ['Enfant < 4 ans', 'Monotest peu sensible : sérologie EBV d’emblée'],
    ['DFGe < 30 mL/min/1,73 m²', 'Aucune adaptation des tests ; adapter les médicaments'],
    ['Allergie à l’iode', 'Échographie plutôt que scanner pour la rate'],
    ['Stimulateur cardiaque', 'Échographie ; IRM si le dispositif est compatible'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('L’hémogramme et le Monotest suffisent dans un tableau typique de l’adolescent. '
   'La sérologie EBV précise le diagnostic quand le Monotest est négatif, et le test VIH s’impose si l’EBV n’est pas en cause. '
   'Les transaminases et l’échographie évaluent les complications.', 90, 68, 4) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une obstruction des voies aériennes ou une rupture de rate est suspectée, alors le patient est adressé aux urgences. '
   'Si le Monotest est positif avec un tableau typique, alors le diagnostic est retenu et le traitement est symptomatique. '
   'Si le Monotest est négatif, alors le médecin demande la sérologie EBV et un test VIH.', 85, 68, 4) +
 F('Embranchements',
   TAB(['Si…', 'Alors…', 'Contrôle'], [
    ['Stridor, salive non avalée', 'Urgences, corticoïdes', 'Hospitalisation'],
    ['Douleur abdominale gauche, malaise', 'Urgences, échographie', 'Chirurgie si rupture'],
    ['Monotest positif', 'Traitement symptomatique, arrêt du sport', 'Contrôle à 2–3 semaines'],
    ['Monotest négatif < 7 jours', 'Répéter ou sérologie EBV', '1 semaine'],
    ['EBV négatif', 'CMV, toxoplasmose, test VIH', 'Selon les résultats'],
    ['Adénopathies > 4–6 semaines', 'Revoir le diagnostic, biopsie', 'Avis spécialisé'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Paracétamol, DAFALGAN® (antalgique non opioïde)', '500–1000 mg toutes les 4–8 heures, maximum 4 g par jour ; maximum plus bas en cas d’hépatite (avis médical)', 'Hépatotoxicité en surdosage ; prudence si les transaminases sont élevées'],
   ['Ibuprofène (AINS)', '400 mg jusqu’à 3 fois par jour avec un repas, quelques jours', 'Gastrique, rénal ; contre-indiqué en cas de thrombopénie marquée'],
   ['Prednisone (glucocorticoïde)', 'Réservée aux complications : obstruction des voies aériennes, anémie hémolytique, thrombopénie sévère ; par exemple 40–60 mg par jour sur quelques jours, puis décroissance, selon l’avis spécialisé', 'Hyperglycémie, insomnie, infection ; pas d’usage de routine'],
   ['Aciclovir, valaciclovir (antiviraux)', 'Non recommandés', 'Aucun bénéfice clinique démontré'],
   ['Amoxicilline', 'À éviter si la mononucléose est probable', 'Éruption chez ≈ 30 % des patients traités'],
  ]) + P('Les corticoïdes ne sont pas indiqués dans la forme simple ; la dose de prednisone citée est un ordre de grandeur à valider par un spécialiste.', 10, 68, 84, 92))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est de soulager, de protéger la rate et de dépister les complications, parce que la maladie guérit spontanément. '
   'La prise en charge est ambulatoire dans la grande majorité des cas. '
   'L’hospitalisation est réservée à l’obstruction des voies aériennes, à la rupture de rate et aux complications hématologiques ou neurologiques.', 68, 92) +
 F('11.A Buts : urgence ou non',
   P('La forme non compliquée n’est pas une urgence ; le but chiffré est l’absence de sport de contact pendant au moins 3–4 semaines après le début. La rupture de rate et l’obstruction des voies aériennes sont des urgences vitales, à adresser dans l’heure.', 85), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Expliquer le diagnostic, la durée de la fatigue et la contagion par la salive.', 'Repos selon la tolérance, sans alitement strict.', 'Hydratation et antalgie.', 'Arrêt des sports de contact et des efforts intenses au moins 3–4 semaines.', 'Éviter l’alcool en cas d’hépatite.']), 68, 85) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal prend en charge les consultations et les analyses.', 'Un arrêt de travail ou une dispense scolaire de 1–2 semaines est souvent justifié ; la LAA et la LAI ne sont pas concernées.', 'La conduite automobile est possible sauf en cas de fatigue importante.']), 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Paracétamol ; éviter les AINS au 3e trimestre ; la mononucléose ne pose pas de risque fœtal majeur connu, contrairement au CMV.'],
      ['Personne âgée', 'Forme moins typique, plus d’hépatite ; rechercher une autre cause.'],
      ['Enfant', 'Formes souvent pauci-symptomatiques ; paracétamol selon le poids.'],
      ['Insuffisance hépatique', 'Paracétamol à dose réduite.'],
      ['Insuffisance rénale (DFGe)', 'Éviter les AINS.'],
      ['Immunodépression, transplantation', 'Risque de syndrome lymphoprolifératif : avis spécialisé.'],
     ]), 68), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Douleur abdominale, malaise', 'Information du patient', 'Urgences immédiates'],
    ['Hémogramme, transaminases', 'À 2–3 semaines si anormaux', 'Aggravation : avis spécialisé'],
    ['Taille de la rate', 'Avant la reprise du sport', 'Splénomégalie persistante : prolonger l’arrêt'],
    ['Adénopathies', 'À 4–6 semaines', 'Persistance : biopsie'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Déglutition et hydratation possibles.', 'Absence de douleur abdominale.', 'Patient informé de l’interdiction temporaire du sport de contact.', 'Contrôle prévu.']), 85, 68) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La guérison est la règle en 2–4 semaines ; la fatigue peut persister plusieurs mois. La recherche 2026 porte sur un vaccin contre l’EBV et sur le lien avec la sclérose en plaques.', 68), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('Aucun vaccin contre l’EBV n’est disponible en 2026. '
   'La prévention primaire consiste à ne pas partager verres et couverts pendant la phase aiguë. '
   'La prévention secondaire et tertiaire repose sur l’arrêt du sport de contact et sur la surveillance des complications.', 68, 85) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Éviter l’échange de salive en phase aiguë'],
    ['Secondaire', 'Test VIH devant un syndrome mononucléosique à Monotest négatif'],
    ['Tertiaire', 'Arrêt du sport de contact ≥ 3–4 semaines'],
   ]), 4, 85)))
PTS.append(POINT(13, 'Points clés',
 P('La mononucléose est la primo-infection symptomatique par l’EBV, surtout entre 15 et 24 ans. '
   'L’hémogramme et le Monotest confirment un tableau typique ; la sérologie EBV prend le relais si le Monotest est négatif. '
   'Un test VIH est proposé devant tout syndrome mononucléosique non expliqué. '
   'L’amoxicilline donne souvent une éruption qui n’est pas une allergie. '
   'Le sport de contact est arrêté au moins 3–4 semaines à cause du risque de rupture de rate.', 68, 84, 85, 93)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Un Monotest négatif au 3e jour exclut la mononucléose.', 'Faux : il est souvent négatif la 1re semaine.'],
  ['Une éruption sous amoxicilline est une allergie à la pénicilline.', 'Faux : c’est une réaction liée au virus.'],
  ['Prescrire de l’aciclovir.', 'Erreur : aucun bénéfice démontré.'],
  ['Donner des corticoïdes à tous.', 'Erreur : ils sont réservés aux complications.'],
  ['Oublier le test VIH.', 'Erreur : la primo-infection VIH mime une mononucléose.'],
  ['Autoriser le football après 1 semaine.', 'Erreur : arrêt d’au moins 3–4 semaines.'],
 ]) + P('Ces pièges reprennent les revues de 2004, 2015, 2016 et 2018.', 90, 92, 67, 68)))
CTX = {'_prefixe': 'Devant une mononucléose infectieuse',
 'monotest': 'Un Monotest positif avec un tableau typique suffit au diagnostic ; un Monotest négatif la première semaine se répète.',
 'sero': 'VCA-IgM positive avec EBNA négatif signe la primo-infection à EBV ; EBNA positif signe une infection ancienne.',
 'nfs': 'Des lymphocytes activés ≥ 10 % soutiennent fortement la mononucléose (RV+ ≈ 11).',
 'frottis': 'Le frottis distingue les lymphocytes activés de la mononucléose des blastes d’une leucémie.',
 'hep': 'Une élévation modérée des transaminases est fréquente et régresse en quelques semaines.',
 'vih': 'Le test VIH de 4e génération est indiqué devant un syndrome mononucléosique sans EBV.',
 'cv': 'La charge virale VIH diagnostique une primo-infection avant la séroconversion.',
 'echoabdo': 'L’échographie mesure la rate et recherche un hématome ou une rupture.',
 'echo': 'L’échographie de la rate guide la reprise du sport de contact.',
 'echogg': 'Les ganglions de la mononucléose sont ovales, à hile conservé.',
 'pcr': 'La PCR EBV dans le sang est utile chez l’immunodéprimé, pas chez l’adolescent immunocompétent.',
 'biopsie': 'Une biopsie n’est indiquée que si les adénopathies persistent au-delà de 4–6 semaines.',
 'hcg': 'Un test de grossesse guide le choix des sérologies et des médicaments.',
 'tdm': 'Le scanner abdominal est demandé en urgence si une rupture de rate est suspectée chez un patient stable.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
