# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.10 · Nodule ou masse thyroïdienne (LOT 2, Partie 4)."""
from lot2_commun import *
POINT = mkPOINT('dx10')
M = META('dx10', 'DX.10', 'Nodule ou masse thyroïdienne', 'Nodule ou masse thyroïdienne', 'LOT_002_DX10_Nodule_ou_masse_thyroidienne_AUDITÉ.html', 4,
         'Les risques EU-TIRADS et Bethesda sont des fourchettes publiées ; ils restent à vérifier par un médecin.')
NOD = T('nodule thyroïdien', 'Le nodule thyroïdien est une lésion de la thyroïde distincte du tissu voisin à l’échographie ; il est palpable ou découvert par hasard.')
TIR = T('EU-TIRADS', 'L’EU-TIRADS (European Thyroid Imaging Reporting and Data System) classe un nodule de 1 à 5 selon son aspect échographique, du normal au haut risque de malignité.')
BET = T('système de Bethesda', 'Le système de Bethesda classe le résultat d’une cytoponction thyroïdienne en six catégories, chacune liée à un risque de malignité et à une conduite.')
CHA = T('nodule chaud', 'Un nodule chaud capte plus le traceur que le reste de la thyroïde à la scintigraphie ; il est autonome et presque toujours bénin.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Le {NOD} est très fréquent et le plus souvent bénin. '
   'L’enjeu est de repérer le petit nombre de cancers sans multiplier les examens inutiles. '
   f'Le médecin s’appuie sur la TSH, sur l’échographie classée par l’{TIR} (European Thyroid Imaging Reporting and Data System) et sur la cytoponction lue selon le {BET}.', 48, 75, 76, 77) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Nodule thyroïdien', 'Lésion focale de la thyroïde', 'Goitre diffus'],
    ['Goitre multinodulaire', 'Thyroïde augmentée, plusieurs nodules', 'Nodule unique'],
    ['Nodule chaud (autonome)', 'Hyperfixant, TSH basse', 'Nodule froid'],
    ['Incidentalome', 'Nodule découvert par une imagerie faite pour autre chose', 'Nodule palpable'],
    ['Carcinome papillaire', 'Cancer thyroïdien le plus fréquent', 'Carcinome médullaire (calcitonine)'],
   ]) + P(f'Le terme {CHA} explique pourquoi la TSH vient en premier.', 48))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, le cancer de la thyroïde touche environ 850 personnes par an, soit environ 9 pour 100 000 habitants. '
   'Un nodule est palpable chez 4 à 7 % des adultes et visible à l’échographie chez 19 à 68 %. '
   'Seuls 7 à 15 % des nodules sont malins, selon les données américaines et européennes reprises par l’ETA 2023.', 60, 75, 48) +
 F('Chiffres et terrain',
   TAB(['Donnée', 'Valeur', 'Source'], [
    ['Cancers de la thyroïde en Suisse', '≈ 850 par an (≈ 9 / 100 000)', 'NKRS 2018–2022'],
    ['Nodules palpables', '4–7 % des adultes', 'ATA 2015'],
    ['Nodules à l’échographie', '19–68 % des adultes', 'ATA 2015'],
    ['Malignité d’un nodule', '7–15 %', 'ATA 2015'],
    ['Sexe', 'Plus fréquent chez la femme', 'ETA 2023'],
   ]) + P('Le pronostic du carcinome papillaire est très bon. Les facteurs de risque de cancer sont une irradiation cervicale dans l’enfance, des antécédents familiaux de cancer thyroïdien (médullaire, NEM 2) et une croissance rapide.', 75, 48))))
PTS.append(POINT(3, 'Physiopathologie',
 P('La thyroïde capte l’iode et produit la T4 et la T3 sous le contrôle de la TSH hypophysaire. '
   'Un nodule naît d’une prolifération clonale de cellules folliculaires, souvent favorisée par la carence en iode. '
   'Un nodule autonome produit des hormones sans TSH et peut donner une hyperthyroïdie.', 48, 75) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'La thyroïde a deux lobes reliés par un isthme, devant la trachée ; les nerfs récurrents et les parathyroïdes sont en arrière.'],
    ['Physiologie', 'La TSH stimule la captation d’iode et la synthèse de T4 et T3 ; la calcitonine vient des cellules C.'],
    ['Physiopathologie', 'Un clone folliculaire forme un nodule bénin, autonome ou malin ; les cellules C donnent le carcinome médullaire.'],
    ['Clinique', 'D’où une masse cervicale antérieure mobile à la déglutition, parfois des signes d’hyperthyroïdie ou de compression.'],
    ['Examens', 'La TSH trie les nodules autonomes ; l’échographie classe le risque ; la cytoponction tranche.'],
    ['Traitement', 'Surveillance du nodule bénin, iode radioactif ou chirurgie du nodule autonome, chirurgie du cancer.'],
   ]), 48, 75) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Autonomie fonctionnelle', 'TSH, scintigraphie', 'Iode radioactif, chirurgie'],
    ['Prolifération bénigne', 'Échographie', 'Surveillance'],
    ['Transformation maligne folliculaire', 'Cytoponction', 'Thyroïdectomie'],
    ['Cellules C malignes', 'Calcitonine', 'Thyroïdectomie totale et curage'],
    ['Compression', 'Échographie, scanner', 'Chirurgie'],
   ]) + P('Cette chaîne justifie l’ordre : TSH, puis échographie, puis cytoponction si les seuils sont atteints.', 48, 76))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin écarte d’abord une urgence : stridor, dysphagie aiguë, hémorragie intranodulaire ou crise thyréotoxique. '
   'Il dose ensuite la TSH ; une TSH basse oriente vers un nodule chaud. '
   'Puis il classe le nodule à l’échographie et décide d’une cytoponction selon l’EU-TIRADS et la taille.', 48, 76) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Nodule bénin' + PR('85–93 % des nodules', 75), 'Nodule stable, EU-TIRADS 2–3', 'Échographie'],
    ['Cancer dans un nodule' + PR('7–15 % des nodules', 75), 'EU-TIRADS 5, adénopathie, croissance', 'Cytoponction'],
    DDXROW('thy', 'Nodule suspect', 'Cytoponction'),
    ['Nodule autonome (chaud)' + PR('fréquence non chiffrée ici', 48), 'TSH basse', 'Scintigraphie'],
    ['Kyste thyréoglosse' + PR('incidence non publiée', 20), 'Médian, monte à la protraction de la langue', 'Échographie'],
    DDXROW('react', 'Ganglion latéral', 'Échographie'),
   ]) + P('Les pourcentages sont des proportions parmi les nodules ; la ligne « / 100 000 » est une incidence suisse annuelle, d’une autre unité.', 75, 60))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien cherche une croissance, des signes de compression ou de dysthyroïdie, une irradiation cervicale et des cas familiaux.') +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Le nodule a-t-il grossi rapidement ?', 'Cancer, hémorragie.', 'Échographie rapide'],
    ['Votre voix a-t-elle changé ?', 'Atteinte récurrentielle.', 'Laryngoscopie'],
    ['Avalez-vous ou respirez-vous mal ?', 'Compression.', 'Imagerie, chirurgie'],
    ['Avez-vous reçu des rayons sur le cou dans l’enfance ?', 'Risque de cancer.', 'Seuil de cytoponction bas'],
    ['Y a-t-il des cancers de la thyroïde dans la famille ?', 'NEM 2, médullaire.', 'Calcitonine'],
    ['Avez-vous palpitations, perte de poids ?', 'Hyperthyroïdie.', 'TSH, scintigraphie'],
   ])) +
 U('<b>Drapeaux rouges</b> (ETA 2023, NHS) : croissance rapide, voix rauque, stridor, nodule dur et fixé, adénopathie cervicale, irradiation dans l’enfance. Ils imposent qu’on adresse rapidement le patient à un spécialiste ; un stridor est une urgence.', 48, 20)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin palpe la thyroïde par derrière, pendant que le patient avale. '
   'Il note la taille, la consistance, la mobilité et les aires ganglionnaires, puis cherche des signes de dysthyroïdie. '
   'La palpation ne suffit pas : elle manque de nombreux nodules visibles à l’échographie.', 75, 48) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal', 'Anomalie et signification'], [
    ['Palpation pendant la déglutition', 'Thyroïde non palpable ou souple', 'Nodule mobile : thyroïdien'],
    ['Consistance', 'Souple', 'Dur, fixé : suspect'],
    ['Aires ganglionnaires', 'Normales', 'Adénopathie : cancer possible'],
    ['Voix, respiration', 'Normales', 'Dysphonie, stridor'],
    ['Pouls, tremblement', 'Normaux', 'Tachycardie : hyperthyroïdie'],
   ]) + P('Un kyste thyréoglosse monte à la protraction de la langue, ce qui le distingue d’un nodule thyroïdien.', 20))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('La plupart des nodules ne donnent aucun signe fonctionnel. '
   'Un nodule autonome donne un syndrome d’hyperthyroïdie ; un gros goitre donne un syndrome compressif. '
   'Les signes physiques suspects sont un nodule dur, fixé, avec adénopathie.', 48) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    ['Syndrome d’hyperthyroïdie', 'Palpitations, amaigrissement, tremblement', 'Nodule autonome'],
    ['Syndrome compressif', 'Dysphagie, dyspnée, stridor', 'Compression trachéale ou œsophagienne'],
    ['Dysphonie', 'Voix rauque', 'Atteinte du nerf récurrent'],
    ['Douleur brutale', 'Augmentation soudaine', 'Hémorragie intranodulaire'],
   ]) + P('Termes : ' + CHA + '.', 48))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Selon la recommandation de l’ETA 2017 (EU-TIRADS), le critère de cytoponction dépend de la classe et de la taille : > 20 mm en classe 3, > 15 mm en classe 4, > 10 mm en classe 5. '
   'La cytoponction est classée selon le système de Bethesda 2023. '
   'L’échographie seule ne suffit pas à affirmer un cancer.', 76, 77, 48) +
 F('Classes EU-TIRADS',
   TAB(['Classe', 'Aspect', 'Risque de malignité', 'Seuil de cytoponction'], [
    ['EU-TIRADS 2', 'Kyste pur, spongiforme', '≈ 0 %', 'Aucune'],
    ['EU-TIRADS 3', 'Ovale, lisse, isoéchogène, sans signe de haut risque', '2–4 %', '> 20 mm'],
    ['EU-TIRADS 4', 'Modérément hypoéchogène, sans signe de haut risque', '6–17 %', '> 15 mm'],
    ['EU-TIRADS 5', 'Au moins un signe de haut risque (plus haut que large, contours irréguliers, microcalcifications, hypoéchogénicité marquée)', '26–87 %', '> 10 mm'],
   ]) + P('Ces seuils sont ceux de l’EU-TIRADS 2017.', 76)) +
 F('Catégories de Bethesda 2023',
   TAB(['Catégorie', 'Signification', 'Risque moyen de malignité', 'Conduite'], [
    ['I', 'Non diagnostique', '≈ 13 %', 'Nouvelle cytoponction'],
    ['II', 'Bénin', '≈ 4 %', 'Surveillance'],
    ['III', 'Atypies de signification indéterminée', '≈ 22 %', 'Nouvelle cytoponction, biologie moléculaire'],
    ['IV', 'Néoplasie folliculaire', '≈ 30 %', 'Lobectomie diagnostique ou biologie moléculaire'],
    ['V', 'Suspect de malignité', '≈ 74 %', 'Chirurgie'],
    ['VI', 'Malin', '≈ 97 %', 'Chirurgie'],
   ]) + P('Les risques moyens viennent du système de Bethesda 2023 ; ils varient selon les centres.', 77))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['TSH', 'Fonction thyroïdienne', 'Premier examen', 'Ne dit rien de la malignité'],
    ['Échographie classée EU-TIRADS', 'Risque de malignité', 'Bonne sensibilité pour les classes 4–5 ; spécificité modérée', 'Opérateur-dépendante'],
    ['Cytoponction échoguidée (Bethesda)', 'Nature cytologique', 'Référence avant chirurgie', 'Catégories III–IV indéterminées'],
    ['Histologie opératoire', 'Diagnostic définitif', 'Gold standard', 'Demande une chirurgie'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'TSH', 'Tout nodule'],
    ['Première', 'Échographie thyroïdienne et cervicale', 'Tout nodule'],
    ['Seconde', 'Scintigraphie', 'TSH basse'],
    ['Seconde', 'Cytoponction', 'Seuil EU-TIRADS atteint, ganglion suspect'],
    ['Seconde', 'Calcitonine', 'Antécédent familial, NEM 2, avant chirurgie selon l’ETA'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La <b>TSH</b> est indiquée d’emblée, à tout moment de la journée.', 'La <b>scintigraphie</b> se fait après une TSH basse ; elle demande l’arrêt des produits iodés et est contre-indiquée pendant la grossesse.', 'La <b>cytoponction</b> se fait sous échographie ; l’anticoagulant ne demande souvent pas d’arrêt (avis du centre).']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['TSH normale', '≈ 0,4–4,0 mU/L (selon le laboratoire)', 'Euthyroïdie', 'Échographie'],
    ['TSH basse', '< 0,4 mU/L', 'Nodule autonome possible', 'Scintigraphie'],
    ['Calcitonine', '> 100 pg/mL', 'Carcinome médullaire probable', 'Chirurgie spécialisée'],
    ['Résultat positif : Bethesda V–VI', '—', 'Cancer probable', 'Chirurgie'],
    ['Résultat négatif : Bethesda II', '—', 'Bénin', 'Surveillance'],
    ['Résultat limite : Bethesda III–IV', '—', 'Indéterminé', 'Nouvelle cytoponction, biologie moléculaire, lobectomie'],
    ['Résultat discordant : Bethesda II et EU-TIRADS 5', '—', 'Revoir', 'Nouvelle cytoponction'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Échographie et cytoponction possibles ; scintigraphie contre-indiquée'],
    ['Enfant', 'Risque de cancer plus élevé : avis spécialisé'],
    ['DFGe < 30 mL/min/1,73 m²', 'Calcitonine à interpréter avec prudence'],
    ['Iode (produit de contraste)', 'Retarde la scintigraphie et l’iode radioactif de plusieurs semaines'],
    ['Stimulateur cardiaque', 'Sans incidence sur l’échographie'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('La TSH est le premier examen. '
   'L’échographie thyroïdienne et cervicale classe le nodule selon l’EU-TIRADS. '
   'La cytoponction échoguidée est faite quand le seuil de taille est atteint.', 48, 76, 36) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si la TSH est basse, alors le médecin demande une scintigraphie ; un nodule chaud ne se ponctionne pas. '
   'Si la TSH est normale ou haute, alors il classe le nodule à l’échographie. '
   'Si le seuil EU-TIRADS est atteint, alors il demande une cytoponction et applique la conduite de Bethesda.', 48, 76, 77) +
 F('Embranchements',
   TAB(['Si…', 'Alors…', 'Contrôle'], [
    ['TSH basse, nodule chaud', 'Iode radioactif, chirurgie ou carbimazole', 'TSH'],
    ['EU-TIRADS 2', 'Aucune cytoponction', 'Pas de suivi systématique'],
    ['Seuil EU-TIRADS atteint', 'Cytoponction', 'Bethesda'],
    ['Bethesda II', 'Surveillance échographique', 'À 12–24 mois'],
    ['Bethesda V–VI', 'Chirurgie', 'Histologie'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Lévothyroxine, EUTHYROX® (hormone thyroïdienne T4 de synthèse)', 'Après thyroïdectomie totale : ≈ 1,6 µg/kg par jour à jeun, à vie ; demi-vie ≈ 7 jours ; ajustée selon la TSH après 6–8 semaines', 'Surdosage : palpitations, fibrillation auriculaire, ostéoporose ; contre-indiquée en hyperthyroïdie non traitée ; interactions avec le fer, le calcium et les IPP'],
   ['Carbimazole, NÉO-MERCAZOLE® (antithyroïdien, inhibe la thyroperoxydase)', '15–40 mg par jour au début, puis 5–15 mg ; demi-vie courte, action prolongée dans la thyroïde ; durée jusqu’au traitement définitif', 'Agranulocytose (fièvre, angine : formule sanguine en urgence), hépatite, éruption ; contre-indiqué au premier trimestre de grossesse'],
   ['Iode radioactif (iode 131, rayonnement bêta qui détruit les cellules qui le captent)', 'Activité fixée par la médecine nucléaire, dose unique ; élimination urinaire', 'Hypothyroïdie ; contre-indiqué pendant la grossesse et l’allaitement ; arrêt des produits iodés avant'],
  ]) + P('Les doses sont celles de l’AIPS ; le médecin les vérifie dans la version en vigueur.', 82, 48))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est de traiter les cancers et les nodules gênants, et de surveiller simplement les nodules bénins. '
   'Un nodule bénin asymptomatique se surveille par échographie. '
   'Un cancer différencié de bas risque relève d’une lobectomie ou d’une thyroïdectomie, selon l’ETA et l’ATA.', 48, 75) +
 F('11.A Buts : urgence ou non',
   P('La forme compliquée (stridor, hémorragie intranodulaire compressive, crise thyréotoxique) est une urgence à évaluer dans l’heure. La forme non compliquée se prend en charge en ambulatoire, avec des mesures générales (information, surveillance) ; la cytoponction est programmée en quelques semaines. Le but chiffré après thyroïdectomie totale est une TSH dans la cible fixée par l’endocrinologue.', 48), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Doser la TSH.', 'Faire l’échographie classée EU-TIRADS.', 'Cytoponction si le seuil est atteint.', 'Discuter en équipe le traitement des nodules suspects ou malins.', 'Organiser la surveillance des nodules bénins.']), 48, 76) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal prend en charge les examens et le traitement.', 'L’arrêt de travail après thyroïdectomie dure environ 1 à 3 semaines.', 'La LAA et la LAI sont rarement concernées ; la conduite automobile est possible dès que la douleur cervicale le permet.']), 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Pas de scintigraphie ni d’iode radioactif ; chirurgie au deuxième trimestre si nécessaire.'],
      ['Personne âgée', 'Lévothyroxine à dose initiale basse.'],
      ['Enfant', 'Centre spécialisé.'],
      ['Insuffisance hépatique', 'Carbimazole avec prudence.'],
      ['Insuffisance rénale (DFGe)', 'Calcitonine interprétée avec prudence.'],
      ['Cardiopathie', 'Lévothyroxine augmentée lentement.'],
     ]), 82, 48), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Échographie d’un nodule bénin', 'À 12–24 mois, puis espacée', 'Croissance > 20 % sur deux dimensions : nouvelle cytoponction'],
    ['TSH sous lévothyroxine', '6–8 semaines après chaque changement', 'Hors cible : ajuster'],
    ['Formule sanguine sous carbimazole', 'En cas de fièvre ou d’angine', 'Neutrophiles bas : arrêt'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Pas de saignement cervical.', 'Calcémie contrôlée après thyroïdectomie totale.', 'Voix et déglutition évaluées.', 'Traitement et suivi remis.']), 48) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic du nodule bénin est excellent ; celui du carcinome papillaire est très bon, avec guérison fréquente. La recherche 2026 évalue la biologie moléculaire des cytologies indéterminées et l’ablation thermique des nodules bénins.', 48), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur un apport suffisant en iode, assuré en Suisse par le sel iodé. '
   'La prévention secondaire évite le surdiagnostic : on ne ponctionne que si les seuils sont atteints. '
   'La prévention tertiaire organise le suivi après un cancer.', 48, 76) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Sel iodé (recommandation suisse de l’OFSP) ; limiter l’irradiation cervicale de l’enfant'],
    ['Secondaire', 'Pas de dépistage échographique de la population ; cytoponction selon l’EU-TIRADS'],
    ['Tertiaire', 'Suivi du cancer par TSH, thyroglobuline et échographie'],
   ]), 48, 76)))
PTS.append(POINT(13, 'Points clés',
 P('Le nodule thyroïdien est fréquent et malin dans 7 à 15 % des cas. '
   'Le premier examen est la TSH ; une TSH basse oriente vers un nodule chaud. '
   'L’échographie classée EU-TIRADS fixe le seuil de cytoponction. '
   'La cytoponction se lit selon Bethesda, qui fixe la conduite. '
   'Le médecin cherche les drapeaux rouges : croissance, dysphonie, adénopathie, irradiation.', 75, 48, 76, 77)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Ponctionner un nodule chaud.', 'Erreur : presque toujours bénin.'],
  ['Échographie avant la TSH.', 'La TSH vient en premier.'],
  ['Ponctionner tout nodule de 8 mm.', 'Faux : seuils EU-TIRADS.'],
  ['Scintigraphie pendant la grossesse.', 'Contre-indiquée.'],
  ['Bethesda I signifie bénin.', 'Faux : non diagnostique, à refaire.'],
 ]) + P('Ces pièges reprennent l’ETA 2023, l’EU-TIRADS et Bethesda 2023.', 48, 76, 77)))
CTX = {'_prefixe': 'Devant un nodule thyroïdien',
 'tsh': 'La TSH est le premier examen ; basse, elle oriente vers un nodule autonome.',
 'echothy': 'L’échographie classe le nodule selon l’EU-TIRADS et fixe le seuil de cytoponction.',
 'cyto': 'La cytoponction échoguidée se lit selon Bethesda 2023.',
 'scinti': 'La scintigraphie se fait si la TSH est basse ; un nodule chaud ne se ponctionne pas.',
 'calcito': 'Une calcitonine > 100 pg/mL fait suspecter un carcinome médullaire.',
 't4t3': 'La T4 libre précise une dysthyroïdie quand la TSH est anormale.',
 'tpo': 'Les anticorps anti-TPO orientent vers une thyroïdite de Hashimoto.',
 'trab': 'Les TRAb orientent vers une maladie de Basedow.',
 'tg': 'La thyroglobuline sert au suivi après cancer, pas au diagnostic du nodule.',
 'tdm': 'Le scanner évalue un goitre plongeant ; le produit iodé retarde l’iode radioactif.',
 'nfs': 'La formule sanguine en urgence recherche une agranulocytose sous carbimazole.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
