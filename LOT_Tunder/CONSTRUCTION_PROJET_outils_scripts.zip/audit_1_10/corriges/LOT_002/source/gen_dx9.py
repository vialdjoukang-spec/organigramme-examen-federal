# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.9 · Sarcome des tissus mous (LOT 2, Partie 4)."""
from lot2_commun import *
POINT = mkPOINT('dx9')
M = META('dx9', 'DX.9', 'Sarcome des tissus mous', 'Sarcome des tissus mous', 'LOT_002_DX9_Sarcome_des_tissus_mous_AUDITÉ.html', 4,
         'Les doses de chimiothérapie sont tirées de l’ESMO et de l’AIPS ; elles relèvent du centre de référence et restent à vérifier par un médecin.')
SAR = T('sarcome', 'Le sarcome est un cancer né du tissu conjonctif (graisse, muscle, vaisseaux, tissu fibreux), et non d’un épithélium comme le carcinome.')
FNC = T('grade FNCLCC', 'Le grade FNCLCC (Fédération nationale des centres de lutte contre le cancer) additionne trois scores : différenciation, mitoses et nécrose ; il classe le sarcome en grade 1, 2 ou 3.')
WHO = T('whoops procedure', 'La « whoops procedure » est l’exérèse non planifiée d’une masse crue bénigne qui se révèle être un sarcome ; elle contamine les tissus et aggrave le pronostic local.')
R0 = T('résection R0', 'Une résection R0 enlève la tumeur avec des marges saines au microscope ; R1 laisse des cellules en marge, R2 un reliquat visible.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Le {SAR} des tissus mous est un cancer rare, né du tissu de soutien des membres, du tronc ou du rétropéritoine. '
   'Il comprend plus de 50 sous-types histologiques, classés par l’OMS. '
   f'Son pronostic dépend du {FNC}, de la taille, de la profondeur et de la qualité de la chirurgie.', 74, 18) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Sarcome des tissus mous', 'Cancer conjonctif des parties molles', 'Sarcome osseux (ostéosarcome)'],
    ['Liposarcome', 'Sarcome adipocytaire', 'Lipome'],
    ['Sarcome pléomorphe indifférencié', 'Sarcome sans lignée identifiable', 'Carcinome indifférencié'],
    ['Léiomyosarcome', 'Sarcome du muscle lisse', 'Léiomyome'],
    ['Centre de référence', 'Équipe multidisciplinaire spécialisée en sarcomes', 'Chirurgie générale isolée'],
   ]) + P(f'Les termes {WHO} et {R0} structurent la prise en charge.', 2, 74))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, le sarcome des tissus mous touche environ 340 personnes par an, soit environ 4 pour 100 000 habitants, ou environ 1 % des cancers de l’adulte. '
   'En Europe, l’ESMO estime l’incidence à environ 4 à 5 pour 100 000 par an. '
   'Il est environ 100 fois plus rare que les tumeurs bénignes des tissus mous.', 60, 74) +
 F('Chiffres, terrain et facteurs de risque',
   TAB(['Donnée', 'Valeur', 'Source'], [
    ['Cas en Suisse', '≈ 340 par an (≈ 4 / 100 000)', 'NKRS 2018–2022'],
    ['Incidence européenne', '≈ 4–5 / 100 000 par an', 'ESMO 2021'],
    ['Part des cancers de l’adulte', '≈ 1 %', 'ESMO 2021 (à vérifier)'],
    ['Siège', 'Membres surtout, puis tronc et rétropéritoine', 'ESMO 2021'],
    ['Survie à 5 ans', 'Non chiffrée ici : dépend du grade et du sous-type', 'Aucune source suisse'],
   ]) + P('Le pronostic dépend du grade, de la taille et de la marge. Les facteurs de risque sont une radiothérapie antérieure, le lymphœdème chronique (syndrome de Stewart-Treves), la neurofibromatose de type 1 et le syndrome de Li-Fraumeni.', 74, 18))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Une cellule mésenchymateuse accumule des altérations génétiques : translocation spécifique, amplification (MDM2 dans le liposarcome) ou génome instable. '
   'La tumeur croît dans le compartiment musculaire et refoule les tissus en formant une pseudocapsule envahie de cellules tumorales. '
   'Elle métastase surtout par voie sanguine vers le poumon.', 74, 18) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les muscles sont groupés en loges limitées par des fascias, barrières naturelles.'],
    ['Physiologie', 'Les cellules mésenchymateuses renouvellent graisse, muscle et tissu fibreux.'],
    ['Physiopathologie', 'Un clone malin croît dans la loge, forme une pseudocapsule infiltrée et essaime vers le poumon.'],
    ['Clinique', 'D’où une masse profonde, ferme, croissante, souvent indolore au début.'],
    ['Examens', 'L’IRM précise la loge ; la biopsie au trocart donne le type et le grade ; le scanner thoracique cherche les métastases.'],
    ['Traitement', 'La pseudocapsule infiltrée impose une exérèse large R0, souvent avec radiothérapie.'],
   ]), 74, 2) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Croissance dans la loge', 'IRM avec gadolinium', 'Exérèse large R0'],
    ['Pseudocapsule infiltrée', 'Histologie des marges', 'Radiothérapie'],
    ['Métastases pulmonaires', 'Scanner thoracique', 'Chimiothérapie, chirurgie des métastases'],
    ['Amplification de MDM2', 'FISH MDM2', 'Diagnostic du liposarcome'],
    ['Translocation spécifique', 'Biologie moléculaire', 'Classement du sous-type'],
   ]) + P('Cette chaîne explique la règle centrale : biopsier et opérer dans le même centre.', 2, 34)) +
 F('Sous-types fréquents et leur biologie',
   TAB(['Sous-type', 'Siège habituel', 'Anomalie typique', 'Conséquence pratique'], [
    ['Liposarcome bien différencié ou dédifférencié', 'Cuisse, rétropéritoine', 'Amplification de MDM2', 'FISH MDM2 sur biopsie'],
    ['Liposarcome myxoïde', 'Cuisse', 'Translocation caractéristique', 'Sensible à la radiothérapie'],
    ['Sarcome pléomorphe indifférencié', 'Membres, sujet âgé', 'Génome instable', 'Haut grade fréquent'],
    ['Léiomyosarcome', 'Rétropéritoine, utérus, vaisseaux', 'Génome instable', 'Métastases fréquentes'],
    ['Synovialosarcome', 'Près des articulations, adulte jeune', 'Translocation caractéristique', 'Chimiosensible'],
    ['Rhabdomyosarcome', 'Enfant, tête et cou', 'Translocation caractéristique (forme alvéolaire)', 'Centre pédiatrique'],
   ]) + P('La biologie moléculaire confirme le sous-type et oriente le traitement ; le pathologiste de référence la demande sur la biopsie.', 74, 18))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin cherche d’abord une urgence vitale : compression vasculaire ou nerveuse, saignement, détresse respiratoire. '
   'Il applique ensuite les drapeaux rouges : masse > 5 cm, profonde, croissante, douloureuse ou récidivante. '
   'Puis il demande une IRM et adresse au centre avant toute biopsie ou exérèse.', 2, 74, 37) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    DDXROW('sarc', 'Masse profonde > 5 cm, croissante', 'IRM puis biopsie au trocart'),
    ['Lipome' + PR('16 % des tumeurs bénignes des tissus mous', 83), 'Masse molle, superficielle, stable', 'Échographie'],
    ['Hématome' + PR('incidence non publiée', 44), 'Traumatisme, anticoagulant', 'IRM ; un hématome sans cause se biopsie'],
    DDXROW('nhl', 'Adénopathies, signes B', 'Biopsie'),
    DDXROW('mel', 'Antécédent de mélanome', 'Biopsie'),
    ['Myosite ossifiante' + PR('incidence non publiée', 44), 'Traumatisme, calcification périphérique', 'Scanner'],
   ]) + P('Les lignes « / 100 000 » sont des incidences suisses annuelles ; les pourcentages sont des proportions parmi les tumeurs des tissus mous et ne se comparent pas directement.', 60, 83))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien date la masse, mesure sa croissance et cherche les facteurs de risque : radiothérapie, lymphœdème, syndrome familial.') +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis quand la masse grossit-elle ?', 'Croissance : drapeau rouge.', 'IRM rapide'],
    ['Avez-vous reçu une radiothérapie ?', 'Sarcome radio-induit.', 'Biopsie'],
    ['Y a-t-il des cancers dans la famille ?', 'Li-Fraumeni.', 'Conseil génétique'],
    ['Avez-vous des taches café au lait ?', 'Neurofibromatose de type 1.', 'Examen cutané'],
    ['Avez-vous perdu du poids, ou toussez-vous ?', 'Métastases pulmonaires.', 'Scanner thoracique'],
    ['A-t-on déjà enlevé une masse ici ?', 'Récidive après exérèse incomplète.', 'Centre'],
   ])) +
 U('<b>Drapeaux rouges</b> : masse > 5 cm, profonde, croissante, douloureuse ou récidivante ; toute masse du rétropéritoine. Ils imposent une IRM et l’adresse au Swiss Sarcoma Network avant toute biopsie.', 2, 34, 74)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure la masse, apprécie sa profondeur par la contraction musculaire, sa fixité et sa consistance. '
   'Il examine les pouls, la sensibilité et la motricité en aval, puis les aires ganglionnaires et le poumon. '
   'L’examen ne suffit pas : une masse profonde paraît souvent plus petite qu’elle n’est.', 74, 2) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal', 'Anomalie et signification'], [
    ['Mesure à la règle', '< 5 cm', '> 5 cm : drapeau rouge'],
    ['Contraction musculaire', 'Masse mobile, superficielle', 'Masse fixée : profonde'],
    ['Palpation', 'Molle', 'Ferme, fixée : suspect'],
    ['Pouls, sensibilité, motricité', 'Normaux', 'Compression vasculo-nerveuse'],
    ['Aires ganglionnaires', 'Normales', 'Adénopathie : sous-types rares (épithélioïde, synovial)'],
   ]) + P('La palpation ne distingue pas un sarcome d’une tumeur bénigne profonde.', 74))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Le sarcome se présente surtout comme une masse indolore et croissante, sans syndrome général. '
   'Les signes fonctionnels apparaissent tard : douleur, syndrome compressif vasculaire ou nerveux. '
   'Les signes physiques sont une masse ferme, profonde, parfois fixée.', 74) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    ['Masse croissante', 'Augmentation mesurée', 'Prolifération maligne'],
    ['Syndrome compressif', 'Œdème, paresthésies, déficit', 'Compression vasculo-nerveuse'],
    ['Douleur', 'Tardive', 'Envahissement nerveux ou osseux'],
    ['Dyspnée', 'Rare au diagnostic', 'Métastases pulmonaires'],
   ]) + P('Termes : ' + WHO + '.', 2))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le critère diagnostique est l’histologie d’une biopsie au trocart, lue par un pathologiste spécialisé selon la classification OMS 2020. '
   'Le grade FNCLCC et la taille (seuil 5 cm) entrent dans la stadification selon la recommandation ESMO 2021. '
   'L’imagerie seule ne suffit pas à poser le diagnostic.', 74, 18) +
 F('Éléments qui confirment ou réfutent',
   TAB(['Confirme', 'Réfute ou fait revoir'], [
    ['Histologie de sarcome avec immunohistochimie', 'Tumeur bénigne à l’histologie'],
    ['Translocation ou amplification spécifique', 'Biologie moléculaire non concordante : relecture'],
    ['Grade FNCLCC 1, 2 ou 3', 'Prélèvement non représentatif : nouvelle biopsie'],
    ['IRM : masse profonde hétérogène, nécrose', 'IRM : lésion kystique pure'],
   ]) + H4('Grade FNCLCC') + TAB(['Score', 'Différenciation', 'Mitoses (pour 10 champs)', 'Nécrose'], [['0', '—', '—', 'Absente'], ['1', 'Proche du tissu adulte normal', '0–9', '< 50 %'], ['2', 'Type histologique certain', '10–19', '≥ 50 %'], ['3', 'Embryonnaire ou indifférencié', '≥ 20', '—']]) + P('La somme des trois scores (2 à 8) donne le grade : 2–3 = grade 1, 4–5 = grade 2, 6–8 = grade 3.', 74) + P('La relecture par un pathologiste de référence modifie souvent le diagnostic de sarcome ; le chiffre exact n’est pas sourcé ici.', 74))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['IRM avec gadolinium', 'Taille, profondeur, loge', 'Référence d’imagerie locale ; sensibilité élevée, spécificité limitée', 'Ne donne pas le type'],
    ['Biopsie au trocart (plusieurs carottes)', 'Type et grade', 'Gold standard', 'À faire dans le centre qui opère'],
    ['Scanner thoracique', 'Métastases pulmonaires', 'Bilan d’extension', 'Nodules non spécifiques'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Échographie', 'Masse superficielle de doute'],
    ['Première', 'IRM', 'Drapeau rouge'],
    ['Seconde', 'Biopsie au trocart en centre', 'IRM suspecte'],
    ['Seconde', 'Scanner thoracique, TEP selon le sous-type', 'Sarcome confirmé'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['L’<b>IRM</b> est indiquée avant toute biopsie ; elle demande la créatinine et la recherche de métal.', 'La <b>biopsie</b> se fait après l’IRM, selon un trajet que le chirurgien enlèvera ; l’anticoagulant fait l’objet d’un arrêt planifié.', 'Le <b>scanner thoracique</b> se fait après le diagnostic.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Taille normale d’une masse bénigne superficielle', '< 5 cm', 'Rassurant si superficielle', 'Surveillance'],
    ['Taille', '> 5 cm', 'Drapeau rouge', 'IRM, centre'],
    ['Résultat positif : sarcome à la biopsie', 'Grade 1–3', 'Cancer', 'Discussion multidisciplinaire'],
    ['Résultat négatif : tumeur bénigne', '—', 'Bénin', 'Prise en charge adaptée'],
    ['Résultat limite : prélèvement non représentatif', '—', 'Incertitude', 'Nouvelle biopsie'],
    ['Résultat discordant : IRM agressive, histologie bénigne', '—', 'Revoir', 'Relecture, nouvelle biopsie'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'IRM sans gadolinium ; décision en centre'],
    ['Enfant', 'Rhabdomyosarcome : centre pédiatrique'],
    ['DFGe < 30 mL/min/1,73 m²', 'IRM sans gadolinium'],
    ['Allergie à l’iode', 'Scanner thoracique sans contraste, suffisant pour les nodules'],
    ['Stimulateur cardiaque', 'IRM selon la compatibilité ; sinon scanner'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('L’IRM avec gadolinium est l’examen de première intention devant un drapeau rouge. '
   'La biopsie au trocart, faite dans le centre qui opérera, donne le type et le grade. '
   'Le scanner thoracique complète le bilan d’extension.', 74, 2) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si la masse porte un drapeau rouge, alors le médecin demande une IRM et adresse au centre. '
   'Si l’IRM est suspecte, alors le centre fait la biopsie au trocart. '
   'Si le sarcome est confirmé, alors la discussion multidisciplinaire fixe la chirurgie, la radiothérapie et la chimiothérapie.', 2, 74) +
 F('Embranchements',
   TAB(['Si…', 'Alors…', 'Contrôle'], [
    ['Drapeau rouge', 'IRM, centre', 'Avant biopsie'],
    ['Sarcome localisé de haut grade, profond, > 5 cm', 'Exérèse large R0 et radiothérapie', 'Marges'],
    ['Sarcome de bas grade, superficiel', 'Exérèse large seule', 'Marges'],
    ['Métastases', 'Chimiothérapie par doxorubicine', 'Imagerie toutes les 6–9 semaines'],
    [WHO, 'Adresser au centre pour reprise', 'IRM postopératoire'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS et ESMO)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Doxorubicine, ADRIBLASTIN® (anthracycline, s’intercale dans l’ADN et inhibe la topoisomérase II)', '75 mg/m² IV toutes les 3 semaines, jusqu’à 6 cycles ; dose cumulée limitée (≈ 450–550 mg/m²) ; demi-vie terminale ≈ 20–48 heures ; élimination biliaire', 'Cardiotoxicité, aplasie, mucite, alopécie ; contre-indiquée si fraction d’éjection basse ; interactions avec le trastuzumab et le vérapamil'],
   ['Ifosfamide, HOLOXAN® (agent alkylant, lie les brins d’ADN) avec mésna (protège la vessie)', '≈ 9–10 g/m² par cycle, réparti sur plusieurs jours, toutes les 3 semaines ; élimination rénale', 'Cystite hémorragique, encéphalopathie, toxicité rénale ; contre-indiqué en insuffisance rénale sévère'],
   ['Ondansétron, ZOFRAN® (antagoniste des récepteurs 5-HT3)', '8 mg avant la chimiothérapie, puis 8 mg 2 fois par jour, 2–3 jours ; demi-vie ≈ 3–4 heures ; métabolisme hépatique', 'Constipation, céphalées, allongement de l’intervalle QT ; interaction avec les autres médicaments allongeant le QT'],
  ]) + P('Les doses sont indicatives et relèvent du centre ; elles restent à vérifier dans l’AIPS en vigueur.', 74, 82))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est une résection R0 en centre de référence, qui contrôle la maladie locale. '
   'La radiothérapie complète la chirurgie des sarcomes profonds de haut grade. '
   'La chimiothérapie par doxorubicine traite les formes métastatiques et certains sous-types.', 74, 18, 2) +
 F('11.A Buts : urgence ou non',
   P('La forme compliquée (compression vasculaire, saignement) est une urgence à adresser dans l’heure ; la forme non compliquée est programmée en quelques semaines, en ambulatoire jusqu’à la chirurgie, avec des mesures générales (antalgie, information, soutien). Le but chiffré est une marge R0, de préférence ≥ 1 cm de tissu sain selon le site.', 74), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Adresser au centre avant toute biopsie.', 'IRM, puis biopsie au trocart.', 'Bilan d’extension par scanner thoracique.', 'Discussion multidisciplinaire.', 'Chirurgie large, avec radiothérapie avant ou après selon le cas.', 'Chimiothérapie selon le grade, le sous-type et l’extension.']), 2, 74) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal prend en charge le traitement ; la LAI peut intervenir pour une réadaptation professionnelle après une amputation ou une séquelle fonctionnelle.', 'L’arrêt de travail est souvent de plusieurs mois.', 'La LAA n’intervient pas, sauf sarcome radio-induit reconnu professionnel (rare) ; la conduite automobile se réévalue après la chirurgie d’un membre.']), 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Décision en centre ; chimiothérapie contre-indiquée au premier trimestre.'],
      ['Personne âgée', 'Évaluation gériatrique avant chimiothérapie.'],
      ['Enfant', 'Centre pédiatrique.'],
      ['Insuffisance hépatique', 'Doxorubicine réduite selon la bilirubine.'],
      ['Insuffisance rénale (DFGe)', 'Ifosfamide évité si DFGe bas.'],
      ['Fertilité', 'Préservation avant chimiothérapie.'],
     ]), 74, 82), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['IRM du site opéré', 'Tous les 3–6 mois les premières années (haut grade)', 'Récidive locale'],
    ['Scanner thoracique', 'Tous les 3–6 mois les premières années', 'Métastases'],
    ['Échocardiographie', 'Avant et pendant la doxorubicine', 'Baisse de fraction d’éjection : arrêt'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Plaie cicatrisée ou soins organisés.', 'Douleur contrôlée.', 'Rééducation planifiée.', 'Calendrier de suivi remis.']), 74) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic dépend du grade, de la taille, de la profondeur et de la marge ; la guérison est fréquente pour un sarcome de bas grade réséqué R0. La recherche 2026 évalue les thérapies ciblées par sous-type et l’immunothérapie.', 74), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire se limite à éviter les irradiations inutiles. '
   'La prévention secondaire consiste à adresser tôt toute masse à drapeau rouge. '
   f'La prévention tertiaire évite la {WHO} et organise le suivi.', 2, 74) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Indication stricte des radiothérapies ; traitement du lymphœdème'],
    ['Secondaire', 'Recommandation suisse du Swiss Sarcoma Network : IRM et centre devant tout drapeau rouge'],
    ['Tertiaire', 'Chirurgie en centre ; suivi d’imagerie ; conseil génétique si Li-Fraumeni'],
   ]), 2, 34)))
PTS.append(POINT(13, 'Points clés',
 P('Le sarcome des tissus mous est rare : environ 4 cas pour 100 000 habitants par an en Suisse. '
   'Une masse > 5 cm, profonde, croissante ou douloureuse impose une IRM. '
   'Le médecin adresse au centre de référence avant toute biopsie ou exérèse. '
   'La biopsie au trocart donne le type et le grade. '
   'Le traitement repose sur une exérèse large R0, souvent avec radiothérapie.', 60, 2, 74)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Énucléer une masse profonde « lipomateuse ».', 'Erreur : IRM et centre d’abord.'],
  ['Une masse indolore est bénigne.', 'Faux : le sarcome est souvent indolore.'],
  ['Biopsie chirurgicale ouverte au cabinet.', 'Erreur : biopsie au trocart en centre.'],
  ['Un hématome spontané se surveille.', 'Faux : il peut masquer un sarcome.'],
  ['Le sarcome métastase surtout aux ganglions.', 'Faux : surtout au poumon.'],
 ]) + P('Ces pièges reprennent l’ESMO 2021 et le Swiss Sarcoma Network.', 74, 2)))
CTX = {'_prefixe': 'Devant un sarcome des tissus mous',
 'irm': 'L’IRM avec gadolinium précise la taille, la profondeur et la loge ; elle précède toute biopsie.',
 'biopsie': 'La biopsie au trocart se fait dans le centre qui opérera, selon un trajet planifié.',
 'mdm2': 'L’amplification de MDM2 signe le liposarcome bien différencié ou dédifférencié.',
 'tdm': 'Le scanner thoracique cherche les métastases pulmonaires.',
 'tep': 'La TEP-TDM aide pour certains sous-types et pour le bilan d’extension.',
 'echo': 'L’échographie trie les masses superficielles ; elle ne remplace pas l’IRM.',
 'echocoeur': 'L’échocardiographie mesure la fraction d’éjection avant la doxorubicine.',
 'creat': 'Le DFGe guide le gadolinium et l’ifosfamide.',
 'nfs': 'La formule sanguine surveille l’aplasie après chimiothérapie.',
 'radio': 'La radiographie montre une atteinte osseuse ou des calcifications.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
