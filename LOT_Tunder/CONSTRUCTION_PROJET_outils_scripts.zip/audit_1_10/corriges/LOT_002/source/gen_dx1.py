# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.1 · Adénopathie réactionnelle non spécifique (LOT 2, Appel B, Partie 1, r2 → audit du 24.10.2026)."""
from lot2_commun import *
POINT = mkPOINT('dx1')
M = META('dx1', 'DX.1', 'Adénopathie réactionnelle', 'Adénopathie réactionnelle non spécifique', 'LOT_002_DX1_Adenopathie_reactionnelle_AUDITÉ.html', 1,
         'Les doses de paracétamol proviennent de l’information professionnelle suisse (AIPS) de DAFALGAN®.')
GG = T('ganglion lymphatique', 'Le ganglion lymphatique est un petit organe en forme de haricot placé sur le trajet de la lymphe ; il filtre les antigènes venus de son territoire et y déclenche la réponse immunitaire.')
TERR = T('territoire de drainage', 'Le territoire de drainage est la région du corps dont la lymphe rejoint un groupe ganglionnaire donné ; un foyer dans ce territoire explique une adénopathie de ce groupe.')
GEN = T('adénopathie généralisée', 'Une adénopathie est dite généralisée lorsqu’elle touche au moins deux territoires ganglionnaires non contigus ; elle oriente vers une cause systémique (virus, VIH, lymphome, maladie auto-immune, médicament).')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Une adénopathie est un {GG} anormal par sa taille, en pratique plus de 1 cm de petit axe, ou par sa consistance. '
   'L’adénopathie réactionnelle non spécifique est l’augmentation de volume d’un ganglion qui répond à un antigène venu de son territoire, sans maladie propre du ganglion. '
   'C’est une hypothèse de travail qui se confirme par la régression, et non un diagnostic posé à la palpation.', 64, 66, 6) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Adénopathie', 'Ganglion > 1 cm (seuils : épitrochléen > 0,5 cm, inguinal > 1,5 cm)', 'Masse non ganglionnaire : lipome, kyste, nodule thyroïdien'],
    ['Adénopathie localisée', 'Un seul territoire touché', f'{GEN}'],
    ['Adénopathie réactionnelle', 'Hyperplasie bénigne en réponse à un antigène', 'Lymphadénite bactérienne (DX.2) : ganglion infecté, chaud, douloureux'],
    ['Adénite suppurée', 'Ganglion abcédé, fluctuant', 'Abcès cutané ou kyste surinfecté'],
    ['Lymphœdème', 'Gonflement d’un membre par défaut de drainage lymphatique', 'Adénopathie, qui est une masse localisée'],
   ]) + P(f'Le mot « réactionnel » décrit un mécanisme ; il se distingue d’une adénopathie tumorale ou granulomateuse uniquement par le contexte, l’évolution et, si besoin, l’histologie. Le {TERR} relie la masse à sa cause probable.', 64, 66))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('Aucune incidence suisse des adénopathies réactionnelles n’est publiée, et les sources suisses (Primary and Hospital Care 2020) décrivent un motif fréquent de consultation au cabinet. '
   'Dans une étude néerlandaise de médecine de famille (Europe), une cause maligne n’a été trouvée que chez 1,1 % des patients avec une adénopathie inexpliquée. '
   'Le risque augmente avec l’âge : environ 0,4 % avant 40 ans et 4 % après 40 ans selon une revue américaine.', 32, 65, 64) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Malignité devant une adénopathie inexpliquée en médecine de famille', '1,1 % (Pays-Bas, 2556 patients)', 'Population de soins primaires, non hospitalière'],
    ['Malignité selon l’âge', '≈ 0,4 % avant 40 ans ; ≈ 4 % après 40 ans', 'Ordre de grandeur, revue américaine'],
    ['Adénopathie sus-claviculaire', 'Malignité estimée à 34–50 %', 'Territoire le plus à risque'],
    ['Adénopathie généralisée', 'Cause systémique plus probable', 'Bilan d’emblée'],
    ['Incidence suisse', 'Non disponible', 'Aucune source suisse trouvée'],
   ]) + P('Le facteur de risque principal de malignité est l’âge, suivi du siège sus-claviculaire, de la durée de plus de 4 semaines et des signes généraux. Le pronostic d’une adénopathie réactionnelle est excellent : elle régresse en quelques semaines lorsque la cause disparaît, sans mortalité propre.', 64, 66))))
PTS.append(POINT(3, 'Physiopathologie',
 P('La lymphe d’un territoire arrive au ganglion par les vaisseaux afférents et traverse ses sinus, où les cellules présentatrices d’antigène captent les germes et les débris. '
   'Les lymphocytes B se multiplient dans les follicules et les lymphocytes T dans le paracortex, ce qui augmente le volume du ganglion. '
   'La distension rapide de la capsule explique la douleur, et le retour au calme après l’élimination de l’antigène explique la régression.', 64, 66) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Environ 600 ganglions jalonnent les vaisseaux lymphatiques ; les groupes palpables sont cervicaux, sus-claviculaires, axillaires, épitrochléens et inguinaux.'],
    ['Physiologie', 'Chaque groupe filtre la lymphe d’un territoire précis ; le ganglion est le lieu où l’antigène rencontre le lymphocyte.'],
    ['Physiopathologie', 'Une infection ou une inflammation locale apporte des antigènes ; la prolifération lymphocytaire (hyperplasie folliculaire ou paracorticale) fait grossir le ganglion.'],
    ['Clinique', 'D’où un ganglion souple, mobile, souvent sensible, dans le territoire d’un foyer récent (angine, plaie, eczéma).'],
    ['Examens', 'Comme la cause est extérieure au ganglion, on cherche le foyer ; le ganglion lui-même ne s’explore que s’il persiste ou paraît suspect.'],
    ['Traitement', 'On traite le foyer, pas le ganglion ; la régression attendue en 2 à 4 semaines confirme l’hypothèse.'],
   ]), 64, 66) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme (lésion)', 'Exploration', 'Cible thérapeutique'], [
    ['Hyperplasie folliculaire (réponse B)', 'Palpation, recherche du foyer', 'Traitement du foyer'],
    ['Hyperplasie paracorticale (réponse T, virus)', 'Hémogramme, sérologies orientées', 'Traitement symptomatique'],
    ['Histiocytose sinusale (drainage de débris)', 'Examen du territoire', 'Aucun traitement spécifique'],
    ['Distension capsulaire (douleur)', 'Palpation douce', 'Antalgique (paracétamol)'],
    ['Persistance anormale (> 4 semaines)', 'Échographie, biopsie', 'Diagnostic histologique'],
   ]) + P('Cette réponse explique pourquoi un ganglion réactionnel reste mobile : l’architecture et la capsule restent intactes. À l’inverse, une infiltration tumorale détruit l’architecture, ce qui provoque un ganglion dur, fixé et indolore.', 64))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin recherche d’abord une urgence vitale : stridor, dysphagie, sepsis, compression veineuse cave supérieure. '
   'Ensuite, il distingue une adénopathie localisée avec un foyer évident d’une adénopathie généralisée ou sans cause. '
   'Enfin, il cherche les éléments de malignité : âge ≥ 40 ans, siège sus-claviculaire, taille > 2 cm, dureté, fixation, durée > 4 semaines, signes généraux.', 64, 66, 6) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Adénopathie réactionnelle bénigne' + PR('≈ 99 % des adénopathies inexpliquées en médecine de famille', 65), 'Foyer dans le territoire, ganglion souple et mobile, régression', 'Évolution à 2–4 semaines'],
    ['Toutes causes malignes réunies' + PR('1,1 % (≈ 4 % après 40 ans)', 65, 64), 'Ganglion dur, fixé, indolore, sus-claviculaire', 'Biopsie-exérèse'],
    DDXROW('nhl', 'Adénopathies persistantes, signes B, âge', 'Biopsie-exérèse, cytométrie'),
    DDXROW('hl', 'Adulte jeune, adénopathie cervicale ou médiastinale, prurit', 'Biopsie-exérèse'),
    DDXROW('orl', 'Fumeur, alcool, ganglion cervical dur, dysphonie, otalgie', 'Examen ORL, cytoponction'),
    DDXROW('tb', 'Migration, contact, ganglion cervical froid, fistule', 'IGRA, biopsie avec culture'),
    DDXROW('vih', 'Adénopathies généralisées, exposition, syndrome viral', 'Test VIH de 4e génération'),
    ['Mononucléose infectieuse' + PR('incidence suisse non publiée', 68), 'Adolescent, angine, fatigue, adénopathies cervicales postérieures', 'Monotest, hémogramme'],
    ['Lymphadénite bactérienne (DX.2)' + PR('incidence non publiée', 69), 'Ganglion chaud, rouge, très douloureux, fièvre', 'Échographie si fluctuation'],
    ['Maladie des griffes du chat' + PR('incidence suisse non publiée', 86), 'Contact avec un chaton, papule d’inoculation', 'Sérologie Bartonella'],
   ]) + P(UNITE + ' Les deux premières lignes donnent, elles, la probabilité devant une adénopathie inexpliquée en médecine de famille.', 60, 65))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien date l’apparition, décrit l’évolution et recherche un foyer infectieux récent dans le territoire. '
   'Il recherche les signes généraux, les expositions (animaux, voyages, sexualité, tuberculose) et les médicaments.', 64, 66) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis quand la boule est-elle là ? Grossit-elle ?', 'Plus de 4 semaines ou une croissance continue sont suspectes.', 'Bilan au lieu de la surveillance'],
    ['Avez-vous eu une angine, une plaie, un soin dentaire ?', 'Un foyer du territoire explique la réaction.', 'Soutient l’hypothèse réactionnelle'],
    ['Avez-vous de la fièvre, des sueurs nocturnes, perdu du poids ?', 'Ce sont les symptômes B des lymphomes.', 'Biopsie rapide'],
    ['Avez-vous un chat, voyagé, eu un contact tuberculeux ?', 'Bartonella, toxoplasmose, tuberculose.', 'Sérologies, IGRA'],
    ['Avez-vous eu un rapport sexuel à risque ?', 'VIH, syphilis.', 'Test VIH et syphilis'],
    ['Fumez-vous ? Buvez-vous de l’alcool ?', 'Facteurs de risque des cancers ORL.', 'Examen ORL complet'],
    ['Quels médicaments prenez-vous ?', 'Phénytoïne, allopurinol peuvent donner des adénopathies.', 'Arrêt et contrôle'],
   ])) +
 U('<b>Drapeaux rouges</b> : stridor, dysphagie ou trismus (appel du 144 ou urgences), sepsis, adénopathie sus-claviculaire, ganglion dur et fixé, taille > 2 cm, croissance, persistance > 4 semaines, symptômes B, adénopathie généralisée inexpliquée ; ils imposent un bilan rapide et l’adresse au spécialiste.', 6, 64, 66, 37)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin inspecte puis palpe toutes les aires ganglionnaires, des deux côtés, avec la pulpe des doigts et en mouvements circulaires. '
   'Il mesure le ganglion avec une règle, note sa consistance, sa mobilité, sa sensibilité, puis examine le territoire de drainage, le foie et la rate. '
   'Aucun signe isolé n’a une sensibilité suffisante ; la combinaison âge, taille, dureté et siège porte la valeur diagnostique.', 64, 66) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Palpation cervicale, patient assis, tête légèrement fléchie du côté examiné', 'Ganglions < 1 cm, souples, mobiles', 'Ganglion > 1 cm : adénopathie'],
    ['Palpation sus-claviculaire pendant une manœuvre de Valsalva', 'Aucun ganglion palpable', 'Ganglion de Troisier à gauche : cancer abdominal ; à droite : thorax'],
    ['Palpation axillaire, bras du patient soutenu', 'Petits ganglions souples possibles', 'Ganglion dur : cancer du sein, mélanome, lymphome'],
    ['Palpation inguinale', 'Ganglions jusqu’à 1,5 cm souvent normaux', 'Ganglion dur, fixé : cancer anal, vulvaire, mélanome'],
    ['Consistance et mobilité', 'Souple, mobile', 'Dur, fixé, indolore : malignité ; fluctuant : abcès'],
    ['Palpation de la rate et du foie', 'Non palpables', 'Splénomégalie : mononucléose, lymphome'],
   ]) + P('La sensibilité oriente vers une cause inflammatoire, mais une hémorragie dans un ganglion tumoral peut aussi être douloureuse ; la douleur ne prouve donc pas la bénignité.', 64, 66))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la boule perçue, la douleur, et parfois les symptômes du foyer : mal de gorge, plaie, prurit. '
   'Les signes physiques sont la taille, la consistance, la mobilité, la sensibilité et le foyer visible. '
   'Ils se regroupent en syndrome de drainage local, syndrome mononucléosique, syndrome d’adénopathies généralisées et syndrome tumoral.', 64, 66) +
 F('Signes définis',
   TAB(['Signe ou syndrome', 'Description', 'Mécanisme'], [
    ['Ganglion souple et mobile', 'Roule sous les doigts, consistance élastique', 'Architecture et capsule intactes'],
    ['Ganglion sensible', 'Douleur à la palpation', 'Distension rapide de la capsule'],
    ['Ganglion dur et fixé', 'Consistance pierreuse, adhérent aux plans', 'Infiltration tumorale et dépassement capsulaire'],
    ['Syndrome de drainage local', 'Ganglion + foyer du territoire', 'Réponse immunitaire régionale'],
    ['Syndrome mononucléosique', 'Angine, fièvre, adénopathies, lymphocytes activés', 'Prolifération T contre des cellules infectées par un virus'],
    ['Symptômes B', 'Fièvre > 38 °C, sueurs nocturnes, perte de poids > 10 % en 6 mois', 'Cytokines tumorales (lymphome)'],
    ['Adénopathies généralisées', '≥ 2 territoires non contigus', 'Maladie systémique'],
   ]) + P('Termes : ' + T('ganglion de Troisier', 'Le ganglion de Troisier (ou de Virchow) est une adénopathie sus-claviculaire gauche ; il reçoit la lymphe du canal thoracique et révèle souvent un cancer abdominal.') + ', ' + T('hyperplasie folliculaire', 'L’hyperplasie folliculaire est la multiplication des follicules lymphoïdes B ; c’est l’aspect histologique typique d’une réaction bénigne.') + '.', 64, 66))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Aucune société savante ne publie de critères formels de l’adénopathie réactionnelle ; le diagnostic repose sur un foyer cohérent et sur la régression. '
   'Les revues américaines (Ferrer 1998, Gaddey 2016) proposent une surveillance de 3 à 4 semaines si l’adénopathie est localisée, < 2 cm, sans signe de malignité. '
   'Une biologie normale ne suffit pas à poser le diagnostic, et la persistance au-delà de ce délai impose une exploration.', 64, 66) +
 F('Éléments qui soutiennent ou réfutent l’hypothèse',
   TAB(['Soutient l’hypothèse réactionnelle', 'Réfute l’hypothèse et impose un bilan'], [
    ['Foyer récent dans le territoire', 'Aucun foyer retrouvé'],
    ['Ganglion < 2 cm, souple, mobile, sensible', 'Ganglion > 2 cm, dur, fixé, indolore'],
    ['Âge < 40 ans', 'Âge ≥ 40 ans'],
    ['Siège cervical antérieur ou inguinal', 'Siège sus-claviculaire'],
    ['Régression en 2–4 semaines', 'Persistance > 4 semaines ou croissance'],
    ['Pas de signes généraux', 'Fièvre, sueurs, perte de poids'],
   ], 'Aucun élément isolé ne pose ni n’exclut le diagnostic.') + P('Un antibiotique « d’épreuve » n’établit pas le diagnostic : la régression peut être spontanée, et un lymphome peut fluctuer.', 64, 66))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Régression clinique à 2–4 semaines', 'Référence pratique de l’hypothèse réactionnelle', 'Aucune sensibilité ni spécificité publiées', 'Exige un suivi organisé'],
    ['Biopsie-exérèse ganglionnaire (histologie)', 'Gold standard du diagnostic étiologique', 'Référence (architecture, immunohistochimie, cultures)', 'Geste chirurgical'],
    ['Cytoponction à l’aiguille fine', 'Cytologie : métastase de carcinome, tuberculose', 'Sensibilité insuffisante pour le lymphome (architecture absente)', 'Ne remplace pas l’exérèse si un lymphome est suspecté'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Aucun examen si foyer évident et ganglion non suspect', 'Surveillance de 3–4 semaines'],
    ['Première (bilan simple)', 'Hémogramme, CRP, sérologies orientées (EBV, CMV, toxoplasmose), test VIH', 'Adénopathie sans foyer ou généralisée'],
    ['Seconde', 'Échographie ganglionnaire', 'Persistance > 4 semaines, taille > 2 cm, doute clinique'],
    ['Seconde', 'Biopsie-exérèse', 'Échographie suspecte, persistance inexpliquée, drapeau rouge'],
    ['Seconde (extension)', 'Radiographie du thorax, scanner, TEP', 'Lymphome ou cancer suspecté'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['L’<b>échographie</b> ne demande aucune préparation ; elle se fait après la période de surveillance, ou d’emblée si un drapeau rouge est présent.',
       'Les <b>sérologies</b> se prélèvent au moment du tableau aigu, puis 2 à 3 semaines après si une séroconversion doit être prouvée.',
       'Avant toute <b>biopsie</b>, le médecin arrête si possible les anticoagulants selon le protocole local et évite les corticoïdes, qui peuvent masquer un lymphome.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil ou aspect normal', 'Signification', 'Conduite'], [
    ['Échographie : ganglion ovale, hile graisseux visible', 'Normal : petit axe < 1 cm, rapport long/court > 2', 'Aspect réactionnel', 'Surveillance'],
    ['Échographie : ganglion rond, hile effacé, nécrose', 'Rapport long/court < 2', 'Suspect de malignité ou de tuberculose', 'Biopsie'],
    ['Hémogramme : lymphocytose avec lymphocytes activés', '—', 'Infection virale (EBV, CMV)', 'Monotest, sérologies'],
    ['Résultat négatif (sérologies négatives)', '—', 'N’exclut pas une cause maligne', 'Poursuivre la surveillance ou biopsier'],
    ['Résultat limite (CRP modérément élevée)', '—', 'Inflammation non spécifique', 'Réévaluation clinique'],
    ['Résultat discordant (biologie normale mais ganglion qui grossit)', '—', 'La clinique prime', 'Biopsie-exérèse'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Échographie sans risque ; scanner seulement si indispensable ; sérologie toxoplasmose et CMV importante'],
    ['Enfant', 'Ganglions cervicaux palpables fréquents ; échographie de première intention, pas de scanner systématique'],
    ['DFGe < 30 mL/min/1,73 m²', 'Préférer l’échographie et l’IRM sans gadolinium au scanner injecté'],
    ['Allergie à l’iode (produit de contraste)', 'Échographie, IRM ; prémédication selon le protocole local si le scanner est indispensable'],
    ['Stimulateur cardiaque', 'IRM selon la compatibilité du dispositif ; échographie et scanner possibles'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Une adénopathie localisée avec un foyer évident et sans signe de malignité ne demande aucun examen. '
   'Une adénopathie sans foyer, généralisée ou persistante fait demander un hémogramme, une CRP, des sérologies orientées et un test VIH, puis une échographie. '
   'La biopsie-exérèse reste la référence lorsqu’un lymphome ou un cancer est suspecté.', 64, 66, 4) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une urgence vitale est présente, alors le patient est adressé immédiatement aux urgences. '
   'Si l’adénopathie est localisée avec un foyer et sans drapeau rouge, alors le médecin traite le foyer et fixe un contrôle à 3–4 semaines. '
   'Si elle persiste, grossit ou présente un drapeau rouge, alors il demande une échographie et adresse pour une biopsie.', 64, 66) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Stridor, dysphagie, sepsis', 'Urgences (144)', 'Selon l’hôpital'],
    ['Foyer évident, ganglion < 2 cm, souple, < 40 ans', 'Traitement du foyer, surveillance', 'Contrôle à 3–4 semaines'],
    ['Adénopathie généralisée', 'Hémogramme, CRP, test VIH, sérologies', 'Résultats en 1 semaine'],
    ['Sus-claviculaire, dur, fixé, > 2 cm ou symptômes B', 'Échographie et biopsie rapides', 'Avis spécialisé en 1–2 semaines'],
    ['Persistance > 4 semaines sans explication', 'Échographie puis biopsie-exérèse', 'Discussion des résultats'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Paracétamol, DAFALGAN® (antalgique et antipyrétique non opioïde ; inhibe la synthèse centrale des prostaglandines)', 'Adulte > 50 kg sans facteur de risque : 500–1000 mg par prise, toutes les 4–8 heures, maximum 4 g par jour ; clairance de la créatinine 10–50 mL/min : intervalle ≥ 6 h et 3 g par jour au maximum ; < 10 mL/min : intervalle ≥ 8 h et 2 g par jour ; métabolisme hépatique, élimination rénale, demi-vie d’environ 2 heures ; durée la plus courte possible', 'Hépatotoxicité en surdosage ; prudence en cas d’alcoolisme chronique, de malnutrition, de déshydratation ou d’insuffisance hépatique ; contre-indiqué en cas d’insuffisance hépatique sévère ; la forme effervescente 500 mg contient 197 mg de sodium par comprimé ; interaction : effet des antivitamines K augmenté à forte dose prolongée'],
   ['Ibuprofène (anti-inflammatoire non stéroïdien, inhibiteur des cyclo-oxygénases)', '200–400 mg par prise, 3 fois par jour au maximum en automédication, avec un repas ; quelques jours', 'Ulcère, insuffisance rénale, aggravation de l’asthme ; contre-indiqué au 3e trimestre de la grossesse et en cas d’ulcère évolutif ; interactions avec les anticoagulants, les IEC et les diurétiques'],
   ['Corticoïdes (glucocorticoïdes)', 'Non indiqués', 'Ils peuvent faire régresser un lymphome et retarder son diagnostic ; à éviter avant la biopsie'],
   ['Antibiotiques', 'Non indiqués sans infection bactérienne prouvée ou probable', 'Le test antibiotique n’est pas un outil diagnostique'],
  ]) + P('Les doses du paracétamol sont celles de l’AIPS de DAFALGAN® ; celles de l’ibuprofène sont à vérifier dans l’AIPS du produit utilisé.', 10, 82))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est de traiter le foyer, de soulager la douleur et de ne pas retarder un diagnostic de lymphome ou de cancer, parce que l’adénopathie réactionnelle guérit seule. '
   'La prise en charge est ambulatoire, avec un contrôle daté et des consignes de retour écrites. '
   'Les antibiotiques et les corticoïdes ne sont pas des traitements du ganglion.', 64, 66, 10) +
 F('11.A Buts : sans urgence dans la forme non compliquée',
   P('La forme non compliquée n’est pas une urgence ; le but chiffré est une régression ou une stabilité à 3–4 semaines et une douleur ≤ 3/10. Une forme compliquée (compression des voies aériennes, sepsis) relève des urgences dans l’heure.', 64, 66), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Expliquer le mécanisme réactionnel et le délai de régression attendu.',
         'Traiter le foyer (soins de plaie, traitement d’une angine bactérienne si les critères sont réunis).',
         'Soulager la douleur par le paracétamol ; compresses tièdes si le ganglion est sensible.',
         'Mesurer et noter la taille initiale au millimètre.',
         'Fixer un contrôle à 3–4 semaines et donner les motifs de retour immédiat.']), 64, 66) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal (art. 25) prend en charge la consultation, l’échographie et la biopsie indiquées ; la LAA n’intervient que si la plaie d’origine est un accident.',
         'Un arrêt de travail n’est en général pas nécessaire, sauf fièvre ou foyer invalidant (quelques jours).',
         'La conduite automobile n’est pas limitée par l’adénopathie elle-même ; la LAI ne concerne pas cette situation bénigne.']), 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Paracétamol à dose minimale efficace ; AINS contre-indiqués au 3e trimestre ; sérologies toxoplasmose et CMV si le contexte l’évoque.'],
      ['Personne âgée', 'Le risque de malignité est plus élevé : seuil d’exploration plus bas.'],
      ['Enfant', 'Les ganglions cervicaux sont souvent palpables ; paracétamol selon le poids (AIPS pédiatrique).'],
      ['Insuffisance hépatique', 'Paracétamol à dose réduite, contre-indiqué si l’atteinte est sévère.'],
      ['Insuffisance rénale (DFGe)', 'Adapter le paracétamol à la clairance ; éviter les AINS.'],
      ['Immunodépression', 'Seuil d’exploration bas : infections opportunistes, lymphome.'],
     ]), 10, 64), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Taille du ganglion (règle ou échographie)', 'À 3–4 semaines', 'Persistance ou croissance : arrêt de la surveillance, bilan'],
    ['Signes généraux', 'À chaque contact', 'Apparition : bilan rapide'],
    ['Foyer d’origine', 'À 1–2 semaines', 'Non guéri : réévaluer'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Régression ou disparition du ganglion au contrôle.', 'Absence de signes généraux.', 'Patient informé des motifs de retour (croissance, fièvre, sueurs, perte de poids).']), 64, 66) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La guérison est la règle quand le foyer disparaît ; une persistance inexpliquée doit être considérée comme un diagnostic non posé. La recherche 2026 évalue l’élastographie et des scores échographiques pour mieux choisir les ganglions à biopsier.', 64, 66), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire vise les causes : vaccinations du plan suisse, hygiène des plaies, protection contre les griffures et les rapports à risque. '
   'La prévention secondaire repose sur le contrôle daté, qui détecte tôt un lymphome ou un cancer. '
   'La prévention tertiaire évite les biopsies inutiles et les antibiotiques sans indication.', 35, 64) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Plan de vaccination suisse, soins des plaies, préservatif, PrEP selon l’OFSP'],
    ['Secondaire', 'Contrôle à 3–4 semaines, biopsie si persistance ; dépistage du VIH selon la directive OFSP'],
    ['Tertiaire', 'Bon usage des antibiotiques, information du patient'],
   ]), 4, 35)))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin recherche d’abord le foyer dans le territoire de drainage. '
   'Il surveille 3 à 4 semaines une adénopathie localisée, souple, < 2 cm, chez un patient de moins de 40 ans. '
   'Il explore sans attendre un ganglion sus-claviculaire, dur, fixé, > 2 cm ou associé à des symptômes B. '
   'Il ne prescrit ni antibiotique d’épreuve ni corticoïde. '
   'Il demande une biopsie-exérèse, et non une simple cytoponction, si un lymphome est suspecté.', 64, 66)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Un ganglion douloureux est forcément bénin.', 'Faux : une hémorragie dans un ganglion tumoral peut être douloureuse.'],
  ['Un antibiotique d’épreuve permet de trancher.', 'Faux : la régression peut être spontanée ; la persistance impose un bilan.'],
  ['Prescrire des corticoïdes pour faire dégonfler le ganglion.', 'Erreur : ils peuvent masquer un lymphome.'],
  ['Une cytoponction négative exclut un lymphome.', 'Faux : il faut une biopsie-exérèse (architecture).'],
  ['Un ganglion sus-claviculaire de 1 cm peut être surveillé.', 'Faux : ce siège est à haut risque de malignité (34–50 %).'],
  ['Un ganglion inguinal de 1,2 cm est pathologique.', 'Pas forcément : jusqu’à 1,5 cm, il est souvent normal.'],
 ]) + P('Ces pièges reprennent les revues de Ferrer 1998 et de Gaddey 2016.', 64, 66)))
CTX = {'_prefixe': 'Devant une adénopathie réactionnelle',
 'echogg': 'Un ganglion ovale à hile graisseux conservé soutient l’hypothèse réactionnelle ; un ganglion rond sans hile impose une biopsie.',
 'echo': 'L’échographie mesure le ganglion et décrit son hile ; elle se demande si le ganglion persiste plus de 4 semaines.',
 'biopsie': 'La biopsie-exérèse d’un ganglion réactionnel montre une hyperplasie folliculaire ou paracorticale sans cellule tumorale.',
 'nfs': 'Une lymphocytose avec lymphocytes activés oriente vers un virus ; une cytopénie ou des blastes vers une hémopathie.',
 'crp': 'Une CRP élevée oriente vers une cause bactérienne ; une CRP normale n’exclut pas un lymphome.',
 'sero': 'Les sérologies EBV, CMV et toxoplasmose cherchent une cause virale ou parasitaire d’adénopathies.',
 'vih': 'Le test VIH de 4e génération se demande devant toute adénopathie généralisée ou exposition.',
 'igra': 'Un IGRA positif soutient une tuberculose ganglionnaire sans la prouver ; la culture du ganglion est nécessaire.',
 'tdm': 'Le scanner cervico-thoraco-abdominal recherche d’autres adénopathies profondes si une cause maligne est suspectée.',
 'tep': 'La TEP-TDM sert au bilan d’extension d’un lymphome prouvé, pas au diagnostic d’une adénopathie réactionnelle.',
 'radio': 'La radiographie du thorax recherche des adénopathies médiastinales ou une tuberculose.',
 'irm': 'L’IRM est une alternative au scanner pendant la grossesse ou si le DFGe est bas.',
 'cyto': 'La cytométrie en flux recherche une population lymphocytaire clonale si un lymphome est suspecté.',
 'creat': 'Le DFGe guide la dose du paracétamol et l’injection de produit de contraste.',
 'monotest': 'Un Monotest positif explique des adénopathies cervicales chez l’adolescent.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
