#!/usr/bin/env python3
"""sources_orig_lot2.py SORTIE.py FICHIER.html... — variante LOT 2 de outils/sources_orig.py : les sources y sont des <p id="Sn">."""
import sys, re, html
from bs4 import BeautifulSoup
out = {}
for f in sys.argv[2:]:
    soup = BeautifulSoup(open(f, encoding='utf-8').read(), 'html.parser')
    for p in soup.select('#sources p[id^=S]'):
        n = int(p['id'][1:])
        st = p.find('strong'); lab = re.sub(r'^\[S\d+\]\s*', '', st.get_text(' ', strip=True)) if st else ''
        a = p.find('a'); href = a.get('href') if a else None
        txt = p.get_text('\n', strip=True).split('\n')
        ver = next((re.sub(r'^La version consultée est\s*:\s*', '', t).replace(' La consultation date du 23 octobre 2026.', '').strip(' .') for t in txt if t.startswith('La version')), '')
        lien = f'<a href="{html.escape(href, quote=True)}">{html.escape(lab)}</a>' if href else html.escape(lab)
        s = lien + (f'. Version : {html.escape(ver)}' if ver else '') + '. Document consulté le 23 octobre 2026.'
        out.setdefault(n, s)
with open(sys.argv[1], 'w', encoding='utf-8') as w:
    w.write('# -*- coding: utf-8 -*-\n# Sources extraites des originaux LOT 2 (outils_local/sources_orig_lot2.py).\nSOURCES_ORIG = {\n')
    for n in sorted(out): w.write(f' {n}: {out[n]!r},\n')
    w.write('}\n')
print(len(out), 'sources →', sys.argv[1])
