# -*- coding: utf-8 -*-
"""Générateur de l'Appel A AUDITÉ (SSP « Tuméfaction, masse et adénopathie », plan en 14 points + Bloc 2) — LOT 2."""
import os, shutil
from lot2_commun import *
POINT = mkPOINT('ssp')
M = dict(LOT, pref='ssp', dx='SSP', court='Tuméfaction, masse et adénopathie', long='Tuméfaction, masse et adénopathie (Appel A : plan et liste)',
         fichier='LOT_002_AppelA_SSP_Tumefaction_masse_adenopathie_AUDITÉ.html',
         sous_titre='PROFILES 2023 · SSP G2 · LOT 2 · Appel A · V7 · Plan et liste · version AUDITÉE',
         statut='Cette version corrige l’Appel A du LOT 2 (situation de départ, plan en 14 points et Bloc 2 des dix hypothèses ; révision AUDIT_CORRIGE r2) après audit médical et linguistique selon la charte du 24 octobre 2026. Les chiffres de malignité viennent de séries de médecine de premier recours ; ils restent à vérifier par un médecin.')
ADP = T('adénopathie', 'Une adénopathie est un ganglion lymphatique augmenté de volume : en général > 1 cm, > 1,5 cm à l’aine, > 0,5 cm au coude.')
TUM = T('tuméfaction', 'Une tuméfaction est une augmentation de volume localisée, perçue par le patient ou le médecin, quelle qu’en soit la cause.')
SB = T('signes B', 'Les signes B sont une fièvre > 38 °C inexpliquée, des sueurs nocturnes profuses et une perte de > 10 % du poids en 6 mois ; ils évoquent un lymphome.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Une {TUM} est une masse palpable ; le médecin précise d’abord si elle est ganglionnaire ou non. '
   f'Une {ADP} est localisée (un seul territoire) ou généralisée (au moins deux territoires non contigus). '
   'Une masse non ganglionnaire peut venir de la peau, de la graisse, du muscle ou de la thyroïde.', 64, 66, 32) +
 F('Terminologie et seuils',
   TAB(['Terme', 'Définition', 'Seuil ou repère'], [
    ['Adénopathie cervicale ou axillaire', 'Ganglion augmenté', '> 1 cm'],
    ['Adénopathie inguinale', 'Ganglion augmenté', '> 1,5 cm'],
    ['Adénopathie épitrochléenne', 'Ganglion augmenté', '> 0,5 cm'],
    ['Adénopathie sus-claviculaire', 'Toujours anormale', 'Toute taille'],
    ['Masse des tissus mous', 'Masse non ganglionnaire', '> 5 cm ou profonde : drapeau rouge'],
    ['Nodule thyroïdien', 'Masse cervicale antérieure mobile à la déglutition', 'Seuils EU-TIRADS'],
   ]) + P('L’adénopathie se distingue des masses voisines non ganglionnaires (lipome, kyste, nodule thyroïdien, glande salivaire) par son siège sur une aire ganglionnaire.', 64) + P('Ces seuils sont ceux de Ferrer et de Gaddey ; ceux des tissus mous et de la thyroïde viennent de l’ESSR 2023 et de l’ETA 2023.', 64, 66, 44, 48))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('Aucune incidence suisse des adénopathies n’est publiée. '
   'En médecine de premier recours aux Pays-Bas, une cause maligne est trouvée chez environ 1,1 pour 100 patients consultant pour une adénopathie inexpliquée ; ce taux atteint environ 4 % après 40 ans. '
   'En Suisse, les lymphomes non hodgkiniens touchent environ 1700 personnes par an, le sarcome des tissus mous environ 340, le cancer de la thyroïde environ 850.', 65, 64, 60) +
 F('Chiffres comparés',
   TAB(['Donnée', 'Valeur', 'Source'], [
    ['Malignité, adénopathie inexpliquée en premier recours', '≈ 1,1 %', 'Fijten 1988 (Pays-Bas, Europe)'],
    ['Malignité après 40 ans', '≈ 4 %', 'Fijten, Ferrer'],
    ['Malignité d’une adénopathie sus-claviculaire', '34–50 %', 'Ferrer 1998'],
    ['Lymphomes non hodgkiniens en Suisse', '≈ 1700 par an (≈ 19 / 100 000)', 'NKRS 2018–2022'],
    ['Sarcomes des tissus mous en Suisse', '≈ 340 par an (≈ 4 / 100 000)', 'NKRS 2018–2022'],
    ['Cancers de la thyroïde en Suisse', '≈ 850 par an (≈ 9 / 100 000)', 'NKRS 2018–2022'],
   ]) + P('Le terrain compte : l’âge > 40 ans, le tabac et l’immunodépression augmentent le risque de cause maligne ; le pronostic dépend de la cause.', 64, 65) + P('Les pourcentages sont des proportions parmi les patients consultants ; les taux « / 100 000 » sont des incidences annuelles, d’une autre unité.', 65, 60))))
PTS.append(POINT(3, 'Physiopathologie',
 P('La lymphe d’un territoire draine vers un groupe ganglionnaire précis. '
   'Un ganglion grossit quand ses lymphocytes prolifèrent (infection, inflammation), quand il est envahi (lymphome, métastase) ou infiltré. '
   'Une masse non ganglionnaire naît du tissu local : graisse, conjonctif, thyroïde.', 64, 66) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Chaque groupe ganglionnaire draine un territoire : cervical (tête et cou), axillaire (membre supérieur, sein), inguinal (membre inférieur, périnée), sus-claviculaire (thorax, abdomen).'],
    ['Physiologie', 'Le ganglion filtre la lymphe et présente les antigènes aux lymphocytes.'],
    ['Physiopathologie', 'Réaction, infection, prolifération maligne ou métastase augmentent son volume.'],
    ['Clinique', 'D’où le siège, la taille, la consistance et l’évolution, qui orientent la cause.'],
    ['Examens', 'La formule sanguine, les sérologies et l’échographie trient ; la biopsie tranche.'],
    ['Traitement', 'On traite la cause ; on ne donne ni corticoïde ni antibiotique à l’aveugle.'],
   ]), 64, 66) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Réaction à une infection locale', 'Examen du territoire drainé', 'Traiter la porte d’entrée'],
    ['Infection ganglionnaire', 'Échographie, ponction', 'Antibiotique, drainage'],
    ['Infection systémique (EBV, VIH, tuberculose)', 'Sérologies, IGRA', 'Traitement spécifique'],
    ['Lymphome', 'Biopsie-exérèse', 'Chimiothérapie'],
    ['Métastase', 'Cytoponction, recherche du primitif', 'Traitement oncologique'],
   ]) + P('Cette chaîne explique pourquoi le territoire drainé est examiné en entier.', 64))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin cherche d’abord une urgence : compression des voies aériennes, sepsis, syndrome cave supérieur. '
   'Il distingue ensuite masse ganglionnaire et non ganglionnaire, puis adénopathie localisée et généralisée. '
   'Puis il pèse l’âge, le siège, la durée et les signes généraux.', 64, 66, 32) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    DDXROW('react', 'Infection récente, ganglion < 2 cm', 'Réévaluation à 3–4 semaines'),
    DDXROW('mel', 'Lésion cutanée du territoire', 'Examen cutané, biopsie'),
    DDXROW('vih', 'Adénopathies généralisées, exposition', 'Test VIH'),
    DDXROW('tb', 'Ganglion cervical froid, migrant', 'IGRA, ponction'),
    DDXROW('nhl', 'Ganglion ferme, signes B', 'Biopsie-exérèse'),
    DDXROW('hl', 'Adulte jeune, médiastin', 'Biopsie-exérèse'),
    DDXROW('orl', 'Fumeur, ≥ 45 ans', 'Examen ORL, cytoponction'),
    DDXROW('sarc', 'Masse > 5 cm, profonde', 'IRM'),
    DDXROW('thy', 'Masse mobile à la déglutition', 'TSH, échographie'),
   ]) + P('Toutes les lignes sont des incidences suisses annuelles « / 100 000 » ou des données nationales, dans la même unité quand elle est donnée.', 60, 61, 62))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien date la masse, précise son évolution et cherche une infection, une exposition et des signes généraux.') +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Depuis quand ?', '> 4 semaines : suspect.', 'Bilan'],
    ['Avez-vous eu une infection récente ?', 'Adénopathie réactionnelle.', 'Surveillance'],
    ['Avez-vous fièvre, sueurs, perte de poids ?', 'Signes B.', 'Biopsie rapide'],
    ['Avez-vous eu un rapport à risque, un voyage, un contact tuberculeux ?', 'VIH, tuberculose.', 'Test VIH, IGRA'],
    ['Fumez-vous, buvez-vous ?', 'Cancer ORL.', 'Examen ORL'],
    ['Avez-vous un chat ?', 'Griffes du chat.', 'Sérologie Bartonella'],
   ])) +
 U(f'<b>Drapeaux rouges</b> : adénopathie sus-claviculaire, > 2 cm, dure, fixée, évoluant depuis > 4 semaines, {SB}, âge > 40 ans ; masse > 5 cm ou profonde ; stridor ou dysphagie. Le médecin adresse alors rapidement (biopsie, centre), et en urgence en cas de stridor.', 64, 66, 37, 2)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin examine toutes les aires ganglionnaires, la rate et le foie. '
   'Pour chaque masse, il note le siège, la taille, la consistance, la mobilité et la sensibilité, puis examine le territoire drainé. '
   'L’examen ne suffit pas à exclure une cause maligne.', 64, 66) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal', 'Anomalie et signification'], [
    ['Palpation des aires', 'Ganglions < 1 cm, souples', '> 1 cm : adénopathie'],
    ['Consistance', 'Souple', 'Dure : métastase ; élastique : lymphome'],
    ['Mobilité', 'Mobile', 'Fixée : envahissement'],
    ['Sensibilité', 'Indolore', 'Douloureuse : inflammation'],
    ['Rate', 'Non palpable', 'Splénomégalie : EBV, lymphome'],
    ['Territoire drainé', 'Normal', 'Plaie, tumeur cutanée, ORL'],
   ]) + P('Le ganglion sus-claviculaire gauche (Troisier) évoque un cancer abdominal.', 64))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les principaux syndromes sont le syndrome mononucléosique, le syndrome tumoral et le syndrome inflammatoire. '
   'Les signes fonctionnels sont la douleur, la fièvre et les signes B. '
   'Les signes physiques sont la masse, la splénomégalie et l’hépatomégalie.', 64, 90) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    ['Syndrome mononucléosique', 'Angine, adénopathies, lymphocytes activés', 'Réponse T à l’EBV'],
    [SB, 'Fièvre, sueurs, amaigrissement', 'Cytokines tumorales'],
    ['Fluctuation', 'Masse molle à onde liquidienne', 'Abcès'],
    ['Fistulisation', 'Écoulement chronique', 'Tuberculose, actinomycose'],
   ]) + P('Ces syndromes orientent la première prescription.', 90))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Il n’existe pas de critère unique ; la recommandation NICE NG12 (2025) adresse rapidement une adénopathie inexpliquée persistante et une masse cervicale inexpliquée chez une personne de 45 ans et plus. '
   'Le critère de taille est > 1 cm en général, et toute adénopathie sus-claviculaire. '
   'L’imagerie ne suffit pas : le diagnostic d’un lymphome demande une biopsie-exérèse.', 37, 64, 72) +
 F('Éléments qui confirment ou réfutent',
   TAB(['Confirme une cause bénigne', 'Fait chercher une cause maligne'], [
    ['Cause infectieuse évidente', 'Aucune cause, > 4 semaines'],
    ['Ganglion < 2 cm, souple, mobile', 'Ganglion > 2 cm, dur, fixé'],
    ['Régression à 3–4 semaines', 'Croissance'],
    ['Âge < 40 ans', 'Âge > 40 ans, tabac'],
   ]) + P('Ces critères viennent de Ferrer, de Gaddey et du NICE.', 64, 66, 37))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Biopsie-exérèse ganglionnaire', 'Diagnostic histologique', 'Gold standard du lymphome', 'Geste chirurgical'],
    ['Cytoponction échoguidée', 'Métastase, infection', 'Bonne sensibilité et spécificité pour une métastase de carcinome', 'Insuffisante pour classer un lymphome'],
    ['Échographie ganglionnaire', 'Forme, hile, vascularisation', 'Triage', 'Opérateur-dépendante'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Formule sanguine, CRP', 'Adénopathie > 4 semaines ou signes généraux'],
    ['Première', 'Test VIH, sérologie EBV', 'Selon le contexte'],
    ['Première', 'Échographie', 'Masse ou ganglion douteux'],
    ['Seconde', 'Biopsie-exérèse ou cytoponction', 'Ganglion suspect'],
    ['Seconde', 'IRM', 'Masse des tissus mous à drapeau rouge'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La <b>formule sanguine</b> est indiquée d’emblée devant des signes généraux.', 'Le <b>test VIH</b> se fait avec accord, en tenant compte du délai après exposition.', 'La <b>biopsie</b> demande un arrêt planifié des anticoagulants et précède tout corticoïde.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Échographie normale : ganglion ovale à hile graisseux', 'Petit axe < 10 mm', 'Rassurant', 'Surveillance'],
    ['Lymphocytes activés', '≥ 10 %', 'Syndrome mononucléosique', 'Sérologie EBV'],
    ['Résultat positif : test VIH', '—', 'Infection VIH', 'Confirmation, centre'],
    ['Résultat négatif : bilan normal', '—', 'Réactionnel probable', 'Réévaluation à 3–4 semaines'],
    ['Résultat limite : cytoponction non diagnostique', '—', 'Incertitude', 'Biopsie-exérèse'],
    ['Résultat discordant : bilan rassurant, ganglion croissant', '—', 'Revoir', 'Biopsie'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Échographie ; IRM sans gadolinium ; pas de scanner sans indication forte'],
    ['Enfant', 'Adénopathies réactionnelles très fréquentes ; seuil de biopsie différent'],
    ['DFGe < 30 mL/min/1,73 m²', 'Pas de produit de contraste sans avis'],
    ['Allergie à l’iode', 'IRM ou échographie'],
    ['Stimulateur cardiaque', 'Échographie ; IRM selon la compatibilité'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Une adénopathie réactionnelle évidente ne demande aucun examen. '
   'Devant une adénopathie persistante, la formule sanguine, la CRP, les sérologies ciblées et l’échographie viennent en premier. '
   'La biopsie-exérèse est la référence pour un lymphome.', 64, 66, 72) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une cause locale explique la masse, alors le médecin traite la cause et revoit le patient à 3–4 semaines. '
   'Si la masse persiste ou porte un drapeau rouge, alors il demande la formule sanguine, les sérologies et l’échographie. '
   'Si le bilan reste inexpliqué, alors il adresse pour biopsie.', 64, 66, 32) +
 F('Embranchements',
   TAB(['Si…', 'Alors…', 'Contrôle'], [
    ['Cause infectieuse évidente', 'Traitement, réévaluation', '3–4 semaines'],
    ['Adénopathie généralisée', 'Formule sanguine, VIH, EBV', 'Selon résultat'],
    ['Sus-claviculaire, > 2 cm, signes B', 'Biopsie rapide', 'Histologie'],
    ['Masse > 5 cm ou profonde', 'IRM, centre sarcome', 'Avant biopsie'],
    ['Masse thyroïdienne', 'TSH, échographie', 'EU-TIRADS'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Paracétamol, DAFALGAN® (antalgique, inhibe la synthèse centrale des prostaglandines)', '500–1000 mg toutes les 4–8 heures, maximum 4 g par jour ; demi-vie ≈ 2 heures ; élimination hépatique ; quelques jours', 'Hépatotoxicité en surdosage ; contre-indiqué en insuffisance hépatique sévère ; interaction avec les antivitamines K'],
   ['Amoxicilline et acide clavulanique, CO-AMOXI® (bêtalactamine avec inhibiteur de bêtalactamase, bloque la paroi bactérienne)', '625 mg 3 fois par jour ou 1 g 2 fois par jour, 7–10 jours ; demi-vie ≈ 1 heure ; élimination rénale', 'Diarrhée, éruption, hépatite ; contre-indiquée en allergie aux pénicillines ; interaction avec le méthotrexate'],
   ['Corticoïdes', 'À éviter avant le diagnostic', 'Ils peuvent masquer un lymphome et fausser la biopsie'],
  ]) + P('Le traitement dépend de la cause ; les doses figurent dans le cours de chaque diagnostic.', 10, 82, 11))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est d’identifier la cause sans retarder un cancer ni multiplier les examens. '
   'Le médecin traite la cause identifiée et surveille une adénopathie réactionnelle. '
   'Il évite les corticoïdes et les antibiotiques à l’aveugle.', 64, 66) +
 F('11.A Buts : urgence ou non',
   P('Une forme compliquée (stridor, sepsis, compression) est une urgence à évaluer dans l’heure. La forme non compliquée se prend en charge en ambulatoire avec des mesures générales. Le but chiffré est une réévaluation à 3–4 semaines et une biopsie avant 2 semaines en cas de drapeau rouge (délai d’audit, à vérifier).', 64, 37), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Rechercher une urgence.', 'Examiner toutes les aires et le territoire drainé.', 'Traiter une cause évidente.', 'Prescrire le bilan de première intention si la masse persiste.', 'Adresser pour biopsie ou au centre spécialisé.']), 64, 66) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal prend en charge le bilan.', 'Un arrêt de travail dépend de la cause.', 'La LAA intervient si la cause est professionnelle (tuberculose d’un soignant) ; la LAI selon les séquelles ; la conduite automobile n’est pas limitée par une adénopathie seule.']), 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Échographie ; biopsie possible.'],
      ['Personne âgée', 'Seuil de biopsie bas.'],
      ['Enfant', 'Adénopathies réactionnelles fréquentes.'],
      ['Insuffisance hépatique', 'Paracétamol réduit.'],
      ['Insuffisance rénale (DFGe)', 'Antibiotiques adaptés.'],
      ['Immunodépression', 'Infections opportunistes, lymphome.'],
     ]), 82, 66), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Taille de l’adénopathie', 'À 3–4 semaines', 'Persistance ou croissance : bilan'],
    ['Signes généraux', 'À chaque visite', 'Signes B : biopsie'],
    ['Résultats', 'À réception', 'Anomalie : orientation'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Cause identifiée ou régression.', 'Drapeaux rouges absents.', 'Consignes de retour données.', 'Résultats communiqués.']), 64) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic dépend de la cause ; la plupart des adénopathies sont bénignes et régressent. La recherche 2026 évalue l’échographie de contraste et l’intelligence artificielle pour trier les ganglions.', 65), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur les vaccinations, le préservatif, l’arrêt du tabac et la vaccination contre le HPV. '
   'La prévention secondaire est le dépistage du VIH et la reconnaissance des drapeaux rouges. '
   'La prévention tertiaire organise le suivi des cancers.', 91, 4, 35) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Plan de vaccination suisse (HPV, hépatite B), préservatif, arrêt du tabac'],
    ['Secondaire', 'Dépistage du VIH selon l’OFSP ; biopsie rapide devant un drapeau rouge'],
    ['Tertiaire', 'Suivi spécialisé'],
   ]), 91, 4)))
PTS.append(POINT(13, 'Points clés',
 P('La plupart des adénopathies sont réactionnelles et régressent en 3–4 semaines. '
   'Le médecin examine toutes les aires, la rate et le territoire drainé. '
   'Une adénopathie sus-claviculaire, dure, > 2 cm ou avec signes B fait chercher un cancer. '
   'Une masse > 5 cm ou profonde demande une IRM avant toute biopsie. '
   'Le médecin ne donne pas de corticoïde avant le diagnostic.', 64, 66, 2)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Donner un corticoïde à une adénopathie inexpliquée.', 'Erreur : il masque un lymphome.'],
  ['Cytoponction pour classer un lymphome.', 'Faux : biopsie-exérèse.'],
  ['Oublier le test VIH.', 'Erreur : à proposer devant des adénopathies généralisées.'],
  ['Enlever une masse profonde de 8 cm au cabinet.', 'Erreur : IRM et centre sarcome.'],
  ['Une adénopathie sus-claviculaire se surveille.', 'Faux : bilan rapide.'],
 ]) + P('Ces pièges reprennent Ferrer, Gaddey, le NICE et le Swiss Sarcoma Network.', 64, 66, 37, 2)))
BLOC2 = ('<section class="point" id="ssp-p15"><h3><strong>Bloc 2 — Dix hypothèses diagnostiques</strong></h3>\n' +
 P('Les dix hypothèses ci-dessous forment l’Appel B ; chacune a son cours AUDITÉ. Le médecin les ordonne selon l’urgence, puis la fréquence.', 31) +
 TAB(['Hypothèse', 'Indice clé', 'Examen discriminant', 'Fichier'], [
  ['DX.1 · Adénopathie réactionnelle non spécifique', 'Infection récente, ganglion < 2 cm', 'Réévaluation à 3–4 semaines', 'LOT_002_DX1_…_AUDITÉ'],
  ['DX.2 · Lymphadénite bactérienne', 'Ganglion chaud, douloureux, fièvre', 'Échographie (abcès)', 'LOT_002_DX2_…_AUDITÉ'],
  ['DX.3 · Mononucléose infectieuse (EBV)', 'Angine, adénopathies postérieures', 'Monotest, sérologie EBV', 'LOT_002_DX3_…_AUDITÉ'],
  ['DX.4 · VIH révélé par adénopathies', 'Adénopathies généralisées, exposition', 'Test VIH de 4e génération', 'LOT_002_DX4_…_AUDITÉ'],
  ['DX.5 · Tuberculose ganglionnaire', 'Ganglion cervical froid, fistule', 'Ponction, PCR, culture', 'LOT_002_DX5_…_AUDITÉ'],
  ['DX.6 · Lymphome hodgkinien ou non hodgkinien', 'Ganglion ferme, signes B', 'Biopsie-exérèse', 'LOT_002_DX6_…_AUDITÉ'],
  ['DX.7 · Métastase ganglionnaire de carcinome', 'Ganglion dur, fumeur, ≥ 45 ans', 'Cytoponction, examen ORL', 'LOT_002_DX7_…_AUDITÉ'],
  ['DX.8 · Lipome superficiel', 'Masse molle, mobile, < 5 cm', 'Échographie', 'LOT_002_DX8_…_AUDITÉ'],
  ['DX.9 · Sarcome des tissus mous', 'Masse > 5 cm, profonde, croissante', 'IRM puis biopsie en centre', 'LOT_002_DX9_…_AUDITÉ'],
  ['DX.10 · Nodule ou masse thyroïdienne', 'Masse mobile à la déglutition', 'TSH, échographie EU-TIRADS', 'LOT_002_DX10_…_AUDITÉ'],
 ]) + P('Les fréquences de chaque hypothèse figurent au point 4 ci-dessus et dans chaque cours.', 60) + '</section>\n')
PTS.append(BLOC2)
CTX = {'_prefixe': 'Devant une tuméfaction ou une adénopathie',
 'nfs': 'La formule sanguine cherche des lymphocytes activés, une cytopénie ou une hyperleucocytose.',
 'crp': 'La CRP élevée oriente vers une infection bactérienne, sans exclure un lymphome.',
 'sero': 'Les sérologies ciblées (EBV, toxoplasmose, Bartonella) expliquent une adénopathie réactionnelle.',
 'vih': 'Le test VIH de 4e génération est proposé devant des adénopathies généralisées.',
 'echogg': 'L’échographie distingue un ganglion ovale à hile graisseux d’un ganglion rond suspect.',
 'biopsie': 'La biopsie-exérèse est la référence pour un lymphome.',
 'cyto': 'La cytoponction trouve une métastase de carcinome ou une infection.',
 'igra': 'L’IGRA soutient une tuberculose, sans la prouver.',
 'irm': 'L’IRM précède toute biopsie d’une masse des tissus mous à drapeau rouge.',
 'tsh': 'La TSH est le premier examen devant une masse thyroïdienne.',
 'ldh': 'Les LDH élevées soutiennent un lymphome.',
 'tep': 'La TEP-TDM stadifie un lymphome ou cherche un primitif.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
    # copie de scoring (classée « Appel A » par outils/decoupe.py) — fichier de travail, non livré
    d = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ssp_score'); os.makedirs(d, exist_ok=True)
    shutil.copy(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', M['fichier']), os.path.join(d, 'LOT_2_Appel_A_V7_Plan_et_Liste_AUDIT_CORRIGE_score.html'))
