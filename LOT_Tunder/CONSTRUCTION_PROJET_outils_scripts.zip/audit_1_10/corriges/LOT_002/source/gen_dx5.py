# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.5 · Tuberculose ganglionnaire (LOT 2, Partie 2)."""
from lot2_commun import *
POINT = mkPOINT('dx5')
M = META('dx5', 'DX.5', 'Tuberculose ganglionnaire', 'Tuberculose ganglionnaire', 'LOT_002_DX5_Tuberculose_ganglionnaire_AUDITÉ.html', 2,
         'Les doses antituberculeuses suivent l’OMS 2022 et le manuel suisse de la tuberculose ; elles restent à vérifier par un médecin.')
GRA = T('granulome épithélioïde', 'Le granulome épithélioïde est un amas organisé de macrophages transformés, entouré de lymphocytes ; il emprisonne les mycobactéries. Sa nécrose centrale « caséeuse » est typique de la tuberculose.')
FR = T('abcès froid', 'L’abcès froid est une collection de caséum sans chaleur ni rougeur marquée ; il peut se fistuliser à la peau (écrouelles, ou scrofule).')
PAR = T('réaction paradoxale', 'La réaction paradoxale est l’augmentation temporaire d’un ganglion sous traitement efficace, due à la restauration de la réponse immunitaire ; elle ne signe pas un échec.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('La tuberculose ganglionnaire est l’infection d’un ou de plusieurs ganglions par une bactérie du complexe Mycobacterium tuberculosis. '
   'C’est la forme extrapulmonaire la plus fréquente ; elle touche surtout les ganglions cervicaux. '
   f'Le ganglion forme un {GRA}, puis se ramollit en {FR}.', 9, 71) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Infection tuberculeuse latente', 'Bacilles quiescents, sans maladie, non contagieuse', 'Tuberculose-maladie'],
    ['Tuberculose-maladie', 'Infection active avec lésions', 'Réaction immunitaire isolée (IGRA positif)'],
    ['Scrofule', 'Tuberculose ganglionnaire cervicale fistulisée', 'Adénite à mycobactérie non tuberculeuse de l’enfant'],
    ['Tuberculose extrapulmonaire', 'Atteinte hors du poumon', 'Tuberculose pulmonaire, contagieuse'],
    ['Mycobactérie non tuberculeuse', 'Mycobactéries de l’environnement', 'Complexe M. tuberculosis'],
   ]) + P('Une tuberculose ganglionnaire isolée n’est pas contagieuse ; elle le devient si une atteinte pulmonaire coexiste.', 9))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('La Suisse a enregistré 432 cas de tuberculose en 2024, soit 4,8 pour 100 000 habitants, puis 544 cas en 2025, soit 6,0 pour 100 000. '
   'En 2024, 22 % des cas étaient purement extrapulmonaires, la forme ganglionnaire étant la plus fréquente d’entre elles. '
   'La moyenne européenne était de 8,4 pour 100 000 en 2024.', 62, 63) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Cas en Suisse 2024', '432 (4,8 / 100 000)', 'OFSP'],
    ['Cas en Suisse 2025', '544 (6,0 / 100 000)', 'OFSP, Bulletin 2026'],
    ['Formes purement extrapulmonaires', '22 % (2024)', 'Ligue pulmonaire suisse, rapport 2024'],
    ['Moyenne européenne', '8,4 / 100 000 (2024)', 'Région européenne'],
    ['Réaction paradoxale sous traitement', '≈ 20 % des formes ganglionnaires', 'Ordre de grandeur des séries ; à vérifier'],
   ]) + P('Les personnes nées dans un pays de forte incidence, les personnes vivant avec le VIH, les patients sous anti-TNF et les personnes en précarité sont les plus exposés. La guérison dépasse 90 % sous traitement complet.', 62, 9, 71))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Le bacille est inhalé, phagocyté par les macrophages alvéolaires, puis transporté par la lymphe jusqu’aux ganglions. '
   'Les lymphocytes T activent les macrophages, qui forment des granulomes pour contenir les bacilles. '
   'Quand ce contrôle échoue, le centre du granulome se nécrose en caséum, le ganglion grossit, se ramollit et peut se fistuliser.', 9, 71) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les ganglions cervicaux, sus-claviculaires et médiastinaux drainent le poumon et l’oropharynx.'],
    ['Physiologie', 'L’immunité cellulaire (lymphocytes T CD4, interféron gamma) contrôle normalement les mycobactéries.'],
    ['Physiopathologie', 'Une immunité déficiente laisse les bacilles se multiplier ; le granulome caséeux détruit le ganglion.'],
    ['Clinique', 'D’où un ganglion lentement croissant, peu douloureux, froid, puis fluctuant ou fistulisé, avec parfois fièvre et sueurs.'],
    ['Examens', 'Le prélèvement frais permet culture et PCR ; l’histologie montre le granulome ; l’IGRA ne fait que soutenir.'],
    ['Traitement', 'Les bacilles se divisent lentement et des mutants résistants existent, d’où quatre antibiotiques puis deux, pendant 6 mois.'],
   ]), 9, 71) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Bacilles en multiplication rapide', 'Culture, PCR', 'Isoniazide'],
    ['Bacilles semi-dormants', 'Culture', 'Rifampicine'],
    ['Bacilles intracellulaires en milieu acide', 'Histologie', 'Pyrazinamide'],
    ['Mutants résistants', 'PCR Xpert MTB/RIF, antibiogramme', 'Éthambutol en phase initiale'],
    ['Restauration immunitaire', 'Suivi clinique', 'Poursuite du traitement (réaction paradoxale)'],
   ]) + P('Cette chaîne explique pourquoi une monothérapie sélectionne des résistances et pourquoi le traitement dure longtemps.', 71))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin écarte d’abord une urgence (tuberculose pulmonaire contagieuse, compression trachéale), puis il évoque une tuberculose devant un ganglion cervical lentement croissant, peu inflammatoire, chez une personne exposée. '
   'Il cherche toujours une atteinte pulmonaire associée, car elle rend le patient contagieux. '
   'Il distingue la tuberculose du lymphome, de la métastase et des mycobactéries non tuberculeuses par la biopsie avec culture.', 9, 66) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    DDXROW('tb', 'Origine d’un pays de forte incidence, contact, ganglion froid', 'Culture, PCR, histologie'),
    DDXROW('nhl', 'Adénopathies multiples, symptômes B', 'Biopsie-exérèse'),
    DDXROW('hl', 'Adulte jeune, prurit, médiastin', 'Biopsie-exérèse'),
    DDXROW('orl', 'Fumeur, ganglion dur', 'Examen ORL, cytoponction'),
    ['Mycobactérie non tuberculeuse' + PR('incidence suisse non publiée', 84), 'Enfant de 1–5 ans, peau violacée, IGRA négatif', 'Culture'],
    ['Maladie des griffes du chat' + PR('incidence suisse non publiée', 86), 'Chat, adénopathie subaiguë', 'Sérologie Bartonella'],
    ['Sarcoïdose' + PR('incidence suisse non publiée', 66), 'Adénopathies médiastinales symétriques', 'Biopsie (granulome sans nécrose)'],
   ]) + P(UNITE, 60, 62))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien recherche le pays d’origine, les voyages, les contacts tuberculeux et les traitements immunosuppresseurs. '
   'Il recherche les symptômes généraux et respiratoires, ainsi que les médicaments, en raison des interactions de la rifampicine.', 9) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Où êtes-vous né, où avez-vous vécu ?', 'Incidence du pays d’origine.', 'Probabilité pré-test'],
    ['Avez-vous côtoyé une personne tuberculeuse ?', 'Contage.', 'Bilan rapide'],
    ['Toussez-vous depuis plus de 3 semaines ?', 'Atteinte pulmonaire contagieuse.', 'Masque, expectorations, isolement'],
    ['Avez-vous de la fièvre, des sueurs, perdu du poids ?', 'Maladie active.', 'Bilan d’extension'],
    ['Prenez-vous un traitement immunosuppresseur ?', 'Risque accru (anti-TNF).', 'Seuil bas de biopsie'],
    ['Prenez-vous une contraception orale ou d’autres médicaments ?', 'Interactions de la rifampicine.', 'Conciliation'],
   ])) +
 U('<b>Drapeaux rouges</b> : toux avec hémoptysie (contagiosité, masque et isolement), dyspnée, signes méningés, compression trachéale, ictère sous traitement (hépatite médicamenteuse : arrêt et avis immédiat), baisse de la vision sous éthambutol.', 9, 71)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin palpe toutes les aires ganglionnaires, puis examine la peau en regard, les poumons et le poids. '
   'Un ganglion tuberculeux est souvent cervical, unilatéral, ferme puis fluctuant, avec une peau violacée adhérente. '
   'Aucun signe clinique n’a une valeur suffisante pour poser le diagnostic sans prélèvement.', 9, 66) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal', 'Anomalie et signification'], [
    ['Palpation cervicale et sus-claviculaire', 'Ganglions < 1 cm', 'Masse ferme, peu douloureuse, parfois en chapelet'],
    ['Inspection cutanée', 'Peau normale', 'Peau violacée, fistule : abcès froid'],
    ['Auscultation pulmonaire', 'Murmure vésiculaire normal', 'Crépitants, souffle : atteinte pulmonaire'],
    ['Poids', 'Stable', 'Perte : maladie active'],
    ['Examen de la vision des couleurs (avant éthambutol)', 'Normale', 'Anomalie : choix d’un autre médicament'],
   ]) + P('La température est souvent normale dans la forme ganglionnaire isolée ; son absence n’exclut donc pas la maladie.', 66))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la masse, parfois la fièvre, les sueurs et l’amaigrissement. '
   'Les signes physiques sont la masse ferme, fluctuante ou fistulisée, et parfois des signes pulmonaires. '
   'Ils forment un syndrome ganglionnaire subaigu avec, inconstamment, un syndrome inflammatoire général.', 9) +
 F('Signes définis',
   TAB(['Signe', 'Description', 'Mécanisme'], [
    ['Adénopathie en chapelet', 'Plusieurs ganglions alignés le long du sterno-cléido-mastoïdien', 'Drainage lymphatique successif'],
    [FR, 'Masse fluctuante sans chaleur', 'Nécrose caséeuse'],
    ['Fistule', 'Écoulement chronique de caséum', 'Rupture à la peau'],
    ['Symptômes généraux', 'Fièvre vespérale, sueurs, perte de poids', 'Cytokines (TNF)'],
    [PAR, 'Ganglion qui grossit sous traitement', 'Restauration immunitaire'],
   ]), 9)))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Selon le manuel suisse de la tuberculose, le diagnostic certain repose sur l’identification du complexe M. tuberculosis par culture ou par amplification génique. '
   'Un granulome caséeux avec un contexte compatible permet un diagnostic probable et le début du traitement. '
   'Un IGRA positif ne suffit pas à prouver la tuberculose-maladie ; le test tuberculinique, positif à partir de 10 mm d’induration selon le critère de l’OMS 2022, a la même limite.', 9, 71) +
 F('Éléments qui confirment ou réfutent',
   TAB(['Confirme', 'Réfute ou fait revoir'], [
    ['Culture positive à M. tuberculosis', 'Culture positive à une mycobactérie non tuberculeuse'],
    ['PCR positive (Xpert MTB/RIF)', 'Histologie de lymphome ou de carcinome'],
    ['Granulome caséeux et contexte compatible (probable)', 'Granulome sans nécrose : sarcoïdose possible'],
    ['IGRA positif (soutien seulement)', 'IGRA négatif (n’exclut pas)'],
   ]) + P('L’antibiogramme est indispensable, car la résistance à la rifampicine modifie tout le traitement.', 9, 71))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Culture du ganglion (prélèvement frais)', 'Diagnostic certain et antibiogramme', 'Référence', 'Résultat en 2–6 semaines'],
    ['PCR (Xpert MTB/RIF)', 'Diagnostic rapide, résistance à la rifampicine', 'Spécificité élevée ; sensibilité plus faible que la culture sur le ganglion', 'Ne remplace pas la culture'],
    ['Histologie', 'Granulome caséeux', 'Très évocateur', 'Pas spécifique de l’espèce'],
    ['IGRA', 'Réponse immunitaire', 'Ne distingue pas infection latente et maladie', 'Négatif possible si immunodépression'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Échographie ganglionnaire', 'Masse cervicale subaiguë'],
    ['Première', 'Cytoponction ou biopsie au trocart avec culture et PCR', 'Ganglion accessible'],
    ['Première', 'Radiographie du thorax', 'Toujours, pour rechercher une atteinte pulmonaire'],
    ['Première', 'Test VIH', 'Toute tuberculose'],
    ['Seconde', 'Biopsie-exérèse', 'Prélèvement non contributif'],
    ['Seconde', 'Expectorations (3 échantillons)', 'Toux ou radiographie anormale'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Une partie du <b>prélèvement</b> part fraîche, sans formol, en microbiologie ; une autre part en histologie.', 'Les <b>expectorations</b> se recueillent le matin, 3 jours de suite.', 'Avant l’éthambutol, la vision et la fonction rénale sont contrôlées ; avant le traitement, les transaminases.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['ALAT sous traitement', 'Normal < 45 U/L', '> 3 fois la normale avec symptômes ou > 5 fois sans symptômes : hépatite médicamenteuse', 'Arrêt et avis spécialisé'],
    ['Résultat positif : culture ou PCR positive', '—', 'Tuberculose certaine', 'Traitement, déclaration'],
    ['Résultat négatif : culture négative', '—', 'N’exclut pas la maladie', 'Traitement si histologie et contexte compatibles'],
    ['Résultat limite : IGRA indéterminé', '—', 'Immunodépression, erreur technique', 'Répéter ou ignorer'],
    ['Résultat discordant : PCR positive, culture négative', '—', 'Faible charge, bacilles morts', 'Avis spécialisé'],
    ['Résistance à la rifampicine', '—', 'Tuberculose multirésistante possible', 'Centre de référence'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Radiographie du thorax avec protection ; traitement standard sans retard'],
    ['Enfant', 'Les mycobactéries non tuberculeuses sont fréquentes avant 5 ans : culture indispensable'],
    ['DFGe < 30 mL/min/1,73 m²', 'Pyrazinamide et éthambutol 3 fois par semaine selon l’OMS'],
    ['Allergie à l’iode', 'Échographie, IRM'],
    ['Stimulateur cardiaque', 'Échographie et scanner ; IRM selon la compatibilité'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le diagnostic repose sur un prélèvement du ganglion envoyé frais en microbiologie et en histologie. '
   'La radiographie du thorax et le test VIH sont systématiques. '
   'L’IGRA soutient le diagnostic, sans le prouver ni l’exclure.', 9, 71, 4) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si le patient tousse ou si la radiographie est anormale, alors il porte un masque et le médecin recherche une tuberculose pulmonaire. '
   'Si la culture, la PCR ou l’histologie sont compatibles, alors un traitement de 6 mois est commencé et la maladie est déclarée. '
   'Si une résistance à la rifampicine est détectée, alors le patient est adressé à un centre de référence.', 9, 71) +
 F('Embranchements',
   TAB(['Si…', 'Alors…', 'Contrôle'], [
    ['Toux, radiographie anormale', 'Masque, expectorations, isolement si positif', 'Résultats en 48 heures'],
    ['Ganglion isolé, prélèvement compatible', '2HRZE puis 4HR', 'Visite toutes les 2 semaines en phase initiale'],
    ['Résistance à la rifampicine', 'Centre de référence', 'Schéma adapté'],
    ['Ganglion qui grossit sous traitement', 'Penser à une réaction paradoxale ; vérifier l’observance et la sensibilité', 'Ponction si fluctuation'],
    ['Hépatite médicamenteuse', 'Arrêt, réintroduction séquentielle', 'Transaminases'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Isoniazide (H), antituberculeux bactéricide', '5 mg/kg par jour, maximum 300 mg, 6 mois ; avec pyridoxine (vitamine B6) en cas de risque de neuropathie ; métabolisme hépatique par acétylation', 'Hépatite, neuropathie périphérique ; interaction avec la phénytoïne'],
   ['Rifampicine (R), antituberculeux bactéricide', '10 mg/kg par jour, maximum 600 mg, à jeun, 6 mois', 'Hépatite, coloration orange des urines et des larmes ; inducteur enzymatique puissant : contraception orale, anticoagulants, antirétroviraux, corticoïdes moins efficaces'],
   ['Pyrazinamide (Z)', '25 mg/kg par jour, 2 premiers mois', 'Hépatite, hyperuricémie, arthralgies ; contre-indiqué en cas de goutte sévère'],
   ['Éthambutol (E)', '15 mg/kg par jour, 2 premiers mois', 'Névrite optique (contrôle de la vision) ; adapter si DFGe bas'],
   ['Associations fixes : RIMSTAR® (HRZE), RIFINAH® (HR)', 'Nombre de comprimés selon le poids (AIPS)', 'Améliorent l’observance'],
  ]) + P('Le schéma 2HRZE + 4HR et les doses par kilo suivent l’OMS 2022 et le manuel suisse ; le médecin vérifie l’AIPS de chaque spécialité.', 71, 9, 82))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est de guérir la tuberculose, d’éviter les résistances et de prévenir la transmission. '
   'Le traitement standard dure 6 mois : 2 mois d’isoniazide, rifampicine, pyrazinamide et éthambutol, puis 4 mois d’isoniazide et rifampicine. '
   'La forme ganglionnaire isolée se traite en ambulatoire, sans isolement.', 71, 9) +
 F('11.A Buts : urgence ou non',
   P('La forme ganglionnaire isolée non compliquée n’est pas une urgence vitale ; le but chiffré est la prise de plus de 90 % des doses et un traitement complet de 6 mois. La tuberculose pulmonaire contagieuse impose l’isolement dans l’heure.', 9, 71), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Confirmer par culture ou PCR et obtenir l’antibiogramme.', 'Rechercher une atteinte pulmonaire et faire un test VIH.', 'Déclarer le cas à l’OFSP et au médecin cantonal.', 'Commencer 2HRZE puis 4HR.', 'Organiser l’enquête d’entourage si une atteinte pulmonaire existe.', 'Vérifier l’observance (traitement sous observation directe si besoin).']), 9, 71) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal prend en charge le traitement ; les cantons financent souvent l’enquête d’entourage.', 'L’arrêt de travail n’est nécessaire que pour une forme contagieuse ou un état général altéré ; la LAA intervient si la tuberculose est une maladie professionnelle (soignants).', 'La LAI n’intervient qu’en cas d’incapacité durable ; la conduite automobile n’est pas limitée.']), 9, 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Schéma standard avec pyridoxine ; traitement sans retard.'],
      ['Personne âgée', 'Hépatotoxicité plus fréquente : transaminases rapprochées.'],
      ['Enfant', 'Doses par kilo selon l’OMS ; centre pédiatrique.'],
      ['Insuffisance hépatique', 'Schéma adapté par un spécialiste.'],
      ['Insuffisance rénale (DFGe < 30)', 'Pyrazinamide et éthambutol 3 fois par semaine.'],
      ['VIH', 'Interactions de la rifampicine avec les antirétroviraux ; dolutégravir 2 fois par jour.'],
     ]), 71, 24), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Observance, effets indésirables', 'Toutes les 2 semaines en phase initiale, puis tous les mois', 'Mauvaise observance : traitement observé'],
    ['Transaminases', 'Au départ, puis selon le risque', 'ALAT > 3 fois la normale avec symptômes : arrêt'],
    ['Vision', 'Mensuelle sous éthambutol', 'Anomalie : arrêt de l’éthambutol'],
    ['Taille du ganglion', 'À chaque visite', 'Croissance : réaction paradoxale ou échec'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Atteinte pulmonaire contagieuse exclue ou traitée.', 'Traitement toléré et compris.', 'Rendez-vous fixé dans 2 semaines.', 'Déclaration faite.']), 9, 71) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La guérison dépasse 90 % sous traitement complet ; un ganglion résiduel ou une cicatrice peuvent persister. La recherche 2026 évalue des schémas raccourcis à 4 mois (rifapentine, moxifloxacine) déjà validés pour la forme pulmonaire.', 71), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur le dépistage et le traitement de l’infection latente chez les contacts et les patients à risque. '
   'Le vaccin BCG n’est plus recommandé en routine en Suisse. '
   'La prévention secondaire et tertiaire repose sur le diagnostic précoce, le traitement complet et l’enquête d’entourage.', 9, 91) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Traitement de l’infection latente (par exemple 4 mois de rifampicine), enquête d’entourage'],
    ['Secondaire', 'Dépistage chez les migrants symptomatiques et avant un anti-TNF'],
    ['Tertiaire', 'Traitement complet, observé si besoin, pour éviter rechute et résistance'],
   ]), 9)))
PTS.append(POINT(13, 'Points clés',
 P('La tuberculose ganglionnaire est la forme extrapulmonaire la plus fréquente. '
   'Le médecin envoie toujours une partie du prélèvement fraîche, sans formol, en culture. '
   'Il recherche une atteinte pulmonaire et fait un test VIH. '
   'Il traite 6 mois par 2HRZE puis 4HR et déclare le cas. '
   'Il ne confond pas une réaction paradoxale avec un échec.', 9, 71)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Un IGRA positif prouve la tuberculose ganglionnaire.', 'Faux : il prouve une réponse immunitaire.'],
  ['Un IGRA négatif l’exclut.', 'Faux : sensibilité imparfaite.'],
  ['Mettre tout le ganglion dans le formol.', 'Erreur : la culture devient impossible.'],
  ['Isoler toute tuberculose ganglionnaire.', 'Faux : seule l’atteinte pulmonaire est contagieuse.'],
  ['Arrêter le traitement si le ganglion grossit.', 'Erreur : réaction paradoxale possible.'],
  ['Oublier l’interaction rifampicine-contraception orale.', 'Erreur : contraception non hormonale nécessaire.'],
 ]) + P('Ces pièges reprennent le manuel suisse et l’OMS 2022.', 9, 71)))
CTX = {'_prefixe': 'Devant une tuberculose ganglionnaire',
 'igra': 'Un IGRA positif soutient le diagnostic sans le prouver ; un IGRA négatif ne l’exclut pas.',
 'pcr': 'La PCR Xpert MTB/RIF sur le ganglion donne un diagnostic rapide et détecte la résistance à la rifampicine.',
 'biopsie': 'La biopsie montre un granulome épithélioïde avec nécrose caséeuse ; une partie fraîche part en culture.',
 'expecto': 'Les expectorations recherchent une tuberculose pulmonaire associée, contagieuse.',
 'radio': 'La radiographie du thorax recherche une atteinte pulmonaire ou médiastinale.',
 'echogg': 'Un ganglion hypoéchogène avec nécrose centrale ou calcifications évoque une tuberculose.',
 'echo': 'L’échographie guide la ponction d’un abcès froid.',
 'vih': 'Un test VIH est systématique chez toute personne tuberculeuse.',
 'hep': 'Les transaminases sont contrôlées avant et pendant le traitement antituberculeux.',
 'creat': 'Le DFGe guide la dose de l’éthambutol et du pyrazinamide.',
 'tdm': 'Le scanner recherche des adénopathies médiastinales ou abdominales.',
 'nfs': 'L’hémogramme est souvent normal ; une anémie modérée accompagne la maladie active.',
 'crp': 'La CRP est souvent peu élevée dans la forme ganglionnaire isolée.',
 'vs': 'La VS est souvent accélérée, sans spécificité.',
 'cd4': 'Les CD4 évaluent l’immunodépression d’une personne tuberculeuse vivant avec le VIH.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
