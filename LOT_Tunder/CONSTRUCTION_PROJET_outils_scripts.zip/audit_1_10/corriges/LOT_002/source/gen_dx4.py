# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.4 · Infection par le VIH révélée par des adénopathies (LOT 2, Partie 2)."""
from lot2_commun import *
POINT = mkPOINT('dx4')
M = META('dx4', 'DX.4', 'VIH et adénopathies', 'Infection par le VIH révélée par des adénopathies', 'LOT_002_DX4_VIH_revele_par_adenopathies_AUDITÉ.html', 2,
         'Les schémas antirétroviraux suivent l’EACS v13.0 et les AIPS ; leur choix final appartient à l’infectiologue.')
LGP = T('lymphadénopathie généralisée persistante', 'La lymphadénopathie généralisée persistante (LGP) associe des ganglions > 1 cm dans au moins deux sites extra-inguinaux, pendant plus de 3 mois, sans autre cause ; elle traduit la stimulation immunitaire chronique par le VIH.')
PI = T('primo-infection VIH', 'La primo-infection VIH est la phase des 2 à 6 semaines qui suivent la contamination ; la charge virale est très élevée et un syndrome mononucléosique apparaît chez une partie des patients.')
UU = T('U = U', 'U = U (« undetectable = untransmittable ») signifie qu’une personne sous traitement avec une charge virale indétectable durablement ne transmet pas le VIH par voie sexuelle ; la Suisse l’a formulé dès 2008.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('L’infection par le virus de l’immunodéficience humaine (VIH) est une infection chronique des lymphocytes T CD4, qui détruit progressivement l’immunité cellulaire. '
   f'Elle peut se révéler par des adénopathies à trois moments : la {PI}, la {LGP}, puis les complications (lymphome, tuberculose, maladie de Kaposi). '
   'Le diagnostic exige un test de dépistage réactif confirmé par le laboratoire, puis vérifié sur un second prélèvement.', 4, 24, 25) +
 F('Terminologie et notions voisines',
   TAB(['Terme', 'Définition', 'À ne pas confondre avec'], [
    ['Primo-infection', 'Phase aiguë, 2–6 semaines après l’exposition', 'Mononucléose à EBV'],
    ['LGP', 'Adénopathies ≥ 2 sites extra-inguinaux > 3 mois', 'Lymphome (adénopathie asymétrique, croissante)'],
    ['SIDA', 'Stade avec infection opportuniste ou CD4 < 200/µL', 'Infection VIH sans immunodépression'],
    ['Charge virale indétectable', '< 50 copies/mL sous traitement', 'Guérison (le virus persiste)'],
    ['Fenêtre sérologique', 'Délai pendant lequel un test peut être faussement négatif', 'Absence d’infection'],
   ]) + P(f'Le principe {UU} rend le traitement à la fois thérapeutique et préventif.', 24, 4))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En 2024, 318 nouveaux diagnostics de VIH ont été déclarés en Suisse, soit 3,5 pour 100 000 habitants, contre 357 en 2023. '
   'Les groupes les plus touchés sont les hommes ayant des rapports sexuels avec des hommes et les personnes venues de régions à forte prévalence. '
   'Une partie des diagnostics reste tardive, avec des CD4 < 350/µL, comme dans le reste de l’Europe.', 61, 5) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Nouveaux diagnostics en Suisse 2024', '318 (3,5 / 100 000)', 'OFSP, Bulletin 44/2025'],
    ['Nouveaux diagnostics en Suisse 2023', '357', 'OFSP'],
    ['Fenêtre du test de 4e génération', '6 semaines', 'Directive OFSP 2025, version 4'],
    ['Primo-infection mimant une mononucléose', '≈ 1 % des patients testés pour une mononucléose', 'Rosenberg 1999 (États-Unis)'],
    ['Espérance de vie sous traitement précoce', 'Proche de la population générale', 'EACS v13.0'],
   ]) + P('Les facteurs de risque sont les rapports sexuels sans protection, le partage de matériel d’injection et l’origine d’une région de forte prévalence. Sous traitement efficace, le pronostic est proche de celui de la population générale.', 61, 24, 93))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Le VIH entre dans les lymphocytes T CD4 par le récepteur CD4 et un corécepteur (CCR5 ou CXCR4), puis il intègre son génome dans celui de la cellule. '
   'Il se réplique massivement dans les ganglions et le tube digestif, où il active en continu le système immunitaire. '
   'Cette activation chronique explique la LGP, et la perte progressive des CD4 explique les infections opportunistes et les lymphomes.', 24, 12) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les ganglions et le tissu lymphoïde digestif contiennent la majorité des lymphocytes CD4.'],
    ['Physiologie', 'Les lymphocytes CD4 coordonnent la réponse B et T ; leur nombre normal dépasse 500/µL.'],
    ['Physiopathologie', 'Le VIH infecte et détruit les CD4 ; l’hyperactivation folliculaire fait grossir les ganglions.'],
    ['Clinique', 'D’où une primo-infection fébrile, puis des adénopathies diffuses, puis des infections opportunistes quand les CD4 chutent.'],
    ['Examens', 'Le test combiné détecte l’antigène p24 et les anticorps ; la charge virale et les CD4 mesurent l’activité et l’atteinte.'],
    ['Traitement', 'Le traitement antirétroviral bloque la réplication, fait remonter les CD4 et rend la charge virale indétectable.'],
   ]), 24, 4) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Entrée virale (CD4, CCR5)', 'Génotype de résistance', 'Antagonistes de CCR5 (rarement)'],
    ['Transcription inverse', 'Charge virale', 'Inhibiteurs nucléosidiques (emtricitabine, ténofovir)'],
    ['Intégration au génome', 'Charge virale', 'Inhibiteurs de l’intégrase (bictégravir, dolutégravir)'],
    ['Destruction des CD4', 'Numération des CD4', 'Prophylaxie par cotrimoxazole si CD4 < 200/µL'],
    ['Hyperplasie folliculaire', 'Examen des ganglions', 'Traitement antirétroviral'],
    ['Lymphomagenèse (EBV, HHV-8)', 'Biopsie, TEP-TDM', 'Chimiothérapie avec traitement antirétroviral'],
   ]) + P('Cette chaîne explique pourquoi une adénopathie asymétrique et croissante chez une personne vivant avec le VIH doit faire chercher une complication, et non être attribuée au virus.', 24))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin traite d’abord une urgence (exposition < 72 heures, infection opportuniste), puis il pense au VIH devant toute adénopathie généralisée, tout syndrome mononucléosique et toute infection sexuellement transmissible. '
   'Il propose un test avec l’accord du patient, sans attendre que celui-ci se déclare « à risque ». '
   'Chez une personne déjà séropositive, il recherche une cause propre à toute adénopathie asymétrique, croissante ou fébrile.', 4, 5, 24) +
 F('Diagnostic différentiel (fréquences en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    DDXROW('vih', 'Adénopathies diffuses, exposition, IST, perte de poids', 'Test de 4e génération, charge virale'),
    DDXROW('tb', 'Fièvre, sueurs, ganglion cervical froid, CD4 bas', 'IGRA, biopsie avec culture'),
    DDXROW('nhl', 'Adénopathie croissante, symptômes B, LDH élevée', 'Biopsie-exérèse'),
    DDXROW('hl', 'Adénopathie cervicale, prurit', 'Biopsie-exérèse'),
    ['Syphilis secondaire' + PR('incidence suisse non chiffrée ici', 5), 'Éruption palmo-plantaire, adénopathies diffuses', 'Sérologie syphilis'],
    ['Mononucléose à EBV' + PR('incidence suisse non publiée', 68), 'Adolescent, angine', 'Monotest'],
    ['Maladie de Kaposi ganglionnaire' + PR('incidence suisse non publiée', 24), 'Lésions violacées, CD4 bas', 'Biopsie, HHV-8'],
   ]) + P(UNITE, 60, 61, 62))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien recherche les expositions des 3 derniers mois, les symptômes d’une primo-infection et les antécédents d’IST. '
   'Il se mène avec tact, dans un cadre confidentiel, et précise le droit du patient à refuser le test.', 4, 5) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Quand a eu lieu votre dernière exposition à risque ?', 'Fenêtre de 6 semaines du test de 4e génération.', 'Répéter le test ou demander une charge virale'],
    ['Avez-vous eu fièvre, éruption ou aphtes après cette exposition ?', 'Primo-infection.', 'Charge virale en plus du test'],
    ['Avez-vous eu une IST, une hépatite B ou C ?', 'Facteurs de risque partagés.', 'Bilan IST complet'],
    ['Avez-vous perdu du poids, des sueurs la nuit ?', 'Tuberculose, lymphome.', 'Biopsie, IGRA'],
    ['Prenez-vous une PrEP ou des médicaments ?', 'Résistance, interactions.', 'Génotype, avis spécialisé'],
    ['Êtes-vous enceinte ?', 'Prévention de la transmission à l’enfant.', 'Traitement urgent'],
   ])) +
 U('<b>Drapeaux rouges</b> : exposition de moins de 72 heures (prophylaxie postexposition urgente), fièvre avec céphalées ou raideur de nuque (méningite à cryptocoque), dyspnée avec désaturation (pneumocystose), adénopathie croissante avec symptômes B, CD4 < 200/µL ; adresse immédiate aux urgences ou à l’infectiologie.', 4, 24)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin palpe toutes les aires ganglionnaires et note leur symétrie. '
   'Il examine la bouche (candidose, leucoplasie chevelue), la peau (Kaposi, zona, éruption), le foie, la rate et l’état général. '
   'Une LGP est symétrique et stable ; une asymétrie ou une croissance oriente vers une complication.', 24) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal', 'Anomalie et signification'], [
    ['Palpation de tous les sites', 'Ganglions < 1 cm', 'Ganglions symétriques > 1 cm : LGP'],
    ['Comparaison droite-gauche', 'Symétrie', 'Asymétrie, croissance : lymphome, tuberculose'],
    ['Examen de la bouche', 'Muqueuse saine', 'Candidose : CD4 souvent < 200/µL'],
    ['Examen cutané', 'Peau normale', 'Lésions violacées : Kaposi ; éruption : primo-infection, syphilis'],
    ['Poids et IMC', 'Stable', 'Perte > 10 % : maladie avancée, tuberculose, lymphome'],
    ['Examen génital et anal', 'Normal', 'Ulcération, condylomes : IST associée'],
   ]) + P('L’examen clinique ne permet ni de poser ni d’exclure l’infection : seul le test le fait.', 4))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fièvre, la fatigue, les sueurs, la perte de poids et les signes d’infection opportuniste. '
   'Les signes physiques sont les adénopathies, la candidose buccale et les lésions cutanées. '
   'Ils se regroupent en syndrome de primo-infection, en LGP et en syndromes de déficit immunitaire.', 24) +
 F('Signes définis',
   TAB(['Syndrome', 'Description', 'Mécanisme'], [
    ['Primo-infection', 'Fièvre, angine, éruption, aphtes, adénopathies, 2–6 semaines après l’exposition', 'Virémie massive et réponse immunitaire'],
    ['LGP', 'Adénopathies symétriques, ≥ 2 sites extra-inguinaux, > 3 mois', 'Hyperplasie folliculaire chronique'],
    ['Candidose buccale', 'Dépôts blancs détachables', 'Déficit en CD4'],
    ['Leucoplasie chevelue de la langue', 'Stries blanches non détachables sur les bords', 'EBV chez l’immunodéprimé'],
    ['Maladie de Kaposi', 'Macules et nodules violacés', 'HHV-8 et déficit immunitaire'],
   ]) + P('Termes : ' + PI + '.', 24))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Selon la recommandation de la directive OFSP 2025, critère de référence en Suisse, le dépistage utilise un test de 4e génération (antigène p24 et anticorps). '
   'Un résultat réactif est confirmé au laboratoire sur le même échantillon par une méthode différente, puis vérifié sur un second prélèvement indépendant. '
   'La primo-infection est affirmée par une charge virale élevée avec une sérologie incomplète ; le stade SIDA, par des CD4 < 200/µL ou < 14 % des lymphocytes. Un test rapide isolé ne suffit pas.', 4, 25) +
 F('Éléments qui confirment ou réfutent',
   TAB(['Confirme', 'Réfute ou fait répéter'], [
    ['Test de 4e génération réactif confirmé et second prélèvement positif', 'Test non réactif ≥ 6 semaines après la dernière exposition'],
    ['Charge virale détectable', 'Test rapide négatif < 6 semaines : ne pas conclure'],
    ['CD4 < 200/µL ou infection opportuniste : stade SIDA', 'Résultat douteux : nouveau prélèvement'],
   ]) + P('La séropositivité n’est jamais annoncée sur un test de dépistage isolé.', 4))))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['Test combiné de 4e génération', 'Dépistage', 'Sensibilité et spécificité > 99 % après la période muette', 'Fenêtre de 6 semaines'],
    ['Test de confirmation (immunoblot)', 'Confirmation', 'Référence de laboratoire', 'Délai'],
    ['Charge virale (PCR ARN VIH)', 'Primo-infection, suivi', 'Détecte l’infection environ 10 jours après l’exposition', 'Faux positifs à faible titre'],
    ['Biopsie-exérèse ganglionnaire', 'Lymphome, tuberculose, Kaposi', 'Référence histologique', 'Geste chirurgical'],
   ]), 'fenetre') +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère'], [
    ['Première', 'Test de 4e génération', 'Toute suspicion'],
    ['Première', 'Charge virale', 'Primo-infection suspectée'],
    ['Après confirmation', 'CD4, génotype, hépatites B et C, syphilis, créatinine, ALAT', 'Bilan initial'],
    ['Seconde', 'Biopsie-exérèse, TEP-TDM', 'Adénopathie asymétrique ou croissante'],
    ['Seconde', 'IGRA, radiographie du thorax', 'Dépistage de la tuberculose'],
   ]), 'fenetre') +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Le <b>test VIH</b> se fait avec l’accord du patient, après une information sur sa signification.', 'Il se répète 6 semaines après la dernière exposition si le premier test est trop précoce.', 'Le <b>génotype</b> se prélève avant le premier traitement.']), 'fenetre') +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['CD4', 'Normal > 500/µL', '< 200/µL : risque d’infection opportuniste', 'Cotrimoxazole prophylactique'],
    ['Charge virale', 'Indétectable < 50 copies/mL', 'Élevée : réplication active', 'Traitement, contrôle'],
    ['Résultat positif : test réactif confirmé', '—', 'Infection probable', 'Second prélèvement, infectiologue'],
    ['Résultat négatif : test non réactif à ≥ 6 semaines', '—', 'Infection exclue', 'Conseil de prévention'],
    ['Résultat limite ou douteux', '—', 'Fenêtre ou faux positif', 'Charge virale, nouveau test'],
    ['Résultat discordant : test négatif mais tableau typique', '—', 'Primo-infection précoce', 'Charge virale'],
   ]), 'fenetre') +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Test proposé à toute femme enceinte ; traitement immédiat si positif'],
    ['Enfant de mère séropositive', 'PCR ARN ou ADN, car les anticorps maternels persistent jusqu’à 18 mois'],
    ['DFGe < 30 mL/min/1,73 m²', 'Tests inchangés ; adapter les antirétroviraux'],
    ['Allergie à l’iode', 'IRM ou TEP sans iode pour le bilan ganglionnaire'],
    ['Stimulateur cardiaque', 'Scanner, TEP ; IRM si le dispositif est compatible'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le test de 4e génération est l’examen central ; la charge virale s’y ajoute si une primo-infection est suspectée. '
   'Après confirmation, le bilan initial comprend CD4, génotype, sérologies des hépatites et de la syphilis, fonction rénale et hépatique. '
   'Une adénopathie asymétrique ou croissante impose une biopsie-exérèse.', 4, 24) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si une exposition date de moins de 72 heures, alors le médecin organise une prophylaxie postexposition sans délai. '
   'Si le test est réactif, alors il le fait confirmer et adresse le patient à l’infectiologie. '
   'Si une adénopathie est asymétrique ou croissante chez une personne séropositive, alors il demande une biopsie.', 4, 24) +
 F('Embranchements',
   TAB(['Si…', 'Alors…', 'Contrôle'], [
    ['Exposition < 72 heures', 'Prophylaxie postexposition 28 jours', 'Tests à 6 semaines'],
    ['Test non réactif, exposition > 6 semaines', 'Infection exclue', 'Conseil de prévention, PrEP'],
    ['Test non réactif, exposition < 6 semaines', 'Charge virale si symptômes, test à 6 semaines', 'Nouveau test'],
    ['Test réactif', 'Confirmation, second prélèvement, infectiologue', 'Traitement rapide'],
    ['Séropositif avec adénopathie atypique', 'Biopsie, TEP-TDM', 'Avis oncologique'],
   ]))))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe et mécanisme d’action)', 'Dose AIPS, pharmacocinétique (demi-vie, élimination) et durée', 'Effets indésirables, contre-indications, interactions'], [
   ['Bictégravir 50 mg, emtricitabine 200 mg, ténofovir alafénamide 25 mg, BIKTARVY® (inhibiteur de l’intégrase et deux nucléosidiques)', '1 comprimé par jour, à vie ; demi-vie du bictégravir ≈ 17 heures', 'Céphalées, nausées ; contre-indiqué avec la rifampicine ; non recommandé si clairance < 30 mL/min hors dialyse ; prendre à distance des antiacides contenant des cations'],
   ['Dolutégravir 50 mg et lamivudine 300 mg, DOVATO® (inhibiteur de l’intégrase et nucléosidique)', '1 comprimé par jour si charge virale < 500 000 copies/mL, sans hépatite B ni résistance', 'Insomnie, prise de poids ; augmente la metformine ; non adapté si hépatite B'],
   ['Cotrimoxazole 800/160 mg, BACTRIM® forte (sulfamide et triméthoprime)', 'Prophylaxie : 1 comprimé par jour si CD4 < 200/µL, jusqu’à CD4 > 200/µL durablement', 'Éruption, cytopénie, hyperkaliémie ; contre-indiqué en cas d’allergie aux sulfamides'],
   ['Prophylaxie postexposition (par exemple ténofovir, emtricitabine et un inhibiteur de l’intégrase)', 'Début le plus tôt possible, au plus tard 72 heures, durée 28 jours', 'Selon le schéma choisi par le centre de référence'],
  ]) + P('Ces données proviennent de l’EACS v13.0 et des AIPS ; le schéma est choisi par l’infectiologue après le génotype.', 24, 87, 82, 12))
PTS.append(POINT(11, 'Prise en charge',
 P('Le but est de rendre la charge virale indétectable, de restaurer les CD4 et de supprimer la transmission. '
   'Le traitement antirétroviral est commencé chez toute personne infectée, quel que soit le taux de CD4, et le plus tôt possible. '
   'La prise en charge est ambulatoire et coordonnée par un centre d’infectiologie.', 24, 87) +
 F('11.A Buts : urgence ou non',
   P('La forme non compliquée n’est pas une urgence vitale ; une infection opportuniste ou une exposition < 72 heures l’est ; le but chiffré est une charge virale < 50 copies/mL à 6 mois et des CD4 > 500/µL à long terme.', 24), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales et ordre',
     OL(['Annoncer le diagnostic dans un cadre confidentiel et soutenant.', 'Adresser à l’infectiologie dans les jours qui suivent.', 'Faire le bilan initial (CD4, génotype, hépatites, IST).', 'Commencer le traitement antirétroviral.', 'Commencer le cotrimoxazole si CD4 < 200/µL.', 'Informer les partenaires avec l’accord du patient.']), 24, 4) +
   MED +
   F('Volets social et professionnel',
     UL(['La LAMal prend en charge le traitement antirétroviral.', 'Aucune obligation d’informer l’employeur ; l’arrêt de travail est rarement nécessaire hors complication.', 'La LAI intervient seulement en cas d’incapacité durable ; la LAA n’est pas concernée sauf exposition professionnelle (piqûre).', 'La conduite automobile n’est pas limitée.']), 32) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Traitement immédiat, dolutégravir possible ; prévention de la transmission à l’enfant.'],
      ['Personne âgée', 'Interactions et comorbidités : revue complète des médicaments.'],
      ['Enfant', 'Schémas pédiatriques par un centre spécialisé.'],
      ['Insuffisance hépatique', 'Hépatite B : garder un traitement actif sur le VHB (ténofovir).'],
      ['Insuffisance rénale (DFGe)', 'Éviter le ténofovir disoproxil ; adapter selon l’AIPS.'],
      ['Tuberculose associée', 'Dolutégravir 50 mg 2 fois par jour avec la rifampicine ; avis spécialisé.'],
     ]), 24, 87), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Charge virale', 'À 1, 3 et 6 mois, puis tous les 6 mois', '> 50 copies/mL à 6 mois : adhérence, résistance'],
    ['CD4', 'Tous les 3–6 mois au début', '< 200/µL : prophylaxie'],
    ['Créatinine, ALAT', 'Tous les 6 mois', 'Toxicité'],
    ['Adénopathies', 'À chaque visite', 'Asymétrie ou croissance : biopsie'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Diagnostic annoncé et compris.', 'Rendez-vous d’infectiologie fixé.', 'Absence d’infection opportuniste aiguë.', 'Contact pour le soutien psychosocial donné.']), 12, 24) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le traitement ne guérit pas le virus, mais l’espérance de vie devient proche de celle de la population générale. La recherche 2026 porte sur les traitements injectables à longue action (cabotégravir, lénacapavir) et sur les stratégies de rémission.', 24), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur le préservatif, la PrEP et le traitement des personnes infectées (U = U). '
   'La prévention secondaire est le dépistage selon la directive OFSP, y compris devant des adénopathies. '
   'La prévention tertiaire comprend la prophylaxie des infections opportunistes et les vaccinations.', 4, 5, 24) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Préservatif, PrEP, prophylaxie postexposition, matériel d’injection stérile'],
    ['Secondaire', 'Dépistage proposé selon la directive OFSP 2025'],
    ['Tertiaire', 'Cotrimoxazole, vaccinations (pneumocoque, hépatite B, HPV), dépistage de la tuberculose'],
   ]), 4, 5, 91)))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin propose un test VIH devant toute adénopathie généralisée inexpliquée. '
   'Il interprète un test négatif selon la fenêtre de 6 semaines. '
   'Il ne communique jamais une séropositivité sur un test de dépistage isolé. '
   'Il fait débuter le traitement antirétroviral chez toute personne infectée, quel que soit le taux de CD4. '
   'Il biopsie toute adénopathie asymétrique ou croissante chez une personne séropositive.', 4, 24)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Un test négatif 2 semaines après l’exposition exclut le VIH.', 'Faux : fenêtre de 6 semaines.'],
  ['Attendre CD4 < 350/µL pour traiter.', 'Faux : traitement chez tous.'],
  ['Attribuer toute adénopathie au VIH.', 'Erreur : chercher lymphome et tuberculose.'],
  ['Associer bictégravir et rifampicine.', 'Erreur : interaction contre-indiquée.'],
  ['Annoncer le diagnostic sur un test rapide.', 'Erreur : confirmation obligatoire.'],
 ]) + P('Ces pièges reprennent la directive OFSP et l’EACS.', 4, 24)))
CTX = {'_prefixe': 'Devant une suspicion de VIH',
 'vih': 'Le test de 4e génération exclut l’infection s’il est non réactif 6 semaines après la dernière exposition.',
 'cv': 'La charge virale diagnostique la primo-infection et mesure l’efficacité du traitement (cible < 50 copies/mL).',
 'cd4': 'Des CD4 < 200/µL imposent une prophylaxie par cotrimoxazole.',
 'biopsie': 'La biopsie d’une adénopathie asymétrique recherche un lymphome, une tuberculose ou une maladie de Kaposi.',
 'tep': 'La TEP-TDM guide la biopsie vers le ganglion le plus actif, mais la LGP fixe aussi le traceur.',
 'igra': 'L’IGRA dépiste une tuberculose latente au bilan initial ; il est moins sensible si les CD4 sont bas.',
 'radio': 'La radiographie du thorax recherche une tuberculose ou une pneumocystose.',
 'sero': 'Les sérologies de la syphilis et des hépatites B et C complètent le bilan initial.',
 'hep': 'Les transaminases et l’hépatite B guident le choix des antirétroviraux.',
 'creat': 'Le DFGe guide le choix du ténofovir et des associations fixes.',
 'nfs': 'Une lymphopénie et une thrombopénie sont fréquentes au diagnostic.',
 'pcr': 'La PCR ARN du VIH confirme une primo-infection avant l’apparition des anticorps.',
 'hcg': 'Le test de grossesse oriente le choix du traitement et la prévention de la transmission à l’enfant.',
 'echogg': 'Des ganglions symétriques à hile conservé évoquent une LGP ; un ganglion nécrotique évoque une tuberculose.',
 'tdm': 'Le scanner recherche des adénopathies profondes avant une biopsie.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
