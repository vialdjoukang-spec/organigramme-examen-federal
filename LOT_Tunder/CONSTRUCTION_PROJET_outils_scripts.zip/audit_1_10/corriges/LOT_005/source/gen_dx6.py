# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.6 · Syndrome coronarien aigu à présentation atypique (LOT 5, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('dx6')
M = meta('dx6', 'DX.6', 'SCA atypique', 'Syndrome coronarien aigu à présentation atypique (équivalent angineux)', 'LOT_005_DX6_SCA_atypique_AUDITE.html'.replace('AUDITE', 'AUDITÉ'))
ISCH = T('ischémie myocardique', 'L’ischémie myocardique est un manque d’oxygène du muscle cardiaque ; elle devient un infarctus quand les cellules meurent.')
PLAQ = T('plaque d’athérome', 'La plaque d’athérome est un dépôt de graisse et de cellules dans la paroi d’une artère ; sa rupture déclenche un caillot.')
EQUIV = T('équivalent angineux', 'Un équivalent angineux est un symptôme d’ischémie autre que la douleur thoracique : dyspnée, malaise, nausées, sueurs.')
BJ = T('réflexe de Bezold-Jarisch', 'Le réflexe de Bezold-Jarisch est un réflexe vagal parti du ventricule ; il ralentit le cœur et fait baisser la pression.')
PTS = []

# ---------- 1
TERMES1 = TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['STEMI', 'Infarctus avec sus-décalage persistant du segment ST', 'Repolarisation précoce, péricardite'],
    ['NSTEMI', 'Infarctus (troponine qui varie au-dessus du 99e percentile) sans sus-décalage persistant', 'Lésion myocardique non ischémique'],
    ['Angor instable', 'Ischémie au repos sans hausse de la troponine', 'Angor stable d’effort'],
    ['Lésion myocardique', 'Troponine > 99e percentile, sans preuve d’ischémie', 'Infarctus de type 1'],
    ['Infarctus de type 2', 'Déséquilibre apport-demande en oxygène (anémie, tachycardie, choc)', 'Rupture de plaque (type 1)'],
   ])
PTS.append(POINT(1, 'Définition et sémantique',
 P('Le syndrome coronarien aigu (SCA) regroupe l’infarctus avec ou sans sus-décalage du segment ST (segment de repolarisation de l’ECG) et l’angor instable. '
   f'Il est dit atypique quand il se manifeste sans douleur thoracique, par un {EQUIV}. '
   'Ce terme décrit une présentation, et non une maladie différente : le traitement reste celui du SCA.', 9, 10) +
 F('Terminologie : à ne pas confondre', TERMES1 + P('Ces définitions suivent la quatrième définition universelle de l’infarctus (2018).', 10), 10)))

# ---------- 2
EPI = TAB(['Donnée', 'Valeur', 'Population'], [
    ['Infarctus sans douleur thoracique, femmes', '42,0 %', 'États-Unis, registre NRMI, 1 143 513 infarctus'],
    ['Infarctus sans douleur thoracique, hommes', '30,7 %', 'Même registre'],
    ['Mortalité hospitalière, femmes et hommes', '14,6 % et 10,3 %', 'Même registre'],
    ['Mortalité hospitalière du STEMI en 2016, hommes et femmes', '5,5 % et 6,9 %', 'Suisse, registre AMIS Plus'],
    ['Mortalité hospitalière du NSTEMI en 2016, hommes et femmes', '2,1 % et 3,6 %', 'Suisse, registre AMIS Plus'],
   ])
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, le registre AMIS Plus a suivi 51 725 infarctus de 1997 à 2016. '
   'La mortalité hospitalière du STEMI y a baissé de 9,8 % à 5,5 % chez l’homme et de 18,3 % à 6,9 % chez la femme. '
   'Au niveau international, un grand registre américain montre qu’un infarctus sur trois environ survient sans douleur thoracique.', 96, 36) +
 F('Chiffres, terrain et pronostic', EPI +
   P('Le terrain à risque associe l’âge, le sexe féminin, le diabète et l’insuffisance rénale. '
     'L’absence de douleur retarde le traitement, ce qui aggrave le pronostic. '
     'Correction de l’original : les chiffres de 20–30 % et de plus de 45 %, attribués à la Société suisse de cardiologie, n’ont pas été retrouvés.', 36, 96), 36, 96)))

# ---------- 3
CHAINE = TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les artères coronaires droite et gauche (interventriculaire antérieure, circonflexe) irriguent le myocarde ; la coronaire droite irrigue souvent la face inférieure.'],
    ['Physiologie', 'Le myocarde extrait presque tout l’oxygène du sang ; il ne peut augmenter son apport qu’en augmentant le débit coronaire.'],
    ['Physiopathologie', f'La rupture d’une {PLAQ} forme un thrombus ; sans débit, le muscle passe au métabolisme anaérobie et meurt en quelques heures.'],
    ['Clinique', 'Les fibres sympathiques donnent la douleur thoracique ; les fibres vagales donnent nausées, sueurs, malaise et bradycardie.'],
    ['Examens', 'Les cellules mortes libèrent la troponine ; l’ECG montre la zone atteinte.'],
    ['Traitement', 'On rouvre l’artère (angioplastie) et on empêche un nouveau caillot (antiplaquettaires, anticoagulant).'],
   ])
MECA = TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Thrombus sur plaque rompue', 'ECG, coronarographie', 'Angioplastie, antiplaquettaires'],
    ['Nécrose des cardiomyocytes', 'Troponine ultrasensible', 'Délai de reperfusion le plus court'],
    ['Trouble de la contraction', 'Échocardiographie', 'Traitement de l’insuffisance cardiaque'],
    ['Réflexe vagal (face inférieure)', 'Fréquence cardiaque, pression', 'Atropine si bradycardie mal tolérée'],
   ])
ALGO = TAB(['Étape (hs-cTnT Elecsys, ng/L)', 'Exclusion (rule-out)', 'Zone d’observation', 'Confirmation (rule-in)'], [
    ['Valeur à l’arrivée (0 h)', '< 5 si douleur depuis > 3 heures', 'Ni exclusion, ni confirmation', '≥ 52'],
    ['Valeur à 0 h et variation à 1 h', '< 12 et variation < 3', 'Troisième dosage à 3 heures', 'Variation ≥ 5'],
   ], 'Seuils propres à la troponine T ultrasensible Elecsys ; chaque test a ses propres seuils. Correction de l’original : la plupart des valeurs manquaient.')
PTS.append(POINT(3, 'Physiopathologie',
 P(f'L’occlusion brutale d’une artère coronaire prive le muscle d’oxygène et cause une {ISCH}. '
   'La douleur classique vient des fibres sympathiques (segments T1–T5). '
   f'Quand l’ischémie touche la face inférieure, les fibres vagales dominent : le {BJ} explique nausées, sueurs, bradycardie et malaise.', 9, 10) +
 F('Chaîne logique : de l’anatomie au traitement', CHAINE, 9, 10) +
 F('Mécanisme, exploration et cible thérapeutique', MECA, 9) +
 F('Algorithme ESC 0 h/1 h : seuils et exemple', ALGO +
   P('Exemple construit par l’audit : une patiente diabétique de 71 ans a 38 ng/L à l’arrivée et 47 ng/L à 1 heure. '
     'La variation vaut 9 ng/L, donc ≥ 5 : l’algorithme confirme l’infarctus sans sus-décalage. '
     'Correction de l’original : le réflexe de Bezold-Jarisch cause une bradycardie et une hypotension, et non une tachycardie.', 9), 9)))

# ---------- 4
DIFF = TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Infarctus avec sus-décalage (STEMI)' + PR('5–10 %', 98), 'Sus-décalage du ST, malaise, sueurs', 'ECG dans les 10 minutes'],
    ['Infarctus sans sus-décalage (NSTEMI)' + PR('15–20 %', 98), 'ECG normal ou sous-décalage', 'Troponine 0 h/1 h'],
    ['Angor instable' + PR('10 %', 98), 'Troponine normale, symptômes au repos', 'Coronarographie ou scanner coronaire'],
    ['Autres causes cardiaques (myocardite, péricardite, arythmie)' + PR('15 %', 98), 'Fièvre, frottement, palpitations', 'ECG, échocardiographie'],
    ['Causes non cardiaques' + PR('50 %', 98), 'Douleur pariétale, reflux, anxiété', 'Exclusion du SCA d’abord'],
    ['Embolie pulmonaire', 'Dyspnée, tachycardie, facteurs de thrombose', 'Score de Wells, D-dimères, angioscanner'],
    ['Dissection aortique', 'Douleur déchirante, asymétrie des pouls', 'Angioscanner aortique'],
   ])
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin traite d’abord l’urgence vitale : il enregistre un ECG dans les 10 minutes et surveille le rythme. '
   'Il cherche ensuite les autres urgences : embolie pulmonaire, dissection aortique, tamponnade, trouble du rythme grave. '
   'Il pense enfin aux causes non cardiaques du malaise.', 9) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même unité : % des patients adultes aux urgences pour douleur thoracique aiguë)',
   DIFF + P('Les fréquences ne sont pas des probabilités devant un patient donné, et elles concernent la douleur thoracique, non le malaise isolé. '
            'Pour l’embolie pulmonaire et la dissection, aucune fréquence dans cette même population n’a été retrouvée.', 98), 98)))

# ---------- 5
QUEST = TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Le malaise est-il survenu à l’effort ou au stress ?', 'L’ischémie suit la demande en oxygène.', 'ECG et troponine immédiats.'],
    ['Avez-vous une gêne dans la mâchoire, le bras ou l’épigastre ?', 'Douleur projetée de l’ischémie.', 'Probabilité de SCA plus élevée.'],
    ['Avez-vous eu des sueurs froides, des nausées ?', 'Réaction vagale et sympathique.', 'Recherche d’une atteinte inférieure.'],
    ['Êtes-vous diabétique, fumeur, hypertendu ?', 'Facteurs de risque cardiovasculaire.', 'Seuil d’exploration plus bas.'],
    ['Avez-vous déjà eu un infarctus ou un stent ?', 'Maladie coronaire connue.', 'Avis cardiologique rapide.'],
    ['Prenez-vous un anticoagulant, un médicament pour l’érection ?', 'Risque de saignement, interaction avec les nitrés.', 'Choix des traitements.'],
   ])
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise le début, l’effort déclenchant, la durée et les symptômes associés. '
   'Il relève les facteurs de risque : tabac, diabète, hypertension artérielle (HTA), dyslipidémie, antécédents familiaux.', 9, 53) +
 F('Questions et ce que la réponse change', QUEST, 9) +
 U('<b>Drapeaux rouges (urgence, 144)</b> : malaise à l’effort, sueurs froides, syncope, dyspnée de repos, hypotension, bradycardie, toute anomalie ischémique à l’ECG.', 9)))

# ---------- 6
EXAM = TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Pression aux deux bras', 'Différence < 20 mmHg', 'Asymétrie : dissection aortique'],
    ['Fréquence cardiaque', '60–100/min', 'Bradycardie : atteinte inférieure, bloc ; tachycardie : choc'],
    ['Auscultation cardiaque', 'Deux bruits réguliers', 'Galop B3 : insuffisance ventriculaire ; souffle nouveau : insuffisance mitrale aiguë'],
    ['Auscultation pulmonaire', 'Murmure symétrique', 'Crépitants : œdème pulmonaire'],
    ['Veines jugulaires', 'Non turgescentes', 'Turgescence : atteinte du ventricule droit, tamponnade'],
    ['Peau', 'Chaude, sèche', 'Pâleur, sueurs froides : bas débit'],
   ])
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen cherche les signes de bas débit et de congestion. '
   'Il mesure la pression aux deux bras pour ne pas manquer une dissection. '
   'Un examen normal ne suffit pas à exclure un SCA.', 9) +
 F('Technique, normal, anomalie et valeur', EXAM + P('La classification de Killip (I à IV) résume la gravité de l’insuffisance cardiaque à l’admission.', 9), 9)))

# ---------- 7
SYN = TAB(['Syndrome', 'Signes', 'Gravité'], [
    ['Équivalent angineux vagal', 'Malaise, sueurs, nausées, bradycardie, sans douleur', 'Atteinte inférieure possible'],
    ['Équivalent dyspnéique', 'Dyspnée d’effort ou de repos inexpliquée', 'Ischémie étendue, insuffisance cardiaque'],
    ['Syncope ou lipothymie rythmique', 'Perte de connaissance brève', 'Arythmie ventriculaire ou bloc'],
    ['Choc cardiogénique', 'Hypotension, marbrures, oligurie', 'Urgence vitale'],
   ])
TERMES7 = ('Termes : ' + T('lipothymie', 'La lipothymie est une sensation de perte de connaissance imminente, sans perte de connaissance complète.') + ', '
   + T('syncope', 'La syncope est une perte de connaissance brève avec retour spontané ; elle vient d’une baisse du débit sanguin cérébral.') + ', '
   + T('galop B3', 'Le galop B3 est un troisième bruit au début de la diastole ; il signe un ventricule gauche défaillant.') + ', '
   + T('sueurs froides', 'Les sueurs froides viennent d’une décharge d’adrénaline ; avec un malaise, elles évoquent une ischémie.') + ', '
   + T('choc cardiogénique', 'Le choc cardiogénique est une hypoperfusion des organes due à une défaillance de la pompe cardiaque.') + '.')
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont le malaise, la dyspnée, les nausées et les sueurs. '
   'Les signes physiques sont la pâleur, la bradycardie ou la tachycardie, l’hypotension et le galop. '
   'Chez la femme, la personne âgée et le patient diabétique, la douleur manque plus souvent.', 36, 9) +
 F('Syndromes à reconnaître', SYN + P(TERMES7, 9, 36), 9, 36)))

# ---------- 8
CRIT = TAB(['Critère', 'Seuil', 'Commentaire'], [
    ['Troponine qui monte ou baisse', 'Au moins une valeur > 99e percentile (hs-cTnT : 14 ng/L)', 'Obligatoire pour l’infarctus'],
    ['Symptômes d’ischémie', 'Douleur ou équivalent angineux', 'Un des critères d’ischémie'],
    ['ECG ischémique nouveau', 'Sus-décalage du ST ≥ 1 mm dans 2 dérivations contiguës (V2–V3 : seuils selon âge et sexe)', 'Un des critères d’ischémie'],
    ['Onde Q pathologique', 'Nouvelle', 'Un des critères d’ischémie'],
    ['Imagerie', 'Nouvelle perte de myocarde viable ou anomalie de contraction', 'Un des critères d’ischémie'],
    ['Thrombus', 'Vu à la coronarographie', 'Un des critères d’ischémie'],
   ], 'Seuils de sus-décalage en V2–V3 : ≥ 2 mm chez l’homme ≥ 40 ans, ≥ 2,5 mm avant 40 ans, ≥ 1,5 mm chez la femme.')
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le critère de la quatrième définition universelle (2018) exige une troponine qui varie, avec au moins une valeur au-dessus du 99e percentile en ng/L. '
   'Il demande aussi au moins un signe d’ischémie. '
   'Une troponine élevée seule ne suffit pas : elle définit une lésion myocardique, pas un infarctus.', 10) +
 F('Critères de l’infarctus (recommandation 2018)', CRIT + P('Correction de l’original : la Société suisse de cardiologie n’a pas publié de définition propre ; elle applique les recommandations ESC.', 10, 9), 10)))

# ---------- 9
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Coronarographie invasive', 'Siège et type de la lésion, traitement immédiat', 'Référence anatomique ; valeurs non données par l’audit', 'Geste invasif, produit de contraste'],
    ['Troponine ultrasensible sériée (0 h/1 h)', 'Infarctus ou exclusion', 'Valeur prédictive négative très élevée selon l’ESC ; chiffre exact à vérifier', 'Élevée aussi dans l’insuffisance rénale, l’embolie pulmonaire, la myocardite'],
   ]), 9) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'ECG 12 dérivations dans les 10 minutes, répété si symptômes', 'Tout malaise suspect'],
    ['Première', 'Troponine ultrasensible 0 h/1 h, NFS, créatinine, ionogramme, glycémie', 'ECG sans sus-décalage'],
    ['Seconde', 'Échocardiographie transthoracique', 'Troponine élevée, instabilité, souffle'],
    ['Seconde', 'Scanner coronaire', 'Probabilité faible à intermédiaire, troponine non concluante'],
    ['Seconde', 'Bilan lipidique, HbA1c', 'Prévention secondaire'],
   ]), 9) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['L’<b>ECG</b> s’enregistre dans les 10 minutes après le premier contact, puis à chaque récidive.',
       'La <b>troponine</b> se dose à l’arrivée et à 1 heure, en notant l’heure de début des symptômes.',
       'La <b>coronarographie</b> suit un délai selon le risque : immédiat (< 2 heures), précoce (< 24 heures) ou sélectif.']), 9) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Sus-décalage du ST', '≥ 1 mm dans 2 dérivations contiguës', 'STEMI', 'Angioplastie primaire'],
    ['Signe de de Winter', 'Sous-décalage ascendant du ST et grandes ondes T symétriques (V1–V6)', 'Occlusion de l’IVA', 'Traiter comme un STEMI'],
    ['Syndrome de Wellens', 'Ondes T profondes ou biphasiques en V2–V3', 'Sténose critique de l’IVA proximale', 'Coronarographie rapide'],
    ['hs-cTnT', '≥ 52 ng/L ou variation ≥ 5 ng/L à 1 h', 'Infarctus probable', 'Coronarographie selon le risque'],
   ], 'Correction de l’original : le signe de de Winter associe un sous-décalage ascendant et des ondes T amples, et non une inversion des ondes T.'), 9) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (troponine élevée stable)', 'Lésion chronique : insuffisance rénale, insuffisance cardiaque'],
    ['Résultat négatif mais clinique typique', 'Répéter l’ECG et la troponine à 3 heures'],
    ['Résultat limite (zone d’observation)', 'Troisième dosage, échocardiographie'],
    ['Grossesse', 'ECG et troponine identiques ; coronarographie possible avec protection'],
    ['Enfant', 'SCA exceptionnel : chercher une anomalie coronaire congénitale ou une maladie de Kawasaki'],
    ['Insuffisance rénale (DFGe bas)', 'Troponine de base plus élevée : se fier à la variation'],
    ['Allergie à l’iode, pacemaker ou IRM', 'Prémédication avant produit de contraste ; ECG peu lisible sous stimulation'],
   ]), 9))
PTS.append(POINT(9, 'Examens complémentaires',
 P('L’ECG trie d’abord : sus-décalage ou non. '
   'La troponine ultrasensible confirme ou exclut l’infarctus sans sus-décalage. '
   'La coronarographie confirme et traite.', 9) + P9))

# ---------- 10
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si l’ECG montre un sus-décalage, alors le médecin active la filière d’angioplastie primaire. '
   'Si l’ECG ne montre pas de sus-décalage, alors il applique l’algorithme 0 h/1 h de la troponine. '
   'Si le patient est instable, alors la coronarographie est immédiate quel que soit l’ECG.', 9) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Sus-décalage du ST', 'Angioplastie primaire ≤ 120 minutes après le diagnostic ; sinon fibrinolyse dans les 10 minutes', 'Coronarographie après fibrinolyse'],
    ['Instabilité, douleur réfractaire, arythmie', 'Coronarographie immédiate (< 2 heures)', 'Soins intensifs'],
    ['NSTEMI confirmé', 'Coronarographie précoce (< 24 heures)', 'Échocardiographie'],
    ['Troponine en zone d’observation', 'Dosage à 3 heures', 'Nouvel ECG'],
    ['Exclusion par l’algorithme', 'Chercher une autre cause du malaise', 'Suivi ambulatoire'],
   ]), 9)))

# ---------- 11
MED = F('Fiches médicamenteuses (posologies AIPS et recommandations)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Acide acétylsalicylique, Aspirin Cardio® (antiplaquettaire)', 'Bloque la cyclo-oxygénase des plaquettes de façon irréversible', 'Charge 150–300 mg per os ou 75–250 mg IV, puis 75–100 mg/j', 'Saignement, ulcère ; allergie'],
   ['Ticagrelor, Brilique® (inhibiteur P2Y12)', 'Bloque le récepteur P2Y12 de façon réversible', 'Charge 180 mg, puis 90 mg deux fois par jour', 'Dyspnée, saignement ; interactions avec les inhibiteurs du CYP3A4'],
   ['Prasugrel, Efient® (inhibiteur P2Y12)', 'Bloque le récepteur P2Y12 de façon irréversible', 'Charge 60 mg, puis 10 mg/j (5 mg si ≥ 75 ans ou < 60 kg)', 'Contre-indiqué après AVC ou accident ischémique transitoire'],
   ['Héparine non fractionnée (anticoagulant)', 'Active l’antithrombine ; action immédiate', 'Bolus IV de 70–100 UI/kg pendant l’angioplastie', 'Saignement, thrombopénie induite'],
   ['Énoxaparine, Clexane® (héparine de bas poids moléculaire)', 'Inhibe surtout le facteur Xa', 'Selon le protocole ESC et l’AIPS ; adaptation rénale', 'Saignement ; accumulation si insuffisance rénale'],
   ['Nitroglycérine, Nitrolingual® spray (dérivé nitré)', 'Dilate les veines et les coronaires', '0,4 mg sublingual, à répéter selon la pression', 'Contre-indiqué si PAS < 90 mmHg, atteinte du ventricule droit ou prise d’inhibiteur de la phosphodiestérase 5'],
  ]) + P('Correction de l’original : l’aspirine IV se donne à 75–250 mg, et non à 250–300 mg. Les recommandations ESC 2023 ne prévoient plus de prétraitement systématique par inhibiteur P2Y12 sans sus-décalage quand une coronarographie précoce est prévue.', 9, 1), 9, 1)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge rouvre l’artère au plus vite, parce que chaque minute d’occlusion détruit du muscle. '
   'Elle associe antiplaquettaires, anticoagulant et revascularisation. '
   'Elle prévient ensuite la récidive par un traitement à vie.', 9) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans une forme compliquée (STEMI, choc, arythmie), le but est la reperfusion dans les délais et la survie. Dans une forme non compliquée (NSTEMI stable), le but est la revascularisation au bon moment et la prévention de la récidive.', 9), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Forme compliquée, en urgence</b> : 144 ; monitorage du rythme ; défibrillateur à portée ; oxygène seulement si saturation < 90 % ; transfert vers un centre d’angioplastie disponible 24 heures sur 24.',
         '<b>B. Traitement antithrombotique</b> : aspirine, puis inhibiteur P2Y12 selon la stratégie, et anticoagulant pendant l’angioplastie.',
         '<b>C. Forme non compliquée, en ambulatoire après la sortie</b> : mesures générales (arrêt du tabac, activité physique, éducation sur les signes d’alerte), réadaptation cardiaque.',
         '<b>D. Double antiplaquettaire</b> : en général 12 mois, puis un seul antiplaquettaire à vie.']), 9) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('La conduite automobile reprend selon l’avis du cardiologue et les règles de l’OAC ; les chauffeurs professionnels ont des règles plus strictes.',
            'La réadaptation cardiaque prépare le retour au travail ; l’AI intervient seulement si une incapacité durable menace.'), 59, 60, 61) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Personne âgée', 'Présentation atypique fréquente ; même stratégie, attention au risque de saignement'],
      ['Diabète', 'Seuil bas pour l’ECG devant tout malaise'],
      ['Insuffisance rénale (DFGe)', 'Adapter les anticoagulants, limiter le produit de contraste'],
      ['Femme jeune', 'Penser aussi à la dissection spontanée d’une artère coronaire'],
      ['Grossesse et allaitement', 'Avis cardiologique et obstétrical ; choix des antithrombotiques au cas par cas'],
      ['Enfant', 'Avis de cardiologie pédiatrique'],
      ['Insuffisance hépatique', 'Prudence avec le ticagrelor et les anticoagulants (risque de saignement)'],
     ]), 9), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Rythme cardiaque', 'Monitorage continu 24–48 heures', 'Arythmie ventriculaire : défibrillation'],
    ['Pression, signes d’insuffisance cardiaque', 'Plusieurs fois par jour', 'Crépitants, hypotension : échocardiographie'],
    ['Créatinine', 'Après le produit de contraste', 'Hausse : hydratation, adaptation des doses'],
    ['Fraction d’éjection', 'Échocardiographie avant la sortie', 'Altérée : traitement de l’insuffisance cardiaque'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Pas d’arythmie ni de douleur.', 'Traitement de prévention secondaire en place.', 'Réadaptation cardiaque planifiée.', 'Suivi cardiologique fixé.']), 9) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('En Suisse, la mortalité hospitalière du STEMI était de 5,5 % chez l’homme et 6,9 % chez la femme en 2016. Sa baisse suit la diffusion de la reperfusion. Correction de l’original : les stents biorésorbables ne sont pas une avancée de 2026 ; ce point n’a pas été vérifié et a été retiré.', 96), 'fenetre')))

# ---------- 12
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire traite les facteurs de risque avant tout événement. '
   'La prévention secondaire vise un LDL-cholestérol < 1,4 mmol/L et une baisse d’au moins 50 % par une statine de haute intensité. '
   'Elle ajoute l’ézétimibe, puis un inhibiteur de PCSK9 si la cible n’est pas atteinte.', 97, 9) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Arrêt du tabac, contrôle de la pression, du diabète et des lipides'],
    ['Secondaire', 'Atorvastatine 40–80 mg (Sortis® en Suisse) ou rosuvastatine, aspirine, réadaptation'],
    ['Tertiaire', 'Traitement de l’insuffisance cardiaque, défibrillateur si indiqué'],
   ], 'Correction de l’original : Lipitor® est le nom américain ; en Suisse, l’atorvastatine originale est Sortis®.'), 97, 1)))

# ---------- 13
PTS.append(POINT(13, 'Points clés',
 P('Le médecin enregistre un ECG devant tout malaise inexpliqué avec facteurs de risque. '
   'Il dose la troponine ultrasensible à 0 h et 1 h. '
   'Il sait qu’environ 4 femmes sur 10 font un infarctus sans douleur thoracique. '
   'Il traite le SCA atypique comme un SCA typique.', 9, 36)))

# ---------- 14
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Renoncer à l’ECG faute de douleur thoracique.', 'ECG dans les 10 minutes devant tout malaise suspect.'],
  ['Conclure à un infarctus sur une seule troponine élevée.', 'Il faut une variation et un signe d’ischémie.'],
  ['Donner un dérivé nitré à un patient hypotendu ou sous inhibiteur de la phosphodiestérase 5.', 'Contre-indication.'],
  ['Prendre un signe de de Winter pour un simple sous-décalage.', 'Équivalent de STEMI : coronarographie immédiate.'],
  ['Donner de l’oxygène à tout patient.', 'Seulement si saturation < 90 %.'],
 ]) + P('Ces pièges reprennent les recommandations ESC 2023 et la définition universelle de 2018.', 9, 10)))

CTX = {'_prefixe': 'Dans le SCA atypique',
 'ecg': 'L’ECG dans les 10 minutes cherche un sus-décalage du ST ou un équivalent.',
 'tropo': 'La troponine ultrasensible à 0 h et 1 h confirme ou exclut l’infarctus sans sus-décalage.',
 'coro': 'La coronarographie localise et traite la lésion coupable.',
 'echocoeur': 'L’échocardiographie cherche un trouble de la contraction et une complication mécanique.',
 'nfs': 'La NFS cherche une anémie, cause d’infarctus de type 2.',
 'creat': 'La créatinine guide les doses et le produit de contraste.',
 'iono': 'Le potassium et le magnésium influencent le risque d’arythmie.',
 'gly': 'La glycémie dépiste un diabète méconnu.',
 'lip': 'Le bilan lipidique fixe la cible de LDL-cholestérol.',
 'hba1c': 'L’HbA1c dépiste un diabète méconnu.',
 'ddim': 'Les D-dimères aident à exclure une embolie pulmonaire si la probabilité est faible.',
 'tdm': 'L’angioscanner cherche une dissection aortique ou une embolie pulmonaire.',
 'radio': 'La radiographie du thorax cherche un œdème pulmonaire.',
 'bnp': 'Le BNP évalue une insuffisance cardiaque associée.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
