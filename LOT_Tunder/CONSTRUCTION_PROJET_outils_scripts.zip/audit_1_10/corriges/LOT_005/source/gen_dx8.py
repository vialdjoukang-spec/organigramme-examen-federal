# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.8 · Delirium hypoactif et décompensation gériatrique (« glissement ») (LOT 5, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('dx8')
M = meta('dx8', 'DX.8', 'Delirium et glissement', 'Delirium hypoactif et décompensation gériatrique aiguë (« syndrome de glissement »)', 'LOT_005_DX8_Delirium_et_glissement_AUDITÉ.html')
INATT = T('inattention', 'L’inattention est l’incapacité à fixer et maintenir son attention ; c’est le signe central du delirium.')
RESERVE = T('réserve cognitive', 'La réserve cognitive est la capacité du cerveau à compenser une agression ; elle baisse avec l’âge et la démence.')
ANTICHOL = T('effet anticholinergique', 'Un effet anticholinergique bloque l’acétylcholine ; il cause confusion, rétention d’urine, constipation et bouche sèche.')
FRAG = T('fragilité', 'La fragilité est une baisse des réserves de plusieurs organes ; une petite agression suffit alors à décompenser.')
PTS = []

# ---------- 1
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Le delirium (état confusionnel aigu) est un trouble aigu et fluctuant de l’attention et de la conscience, dû à une cause somatique, toxique ou à un sevrage. '
   'Dans sa forme hypoactive, le patient est calme, somnolent et ralenti ; il paraît seulement « mal » ou « fatigué ». '
   f'Le « syndrome de glissement » n’est pas un diagnostic reconnu : il décrit une décompensation globale d’une personne âgée en {FRAG}, qu’il faut explorer.', 18, 16) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Delirium', 'Trouble aigu et fluctuant de l’attention et de la conscience', 'Démence (installation lente, attention conservée au début)'],
    ['Delirium hypoactif', 'Somnolence, ralentissement, apathie', 'Dépression'],
    ['Delirium hyperactif', 'Agitation, hallucinations', 'Psychose'],
    ['« Glissement »', 'Terme descriptif français, sans critères validés', 'Diagnostic à part entière'],
   ]) + P('Correction de l’original : « failure to thrive » et delirium ne sont pas synonymes ; le premier décrit un déclin global, le second un trouble de l’attention.', 18, 16), 18, 16)))

# ---------- 2
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('Aucune donnée suisse publiée n’a été retrouvée ; les chiffres de 20–30 % attribués à la société suisse de gériatrie ne sont pas confirmés. '
   'En Europe, une cohorte anglaise de 51 202 admissions non programmées (âge moyen 82 ans) trouve un delirium chez 14,6 % des patients. '
   'Une méta-analyse internationale trouve une prévalence de 24,2 % dans les études du 4AT.', 102, 17) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Delirium seul', '14,6 %', 'Admissions non programmées, Oxfordshire, âge moyen 82 ans'],
    ['Delirium et démence', '9,4 %', 'Même cohorte'],
    ['Démence seule', '7,5 %', 'Même cohorte'],
    ['Toute fragilité cognitive', '34,5 %', 'Même cohorte'],
    ['Delirium dans les études du 4AT', '24,2 % (10,5–61,9 %)', 'Personnes âgées, soins aigus, 17 études'],
   ]) + P('Le terrain associe l’âge avancé, la démence, la fragilité, les déficits sensoriels et la polymédication. '
          'Le delirium aggrave le pronostic : mortalité, chutes, perte d’autonomie, entrée en institution.', 102, 16, 17), 102, 17)))

# ---------- 3
PTS.append(POINT(3, 'Physiopathologie',
 P(f'Le cerveau âgé a une {RESERVE} diminuée. '
   'Une agression (infection, médicament, déshydratation, douleur) perturbe alors les neurotransmetteurs : l’acétylcholine baisse et la dopamine augmente relativement. '
   'L’inflammation générale atteint aussi le cerveau, ce qui désorganise les réseaux de l’attention.', 16) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'L’attention dépend du thalamus, du tronc cérébral et du cortex préfrontal, reliés par des voies cholinergiques.'],
    ['Physiologie', 'Pourquoi l’acétylcholine compte : elle maintient l’éveil et l’attention.'],
    ['Physiopathologie', f'Un {ANTICHOL}, une hypoxie ou des cytokines réduisent cette transmission et le réseau se désorganise.'],
    ['Clinique', 'D’où l’inattention, la fluctuation, la somnolence ou l’agitation.'],
    ['Examens', 'Les tests d’attention (4AT, CAM) détectent le trouble ; la biologie et l’imagerie cherchent la cause.'],
    ['Traitement', 'On traite la cause et on retire les médicaments en cause ; on protège le cerveau par des mesures non médicamenteuses.'],
   ]), 16) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Infection, inflammation', 'CRP, ECBU, radiographie du thorax', 'Traitement de l’infection'],
    ['Médicament anticholinergique ou sédatif', 'Revue des médicaments', 'Arrêt ou réduction'],
    ['Troubles métaboliques', 'Glycémie, sodium, calcium, créatinine', 'Correction'],
    ['Rétention d’urine, fécalome', 'Échographie vésicale, toucher rectal', 'Sondage, évacuation'],
    ['Lésion cérébrale', 'Scanner cérébral', 'Prise en charge neurologique'],
   ]), 16, 103) +
 F('4AT et CAM : items et calcul',
   TAB(['Item du 4AT', 'Normal', 'Anormal'], [
    ['Vigilance', '0', '4 (somnolence ou agitation nette)'],
    ['AMT4 (âge, date de naissance, lieu, année)', '0', '1 (une erreur) ou 2 (deux erreurs ou plus)'],
    ['Mois de l’année à l’envers', '0 (au moins 7 mois corrects)', '1 (moins de 7) ou 2 (refus, impossible)'],
    ['Changement aigu ou fluctuant', '0', '4'],
   ], 'Score ≥ 4 : delirium possible ; 1–3 : trouble cognitif possible ; 0 : delirium peu probable. Sensibilité et spécificité 88 %.') +
   P('La CAM exige un début aigu ou fluctuant et une inattention, plus une pensée désorganisée ou une altération de la conscience. '
     'Exemple de l’original recalculé : somnolence (4), mois à l’envers impossibles (2), début brutal (4). Le score vaut au moins 10, et non 5 ; le delirium est probable.', 104, 17, 38), 104, 17, 38)))

# ---------- 4
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin cherche d’abord une urgence vitale : hypoglycémie, hypoxie, sepsis, AVC, hématome sous-dural. '
   'Il confirme ensuite le delirium par un test d’attention, puis cherche toutes les causes, souvent multiples. '
   'Il distingue enfin le delirium d’une démence ou d’une dépression.', 16, 103) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même unité : % des admissions non programmées, Oxfordshire, âge moyen 82 ans)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Delirium seul' + PR('14,6 %', 102), 'Début aigu, inattention, fluctuation', '4AT, CAM'],
    ['Delirium sur démence' + PR('9,4 %', 102), 'Aggravation aiguë d’un déclin connu', '4AT, avis des proches'],
    ['Démence sans delirium' + PR('7,5 %', 102), 'Déclin lent, attention conservée', 'Tests cognitifs à distance'],
    ['Test cognitif anormal sans diagnostic' + PR('3 %', 102), 'AMTS < 8', 'Réévaluation'],
    ['Dépression du sujet âgé', 'Tristesse, attention conservée', 'Échelle de dépression gériatrique'],
    ['Accident vasculaire cérébral', 'Déficit focal', 'Scanner ou IRM cérébrale'],
   ]) + P('Les fréquences ne sont pas des probabilités devant un patient donné. '
          'Pour la dépression et l’AVC, aucune fréquence dans cette même population n’a été retrouvée.', 102), 102)))

# ---------- 5
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien avec les proches précise l’état antérieur et la rapidité du changement. '
   'Il relève tous les médicaments, surtout ceux qui ont été ajoutés ou arrêtés récemment.', 16, 23) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Comment était-il il y a deux semaines ?', 'Comparer à l’état antérieur.', 'Changement aigu : delirium.'],
    ['Quels médicaments ont changé ?', 'Cause médicamenteuse fréquente.', 'Arrêt du médicament en cause.'],
    ['A-t-il chuté, s’est-il cogné la tête ?', 'Hématome sous-dural.', 'Scanner cérébral.'],
    ['Boit-il de l’alcool, prend-il un somnifère ?', 'Sevrage possible.', 'Traitement du sevrage.'],
    ['Urine-t-il, va-t-il à selles ?', 'Rétention, fécalome.', 'Échographie vésicale, toucher rectal.'],
   ]), 16, 23) +
 U('<b>Drapeaux rouges (urgence, 144)</b> : déficit neurologique focal, fièvre ou hypothermie, saturation basse, chute avec anticoagulant, raideur de nuque, glycémie basse.', 16, 103)))

# ---------- 6
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen mesure toutes les constantes et la glycémie capillaire. '
   'Il cherche un foyer infectieux, un globe vésical, un fécalome, une déshydratation et un déficit neurologique. '
   'Un examen sans cause évidente ne suffit pas à conclure à un « glissement ».', 16) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Constantes, glycémie capillaire', 'Normales', 'Fièvre, hypoxie, hypotension, hypoglycémie'],
    ['Palpation de l’hypogastre, échographie vésicale', 'Vessie non palpable', 'Globe : rétention d’urine'],
    ['Toucher rectal', 'Ampoule vide', 'Fécalome'],
    ['Examen neurologique', 'Pas de déficit', 'Déficit focal : AVC, hématome'],
    ['Peau, bouche', 'Humides, intactes', 'Pli cutané, escarre infectée'],
    ['Test d’attention (mois à l’envers)', 'Au moins 7 mois corrects', 'Échec : inattention'],
   ]), 16, 104)))

# ---------- 7
TERMES = ('Termes : ' + T('fluctuation', 'La fluctuation est la variation des troubles au cours de la journée ; elle aide à distinguer le delirium de la démence.') + ', '
   + T('inversion du rythme', 'L’inversion du rythme veille-sommeil est une somnolence le jour et une agitation la nuit.') + ', '
   + T('apathie', 'L’apathie est une perte d’initiative et d’intérêt ; elle domine le delirium hypoactif.') + ', '
   + T('hallucination', 'Une hallucination est une perception sans objet ; elle est surtout visuelle dans le delirium.') + ', '
   + T('globe vésical', 'Le globe vésical est une vessie distendue par une rétention d’urine ; il peut causer agitation ou confusion.') + '.')
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P(f'Le signe central est l’{INATT}. '
   'Les signes fonctionnels, rapportés par les proches, sont la somnolence, le refus de manger, l’agitation nocturne et les hallucinations. '
   'Les signes physiques sont l’échec aux tests d’attention, le ralentissement psychomoteur et la désorientation.', 16, 18) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Gravité'], [
    ['Delirium hypoactif', 'Somnolence, apathie, refus alimentaire', 'Souvent méconnu'],
    ['Delirium hyperactif', 'Agitation, hallucinations', 'Chutes, arrachage des perfusions'],
    ['Delirium mixte', 'Alternance des deux', 'Même prise en charge'],
    ['Décompensation globale de la personne âgée fragile', 'Perte d’autonomie, chutes, refus de se lever', 'Chercher une cause'],
   ]) + P(TERMES, 16, 18), 16, 18)))

# ---------- 8
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le critère DSM-5-TR (2022) exige un trouble de l’attention et de la conscience, installé en heures ou en jours, et fluctuant. '
   'Il exige aussi un trouble cognitif associé et la preuve d’une cause somatique, toxique ou d’un sevrage. '
   'Un score 4AT ≥ 4 ne suffit pas à poser le diagnostic : il oriente vers une évaluation clinique, sa sensibilité est de 88 % selon la recommandation NICE et la méta-analyse de 2021.', 18, 103, 104) +
 F('Critères DSM-5-TR et place des outils',
   TAB(['Critère', 'Contenu', 'Outil'], [
    ['A', 'Trouble de l’attention et de la conscience', 'Mois à l’envers, 4AT'],
    ['B', 'Installation rapide, fluctuation', 'Avis des proches'],
    ['C', 'Trouble cognitif associé (mémoire, orientation, langage, perception)', 'AMT4'],
    ['D', 'Non expliqué par une démence préexistante, pas de coma', 'Anamnèse'],
    ['E', 'Cause somatique, toxique ou sevrage', 'Bilan étiologique'],
   ], 'Correction de l’original : la société suisse de gériatrie n’a pas publié de critères propres ; elle applique le DSM-5-TR.'), 18)))

# ---------- 9
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Évaluation clinique selon le DSM-5-TR', 'Diagnostic du delirium', 'Référence', 'Demande du temps et de l’expérience'],
    ['4AT', 'Dépistage', 'Sensibilité 88 %, spécificité 88 %', 'Ne remplace pas l’évaluation'],
   ]), 18, 17) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Glycémie, ionogramme (sodium, calcium), créatinine, urée, CRP, NFS, bilan hépatique', 'Tout delirium'],
    ['Première', 'Bandelette urinaire, ECG, saturation', 'Tout delirium'],
    ['Seconde', 'Scanner cérébral', 'Chute, anticoagulant, déficit focal, absence de cause'],
    ['Seconde', 'Radiographie du thorax, hémocultures', 'Fièvre, toux'],
    ['Seconde', 'TSH, vitamine B12, dosages de médicaments', 'Cause non trouvée'],
   ]), 16, 103) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La <b>glycémie capillaire</b> se mesure dans les premières minutes.',
       'La <b>bandelette urinaire</b> positive sans symptôme urinaire ne prouve pas une infection chez la personne âgée.',
       'Le <b>scanner cérébral</b> se fait sans injection, en urgence si chute ou anticoagulant.']), 16) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['4AT', '≥ 4', 'Delirium possible', 'Évaluation clinique et bilan étiologique'],
    ['4AT', '1–3', 'Trouble cognitif possible', 'Évaluation cognitive'],
    ['Sodium', '< 125 mmol/L', 'Hyponatrémie profonde', 'Correction prudente'],
    ['Glycémie', '< 3,9 mmol/L', 'Hypoglycémie', 'Sucre immédiat'],
   ]), 104, 12) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (bandelette positive sans symptômes)', 'Bactériurie asymptomatique : ne pas traiter d’emblée'],
    ['Résultat négatif mais clinique typique (bilan normal)', 'Revoir les médicaments, chercher douleur, rétention, sevrage'],
    ['Résultat limite (4AT à 3)', 'Répéter le test dans la journée'],
    ['Grossesse', 'Situation rare ; chercher une éclampsie'],
    ['Enfant', 'Échelles pédiatriques'],
    ['Insuffisance rénale (DFGe bas)', 'Accumulation des médicaments : adapter les doses'],
    ['Allergie à l’iode, pacemaker ou IRM', 'Scanner sans injection en première intention'],
   ]), 16))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le diagnostic est clinique. '
   'La biologie et l’imagerie cherchent la cause, souvent multiple. '
   'Le choix des examens suit l’anamnèse et l’examen.', 16, 103) + P9))

# ---------- 10
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si la glycémie, la saturation ou les constantes sont anormales, alors le médecin corrige immédiatement. '
   'Si le 4AT est ≥ 4, alors il cherche les causes et revoit les médicaments. '
   'Si une chute, un anticoagulant ou un déficit focal sont présents, alors il demande un scanner cérébral.', 16, 104) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Hypoglycémie', 'Glucose', 'Glycémie à 15 minutes'],
    ['Globe vésical', 'Sondage', 'Diurèse'],
    ['Fécalome', 'Évacuation, laxatif', 'Transit'],
    ['Médicament suspect', 'Arrêt ou réduction', '4AT quotidien'],
    ['Agitation dangereuse malgré les mesures', 'Halopéridol à faible dose, de courte durée', 'Réévaluation quotidienne'],
   ]), 16, 103)))

# ---------- 11
MED = F('Fiches médicamenteuses (posologies AIPS et recommandations)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte âgé)', 'Effets indésirables, contre-indications, interactions'], [
   ['Halopéridol, Haldol® (antipsychotique)', 'Bloque les récepteurs D2 de la dopamine', '0,5 mg, à répéter avec prudence ; durée courte, en général ≤ 1 semaine', 'QT long, syndrome extrapyramidal ; éviter dans la maladie de Parkinson et la démence à corps de Lewy'],
   ['Quétiapine, Seroquel® (antipsychotique atypique)', 'Bloque D2 et 5-HT2A ; sédatif', '12,5–25 mg, hors AIPS pour le delirium', 'Sédation, hypotension ; préférée si Parkinson'],
   ['Lorazépam, Temesta® (benzodiazépine)', 'Renforce le GABA', 'Réservé au sevrage d’alcool ou de benzodiazépines', 'Aggrave le delirium dans les autres cas'],
  ]) + P('Aucun médicament n’a prouvé qu’il traite ou prévient le delirium ; les antipsychotiques ne servent qu’à une agitation dangereuse.', 16, 103, 1), 16, 103, 1)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge traite la cause, parce que le delirium est le symptôme d’une maladie. '
   'Elle repose sur des mesures non médicamenteuses et le retrait des médicaments en cause. '
   'Elle n’utilise un antipsychotique que pour une agitation dangereuse.', 16, 103) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans une forme compliquée (cause vitale, agitation dangereuse), le but est de traiter la cause et de protéger le patient. Dans une forme non compliquée, le but est de réorienter le patient et de préserver l’autonomie.', 16), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Forme compliquée, en urgence</b> : correction de l’hypoglycémie, de l’hypoxie, de la rétention ; traitement du sepsis ; scanner si besoin.',
         '<b>B. Revue des médicaments</b> : arrêt des anticholinergiques, des sédatifs et des médicaments inutiles.',
         '<b>C. Forme non compliquée, en ambulatoire ou en EMS</b> : mesures générales (réorientation, lunettes, appareils auditifs, lever précoce, hydratation, sommeil, éducation des proches).',
         '<b>D. Agitation dangereuse</b> : antipsychotique à faible dose et de courte durée ; pas de contention physique.']), 16, 39, 103) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('La conduite automobile est suspendue pendant le delirium ; l’aptitude se réévalue ensuite, surtout en cas de démence.',
            'Le retour à domicile se prépare avec les soins à domicile et les proches ; la mesure de protection de l’adulte se discute si le discernement reste altéré.'), 59, 60, 61) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Rare ; avis spécialisé'],
      ['Démence à corps de Lewy, Parkinson', 'Éviter l’halopéridol'],
      ['Enfant', 'Avis pédiatrique'],
      ['Insuffisance hépatique', 'Encéphalopathie hépatique à chercher'],
      ['Insuffisance rénale (DFGe)', 'Adapter les doses, éviter l’accumulation'],
     ]), 16, 103), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['4AT ou CAM', 'Chaque jour', 'Aggravation : rechercher une nouvelle cause'],
    ['Apports, transit, diurèse', 'Chaque jour', 'Baisse : correction'],
    ['Antipsychotique', 'Chaque jour', 'Arrêt dès que l’agitation cède'],
    ['ECG sous halopéridol', 'Avant et pendant', 'QT long : arrêt'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Cause traitée.', 'Attention améliorée.', 'Médicaments revus.', 'Retour à domicile organisé, suivi cognitif prévu.']), 16, 103) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le delirium peut durer des semaines et laisser un déclin cognitif. Les programmes non médicamenteux réduisent son incidence (odds ratio 0,47) et les chutes. Le chiffre de 40 % attribué par l’original aux protocoles suisses de 2026 n’est pas sourcé.', 39, 16), 'fenetre')))

# ---------- 12
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repère les patients à risque à l’admission. '
   'Elle applique des mesures non médicamenteuses à plusieurs composantes : orientation, mobilisation, sommeil, hydratation, lunettes et appareils auditifs. '
   'Elle évite les médicaments anticholinergiques et sédatifs selon les critères STOPP, comme le recommande aussi smarter medicine en Suisse.', 39, 23, 103, 41) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Programme non médicamenteux, revue des médicaments'],
    ['Secondaire', 'Dépistage quotidien par le 4AT'],
    ['Tertiaire', 'Suivi cognitif après la sortie'],
   ]), 39, 17)))

# ---------- 13
PTS.append(POINT(13, 'Points clés',
 P('Le médecin teste l’attention chez toute personne âgée qui « va mal », car le delirium hypoactif passe souvent inaperçu. '
   'Il cherche toutes les causes, souvent multiples : infection, médicament, déshydratation, rétention, douleur. '
   'Il revoit et réduit les médicaments, surtout anticholinergiques et sédatifs. '
   'Il évite les benzodiazépines, sauf sevrage, et les contentions physiques.', 16, 103)))

# ---------- 14
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Conclure à une dépression devant un patient apathique.', 'Tester l’attention : delirium hypoactif.'],
  ['Donner une benzodiazépine à un patient agité.', 'Elle aggrave le delirium, sauf sevrage.'],
  ['Exiger les 4 critères de la CAM.', 'Les critères 1 et 2, plus le 3 ou le 4.'],
  ['Parler de « glissement » sans bilan.', 'Chercher une cause traitable.'],
  ['Attacher un patient agité.', 'Les contentions aggravent l’agitation.'],
 ]) + P('Ces pièges reprennent Inouye 2014 et la recommandation NICE.', 16, 103)))

CTX = {'_prefixe': 'Dans le delirium',
 'gly': 'La glycémie capillaire exclut une hypoglycémie dans les premières minutes.',
 'iono': 'Le sodium et le calcium sont des causes fréquentes de delirium.',
 'creat': 'La créatinine guide les doses des médicaments.',
 'uree': 'L’urée élevée évoque une déshydratation.',
 'crp': 'La CRP oriente vers une infection.',
 'nfs': 'La NFS cherche une infection ou une anémie.',
 'ecbu': 'L’ECBU confirme une infection urinaire symptomatique.',
 'ecg': 'L’ECG cherche un trouble du rythme ou un SCA et mesure le QT.',
 'tdm': 'Le scanner cérébral cherche un hématome ou un AVC.',
 'hep': 'Le bilan hépatique cherche une encéphalopathie hépatique.',
 'tsh': 'La TSH exclut une dysthyroïdie.',
 'b12': 'La vitamine B12 cherche une carence.',
 'tox': 'Les dosages cherchent une intoxication médicamenteuse.',
 'radio': 'La radiographie du thorax cherche une pneumonie.',
 'oxy': 'La saturation exclut une hypoxie.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
