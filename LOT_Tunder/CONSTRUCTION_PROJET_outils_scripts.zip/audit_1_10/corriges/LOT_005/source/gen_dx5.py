# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.5 · Sepsis occulte et infection bactérienne invasive débutante (LOT 5, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('dx5')
M = meta('dx5', 'DX.5', 'Sepsis occulte', 'Sepsis occulte et infection bactérienne invasive débutante', 'LOT_005_DX5_Sepsis_occulte_AUDITÉ.html')
DYSF = T('dysfonction d’organe', 'Une dysfonction d’organe est la perte partielle de la fonction d’un organe (rein, cerveau, poumon, foie, coagulation, circulation) ; le score SOFA la mesure de 0 à 4 points par organe.')
VASO = T('vasoplégie', 'La vasoplégie est une dilatation excessive des artérioles ; la pression baisse malgré un cœur qui bat vite.')
HYPOP = T('hypoperfusion', 'L’hypoperfusion est un apport de sang insuffisant aux tissus ; les cellules manquent d’oxygène et produisent du lactate.')
FOYER = T('foyer infectieux', 'Le foyer infectieux est l’organe d’où part l’infection (poumon, urine, abdomen, peau, cathéter) ; le traiter ou le drainer est indispensable.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Le sepsis est une {DYSF} qui menace la vie et qui est causée par une réponse déréglée de l’organisme à une infection. '
   'Il est « occulte » quand il se présente seulement par un malaise, une fatigue, une confusion ou une chute, sans fièvre ni signe local évident. '
   'Le choc septique est un sepsis avec une hypotension qui exige un vasopresseur pour maintenir une PAM ≥ 65 mmHg et un lactate > 2 mmol/L malgré un remplissage adéquat.', 4) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition exacte (Sepsis-3)', 'À ne pas confondre avec'], [
    ['Sepsis', 'Infection + hausse aiguë du SOFA ≥ 2 points', 'Infection sans dysfonction d’organe'],
    ['Choc septique', 'Sepsis + vasopresseur pour PAM ≥ 65 mmHg + lactate > 2 mmol/L après remplissage', 'Hypotension corrigée par le remplissage'],
    ['« Sepsis sévère »', 'Terme abandonné en 2016', 'Sepsis selon Sepsis-3'],
    ['SIRS', 'Réponse inflammatoire (température, pouls, respiration, leucocytes)', 'Sepsis : le SIRS n’est plus un critère'],
    ['Bactériémie', 'Bactéries dans le sang (hémocultures positives)', 'Sepsis : une bactériémie peut être sans dysfonction'],
   ]) + P('Correction de l’original : l’exemple qualifiait un SOFA de 5 de « sepsis sévère », terme abandonné par Sepsis-3.', 4))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, le Swiss Sepsis Report 2025 compte 21 001 séjours hospitaliers codés sepsis en 2023, soit 240 cas pour 100 000 habitants par an. '
   'La mortalité hospitalière atteint 18,9 %, 32,6 % en cas de choc septique et 22,3 % chez les personnes de 65 ans ou plus, qui représentent 70,2 % des cas. '
   'Le chiffre de l’original (plus de 30 000 cas) n’est pas confirmé, et la part de 8 % des consultations pour malaise n’a pas été retrouvée.', 92) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Séjours codés sepsis', '21 001 (2023), 240/100 000 par an', 'Suisse, tous âges'],
    ['Séjours avec définition large (infection + dysfonction)', '72 000–90 000 par an', 'Suisse'],
    ['Mortalité hospitalière', '18,9 % ; choc septique 32,6 %', 'Suisse 2023'],
    ['Mortalité à 1 an après 65 ans', 'Près de 30 %', 'Suisse 2023'],
    ['Passage en soins intensifs', '40,7 %', 'Suisse 2023'],
    ['Sepsis au niveau mondial', '48,9 millions de cas et 11 millions de décès en 2017', 'Rudd 2020'],
   ]) + P('Le terrain associe l’âge ≥ 65 ans, les maladies chroniques, l’immunosuppression, les sondes et cathéters. Le pronostic dépend de la rapidité du traitement et du terrain.', 92, 34))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Le système immunitaire reconnaît les composants des bactéries et libère des cytokines pour les détruire. '
   f'Dans le sepsis, cette réponse s’emballe : elle cause une {VASO}, une fuite capillaire, des microthromboses et une baisse de la contraction du cœur. '
   f'Il en résulte une {HYPOP}, qui explique la confusion, l’oligurie et la hausse du lactate.', 4, 5) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'L’endothélium tapisse tous les vaisseaux ; les monocytes et les neutrophiles circulent dans le sang et reconnaissent les bactéries.'],
    ['Physiologie', 'Pourquoi l’inflammation est utile : elle dilate les vaisseaux du foyer, attire les leucocytes et isole l’infection.'],
    ['Physiopathologie', 'Quand elle devient générale, le monoxyde d’azote dilate toutes les artérioles, l’endothélium fuit et la coagulation s’active dans les petits vaisseaux.'],
    ['Clinique', 'D’où la tachypnée, la tachycardie, l’hypotension, la confusion, l’oligurie et les marbrures, parfois sans fièvre chez la personne âgée.'],
    ['Examens', 'Comme les cellules manquent d’oxygène, le lactate monte ; la créatinine, la bilirubine et les plaquettes mesurent les organes atteints.'],
    ['Traitement', 'On agit sur la cause et sur la perfusion : antibiotique dans l’heure, contrôle du foyer, remplissage, noradrénaline.'],
   ]), 4, 5) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Bactéries dans le sang', 'Hémocultures', 'Antibiotique dans l’heure'],
    ['Foyer collecté ou obstacle', 'Échographie, scanner', 'Drainage, retrait du cathéter'],
    ['Vasoplégie, fuite capillaire', 'PAM, lactate', 'Cristalloïdes, noradrénaline'],
    ['Atteinte rénale', 'Créatinine, diurèse', 'Perfusion, adaptation des doses'],
    ['Coagulation intravasculaire', 'Plaquettes, temps de prothrombine, fibrinogène', 'Traitement de la cause'],
   ]), 5, 4) +
 F('Score SOFA : organes, paramètres et points',
   TAB(['Organe', 'Paramètre', '1 point', '2 points', '3 points', '4 points'], [
    ['Respiration', 'PaO2/FiO2 (mmHg)', '< 400', '< 300', '< 200 avec assistance', '< 100 avec assistance'],
    ['Coagulation', 'Plaquettes (G/L)', '< 150', '< 100', '< 50', '< 20'],
    ['Foie', 'Bilirubine (µmol/L)', '20–32', '33–101', '102–204', '> 204'],
    ['Circulation', 'PAM ou vasopresseur', 'PAM < 70 mmHg', 'Dopamine ≤ 5 µg/kg/min ou dobutamine', 'Noradrénaline ≤ 0,1 µg/kg/min', 'Noradrénaline > 0,1 µg/kg/min'],
    ['Cerveau', 'Score de Glasgow', '13–14', '10–12', '6–9', '< 6'],
    ['Rein', 'Créatinine (µmol/L) ou diurèse', '110–170', '171–299', '300–440 ou < 500 mL/j', '> 440 ou < 200 mL/j'],
   ], 'Vincent 1996, repris par Sepsis-3. Correction de l’audit : l’original donnait 110–299 µmol/L pour 2 points rénaux.') +
   P('Exemple de l’original recalculé : PAM 61 mmHg (1 point), plaquettes 95 G/L (2 points), créatinine 185 µmol/L (2 points), Glasgow 13 (1 point). Le SOFA vaut donc 6, et non 5 ; il s’agit d’un sepsis selon Sepsis-3.', 95, 4), 95, 4)))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin évalue d’abord l’urgence vitale : respiration, pression, conscience, lactate. '
   f'Il cherche ensuite le {FOYER}, par ordre de fréquence : poumon, urine, abdomen, peau, cathéter, endocarde. '
   'Il pense enfin aux causes non infectieuses de défaillance (embolie pulmonaire, pancréatite, insuffisance surrénalienne).', 5, 92) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même unité : cas pour 100 000 habitants par an)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Sepsis codé à l’hôpital (Suisse)' + PR('240/100 000 par an', 92), 'Malaise, confusion, tachypnée, hypotension', 'Lactate, SOFA, hémocultures'],
    ['Bactériémie (Europe et Amérique du Nord)' + PR('113–204/100 000 par an', 93), 'Frissons, fièvre ou hypothermie', 'Hémocultures'],
    ['Pneumonie communautaire (Europe)' + PR('107–120/100 000 par an', 67), 'Toux, tachypnée, crépitants, parfois sans fièvre', 'Radiographie du thorax'],
    ['Légionellose (Suisse)' + PR('6,7/100 000 par an', 68), 'Pneumonie, diarrhée, hyponatrémie', 'Antigène urinaire'],
    ['Endocardite infectieuse (monde, 2019)' + PR('13,8/100 000 par an', 11), 'Souffle, valve prothétique, fièvre prolongée', 'Hémocultures, échocardiographie'],
    ['Méningococcie (Suisse)' + PR('0,4/100 000 par an', 68), 'Purpura, céphalées, raideur de nuque', 'Hémocultures, ponction lombaire'],
    ['Pyélonéphrite obstructive, cholangite', 'Douleur lombaire ou de l’hypocondre droit', 'ECBU, échographie'],
   ]) + P('Les fréquences ne sont pas des probabilités devant un patient donné. Pour la pyélonéphrite obstructive et la cholangite, aucune incidence comparable n’a été retrouvée.', 92, 93, 67, 68, 11))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien cherche les frissons, la toux, les brûlures urinaires, la douleur abdominale et les plaies. '
   'Il relève le terrain : âge, diabète, cancer, immunosuppression, sonde, cathéter, intervention récente.', 5, 6) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Avez-vous eu des frissons ?', 'Les frissons évoquent une bactériémie.', 'Hémocultures immédiates.'],
    ['Toussez-vous, êtes-vous essoufflé ?', 'Pneumonie, premier foyer du sepsis.', 'Radiographie, antigènes urinaires.'],
    ['Avez-vous des brûlures en urinant, une sonde ?', 'Infection urinaire, obstacle.', 'ECBU, échographie.'],
    ['Avez-vous mal au ventre ?', 'Cholangite, diverticulite, abcès.', 'Échographie ou scanner.'],
    ['Le comportement a-t-il changé selon les proches ?', 'Confusion, premier signe chez la personne âgée.', 'Glasgow, NEWS2.'],
    ['Prenez-vous un immunosuppresseur ?', 'Fièvre absente, germes inhabituels.', 'Antibiothérapie plus large.'],
   ])) +
 U('<b>Drapeaux rouges (urgence, 144)</b> : NEWS2 ≥ 5, fréquence respiratoire ≥ 22/min, PAS ≤ 100 mmHg, confusion nouvelle, marbrures, oligurie < 0,5 mL/kg/h, lactate > 2 mmol/L, purpura.', 6, 4, 5)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure toutes les constantes : fréquence respiratoire, saturation, pression, pouls, température et conscience. '
   'Il examine la peau, les poumons, l’abdomen, les fosses lombaires, les points d’appui et les cathéters. '
   'L’absence de fièvre ne suffit pas à exclure un sepsis chez la personne âgée.', 6, 5) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Fréquence respiratoire sur 1 minute', '12–20/min', '≥ 22/min : signe précoce de sepsis'],
    ['Pression et PAM', 'PAM ≥ 65 mmHg', 'PAS ≤ 100 mmHg : gravité ; PAM < 65 mmHg : hypoperfusion'],
    ['Temps de recoloration capillaire', '≤ 3 secondes', '> 3 secondes, marbrures : hypoperfusion'],
    ['Auscultation pulmonaire', 'Murmure symétrique', 'Crépitants localisés : pneumonie'],
    ['Percussion des fosses lombaires', 'Indolore', 'Douleur : pyélonéphrite'],
    ['Peau, points d’appui, cathéters', 'Intacts', 'Escarre infectée, cellulite, rougeur au point d’entrée'],
   ]) + P('Le score NEWS2 additionne ces constantes ; un score ≥ 5 impose une évaluation urgente, et ≥ 7 une réponse d’urgence.', 6))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont le malaise, la faiblesse, les frissons et la confusion. '
   'Les signes physiques sont la tachypnée, la tachycardie, l’hypotension, les marbrures et l’oligurie. '
   'Chez la personne âgée, le sepsis se présente souvent par une chute ou un déclin fonctionnel.', 5, 6) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Gravité'], [
    ['Sepsis', 'Infection + dysfonction : confusion, tachypnée, oligurie', 'SOFA ≥ 2'],
    ['Choc septique', 'Hypotension malgré remplissage, lactate élevé', 'Mortalité hospitalière 32,6 % en Suisse'],
    ['Défaillance multiviscérale', 'Rein, foie, coagulation, poumon atteints', 'Soins intensifs'],
    ['Déclin fonctionnel aigu de la personne âgée', 'Perte d’autonomie, refus de manger, chutes', 'Chercher une infection'],
   ]) + P('Termes : ' + T('marbrures', 'Les marbrures sont des taches violacées en réseau sur les genoux ; elles traduisent une mauvaise perfusion de la peau.') + ', ' + T('oligurie', 'L’oligurie est une diurèse inférieure à 0,5 mL/kg/h ; elle traduit une baisse de la perfusion du rein.') + ', ' + T('tachypnée', 'La tachypnée est une fréquence respiratoire élevée ; dans le sepsis, elle compense l’acidose lactique.') + ', ' + T('frissons solennels', 'Les frissons solennels sont des tremblements intenses avec claquement des dents ; ils accompagnent le passage de bactéries dans le sang.') + ', ' + T('purpura', 'Le purpura est une tache rouge qui ne s’efface pas à la pression ; avec de la fièvre, il fait craindre une méningococcie.') + '.', 92, 4))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le critère Sepsis-3 (2016) associe une infection suspectée ou prouvée et une hausse aiguë du SOFA ≥ 2 points. '
   'Le qSOFA (≥ 2 critères sur 3 : FR ≥ 22/min, confusion, PAS ≤ 100 mmHg) ne suffit pas comme outil unique de dépistage. '
   'La recommandation de la Surviving Sepsis Campaign 2021 préfère le NEWS2 ou les critères de SIRS pour le dépistage, et utilise un lactate en mmol/L.', 4, 5, 6) +
 F('Outils et seuils',
   TAB(['Outil', 'Seuil', 'Usage'], [
    ['SOFA', 'Hausse ≥ 2 points', 'Définition du sepsis'],
    ['qSOFA', '≥ 2 critères', 'Pronostic ; dépistage seul déconseillé (SSC 2021)'],
    ['NEWS2', '≥ 5 : évaluation urgente ; ≥ 7 : urgence', 'Dépistage hors des soins intensifs'],
    ['Lactate', '> 2 mmol/L', 'Hypoperfusion ; > 4 mmol/L : remplissage immédiat'],
   ], 'Correction de l’original : le qSOFA n’est pas couplé au lactate dans Sepsis-3.'), 4, 5, 6)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Hémocultures, 2 paires prélevées avant l’antibiotique', 'Bactériémie et sensibilité du germe', 'Positives dans environ un tiers des sepsis ; valeur exacte non sourcée', 'Résultat en 24–72 heures'],
    ['Culture du foyer (urine, crachat, pus)', 'Germe du foyer', 'Dépend du prélèvement', 'Contamination'],
    ['Lactate', 'Hypoperfusion', 'Marqueur de gravité, non spécifique', 'Élevé aussi après convulsion ou sous metformine'],
   ]), 5) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Hémocultures, lactate, NFS, CRP, créatinine, bilirubine, ionogramme, gazométrie', 'Tout sepsis suspecté'],
    ['Première', 'Bandelette et ECBU, radiographie du thorax', 'Foyer non évident'],
    ['Seconde', 'Échographie ou scanner abdominal', 'Douleur abdominale, cholestase, obstacle urinaire'],
    ['Seconde', 'Échocardiographie transthoracique puis transœsophagienne', 'Hémocultures à Staphylococcus aureus ou streptocoque'],
    ['Seconde', 'PCR rapide sur hémoculture positive', 'Identification du germe et des gènes de résistance'],
   ]), 5, 11) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Les <b>hémocultures</b> se prélèvent avant l’antibiotique, mais leur prélèvement ne doit pas retarder l’antibiotique au-delà d’une heure.',
       'Le <b>lactate</b> se mesure à l’arrivée, puis à 2–4 heures s’il était > 2 mmol/L.',
       'L’<b>ECBU</b> se prélève au milieu du jet ou sur une sonde neuve.',
       'Le <b>scanner</b> injecté demande la créatinine ; l’insuffisance rénale aiguë n’est pas une contre-indication absolue en urgence.']), 5) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Lactate', '> 2 mmol/L', 'Hypoperfusion', 'Remplissage, contrôle à 2–4 heures'],
    ['Lactate', '> 4 mmol/L', 'Hypoperfusion grave', 'Cristalloïdes 30 mL/kg dans les 3 heures'],
    ['Leucocytes', '> 12 ou < 4 G/L', 'Réponse inflammatoire', 'Ne pose pas à lui seul le diagnostic'],
    ['Procalcitonine', 'Valeur élevée', 'Infection bactérienne plus probable', 'Aide à l’arrêt de l’antibiotique, pas à son début'],
    ['Hémocultures à Staphylococcus aureus', 'Une seule positive', 'Jamais un contaminant', 'Échocardiographie, avis infectiologique'],
   ]), 5, 11) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (staphylocoque à coagulase négative dans une seule paire)', 'Contaminant probable ; répéter'],
    ['Résultat négatif mais clinique typique', 'Antibiotique déjà donné ; chercher le foyer par imagerie'],
    ['Résultat limite (lactate 2–4 mmol/L, pression normale)', 'Sepsis possible : surveillance rapprochée'],
    ['Grossesse', 'Échographie d’abord ; avis obstétrical'],
    ['Enfant', 'Seuils pédiatriques (scores de Phoenix) ; avis pédiatrique'],
    ['Insuffisance rénale (DFGe bas)', 'Adapter les doses après la première, qui reste pleine'],
    ['Allergie à l’iode, pacemaker ou IRM', 'Allergie aux produits de contraste : prémédication ou échographie'],
   ]), 5))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Les hémocultures identifient le germe, et le lactate mesure la gravité. '
   'La biologie compte les organes atteints (SOFA), et l’imagerie cherche le foyer. '
   'Aucun examen ne doit retarder l’antibiotique.', 5, 4) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si un choc ou un sepsis probable est présent, alors le médecin donne l’antibiotique dans l’heure après les hémocultures. '
   'Si le sepsis est seulement possible sans choc, alors il complète le bilan et donne l’antibiotique dans les 3 heures si le doute persiste. '
   'Si un foyer drainable est trouvé, alors il le fait drainer au plus vite.', 5) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Choc ou sepsis probable', 'Hémocultures, antibiotique dans l’heure, cristalloïdes', 'Lactate à 2–4 heures'],
    ['PAM < 65 mmHg après remplissage', 'Noradrénaline, soins intensifs', 'Monitorage continu'],
    ['Sepsis possible sans choc', 'Bilan rapide, antibiotique dans les 3 heures', 'Réévaluation à 1 heure'],
    ['Obstacle urinaire ou biliaire', 'Sonde JJ, néphrostomie, drainage biliaire', 'Contrôle clinique et lactate'],
    ['Noradrénaline ≥ 0,25 µg/kg/min depuis ≥ 4 heures', 'Hydrocortisone 200 mg/j', 'Sevrage dès l’arrêt des vasopresseurs'],
   ]), 5)))
MED = F('Fiches médicamenteuses (posologies AIPS et recommandations)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Ceftriaxone, Rocephin® (céphalosporine de 3e génération)', 'Bloque la paroi bactérienne ; demi-vie ≈ 8 heures, élimination biliaire et rénale', '2 g IV une fois par jour (méningite : 2 g toutes les 12 heures)', 'Allergie, boue biliaire ; ne pas mélanger au calcium IV chez le nouveau-né'],
   ['Amoxicilline-acide clavulanique, Co-Amoxi® (pénicilline + inhibiteur)', 'Bloque la paroi ; demi-vie ≈ 1 heure', '2,2 g IV toutes les 8 heures', 'Diarrhée, hépatite cholestatique ; allergie'],
   ['Pipéracilline-tazobactam, Tazobac® (pénicilline à large spectre)', 'Spectre incluant Pseudomonas ; demi-vie ≈ 1 heure', '4,5 g IV toutes les 6–8 heures, perfusion prolongée possible', 'Allergie, néphrotoxicité avec la vancomycine'],
   ['Noradrénaline (vasopresseur)', 'Contracte les artérioles (récepteurs alpha) ; action en quelques minutes', 'Perfusion continue titrée pour une PAM ≥ 65 mmHg ; voie périphérique possible au début', 'Ischémie des extrémités, arythmie'],
   ['Hydrocortisone, Solu-Cortef® (corticoïde)', 'Restaure la réponse aux vasopresseurs', '200 mg par jour (50 mg IV toutes les 6 heures)', 'Hyperglycémie, infections'],
  ]) + P('Les choix d’antibiotiques suivent les recommandations de la Société suisse d’infectiologie et l’épidémiologie locale ; l’audit n’a pas rouvert les fiches correspondantes. L’original indiquait la ceftazidime pour le sepsis nosocomial ; elle reste un choix selon l’écologie locale.', 35, 5, 1))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge traite la cause et restaure la perfusion en même temps, parce que chaque heure de retard aggrave le pronostic du choc. '
   'Elle associe antibiotique, contrôle du foyer, remplissage et vasopresseur. '
   'Elle réévalue l’antibiotique chaque jour selon les cultures.', 5) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans une forme compliquée (choc), le but est une PAM ≥ 65 mmHg, une baisse du lactate et une diurèse ≥ 0,5 mL/kg/h dans les premières heures. Dans une forme non compliquée (infection sans dysfonction), le but est de traiter le foyer et d’éviter l’évolution vers le sepsis.', 5), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Forme compliquée, en urgence</b> : 144 ; oxygène si saturation < 92 % ; 2 paires d’hémocultures ; antibiotique IV dans l’heure ; cristalloïdes balancés 30 mL/kg dans les 3 heures si hypoperfusion ; noradrénaline si PAM < 65 mmHg.',
         '<b>B. Contrôle du foyer</b> : drainage d’un abcès, d’un obstacle urinaire ou biliaire, retrait d’un cathéter infecté, dans les 6–12 heures.',
         '<b>C. Forme non compliquée, en ambulatoire</b> : mesures générales (hydratation, antipyrétique, éducation sur les signes d’alerte), antibiotique oral selon le foyer, contrôle à 48 heures.',
         '<b>D. Désescalade</b> : adaptation à l’antibiogramme, durée courte selon le foyer, arrêt guidé par la clinique et la procalcitonine.']), 5, 35) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('La conduite automobile reprend après la récupération physique et cognitive.',
            'Les survivants peuvent garder fatigue, troubles de mémoire et anxiété ; une réadaptation se discute, et l’AI peut intervenir en cas d’incapacité durable.'), 60, 61, 92) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Sepsis maternel : avis obstétrical immédiat ; éviter les antibiotiques contre-indiqués'],
      ['Personne âgée', 'Présentation sans fièvre ; seuil bas pour les hémocultures'],
      ['Enfant', 'Critères pédiatriques ; remplissage par bolus de 10–20 mL/kg'],
      ['Neutropénie', 'Antibiotique anti-Pseudomonas dans l’heure'],
      ['Insuffisance rénale (DFGe)', 'Première dose pleine, puis adaptation'],
     ]), 5), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['PAM, fréquence, saturation, conscience', 'En continu les premières heures', 'PAM < 65 mmHg : vasopresseur'],
    ['Lactate', 'À 2–4 heures', 'Lactate qui ne baisse pas : réévaluer le foyer et la perfusion'],
    ['Diurèse', 'Horaire', '< 0,5 mL/kg/h : remplissage ou avis'],
    ['Cultures', 'À 48–72 heures', 'Désescalade'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Constantes stables sans vasopresseur.', 'Foyer contrôlé.', 'Relais oral possible.', 'Suivi planifié, avec attention aux séquelles du sepsis.']), 5) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('En Suisse, la mortalité hospitalière est de 18,9 % et atteint près de 30 % à un an après 65 ans. Les PCR multiplex donnent le germe et certains gènes de résistance en environ une heure, mais sur une hémoculture déjà positive, et non sur le sang total comme l’affirmait l’original. La recherche 2026 évalue des biomarqueurs de réponse immunitaire pour personnaliser le traitement.', 92), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur la vaccination contre la grippe et le pneumocoque selon le plan suisse de vaccination. '
   'La prévention secondaire retire les sondes et cathéters inutiles et forme les équipes à reconnaître le sepsis. '
   'La prévention tertiaire organise le suivi des survivants ; le plan national suisse contre le sepsis soutient ces mesures avec l’OFSP.', 3, 94, 92) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Vaccination, hygiène des mains, asepsie des gestes'],
    ['Secondaire', 'Dépistage par NEWS2, traitement précoce'],
    ['Tertiaire', 'Réadaptation, suivi des séquelles'],
   ]))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin compte la fréquence respiratoire chez tout patient âgé avec un malaise. '
   'Il mesure le lactate et calcule le SOFA. '
   'Il prélève les hémocultures, puis donne l’antibiotique dans l’heure en cas de choc ou de sepsis probable. '
   'Il cherche et draine le foyer. '
   'Il n’attend pas l’hypotension pour agir.', 5, 4)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Attendre une PAS < 90 mmHg pour traiter.', 'Le lactate et la tachypnée apparaissent avant l’hypotension.'],
  ['Exclure un sepsis faute de fièvre.', 'La personne âgée peut être hypotherme.'],
  ['Utiliser le qSOFA seul pour dépister.', 'NEWS2 ou SIRS pour le dépistage ; SOFA pour la définition.'],
  ['Donner un bêtabloquant pour une tachycardie septique.', 'La tachycardie compense ; traiter le sepsis.'],
  ['Oublier de drainer un obstacle urinaire.', 'Sonde JJ ou néphrostomie en urgence.'],
 ]) + P('Ces pièges reprennent Sepsis-3 et la Surviving Sepsis Campaign 2021.', 4, 5)))
CTX = {'_prefixe': 'Dans le sepsis occulte',
 'hemoc': 'Deux paires d’hémocultures avant l’antibiotique identifient le germe.',
 'lact': 'Un lactate > 2 mmol/L signe une hypoperfusion ; > 4 mmol/L impose un remplissage immédiat.',
 'nfs': 'Les plaquettes entrent dans le SOFA ; une leucopénie est un signe de gravité.',
 'crp': 'La CRP suit l’évolution, mais ne pose pas le diagnostic.',
 'pct': 'La procalcitonine aide surtout à arrêter l’antibiotique.',
 'creat': 'La créatinine mesure l’atteinte rénale du SOFA.',
 'hep': 'La bilirubine mesure l’atteinte hépatique du SOFA ; une cholestase oriente vers une cholangite.',
 'gds': 'La gazométrie mesure le rapport PaO2/FiO2 et l’acidose.',
 'ecbu': 'L’ECBU cherche une infection urinaire, foyer fréquent chez la personne âgée.',
 'radio': 'La radiographie du thorax cherche une pneumonie.',
 'tdm': 'Le scanner cherche un abcès ou un obstacle.',
 'echoabdo': 'L’échographie cherche une dilatation des voies urinaires ou biliaires.',
 'echocoeur': 'L’échocardiographie cherche une végétation si les hémocultures poussent à Staphylococcus aureus ou à streptocoque.',
 'coag': 'La coagulation cherche une coagulation intravasculaire disséminée.',
 'iono': 'L’ionogramme cherche une hyponatrémie (légionellose) et guide le remplissage.',
 'pcr': 'La PCR multiplex sur hémoculture positive identifie vite le germe.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
