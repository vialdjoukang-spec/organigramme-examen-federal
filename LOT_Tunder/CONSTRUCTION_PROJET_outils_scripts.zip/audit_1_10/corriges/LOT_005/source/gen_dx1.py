# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.1 · Infections virales aiguës et syndrome grippal (LOT 5, original V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('dx1')
M = meta('dx1', 'DX.1', 'Syndrome grippal', 'Infections virales aiguës et syndrome grippal (ILI)', 'LOT_005_DX1_Infections_virales_syndrome_grippal_AUDITÉ.html')
IFN = T('interféron de type I', 'Les interférons de type I (alpha et bêta) sont des cytokines libérées par les cellules infectées ; ils bloquent la réplication virale dans les cellules voisines et provoquent fièvre, fatigue et courbatures.')
PYRO = T('pyrogène endogène', 'Un pyrogène endogène est une cytokine (interleukine 1, interleukine 6, TNF-alpha) qui élève la consigne thermique de l’hypothalamus par la prostaglandine E2 ; le corps produit alors de la chaleur (frissons) jusqu’à atteindre la nouvelle consigne.')
NEUR = T('neuraminidase', 'La neuraminidase est une enzyme de surface du virus influenza ; elle coupe l’acide sialique qui retient les nouveaux virus à la cellule et leur permet de partir infecter d’autres cellules.')
SURINF = T('surinfection bactérienne', 'Une surinfection bactérienne est une infection par une bactérie (pneumocoque, Staphylococcus aureus, Haemophilus) qui profite d’un épithélium respiratoire abîmé par le virus ; elle survient typiquement après une amélioration initiale.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('Le syndrome grippal, ou « influenza-like illness » (ILI), est un début brutal de fièvre avec sensation de maladie, courbatures et céphalées, accompagné de toux ou de mal de gorge. '
   'Il traduit la réponse immunitaire générale à un virus respiratoire, le plus souvent influenza, SARS-CoV-2 ou le virus respiratoire syncytial (VRS). '
   'C’est un diagnostic de syndrome, contrairement à la grippe, qui est un diagnostic de virus prouvé par un test.', 2, 8) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Syndrome grippal (ILI)', 'Début soudain, fièvre > 38 °C, toux ou mal de gorge (définition Sentinella)', 'Grippe confirmée par PCR'],
    ['Grippe (influenza)', 'Infection prouvée par le virus influenza A ou B', 'Rhume (rhinovirus) sans fièvre élevée'],
    ['Rhume (rhinopharyngite)', 'Atteinte nasale et pharyngée, sans atteinte générale marquée', 'Syndrome grippal'],
    ['Sepsis', 'Dysfonction d’organe menaçant la vie, due à une réponse déréglée à une infection', 'Fièvre bien tolérée'],
    ['Surinfection bactérienne', 'Infection bactérienne secondaire d’un épithélium lésé par le virus', 'Crachats colorés sans aggravation, fréquents et banals'],
   ]) + P(f'La fièvre et la fatigue ne viennent pas du virus lui-même : elles viennent de la réponse de l’hôte, en particulier de l’{IFN}.', 8))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, l’OFSP estime que la grippe cause chaque année 50 000 à 250 000 consultations médicales selon Sentinella, plusieurs milliers d’hospitalisations et souvent plusieurs centaines de décès. '
   'Une étude suisse sur trois saisons (2016–2019) compte en moyenne 203 090 consultations pour syndrome grippal, 4 944 hospitalisations et 1 355 décès en excès par saison chez l’adulte ; 35,8 % des personnes de 65 ans et plus étaient vaccinées. '
   'En Europe et dans le monde, l’OMS estime 3 à 5 millions de formes graves et 290 000 à 650 000 décès respiratoires par an.', 2, 63, 8) +
 F('Chiffres, terrain et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Consultations pour syndrome grippal (Suisse)', '3 611 pour 100 000 habitants sur la dernière saison publiée', 'Sentinella, extrapolation nationale'],
    ['Hospitalisations dues à la grippe (adultes, Suisse)', '4 944 par saison en moyenne ; 2 % décèdent à l’hôpital', 'Trois saisons, 2016–2019'],
    ['Couverture vaccinale ≥ 65 ans (Suisse)', '35,8 %', 'Même étude ; loin de l’objectif'],
    ['Saison', 'Décembre à mars le plus souvent', 'Circulation simultanée possible avec SARS-CoV-2 et VRS'],
    ['Répartition suisse « 35 % des plaintes de malaise »', 'Non retrouvée dans la littérature', 'Chiffre de l’original V5, retiré ou à vérifier'],
   ]) + P('Le terrain change le pronostic : la mortalité se concentre chez les personnes âgées, les malades chroniques et les femmes enceintes. Chez l’adulte jeune sans comorbidité, la guérison survient en général en une à deux semaines.', 2, 63))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Le virus entre par les voies respiratoires et se multiplie dans les cellules ciliées de l’épithélium. '
   f'Les cellules infectées libèrent des interférons et des cytokines, qui agissent comme un {PYRO} et provoquent fièvre, frissons, courbatures et fatigue. '
   'La lésion de l’épithélium explique la toux et ouvre la porte à une surinfection bactérienne ; chaque traitement vise un maillon précis.', 8) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les voies respiratoires sont tapissées d’un épithélium cilié couvert de mucus ; il piège et évacue les particules.'],
    ['Physiologie', 'Pourquoi on ne tombe pas toujours malade : le mucus, les cils et l’immunité innée éliminent la plupart des virus avant qu’ils se multiplient.'],
    ['Physiopathologie', 'Le virus se fixe à l’acide sialique (influenza) ou au récepteur ACE2 (SARS-CoV-2), se multiplie, puis détruit la cellule. Les cytokines diffusent dans le sang et élèvent la consigne thermique de l’hypothalamus.'],
    ['Clinique', 'D’où le début brutal, la fièvre avec frissons, les courbatures, la toux sèche et la sensation de maladie intense.'],
    ['Examens', 'Comme le virus se trouve dans le nez et la gorge, on le cherche par un frottis nasopharyngé (PCR ou test antigénique) ; la biologie sanguine ne sert qu’à chercher une complication.'],
    ['Traitement', 'On agit sur trois maillons : la fièvre et la douleur (paracétamol), la sortie des virus de la cellule (inhibiteur de la neuraminidase) et, pour le SARS-CoV-2, la protéase virale (nirmatrelvir).'],
   ]), 8, 1) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme (lésion)', 'Exploration', 'Cible thérapeutique'], [
    ['Réplication virale dans l’épithélium', 'PCR multiplex sur frottis nasopharyngé', f'Inhibiteur de la {NEUR} (oseltamivir) ou de l’endonucléase (baloxavir)'],
    ['Libération de cytokines (fièvre, douleur)', 'Température, fréquence cardiaque', 'Paracétamol, ibuprofène'],
    ['Lésion épithéliale, surinfection', 'Auscultation, radiographie thoracique, CRP', 'Antibiotique seulement si la surinfection est probable'],
    ['Réponse inflammatoire déréglée (sepsis)', 'Score qSOFA, lactate, hémocultures', 'Remplissage, antibiotique dans l’heure, oxygène'],
    ['Hypoxémie (pneumonie virale)', 'Oxymétrie de pouls', 'Oxygène, hospitalisation'],
   ]) + P(f'Une {SURINF} donne typiquement une courbe en deux temps : amélioration, puis nouvelle fièvre vers le 5e jour avec expectoration purulente.', 8))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin cherche d’abord une urgence : sepsis, méningococcie, pneumonie hypoxémiante ou paludisme chez un voyageur. '
   'Il classe ensuite le tableau : virose simple, virose chez un patient à risque, ou infection bactérienne. '
   'Il demande toujours les voyages des trois derniers mois, puis il décide si un test viral change la conduite.', 2, 4, 55) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même unité : cas pour 100 000 habitants par an en Suisse)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Syndrome grippal (consultations)' + PR('≈ 3 600 / 100 000', 2), 'Épidémie saisonnière, début brutal, toux, courbatures', 'PCR multiplex si elle change la conduite'],
    ['Pneumonie communautaire' + PR('≈ 107–120 / 100 000 (Europe)', 67), 'Fièvre, toux, crépitants localisés, dyspnée', 'Radiographie thoracique, CRP'],
    ['Maladie invasive à pneumocoque' + PR('11,9 / 100 000', 68), 'Pneumonie bactériémique, souvent en deux temps', 'Hémocultures'],
    ['Légionellose' + PR('6,7 / 100 000', 68), 'Été, âge > 50 ans, diarrhée, hyponatrémie, pneumonie', 'Antigène urinaire, PCR'],
    ['Paludisme importé' + PR('3,0 / 100 000', 69), 'Retour de zone tropicale, fièvre sans foyer, thrombopénie', 'Frottis sanguin et goutte épaisse le jour même'],
    ['Dengue importée' + PR('2,0 / 100 000', 69), 'Retour de zone tropicale, douleurs rétro-orbitaires, éruption', 'Antigène NS1, sérologie, PCR'],
    ['Méningococcie invasive' + PR('0,4 / 100 000', 68), 'Purpura, raideur de nuque, choc rapide', 'Hémocultures, ponction lombaire sans retarder l’antibiotique'],
   ]) + P('Ces chiffres décrivent la population suisse (cas déclarés ou consultations pour 100 000 habitants par an) ; la pneumonie est une incidence européenne. Ils ne sont pas des probabilités devant un patient donné : en hiver, sans voyage ni signe de gravité, la virose est de loin la plus probable.', 2, 67, 68, 69))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien date le début, souvent « d’une heure à l’autre » dans la grippe, et recherche les contacts malades. '
   'Il précise le statut vaccinal, les comorbidités, la grossesse, les traitements et les voyages, car ils définissent le risque de complication.', 2, 3, 55) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Quand exactement cela a-t-il commencé ?', 'Le début brutal est typique de la grippe.', 'Un antiviral n’est utile qu’au début (≤ 48 heures).'],
    ['Avez-vous voyagé hors d’Europe ces trois derniers mois ?', 'Le paludisme imite la grippe.', 'Frottis et goutte épaisse le jour même.'],
    ['Avez-vous plus de 65 ans, une maladie chronique, une grossesse ?', 'Ce sont les groupes à risque de complication.', 'Test viral et antiviral envisagés.'],
    ['Avez-vous du mal à respirer au repos ?', 'Une pneumonie ou une hypoxémie est possible.', 'Oxymétrie, radiographie, hospitalisation.'],
    ['La fièvre est-elle revenue après une amélioration ?', 'C’est le signe de la surinfection.', 'Examen pulmonaire, CRP, radiographie.'],
    ['Êtes-vous vacciné contre la grippe et le COVID-19 ?', 'La vaccination réduit les formes graves.', 'Ne suffit pas à exclure le diagnostic.'],
    ['Quels médicaments prenez-vous ?', 'Le nirmatrelvir-ritonavir a de nombreuses interactions.', 'Choix et adaptation de l’antiviral.'],
   ])) +
 U('<b>Drapeaux rouges, qui imposent une hospitalisation ou l’appel du 144</b> : dyspnée de repos ou SpO₂ < 92 %, confusion, pression systolique ≤ 100 mmHg, fréquence respiratoire ≥ 22/min (qSOFA ≥ 2), purpura ou raideur de nuque, fièvre au retour d’une zone tropicale, aggravation en deux temps, déshydratation chez la personne âgée.', 4, 55, 7)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure d’abord les signes vitaux : température, fréquence cardiaque, pression artérielle, fréquence respiratoire, saturation et état de conscience. '
   'Il ausculte les poumons, examine la gorge, cherche une raideur de nuque et inspecte toute la peau à la recherche d’un purpura. '
   'Un examen normal n’exclut pas une pneumonie débutante, car l’auscultation a une sensibilité limitée.', 4, 6, 67) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Signes vitaux et score NEWS2', 'NEWS2 0–4', 'NEWS2 ≥ 5 : évaluation urgente ; ≥ 7 : réponse d’urgence'],
    ['Indice de choc (fréquence cardiaque / pression systolique)', '0,5–0,7', '≥ 1 : hypovolémie ou sepsis possibles'],
    ['Auscultation pulmonaire', 'Murmure vésiculaire symétrique', 'Crépitants localisés, souffle tubaire : pneumonie'],
    ['Examen de la gorge', 'Érythème modéré sans exsudat', 'Exsudat, adénopathies douloureuses : angine bactérienne possible'],
    ['Raideur de nuque (signes de Kernig, Brudzinski)', 'Nuque souple', 'Raideur : méningite ; ces signes ont une faible sensibilité'],
    ['Peau', 'Pas de purpura', 'Purpura qui ne s’efface pas à la vitropression : méningococcie, urgence absolue'],
   ]) + P('La valeur de l’examen tient surtout aux signes vitaux, que le score NEWS2 résume ; un purpura fébrile impose l’antibiotique immédiat.', 6, 64, 4))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la sensation de maladie, les frissons, les courbatures, les céphalées, la toux sèche et le mal de gorge. '
   'Les signes physiques sont la fièvre, la tachycardie proportionnée, une rougeur pharyngée et une auscultation souvent normale. '
   'Le médecin regroupe ces signes en syndromes, car chaque syndrome oriente vers une conduite différente.', 2, 8) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Mécanisme et conduite'], [
    ['Syndrome grippal systémique', 'Fièvre 38,5–40 °C, frissons, courbatures, céphalées', 'Cytokines ; traitement symptomatique'],
    ['Syndrome catarrhal', 'Rhinorrhée, mal de gorge, toux sèche', 'Atteinte de l’épithélium ; pas d’antibiotique'],
    ['Syndrome de condensation pulmonaire', 'Crépitants localisés, souffle tubaire, matité', 'Pneumonie ; radiographie, CRP'],
    ['Syndrome septique', 'Hypotension, confusion, polypnée, marbrures', 'Sepsis ; 144, antibiotique dans l’heure'],
    ['Syndrome méningé', 'Céphalées, raideur de nuque, photophobie, vomissements', 'Méningite ; hémocultures, antibiotique, ponction lombaire'],
   ]) + P('Termes : ' + T('marbrures', 'Les marbrures sont des taches violacées de la peau, surtout aux genoux ; elles traduisent une mauvaise perfusion de la peau et un état de choc.') + ', ' + T('polypnée', 'La polypnée est une respiration trop rapide ; chez l’adulte, une fréquence ≥ 22/min compte dans le score qSOFA.') + ', ' + T('souffle tubaire', 'Le souffle tubaire est un bruit respiratoire rude entendu à travers un poumon devenu plein (condensé) ; il oriente vers une pneumonie.') + '.', 4, 6))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Selon la définition Sentinella de l’OFSP, un cas de syndrome grippal associe un début soudain, une fièvre > 38 °C et de la toux ou un mal de gorge. '
   'Cette définition sert à la surveillance ; elle ne suffit pas à prouver la grippe, que seule une PCR ou un test antigénique confirme. '
   'Selon les recommandations (CURB-65, Lim 2003, et qSOFA, Sepsis-3 2016), un score de gravité décide du lieu de soins.', 2, 7, 4) +
 F('Définition Sentinella et score CURB-65',
   TAB(['Critère (1 point chacun)', 'Seuil et unité'], [
    ['Confusion', 'Désorientation nouvelle'],
    ['Urée', '> 7 mmol/L (le score CRB-65 se passe de ce critère au cabinet)'],
    ['Fréquence respiratoire', '≥ 30/min'],
    ['Pression artérielle', 'Systolique < 90 mmHg ou diastolique ≤ 60 mmHg'],
    ['Âge', '≥ 65 ans'],
   ], 'CURB-65 (Lim 2003, British Thoracic Society) : 0–1 point, mortalité ≈ 1,5 % à 30 jours ; 2 points, ≈ 9,2 % ; ≥ 3 points, ≈ 22 %.') +
   P('Le score qSOFA (Sepsis-3, 2016) compte la fréquence respiratoire ≥ 22/min, la pression systolique ≤ 100 mmHg et l’altération de la conscience ; ≥ 2 points signale un risque de mauvaise évolution, mais un qSOFA bas ne suffit pas à exclure un sepsis.', 4, 5), 7, 2)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['RT-PCR sur frottis nasopharyngé', 'Gold standard : présence du génome viral (influenza, SARS-CoV-2, VRS)', 'Tests rapides moléculaires : sensibilité ≈ 92 %, spécificité ≈ 99 % par rapport à la RT-PCR de laboratoire', 'Ne distingue pas portage et maladie'],
    ['Test antigénique rapide', 'Antigène viral en 15 minutes', 'Sensibilité ≈ 62 %, spécificité ≈ 98 % (grippe)', 'Un résultat négatif n’exclut pas la grippe'],
    ['Radiographie thoracique', 'Pneumonie (opacité)', 'Référence pratique de la pneumonie, sensibilité imparfaite au début', 'Irradiation faible ; grossesse : protéger, discuter l’échographie'],
   ]), 65, 66) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première (adulte jeune, sans signe de gravité)', 'Aucun examen', 'smarter medicine : pas d’examen qui ne change rien'],
    ['Première (patient à risque)', 'PCR multiplex ou test antigénique, oxymétrie de pouls', 'Décision d’antiviral dans les 48 heures'],
    ['Première (voyageur fébrile)', 'Frottis sanguin et goutte épaisse, hémogramme', 'Le jour même, à répéter si négatif'],
    ['Seconde', 'Radiographie thoracique, CRP, hémogramme', 'Crépitants, dyspnée, fièvre en deux temps'],
    ['Seconde (sepsis)', 'Hémocultures, lactate, créatinine, gaz du sang', 'qSOFA ≥ 2, NEWS2 ≥ 7, hypotension'],
   ]), 41, 55, 4) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Le <b>frottis nasopharyngé</b> se fait dans les premiers jours, quand la charge virale est maximale ; l’écouvillon va jusqu’au nasopharynx, tête légèrement inclinée en arrière.',
       'Les <b>hémocultures</b> (2 paires) se prélèvent avant l’antibiotique, mais sans le retarder au-delà d’une heure en cas de sepsis.',
       'Le <b>frottis sanguin et la goutte épaisse</b> ne demandent aucune préparation ; le délai de résultat doit être de quelques heures, et on répète l’examen à 12–24 heures s’il est négatif.',
       'Aucun examen n’exige d’être à jeun ; la grossesse se recherche (hCG) avant une radiographie chez une femme en âge de procréer.']), 5, 55) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['PCR influenza positive', 'Qualitatif', 'Grippe confirmée', 'Antiviral si patient à risque ou hospitalisé'],
    ['Test antigénique négatif en pleine épidémie', '—', 'N’exclut pas la grippe', 'Décision clinique ou PCR'],
    ['CRP', '< 20 mg/L : infection bactérienne peu probable ; > 100 mg/L : plus probable', 'Orientation seulement', 'Croiser avec la clinique et la radiographie'],
    ['Procalcitonine', '< 0,25 µg/L : antibiotique souvent évitable', 'Aide à la décision hospitalière', 'Jamais seule'],
    ['Lactate', '> 2 mmol/L', 'Hypoperfusion', 'Remplissage ; > 4 mmol/L : choc probable'],
    ['Goutte épaisse positive', 'Parasitémie en %', 'Paludisme', 'Hospitalisation si P. falciparum ou parasitémie élevée'],
   ]) + P('Les seuils de CRP et de procalcitonine sont des repères d’orientation, pas des seuils de décision isolés ; la conduite dépend de la clinique.', 5, 35)) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant avec la clinique', 'Portage possible ; réévaluer et chercher une co-infection bactérienne'],
    ['Résultat négatif mais clinique typique en épidémie', 'Traiter un patient à risque sans attendre'],
    ['Résultat limite (CRP 20–100 mg/L)', 'Réévaluation clinique à 24–48 heures'],
    ['Grossesse', 'Test viral recommandé ; radiographie possible avec protection, échographie pulmonaire en alternative'],
    ['Enfant', 'Frottis nasal ; seuils de fréquence respiratoire selon l’âge'],
    ['DFGe < 30 mL/min/1,73 m²', 'Examens sans contraste ; adapter oseltamivir et nirmatrelvir'],
    ['Allergie à l’iode, stimulateur cardiaque (pacemaker)', 'Sans objet pour ces examens ; scanner thoracique sans contraste si nécessaire'],
   ])))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Chez l’adulte jeune sans signe de gravité, aucun examen n’est nécessaire, car le résultat ne change pas la conduite. '
   'Chez le patient à risque, un test viral rapide décide d’un antiviral, et l’oxymétrie dépiste l’hypoxémie. '
   'Les examens sanguins, la radiographie et les hémocultures cherchent une complication bactérienne ou un sepsis.', 41, 5) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si un drapeau rouge est présent, alors le médecin oriente le patient vers l’hôpital ou appelle le 144. '
   'Si le patient revient d’une zone tropicale, alors il fait un frottis et une goutte épaisse le jour même. '
   'Sinon, il classe le patient selon le risque de complication, puis il décide du test et de l’antiviral.', 4, 55, 7) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['qSOFA ≥ 2, NEWS2 ≥ 7, purpura ou SpO₂ < 92 %', 'Hospitalisation ; hémocultures et antibiotique dans l’heure si sepsis', 'Réévaluation horaire'],
    ['Retour de zone tropicale', 'Frottis, goutte épaisse, hémogramme le jour même', 'Répéter à 12–24 heures si négatif'],
    ['Patient à risque, début ≤ 48 heures', 'PCR ou test rapide, puis antiviral', 'Appel à 48 heures'],
    ['Adulte jeune, pas de risque, CRB-65 = 0', 'Traitement symptomatique, arrêt de travail, consignes écrites', 'Reconsulter si aggravation'],
    ['Fièvre en deux temps, crépitants', 'Radiographie, CRP, antibiotique selon la SSI', 'Contrôle à 48–72 heures'],
   ]), 2, 35)))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Paracétamol, Dafalgan® (analgésique antipyrétique)', 'Inhibe la synthèse centrale des prostaglandines ; demi-vie ≈ 2 heures, métabolisme hépatique', '500–1000 mg toutes les 6–8 heures, maximum 4 g par jour ; dose maximale réduite si poids < 50 kg, alcoolisme chronique ou atteinte hépatique', 'Hépatotoxicité en surdosage ; contre-indiqué en insuffisance hépatique sévère ; prudence avec l’alcool'],
   ['Ibuprofène, Irfen® (anti-inflammatoire non stéroïdien)', 'Inhibe les cyclo-oxygénases 1 et 2 ; demi-vie ≈ 2 heures', '400 mg 3 fois par jour pendant 3 jours au maximum en automédication', 'Ulcère, insuffisance rénale aiguë si déshydratation ; contre-indiqué au 3e trimestre de grossesse et en insuffisance rénale sévère ; interaction avec anticoagulants et IECA'],
   ['Oseltamivir, Tamiflu® (inhibiteur de la neuraminidase)', 'Promédicament ; métabolite actif à élimination rénale, demi-vie 6–10 heures', '75 mg 2 fois par jour pendant 5 jours, à débuter dans les 48 heures ; clairance > 30–60 mL/min : 30 mg 2 fois par jour ; 10–30 mL/min : 30 mg 1 fois par jour', 'Nausées, vomissements (prendre avec un repas), rares troubles neuropsychiatriques ; pas d’interaction majeure'],
   ['Baloxavir marboxil, Xofluza® (inhibiteur de l’endonucléase cap-dépendante)', 'Prise unique ; demi-vie ≈ 80 heures', '40 mg si 40–79 kg, 80 mg si ≥ 80 kg, en une prise', 'Diarrhée ; ne pas prendre avec laitages, antiacides ou fer (chélation) ; statut d’autorisation et de remboursement suisse à vérifier'],
   ['Nirmatrelvir + ritonavir, Paxlovid® (inhibiteur de la protéase 3CL du SARS-CoV-2, potentialisé par le ritonavir)', 'Le ritonavir inhibe fortement le CYP3A4 et élève le nirmatrelvir ; élimination rénale', '300 mg + 100 mg 2 fois par jour pendant 5 jours, à débuter dans les 5 jours ; DFGe 30–60 : 150 mg + 100 mg 2 fois par jour ; DFGe < 30 : schéma de l’AIPS en vigueur', 'Dysgueusie, diarrhée ; contre-indiqué avec simvastatine, amiodarone, certains antiépileptiques inducteurs ; interactions majeures avec tacrolimus et anticoagulants oraux directs'],
  ]) + P('Les doses chiffrées viennent des AIPS suisses ; la dose rénale de Tamiflu® a été corrigée par l’audit (l’original indiquait 75 mg 1 fois par jour). Les interactions du nirmatrelvir-ritonavir se vérifient avant chaque prescription.', 1, 71))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge soulage les symptômes, prévient la déshydratation et réserve l’antiviral aux patients à risque, parce que son bénéfice est modeste chez l’adulte sain. '
   'Elle n’utilise pas d’antibiotique sans argument bactérien, parce qu’un antibiotique ne raccourcit pas une virose. '
   'Elle surveille l’apparition d’une complication pendant la première semaine.', 1, 35, 41) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans une forme compliquée (sepsis, pneumonie hypoxémiante), le but est de corriger l’hypoxémie et l’hypotension en moins d’une heure : saturation 92–96 %, pression artérielle moyenne ≥ 65 mmHg, antibiotique dans l’heure si sepsis. Dans une forme non compliquée, le but est un retour aux activités en 1 à 2 semaines sans complication.', 5), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Forme compliquée, en urgence</b> : 144 ou hospitalisation, oxygène, voie veineuse, hémocultures, cristalloïdes 30 mL/kg en cas d’hypotension ou de lactate ≥ 4 mmol/L, antibiotique dans l’heure ; on agit dans l’heure parce que la mortalité du choc septique augmente avec le délai.',
         '<b>B. Patient à risque</b> : test viral, puis oseltamivir dans les 48 heures (grippe) ou nirmatrelvir-ritonavir dans les 5 jours (COVID-19), parce que l’antiviral n’agit que pendant la réplication.',
         '<b>C. Forme non compliquée en ambulatoire</b> : mesures générales (repos, boissons fréquentes, paracétamol), masque en présence de personnes vulnérables, consignes de reconsultation.',
         '<b>D. Moyens non médicamenteux</b> : hygiène des mains, aération, isolement à domicile tant que la fièvre persiste.']), 5, 1, 2) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('L’arrêt de travail dure habituellement le temps de la fièvre plus 24 heures ; le personnel soignant reprend avec un masque selon les règles de l’établissement.',
            'La conduite automobile est déconseillée en cas de fièvre élevée, de somnolence ou de confusion.',
            'La grippe contractée par un soignant au travail n’est pas, en règle générale, reconnue comme maladie professionnelle (LAA) ; cas particuliers à vérifier avec l’assureur.'), 60, 61) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Groupe à risque : oseltamivir recommandé ; paracétamol ; pas d’AINS au 3e trimestre ; allaitement poursuivi'],
      ['Personne âgée', 'Fièvre parfois absente, confusion fréquente ; seuil d’hospitalisation bas'],
      ['Enfant', 'Doses selon le poids (AIPS) ; jamais d’acide acétylsalicylique (syndrome de Reye)'],
      ['Insuffisance hépatique', 'Paracétamol à dose réduite ; nirmatrelvir contre-indiqué si atteinte sévère'],
      ['Insuffisance rénale (DFGe)', 'Oseltamivir et nirmatrelvir adaptés au DFGe ; AINS à éviter'],
      ['Immunosuppression', 'Excrétion virale prolongée ; avis infectiologique'],
     ]), 1, 71), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Fièvre', 'Chaque jour pendant la première semaine', 'Fièvre > 5 jours ou retour après amélioration : reconsulter'],
    ['Respiration et saturation', 'Chaque jour chez le patient à risque', 'SpO₂ < 92 % : hospitalisation'],
    ['Hydratation, diurèse', 'Chaque jour chez la personne âgée', 'Oligurie : bilan rénal'],
    ['Toux', 'À 3 semaines', 'Toux persistante au-delà de 3 semaines : radiographie, arrêt du traitement symptomatique'],
   ]) + H4('Critères de sortie (hospitalisation), un par un') +
   OL(['Apyrexie ou fièvre en baisse depuis 24 heures.', 'SpO₂ ≥ 92 % à l’air ambiant.', 'Alimentation et hydratation orales possibles.', 'Signes vitaux stables (NEWS2 bas).', 'Suivi par le médecin de famille organisé en une semaine.']), 6) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('L’adulte sain guérit en 1 à 2 semaines ; une toux post-virale peut durer 3 semaines. La mortalité se concentre chez les personnes âgées et les malades chroniques (1 355 décès en excès par saison en Suisse). La recherche 2026 évalue des vaccins combinés grippe et COVID-19 et des antiviraux à large spectre ; l’original annonçait un vaccin combiné à ARN messager déjà intégré au plan suisse, ce que l’audit n’a pas confirmé.', 63, 3), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur la vaccination antigrippale annuelle d’octobre à novembre. '
   'L’OFSP la recommande aux 65 ans et plus, aux femmes enceintes, aux malades chroniques, à leur entourage et au personnel de santé. '
   'La prévention secondaire repose sur le diagnostic précoce et l’antiviral chez les patients à risque. '
   'La prévention tertiaire réduit les complications par la vaccination antipneumococcique et le suivi des malades chroniques.', 3) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Vaccins grippe et COVID-19 selon le plan suisse ; hygiène des mains, masque, aération'],
    ['Secondaire', 'Test et antiviral précoce chez les patients à risque'],
    ['Tertiaire', 'Vaccination antipneumococcique, réadaptation après pneumonie grave'],
   ]), 3)))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin demande toujours les voyages, car le paludisme imite la grippe. '
   'Il mesure les signes vitaux et cherche un sepsis ou un purpura avant de conclure à une virose. '
   'Il réserve le test et l’antiviral aux patients à risque, dans les 48 heures pour la grippe. '
   'Il adapte l’oseltamivir à la fonction rénale. '
   'Il ne prescrit pas d’antibiotique pour une virose simple, même avec une expectoration colorée.', 2, 55, 71, 41)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Oseltamivir 75 mg 1 fois par jour si clairance 30–60 mL/min.', 'Non : 30 mg 2 fois par jour selon l’AIPS.'],
  ['Expectoration verte au 4e jour = antibiotique.', 'Non : la couleur vient des neutrophiles ; seule une aggravation clinique compte.'],
  ['Fièvre au retour d’Afrique en hiver = grippe.', 'Non : paludisme jusqu’à preuve du contraire, goutte épaisse le jour même.'],
  ['Test antigénique négatif = pas de grippe.', 'Non : sa sensibilité est d’environ 60 %.'],
  ['Paxlovid® sans revoir les médicaments.', 'Non : interactions majeures (statines, tacrolimus, anticoagulants).'],
  ['qSOFA à 1 = pas de sepsis.', 'Non : le qSOFA ne suffit pas à exclure un sepsis.'],
 ]) + P('Ces pièges reprennent l’AIPS, Sepsis-3 et les recommandations de médecine des voyages.', 1, 4, 55, 65, 71)))
CTX = {'_prefixe': 'Dans le syndrome grippal',
 'pcr': 'La PCR multiplex sur frottis nasopharyngé confirme influenza, SARS-CoV-2 ou VRS ; elle ne se demande que si le résultat change la conduite.',
 'crp': 'Une CRP < 20 mg/L rend une infection bactérienne peu probable ; elle ne décide jamais seule.',
 'pct': 'La procalcitonine aide à éviter un antibiotique à l’hôpital ; un seuil < 0,25 µg/L est rassurant.',
 'radio': 'La radiographie thoracique cherche une pneumonie si l’auscultation, la dyspnée ou une fièvre en deux temps l’évoquent.',
 'hemoc': 'Les hémocultures se prélèvent avant l’antibiotique en cas de sepsis, sans le retarder.',
 'frottis': 'Le frottis sanguin et la goutte épaisse sont obligatoires le jour même chez tout voyageur fébrile.',
 'nfs': 'L’hémogramme montre souvent une lymphopénie virale ; une thrombopénie chez un voyageur oriente vers le paludisme ou la dengue.',
 'oxy': 'Une SpO₂ < 92 % à l’air ambiant impose une hospitalisation.',
 'lact': 'Un lactate > 2 mmol/L signale une hypoperfusion ; > 4 mmol/L, un choc probable.',
 'gds': 'Les gaz du sang mesurent l’hypoxémie et l’acidose dans les formes graves.',
 'creat': 'Le DFGe guide la dose d’oseltamivir et de nirmatrelvir.',
 'uree': 'L’urée > 7 mmol/L compte un point dans le score CURB-65.',
 'pl': 'La ponction lombaire se fait si un syndrome méningé est présent, sans retarder l’antibiotique.',
 'hcg': 'Le test de grossesse précède la radiographie et le choix des médicaments.',
 'sero': 'Les sérologies n’ont pas de place au stade aigu, sauf dengue (avec antigène NS1) chez le voyageur.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
