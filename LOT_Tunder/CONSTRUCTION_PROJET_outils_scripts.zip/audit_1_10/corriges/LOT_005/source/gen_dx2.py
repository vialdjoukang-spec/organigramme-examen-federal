# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.2 · Malaise iatrogène médicamenteux (LOT 5, original V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('dx2')
M = meta('dx2', 'DX.2', 'Malaise iatrogène', 'Malaise iatrogène médicamenteux (effets indésirables, interactions, sevrage)', 'LOT_005_DX2_Malaise_iatrogene_medicamenteux_AUDITÉ.html')
EIM = T('effet indésirable médicamenteux', 'Un effet indésirable médicamenteux est une réaction nocive et non voulue à un médicament utilisé à dose normale ; un surdosage ou une erreur en sont des formes particulières.')
CASC = T('cascade de prescription', 'Une cascade de prescription survient quand un effet indésirable est pris pour une nouvelle maladie et traité par un deuxième médicament, qui ajoute ses propres effets indésirables.')
MARGE = T('marge thérapeutique étroite', 'Un médicament a une marge thérapeutique étroite quand la dose efficace est proche de la dose toxique (lithium, digoxine, antiépileptiques) ; un petit changement de concentration suffit à le rendre toxique.')
SEVR = T('syndrome de discontinuation', 'Le syndrome de discontinuation est l’ensemble des symptômes qui suivent l’arrêt ou la baisse brusque d’un médicament auquel le cerveau s’est adapté (antidépresseur, benzodiazépine) ; il n’est pas une rechute de la maladie.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'Le malaise iatrogène est une sensation de maladie causée par un médicament : {EIM}, surdosage, interaction ou arrêt brutal. '
   'Il se manifeste par une fatigue, des vertiges, des nausées, une confusion ou une faiblesse, sans maladie nouvelle. '
   'Il se distingue d’une maladie intercurrente par sa chronologie, qui suit un changement de traitement.', 22, 42) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Effet indésirable', 'Réaction nocive à dose normale', 'Surdosage, erreur de prise'],
    ['Interaction', 'Un médicament modifie la concentration ou l’effet d’un autre', 'Effet indésirable d’un seul médicament'],
    ['Syndrome de discontinuation', 'Symptômes à l’arrêt d’un médicament', 'Rechute de la maladie traitée'],
    ['Syndrome sérotoninergique', 'Excès de sérotonine : confusion, agitation, clonus, fièvre', 'Syndrome malin des neuroleptiques (rigidité, évolution lente)'],
    ['Cascade de prescription', 'Effet indésirable traité comme une maladie', 'Polymédication justifiée'],
   ]) + P(f'Un médicament à {MARGE} expose plus souvent au malaise iatrogène, parce qu’une déshydratation ou une interaction suffit à le rendre toxique.', 76, 77))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Suisse, la loi impose d’annoncer les effets indésirables graves à Swissmedic (LPTh, art. 59), mais aucune source suisse ne chiffre la part des malaises dus aux médicaments. '
   'Au Royaume-Uni, une étude de 18 820 admissions attribue 6,5 % des hospitalisations à un effet indésirable, et la mortalité de ces patients atteint 2,3 %. '
   'Le risque augmente avec l’âge, le nombre de médicaments et l’insuffisance rénale, qui sont les principaux facteurs de terrain.', 24, 42) +
 F('Chiffres, terrain et histoire naturelle',
   TAB(['Donnée', 'Valeur', 'Portée'], [
    ['Admissions dues à un effet indésirable (Europe)', '6,5 % des admissions', 'Pirmohamed 2004, 18 820 patients'],
    ['Part évitable', '≈ 70 %', 'Même étude'],
    ['Médicaments les plus impliqués', 'Acide acétylsalicylique à faible dose, diurétiques, anticoagulants, AINS', 'Même étude'],
    ['Part suisse des malaises non spécifiques', 'Non publiée', 'Chiffre de 18 % de l’original retiré'],
    ['Polymédication en pharmacie suisse', 'Contrôle proposé dès 4 médicaments pendant 3 mois', 'pharmaSuisse'],
   ]) + P('L’évolution est en général favorable à l’arrêt du médicament ; elle est grave quand le malaise annonce une hyponatrémie profonde, une arythmie ou un syndrome sérotoninergique.', 42, 78))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Un médicament agit sur une cible ; le malaise apparaît quand il agit trop fort, trop longtemps ou sur une autre cible. '
   'Quatre mécanismes dominent : la baisse de la pression ou du sodium, l’excès d’effet sur le cerveau, l’accumulation par interaction ou insuffisance rénale, et le sevrage. '
   'Chaque mécanisme se cherche par un examen précis et se corrige par une action précise.', 42, 43) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Le médicament passe par l’intestin, le foie (cytochromes P450) et le rein ; il agit sur des récepteurs du cerveau, du cœur et des vaisseaux.'],
    ['Physiologie', 'Pourquoi un médicament reste sûr : sa concentration reste dans une zone thérapeutique, entre l’effet utile et la toxicité, grâce à l’élimination hépatique et rénale.'],
    ['Physiopathologie', 'Une interaction (inhibition du CYP3A4), une déshydratation ou une baisse du DFGe élèvent la concentration ; un arrêt brutal la fait chuter alors que le cerveau s’était adapté.'],
    ['Clinique', 'D’où les vertiges orthostatiques (antihypertenseurs), la confusion (anticholinergiques), les nausées (digoxine, lithium) ou le malaise pseudo-grippal du sevrage.'],
    ['Examens', 'Comme le mécanisme laisse une trace, on mesure la pression couchée puis debout, le sodium, la créatinine, l’ECG (QTc) et le taux sanguin des médicaments à marge étroite.'],
    ['Traitement', 'On agit sur la cause : arrêter ou réduire le médicament, corriger le sodium ou le potassium, et, pour un sevrage, reprendre puis diminuer lentement.'],
   ]), 42, 43, 25) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Hypotension (antihypertenseurs, alpha-bloquants, neuroleptiques)', 'Pression couchée puis debout à 1 et 3 minutes', 'Réduire ou arrêter le médicament'],
    ['Hyponatrémie (thiazides, ISRS, carbamazépine)', 'Ionogramme, osmolalité', 'Arrêt, restriction hydrique ou correction prudente'],
    ['Charge anticholinergique', 'Score ACB, globe vésical, confusion', 'Déprescription'],
    ['Excès de sérotonine', 'Critères de Hunter', 'Arrêt, benzodiazépine, cyproheptadine'],
    ['Accumulation (interaction, DFGe bas)', 'Créatinine, taux sanguins', 'Adapter la dose au DFGe'],
    ['Allongement du QT', 'ECG, potassium, magnésium', 'Arrêt des médicaments en cause, correction du potassium et du magnésium'],
    ['Sevrage', 'Chronologie de l’arrêt', f'Reprise puis réduction lente ; voir {SEVR}'],
   ]) + P('Le millepertuis induit le CYP3A4 et baisse l’effet de nombreux médicaments ; il ajoute aussi un effet sérotoninergique.', 43))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin cherche d’abord une urgence iatrogène : syndrome sérotoninergique, syndrome malin des neuroleptiques, toxicité du lithium ou de la digoxine, hyponatrémie profonde, QT long. '
   'Il relie ensuite chaque symptôme à un changement récent de traitement. '
   'Il exclut enfin une maladie intercurrente, car un patient polymédiqué peut aussi avoir une infection.', 21, 43, 74) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même unité : % des patients exposés à la situation)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Syndrome de discontinuation d’un antidépresseur' + PR('≈ 31 % des patients qui arrêtent (≈ 15 % après correction placebo)', 72), 'Malaise pseudo-grippal, vertiges, « décharges » dans la tête, 2–4 jours après l’arrêt', 'Chronologie ; disparition à la reprise'],
    ['Hyponatrémie sous ISRS (personne âgée)' + PR('0,5–32 % des patients traités', 73), 'Fatigue, nausées, confusion, chutes', 'Ionogramme'],
    ['Syndrome sérotoninergique' + PR('14–16 % des surdosages d’ISRS', 43), 'Agitation, sueurs, clonus, hyperthermie', 'Critères de Hunter, CK'],
    ['Hospitalisation pour effet indésirable' + PR('6,5 % des admissions', 42), 'Diurétique, AINS, anticoagulant, aspirine', 'Revue de la médication'],
    ['Toxicité du lithium', 'Tremblement grossier, diarrhée, confusion après déshydratation, AINS ou diurétique', 'Lithiémie, créatinine'],
    ['Toxicité de la digoxine', 'Nausées, troubles visuels, bradycardie', 'Digoxinémie, potassium, ECG'],
   ]) + P('Les fréquences portent sur des patients exposés (traitement, arrêt, surdosage) ; elles ne sont pas des probabilités devant un patient donné. Pour la toxicité du lithium et de la digoxine, aucune fréquence comparable n’a été retrouvée.', 42, 43, 72, 73))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien reconstruit la liste complète des médicaments, y compris l’automédication et les plantes, et '
   'Il date chaque changement, car la chronologie est l’argument le plus fort.', 22, 78) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Quels médicaments prenez-vous, même sans ordonnance ?', 'AINS, antihistaminiques, millepertuis passent inaperçus.', 'Interaction ou effet anticholinergique.'],
    ['Qu’est-ce qui a changé ces dernières semaines ?', 'Le malaise suit souvent un ajout ou une hausse de dose.', 'Imputabilité chronologique (Naranjo).'],
    ['Avez-vous arrêté un médicament récemment ?', 'Le sevrage d’un antidépresseur donne un malaise.', 'Reprise puis réduction lente.'],
    ['Avez-vous eu de la diarrhée, des vomissements, de la fièvre ?', 'La déshydratation fait monter le lithium et la digoxine.', 'Dosage sanguin, créatinine.'],
    ['Avez-vous des vertiges en vous levant ?', 'Hypotension orthostatique médicamenteuse.', 'Pression couchée puis debout.'],
    ['Avez-vous des palpitations ou une perte de connaissance ?', 'Arythmie sur QT long.', 'ECG immédiat.'],
   ])) +
 U('<b>Drapeaux rouges, qui imposent une hospitalisation (144 si instabilité)</b> : fièvre avec rigidité ou clonus, confusion aiguë, syncope ou palpitations sous un médicament qui allonge le QT. Les seuils d’alerte sont un QTc ≥ 500 ms, une bradycardie < 45/min sous digoxine ou bêtabloquant, un sodium < 125 mmol/L et une lithiémie > 1,5 mmol/L.', 21, 74, 12, 76)))
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin mesure la pression et la fréquence cardiaque couché, puis debout à 1 et 3 minutes. '
   'Il examine les pupilles, les réflexes, le tonus et la recherche d’un clonus, la peau, la vessie et l’état de conscience. '
   'Le clonus inductible a une bonne spécificité pour la toxicité sérotoninergique, mais un examen normal n’exclut pas une hyponatrémie.', 21, 43) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Pression couchée puis debout (1 et 3 minutes)', 'Baisse < 20 mmHg (systolique) et < 10 mmHg (diastolique)', 'Baisse plus forte : hypotension orthostatique'],
    ['Réflexes, recherche de clonus (cheville, yeux)', 'Réflexes normaux, pas de clonus', 'Clonus, hyperréflexie : excès de sérotonine'],
    ['Tonus', 'Normal', 'Rigidité « en tuyau de plomb » : syndrome malin des neuroleptiques'],
    ['Pupilles et peau', 'Pupilles normales, peau normale', 'Mydriase et peau sèche : anticholinergique ; mydriase et sueurs : sérotonine'],
    ['Palpation du bas-ventre', 'Pas de globe', 'Globe vésical : rétention anticholinergique'],
    ['Tremblement, marche', 'Absent, marche stable', 'Tremblement grossier, ataxie : toxicité du lithium'],
   ]) + P('Les critères de Hunter reposent sur l’examen (clonus, réflexes, température) ; leur sensibilité est de 84 % et leur spécificité de 97 %.', 21))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fatigue, les vertiges, les nausées, l’insomnie, l’anxiété et la confusion. '
   'Les signes physiques sont l’hypotension orthostatique, le clonus, la rigidité, les sueurs, la mydriase ou le globe vésical. '
   'Le médecin regroupe ces signes en syndromes, car chacun désigne une famille de médicaments.', 21, 43, 25) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Médicaments en cause'], [
    ['Syndrome de discontinuation (mnémonique FINISH)', 'Pseudo-grippe, insomnie, nausées, déséquilibre, troubles sensoriels, hyperexcitation', 'Paroxétine, venlafaxine surtout'],
    ['Syndrome sérotoninergique', 'Confusion, sueurs, tachycardie, clonus, hyperthermie', 'ISRS + tramadol, fentanyl, triptan, millepertuis, linézolide'],
    ['Syndrome anticholinergique', 'Confusion, peau sèche, mydriase, rétention urinaire, constipation', 'Antihistaminiques sédatifs, tricycliques, oxybutynine'],
    ['Syndrome malin des neuroleptiques', 'Rigidité, fièvre, confusion, CK très élevées', 'Neuroleptiques, arrêt brutal de la lévodopa'],
    ['Syndrome orthostatique', 'Vertiges au lever, chutes', 'Antihypertenseurs, alpha-bloquants, neuroleptiques'],
   ]) + P('Termes : ' + T('clonus', 'Le clonus est une série de contractions rythmiques d’un muscle après un étirement brusque (cheville) ; il traduit une hyperexcitabilité de la moelle.') + ', ' + T('mydriase', 'La mydriase est une dilatation de la pupille.') + ', ' + T('globe vésical', 'Le globe vésical est une vessie pleine qui ne se vide pas ; on la palpe au-dessus du pubis.') + '.', 21, 43))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('L’imputabilité se juge par l’échelle de Naranjo (1981) : un score ≥ 9 rend la relation certaine, 5 à 8 probable, 1 à 4 possible. '
   'Les critères de Hunter (2003) diagnostiquent la toxicité sérotoninergique ; un seul signe ne suffit pas. '
   'Selon la recommandation ESC 2022, un QTc ≥ 500 ms signale un risque élevé de torsade de pointes.', 22, 21, 74) +
 F('Critères de Hunter et seuils utiles',
   TAB(['Critère (agent sérotoninergique pris)', 'Ce que le médecin vérifie'], [
    ['Clonus spontané', 'Suffit au diagnostic'],
    ['Clonus inductible + agitation ou sueurs', 'Cheville, examen répété'],
    ['Clonus oculaire + agitation ou sueurs', 'Mouvements oculaires horizontaux lents'],
    ['Tremblement + hyperréflexie', 'Membres inférieurs surtout'],
    ['Hypertonie + température > 38 °C + clonus inductible ou oculaire', 'Forme grave'],
   ], 'Hunter 2003 : sensibilité 84 %, spécificité 97 % par rapport à l’avis du toxicologue.') +
   TAB(['Mesure', 'Seuil', 'Source'], [
    ['QTc', '≥ 500 ms ou hausse ≥ 60 ms : risque élevé', 'ESC 2022'],
    ['Lithiémie (prise de sang 12 heures après la dernière dose)', 'Cible 0,6–0,8 mmol/L ; toxicité souvent > 1,2 mmol/L', 'ISBD/IGSLI 2019'],
    ['Digoxinémie', 'Cible 0,5–0,9 ng/mL (≈ 0,6–1,2 nmol/L)', 'ESC 2021'],
    ['Score ACB', '≥ 3 : charge anticholinergique cliniquement significative', 'Boustani 2008'],
   ]), 21, 74, 76, 77, 75)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Arrêt du médicament (épreuve d’éviction) puis réintroduction éventuelle', 'Gold standard de l’imputabilité', 'Aucune sensibilité ni spécificité chiffrée', 'Réintroduction dangereuse si l’effet était grave'],
    ['Critères de Hunter', 'Toxicité sérotoninergique', 'Sensibilité 84 %, spécificité 97 %', 'Validés après surdosage'],
    ['Dosage sanguin (lithium, digoxine, antiépileptiques)', 'Concentration réelle', 'Valeur seulement si l’heure de prélèvement est respectée', 'Toxicité possible avec un taux « normal »'],
   ]), 21, 22, 76) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'ECG (QTc), ionogramme, créatinine et DFGe, glycémie', 'Tout malaise sous psychotropes, diurétiques ou antiarythmiques'],
    ['Première', 'Lithiémie, digoxinémie', 'Patient traité, surtout si déshydraté'],
    ['Seconde', 'CK, bilan hépatique, magnésium', 'Rigidité, fièvre, ictère, QT long'],
    ['Seconde', 'Génotypage des cytochromes (CYP2D6, CYP2C19)', 'Effets répétés à faible dose ; centre spécialisé'],
   ]), 74, 76) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La <b>lithiémie</b> se prélève 12 heures après la dernière prise, à l’état d’équilibre (5 jours après un changement de dose).',
       'La <b>digoxinémie</b> se prélève au moins 6 heures après la prise, sinon le taux est faussement élevé.',
       'L’<b>ECG</b> se fait au repos ; on mesure le QT en D2 ou V5 et on le corrige par la formule de Fridericia si la fréquence s’éloigne de 60/min.',
       'L’<b>ionogramme</b> ne demande pas d’être à jeun ; on arrête le diurétique en cause après le prélèvement si la natrémie est basse.']), 76, 77, 74) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['QTc', '≥ 500 ms', 'Risque de torsade de pointes', 'Arrêt des médicaments en cause, potassium > 4 mmol/L, magnésium, monitorage'],
    ['Natrémie', '< 125 mmol/L ou symptômes graves', 'Hyponatrémie profonde', 'Hospitalisation, correction selon la recommandation européenne'],
    ['Lithiémie', '> 1,5 mmol/L', 'Intoxication', 'Arrêt, hydratation, avis néphrologique (dialyse si grave)'],
    ['Digoxinémie élevée + potassium élevé', '> 2 ng/mL, K > 5 mmol/L', 'Intoxication digitalique', 'Arrêt ; anticorps antidigoxine si arythmie'],
    ['CK', '> 5 fois la normale', 'Atteinte musculaire', 'Hydratation ; chercher un syndrome malin'],
   ]) + P('Ces seuils sont des seuils d’action ; ils se lisent avec la clinique.', 12, 74, 76, 77)) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (taux toxique sans symptôme)', 'Vérifier l’heure du prélèvement ; répéter'],
    ['Résultat négatif mais clinique typique (lithium normal, tremblement)', 'Toxicité possible : ne pas se rassurer'],
    ['Résultat limite (QTc 470–500 ms)', 'Éviter un deuxième médicament qui allonge le QT ; contrôle ECG'],
    ['Grossesse', 'Lithium et antiépileptiques : avis spécialisé ; dosages plus fréquents'],
    ['Enfant', 'Intoxication accidentelle : Tox Info Suisse (145)'],
    ['DFGe bas', 'Adapter toutes les doses ; dosages rapprochés'],
    ['Allergie à l’iode, pacemaker ou IRM', 'Sans objet pour ces examens'],
   ]), 15))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Les examens cherchent la trace du mécanisme : ECG pour le QT, ionogramme pour le sodium, créatinine pour l’accumulation. '
   'Les dosages sanguins se demandent pour les médicaments à marge étroite. '
   'L’épreuve d’éviction reste la référence de l’imputabilité.', 22, 74, 76) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si un toxidrome grave est présent, alors le médecin arrête le médicament et hospitalise. '
   'Si le malaise suit l’arrêt d’un antidépresseur, alors il reprend la dernière dose tolérée, puis il réduit lentement. '
   'Sinon, il fait une revue de médication et déprescrit ce qui n’est plus utile.', 21, 25, 23) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Critères de Hunter positifs', 'Arrêt des agents sérotoninergiques, hospitalisation, benzodiazépine', 'Surveillance continue 24 heures'],
    ['QTc ≥ 500 ms', 'Arrêt, correction du potassium et du magnésium, monitorage', 'ECG répété'],
    ['Na < 125 mmol/L', 'Hospitalisation, arrêt du thiazide ou de l’ISRS', 'Natrémie toutes les 4–6 heures'],
    ['Sevrage d’antidépresseur', 'Reprise, puis réduction par paliers de plusieurs semaines', 'Contrôle à 2–4 semaines'],
    ['Hypotension orthostatique', 'Réduire l’antihypertenseur ou l’alpha-bloquant', 'Pression debout à 2 semaines'],
   ]), 21, 74, 12, 25)))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Lorazépam, Temesta® (benzodiazépine)', 'Renforce l’effet du GABA ; demi-vie 12–16 heures ; métabolisme par glucuronidation, sans métabolite actif', '1–2,5 mg par voie orale, à répéter selon la sédation ; voie intraveineuse à l’hôpital', 'Sédation, dépression respiratoire ; contre-indiqué en insuffisance respiratoire sévère et myasthénie ; interaction avec opioïdes et alcool'],
   ['Cyproheptadine (antagoniste des récepteurs 5-HT2A, antihistaminique)', 'Bloque les récepteurs de la sérotonine ; demi-vie ≈ 8 heures', 'Hors AIPS dans cette indication : 12 mg puis 2 mg toutes les 2 heures si symptômes persistants (Boyer 2005) ; disponibilité suisse à vérifier', 'Sédation, effets anticholinergiques ; pas de voie intraveineuse'],
   ['Fluoxétine, Fluctine® (ISRS à longue demi-vie)', 'Inhibe la recapture de la sérotonine ; demi-vie 4–6 jours (norfluoxétine 4–16 jours)', 'Relais pour sevrer un antidépresseur à demi-vie courte : 10–20 mg par jour, puis arrêt (pratique hors AIPS, à individualiser)', 'Nausées, insomnie ; inhibe fortement le CYP2D6 ; contre-indiquée avec les IMAO'],
   ['Sulfate de magnésium (électrolyte)', 'Stabilise la membrane cardiaque ; élimination rénale', 'Torsade de pointes : 2 g par voie intraveineuse (ERC 2021)', 'Hypotension, flush ; prudence en insuffisance rénale'],
  ]) + P('L’audit a ajouté les mentions « hors AIPS » ; les doses de cyproheptadine et de fluoxétine en relais viennent de la littérature et non d’une AIPS suisse.', 1, 43, 25, 13))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge arrête ou réduit le médicament en cause, parce que la cause disparaît avec lui. '
   'Elle corrige le désordre créé (sodium, potassium, QT) et prévient la récidive par une revue de médication. '
   'Elle évite la cascade de prescription, qui ajouterait un nouveau médicament.', 23, 42) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans une forme compliquée (syndrome sérotoninergique, torsade de pointes, hyponatrémie symptomatique), le but est de stabiliser le patient en quelques heures. Les cibles sont une température < 38,5 °C, un QTc < 500 ms et une natrémie remontée de 5 mmol/L sans dépasser 10 mmol/L en 24 heures. Dans une forme non compliquée, le but est la disparition du malaise en 1 à 2 semaines avec une ordonnance simplifiée.', 12, 43, 74), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Forme compliquée, en urgence</b> : 144, arrêt des médicaments en cause, monitorage, refroidissement, benzodiazépine pour l’agitation ; magnésium intraveineux pour une torsade ; on agit dans l’heure parce que l’hyperthermie et la torsade tuent vite.',
         '<b>B. Hyponatrémie symptomatique</b> : sérum salé hypertonique à 3 % (150 mL en 20 minutes, à répéter une fois) si signes graves, selon la recommandation européenne 2014, parce que l’œdème cérébral menace.',
         '<b>C. Forme non compliquée en ambulatoire</b> : arrêt ou réduction, mesures générales (hydratation, lever progressif), revue de médication STOPP/START.',
         '<b>D. Sevrage</b> : reprise du médicament, puis réduction lente en pourcentage de la dose précédente, parce que l’occupation des récepteurs n’est pas linéaire.']), 12, 13, 23, 25) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un effet indésirable grave ou inattendu s’annonce à Swissmedic (LPTh, art. 59) par le portail ElViS.',
            'La conduite automobile est interdite tant que persistent vertiges, sédation ou confusion ; les psychotropes sédatifs exigent une information écrite (OAC, annexe 1).',
            'L’arrêt de travail est court, le temps de l’adaptation du traitement.'), 24, 59, 60, 61) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Ne pas arrêter brutalement un antidépresseur ; avis spécialisé ; vérifier chaque médicament dans l’AIPS'],
      ['Personne âgée', 'STOPP/START version 3, score ACB ; commencer bas, augmenter lentement'],
      ['Enfant', 'Intoxication accidentelle : Tox Info Suisse (145)'],
      ['Insuffisance hépatique', 'Préférer le lorazépam (sans métabolite actif)'],
      ['Insuffisance rénale (DFGe)', 'Lithium, digoxine, metformine, AINS : adapter ou arrêter'],
     ]), 23, 15), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Natrémie', 'Toutes les 4–6 heures si correction', 'Hausse > 10 mmol/L en 24 heures : arrêt de la correction'],
    ['ECG (QTc)', 'Après l’arrêt et à chaque ajout', 'QTc ≥ 500 ms : arrêt du médicament'],
    ['Pression debout', 'À 2 semaines', 'Baisse persistante : nouvelle réduction'],
    ['Symptômes de sevrage', 'À chaque palier, toutes les 2–4 semaines', 'Symptômes gênants : revenir au palier précédent'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Température normale et absence de clonus depuis 24 heures.', 'QTc < 500 ms et potassium normal.', 'Natrémie stable, corrigée sans dépasser la limite de sécurité.', 'Ordonnance révisée remise au patient et au médecin de famille.']), 12, 21, 74) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic est bon à l’arrêt du médicament ; le syndrome sérotoninergique se résout souvent en 24 heures. Un sevrage d’antidépresseur peut durer plusieurs semaines. La recherche 2026 évalue la pharmacogénétique préventive (CYP2D6, CYP2C19) ; l’original la présentait comme déployée en routine en Suisse, ce que l’audit n’a pas confirmé.', 43, 25), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire choisit le médicament et la dose selon l’âge et le DFGe, et vérifie les interactions avant chaque prescription. '
   'La prévention secondaire repose sur la revue de médication régulière (STOPP/START, contrôle de polymédication en pharmacie). '
   'La prévention tertiaire annonce l’effet à Swissmedic et inscrit l’intolérance dans le dossier ; l’OFSP soutient la sécurité de la médication.', 23, 78, 24) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Indication claire, dose adaptée, contrôle des interactions'],
    ['Secondaire', 'Revue de médication tous les 6–12 mois, score ACB'],
    ['Tertiaire', 'Annonce ElViS, mention d’intolérance, éducation du patient'],
   ]))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin pense au médicament devant tout malaise d’un patient polymédiqué. '
   'Il date chaque changement de traitement et le compare au début des symptômes. '
   'Il mesure la pression debout, le sodium, la créatinine et le QTc. '
   'Il arrête le médicament en cause au lieu d’en ajouter un autre. '
   'Il sevre lentement les antidépresseurs et les benzodiazépines.', 22, 23, 25, 74)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Traiter les nausées d’un ISRS par du métoclopramide.', 'Cascade de prescription : réévaluer l’ISRS.'],
  ['Associer tramadol et ISRS sans surveillance.', 'Le tramadol est sérotoninergique : risque de syndrome sérotoninergique.'],
  ['Lithiémie prélevée 2 heures après la prise.', 'Prélèvement 12 heures après la dernière dose.'],
  ['Prendre le sevrage pour une rechute.', 'Le sevrage commence en quelques jours et disparaît à la reprise.'],
  ['Corriger un sodium bas de 15 mmol/L en 24 heures.', 'Ne pas dépasser 10 mmol/L le premier jour (risque de démyélinisation osmotique).'],
 ]) + P('Ces pièges reprennent Hunter 2003, la recommandation européenne sur l’hyponatrémie et ISBD/IGSLI 2019.', 21, 12, 76)))
CTX = {'_prefixe': 'Dans le malaise iatrogène',
 'ecg': 'L’ECG mesure le QTc ; ≥ 500 ms impose l’arrêt des médicaments qui allongent le QT.',
 'iono': 'L’ionogramme cherche une hyponatrémie (thiazides, ISRS) ou une hypokaliémie qui favorise les torsades.',
 'creat': 'Le DFGe explique l’accumulation du lithium, de la digoxine ou de la metformine.',
 'tox': 'La lithiémie se prélève 12 heures après la dernière dose ; la digoxinémie au moins 6 heures après.',
 'stp': 'Le dosage du lithium ou de la digoxine confirme une intoxication si l’heure de prélèvement est respectée.',
 'ck': 'Des CK très élevées orientent vers un syndrome malin des neuroleptiques ou une rhabdomyolyse.',
 'hep': 'Le bilan hépatique cherche une hépatite médicamenteuse.',
 'mg': 'Une magnésémie basse favorise les torsades de pointes.',
 'osmo': 'L’osmolalité confirme qu’une hyponatrémie est hypotonique.',
 'gly': 'La glycémie cherche une hypoglycémie sous sulfonylurée ou insuline.',
 'gen': 'Le génotypage des cytochromes se discute après des effets répétés à faible dose.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
