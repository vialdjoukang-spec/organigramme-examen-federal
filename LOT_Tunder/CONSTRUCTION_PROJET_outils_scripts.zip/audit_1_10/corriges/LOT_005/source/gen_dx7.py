# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.7 · Maladies inflammatoires systémiques : PPR, artérite à cellules géantes, lupus (LOT 5, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('dx7')
M = meta('dx7', 'DX.7', 'PPR, Horton et lupus', 'Maladies inflammatoires systémiques : pseudopolyarthrite rhizomélique, artérite à cellules géantes, lupus', 'LOT_005_DX7_PPR_Horton_lupus_AUDITÉ.html')
VASC = T('vascularite', 'Une vascularite est une inflammation de la paroi des vaisseaux ; elle peut les rétrécir et priver les organes de sang.')
RHIZ = T('rhizomélique', 'Rhizomélique veut dire « à la racine des membres » : épaules, cou et hanches.')
CG = T('cellules géantes', 'Les cellules géantes sont des macrophages fusionnés en une grande cellule à plusieurs noyaux ; elles signent une inflammation granulomateuse.')
HALO = T('signe du halo', 'Le signe du halo est un épaississement sombre de la paroi artérielle à l’échographie ; il traduit l’œdème inflammatoire.')
PTS = []

# ---------- 1
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'L’artérite à cellules géantes (ACG), ou maladie de Horton, est une {VASC} des grosses et moyennes artères après 50 ans. '
   f'La pseudopolyarthrite rhizomélique (PPR) est une inflammation des bourses et des gaines des ceintures, d’où des douleurs de type {RHIZ}. '
   'Le lupus érythémateux systémique (LES) est une maladie auto-immune à anticorps, qui touche surtout la femme jeune.', 27, 28, 31) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['ACG (Horton)', 'Vascularite granulomateuse des grosses artères après 50 ans', 'Céphalée de tension, migraine'],
    ['PPR', 'Douleur et raideur inflammatoires des épaules et des hanches après 50 ans', 'Polyarthrite rhumatoïde du sujet âgé'],
    ['LES', 'Maladie auto-immune avec anticorps antinucléaires', 'Lupus cutané isolé, lupus induit par un médicament'],
    ['Critères de classification', 'Outils pour la recherche, appliqués à un diagnostic déjà probable', 'Critères diagnostiques'],
   ]) + P('Ces maladies expliquent un malaise général par l’inflammation, qui libère des cytokines et cause fièvre, fatigue et amaigrissement.', 27, 28), 27, 28)))

# ---------- 2
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('Aucune donnée suisse publiée n’a été retrouvée ; le chiffre de 20 pour 100 000 attribué à la Société suisse de rhumatologie n’est pas confirmé. '
   'Au niveau international, l’incidence de l’ACG est de 10 pour 100 000 personnes de plus de 50 ans par an. '
   'Elle atteint 21,6 en Scandinavie et 7,3 dans le reste de l’Europe.', 51) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Incidence de l’ACG', '10,00/100 000 par an', 'Personnes > 50 ans, méta-analyse mondiale'],
    ['Incidence de l’ACG, Scandinavie', '21,57/100 000 par an', 'Personnes > 50 ans'],
    ['Incidence de l’ACG, Europe hors Scandinavie', '7,26/100 000 par an', 'Personnes > 50 ans'],
    ['Prévalence de l’ACG', '51,74/100 000', 'Personnes > 50 ans'],
    ['Incidence de la PPR', '63,9/100 000 par an', 'Personnes ≥ 50 ans, Minnesota'],
   ]) + P('Le terrain associe un âge de plus de 50 ans, avec un âge moyen de 74 ans pour la PPR et une majorité de femmes. '
          'Le pronostic vital de la PPR isolée n’est pas aggravé ; le risque principal de l’ACG est la cécité.', 100, 51, 52), 51, 100)))

# ---------- 3
PTS.append(POINT(3, 'Physiopathologie',
 P('Dans l’ACG, des lymphocytes T et des macrophages envahissent la paroi des artères et forment des granulomes à ' + CG + '. '
   'L’interleukine-6 (IL-6) stimule le foie, qui produit la CRP, d’où le syndrome inflammatoire. '
   'La paroi s’épaissit et rétrécit la lumière, ce qui explique la claudication de la mâchoire et la perte visuelle.', 27, 33) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'L’artère temporale superficielle et l’artère ophtalmique naissent de la carotide ; l’ophtalmique nourrit le nerf optique.'],
    ['Physiologie', 'Pourquoi l’inflammation est utile : l’IL-6 mobilise les défenses et fait produire la CRP par le foie.'],
    ['Physiopathologie', 'Dans l’ACG, l’inflammation se fixe sur la paroi artérielle et la rétrécit ; dans la PPR, elle touche les bourses séreuses.'],
    ['Clinique', 'D’où céphalée, claudication de la mâchoire, troubles visuels, raideur des ceintures, fièvre et amaigrissement.'],
    ['Examens', 'Comme l’IL-6 est élevée, la CRP et la VS montent ; l’échographie voit le halo, la biopsie voit les granulomes.'],
    ['Traitement', 'Les corticoïdes éteignent l’inflammation en quelques jours ; le tocilizumab bloque le récepteur de l’IL-6.'],
   ]), 27, 33) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Granulome de la paroi artérielle', 'Biopsie de l’artère temporale', 'Corticoïdes'],
    ['Œdème de la paroi', 'Échographie (halo)', 'Corticoïdes, tocilizumab'],
    ['Production d’IL-6', 'CRP, VS', 'Tocilizumab'],
    ['Bursite des épaules', 'Échographie des épaules', 'Corticoïdes à faible dose'],
    ['Auto-anticorps (LES)', 'Anticorps antinucléaires, anti-ADN natif, complément', 'Hydroxychloroquine'],
   ]), 27, 28, 31) +
 F('Critères ACR/EULAR 2022 de l’ACG et règle de Miller',
   TAB(['Critère (âge ≥ 50 ans obligatoire)', 'Points'], [
    ['Biopsie positive ou halo à l’échographie temporale', '+5'],
    ['VS ≥ 50 mm/h ou CRP ≥ 10 mg/L', '+3'],
    ['Perte visuelle brutale', '+3'],
    ['Raideur matinale du cou ou des épaules', '+2'],
    ['Claudication de la mâchoire ou de la langue', '+2'],
    ['Céphalée temporale nouvelle', '+2'],
    ['Sensibilité du cuir chevelu', '+2'],
    ['Artère temporale anormale à l’examen', '+2'],
    ['Atteinte axillaire bilatérale à l’imagerie', '+2'],
    ['Fixation de toute l’aorte au TEP-FDG', '+2'],
   ], 'Classement si ≥ 6 points ; sensibilité 87,0 %, spécificité 94,8 %. Correction de l’original : il citait les critères ACR de 1990 sous le nom ACR/EULAR.') +
   P('La VS normale maximale se calcule par la règle de Miller : âge/2 chez l’homme, (âge + 10)/2 chez la femme. '
     'Exemple de l’original recalculé : femme de 76 ans, VS normale maximale = 43 mm/h. '
     'Avec céphalée temporale (2), artère sensible (2) et CRP 112 mg/L (3), le score vaut 7 : le classement en ACG est possible avant la biopsie.', 26, 101), 26, 101)))

# ---------- 4
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin cherche d’abord l’urgence : une perte visuelle impose une corticothérapie immédiate. '
   'Il distingue ensuite l’ACG, la PPR et une cause infectieuse ou tumorale du syndrome inflammatoire. '
   'Il élimine enfin un myélome, une endocardite et une myopathie inflammatoire.', 27, 28) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même unité : incidence pour 100 000 personnes de 50 ans ou plus par an)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['PPR (Minnesota)' + PR('63,9/100 000 par an', 100), 'Raideur matinale des ceintures', 'CRP, VS, échographie des épaules'],
    ['ACG (méta-analyse mondiale)' + PR('10,00/100 000 par an', 51), 'Céphalée, claudication de la mâchoire, vision', 'Échographie temporale, biopsie'],
    ['ACG (Scandinavie)' + PR('21,57/100 000 par an', 51), 'Même tableau', 'Même examen'],
    ['Myélome multiple', 'Anémie, douleurs osseuses, insuffisance rénale', 'Électrophorèse des protéines'],
    ['Endocardite infectieuse subaiguë', 'Souffle, fièvre prolongée', 'Hémocultures, échocardiographie'],
    ['Polyarthrite rhumatoïde du sujet âgé', 'Synovites des petites articulations', 'Facteur rhumatoïde, anti-CCP'],
    ['LES à début tardif', 'Sérites, cytopénies, éruption', 'Anticorps antinucléaires'],
   ]) + P('Les fréquences ne sont pas des probabilités devant un patient donné, et elles viennent de populations différentes. '
          'Pour les autres diagnostics, aucune incidence dans la même population n’a été retrouvée.', 51, 100), 51, 100)))

# ---------- 5
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise la céphalée, la douleur de la mâchoire en mâchant, les troubles visuels et la raideur matinale. '
   'Il relève la fièvre, la perte de poids, les sueurs nocturnes et les médicaments.', 27, 28) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Avez-vous mal à la mâchoire en mâchant ?', 'Claudication par ischémie des muscles masticateurs.', 'Suspicion d’ACG forte.'],
    ['Voyez-vous flou, double ou noir par moments ?', 'Ischémie du nerf optique.', 'Corticoïdes immédiats, ophtalmologue.'],
    ['Êtes-vous raide le matin, combien de temps ?', 'Raideur inflammatoire > 45 minutes dans la PPR.', 'Critères de PPR.'],
    ['Pouvez-vous lever les bras pour vous coiffer ?', 'Atteinte des épaules.', 'Échographie des épaules.'],
    ['Avez-vous perdu du poids, des sueurs ?', 'Inflammation ou cancer.', 'Bilan d’une cause tumorale.'],
   ]), 27, 29) +
 U('<b>Drapeaux rouges (urgence, 144 ou ophtalmologie immédiate)</b> : amaurose fugace, baisse de vision, diplopie, claudication de la mâchoire, signes neurologiques, souffle ou asymétrie de pression aux bras.', 27)))

# ---------- 6
PTS.append(POINT(6, 'Examen clinique',
 P('Le médecin palpe les artères temporales et le cuir chevelu. '
   'Il teste la mobilité des épaules et des hanches et mesure la pression aux deux bras. '
   'Il teste l’acuité visuelle ; un examen normal ne suffit pas à exclure une ACG.', 27) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Palpation des artères temporales', 'Souples, pulsatiles, indolores', 'Indurées, sensibles, pouls absent : ACG'],
    ['Mobilité des épaules', 'Élévation complète', 'Limitation douloureuse bilatérale : PPR'],
    ['Pression aux deux bras', 'Différence < 10 mmHg', 'Différence nette : atteinte de l’artère sous-clavière'],
    ['Auscultation des axes', 'Pas de souffle', 'Souffle axillaire ou sous-clavier : ACG des gros vaisseaux'],
    ['Acuité visuelle', 'Normale', 'Baisse : urgence ophtalmologique'],
    ['Peau, articulations', 'Normales', 'Éruption, synovites, ulcères buccaux : LES'],
   ]), 27, 30)))

# ---------- 7
TERMES = ('Termes : ' + T('claudication de la mâchoire', 'La claudication de la mâchoire est une douleur des muscles masticateurs pendant la mastication, calmée par l’arrêt.') + ', '
   + T('amaurose fugace', 'L’amaurose fugace est une perte brève de la vision d’un œil ; elle annonce une cécité possible dans l’ACG.') + ', '
   + T('raideur matinale', 'La raideur matinale est une difficulté à bouger au réveil ; elle dure plus de 45 minutes dans les rhumatismes inflammatoires.') + ', '
   + T('bursite', 'La bursite est une inflammation d’une bourse séreuse, petite poche qui facilite le glissement des tendons.') + ', '
   + T('neuropathie optique ischémique', 'La neuropathie optique ischémique est une mort du nerf optique par manque de sang ; la perte visuelle est souvent définitive.') + '.')
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fatigue, la céphalée, la douleur des ceintures et les troubles visuels. '
   'Les signes physiques sont une artère temporale indurée, une limitation des épaules et une fièvre modérée. '
   'L’ACG et la PPR s’associent souvent chez le même patient.', 27, 52) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Gravité'], [
    ['ACG crânienne', 'Céphalée, claudication de la mâchoire, troubles visuels', 'Risque de cécité'],
    ['ACG des gros vaisseaux', 'Claudication des bras, souffle, asymétrie de pression', 'Anévrisme de l’aorte à long terme'],
    ['PPR', 'Raideur et douleur bilatérales des épaules et des hanches', 'Handicap fonctionnel'],
    ['Syndrome général inflammatoire', 'Fièvre, amaigrissement, fatigue', 'Chercher aussi un cancer ou une infection'],
   ]) + P(TERMES, 27, 52), 27, 52)))

# ---------- 8
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le critère de classification ACR/EULAR 2022 de l’ACG classe un patient de 50 ans ou plus dès 6 points. '
   'La recommandation EULAR 2012 classe une PPR si l’âge est ≥ 50 ans, avec douleur bilatérale des épaules et CRP ou VS élevée en mg/L ou mm/h, puis un score. '
   'Un score de classification ne suffit pas à poser le diagnostic chez un patient donné.', 26, 29) +
 F('Critères de la PPR et du LES',
   TAB(['Maladie', 'Conditions d’entrée', 'Score'], [
    ['PPR (EULAR/ACR 2012)', 'Âge ≥ 50 ans, douleur bilatérale des épaules, CRP ou VS élevée', 'Raideur > 45 min (2), douleur des hanches (1), absence de facteur rhumatoïde et d’anti-CCP (2), absence d’autre atteinte articulaire (1) ; ≥ 4 points sans échographie'],
    ['LES (EULAR/ACR 2019)', 'Anticorps antinucléaires ≥ 1:80', '≥ 10 points avec au moins un critère clinique'],
   ], 'Correction de l’original : la Société suisse de rhumatologie n’a pas publié de critères propres ; elle suit l’ACR et l’EULAR.'), 29, 30)))

# ---------- 9
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Échographie des artères temporales et axillaires', 'Halo inflammatoire', 'Premier examen selon l’EULAR 2023 ; valeurs non vérifiées par l’audit', 'Dépend de l’opérateur'],
    ['Biopsie de l’artère temporale', 'Granulomes, cellules géantes', 'Lésions segmentaires : une biopsie négative n’exclut pas l’ACG', 'Geste invasif ; longueur suffisante nécessaire'],
   ]), 32, 27) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'CRP, VS, NFS, créatinine, bilan hépatique, électrophorèse des protéines', 'Tout syndrome inflammatoire après 50 ans'],
    ['Première', 'Échographie temporale et axillaire', 'Suspicion d’ACG'],
    ['Seconde', 'Biopsie de l’artère temporale', 'Échographie non concluante ou indisponible'],
    ['Seconde', 'TEP-FDG ou angio-IRM', 'Suspicion d’atteinte de l’aorte et des gros vaisseaux'],
    ['Seconde', 'Anticorps antinucléaires, complément', 'Suspicion de LES'],
   ]), 32, 27, 30) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['L’<b>échographie</b> ou la <b>biopsie</b> se fait dans la semaine après le début des corticoïdes, qui ne doivent pas être retardés.',
       'La <b>biopsie</b> demande un fragment assez long, car les lésions sont segmentaires ; l’original exigeait 2–3 cm, chiffre non vérifié.',
       'Le <b>TEP</b> perd en sensibilité après quelques jours de corticoïdes.']), 32, 27) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['VS', '> âge/2 (homme) ou (âge + 10)/2 (femme)', 'Inflammation', 'Interpréter avec la CRP'],
    ['VS ou CRP', '≥ 50 mm/h ou ≥ 10 mg/L', 'Item ACR/EULAR (+3)', 'Poursuivre le bilan d’ACG'],
    ['Halo temporal', 'Présent', 'ACG très probable si la clinique est typique', 'Biopsie souvent inutile'],
    ['Biopsie', 'Granulomes', 'ACG confirmée', 'Traitement complet'],
   ]), 26, 101, 32) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (CRP élevée sans signe d’ACG)', 'Chercher une infection, un cancer'],
    ['Résultat négatif mais clinique typique (biopsie normale)', 'Échographie axillaire, TEP, avis spécialisé'],
    ['Résultat limite (CRP 10–20 mg/L)', 'Contrôle et examen clinique répétés'],
    ['Grossesse', 'ACG exclue par l’âge ; LES : avis spécialisé'],
    ['Enfant', 'ACG et PPR inexistantes ; penser au lupus pédiatrique'],
    ['Insuffisance rénale (DFGe bas)', 'Préférer l’échographie au produit de contraste'],
    ['Allergie à l’iode, pacemaker ou IRM', 'TEP ou échographie à la place de l’angio-IRM'],
   ]), 32))
PTS.append(POINT(9, 'Examens complémentaires',
 P('La CRP et la VS montrent l’inflammation. '
   'L’échographie et la biopsie confirment l’ACG. '
   'Aucun examen ne doit retarder les corticoïdes en cas de menace visuelle.', 27, 32) + P9))

# ---------- 10
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si des troubles visuels sont présents, alors le médecin débute les corticoïdes à forte dose immédiatement. '
   'Si l’ACG est suspectée sans trouble visuel, alors il débute les corticoïdes et demande l’échographie en urgence. '
   'Si seule la PPR est probable, alors il donne une faible dose de corticoïdes et réévalue à 1 semaine.', 27, 28) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Perte visuelle ou amaurose', 'Méthylprednisolone IV, ophtalmologue', 'Vision quotidienne'],
    ['ACG suspectée', 'Prednisone 40–60 mg/j, échographie', 'Résultat dans la semaine'],
    ['PPR typique', 'Prednisone 12,5–25 mg/j', 'Réponse attendue en quelques jours'],
    ['Pas de réponse aux corticoïdes', 'Revoir le diagnostic', 'Chercher cancer ou infection'],
    ['Rechute à la décroissance', 'Remonter la dose, épargneur', 'CRP et clinique'],
   ]), 27, 28)))

# ---------- 11
MED = F('Fiches médicamenteuses (posologies AIPS et recommandations)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Prednisone (corticoïde)', 'Bloque la transcription des cytokines ; une prise le matin', 'ACG : 40–60 mg/j, puis 15–20 mg/j à 2–3 mois et ≤ 5 mg/j après 1 an ; PPR : 12,5–25 mg/j', 'Diabète, ostéoporose, infections, hypertension'],
   ['Méthylprednisolone, Solu-Medrol® (corticoïde IV)', 'Action rapide', '250–1000 mg/j IV pendant 3 jours en cas de menace visuelle', 'Hyperglycémie, troubles psychiques'],
   ['Tocilizumab, RoActemra® (anti-récepteur de l’IL-6)', 'Bloque le signal de l’IL-6 ; la CRP n’est plus interprétable', '162 mg sous-cutané par semaine avec corticoïdes en décroissance', 'Infections, perforation digestive ; CRP faussement normale'],
   ['Méthotrexate (immunosuppresseur)', 'Antimétabolite de l’acide folique', 'Épargneur de corticoïdes dans l’ACG ou la PPR à rechutes', 'Toxicité hépatique et sanguine ; acide folique associé'],
   ['Hydroxychloroquine, Plaquenil® (antipaludéen)', 'Module l’immunité innée', 'LES : ≤ 5 mg/kg/j', 'Atteinte de la rétine : contrôle ophtalmologique'],
  ]) + P('Correction de l’original : le tocilizumab ne permet pas un sevrage complet chez plus de 70 % des patients ; dans GiACTA, la rémission prolongée à 52 semaines était de 56 % contre 14–18 % sous placebo.', 27, 28, 33, 31, 1), 27, 33, 1)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge éteint l’inflammation, parce que celle-ci menace la vision dans l’ACG. '
   'Elle repose sur les corticoïdes, avec une dose plus forte dans l’ACG que dans la PPR. '
   'Elle prévient en même temps les effets indésirables des corticoïdes.', 27, 28) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans une forme compliquée (menace visuelle), le but est de sauver la vision en quelques heures. Dans une forme non compliquée (PPR, ACG sans signe visuel), le but est de contrôler les symptômes et d’atteindre la dose minimale efficace.', 27, 28), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Forme compliquée, en urgence</b> : méthylprednisolone IV, avis ophtalmologique le jour même.',
         '<b>B. ACG sans menace visuelle</b> : prednisone 40–60 mg/j sans attendre la biopsie, puis décroissance progressive.',
         '<b>C. Forme non compliquée, en ambulatoire (PPR)</b> : prednisone 12,5–25 mg/j ; mesures générales (activité physique, éducation sur la décroissance et les signes visuels).',
         '<b>D. Protection</b> : calcium, vitamine D, densitométrie et traitement de l’ostéoporose selon le risque ; vaccinations.']), 27, 28) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('La conduite automobile est suspendue en cas de perte visuelle, selon les exigences visuelles de l’OAC.',
            'La PPR limite les gestes au-dessus de l’épaule ; un aménagement du poste aide pendant la phase aiguë.'), 59, 60, 61) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'LES : hydroxychloroquine poursuivie ; avis spécialisé'],
      ['Personne âgée', 'Risque élevé d’effets des corticoïdes : épargneur précoce'],
      ['Enfant', 'Lupus pédiatrique : centre spécialisé'],
      ['Diabète', 'Surveillance de la glycémie sous corticoïdes'],
      ['Insuffisance rénale (DFGe) ou hépatique', 'Méthotrexate contre-indiqué si insuffisance sévère'],
     ]), 27, 31), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Symptômes, CRP, VS', 'Toutes les 2–4 semaines au début', 'Hausse avec symptômes : rechute'],
    ['Glycémie, pression', 'À chaque visite', 'Hausse : traitement'],
    ['Densité osseuse', 'Au début si traitement prolongé', 'Ostéoporose : traitement'],
    ['Vision', 'À chaque visite (ACG)', 'Baisse : urgence'],
    ['Infections sous tocilizumab ou méthotrexate', 'À chaque visite', 'Infection grave : arrêt du traitement'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Vision stable.', 'Symptômes contrôlés.', 'Plan de décroissance écrit.', 'Protection osseuse en place.']), 27, 28) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Les rechutes sont fréquentes à la décroissance. Le pronostic vital de la PPR isolée n’est pas aggravé. La recherche évalue d’autres épargneurs de corticoïdes ; l’affirmation de l’original sur 2026 n’est pas sourcée et a été retirée.', 52, 100), 'fenetre')))

# ---------- 12
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire de ces maladies n’existe pas. '
   'La prévention secondaire repose sur un diagnostic rapide pour éviter la cécité. '
   'La prévention tertiaire limite les effets des corticoïdes : os, diabète, infections, vaccinations selon le plan suisse.', 27, 3) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Aucune mesure connue'],
    ['Secondaire', 'Corticoïdes dès la suspicion d’ACG'],
    ['Tertiaire', 'Protection osseuse, vaccinations, épargneur de corticoïdes'],
   ]), 27, 3)))

# ---------- 13
PTS.append(POINT(13, 'Points clés',
 P('Le médecin pense à l’ACG devant tout malaise inflammatoire après 50 ans. '
   'Il demande la claudication de la mâchoire et les troubles visuels. '
   'Il débute les corticoïdes sans attendre la biopsie. '
   'Il protège l’os et surveille la glycémie.', 27, 26)))

# ---------- 14
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Attendre la biopsie pour traiter.', 'Les corticoïdes ne doivent pas attendre ; la biopsie reste utile quelques jours.'],
  ['Exclure une ACG sur une biopsie négative.', 'Les lésions sont segmentaires.'],
  ['Traiter une PPR à 60 mg/j.', 'PPR : 12,5–25 mg/j.'],
  ['Utiliser des critères de classification comme critères diagnostiques.', 'Ils servent à la recherche.'],
  ['Suivre la CRP sous tocilizumab.', 'La CRP reste basse même en cas de rechute.'],
 ]) + P('Ces pièges reprennent les recommandations EULAR.', 27, 28)))

CTX = {'_prefixe': 'Dans les maladies inflammatoires systémiques',
 'vs': 'La VS attendue vaut âge/2 chez l’homme et (âge + 10)/2 chez la femme.',
 'crp': 'Une CRP ≥ 10 mg/L compte 3 points dans les critères de l’ACG.',
 'nfs': 'La NFS montre souvent une anémie inflammatoire et une thrombocytose.',
 'biopsie': 'La biopsie de l’artère temporale montre les granulomes à cellules géantes.',
 'doppler': 'L’échographie Doppler temporale et axillaire cherche le halo.',
 'tep': 'Le TEP-FDG montre l’atteinte de l’aorte et des gros vaisseaux.',
 'irm': 'L’angio-IRM montre l’épaississement de la paroi des gros vaisseaux.',
 'epp': 'L’électrophorèse des protéines cherche un myélome.',
 'creat': 'La créatinine précède le méthotrexate et l’imagerie injectée.',
 'hep': 'Le bilan hépatique précède le méthotrexate.',
 'dxa': 'La densitométrie évalue l’os avant une corticothérapie prolongée.',
 'gly': 'La glycémie se surveille sous corticoïdes.',
 'ck': 'Les CK sont normales dans la PPR et élevées dans une myosite.',
 'hemoc': 'Les hémocultures cherchent une endocardite qui imite une vascularite.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
