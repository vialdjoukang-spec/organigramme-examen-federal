# -*- coding: utf-8 -*-
"""Fragments d'examens complémentaires propres aux LOTs 5–6 (même format que bibliotheque_examens/donnees_*.py + clé regex).
Valeurs adultes usuelles ; bornes exactes selon le laboratoire. Sources de référence : voir RAPPORT_AUDIT.md."""
B = 'Anomalie'; S = 'Signification'; D = 'Diagnostics à évoquer'
EXTRA = {
'hbco': dict(lex='Carboxyhémoglobine (CO-oxymétrie)', cat='BIO', titre='Carboxyhémoglobine (HbCO) par CO-oxymétrie',
 regex=r"carboxyh[ée]moglobin|\bHbCO\b|\bCOHb\b|CO-?oxym[ée]tr",
 p="Le monoxyde de carbone se fixe sur l’hémoglobine avec une affinité environ 200 fois supérieure à celle de l’oxygène ; le CO-oxymètre (gazométrie veineuse ou artérielle, ou appareil de pouls à plusieurs longueurs d’onde) mesure la fraction d’hémoglobine liée au CO. L’oxymètre de pouls ordinaire ne distingue pas HbCO et HbO₂ : la SpO₂ reste faussement normale.",
 cols=[B, S, D], rows=[
 ['HbCO ≤ 3 % (non-fumeur), jusqu’à 10 % (fumeur)', "La valeur est attendue ; elle n’exclut pas une exposition ancienne, car l’HbCO baisse sous oxygène (demi-vie ≈ 4–6 h à l’air, ≈ 1 h sous O₂ à 100 %).", 'Exposition improbable ou ancienne'],
 ['HbCO > 3 % chez un non-fumeur ou > 10 % chez un fumeur', "Une intoxication au CO est confirmée si le contexte concorde.", 'Chauffage défectueux, incendie, moteur en lieu clos, chicha'],
 ['HbCO normale mais symptômes collectifs typiques', "La mesure a pu être faite tard ou après oxygène : le contexte prime.", 'Intoxication au CO à traiter comme telle'],
 ], note="Le taux d’HbCO ne prédit pas bien les séquelles neurologiques ; la décision d’oxygénothérapie hyperbare repose sur la clinique (perte de connaissance, signes neurologiques, grossesse, ischémie cardiaque)."),
'osmo': dict(lex='Osmolalité plasmatique / urinaire', cat='BIO', titre='Osmolalité plasmatique et urinaire',
 regex=r"osmolalit[ée]s?|osmolarit[ée]s?",
 p="L’osmolalité mesure le nombre de particules dissoutes par kilogramme d’eau (osmomètre) ; dans le plasma, elle dépend surtout du sodium. Elle classe une hyponatrémie (hypotonique ou non) et, dans l’urine, elle indique si l’hormone antidiurétique (ADH) agit.",
 cols=[B, S, D], rows=[
 ['Osmolalité plasmatique 275–295 mOsm/kg', "La valeur est normale.", '—'],
 ['Plasma < 275 mOsm/kg avec Na < 135 mmol/L', "L’hyponatrémie est hypotonique ; l’eau entre dans les cellules (risque d’œdème cérébral).", 'SIADH, diurétiques thiazidiques, hypovolémie, insuffisance cardiaque, potomanie'],
 ['Plasma normale ou élevée avec Na bas', "L’hyponatrémie n’est pas hypotonique : une autre osmole attire l’eau hors des cellules.", 'Hyperglycémie, mannitol, pseudohyponatrémie (lipides, protéines)'],
 ['Urine < 100 mOsm/kg dans une hyponatrémie', "L’ADH est freinée : le rein dilue au maximum ; l’apport d’eau dépasse la capacité d’excrétion.", 'Potomanie, faible apport de solutés (« tea and toast »)'],
 ['Urine > 100 mOsm/kg dans une hyponatrémie hypotonique', "L’ADH agit malgré l’hypotonie.", 'SIADH, hypovolémie, thiazidiques, insuffisance surrénalienne, hypothyroïdie sévère'],
 ], note="Le trou osmolaire (mesuré − calculé) > 10 mOsm/kg évoque une osmole non mesurée (éthanol, méthanol, éthylène glycol)."),
'natriu': dict(lex='Natriurèse / ionogramme urinaire', cat='BIO', titre='Sodium urinaire (natriurèse sur échantillon)',
 regex=r"natriur[èe]se|ionogramme urinaire|sodium urinaire|Na urinaire",
 p="Le sodium urinaire, mesuré sur un échantillon prélevé en même temps que le sang, reflète la façon dont le rein traite le sodium ; il sépare une perte extrarénale ou un volume circulant efficace bas (rein qui retient le sodium) d’une perte rénale ou d’un SIADH.",
 cols=[B, S, D], rows=[
 ['Na urinaire ≤ 30 mmol/L (hyponatrémie hypotonique)', "Le rein retient le sodium : le volume circulant efficace est bas.", 'Vomissements, diarrhée, insuffisance cardiaque, cirrhose'],
 ['Na urinaire > 30 mmol/L', "Le rein élimine le sodium.", 'SIADH, diurétiques, insuffisance surrénalienne, néphropathie avec perte de sel'],
 ['Na urinaire > 30 mmol/L sous diurétique', "Le résultat est ininterprétable tant que le diurétique agit.", 'Réévaluer après arrêt et selon l’examen clinique'],
 ], note="Seuil de 30 mmol/L selon la recommandation européenne 2014 sur l’hyponatrémie (Spasovski et al.)."),
'cetone': dict(lex='Corps cétoniques (cétonémie)', cat='BIO', titre='Corps cétoniques (β-hydroxybutyrate capillaire ou sanguin, cétonurie)',
 regex=r"c[ée]ton[ée]mie|corps c[ée]toniques|[βb](?:êta)?-?hydroxybutyrate|c[ée]tonurie",
 p="Quand l’insuline manque, le foie oxyde les acides gras en corps cétoniques (β-hydroxybutyrate surtout) ; leur accumulation provoque une acidose métabolique à trou anionique élevé. La mesure capillaire du β-hydroxybutyrate est plus précise que la bandelette urinaire.",
 cols=[B, S, D], rows=[
 ['β-hydroxybutyrate < 0,6 mmol/L', "La valeur est normale.", '—'],
 ['0,6–1,5 mmol/L', "Une cétose débute : on surveille et on corrige l’apport d’insuline et de glucides.", 'Jeûne, diabète déséquilibré'],
 ['1,5–3,0 mmol/L', "Le risque d’acidocétose est élevé.", 'Acidocétose débutante'],
 ['≥ 3,0 mmol/L avec acidose (pH < 7,30 ou bicarbonates < 15 mmol/L)', "Les critères d’acidocétose diabétique sont remplis.", 'Acidocétose diabétique (y compris euglycémique sous gliflozine)'],
 ], note="Une gliflozine (inhibiteur du SGLT2) peut donner une acidocétose avec une glycémie presque normale."),
'mg': dict(lex='Magnésémie', cat='BIO', titre='Magnésium plasmatique (magnésémie)',
 regex=r"magn[ée]s[ée]mie|hypomagn[ée]s[ée]mie",
 p="Le magnésium stabilise les membranes excitables et sert de cofacteur à la pompe Na⁺/K⁺-ATPase ; un déficit entretient une hypokaliémie et une hypocalcémie réfractaires et favorise les torsades de pointes.",
 cols=[B, S, D], rows=[
 ['Mg 0,70–1,05 mmol/L', "La valeur est normale.", '—'],
 ['Mg < 0,70 mmol/L', "Le déficit favorise arythmies, crampes et tétanie, et empêche la correction du potassium.", 'IPP au long cours, diurétiques, alcool, diarrhée'],
 ['Mg > 1,05 mmol/L', "L’excès déprime la conduction neuromusculaire.", 'Insuffisance rénale, perfusion de magnésium'],
 ]),
'stp': dict(lex='Dosage plasmatique (lithiémie, digoxinémie)', cat='BIO', titre='Suivi thérapeutique pharmacologique (lithiémie, digoxinémie, antiépileptiques)',
 regex=r"lithi[ée]mie|digoxin[ée]mie|suivi th[ée]rapeutique pharmacologique|concentrations? r[ée]siduelles?",
 p="Pour un médicament à marge thérapeutique étroite, le dosage vérifie que la concentration reste dans la zone efficace et non toxique. Il se fait au moment fixé : taux résiduel avant la prise suivante, ou au moins 6 heures après la prise de digoxine.",
 cols=[B, S, D], rows=[
 ['Lithiémie 0,5–0,8 mmol/L (taux résiduel 12 h)', "La zone d’entretien habituelle est atteinte.", '—'],
 ['Lithiémie > 1,2 mmol/L', "Une toxicité devient probable (tremblement grossier, ataxie, confusion).", 'Déshydratation, AINS, IEC, thiazidiques, insuffisance rénale'],
 ['Digoxinémie 0,6–1,2 nmol/L (≈ 0,5–0,9 µg/L)', "La zone visée en insuffisance cardiaque est atteinte.", '—'],
 ['Digoxinémie > 2,6 nmol/L (≈ 2 µg/L) ou symptômes', "Une intoxication digitalique est probable, d’autant plus si K⁺ est bas ou très élevé.", 'Insuffisance rénale, amiodarone, vérapamil, macrolides'],
 ], note="Un dosage prélevé trop tôt après la prise surestime l’exposition ; noter l’heure de la dernière prise."),
}
