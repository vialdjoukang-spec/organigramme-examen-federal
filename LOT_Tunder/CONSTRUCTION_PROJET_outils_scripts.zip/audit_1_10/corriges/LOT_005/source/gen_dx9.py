# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.9 · Endocardite infectieuse subaiguë (LOT 5, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('dx9')
M = meta('dx9', 'DX.9', 'Endocardite subaiguë', 'Endocardite infectieuse subaiguë', 'LOT_005_DX9_Endocardite_subaigue_AUDITÉ.html')
VEG = T('végétation', 'Une végétation est un amas de fibrine, de plaquettes et de bactéries fixé sur une valve ; elle peut se détacher et emboliser.')
BIOF = T('biofilm', 'Le biofilm est une couche de bactéries enrobées dans une matrice ; il les protège des défenses et des antibiotiques.')
EMB = T('embolie septique', 'Une embolie septique est un fragment infecté de végétation qui bouche une artère à distance (cerveau, rein, rate).')
PTS = []

# ---------- 1
PTS.append(POINT(1, 'Définition et sémantique',
 P(f'L’endocardite infectieuse est une infection de l’endocarde, surtout des valves, avec formation d’une {VEG}. '
   'La forme subaiguë évolue sur des semaines : fatigue, fébricule, sueurs, perte de poids, comme un « état grippal qui traîne ». '
   'Elle reste grave, parce qu’elle détruit la valve et cause des embolies.', 11) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Endocardite sur valve native', 'Infection d’une valve propre au patient', 'Endocardite sur prothèse'],
    ['Endocardite sur prothèse', 'Infection d’une valve artificielle', 'Thrombose de prothèse'],
    ['Endocardite sur dispositif', 'Infection des sondes de stimulateur ou de défibrillateur', 'Infection de la loge seule'],
    ['Endocardite à hémocultures négatives', 'Cultures stériles, souvent après antibiotique', 'Absence d’endocardite'],
    ['Maladie d’Osler', 'Ancien nom de la forme subaiguë', 'Maladie de Rendu-Osler (télangiectasies)'],
   ]), 11)))

# ---------- 2
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('Au niveau mondial, l’ESC 2023 rapporte une incidence de 13,8 pour 100 000 personnes par an en 2019, avec 66 300 décès. '
   'Dans le registre européen de l’ESC, la mortalité hospitalière est de 17,1 %.', 11, 37) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Incidence', '13,8/100 000 par an', 'Monde, 2019'],
    ['Endocardite sur valve native', '56,6 %', 'Registre européen, 3 116 patients'],
    ['Endocardite sur prothèse', '30,1 %', 'Même registre'],
    ['Endocardite sur dispositif', '9,9 %', 'Même registre'],
    ['Embolies', '20,6 %', 'Même registre'],
    ['Décès hospitalier', '17,1 %', 'Même registre'],
   ], 'Aucune donnée suisse publiée n’a été retrouvée ; les chiffres de l’original (600–800 cas, 7–10 pour 100 000) ne sont pas confirmés.') + P('Le terrain associe l’âge, les prothèses valvulaires, les dispositifs cardiaques, l’injection de drogues et un antécédent d’endocardite. '
          'Le pronostic s’aggrave avec l’insuffisance cardiaque, les complications cérébrales, un abcès et une végétation > 10 mm.', 37, 11), 37, 11)))

# ---------- 3
PTS.append(POINT(3, 'Physiopathologie',
 P('Une lésion de l’endothélium valvulaire attire plaquettes et fibrine. '
   f'Lors d’une bactériémie, les bactéries s’y fixent et forment un {BIOF}. '
   f'La végétation grossit, détruit la valve, libère des cytokines et cause des {EMB}s et des dépôts de complexes immuns.', 11) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les valves mitrale et aortique, soumises aux pressions élevées, sont les plus touchées ; la tricuspide chez l’usager de drogues.'],
    ['Physiologie', 'Pourquoi la valve est vulnérable : elle n’a presque pas de vaisseaux, donc peu de défenses locales.'],
    ['Physiopathologie', 'Les bactéries du biofilm échappent aux leucocytes ; des fragments partent dans la circulation.'],
    ['Clinique', 'D’où la fièvre prolongée, le souffle nouveau, les embolies et les signes immunologiques.'],
    ['Examens', 'Comme la bactériémie est continue, les hémocultures sont positives ; l’échocardiographie voit la végétation.'],
    ['Traitement', 'Comme les bactéries sont protégées, il faut des antibiotiques bactéricides IV pendant des semaines, parfois la chirurgie.'],
   ]), 11) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Bactériémie continue', 'Hémocultures', 'Antibiotique bactéricide'],
    ['Végétation et destruction valvulaire', 'Échocardiographie transthoracique puis transœsophagienne', 'Chirurgie si insuffisance cardiaque'],
    ['Abcès de l’anneau', 'Échocardiographie transœsophagienne, ECG (bloc)', 'Chirurgie urgente'],
    ['Embolies', 'Scanner, IRM cérébrale', 'Chirurgie si végétation ≥ 10 mm et autre indication'],
    ['Complexes immuns', 'Sédiment urinaire, créatinine', 'Traitement de l’infection'],
   ]), 11) +
 F('Critères de Duke (ESC 2023) : calcul',
   TAB(['Catégorie', 'Contenu'], [
    ['Critère majeur microbiologique', 'Germe typique dans 2 hémocultures séparées, ou bactériémie persistante'],
    ['Critère majeur d’imagerie', 'Végétation, abcès, perforation ou fuite de prothèse (échocardiographie, scanner, TEP)'],
    ['Critères mineurs', 'Prédisposition, fièvre ≥ 38 °C, phénomènes vasculaires, phénomènes immunologiques, preuve microbiologique mineure'],
    ['Certaine', '2 majeurs, ou 1 majeur et au moins 3 mineurs, ou 5 mineurs'],
    ['Possible', '1 majeur et 1–2 mineurs, ou 3–4 mineurs'],
   ], 'Correction de l’original : les « scores pronostiques d’Eichhorn » n’existent pas dans les recommandations ESC et ont été retirés.') +
   P('Exemple de l’original : homme de 59 ans, Streptococcus gallolyticus dans 2 hémocultures sur 2 (majeur) et végétation aortique de 11 mm en échocardiographie transœsophagienne (majeur). '
     'L’endocardite est certaine. '
     'Ce germe impose une coloscopie, à la recherche d’une tumeur du côlon.', 11), 11)))

# ---------- 4
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin cherche d’abord une urgence : insuffisance cardiaque aiguë, AVC embolique, sepsis. '
   'Il pense ensuite à l’endocardite devant toute fièvre prolongée avec souffle, prothèse ou injection de drogues. '
   'Il recherche enfin le germe, car il oriente vers la porte d’entrée.', 11) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même unité : % des endocardites du registre européen de l’ESC selon le germe)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Endocardite à staphylocoques' + PR('44,1 %', 37), 'Évolution rapide, porte d’entrée cutanée, cathéter', 'Hémocultures'],
    ['Endocardite à entérocoques' + PR('15,8 %', 37), 'Sujet âgé, porte d’entrée urinaire ou digestive', 'Hémocultures'],
    ['Endocardite à streptocoques oraux' + PR('12,3 %', 37), 'Forme subaiguë, soins dentaires', 'Hémocultures, examen dentaire'],
    ['Endocardite à Streptococcus gallolyticus' + PR('6,6 %', 37), 'Tumeur du côlon associée', 'Hémocultures, coloscopie'],
    ['Lymphome, connectivite, ACG', 'Fièvre prolongée sans germe', 'Imagerie, biopsie'],
   ]) + P('Les fréquences ne sont pas des probabilités devant un patient donné. '
          'Pour les maladies non infectieuses, aucune fréquence dans cette même population n’a été retrouvée.', 37), 37)))

# ---------- 5
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien précise la durée de la fièvre, les sueurs et la perte de poids. '
   'Il relève les prothèses, les dispositifs, les soins dentaires et les antibiotiques déjà pris.', 11) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Avez-vous une valve artificielle, un stimulateur ?', 'Terrain à haut risque.', 'Échocardiographie transœsophagienne d’emblée.'],
    ['Avez-vous eu des soins dentaires, une coloscopie ?', 'Porte d’entrée.', 'Germe attendu.'],
    ['Injectez-vous des drogues ?', 'Endocardite droite, S. aureus.', 'Antibiotique adapté.'],
    ['Avez-vous déjà reçu un antibiotique ?', 'Hémocultures faussement négatives.', 'Recherche d’anticorps, PCR.'],
    ['Avez-vous eu un trouble neurologique bref ?', 'Embolie cérébrale.', 'Imagerie cérébrale.'],
   ]), 11) +
 U('<b>Drapeaux rouges (urgence, 144)</b> : dyspnée ou œdème pulmonaire, déficit neurologique, douleur lombaire ou abdominale brutale, bloc auriculo-ventriculaire nouveau, sepsis.', 11)))

# ---------- 6
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen ausculte le cœur à la recherche d’un souffle nouveau. '
   'Il cherche les signes vasculaires et immunologiques, la splénomégalie et un déficit neurologique. '
   'L’absence de souffle ne suffit pas à exclure une endocardite.', 11) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Auscultation cardiaque', 'Pas de souffle', 'Souffle de régurgitation nouveau : atteinte valvulaire'],
    ['Peau et conjonctives', 'Pas de pétéchies', 'Pétéchies, lésions de Janeway : phénomènes vasculaires'],
    ['Pulpe des doigts', 'Indolore', 'Nodosités d’Osler : phénomène immunologique'],
    ['Fond d’œil', 'Normal', 'Taches de Roth'],
    ['Palpation de la rate', 'Non palpable', 'Splénomégalie'],
    ['Examen neurologique', 'Normal', 'Déficit : embolie cérébrale'],
   ]), 11)))

# ---------- 7
TERMES = ('Termes : ' + T('lésions de Janeway', 'Les lésions de Janeway sont des macules hémorragiques indolores des paumes et des plantes, d’origine embolique.') + ', '
   + T('nodosités d’Osler', 'Les nodosités d’Osler sont de petits nodules douloureux de la pulpe des doigts, d’origine immunologique.') + ', '
   + T('taches de Roth', 'Les taches de Roth sont des hémorragies de la rétine à centre blanc.') + ', '
   + T('anévrisme mycotique', 'Un anévrisme mycotique est une dilatation d’une artère infectée par une embolie septique ; il peut se rompre.') + ', '
   + T('fébricule', 'La fébricule est une fièvre modérée, souvent entre 37,5 et 38 °C.') + '.')
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fatigue, les sueurs, la fébricule et la perte de poids. '
   'Les signes physiques sont le souffle, la splénomégalie et les signes cutanés. '
   'Les complications emboliques ou cardiaques révèlent parfois la maladie.', 11, 37) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Gravité'], [
    ['Syndrome infectieux subaigu', 'Fièvre prolongée, sueurs, amaigrissement', 'Diagnostic souvent tardif'],
    ['Insuffisance valvulaire aiguë', 'Dyspnée, œdème pulmonaire, souffle', 'Chirurgie urgente'],
    ['Syndrome embolique', 'Déficit neurologique, infarctus rénal ou splénique', 'Embolies chez 20,6 %'],
    ['Syndrome immunologique', 'Hématurie, nodosités d’Osler', 'Glomérulonéphrite'],
   ]) + P(TERMES, 11, 37), 11, 37)))

# ---------- 8
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le critère de Duke modifié par la recommandation ESC 2023 combine critères majeurs et mineurs. '
   'Le diagnostic est certain avec 2 critères majeurs ; la taille d’une végétation (≥ 10 mm) mesure le risque embolique, pas le diagnostic. '
   'Un seul critère majeur ne suffit pas : il faut y ajouter au moins 3 critères mineurs.', 11) +
 F('Classement de Duke (ESC 2023)',
   TAB(['Classement', 'Combinaison'], [
    ['Certaine', '2 majeurs ; 1 majeur + au moins 3 mineurs ; 5 mineurs'],
    ['Possible', '1 majeur + 1–2 mineurs ; 3–4 mineurs'],
    ['Rejetée', 'Ni certaine ni possible'],
   ], 'Correction de l’original : il n’existe pas de recommandation ESC 2025 ni de critères propres à la Société suisse d’infectiologie ; la version de référence est ESC 2023.'), 11)))

# ---------- 9
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Hémocultures (au moins 3 paires à 30 minutes d’intervalle, 10 mL chacune)', 'Germe et sensibilité', 'Négatives après antibiotique', 'Prélever avant tout antibiotique'],
    ['Échocardiographie transœsophagienne', 'Végétation, abcès, perforation', 'Meilleure que la transthoracique ; chiffres exacts à vérifier', 'Examen semi-invasif'],
   ]), 11) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Hémocultures, NFS, CRP, créatinine, sédiment urinaire, ECG', 'Suspicion d’endocardite'],
    ['Première', 'Échocardiographie transthoracique', 'Suspicion d’endocardite'],
    ['Seconde', 'Échocardiographie transœsophagienne', 'Recommandée même si la transthoracique est positive, sauf exceptions'],
    ['Seconde', 'TEP-FDG ou scanner cardiaque', 'Prothèse, dispositif, doute persistant'],
    ['Seconde', 'Scanner ou IRM cérébrale', 'Signes neurologiques ou bilan avant chirurgie'],
   ]), 11) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Les <b>hémocultures</b> se prélèvent avant l’antibiotique, par ponctions veineuses séparées.',
       'L’<b>échocardiographie transœsophagienne</b> demande un patient à jeun.',
       'Le <b>TEP</b> demande un régime pauvre en sucres la veille, pour réduire la fixation normale du cœur.']), 11) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Hémocultures à germe typique', '2 séparées', 'Critère majeur', 'Échocardiographie'],
    ['Végétation', '≥ 10 mm', 'Risque embolique élevé', 'Discussion chirurgicale'],
    ['Bloc auriculo-ventriculaire nouveau', 'À l’ECG', 'Abcès de l’anneau aortique', 'Échocardiographie transœsophagienne urgente'],
    ['Hémocultures négatives', 'Après 5 jours', 'Antibiotique préalable ou germe difficile', 'Recherche d’anticorps (Coxiella, Bartonella), PCR'],
   ]), 11) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (staphylocoque à coagulase négative dans une seule paire)', 'Contaminant probable, sauf prothèse'],
    ['Résultat négatif mais clinique typique (échocardiographie normale)', 'Répéter l’échocardiographie à 5–7 jours, TEP'],
    ['Résultat limite (endocardite possible)', 'Réévaluer pendant le suivi'],
    ['Grossesse', 'Échocardiographie sans risque ; avis obstétrical'],
    ['Enfant', 'Cardiopathie congénitale : centre pédiatrique'],
    ['Insuffisance rénale (DFGe bas)', 'Adapter la gentamicine et la vancomycine'],
    ['Allergie à l’iode, pacemaker ou IRM', 'TEP ou échocardiographie plutôt que scanner injecté'],
   ]), 11))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Les hémocultures donnent le germe. '
   'L’échocardiographie montre la lésion. '
   'Le TEP et le scanner aident pour les prothèses et les embolies.', 11) + P9))

# ---------- 10
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si l’endocardite est suspectée, alors le médecin prélève 3 paires d’hémocultures et demande une échocardiographie transthoracique. '
   'Si la suspicion persiste, alors il demande une échocardiographie transœsophagienne. '
   'Si une complication apparaît, alors l’équipe d’endocardite discute la chirurgie.', 11) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Patient stable', 'Attendre le germe avant l’antibiotique', 'Hémocultures à 24–48 heures'],
    ['Sepsis ou instabilité', 'Antibiotique probabiliste après les hémocultures', 'Adaptation au germe'],
    ['Insuffisance cardiaque', 'Chirurgie en urgence', 'Équipe d’endocardite'],
    ['Végétation ≥ 10 mm avec embolie malgré antibiotique', 'Chirurgie urgente', 'Imagerie cérébrale'],
    ['Patient stable après 10 jours de traitement IV', 'Discuter un relais oral (essai POET)', 'Suivi rapproché'],
   ]), 11)))

# ---------- 11
MED = F('Fiches médicamenteuses (posologies AIPS et recommandations)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Pénicilline G (pénicilline)', 'Inhibe la synthèse de la paroi ; demi-vie courte', '12–18 millions UI/j IV en 4–6 doses ou en continu ; 4 semaines (valve native), 6 semaines (prothèse)', 'Allergie, convulsions à forte dose'],
   ['Ceftriaxone, Rocephin® (céphalosporine)', 'Bactéricide ; une dose par jour', '2 g/j IV ; mêmes durées', 'Allergie, boue biliaire'],
   ['Flucloxacilline (pénicilline antistaphylococcique)', 'Résiste aux pénicillinases', '12 g/j IV en 4–6 doses ; 4–6 semaines (valve native)', 'Hépatite, phlébite'],
   ['Rifampicine (rifamycine)', 'Agit sur le biofilm', 'Prothèse : 900 mg/j en 3 doses, au moins 6 semaines', 'Inducteur enzymatique puissant'],
   ['Gentamicine (aminoside)', 'Synergie bactéricide', '3 mg/kg/j en une dose ; 2 semaines (prothèse à staphylocoque, schéma court à streptocoque)', 'Néphrotoxicité, ototoxicité'],
  ]) + P('Correction de l’original : la gentamicine n’est plus associée à l’endocardite à staphylocoque sur valve native. Le schéma de 2 semaines avec gentamicine est réservé aux streptocoques sensibles sur valve native non compliquée. L’original citait Orbenine®, nom français ; la spécialité suisse est à vérifier dans l’AIPS.', 11, 1), 11, 1)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge stérilise la végétation, parce que les bactéries y sont protégées. '
   'Elle repose sur des antibiotiques bactéricides IV prolongés et, si besoin, sur la chirurgie. '
   'Une équipe d’endocardite pluridisciplinaire décide des cas complexes.', 11) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans une forme compliquée (insuffisance cardiaque, abcès, embolies), le but est d’opérer au bon moment. Dans une forme non compliquée, le but est la guérison par antibiotiques, avec relais oral possible.', 11), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Forme compliquée, en urgence</b> : 144 ; hémocultures ; antibiotique probabiliste si sepsis ; avis chirurgical immédiat.',
         '<b>B. Antibiothérapie ciblée</b> : selon le germe et la sensibilité, pendant 4–6 semaines.',
         '<b>C. Forme non compliquée, en ambulatoire</b> : antibiotique IV à domicile ou relais oral chez un patient stable ; mesures générales (hygiène dentaire, éducation sur la fièvre).',
         '<b>D. Porte d’entrée</b> : soins dentaires, coloscopie si S. gallolyticus, retrait d’un dispositif infecté.']), 11) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('La conduite automobile est suspendue après une embolie cérébrale ou une chirurgie cardiaque, selon l’avis médical.',
            'Le traitement IV à domicile permet parfois une reprise partielle du travail.'), 59, 60, 61) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Éviter les aminosides ; avis obstétrical et cardiologique'],
      ['Usager de drogues', 'Endocardite droite ; prise en charge de l’addiction'],
      ['Enfant', 'Doses pédiatriques ; centre spécialisé'],
      ['Sujet âgé', 'Porte d’entrée digestive ou urinaire plus fréquente ; fonction rénale à surveiller'],
      ['Insuffisance hépatique', 'Prudence avec la rifampicine'],
      ['Insuffisance rénale (DFGe)', 'Adapter les doses, surveiller la gentamicine'],
     ]), 11), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Température, hémocultures', 'Hémocultures à 48–72 heures', 'Hémocultures positives : chercher un abcès'],
    ['Créatinine, taux de gentamicine', '2 fois par semaine', 'Hausse : réduction ou arrêt'],
    ['Auscultation, ECG', 'Chaque jour', 'Souffle ou bloc nouveaux : échocardiographie'],
    ['Échocardiographie', 'En fin de traitement', 'Base pour le suivi'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Apyrexie et hémocultures négatives.', 'Traitement IV à domicile ou relais oral organisé.', 'Porte d’entrée traitée.', 'Suivi cardiologique et dentaire planifié.']), 11) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La mortalité hospitalière est de 17,1 % dans le registre européen de l’ESC. Le relais oral chez le patient stable fait désormais partie des recommandations. Les bactériophages restent expérimentaux ; l’affirmation de l’original sur leur usage en Suisse en 2026 n’est pas sourcée.', 37, 11), 'fenetre')))

# ---------- 12
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur l’hygiène dentaire et cutanée, pour tous. '
   'L’antibioprophylaxie est réservée aux patients à haut risque avant un soin dentaire touchant la gencive ou l’apex : amoxicilline 2 g per os 30–60 minutes avant. '
   'La prévention tertiaire organise le suivi après la guérison ; les recommandations suisses reprennent l’ESC.', 11, 35) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Hygiène dentaire, asepsie des cathéters'],
    ['Secondaire', 'Hémocultures avant tout antibiotique en cas de fièvre inexpliquée'],
    ['Tertiaire', 'Suivi, carte de prophylaxie pour les patients à haut risque'],
   ], 'Haut risque : antécédent d’endocardite, prothèse valvulaire (y compris percutanée), certaines cardiopathies congénitales.'), 11)))

# ---------- 13
PTS.append(POINT(13, 'Points clés',
 P('Le médecin prélève des hémocultures avant tout antibiotique devant une fièvre inexpliquée. '
   'Il ausculte le cœur à chaque visite. '
   'Il demande une échocardiographie transœsophagienne quand la suspicion persiste. '
   'Il cherche la porte d’entrée et traite pendant des semaines.', 11)))

# ---------- 14
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Exclure l’endocardite sur une échocardiographie transthoracique normale.', 'Échocardiographie transœsophagienne si la suspicion persiste.'],
  ['Donner un antibiotique « à l’aveugle » pour un état grippal qui traîne.', 'Hémocultures d’abord.'],
  ['Oublier la coloscopie après S. gallolyticus.', 'Chercher une tumeur du côlon.'],
  ['Ajouter de la gentamicine à une endocardite à staphylocoque sur valve native.', 'Non recommandé.'],
  ['Prescrire une antibioprophylaxie à tout porteur de souffle.', 'Seulement en cas de haut risque.'],
 ]) + P('Ces pièges reprennent les recommandations ESC 2023.', 11)))

CTX = {'_prefixe': 'Dans l’endocardite',
 'hemoc': 'Au moins 3 paires d’hémocultures avant l’antibiotique identifient le germe.',
 'echocoeur': 'L’échocardiographie montre la végétation, l’abcès et la fuite valvulaire.',
 'nfs': 'La NFS montre souvent une anémie inflammatoire.',
 'crp': 'La CRP suit la réponse au traitement.',
 'creat': 'La créatinine guide les doses et cherche une atteinte rénale.',
 'ecbu': 'Le sédiment urinaire cherche une hématurie par glomérulonéphrite.',
 'ecg': 'L’ECG cherche un bloc auriculo-ventriculaire, signe d’abcès.',
 'tep': 'Le TEP-FDG montre une infection de prothèse ou de dispositif.',
 'tdm': 'Le scanner cherche les embolies et les abcès.',
 'irm': 'L’IRM cérébrale cherche les embolies cérébrales.',
 'pcr': 'La PCR sur valve opérée identifie un germe non cultivé.',
 'vs': 'La VS est élevée mais non spécifique.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
