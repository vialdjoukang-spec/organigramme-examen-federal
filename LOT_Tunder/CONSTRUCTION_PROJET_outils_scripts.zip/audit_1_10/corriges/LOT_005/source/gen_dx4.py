# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.4 · Troubles métaboliques et hydro-électrolytiques (LOT 5, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('dx4')
M = meta('dx4', 'DX.4', 'Troubles électrolytiques', 'Troubles métaboliques et hydro-électrolytiques (sodium, potassium, calcium, glucose)', 'LOT_005_DX4_Troubles_metaboliques_electrolytiques_AUDITÉ.html')
OSMO = T('équilibre osmotique', 'L’équilibre osmotique dépend de l’osmolalité, c’est-à-dire le nombre de particules dissoutes par kilogramme d’eau ; l’eau traverse les membranes vers le compartiment où l’osmolalité est la plus élevée.')
ODS = T('syndrome de démyélinisation osmotique', 'Le syndrome de démyélinisation osmotique est une destruction de la gaine des neurones du tronc cérébral après une correction trop rapide d’une hyponatrémie chronique ; il donne paralysie, troubles de la parole et de la déglutition, parfois irréversibles.')
VOL = T('volémie', 'La volémie est le volume de sang circulant ; on l’estime par la pression, la fréquence cardiaque, les veines du cou, les œdèmes et la soif.')
SIADH = T('sécrétion inappropriée d’hormone antidiurétique', 'Dans ce syndrome, l’hormone antidiurétique est sécrétée alors que le sang est déjà dilué ; le rein retient l’eau et la natrémie baisse, sans œdème ni déshydratation.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('Un trouble hydro-électrolytique est une concentration anormale de sodium, de potassium, de calcium ou de glucose dans le sang. '
   'Il se manifeste d’abord par un malaise flou : fatigue, nausées, faiblesse ou confusion. '
   'Il devient grave quand il menace le cerveau (sodium, glucose) ou le cœur (potassium, calcium).', 12, 85, 45) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition exacte (adulte)', 'À ne pas confondre avec'], [
    ['Hyponatrémie', 'Na < 135 mmol/L ; profonde si < 125 mmol/L', 'Pseudohyponatrémie (lipides, protéines très élevés)'],
    ['Hyponatrémie de transfert', 'Na abaissé par un excès de glucose qui attire l’eau hors des cellules', 'Hyponatrémie hypotonique vraie'],
    ['Hyperkaliémie', 'K > 5,5 mmol/L ; sévère si ≥ 6,5 mmol/L', 'Pseudohyperkaliémie (hémolyse du prélèvement)'],
    ['Hypokaliémie', 'K < 3,5 mmol/L ; sévère si < 2,5 mmol/L', 'Transfert passager après insuline ou salbutamol'],
    ['Hypercalcémie', 'Calcium corrigé > 2,6 mmol/L ; sévère si > 3,5 mmol/L', 'Fausse hausse par albumine élevée (déshydratation)'],
   ]) + P(f'L’{OSMO} explique la plupart des symptômes du sodium et du glucose.', 12))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('Aucune source suisse publiée retrouvée ne chiffre la part des hospitalisations compliquées d’un trouble électrolytique ; les chiffres de l’original (10–25 %, et 15–30 % chez la personne âgée selon la Société suisse de néphrologie) n’ont pas été confirmés. '
   'Dans la littérature internationale, l’hyponatrémie touche 15 à 30 % des patients hospitalisés selon la définition, et l’hypokaliémie jusqu’à 20 %. '
   'Le terrain à risque associe l’âge avancé, les diurétiques, l’insuffisance rénale et le cancer, et la mortalité hospitalière augmente avec la profondeur du trouble.', 44, 88, 91) +
 F('Chiffres et terrain',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Hyponatrémie (Na < 135 mmol/L)', '15–30 %', 'Patients hospitalisés (Upadhyay 2006)'],
    ['Hypokaliémie', 'Jusqu’à 20 %', 'Patients hospitalisés (Gennari 1998)'],
    ['Hypercalcémie au cours d’un cancer', '20–30 % des patients cancéreux', 'Stewart 2005'],
    ['Part suisse', 'Non publiée', 'Chiffres de l’original retirés'],
   ]) + P('Le pronostic dépend de la cause : l’hypercalcémie d’un cancer annonce souvent une maladie avancée.', 90))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Les neurones et les cellules cardiaques fonctionnent grâce à des différences de concentration entre l’intérieur et l’extérieur de la cellule. '
   'Le sodium et le glucose règlent le volume des cellules par l’osmolalité, tandis que le potassium et le calcium règlent l’excitabilité. '
   'Un écart rapide est plus dangereux qu’un écart lent, parce que le cerveau a besoin de 48 heures pour s’adapter.', 12, 85) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Le rein règle le sodium, le potassium et l’eau ; l’hypophyse libère l’hormone antidiurétique ; les parathyroïdes règlent le calcium.'],
    ['Physiologie', 'Pourquoi l’équilibre tient : l’hormone antidiurétique retient l’eau quand le sang se concentre, l’aldostérone échange le sodium contre le potassium, la PTH libère le calcium de l’os.'],
    ['Physiopathologie', 'Une hyponatrémie hypotonique fait entrer l’eau dans les neurones (œdème cérébral) ; une hyperkaliémie rapproche le potentiel de repos du seuil et ralentit la conduction ; une hypercalcémie freine les nerfs et le tube digestif et empêche le rein de concentrer l’urine.'],
    ['Clinique', 'D’où céphalées et confusion (sodium), faiblesse et arythmie (potassium), soif, constipation et confusion (calcium).'],
    ['Examens', 'Comme le mécanisme dépend de l’eau et des hormones, on mesure l’osmolalité du sang et de l’urine, le sodium urinaire, la PTH et l’ECG.'],
    ['Traitement', 'On protège d’abord l’organe menacé (cerveau, cœur), puis on corrige lentement et on traite la cause.'],
   ]), 12, 85, 45) +
 F('Hyperglycémie et dilution du sodium : formules de Katz et de Hillier',
   P('Le glucose attire l’eau hors des cellules et dilue le sodium. On ajoute donc 1,6 mmol/L (Katz) ou 2,4 mmol/L (Hillier) de sodium par 5,6 mmol/L de glucose au-dessus de 5,6 mmol/L. Exemple de l’original : Na 126 mmol/L et glucose 25,6 mmol/L. La natrémie corrigée vaut 126 + 1,6 × 20/5,6 ≈ 131,7 mmol/L (Katz) ou 126 + 2,4 × 20/5,6 ≈ 134,6 mmol/L (Hillier). Correction de l’audit : l’original concluait à une natrémie « normale », alors qu’elle reste basse ou limite.', 86, 87), 'fenetre') +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Excès d’eau (SIADH, potomanie, thiazide)', 'Osmolalité plasmatique et urinaire, sodium urinaire', 'Restriction hydrique, arrêt du thiazide'],
    ['Perte de sodium et d’eau (vomissements, diurétiques)', 'Volémie, sodium urinaire < 30 mmol/L', 'NaCl 0,9 %'],
    ['Défaut d’excrétion du potassium (IRA, IECA, spironolactone)', 'Créatinine, ECG', 'Calcium IV, insuline et glucose, arrêt des médicaments'],
    ['Libération de calcium par l’os (PTHrP, métastases, myélome)', 'PTH, PTHrP, électrophorèse des protéines', 'Hydratation, zolédronate'],
    ['Carence en insuline', 'Glycémie, cétonémie, gazométrie', 'Insuline, liquides, potassium'],
   ]) + P(f'Le {SIADH} est la cause la plus fréquente d’hyponatrémie normovolémique.', 12))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin traite d’abord l’urgence : il fait un ECG dans les minutes qui suivent un potassium ou un calcium anormal, et il évalue l’état neurologique si le sodium est bas. '
   'Il classe ensuite le trouble selon la volémie et l’osmolalité. '
   'Il cherche enfin la cause, souvent un médicament (thiazide, IECA, spironolactone, laxatif) ou un cancer.', 12, 85, 45) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même unité : % des patients hospitalisés)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Hyponatrémie' + PR('15–30 % des hospitalisés', 44), 'Confusion, nausées, chutes ; thiazide, ISRS', 'Osmolalité, sodium urinaire'],
    ['Hypokaliémie' + PR('jusqu’à 20 % des hospitalisés', 88), 'Faiblesse, crampes ; diurétique, diarrhée', 'Potassium urinaire, ECG'],
    ['Hypercalcémie maligne' + PR('20–30 % des patients cancéreux (autre population)', 90), 'Soif, constipation, confusion, cancer connu', 'PTH basse, PTHrP'],
    ['Hyperkaliémie', 'Insuffisance rénale, IECA, spironolactone ; souvent sans symptôme', 'ECG, répétition sans hémolyse'],
    ['Hyperparathyroïdie primaire', 'Femme ménopausée, calculs rénaux, calcium peu élevé', 'PTH normale ou haute'],
    ['Acidocétose ou état hyperosmolaire', 'Soif, polyurie, perte de poids, haleine cétonique', 'Glycémie, cétonémie, gazométrie'],
   ]) + P('Les fréquences ne sont pas des probabilités devant un patient. Pour l’hyperkaliémie, l’hyperparathyroïdie et les crises hyperglycémiques, aucune fréquence hospitalière comparable n’a été retrouvée.', 44, 88, 90))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien relève la liste des médicaments, les boissons, les pertes digestives et les signes de cancer. '
   'Il date le début des symptômes, car une hyponatrémie de moins de 48 heures se corrige plus vite qu’une hyponatrémie ancienne.', 12, 91) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Quels médicaments, depuis quand ?', 'Thiazide, ISRS, IECA, spironolactone, lithium, laxatifs.', 'Arrêt du médicament en cause.'],
    ['Combien buvez-vous, faites-vous un sport d’endurance ?', 'Potomanie, hyponatrémie d’effort.', 'Restriction hydrique.'],
    ['Avez-vous vomi ou eu de la diarrhée ?', 'Perte de sodium et de potassium.', 'NaCl 0,9 %, potassium.'],
    ['Avez-vous soif, urinez-vous beaucoup ?', 'Hyperglycémie, hypercalcémie.', 'Glycémie, calcium.'],
    ['Avez-vous maigri, avez-vous des douleurs osseuses ?', 'Cancer ou myélome.', 'Électrophorèse, imagerie.'],
    ['Depuis quand êtes-vous confus ?', 'Durée < 48 heures ou > 48 heures.', 'Vitesse de correction.'],
   ])) +
 U('<b>Drapeaux rouges, qui imposent une hospitalisation (144 si instabilité)</b> : convulsions, somnolence ou coma, vomissements répétés avec Na < 130 mmol/L, anomalie ECG avec K ≥ 6,5 mmol/L, calcium > 3,5 mmol/L, oligurie.', 12, 85, 45)))
PTS.append(POINT(6, 'Examen clinique',
 P(f'Le médecin évalue d’abord la {VOL} : pression couchée et debout, fréquence cardiaque, veines du cou, œdèmes et muqueuses. '
   'Il examine ensuite l’état de conscience, la force musculaire et les réflexes. '
   'L’estimation clinique de la volémie est imprécise ; le sodium urinaire aide quand le doute persiste.', 12, 58) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Pression couchée puis debout', 'Baisse < 20 mmHg', 'Baisse plus forte, tachycardie : hypovolémie'],
    ['Veines du cou, œdèmes, crépitants', 'Veines plates assis, pas d’œdème', 'Turgescence, œdèmes : hypervolémie (insuffisance cardiaque, cirrhose)'],
    ['Muqueuses, pli cutané', 'Muqueuses humides', 'Sécheresse : déshydratation (pli peu fiable chez la personne âgée)'],
    ['Score de Glasgow', '15', 'Baisse : encéphalopathie hyponatrémique ou hypercalcémique'],
    ['Force et réflexes', 'Normaux', 'Faiblesse : hypokaliémie ou hyperkaliémie ; réflexes faibles : hypercalcémie'],
    ['Signes de Chvostek et de Trousseau', 'Absents', 'Présents : hypocalcémie ou hypomagnésémie'],
   ]))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la fatigue, les nausées, la soif, les crampes et la confusion. '
   'Les signes physiques sont l’hypotension, les œdèmes, la faiblesse musculaire et les troubles de la conscience. '
   'Les signes ne permettent pas de deviner l’ion en cause ; seule la prise de sang le dit.', 12, 45) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Gravité'], [
    ['Encéphalopathie hyponatrémique', 'Céphalées, nausées, vomissements, confusion, convulsions, coma', 'Vomissements, somnolence, convulsions : symptômes sévères'],
    ['Crise hypercalcémique', 'Soif, polyurie, constipation, nausées, confusion, QT court', 'Calcium > 3,5 mmol/L'],
    ['Hyperkaliémie', 'Faiblesse, palpitations, souvent rien', 'Ondes T pointues, QRS larges, bradycardie'],
    ['Hypokaliémie', 'Crampes, faiblesse, constipation, palpitations', 'Onde U, arythmie, paralysie'],
    ['Crise hyperglycémique', 'Soif, polyurie, perte de poids, respiration ample', 'Acidose, déshydratation, coma'],
   ]) + P('Termes : ' + T('ondes T pointues', 'Les ondes T pointues sont hautes, étroites et symétriques ; elles sont le premier signe ECG de l’hyperkaliémie.') + ', ' + T('onde U', 'L’onde U est une petite onde après l’onde T ; elle grandit dans l’hypokaliémie.') + ', ' + T('QT court', 'Le QT court traduit une repolarisation accélérée par l’excès de calcium.') + ', ' + T('respiration de Kussmaul', 'La respiration de Kussmaul est ample et profonde ; elle élimine le CO2 pour compenser une acidose métabolique.') + ', ' + T('polyurie', 'La polyurie est une production d’urine supérieure à 3 litres par jour ; le glucose ou le calcium en excès empêchent le rein de retenir l’eau.') + '.', 85, 88, 45, 89))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le critère principal est biologique : le seuil de 135 mmol/L définit l’hyponatrémie selon la recommandation européenne de 2014. '
   'Un ionogramme anormal ne suffit pas à poser le diagnostic de cause ; il faut l’osmolalité, le sodium urinaire et la volémie. '
   'La société européenne d’endocrinologie classe l’hyponatrémie selon le sodium et selon les symptômes.', 12, 91) +
 F('Seuils de gravité (adulte)',
   TAB(['Ion', 'Léger', 'Modéré', 'Sévère ou profond', 'Source'], [
    ['Sodium (mmol/L)', '130–135', '125–129', '< 125', 'Spasovski 2014'],
    ['Potassium élevé (mmol/L)', '5,5–5,9', '6,0–6,4', '≥ 6,5', 'UK Kidney Association 2020'],
    ['Potassium bas (mmol/L)', '3,0–3,4', '2,5–2,9', '< 2,5', 'Gennari 1998'],
    ['Calcium corrigé (mmol/L)', '< 3,0', '3,0–3,5', '> 3,5', 'Endocrine Society 2023'],
   ], 'Correction de l’audit : l’original classait 130–134 mmol/L comme modéré et donnait des seuils de calcium contradictoires.') +
   P('Calcium corrigé = calcium total + 0,02 × (40 − albumine en g/L). Le calcium ionisé est préférable quand l’albumine est très basse.', 45), 12, 85, 88, 45)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Ionogramme sanguin', 'Valeur exacte du sodium, du potassium, du chlore, des bicarbonates', 'Méthode de référence, sans sensibilité ni spécificité au sens diagnostique', 'Hémolyse : fausse hyperkaliémie'],
    ['Osmolalité plasmatique mesurée', 'Hyponatrémie hypotonique (< 275 mOsm/kg)', 'Mesure de référence', 'Délai selon le laboratoire'],
    ['Calcium ionisé', 'Calcium actif', 'Plus fiable que le calcium total corrigé', 'Prélèvement sans garrot prolongé'],
   ]), 12, 45) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'Ionogramme, créatinine, urée, glycémie, calcium, albumine, magnésium', 'Tout malaise inexpliqué chez la personne âgée'],
    ['Première', 'ECG', 'Potassium ou calcium anormal'],
    ['Première', 'Gazométrie veineuse, cétonémie', 'Glycémie élevée, respiration ample'],
    ['Seconde', 'Osmolalité urinaire, natriurèse', 'Hyponatrémie hypotonique'],
    ['Seconde', 'TSH, cortisol du matin', 'Hyponatrémie normovolémique'],
    ['Seconde', 'PTH, PTHrP, 25-OH-vitamine D, électrophorèse des protéines', 'Hypercalcémie'],
   ]), 12, 45, 89) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['Le <b>ionogramme urinaire</b> se prélève avant le NaCl et avant tout diurétique, sinon le sodium urinaire n’est plus interprétable.',
       'Le <b>cortisol</b> se prélève le matin entre 7 et 9 heures.',
       'La <b>PTH</b> se dose en même temps que le calcium.',
       'Un <b>potassium</b> élevé sans anomalie ECG se recontrôle sans garrot prolongé, pour exclure une hémolyse.']), 12, 45, 85) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['Osmolalité urinaire', '≤ 100 mOsm/kg', 'Excès d’apport d’eau (potomanie)', 'Restriction hydrique'],
    ['Sodium urinaire', '≤ 30 mmol/L', 'Volume circulant efficace bas', 'NaCl 0,9 % si hypovolémie'],
    ['Sodium urinaire', '> 30 mmol/L', 'SIADH, diurétique, insuffisance surrénalienne', 'Arrêt du diurétique, cortisol'],
    ['PTH', 'Basse avec calcium élevé', 'Cause non parathyroïdienne (cancer, vitamine D)', 'PTHrP, imagerie'],
    ['ECG avec K élevé', 'T pointues, QRS larges', 'Toxicité cardiaque', 'Calcium IV immédiat'],
   ]), 12, 45, 85) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (K élevé sans cause)', 'Répéter sans hémolyse, sur sang veineux'],
    ['Résultat négatif mais clinique typique (calcium total normal, albumine basse)', 'Calcium corrigé ou ionisé'],
    ['Résultat limite (Na 130–135 mmol/L)', 'Contrôle après arrêt du médicament suspect'],
    ['Grossesse', 'Normes différentes (Na un peu plus bas) ; avis spécialisé'],
    ['Enfant', 'Seuils pédiatriques ; perfusion adaptée au poids'],
    ['Insuffisance rénale (DFGe bas)', 'Hyperkaliémie plus fréquente ; zolédronate selon la fonction rénale'],
    ['Allergie à l’iode, pacemaker ou IRM', 'Sans objet pour ces examens'],
   ]), 45))
PTS.append(POINT(9, 'Examens complémentaires',
 P('L’ionogramme pose le diagnostic, et l’ECG mesure le retentissement cardiaque. '
   'L’osmolalité et le sodium urinaire classent l’hyponatrémie ; la PTH classe l’hypercalcémie. '
   'Les prélèvements urinaires se font avant la perfusion.', 12, 45, 85) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si l’hyponatrémie donne des symptômes sévères, alors le médecin perfuse du NaCl 3 % sans attendre le bilan. '
   'Si le potassium est ≥ 6,5 mmol/L ou si l’ECG est anormal, alors il donne du calcium IV, puis de l’insuline avec du glucose. '
   'Sinon, il cherche la cause et corrige lentement.', 12, 85) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Na bas + symptômes sévères', 'NaCl 3 % 150 mL en 20 minutes, jusqu’à 2 fois', 'Natrémie à 20 minutes'],
    ['Na bas + symptômes modérés', 'NaCl 3 % 150 mL une fois, bilan de cause', 'Natrémie à 1, 6 et 12 heures'],
    ['Na bas sans symptômes', 'Cause, arrêt du médicament, restriction si SIADH', 'Natrémie quotidienne'],
    ['K ≥ 6,5 mmol/L ou ECG anormal', 'Calcium IV, insuline et glucose, salbutamol', 'Potassium et glycémie à 1, 2, 4 et 6 heures'],
    ['Calcium > 3,5 mmol/L', 'NaCl 0,9 %, zolédronate, calcitonine', 'Calcium quotidien'],
   ]), 12, 85, 45)))
MED = F('Fiches médicamenteuses (posologies AIPS et recommandations)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['NaCl 3 % (soluté hypertonique)', 'Attire l’eau hors des neurones', '150 mL IV en 20 minutes, jusqu’à 2 fois, but +5 mmol/L ; limite +10 mmol/L le premier jour, puis +8 mmol/L par 24 heures', 'Correction trop rapide : démyélinisation osmotique'],
   ['Gluconate de calcium 10 % (sel de calcium)', 'Stabilise la membrane cardiaque en quelques minutes, sans baisser le potassium', '30 mL IV en 5–10 minutes, à répéter si l’ECG reste anormal', 'Nécrose si extravasation ; prudence sous digoxine'],
   ['Insuline rapide, Actrapid® (hormone)', 'Fait entrer le potassium dans les cellules en 15–30 minutes', '10 unités IV avec 25 g de glucose, puis glucose 10 % selon la glycémie', 'Hypoglycémie : glycémie horaire pendant 6 heures'],
   ['Salbutamol, Ventolin® (bêta-2 agoniste)', 'Fait entrer le potassium dans les cellules', '10–20 mg en nébulisation', 'Tachycardie, tremblement'],
   ['Acide zolédronique, Zometa® (bisphosphonate)', 'Bloque la résorption de l’os ; effet en 2–4 jours', '4 mg IV en au moins 15 minutes, dose adaptée au DFGe', 'Fièvre, hypocalcémie, ostéonécrose de la mâchoire ; déconseillé si DFGe < 30 mL/min'],
   ['Dénosumab, Xgeva® (anticorps anti-RANKL)', 'Bloque l’activation des ostéoclastes', '120 mg sous-cutané, en cas d’échec ou de contre-indication des bisphosphonates', 'Hypocalcémie marquée, surtout si DFGe bas'],
   ['Calcitonine (hormone)', 'Baisse rapide et brève du calcium', '4 UI/kg toutes les 12 heures pendant 48 heures au maximum', 'Effet épuisé en 48 heures ; disponibilité suisse à vérifier'],
  ]) + P('L’audit a corrigé le glucose de l’original (500 mL de glucose 20 %, soit 100 g) en 25 g selon UK Kidney Association 2020. Le chélateur de potassium cité (Resonium®) et le tolvaptan doivent être vérifiés dans le compendium suisse.', 12, 85, 45, 1))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge protège d’abord l’organe menacé : le cerveau par le NaCl 3 %, le cœur par le calcium IV. '
   'Elle corrige ensuite lentement, parce qu’une correction trop rapide abîme le cerveau. '
   'Elle traite enfin la cause, souvent un médicament à arrêter.', 12, 85) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P(f'Dans une forme compliquée, le but est de faire disparaître les symptômes graves en quelques heures. Les cibles sont +5 mmol/L de sodium, un ECG normalisé et un calcium < 3,5 mmol/L au plus vite. La limite est de 10 mmol/L de hausse du sodium en 24 heures, pour éviter le {ODS}. Dans une forme non compliquée, le but est de corriger la cause en quelques jours.', 12, 85, 45), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Forme compliquée, en urgence</b> : 144, monitorage ; NaCl 3 % pour l’hyponatrémie sévère ; calcium IV puis insuline-glucose pour l’hyperkaliémie avec ECG anormal ; hydratation et zolédronate pour l’hypercalcémie sévère.',
         '<b>B. Élimination du potassium</b> : chélateur intestinal, diurétique de l’anse si la volémie le permet, dialyse si insuffisance rénale grave.',
         '<b>C. Forme non compliquée, en ambulatoire</b> : mesures générales (éducation sur les boissons, revue de médication), puis arrêt du thiazide, de l’IECA ou de la spironolactone ; restriction hydrique < 800 mL/jour dans le SIADH ; potassium oral dans l’hypokaliémie.',
         '<b>D. Cause</b> : traitement du cancer, parathyroïdectomie, insuline dans l’acidocétose.']), 12, 85, 45, 89) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un trouble électrolytique dû à un médicament s’annonce à Swissmedic s’il est grave (LPTh, art. 59).',
            'La reprise de la conduite automobile attend un état neurologique normal.'), 24, 60, 61) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse', 'Hyponatrémie et hypercalcémie rares ; avis spécialisé'],
      ['Personne âgée', 'Thiazides et ISRS : contrôle du sodium à 1–2 semaines'],
      ['Enfant', 'NaCl 3 % 2 mL/kg ; avis pédiatrique'],
      ['Insuffisance hépatique, alcool, dénutrition', 'Risque élevé de démyélinisation : limite +8 mmol/L par 24 heures'],
      ['Insuffisance rénale (DFGe)', 'Dialyse pour l’hyperkaliémie réfractaire ; dénosumab plutôt que zolédronate'],
     ]), 12, 45), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Natrémie', '20 minutes après chaque bolus, puis à 6 et 12 heures', 'Hausse > 10 mmol/L : arrêt, eau ou desmopressine'],
    ['Diurèse', 'Horaire', 'Diurèse aqueuse abondante : risque de correction trop rapide'],
    ['Potassium et glycémie', '1, 2, 4 et 6 heures après insuline', 'Glycémie < 4 mmol/L : glucose'],
    ['Calcium', 'Quotidien', 'Calcium < 2,1 mmol/L sous dénosumab : supplément'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Symptômes neurologiques disparus.', 'Ion contrôlé dans une zone sûre et stable sur 24 heures.', 'Cause identifiée ou médicament arrêté.', 'Contrôle ambulatoire planifié.']), 12, 85, 45) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic dépend de la cause et de la vitesse de correction. La démyélinisation osmotique peut laisser des séquelles. La recherche 2026 évalue la place de l’urée orale et des inhibiteurs de SGLT2 dans le SIADH ; le tolvaptan reste réservé aux équipes spécialisées.', 12, 58), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire contrôle le sodium, le potassium et la créatinine 1 à 2 semaines après l’introduction d’un thiazide, d’un IECA ou de la spironolactone. '
   'La prévention secondaire adapte les boissons pendant l’effort prolongé et la canicule. '
   'La prévention tertiaire évite de réintroduire le médicament en cause ; l’OFSP diffuse des conseils lors des canicules.', 12, 85, 23) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Contrôle biologique après tout nouveau diurétique ou bloqueur du système rénine-angiotensine'],
    ['Secondaire', 'Boire selon la soif lors d’un effort prolongé'],
    ['Tertiaire', 'Mention d’intolérance, revue de médication'],
   ]))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin dose le sodium chez tout patient âgé avec un malaise inexpliqué. '
   'Il fait un ECG devant tout potassium ou calcium anormal. '
   'Il donne le calcium IV avant l’insuline dans l’hyperkaliémie avec ECG anormal. '
   'Il ne dépasse pas +10 mmol/L de sodium en 24 heures. '
   'Il prélève l’urine avant la perfusion.', 12, 85)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Corriger une hyponatrémie chronique de 15 mmol/L en 24 heures.', 'Limite de 10 mmol/L le premier jour.'],
  ['Donner du NaCl 0,9 % dans un SIADH.', 'Le rein élimine le sel et garde l’eau : la natrémie peut baisser.'],
  ['Donner de l’insuline sans calcium devant un ECG anormal.', 'Calcium IV d’abord.'],
  ['Conclure à une natrémie normale après correction du glucose.', 'Calculer : la valeur corrigée peut rester basse.'],
  ['Interpréter un potassium hémolysé.', 'Recontrôler sans hémolyse.'],
 ]) + P('Ces pièges reprennent Spasovski 2014 et UK Kidney Association 2020.', 12, 85)))
CTX = {'_prefixe': 'Dans les troubles électrolytiques',
 'iono': 'L’ionogramme mesure le sodium et le potassium ; il pose le diagnostic.',
 'osmo': 'Une osmolalité plasmatique < 275 mOsm/kg confirme une hyponatrémie hypotonique.',
 'natriu': 'Un sodium urinaire ≤ 30 mmol/L oriente vers un volume circulant bas.',
 'ecg': 'L’ECG cherche des ondes T pointues ou des QRS larges (potassium) ou un QT court (calcium).',
 'creat': 'Le DFGe explique une hyperkaliémie ou guide la dose de zolédronate.',
 'uree': 'L’urée aide à juger la déshydratation.',
 'gly': 'La glycémie corrige la natrémie et cherche une crise hyperglycémique.',
 'cetone': 'La cétonémie confirme une acidocétose.',
 'gds': 'La gazométrie mesure l’acidose et les bicarbonates.',
 'pth': 'Une PTH basse avec un calcium élevé oriente vers un cancer.',
 'mg': 'Une magnésémie basse entretient l’hypokaliémie et l’hypocalcémie.',
 'cort': 'Un cortisol matinal bas oriente vers une insuffisance surrénalienne.',
 'tsh': 'La TSH écarte une hypothyroïdie profonde, cause rare d’hyponatrémie.',
 'epp': 'L’électrophorèse des protéines cherche un myélome.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
