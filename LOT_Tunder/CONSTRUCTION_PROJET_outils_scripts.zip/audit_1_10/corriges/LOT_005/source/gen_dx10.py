# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.10 · Intoxication occulte au monoxyde de carbone et aux gaz domestiques (LOT 5, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('dx10')
M = meta('dx10', 'DX.10', 'Intoxication au CO', 'Intoxication occulte au monoxyde de carbone et aux gaz domestiques', 'LOT_005_DX10_Intoxication_CO_gaz_AUDITÉ.html')
HB = T('hémoglobine', 'L’hémoglobine est la protéine des globules rouges qui transporte l’oxygène des poumons vers les tissus.')
HBCO = T('carboxyhémoglobine', 'La carboxyhémoglobine (HbCO) est l’hémoglobine liée au monoxyde de carbone ; elle ne transporte plus d’oxygène.')
CCO = T('cytochrome c oxydase', 'La cytochrome c oxydase est la dernière enzyme de la chaîne respiratoire des mitochondries ; elle permet aux cellules d’utiliser l’oxygène pour produire leur énergie.')
COURBE = T('courbe de dissociation', 'La courbe de dissociation de l’oxyhémoglobine décrit la facilité avec laquelle l’hémoglobine lâche l’oxygène dans les tissus. Déplacée vers la gauche, elle le retient.')
PTS = []

# ---------- 1
PTS.append(POINT(1, 'Définition et sémantique',
 P('L’intoxication au monoxyde de carbone (CO) est une hypoxie des tissus causée par un gaz invisible et sans odeur. '
   'Le gaz vient d’une combustion incomplète : chauffage, chauffe-eau, poêle, moteur ou braise en lieu clos. '
   'Elle se déguise en « grippe sans fièvre » : céphalées, vertiges, nausées, malaise général.', 14, 49) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Monoxyde de carbone (CO)', 'Gaz toxique de combustion incomplète, sans couleur ni odeur', 'Dioxyde de carbone (CO2), gaz de respiration'],
    ['Carboxyhémoglobine (HbCO)', 'Part de l’hémoglobine liée au CO, en %', 'Saturation en oxygène (SpO2)'],
    ['Intoxication aux fumées d’incendie', 'CO et cyanure respirés ensemble', 'Intoxication au CO seule'],
    ['Syndrome neurologique retardé', 'Troubles cognitifs ou psychiques apparaissant des jours après l’exposition', 'Séquelles immédiates du coma'],
    ['Oxygénothérapie hyperbare (OHB)', 'Oxygène pur respiré dans un caisson sous pression', 'Oxygène normobare au masque'],
   ]) + P('Le mot « occulte » signifie que la cause n’est pas visible : ni le patient ni le médecin ne pensent au gaz. '
   'L’indice principal est collectif : plusieurs personnes du même logement sont malades en même temps.', 14), 14)))

# ---------- 2
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En 2024, Tox Info Suisse a reçu 45 consultations pour une exposition humaine au CO. '
   'Parmi les 15 cas suivis jusqu’au bout, 11 étaient d’intensité moyenne et 1 a été mortel. '
   'Ces chiffres sous-estiment la réalité, parce que beaucoup de cas ne sont ni reconnus ni annoncés.', 105) +
 F('Chiffres, terrain et saison',
   TAB(['Donnée', 'Valeur', 'Population et source'], [
    ['Consultations pour CO', '45 (41 adultes, 4 enfants)', 'Suisse, Tox Info Suisse 2024'],
    ['Cas à évolution documentée', '15 : 3 légers, 11 moyens, 1 mortel', 'Même registre'],
    ['Consultations pour fumées d’incendie', '243', 'Même registre'],
    ['Taux de consultation pour CO', '≈ 0,5 pour 100 000 habitants par an', 'Calcul de l’audit : 45 sur ≈ 9 millions'],
   ], 'Correction de l’original : les chiffres « 300–400 appels, 500–600 intoxiqués par an » ne sont pas retrouvés dans les rapports de Tox Info Suisse et ont été retirés.') +
   P('En Europe, 28 États de l’OMS ont annoncé 2,24 décès liés au CO pour 100 000 habitants par an entre 1980 et 2008. '
     'Les décès non intentionnels en représentent 54,7 %.', 114) +
   TAB(['Facteur de risque ou terrain', 'Effet sur le pronostic'], [
    ['Âge ≥ 65 ans', 'Mortalité plus élevée : 22,3 % des décès européens pour 14,1 % de la population'],
    ['Sexe masculin', 'Mortalité plus élevée dans la plupart des pays européens'],
    ['Grossesse', 'Risque fœtal : le fœtus élimine le CO plus lentement'],
    ['Perte de connaissance, ataxie initiale', 'Pronostic neurologique moins bon (séquelles cognitives plus fréquentes)'],
    ['Coronaropathie', 'Atteinte myocardique et mortalité à long terme accrues'],
   ]) +
   P('Le risque monte en hiver, quand les chauffages tournent et que les fenêtres restent fermées. '
     'Les terrains à risque sont les logements anciens, les chauffages mal entretenus, les groupes électrogènes, les braseros et les chichas en lieu clos. '
     'La femme enceinte, le fœtus, l’enfant et le coronarien sont les plus vulnérables.', 14, 49, 50, 112), 105, 114, 14)))

# ---------- 3
PTS.append(POINT(3, 'Physiopathologie',
 P(f'Le CO entre par les poumons et se fixe sur l’{HB} environ 200 à 250 fois plus fort que l’oxygène. '
   f'Il forme la {HBCO}, qui ne transporte plus d’oxygène. '
   f'Il déplace aussi la {COURBE} vers la gauche : l’oxygène restant est moins bien livré aux tissus.', 14) +
 P(f'Le CO bloque aussi la {CCO} : les cellules manquent d’énergie même si le sang contient de l’oxygène.', 14) +
 F('Au-delà de l’hémoglobine : mitochondries, cœur, cerveau',
   P('Le CO se fixe sur la myoglobine du cœur, ce qui explique l’ischémie et les arythmies. '
     'Une inflammation du cerveau se poursuit après l’exposition ; elle explique les séquelles retardées.', 14, 49), 14, 49) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Les alvéoles échangent les gaz avec le sang ; le cerveau et le cœur consomment le plus d’oxygène.'],
    ['Physiologie', 'Chaque molécule d’hémoglobine transporte l’oxygène et le libère dans les tissus selon leurs besoins.'],
    ['Physiopathologie', 'Le CO occupe l’hémoglobine, retient l’oxygène restant et bloque la respiration des cellules.'],
    ['Clinique', 'D’où les céphalées, les vertiges, la confusion, la douleur thoracique, puis la syncope et le coma.'],
    ['Examens', 'Comme le saturomètre ordinaire confond HbCO et oxyhémoglobine, seule la CO-oxymétrie mesure l’HbCO.'],
    ['Traitement', 'Comme l’oxygène chasse le CO de l’hémoglobine, on donne de l’oxygène à 100 %, parfois sous pression.'],
   ]), 14) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme', 'Exploration', 'Cible thérapeutique'], [
    ['Hémoglobine occupée par le CO', 'CO-oxymétrie (HbCO)', 'Oxygène à 100 %'],
    ['Hypoxie des tissus', 'Lactate, gazométrie', 'Oxygène, OHB si forme grave'],
    ['Atteinte du cœur (myoglobine, ischémie)', 'ECG, troponine', 'Surveillance cardiaque, OHB'],
    ['Atteinte du cerveau', 'Examen neurologique, IRM cérébrale', 'OHB, suivi neuropsychologique'],
    ['Source dans le logement', 'Mesure du CO par les pompiers', 'Évacuation, réparation, détecteur'],
   ]), 14) +
 F('Fenêtre de calcul : demi-vie de l’HbCO selon l’oxygène respiré',
   P('La demi-vie est le temps nécessaire pour que le taux d’HbCO baisse de moitié. '
     'Plus la pression d’oxygène est forte, plus l’oxygène chasse vite le CO.', 14, 107) +
   TAB(['Mode d’oxygénation', 'Fraction d’oxygène', 'Demi-vie de l’HbCO', 'Usage'], [
    ['Air ambiant', '21 %', '≈ 320 minutes (environ 5 heures)', 'Insuffisant'],
    ['Oxygène normobare au masque à réservoir (12–15 L/min)', 'Proche de 100 %', '≈ 74 minutes (26–148)', 'Traitement immédiat de tous les patients'],
    ['OHB (2,5–3 atmosphères absolues)', '100 % sous pression', '≈ 20 minutes', 'Formes graves, grossesse'],
   ]) +
   P('Exemple : une HbCO de 24 % passe à 12 % en environ 74 minutes sous oxygène normobare. '
     'Les taux mesurés dans le cas familial de l’original manquent dans l’export ; l’audit ne les a pas reconstitués.', 107) +
   P('Le taux d’HbCO ne mesure pas bien la gravité, car il baisse dès que le patient respire de l’air frais. '
     'Les paliers classiques (10–20 % : céphalées ; 20–40 % : confusion ; > 40 % : coma) ne sont que des repères approximatifs.', 14, 49), 14, 107)))

# ---------- 4
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin pense au CO devant un malaise sans fièvre qui touche plusieurs personnes du même lieu. '
   'En urgence, il protège d’abord les personnes : évacuation, oxygène, appel au 144 et aux pompiers. '
   'Il distingue ensuite le CO des maladies collectives plus fréquentes, mais bénignes.', 14, 49) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même unité : cas annoncés ou consultations pour 100 000 habitants par an, Suisse)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Syndrome grippal' + PR('≈ 3 611 / 100 000', 2), 'Fièvre, courbatures, épidémie hivernale, toux', 'Clinique, PCR si besoin'],
    ['Toxi-infection alimentaire (campylobactériose)' + PR('92 / 100 000', 111), 'Diarrhée, repas commun, début en heures ou jours', 'Coproculture ou PCR des selles'],
    ['Intoxication aux fumées d’incendie (CO et cyanure)' + PR('≈ 2,7 / 100 000', 105), 'Incendie, suie dans la bouche, lactate très élevé', 'HbCO, lactate'],
    ['Intoxication au CO' + PR('≈ 0,5 / 100 000', 105), 'Sans fièvre, plusieurs occupants, mieux à l’air libre', 'CO-oxymétrie (HbCO)'],
    ['Migraine, céphalée de tension', 'Individuelle, antécédents', 'Clinique'],
   ]) + P('Les chiffres de grippe sont des consultations estimées par le réseau Sentinella, ceux du CO des appels à Tox Info Suisse : le CO est donc sous-estimé. '
          'La faible fréquence du CO n’autorise pas à l’oublier : c’est la cause mortelle et évitable du groupe.', 2, 105, 111) +
   P('Correction de l’original : les « empoisonnements criminels aux métaux lourds ou aux cyanures » sont exceptionnels ; aucune fréquence comparable n’a été retrouvée.', 105), 2, 105, 111)))

# ---------- 5
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien cherche une source de combustion et un lien avec le lieu. '
   'Le malaise qui s’améliore dehors et revient à la maison est très évocateur. '
   'Le médecin demande si d’autres personnes ou les animaux de la maison sont malades.', 14, 49) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['D’autres personnes du logement ont-elles les mêmes symptômes ?', 'Source commune', 'Examiner tout le foyer'],
    ['Les symptômes diminuent-ils quand vous sortez ?', 'Exposition liée au lieu', 'Suspicion forte de CO'],
    ['Quel chauffage, chauffe-eau ou poêle utilisez-vous ? Quand a-t-il été contrôlé ?', 'Source possible', 'Intervention des pompiers'],
    ['Avez-vous utilisé un moteur, un barbecue ou une chicha à l’intérieur ?', 'Source fréquente et oubliée', 'Mesure de l’HbCO'],
    ['Êtes-vous enceinte ?', 'Le fœtus est plus vulnérable', 'Avis pour OHB'],
    ['Avez-vous perdu connaissance, même brièvement ?', 'Critère de gravité', 'Avis pour OHB'],
    ['Fumez-vous ?', 'Le tabac élève l’HbCO de base', 'Interprétation du taux'],
   ]), 14, 49, 106) +
 U('<b>Drapeaux rouges (urgence, 144)</b> : perte de connaissance même brève, confusion, convulsion, déficit neurologique, douleur thoracique ou ECG ischémique, dyspnée, grossesse.', 106, 49)))

# ---------- 6
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen montre souvent peu de signes : pas de fièvre, parfois une tachycardie et une tachypnée. '
   'La couleur « rouge cerise » de la peau est rare et surtout vue à l’autopsie ; son absence n’exclut rien. '
   'L’examen neurologique soigneux est essentiel, car il guide la décision d’OHB.', 14, 49) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Température', '< 38 °C', 'Absence de fièvre : contre une grippe'],
    ['Oxymétrie de pouls', 'SpO2 normale', 'Normale même en cas d’intoxication grave : piège'],
    ['Pouls, pression, ECG de surveillance', 'Rythme régulier', 'Tachycardie, arythmie, ischémie'],
    ['Vigilance et orientation', 'Patient orienté', 'Confusion : critère d’OHB'],
    ['Coordination (doigt-nez, marche)', 'Normale', 'Ataxie cérébelleuse : risque de séquelles plus élevé'],
    ['Mémoire et attention', 'Normales', 'Trouble cognitif : critère d’OHB'],
   ]), 14, 50, 106)))

# ---------- 7
TERMES = ('Termes : ' + T('ataxie', 'L’ataxie est un trouble de la coordination des mouvements, par atteinte du cervelet.') + ', '
   + T('globus pallidus', 'Le globus pallidus est un noyau profond du cerveau, très sensible au manque d’oxygène ; ses lésions sont typiques du CO.') + ', '
   + T('syndrome parkinsonien', 'Un syndrome parkinsonien associe lenteur, raideur et parfois tremblement.') + '.')
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels (symptômes) sont les céphalées, les vertiges, les nausées, la fatigue et la dyspnée. '
   'Les signes physiques sont souvent pauvres : tachycardie, tachypnée, ataxie. '
   'Les signes graves sont la confusion, la syncope, les convulsions, le coma et l’ischémie du cœur. '
, 14, 49) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Gravité'], [
    ['Hypoxie modérée « pseudo-grippale »', 'Céphalées frontales, vertiges, nausées, plusieurs occupants', 'Oxygène normobare'],
    ['Encéphalopathie aiguë', 'Confusion, syncope, convulsions, coma', 'OHB'],
    ['Atteinte cardiaque', 'Douleur thoracique, arythmie, troponine élevée', 'Atteinte myocardique chez ≈ 37 % des formes moyennes à graves'],
    ['Syndrome neurologique retardé', 'Troubles de mémoire, de l’humeur, syndrome parkinsonien, quelques jours à semaines après', 'Suivi neuropsychologique'],
   ]) + P('Des troubles retardés peuvent suivre un intervalle libre de quelques jours.', 14, 49) + P(TERMES, 14), 14, 112)))

# ---------- 8
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le diagnostic associe trois éléments : une exposition plausible, des symptômes compatibles et une HbCO élevée. '
   'Le seuil est une HbCO > 3 % chez le non-fumeur et > 10 % chez le fumeur. '
   'Une HbCO normale n’exclut pas l’intoxication si le patient a déjà reçu de l’oxygène.', 14, 49) +
 F('Critères : ce qui existe, ce qui ne suffit pas',
   P('Aucune société savante ne publie de score diagnostique. '
     'Les recommandations américaines de 2012 (Hampson) et le consensus européen de 2016 retiennent l’association exposition, symptômes et HbCO > 3 % (non-fumeur) ou > 10 % (fumeur). '
     'Une HbCO élevée seule ne suffit pas, car le tabac l’élève aussi. '
     'Une SpO2 normale ne permet pas d’exclure le diagnostic.', 49, 106, 14), 49, 106, 14) +
 F('Combinaison diagnostique',
   TAB(['Situation', 'Conclusion'], [
    ['Exposition + symptômes + HbCO élevée', 'Intoxication confirmée'],
    ['Exposition + symptômes + HbCO normale après oxygène', 'Intoxication probable : traiter'],
    ['CO mesuré dans le logement par les pompiers', 'Confirmation de la source'],
    ['HbCO élevée sans source chez un fumeur', 'Tabagisme ; chercher quand même une source'],
   ]), 14, 49)))

# ---------- 9
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance', 'Limite'], [
    ['CO-oxymétrie sur gazométrie veineuse ou artérielle', 'Taux d’HbCO', 'Examen de référence (étalon) : sa sensibilité et sa spécificité servent de base, sans valeur propre publiée', 'Baisse rapide sous oxygène : noter l’heure'],
    ['Oxymètre de pouls à plusieurs longueurs d’onde (SpCO)', 'Estimation de l’HbCO', 'Sensibilité 0,77, spécificité 0,83 par rapport à la prise de sang', 'Écart jusqu’à ± 8 points : ne confirme ni n’exclut'],
   ]), 14, 49, 115) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'CO-oxymétrie, gazométrie, lactate', 'Toute suspicion'],
    ['Première', 'ECG et troponine', 'Formes moyennes ou graves, douleur thoracique, âge, coronaropathie'],
    ['Première', 'Créatinine, CK, glycémie', 'Coma, rhabdomyolyse'],
    ['Première', 'Test de grossesse', 'Femme en âge de procréer'],
    ['Seconde', 'IRM ou scanner cérébral', 'Coma, déficit, troubles retardés'],
    ['Seconde', 'Dépistage toxicologique', 'Geste suicidaire, autre toxique suspecté'],
   ]), 14, 49, 112) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['La <b>CO-oxymétrie</b> se prélève le plus tôt possible, idéalement avant l’oxygène, sans retarder l’oxygène.',
       'Le médecin note l’heure de fin d’exposition et l’heure du prélèvement, pour interpréter le taux.',
       'L’<b>ECG</b> et la troponine se répètent si la douleur ou l’anomalie persiste.']), 14, 49) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['HbCO', '> 3 % (non-fumeur), > 10 % (fumeur)', 'Exposition au CO', 'Oxygène à 100 %'],
    ['HbCO très élevée', 'Valeur > 25 % souvent citée', 'Exposition massive', 'Discuter l’OHB, même sans symptôme grave'],
    ['Lactate élevé', '> 2 mmol/L', 'Hypoxie des tissus ; si très élevé après incendie : cyanure', 'Hydroxocobalamine si fumées'],
    ['Troponine élevée', 'Au-dessus du 99e percentile', 'Atteinte myocardique', 'Avis cardiologique, OHB'],
    ['IRM : lésions des deux globus pallidus', 'Imagerie', 'Atteinte cérébrale du CO', 'Suivi neurologique'],
   ], 'Le seuil de 25 % n’est pas retenu par le consensus européen : la décision dépend des signes cliniques et de la grossesse.'), 14, 49, 106, 112) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (HbCO 8 % chez un gros fumeur)', 'Tabagisme possible ; chercher les autres occupants malades'],
    ['Résultat négatif mais clinique typique (oxygène déjà donné)', 'Calculer le temps écoulé ; traiter selon la clinique'],
    ['Résultat limite (3–5 % chez un non-fumeur)', 'Mesurer chez les autres occupants ; contrôle du logement'],
    ['Grossesse', 'Le fœtus élimine le CO plus lentement : avis pour OHB'],
    ['Enfant', 'Symptômes peu spécifiques (vomissements, léthargie) ; même démarche'],
    ['Insuffisance rénale (DFGe bas)', 'Pas de changement de l’oxygène ; adapter les autres médicaments'],
    ['Allergie à l’iode, pacemaker ou IRM', 'Scanner sans contraste ; vérifier la compatibilité IRM et caisson'],
   ]), 14, 106, 108))
PTS.append(POINT(9, 'Examens complémentaires',
 P('La CO-oxymétrie confirme le diagnostic. '
   'Le lactate, l’ECG et la troponine mesurent le retentissement. '
   'L’imagerie cérébrale est réservée aux formes neurologiques.', 14, 49) + P9))

# ---------- 10
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si le CO est suspecté, alors le premier geste est de sortir tout le monde à l’air libre et d’appeler le 144. '
   'Si le patient est symptomatique, alors il reçoit de l’oxygène à 100 % avant tout résultat. '
   'Si un critère de gravité existe, alors le médecin appelle le centre hyperbare.', 106, 108) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['Suspicion au domicile', 'Évacuer, ne pas allumer de flamme ni d’interrupteur, appeler 144 et 118', 'Mesure du CO par les pompiers'],
    ['Forme mineure (céphalées, nausées, examen neurologique normal)', 'Oxygène normobare environ 12 heures', 'Disparition des symptômes'],
    ['Trouble de conscience, signe neurologique, cardiaque ou psychique', 'OHB, quel que soit le taux d’HbCO', 'Centre hyperbare (HUG Genève 24 h sur 24)'],
    ['Grossesse', 'OHB, quels que soient les symptômes', 'Suivi obstétrical'],
    ['Fumées d’incendie avec lactate très élevé', 'Hydroxocobalamine IV en plus de l’oxygène', 'Lactate de contrôle'],
    ['Asymptomatique plus de 24 heures après la fin de l’exposition', 'Pas d’OHB', 'Information et suivi'],
   ]), 106, 108, 113)))

# ---------- 11
MED = F('Fiches thérapeutiques (posologies AIPS et recommandations)',
  TAB(['Traitement (classe)', 'Mécanisme d’action et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Oxygène normobare (classe : gaz médical)', 'Entre en compétition avec le CO sur l’hémoglobine ; demi-vie de l’HbCO ≈ 74 minutes', 'Masque à réservoir 12–15 L/min ; durée : environ 12 heures pour une forme mineure', 'Effets indésirables rares en aigu ; aucune contre-indication en urgence, même chez un patient BPCO ; aucune interaction utile'],
   ['Oxygénothérapie hyperbare (classe : gaz médical sous pression)', 'Dissout l’oxygène dans le plasma ; demi-vie de l’HbCO ≈ 20 minutes', '2,5–3 atmosphères absolues ; souvent jusqu’à 3 séances en 24 heures (essai de Weaver)', 'Barotraumatisme de l’oreille, convulsion ; contre-indication : pneumothorax non drainé ; interaction : bléomycine, doxorubicine, cisplatine (avis du centre hyperbare ; non vérifié dans les sources citées)'],
   ['Hydroxocobalamine, Cyanokit® (classe : antidote du cyanure)', 'Fixe le cyanure en cyanocobalamine ; élimination par les urines', '5 g IV en 15 minutes ; 5 g de plus selon la gravité (AIPS) ; dose unique ou répétée une fois', 'Peau et urines rouges ; contre-indication : allergie connue ; interaction : faux résultats colorimétriques, incompatibilité dans la même voie que d’autres perfusions'],
  ]) + P('L’essai de Weaver a comparé 3 séances d’OHB en 24 heures à l’oxygène normobare. '
         'Les troubles cognitifs à 6 semaines passent de 46,1 % à 25,0 %.', 50, 14, 107, 113, 106), 50, 106, 113)
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge chasse le CO de l’hémoglobine, parce que l’oxygène entre en compétition avec lui. '
   'Elle protège aussi le cerveau et le cœur des séquelles. '
   'Elle supprime enfin la source, pour que personne ne retourne dans un logement dangereux.', 14, 106) +
 F('11.A Buts : forme grave (urgence), puis forme mineure',
   P('Dans une forme compliquée (coma, signe neurologique, atteinte cardiaque, grossesse), l’urgence est l’oxygène dès la première minute puis l’OHB dans les heures qui suivent, idéalement dans les 6 premières heures. '
     'Dans une forme non compliquée, le but est d’éliminer le CO par environ 12 heures d’oxygène normobare. '
     'Viennent ensuite les mesures générales : éducation du foyer, contrôle du logement, information sur les troubles retardés.', 106, 108) +
   P('Le délai de 6 heures est un repère d’experts ; l’audit ne l’a pas retrouvé comme seuil dans le consensus européen 2016, à vérifier.', 106), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Sur place</b> : ouvrir et sortir, couper l’appareil si c’est sans risque, appeler le 144 et les pompiers (118).',
         '<b>B. Oxygène à 100 %</b> : masque à réservoir dès la suspicion, sans attendre l’HbCO ; intubation si coma.',
         '<b>C. Critères de gravité</b> : appel du centre hyperbare ; en Suisse, HUG Genève (24 heures sur 24), Bâle avec préavis, caisson mobile au Tessin.',
         '<b>D. Retour à domicile</b> : seulement après contrôle et réparation de l’appareil ; conseil de Tox Info Suisse (145).']), 106, 108, 15) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Une intoxication au travail (garage, entrepôt, chantier) relève de la LAA comme accident professionnel.',
            'La conduite automobile est suspendue en cas de perte de connaissance ou de séquelles neurologiques, jusqu’à évaluation de l’aptitude.',
            'Le propriétaire ou la régie doit faire réparer l’installation ; les contrôles d’émissions sont prévus par l’OPair.'), 59, 60, 61, 109) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'OHB pour toute femme enceinte intoxiquée ; la grossesse n’est pas une contre-indication au caisson dans ce cas'],
      ['Enfant', 'Même démarche ; prévenir le pédiatre'],
      ['Sujet âgé, coronarien', 'ECG et troponine systématiques'],
      ['Geste suicidaire', 'Chercher d’autres toxiques ; évaluation psychiatrique'],
      ['Insuffisance hépatique', 'Pas d’adaptation de l’oxygène'],
      ['Insuffisance rénale (DFGe)', 'Surveiller la rhabdomyolyse'],
     ]), 106, 108), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Symptômes, vigilance', 'Toutes les heures', 'Aggravation : OHB'],
    ['HbCO', 'Après quelques heures d’oxygène', 'Toujours élevée : poursuivre'],
    ['ECG, troponine', 'À l’admission puis à 6 heures si anomalie', 'Hausse : avis cardiologique'],
    ['Cognition', 'Avant la sortie et à 4–6 semaines', 'Trouble : bilan neuropsychologique'],
   ]) + P('Pourquoi surveiller : les signes cardiaques et neurologiques peuvent apparaître après l’amélioration. '
     'Arrêt de l’oxygène normobare : après environ 12 heures pour une forme mineure, selon le consensus européen, et seulement si les symptômes ont disparu. '
     'Contrôle à 4–6 semaines : c’est le délai où l’essai de Weaver a mesuré les séquelles cognitives.', 106, 50) + H4('Critères de sortie, un par un') +
   OL(['Symptômes disparus et examen neurologique normal.', 'Logement contrôlé et sûr.', 'Information sur les troubles retardés remise.', 'Contrôle médical prévu dans les semaines suivantes.']), 14, 49, 112) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('La plupart des formes mineures guérissent sans séquelle. Après une forme grave, des troubles cognitifs persistent souvent ; l’OHB les réduit dans l’essai de Weaver. Le rôle du TEP au FDG cité par l’original pour le pronostic n’est pas confirmé par les recommandations ; il a été retiré.', 50, 106), 'fenetre')))

# ---------- 12
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur l’entretien annuel des chauffages et des conduits de fumée. '
   'L’OPair impose des contrôles des émissions de CO : tous les 2 ans pour le mazout, tous les 4 ans pour le gaz. '
   'Un détecteur de CO est recommandé, mais l’audit n’a trouvé aucune obligation fédérale.', 109, 110) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Entretien des appareils, aération, jamais de moteur, barbecue ou brasero à l’intérieur'],
    ['Primaire', 'Détecteur de CO certifié (norme EN 50291) posé à 1–1,5 m de hauteur, en plus du détecteur de fumée'],
    ['Secondaire', 'Penser au CO devant tout malaise collectif sans fièvre en hiver'],
    ['Tertiaire', 'Suivi des troubles cognitifs retardés ; réparation avant le retour'],
   ], 'Correction de l’original : l’installation de détecteurs n’est pas obligatoire en Suisse selon les sources consultées.'), 109, 110)))

# ---------- 13
PTS.append(POINT(13, 'Points clés',
 P('Le médecin pense au CO devant un malaise collectif sans fièvre. '
   'Il ne se fie pas au saturomètre ordinaire, qui reste normal. '
   'Il mesure l’HbCO par CO-oxymétrie et donne l’oxygène à 100 % sans attendre. '
   'Il demande l’OHB en cas de signe neurologique, cardiaque ou de grossesse. '
   'Il ne renvoie personne dans le logement avant le contrôle de l’appareil.', 14, 106)))

# ---------- 14
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Exclure le CO sur une SpO2 normale à 98 %.', 'Le saturomètre ordinaire ne voit pas l’HbCO : CO-oxymétrie.'],
  ['Exclure le CO sur une HbCO basse mesurée après l’oxygène.', 'Tenir compte du délai et de la clinique.'],
  ['Décider de l’OHB sur le seul taux d’HbCO.', 'Décider sur les signes cliniques et la grossesse.'],
  ['Renvoyer la famille à la maison sans contrôle du logement.', 'Contrôle et réparation par les pompiers ou un spécialiste.'],
  ['Oublier le cyanure après un incendie.', 'Lactate très élevé : hydroxocobalamine.'],
 ]) + P('Ces pièges reprennent les recommandations citées.', 14, 106, 113)))

CTX = {'_prefixe': 'Dans l’intoxication au CO',
 'hbco': 'Une HbCO > 3 % chez le non-fumeur confirme l’exposition ; un taux bas n’exclut rien après oxygène.',
 'gds': 'La gazométrie veineuse suffit pour la CO-oxymétrie ; la PaO2 reste normale.',
 'lact': 'Un lactate élevé signe l’hypoxie des tissus ; très élevé après incendie, il évoque le cyanure.',
 'tropo': 'Une troponine élevée signe une atteinte du cœur.',
 'ecg': 'L’ECG cherche une ischémie ou une arythmie.',
 'creat': 'La créatinine cherche une atteinte rénale par rhabdomyolyse.',
 'ck': 'Les CK cherchent une rhabdomyolyse après un coma.',
 'irm': 'L’IRM cherche des lésions des deux globus pallidus.',
 'tdm': 'Le scanner cérébral écarte une autre cause de coma.',
 'oxy': 'La SpO2 reste faussement normale : elle ne mesure pas l’HbCO.',
 'hcg': 'Le test de grossesse change l’indication d’OHB.',
 'tox': 'Le dépistage cherche d’autres toxiques si le geste est volontaire.',
 'gly': 'La glycémie écarte une hypoglycémie devant un coma.',
 'pcr': 'La PCR confirme une grippe si le doute persiste.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
