# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ DX.3 · Attaque de panique et trouble à symptomatologie somatique (LOT 5, V5 → V7, audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('dx3')
M = meta('dx3', 'DX.3', 'Panique et somatisation', 'Attaque de panique, trouble panique et trouble à symptomatologie somatique', 'LOT_005_DX3_Panique_et_trouble_somatique_AUDITÉ.html')
HYPV = T('hyperventilation', 'L’hyperventilation est une respiration plus rapide ou plus profonde que les besoins ; elle chasse trop de CO2 (dioxyde de carbone) du sang, ce qui le rend alcalin.')
AGORA = T('agoraphobie', 'L’agoraphobie est la peur des lieux ou des situations d’où il serait difficile de sortir ou d’obtenir de l’aide en cas de malaise (foule, transports, files d’attente) ; elle conduit à les éviter.')
ANTIC = T('anxiété anticipatoire', 'L’anxiété anticipatoire est la peur d’avoir une nouvelle crise ; elle entretient le trouble en augmentant la vigilance aux sensations du corps.')
CATA = T('interprétation catastrophique', 'L’interprétation catastrophique est le fait de lire une sensation normale (palpitation, vertige) comme le signe d’une catastrophe (infarctus, folie) ; c’est la cible principale de la thérapie cognitive.')
PTS = []
PTS.append(POINT(1, 'Définition et sémantique',
 P('L’attaque de panique est une montée brutale de peur intense, qui atteint son maximum en quelques minutes et s’accompagne d’au moins 4 symptômes physiques ou psychiques. '
   f'Le trouble panique est la répétition d’attaques inattendues suivie d’au moins un mois d’{ANTIC} ou d’évitement. '
   'Le trouble à symptomatologie somatique associe des symptômes physiques pénibles à des pensées, des émotions ou des comportements excessifs à leur sujet, pendant plus de 6 mois.', 18, 82) +
 F('Terminologie : à ne pas confondre',
   TAB(['Terme', 'Définition exacte', 'À ne pas confondre avec'], [
    ['Attaque de panique', 'Épisode de peur intense, maximum en quelques minutes', 'Trouble panique (attaques répétées et crainte persistante)'],
    ['Trouble panique (CIM-11 6B01)', 'Attaques récurrentes et inattendues avec crainte persistante', 'Attaque de panique isolée, fréquente dans la population'],
    ['Trouble à symptomatologie somatique (DSM-5-TR)', 'Symptôme réel + réaction excessive ; une maladie physique peut coexister', 'Symptôme « sans cause organique », notion abandonnée en 2013'],
    ['Trouble de détresse corporelle (CIM-11 6C20)', 'Équivalent proche dans la classification de l’OMS', 'Trouble factice ou simulation (production volontaire)'],
    ['Crainte excessive d’avoir une maladie', 'Peur d’une maladie grave avec peu de symptômes', 'Trouble à symptomatologie somatique (symptômes au premier plan)'],
   ]) + P('Correction de l’original : le DSM-5 n’exige plus l’absence de cause organique ; il juge l’excès de la réaction au symptôme.', 18))))
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('En Europe, les troubles anxieux touchent 14 % des adultes sur 12 mois, le trouble panique 1,8 % et les troubles somatoformes 4,9 %. '
   'En Suisse, le monitorage Obsan 2020 rapporte une détresse psychologique moyenne ou élevée chez environ 15 % de la population, mais les chiffres de l’original (15 % vie entière, 10–15 % des consultations d’urgence) n’ont pas été retrouvés dans une source. '
   'Les femmes sont 2 à 3 fois plus touchées, et le trouble panique débute en général entre 20 et 35 ans.', 46, 48, 47) +
 F('Chiffres, terrain et pronostic',
   TAB(['Donnée', 'Valeur', 'Population'], [
    ['Troubles anxieux (tous)', '14 % sur 12 mois', 'Adultes européens (Wittchen 2011)'],
    ['Trouble panique', '1,8 % sur 12 mois', 'Idem'],
    ['Trouble anxieux généralisé', '1,7 % (14–65 ans) ; 3,4 % (≥ 65 ans)', 'Idem'],
    ['Troubles somatoformes', '4,9 % sur 12 mois', 'Idem'],
    ['Attaque de panique au moins une fois dans la vie', '22,7 %', 'Adultes américains (Kessler 2006)'],
    ['Trouble panique vie entière', '4,7 %', 'Idem'],
   ]) + P('Le terrain associe le sexe féminin, des antécédents familiaux, le tabac et des événements de vie stressants. Le pronostic sans traitement est fluctuant ; la mortalité n’est pas augmentée par la panique elle-même, mais le risque suicidaire augmente en cas de dépression associée.', 46, 47, 83))))
PTS.append(POINT(3, 'Physiopathologie',
 P('Le cerveau dispose d’un système d’alarme : l’amygdale et le locus coeruleus déclenchent la réponse de lutte ou de fuite. '
   f'Dans la panique, ce système se déclenche sans danger réel ; la noradrénaline accélère le cœur et la respiration, et l’{HYPV} crée des vertiges et des fourmillements. '
   f'Le patient lit ces sensations comme un danger ({CATA}), ce qui relance l’alarme dans un cercle vicieux.', 18, 83) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'L’amygdale détecte la menace ; le locus coeruleus (tronc cérébral) libère la noradrénaline ; le cortex préfrontal freine normalement cette alarme.'],
    ['Physiologie', 'Pourquoi l’alarme est utile : face à un danger, la fréquence cardiaque, la ventilation et la vigilance augmentent pour préparer l’action.'],
    ['Physiopathologie', 'L’alarme part sans danger ; l’hyperventilation baisse le CO2, alcalinise le sang, contracte les artères cérébrales et baisse le calcium ionisé.'],
    ['Clinique', 'D’où les palpitations, l’oppression, le vertige, la tête vide et les fourmillements des doigts et de la bouche.'],
    ['Examens', 'Comme une maladie physique peut produire les mêmes sensations, l’ECG, la glycémie et la TSH écartent les causes somatiques fréquentes.'],
    ['Traitement', 'On casse le cercle : l’explication et la thérapie cognitivo-comportementale corrigent l’interprétation ; un ISRS baisse la réactivité de l’alarme.'],
   ]), 18, 83, 20) +
 F('Mécanisme, symptôme et cible thérapeutique',
   TAB(['Mécanisme', 'Symptôme', 'Cible thérapeutique'], [
    ['Décharge de noradrénaline', 'Palpitations, tremblement, sueurs', 'ISRS au long cours'],
    ['Hypocapnie et alcalose', 'Vertiges, fourmillements, crampes des mains', 'Respiration lente, explication'],
    ['Interprétation catastrophique', 'Peur de mourir ou de devenir fou', 'Thérapie cognitive'],
    ['Évitement', 'Restriction des sorties, agoraphobie', 'Exposition progressive'],
    ['Amplification somatique', 'Attention fixée sur le corps, consultations répétées', 'Consultations programmées, un seul médecin référent'],
   ]))))
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('Le médecin élimine d’abord une cause physique grave, car la panique imite l’infarctus, l’embolie pulmonaire, l’hypoglycémie et l’hyperthyroïdie. '
   'Cette urgence écartée, il cherche ensuite une substance (caféine, cocaïne, sevrage d’alcool ou de benzodiazépine). '
   'Il pose enfin un diagnostic positif sur des critères, et non par simple exclusion.', 18, 9, 83) +
 F('Diagnostic différentiel (fréquences en exposant rouge, même unité : prévalence chez l’adulte européen)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Trouble anxieux (tous)' + PR('14 % sur 12 mois', 46), 'Crises ou inquiétude, examen normal', 'GAD-7, entretien'],
    ['Troubles somatoformes' + PR('4,9 % sur 12 mois', 46), 'Symptômes multiples et durables', 'PHQ-15, entretien'],
    ['Trouble panique' + PR('1,8 % sur 12 mois', 46), 'Crises inattendues, crainte des crises', 'Critères DSM-5-TR'],
    ['Hyperthyroïdie' + PR('0,75 % (prévalence)', 80), 'Perte de poids, tremblement permanent, tachycardie au repos', 'TSH'],
    ['Phéochromocytome' + PR('0,2–0,6 % des hypertendus', 81), 'Céphalées, sueurs, palpitations, hypertension paroxystique', 'Métanéphrines plasmatiques libres'],
    ['Syndrome coronarien aigu, embolie pulmonaire', 'Facteurs de risque, douleur à l’effort, dyspnée, hypoxémie', 'ECG, troponine, D-dimères'],
    ['Hypoglycémie', 'Diabète traité, sueurs, faim, confusion', 'Glycémie capillaire'],
   ]) + P('Les fréquences ne sont pas des probabilités devant un patient ; le phéochromocytome est donné chez les hypertendus, car sa prévalence dans la population générale n’est pas connue avec précision. Pour le syndrome coronarien et l’hypoglycémie, aucune prévalence comparable n’a été retrouvée.', 46, 80, 81))))
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien décrit la crise : début, durée, pic, symptômes et contexte. '
   'Il cherche aussi la consommation de substances, les antécédents personnels et familiaux, l’évitement et les idées suicidaires.', 18, 83) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['La crise a-t-elle atteint son maximum en quelques minutes ?', 'Critère central de l’attaque de panique.', 'Oriente vers la panique.'],
    ['Survient-elle à l’effort ?', 'Une douleur d’effort évoque une ischémie.', 'ECG d’effort ou avis cardiologique.'],
    ['Combien de café, de boissons énergisantes, de cannabis, de cocaïne ?', 'Les stimulants déclenchent des crises.', 'Arrêt de la substance.'],
    ['Évitez-vous des lieux par peur d’une crise ?', 'Agoraphobie associée.', 'Exposition en thérapie.'],
    ['Avez-vous des idées de mort ?', 'Dépression associée et risque suicidaire.', 'Évaluation urgente si oui.'],
    ['Avez-vous perdu du poids, avez-vous des sueurs nocturnes ?', 'Hyperthyroïdie, maladie générale.', 'TSH, bilan.'],
   ])) +
 U('<b>Drapeaux rouges (urgence, 144 si instabilité)</b> : douleur à l’effort, syncope, ECG anormal, hypertension lors des crises, perte de poids, première crise après 45 ans, idées suicidaires. Le seuil de 45 ans vient de l’original et n’a pas été retrouvé dans une recommandation.', 9, 79, 83)))
PTS.append(POINT(6, 'Examen clinique',
 P('Pendant la crise, le médecin trouve une tachycardie sinusale, une respiration rapide, des sueurs et un tremblement fin. '
   'L’auscultation, la saturation et l’examen neurologique sont normaux. '
   'Un examen normal rassure mais n’exclut pas un syndrome coronarien ; l’ECG reste obligatoire.', 9, 83) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Fréquence cardiaque, rythme', 'Sinusal 60–100/min', 'Rythme irrégulier : arythmie à documenter'],
    ['Pression aux deux bras', 'Différence < 10–15 mmHg', 'Poussée hypertensive : phéochromocytome à chercher'],
    ['Saturation en oxygène', '≥ 95 %', 'Baisse : embolie pulmonaire ou maladie pulmonaire'],
    ['Thyroïde', 'Non palpable ou souple', 'Goitre, tremblement permanent : hyperthyroïdie'],
    ['Signe de Chvostek, contracture des mains', 'Absents', 'Présents : hypocalcémie ou alcalose d’hyperventilation'],
   ]))))
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont la peur de mourir, les palpitations, l’oppression, la dyspnée et les vertiges. '
   'Les signes physiques sont la tachycardie, la polypnée, les sueurs et parfois une contracture des mains. '
   'Le trouble somatique se reconnaît à des symptômes durables qui envahissent la vie du patient.', 18) +
 F('Syndromes à reconnaître',
   TAB(['Syndrome', 'Signes', 'Piège'], [
    ['Attaque de panique', 'Peur intense, palpitations, oppression, dyspnée, fourmillements, maximum en quelques minutes', 'Confondre avec un syndrome coronarien sans ECG'],
    ['Syndrome d’hyperventilation', 'Vertiges, fourmillements autour de la bouche, crampes des mains', 'Faire respirer dans un sac : déconseillé (risque d’hypoxie)'],
    ['Trouble à symptomatologie somatique', 'Fatigue, douleurs, troubles digestifs, pensées excessives, consultations répétées', 'Multiplier les examens, ce qui renforce l’inquiétude'],
    ['Agoraphobie', 'Évitement des transports et des foules', 'Ignorer l’évitement, qui entretient le trouble'],
   ]) + P(f'Terme : {AGORA}. La respiration dans un sac fermé est déconseillée, car elle peut faire baisser l’oxygène chez un patient qui a en réalité une maladie cardiaque ou pulmonaire.', 83))))
PTS.append(POINT(8, 'Critères diagnostiques',
 P('Le critère DSM-5-TR (2022) de l’attaque de panique demande au moins 4 symptômes sur 13 et un maximum en quelques minutes ; le seuil de 10 minutes appartenait au DSM-IV. '
   'Le trouble panique exige des attaques récurrentes et inattendues, puis au moins un mois de crainte ou d’évitement, sans cause physique ni substance. '
   'Un score GAD-7 élevé ne suffit pas à poser le diagnostic, et la recommandation de l’OMS (CIM-11, 2022) décrit des critères proches.', 18, 82) +
 F('Outils de mesure et seuils',
   TAB(['Outil', 'Seuils', 'Performance'], [
    ['GAD-7 (7 items, 0–21 points)', '5 léger, 10 modéré, 15 sévère', 'Seuil 10 pour le TAG : sensibilité 89 %, spécificité 82 % (Spitzer 2006)'],
    ['GAD-7 pour le trouble panique', 'Seuil 10', 'Sensibilité 74 %, spécificité 81 % (Kroenke 2007)'],
    ['PHQ-15 (15 symptômes, 0–30 points)', '5 faible, 10 moyen, 15 élevé', 'Mesure la charge somatique'],
    ['Trouble à symptomatologie somatique', '≥ 1 symptôme pénible + pensées, anxiété ou temps excessifs', 'Durée > 6 mois'],
   ]), 19, 84, 54, 18)))
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Examen', 'Ce qu’il établit', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Entretien clinique structuré selon le DSM-5-TR', 'Diagnostic positif du trouble', 'Référence par définition ; aucune sensibilité chiffrée', 'Demande du temps et de la formation'],
    ['ECG de repos', 'Écarte une ischémie ou une arythmie visible', 'Un ECG normal n’exclut pas un syndrome coronarien', 'À répéter si la douleur persiste'],
    ['Métanéphrines plasmatiques libres', 'Exclut un phéochromocytome', 'Sensibilité ≈ 97 %, spécificité ≈ 93 %', 'Faux positifs sous certains médicaments'],
   ]), 18, 9, 79) +
 F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première', 'ECG, glycémie capillaire', 'Toute première crise avec symptômes cardiaques'],
    ['Première', 'TSH', 'Première présentation, tremblement, perte de poids'],
    ['Seconde', 'Ionogramme, calcium, magnésium', 'Crampes, fourmillements persistants'],
    ['Seconde', 'Troponine, D-dimères', 'Douleur thoracique, dyspnée, facteurs de risque'],
    ['Seconde', 'Métanéphrines plasmatiques', 'Hypertension lors des crises, céphalées et sueurs'],
   ]), 9, 79) +
 F('9.c Prescription : indication, moment, préparation',
   UL(['L’<b>ECG</b> se fait pendant ou juste après la crise si possible.',
       'Les <b>métanéphrines plasmatiques</b> se prélèvent idéalement couché depuis 30 minutes ; on note les médicaments (antidépresseurs tricycliques, certains bêtabloquants) qui faussent le dosage.',
       'La <b>TSH</b> ne demande pas d’être à jeun.',
       'On limite les examens : chaque examen inutile peut renforcer l’inquiétude du patient somatisant.']), 79, 41) +
 F('9.d Interprétation',
   TAB(['Résultat', 'Seuil', 'Signification', 'Conduite'], [
    ['TSH basse', '< 0,1 mU/L', 'Hyperthyroïdie probable', 'T4 libre, avis endocrinologique'],
    ['Métanéphrines', '> 3 fois la limite supérieure', 'Phéochromocytome très probable', 'Imagerie, avis spécialisé'],
    ['Glycémie', '< 3,9 mmol/L', 'Hypoglycémie', 'Resucrage, recherche de cause'],
    ['ECG et biologie normaux', 'Sans objet', 'Cause physique fréquente peu probable', 'Diagnostic positif et explication'],
   ]), 79, 80) +
 F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Résultat positif mais discordant (métanéphrines peu élevées)', 'Répéter dans de bonnes conditions, arrêter le médicament gênant'],
    ['Résultat négatif mais clinique typique de phéochromocytome', 'Répéter le dosage pendant une crise ; avis spécialisé'],
    ['Résultat limite (TSH légèrement basse)', 'Contrôle à 6–12 semaines'],
    ['Grossesse', 'TSH avec normes de grossesse ; pas d’imagerie irradiante'],
    ['Enfant et adolescent', 'Avis pédopsychiatrique ; chercher des substances'],
    ['Insuffisance rénale (DFGe bas)', 'Métanéphrines plus difficiles à interpréter'],
    ['Allergie à l’iode, pacemaker ou IRM', 'Sans objet pour ces examens'],
   ]), 79))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Les examens ne prouvent pas la panique ; ils écartent les causes physiques fréquentes ou graves. '
   'L’ECG, la glycémie et la TSH suffisent dans la plupart des cas. '
   'Le dosage des métanéphrines se réserve aux crises avec hypertension.', 9, 79, 83) + P9))
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si le patient a une douleur thoracique, une syncope ou un ECG anormal, alors le médecin traite comme une urgence cardiaque. '
   'Si l’ECG, la glycémie et la TSH sont normaux, alors il pose le diagnostic positif et l’explique. '
   'Si les crises se répètent, alors il propose une thérapie cognitivo-comportementale et discute un ISRS.', 9, 83, 20) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['ECG anormal ou douleur d’effort', 'Filière syndrome coronarien', 'Troponine répétée'],
    ['Crise isolée, examens normaux', 'Explication, respiration lente, pas de traitement de fond', 'Revoir si récidive'],
    ['Trouble panique', 'TCC ± ISRS', 'Contrôle à 2–4 semaines'],
    ['Idées suicidaires', 'Évaluation psychiatrique le jour même', 'Plan de sécurité'],
    ['Trouble à symptomatologie somatique', 'Médecin référent, consultations programmées, TCC', 'Toutes les 4–6 semaines'],
   ]), 83, 20)))
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Mécanisme et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Escitalopram, Cipralex® (ISRS)', 'Bloque la recapture de la sérotonine ; demi-vie ≈ 30 heures', 'Trouble panique : 5 mg par jour la première semaine, puis 10 mg, maximum 20 mg ; ≥ 65 ans maximum 10 mg ; poursuite 6–12 mois après la rémission', 'Nausées, agitation initiale, troubles sexuels, hyponatrémie, allongement du QT ; contre-indiqué avec les IMAO'],
   ['Sertraline, Zoloft® (ISRS)', 'Bloque la recapture de la sérotonine ; demi-vie ≈ 26 heures', 'Trouble panique : 25 mg par jour la première semaine, puis 50 mg, maximum 200 mg', 'Diarrhée, insomnie, troubles sexuels ; interactions modestes'],
   ['Lorazépam, Temesta® (benzodiazépine)', 'Renforce l’effet du GABA ; demi-vie 12–16 heures', '1 mg par voie orale ou sublinguale pour une crise invalidante ; durée maximale 2–4 semaines', 'Dépendance, sédation, chutes ; prudence avec alcool et opioïdes'],
  ]) + P('Les doses suivent l’AIPS des produits suisses ; l’audit n’a pas rouvert ces AIPS et les signale à vérifier.', 1, 20, 83))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge commence par une explication claire du mécanisme, car comprendre le cercle vicieux réduit la peur. '
   'La thérapie cognitivo-comportementale est le traitement de première ligne ; un ISRS s’ajoute si les crises sont fréquentes ou si le patient le préfère. '
   'Les benzodiazépines restent un appoint court, car elles créent une dépendance.', 20, 83) +
 F('11.A Buts : forme compliquée (urgence), puis forme non compliquée',
   P('Dans une forme compliquée (idées suicidaires, crise impossible à distinguer d’une urgence cardiaque), le but est la sécurité du patient le jour même. Dans une forme non compliquée, le but est de réduire les crises et l’évitement, puis de retrouver une vie sociale et professionnelle normale en quelques mois.', 83), 'fenetre') +
 F('11.B Moyens',
   F('Ordre des mesures, de l’urgence à l’ambulatoire',
     OL(['<b>A. Forme compliquée, en urgence</b> : ECG et surveillance si doute cardiaque ; évaluation du risque suicidaire ; 144 si instabilité.',
         '<b>B. Crise aiguë</b> : présence calme, explication, respiration lente (6 cycles par minute) ; lorazépam 1 mg seulement si la crise est invalidante.',
         '<b>C. Forme non compliquée en ambulatoire</b> : psychoéducation, TCC de 12 à 20 séances avec exposition aux sensations, activité physique.',
         '<b>D. Traitement de fond</b> : ISRS à faible dose, augmenté par paliers, poursuivi 6–12 mois après la rémission puis réduit lentement.']), 20, 83) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('La psychothérapie déléguée ou prescrite par le médecin est prise en charge par l’assurance de base dans les conditions de l’OPAS.',
            'Un arrêt de travail court se discute ; un arrêt prolongé renforce l’évitement.',
            'La conduite automobile est déconseillée pendant l’adaptation d’une benzodiazépine.'), 60, 61, 59) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'TCC d’abord ; la sertraline est l’ISRS le plus étudié ; avis spécialisé'],
      ['Personne âgée', 'Escitalopram 10 mg au maximum ; éviter les benzodiazépines (chutes)'],
      ['Enfant et adolescent', 'TCC ; avis pédopsychiatrique avant un ISRS'],
      ['Insuffisance hépatique', 'Escitalopram 5 mg les deux premières semaines, puis 10 mg au maximum'],
      ['Insuffisance rénale (DFGe)', 'Prudence si DFGe < 30 mL/min'],
     ]), 1, 23), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Fréquence des crises, GAD-7', 'Toutes les 4 semaines', 'Pas d’amélioration à 8–12 semaines : changer de stratégie'],
    ['Effets de l’ISRS (agitation, sommeil, sexualité)', 'À 1–2 semaines', 'Agitation importante : réduire la dose'],
    ['Idées suicidaires', 'À chaque visite, surtout chez le jeune adulte', 'Idées présentes : évaluation urgente'],
    ['Natrémie', 'Personne âgée sous ISRS', 'Na < 130 mmol/L : réévaluer'],
   ]) + H4('Critères de sortie, un par un') +
   OL(['Cause physique grave exclue.', 'Patient rassuré et capable d’expliquer le mécanisme.', 'Absence d’idées suicidaires.', 'Suivi ambulatoire planifié.']), 19, 73, 83) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic est bon sous traitement, mais les rechutes sont fréquentes à l’arrêt. Le taux de rémission de 70–80 % de l’original n’a pas été retrouvé dans une source et a été retiré. La recherche 2026 évalue la thérapie par réalité virtuelle et les thérapies cognitives en ligne ; l’usage d’autres molécules reste expérimental.', 83), 'fenetre')))
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire réduit les stimulants (caféine, boissons énergisantes) et encourage l’activité physique et le sommeil régulier. '
   'La prévention secondaire repère tôt les crises et évite l’évitement. '
   'La prévention tertiaire limite les examens répétés et les benzodiazépines au long cours ; l’OFSP soutient la santé psychique par la stratégie nationale.', 83, 62, 41) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure'], [
    ['Primaire', 'Hygiène de vie, gestion du stress'],
    ['Secondaire', 'Repérage par GAD-7 ou PHQ-15 en médecine de famille'],
    ['Tertiaire', 'Médecin référent, TCC, pas de benzodiazépine au long cours'],
   ]))))
PTS.append(POINT(13, 'Points clés',
 P('Le médecin fait un ECG et une glycémie avant de parler de panique. '
   'Il pose un diagnostic positif, il ne se contente pas d’exclure. '
   'Il explique le cercle vicieux de l’hyperventilation. '
   'Il propose une TCC en première ligne et un ISRS au besoin. '
   'Il limite les benzodiazépines à quelques semaines.', 9, 18, 83)))
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Dire « ce n’est que du stress » sans ECG.', 'Faire l’ECG, puis expliquer avec empathie.'],
  ['Exiger l’absence de cause organique pour le trouble somatique.', 'Le DSM-5 juge la réaction excessive au symptôme.'],
  ['Prescrire une benzodiazépine au long cours.', 'TCC et ISRS ; benzodiazépine au maximum 2–4 semaines.'],
  ['Faire respirer dans un sac.', 'Respiration lente guidée.'],
  ['Méconnaître une hyperthyroïdie ou un phéochromocytome.', 'TSH chez tous ; métanéphrines si hypertension lors des crises.'],
 ]) + P('Ces pièges reprennent le DSM-5-TR, NICE CG113 et la recommandation de l’Endocrine Society.', 18, 83, 79)))
CTX = {'_prefixe': 'Dans l’attaque de panique',
 'ecg': 'L’ECG écarte une ischémie ou une arythmie avant de parler de panique.',
 'gly': 'La glycémie capillaire écarte une hypoglycémie, qui donne sueurs et palpitations.',
 'tsh': 'Une TSH basse oriente vers une hyperthyroïdie, qui imite l’anxiété.',
 't4t3': 'La T4 libre confirme une hyperthyroïdie si la TSH est basse.',
 'iono': 'L’ionogramme cherche une anomalie du potassium ou du sodium.',
 'mg': 'Une magnésémie basse donne des crampes et des fourmillements.',
 'meta': 'Les métanéphrines plasmatiques libres excluent un phéochromocytome si elles sont normales.',
 'tropo': 'La troponine écarte un infarctus si la douleur thoracique est typique ou si l’ECG est anormal.',
 'ddim': 'Les D-dimères écartent une embolie pulmonaire si la probabilité clinique est faible.',
 'oxy': 'La saturation normale rend une embolie pulmonaire moins probable.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
