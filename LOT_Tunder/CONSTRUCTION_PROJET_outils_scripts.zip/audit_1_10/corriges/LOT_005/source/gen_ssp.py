# -*- coding: utf-8 -*-
"""Générateur du cours AUDITÉ de l’Appel A du LOT 5 : SSP G5 « Sensation de maladie, malaise général » (14 points) + bloc 2 (liste des dix diagnostics).
Original : LOT_5_Appel_A_V5 (export Google Docs, sans section Sources). Toutes les références viennent du registre lot5_commun (audit du 24.10.2026)."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lot5_commun import *
POINT = mkPOINT('ssp')
M = dict(pref='ssp', dx='SSP G5', court='Sensation de maladie', long='Sensation de maladie, malaise général (situation clinique de départ)', dossier='corriges/LOT_005',
         fichier='LOT_005_Appel_A_SSP_G5_Sensation_de_maladie_AUDITÉ.html', lot_titre='LOT 5 · G5 · Sensation de maladie, malaise général',
         sous_titre='PROFILES 2023 · SSP G5 · LOT 5 · Appel A · V7 · version AUDITÉE (14 points et liste des dix diagnostics)',
         statut='Cette version corrige l’Appel A du LOT 5 (plan monographique et liste différentielle V5, export Google Docs) après audit médical et linguistique. '
                'L’original ne citait aucune source : toutes les références ont été ajoutées par l’audit et restent à vérifier ; les doses proviennent des informations professionnelles suisses (AIPS).')
_build = gen_v7.build
def _build_ssp(*a, **k):
    return _build(*a, **k).replace('<a href="#ssp-p15">15</a>', '<a href="#ssp-p15">Dix DX</a>')
gen_v7.build = _build_ssp

CYTO = T('cytokine', 'Une cytokine est une petite protéine messagère libérée par les cellules immunitaires ; elle informe les autres organes, dont le cerveau, qu’une agression est en cours.')
COMP = T('comportement de maladie', 'Le comportement de maladie (sickness behavior) est l’ensemble fatigue, perte d’appétit, somnolence, repli et douleurs diffuses déclenché par le cerveau en réponse aux cytokines ; il économise l’énergie pour lutter contre l’agression.')
OCV = T('organes circumventriculaires', 'Les organes circumventriculaires sont de petites zones du cerveau sans barrière hémato-encéphalique complète ; les messagers du sang y entrent en contact avec les neurones.')
INSU = T('cortex insulaire', 'Le cortex insulaire (insula) est la région du cerveau qui rassemble les messages venus du corps ; il fabrique la sensation consciente « je ne me sens pas bien ».')
NSC = T('plainte non spécifique', 'Une plainte non spécifique est un motif de consultation qui n’oriente vers aucun organe : « faiblesse », « vertige », « ne pas se sentir bien ».')
QSOFA = T('qSOFA', 'Le qSOFA (quick Sequential Organ Failure Assessment) compte 1 point pour chacun de ces signes : fréquence respiratoire ≥ 22/min, conscience altérée, pression systolique ≤ 100 mmHg.')
PTS = []

# ---------- 1
PTS.append(POINT(1, 'Définition et sémantique',
 P('La sensation de maladie est l’impression diffuse et désagréable de « ne pas se sentir bien », sans organe désigné. '
   f'Elle traduit le plus souvent le {COMP}, déclenché par le cerveau quand l’organisme est agressé. '
   'C’est un symptôme d’appel, pas un diagnostic : il précède souvent les signes localisés.', 118, 116) +
 F('Terminologie : mot courant et terme exact',
   TAB(['Mot courant', 'Terme exact', 'Définition', 'À ne pas confondre avec'], [
    ['« Je ne me sens pas bien »', 'Sensation de maladie, malaise général', 'Perception subjective diffuse d’un état de santé altéré', 'Malaise avec perte de connaissance (syncope)'],
    ['« Je couve quelque chose »', 'Comportement de maladie (sickness behavior)', 'Fatigue, anorexie, repli, douleurs diffuses induits par les cytokines', 'Dépression, même si les symptômes se recouvrent'],
    ['« Je suis faible »', 'Asthénie', 'Manque d’énergie physique et psychique', 'Déficit moteur (paralysie)'],
    ['« Il va moins bien depuis quelques jours »', 'Altération de l’état général (AEG)', 'Asthénie, anorexie, amaigrissement', 'Fatigue d’effort normale'],
    ['« Elle n’est plus elle-même »', 'État confusionnel aigu (delirium)', 'Trouble aigu et fluctuant de l’attention', 'Démence, installée lentement'],
    ['Motif flou aux urgences', 'Plainte non spécifique', 'Motif sans protocole d’organe : faiblesse, vertige, malaise', 'Plainte bénigne : 59 % ont une affection grave à 30 jours dans l’étude bâloise'],
   ]) + P(f'Le terme {NSC} vient de l’étude bâloise BANC, faite aux urgences de l’Hôpital universitaire de Bâle.', 116), 116, 118) +
 F('Pourquoi ces mots changent la décision',
   UL(['Un malaise avec perte de connaissance relève de la syncope, avec un autre bilan.',
       'Une confusion aiguë impose de chercher une cause organique urgente, comme dans le delirium.',
       'Une plainte floue chez une personne âgée doit faire penser à une affection grave, car elle est fréquente.']), 116, 16)))

# ---------- 2
PTS.append(POINT(2, 'Épidémiologie (Suisse, puis Europe)',
 P('À Bâle, 13,5 % des patients non traumatiques de gravité moyenne arrivent aux urgences avec une plainte non spécifique. '
   'Leur âge médian est de 82 ans, et 59 % ont une affection grave dans les 30 jours. '
   'En Europe et dans le monde, aucune étude ne chiffre la part de chaque cause.', 116) +
 P('Le terrain change le pronostic : l’âge, la fragilité et les maladies associées augmentent la mortalité, qui atteint 6 % à 30 jours dans l’étude bâloise.', 116, 92) +
 F('Chiffres comparables : même unité quand c’est possible',
   TAB(['Cause', 'Valeur (pour 100 000 habitants par an)', 'Population et nature du chiffre'], [
    ['Syndrome grippal', '≈ 3 611' + S(2), 'Suisse, consultations Sentinella extrapolées, une saison'],
    ['Sepsis', '240' + S(92), 'Suisse 2023, séjours hospitaliers codés, taux standardisé'],
    ['Pseudopolyarthrite rhizomélique', '63,9' + S(100), 'Minnesota, personnes de 50 ans ou plus'],
    ['Endocardite infectieuse', '13,8' + S(11), 'Incidence mondiale 2019'],
    ['Artérite à cellules géantes (Horton)', '10,0' + S(51), 'Méta-analyse mondiale, personnes de plus de 50 ans'],
    ['Intoxication au CO', '≈ 0,5' + S(105), 'Suisse 2024, consultations de Tox Info Suisse (calcul de l’audit)'],
   ], 'Ces taux n’ont pas la même source ni le même dénominateur : ils donnent un ordre de grandeur, pas une probabilité devant un patient.') +
   P('Les autres causes ne sont chiffrées qu’en proportion d’une autre population : 6,5 % des admissions pour effet indésirable médicamenteux, 14 % de troubles anxieux sur 12 mois en Europe.', 42, 46) +
   P('Correction de l’original : les chiffres « 8 à 15 % des consultations, plus de 20 % après 75 ans, plus de 30 % de pathologie grave » attribués à la SSMIG ne sont pas retrouvés ; ils ont été remplacés par l’étude bâloise.', 116), 116, 2, 92) +
 F('Facteurs de risque, terrain et pronostic',
   TAB(['Facteur ou terrain', 'Pourquoi il compte'], [
    ['Âge ≥ 65 ans', 'Présentations atypiques ; 70,2 % des sepsis suisses surviennent à cet âge'],
    ['Sexe féminin, diabète', 'Infarctus sans douleur thoracique plus fréquent : 42,0 % des femmes contre 30,7 % des hommes'],
    ['Polymédication', 'Effets indésirables et interactions : cause fréquente d’admission'],
    ['Immunodépression, prothèse valvulaire', 'Infection grave plus probable, fièvre parfois absente'],
    ['Démence, fragilité', 'Delirium hypoactif, plainte difficile à exprimer'],
   ]) + P('La mortalité hospitalière du sepsis atteint 18,9 % en Suisse ; celle de l’infarctus est plus élevée sans douleur thoracique.', 92, 36), 92, 36, 42)))

# ---------- 3
PTS.append(POINT(3, 'Physiopathologie',
 P(f'Une agression (microbe, ischémie, tumeur, toxique) active l’immunité innée, qui libère des {CYTO}s : IL-1β, IL-6 et TNF-α. '
   'Ces messagers informent le cerveau, qui déclenche fatigue, perte d’appétit, frissons et repli. '
   'La sensation de maladie est donc un signal d’alarme utile, pas une cause.', 118) +
 F('Deux voies du corps vers le cerveau',
   TAB(['Voie', 'Ce qui se passe', 'Conséquence clinique'], [
    ['Voie humorale (par le sang)', f'Les cytokines agissent sur les {OCV} ; la COX-2 des vaisseaux y fabrique des prostaglandines', 'Fièvre, somnolence ; d’où l’effet du paracétamol'],
    ['Voie nerveuse (nerf vague)', f'Les fibres du nerf vague informent le tronc cérébral puis le {INSU}', 'Malaise rapide, nausée, anorexie'],
    ['Voie hormonale de stress', 'Adrénaline et cortisol augmentent', 'Tachycardie, sueurs, hyperglycémie'],
    ['Voie non immune', 'Hypoxie (CO, anémie), trouble du sodium ou du glucose, médicament', 'Même malaise, sans fièvre ni CRP élevée'],
   ]), 118, 14, 12) +
 F('Chaîne logique : de l’anatomie au traitement',
   TAB(['Étape', 'Ce qu’il faut comprendre'], [
    ['Anatomie', 'Le cerveau reçoit les messages du corps par le sang et par le nerf vague ; l’insula les rend conscients.'],
    ['Physiologie', 'Pourquoi on se sent malade : le cerveau économise l’énergie pour lutter contre l’agression.'],
    ['Physiopathologie', 'Infection, ischémie, trouble métabolique, toxique, médicament ou trouble anxieux activent ce même signal.'],
    ['Clinique', 'D’où un malaise commun à toutes les causes ; seuls les signes associés et les constantes orientent.'],
    ['Examens', 'Constantes, glycémie, ECG, CRP, procalcitonine, lactate : chacun teste une branche.'],
    ['Traitement', 'On traite la cause ; le paracétamol soulage le malaise sans rien guérir.'],
   ]), 118, 4) +
 F('Mécanisme, exploration et cible thérapeutique',
   TAB(['Mécanisme (lésion)', 'Exploration qui le montre', 'Cible thérapeutique'], [
    ['Infection bactérienne et cytokines', 'Hémocultures, CRP, procalcitonine, lactate', 'Antibiotique adapté au foyer, remplissage'],
    ['Infection virale', 'Clinique, PCR si conséquence', 'Traitement symptomatique ; antiviral selon le risque'],
    ['Ischémie du myocarde', 'ECG, troponine', 'Revascularisation, antithrombotiques'],
    ['Trouble du sodium ou du glucose', 'Ionogramme, glycémie', 'Correction prudente, arrêt du médicament en cause'],
    ['Hypoxie toxique (CO)', 'CO-oxymétrie (HbCO)', 'Oxygène à 100 %, OHB selon la gravité'],
    ['Vascularite des grosses artères', 'VS, CRP, échographie temporale', 'Corticoïde'],
    ['Alarme anxieuse sans lésion', 'Examen normal, exclusion organique', 'Explication, thérapie cognitivo-comportementale'],
   ]) + P('Le mécanisme explique pourquoi le paracétamol soulage toutes les causes sans en traiter aucune.', 118, 5, 14), 118, 5, 9, 14) +
 F('Fenêtre bio-mathématique : qSOFA, pression moyenne et biomarqueurs',
   P(f'Le {QSOFA} se calcule au lit, sans laboratoire : FR ≥ 22/min (1 point) + conscience altérée (1 point) + PAS ≤ 100 mmHg (1 point).', 4) +
   P('La pression artérielle moyenne vaut PAM = (PAS + 2 × PAD) / 3 ; une PAM ≥ 65 mmHg est la cible du choc septique.', 5) +
   P('Exemple : patient de 72 ans, pression 94/52 mmHg, FR 26/min, légère désorientation. '
     'Le qSOFA vaut 3, un point par critère, et la PAM vaut (94 + 2 × 52) / 3, soit 66 mmHg : alerte sepsis.', 4, 5) +
   TAB(['Marqueur', 'Valeur normale', 'Seuil et cinétique', 'Interprétation'], [
    ['Score qSOFA', '0', '≥ 2 points', 'Risque accru de décès : calculer le SOFA ; ne suffit pas comme dépistage seul'],
    ['Lactate', '< 2 mmol/L', '≥ 2 mmol/L avec vasopresseur pour PAM ≥ 65 mmHg : choc septique', 'Hypoperfusion des tissus'],
    ['CRP', '< 5 mg/L', 'Monte en 6–12 h, pic à 36–48 h ; demi-vie ≈ 19 h', 'Une CRP normale au début n’exclut pas une infection'],
    ['Procalcitonine', '< 0,05 µg/L', '< 0,25 µg/L : antibiotique déconseillé ; ≥ 0,5 µg/L : antibiotique encouragé', 'Plus basse dans les infections virales ; guide la durée des antibiotiques'],
   ]) + P('La cinétique de la procalcitonine donnée par l’original (hausse en 2–4 h, pic à 12–24 h) n’a pas été retrouvée dans les sources consultées ; elle est retirée.', 117), 4, 5, 117, 119)))

# ---------- 4
PTS.append(POINT(4, 'Raisonnement clinique et diagnostic différentiel',
 P('En urgence, le médecin écarte d’abord les causes vitales à présentation trompeuse : sepsis débutant, infarctus sans douleur, trouble métabolique aigu, intoxication au CO. '
   'Il sépare ensuite les causes aiguës fréquentes, comme la virose ou l’effet médicamenteux, des causes subaiguës. '
   'L’étape finale est le trouble anxieux ou somatique, retenu seulement après exclusion organique.', 4, 36, 116) +
 F('Diagnostic différentiel (fréquence sourcée en exposant rouge)',
   TAB(['Diagnostic et fréquence', 'Éléments d’orientation', 'Examen discriminant'], [
    ['Infection virale aiguë' + PR('≈ 3 611 consultations / 100 000 par saison (Suisse)', 2), 'Hiver, myalgies, fièvre, entourage malade', 'Clinique ; PCR si conséquence'],
    ['Effet indésirable médicamenteux' + PR('6,5 % des admissions (Royaume-Uni)', 42), 'Nouveau médicament, polymédication', 'Chronologie, ionogramme, ECG'],
    ['Trouble anxieux ou somatique' + PR('14 % sur 12 mois (troubles anxieux, Europe)', 46), 'Accès brefs, examen normal', 'Après exclusion organique'],
    ['Trouble métabolique (hyponatrémie)' + PR('15–30 % des hospitalisés', 44), 'Diurétique, ISRS, confusion, chutes', 'Ionogramme, glycémie, calcium'],
    ['Sepsis débutant' + PR('240 / 100 000 par an (Suisse)', 92), 'Frissons, tachypnée, confusion', 'Lactate, hémocultures'],
    ['SCA atypique' + PR('sans douleur thoracique : 42,0 % des femmes, 30,7 % des hommes avec infarctus', 36), 'Diabète, âge, sueurs, nausée', 'ECG, troponine'],
    ['PPR, Horton' + PR('63,9 et 10,0 / 100 000 personnes ≥ 50 ans par an', 100, 51), 'Raideur des épaules, céphalée, claudication de la mâchoire', 'VS, CRP, échographie temporale'],
    ['Delirium, glissement' + PR('14,6 % des admissions non programmées (âge moyen 82 ans)', 102), 'Changement aigu, attention fluctuante', 'Score 4AT'],
    ['Endocardite subaiguë' + PR('13,8 / 100 000 par an (monde)', 11), 'Fièvre prolongée, souffle, prothèse', 'Hémocultures, échocardiographie'],
    ['Intoxication au CO' + PR('≈ 0,5 / 100 000 par an (consultations, Suisse)', 105), 'Malaise collectif sans fièvre en hiver', 'CO-oxymétrie (HbCO)'],
   ]) + P('Ces chiffres ont des populations différentes : ils ne sont pas des probabilités devant un patient donné.', 2, 42, 92)) +
 F('Hiérarchie des urgences : danger, discriminant, action',
   TAB(['Danger', 'Discriminant', 'Action immédiate'], [
    ['Sepsis', 'qSOFA ≥ 2, lactate ≥ 2 mmol/L, marbrures', 'Hémocultures puis antibiotique dans l’heure'],
    ['Infarctus atypique', 'ECG, troponine dans sa cinétique', 'Filière urgente (144)'],
    ['Hypoglycémie, hyponatrémie sévère', 'Glycémie capillaire, ionogramme', 'Correction selon le protocole'],
    ['Intoxication au CO', 'Plusieurs malades sous le même toit, HbCO', 'Évacuation, oxygène à 100 %'],
    ['Delirium', 'Score 4AT ≥ 4', 'Recherche de la cause organique'],
   ]), 4, 5, 9, 14, 17)))

# ---------- 5
PTS.append(POINT(5, 'Anamnèse ciblée et drapeaux rouges',
 P('L’entretien fait préciser ce que le patient entend par « se sentir mal ». '
   'Il établit la chronologie, les médicaments récents, l’entourage et le terrain.', 116, 42) +
 F('Questions et ce que la réponse change',
   TAB(['Question', 'Raison', 'Ce que la réponse change'], [
    ['Que ressentez-vous exactement ?', 'Courbatures, frissons, nausée, tête vide ou angoisse orientent vers des branches différentes.', 'Choix de la branche principale.'],
    ['Depuis quand, brutal ou progressif ?', 'Un début en minutes évoque une cause vasculaire ou toxique.', 'ECG, glycémie, HbCO immédiats.'],
    ['Médicament commencé ou changé en 15 jours ?', 'Les effets indésirables apparaissent souvent après un changement.', 'Révision de l’ordonnance.'],
    ['Quelqu’un d’autre est-il malade chez vous ?', 'Un malaise collectif sans fièvre évoque le CO ; une épidémie évoque une virose.', 'CO-oxymétrie ou test viral.'],
    ['Frissons intenses ?', 'Des frissons solennels évoquent une bactériémie.', 'Hémocultures.'],
    ['Gêne thoracique, épigastrique, essoufflement ?', 'Un infarctus peut se présenter sans douleur franche.', 'ECG en moins de 10 minutes.'],
    ['Céphalée récente, douleur des épaules, après 50 ans ?', 'Évoque une maladie de Horton ou une PPR.', 'VS, CRP, avis rapide.'],
    ['Changement de comportement remarqué par les proches ?', 'Un delirium hypoactif passe inaperçu.', 'Score 4AT.'],
   ]), 116, 36, 42, 14, 104) +
 U('<b>Drapeaux rouges (appel du 144 ou urgences)</b> : qSOFA ≥ 2, frissons secouant le lit, purpura qui ne s’efface pas à la pression, confusion aiguë, oligurie, gêne thoracique ou épigastrique d’effort, malaise collectif.', 4, 5, 36, 14)))

# ---------- 6
PTS.append(POINT(6, 'Examen clinique',
 P('L’examen commence par toutes les constantes : température, pouls, pression, fréquence respiratoire comptée sur une minute, SpO2 et glycémie capillaire. '
   'Le médecin cherche ensuite des signes d’hypoperfusion, puis examine toute la peau et chaque organe.', 6, 5) +
 F('Technique, normal, anomalie et valeur',
   TAB(['Geste', 'Normal attendu', 'Anomalie et signification'], [
    ['Fréquence respiratoire (1 minute)', '12–20/min', '≥ 22/min : critère qSOFA' + S(4)],
    ['Temps de recoloration capillaire', '< 3 secondes', '> 3 secondes : hypoperfusion' + S(5)],
    ['Genoux et cuisses', 'Peau homogène', 'Marbrures : choc débutant' + S(5)],
    ['Peau entière, patient déshabillé', 'Pas de lésion', 'Purpura, érysipèle, escarre infectée' + S(5)],
    ['Auscultation cardiaque', 'Deux bruits, pas de souffle', 'Souffle nouveau : endocardite' + S(11)],
    ['Auscultation pulmonaire', 'Murmure symétrique', 'Crépitants : pneumonie' + S(67)],
    ['Artères temporales (après 50 ans)', 'Battantes, indolores', 'Induration, pouls absent : Horton' + S(51)],
    ['Nuque', 'Souple', 'Raideur : méningite' + S(5)],
    ['Attention (mois à l’envers)', 'Sans erreur', 'Erreurs : delirium possible' + S(104)],
   ]) + P('Termes : ' + T('marbrures', 'Les marbrures sont des taches violacées en réseau sur la peau, surtout aux genoux ; elles traduisent une mauvaise perfusion.') + ', '
          + T('purpura', 'Le purpura est une tache rouge due à du sang sorti des vaisseaux ; il ne s’efface pas quand on appuie dessus.') + '.', 5))))

# ---------- 7
PTS.append(POINT(7, 'Syndromes et signes cliniques',
 P('Les signes fonctionnels sont rapportés par le patient : malaise, fatigue, frissons, nausée, angoisse. '
   'Les signes physiques sont constatés : fièvre, tachypnée, hypotension, marbrures, souffle, confusion. '
   'Ils se regroupent en syndromes, chacun avec son discriminant.', 118, 4) +
 F('Syndromes et signes définis',
   TAB(['Syndrome', 'Signes', 'Mécanisme', 'Discriminant'], [
    ['Comportement de maladie aigu', 'Malaise, asthénie, frissons, myalgies, anorexie, céphalée', 'Cytokines sur le cerveau', 'Contexte viral, constantes normales' + S(118)],
    ['Sepsis débutant', 'Confusion, tachypnée, tachycardie, hypotension, marbrures, oligurie', 'Dysfonction d’organe due à l’infection', 'qSOFA, lactate, SOFA' + S(4)],
    ['Équivalent ischémique', 'Malaise brutal, sueurs froides, nausée, dyspnée', 'Ischémie du myocarde', 'ECG, troponine' + S(36)],
    ['Encéphalopathie métabolique', 'Confusion, faiblesse, chutes, crampes', 'Trouble du sodium, du calcium ou du glucose', 'Ionogramme, glycémie' + S(12)],
    ['Syndrome inflammatoire subaigu', 'Fébricule, raideur, céphalée, amaigrissement', 'Inflammation chronique', 'VS, CRP' + S(51)],
    ['Delirium hypoactif', 'Somnolence, attention fluctuante, repli', 'Défaillance cérébrale aiguë', 'Score 4AT' + S(17)],
    ['Hypoxie toxique collective', 'Céphalées, vertiges, nausées chez plusieurs personnes', 'Fixation du CO sur l’hémoglobine', 'HbCO' + S(14)],
   ]))))

# ---------- 8
PTS.append(POINT(8, 'Critères diagnostiques',
 P('La sensation de maladie n’a pas de critère propre : le diagnostic positif est celui de la cause. '
   'Le consensus Sepsis-3 de 2016 définit le sepsis par une hausse du score SOFA d’au moins 2 points due à une infection. '
   'Un qSOFA ≥ 2 ne suffit pas à poser le diagnostic, et un qSOFA bas ne l’exclut pas.', 4, 5) +
 F('Critères de chaque cause (société, année, seuil)',
   TAB(['Cause', 'Référence', 'Critère et seuil'], [
    ['Sepsis', 'Consensus Sepsis-3, 2016', 'Infection + hausse du SOFA ≥ 2 points ; choc : vasopresseur pour PAM ≥ 65 mmHg et lactate > 2 mmol/L'],
    ['Infarctus', '4e définition universelle (ESC), 2018', 'Troponine en hausse ou en baisse avec au moins une valeur > 99e percentile, plus ischémie'],
    ['Endocardite', 'Critères de Duke ESC, 2023', 'Critères majeurs et mineurs combinés'],
    ['Delirium', 'DSM-5-TR, 2022 ; dépistage 4AT', 'Trouble aigu de l’attention ; 4AT ≥ 4 : delirium possible'],
    ['Trouble somatique', 'DSM-5-TR, 2022', 'Symptômes pénibles avec pensées excessives depuis plus de 6 mois'],
    ['Intoxication au CO', 'Consensus européen, 2016', 'Exposition + symptômes + HbCO > 3 % (non-fumeur)'],
   ]) + P('Une CRP élevée ne permet pas de poser un diagnostic : elle signale une inflammation, sans dire laquelle.', 119), 4, 10, 11, 18, 104, 106)))

# ---------- 9
P9 = (F('9.a Examens de référence (gold standard)',
   TAB(['Question', 'Examen de référence', 'Performance (sensibilité, spécificité)', 'Limite'], [
    ['Bactériémie, endocardite ?', 'Hémocultures avant antibiotique (2–3 paires)', 'Méthode de référence ; sensibilité diminuée après un antibiotique' + S(11), 'Délai de 24–72 h'],
    ['Infarctus ?', 'ECG 12 dérivations et troponine ultrasensible', 'Algorithme ESC 0 h / 1 h' + S(98), 'Une valeur isolée ne suffit pas'],
    ['Grippe ?', 'RT-PCR de laboratoire', 'Tests rapides antigéniques : sensibilité ≈ 62 %, spécificité ≈ 98 %' + S(65), 'Un test rapide négatif n’exclut pas'],
    ['Delirium ?', 'Évaluation clinique selon le DSM-5-TR', 'Score 4AT : sensibilité 0,88, spécificité 0,88' + S(17), 'Dépistage, pas diagnostic'],
    ['Intoxication au CO ?', 'CO-oxymétrie sanguine (HbCO)', 'Oxymètre de pouls du CO (SpCO) : sensibilité 0,77, spécificité 0,83' + S(115), 'Taux bas après oxygène'],
   ]), 'fenetre') +
  F('9.b Première intention, seconde intention',
   TAB(['Intention', 'Examen', 'Critère de passage'], [
    ['Première, au lit', 'Constantes, glycémie capillaire, ECG 12 dérivations (adulte > 40 ans ou à risque)', 'Tout malaise non étiqueté' + S(9)],
    ['Première, laboratoire', 'NFS, CRP, ionogramme (sodium, potassium, calcium corrigé), créatinine, ASAT/ALAT, bandelette urinaire', 'Orientation initiale' + S(12, 57)],
    ['Seconde', 'Lactate et 2 paires d’hémocultures, procalcitonine', 'Suspicion de sepsis' + S(5, 117)],
    ['Seconde', 'Troponine ultrasensible à 0 h et 1 h', 'Doute ischémique' + S(98)],
    ['Seconde', 'VS, échographie Doppler des artères temporales', 'Après 50 ans, inflammation inexpliquée' + S(51)],
    ['Seconde', 'Radiographie du thorax ou échographie au lit', 'Toux, dyspnée, crépitants' + S(67)],
    ['Selon le contexte', 'CO-oxymétrie', 'Malaise collectif, hiver, chauffage' + S(14)],
   ]), 'fenetre') +
  F('9.c Prescription : indication, moment, préparation',
   UL(['Les hémocultures se prélèvent avant l’antibiotique, sans retarder celui-ci au-delà de l’heure en cas de choc.',
       'La troponine se répète selon l’algorithme 0 h / 1 h, avec l’heure exacte du prélèvement.',
       'L’HbCO se mesure le plus tôt possible : l’oxygène la fait baisser rapidement.',
       'La glycémie capillaire se mesure dès l’arrivée, avant toute perfusion de glucose.']), 5, 98, 14) +
  F('9.d Interprétation',
   TAB(['Résultat', 'Signification', 'Conduite'], [
    ['CRP normale dans les 12 premières heures', 'Délai de synthèse par le foie', 'Ne pas exclure une infection ; répéter'],
    ['Procalcitonine < 0,25 µg/L', 'Infection bactérienne peu probable', 'Antibiotique déconseillé si l’état est stable'],
    ['Lactate ≥ 2 mmol/L', 'Hypoperfusion possible', 'Filière sepsis'],
    ['Troponine élevée sans cinétique', 'Atteinte du myocarde, cause à préciser', 'Répéter, ECG, contexte'],
    ['Résultat discordant avec la clinique', 'Moment ou méthode inadapté', 'Ne pas clore l’hypothèse'],
   ]) + P('Un examen normal ne ferme une branche que dans les conditions validées de sa méthode.', 117, 119), 'fenetre') +
  F('9.e Alternatives et terrains particuliers',
   TAB(['Situation', 'Adaptation'], [
    ['Grossesse', 'Test de grossesse d’abord ; échographie préférée ; OHB plus large en cas de CO'],
    ['DFGe < 30 mL/min/1,73 m²', 'Produit de contraste iodé seulement si nécessaire'],
    ['Personne âgée', 'Fièvre souvent absente ; dépistage du delirium systématique'],
    ['Patient anticoagulé', 'Prélèvements avec compression prolongée'],
    ['Enfant', 'Valeurs de référence adaptées à l’âge ; score qSOFA non validé chez l’enfant'],
    ['Allergie au produit de contraste iodé', 'Échographie ou IRM'],
    ['Stimulateur cardiaque', 'Compatibilité vérifiée avant une IRM'],
   ]), 'fenetre'))
PTS.append(POINT(9, 'Examens complémentaires',
 P('Le bilan d’orientation teste les branches dangereuses avant les branches fréquentes. '
   'Le médecin demande d’abord constantes, glycémie et ECG, puis une biologie simple, et des examens ciblés seulement si une hypothèse se précise.', 9, 5) + P9))

# ---------- 10
PTS.append(POINT(10, 'Arbre décisionnel',
 P('Si le qSOFA est ≥ 2 ou s’il existe une hypoperfusion, alors le patient est pris en charge à l’hôpital selon la filière sepsis. '
   'Si les constantes sont stables, alors ECG et glycémie écartent une cause cardiaque ou métabolique. '
   'Si tout est normal, alors l’anamnèse et la biologie orientent vers une virose, un médicament ou une maladie subaiguë.', 4, 5, 9) +
 F('Embranchements et décisions',
   TAB(['Si…', 'Alors…', 'Contrôle suivant'], [
    ['qSOFA ≥ 2, lactate ≥ 2 mmol/L', 'Hémocultures, antibiotique dans l’heure, remplissage', 'Lactate répété'],
    ['ECG anormal ou troponine élevée', 'Filière SCA', 'Troponine à 1 h'],
    ['Glycémie ou sodium anormal', 'Correction selon le protocole', 'Contrôle rapproché'],
    ['Malaise collectif, hiver', 'Évacuation, oxygène, HbCO', 'Logement contrôlé'],
    ['Nouveau médicament', 'Arrêt ou adaptation', 'Réévaluation à 48–72 h'],
    ['Après 50 ans, VS élevée, céphalée', 'Horton possible : avis rapide', 'Biopsie ou échographie'],
    ['Confusion aiguë', 'Recherche de cause, 4AT', 'Réévaluation quotidienne'],
    ['Tout normal, contexte viral', 'Traitement symptomatique, consignes', 'Reconsulter si aggravation'],
   ]) + P('Une amélioration sous paracétamol ne ferme aucune branche dangereuse.', 5, 41))))

# ---------- 11
MED = F('Fiches médicamenteuses (posologies AIPS)',
  TAB(['Médicament (classe)', 'Mécanisme d’action et pharmacocinétique', 'Dose et durée (adulte)', 'Effets indésirables, contre-indications, interactions'], [
   ['Paracétamol, Dafalgan® (classe : analgésique antipyrétique)', 'Inhibe la synthèse centrale des prostaglandines ; demi-vie ≈ 2 heures, métabolisme hépatique', '500–1000 mg toutes les 6–8 heures, maximum 4 g par jour ; dose réduite si poids < 50 kg ou atteinte hépatique ; durée : 3 à 5 jours', 'Hépatotoxicité en surdosage ; contre-indiqué en insuffisance hépatique sévère ; interaction : alcool, anticoagulants oraux (INR)'],
   ['Ceftriaxone, Rocephin® (classe : céphalosporine de 3e génération)', 'Bloque la paroi bactérienne ; demi-vie ≈ 8 heures, élimination biliaire et rénale', '2 g IV une fois par jour ; durée selon le foyer', 'Allergie, boue biliaire ; contre-indication : allergie grave aux bêtalactamines ; interaction : calcium IV chez le nouveau-né'],
   ['Amoxicilline-acide clavulanique, Co-Amoxi® (classe : pénicilline + inhibiteur)', 'Bloque la paroi ; le clavulanate inhibe les bêtalactamases ; demi-vie ≈ 1 heure', '2,2 g IV toutes les 8 heures', 'Diarrhée, hépatite cholestatique ; contre-indication : allergie aux pénicillines ; interaction : méthotrexate'],
   ['Pipéracilline-tazobactam, Tazobac® (classe : pénicilline à large spectre)', 'Spectre incluant Pseudomonas ; demi-vie ≈ 1 heure, élimination rénale', '4,5 g IV toutes les 6–8 heures', 'Allergie ; interaction : néphrotoxicité accrue avec la vancomycine'],
  ]) + P('Le choix de l’antibiotique suit le foyer et l’épidémiologie locale ; ces doses viennent des AIPS et des monographies des infections virales et du sepsis.', 1, 5))
PTS.append(POINT(11, 'Prise en charge',
 P('La prise en charge stabilise d’abord les fonctions vitales, puis traite la cause. '
   'Elle soulage le malaise sans masquer une maladie grave. '
   'Elle évite les antibiotiques inutiles dans les viroses, selon smarter medicine.', 5, 41) +
 F('11.A Buts : formes compliquées et non compliquées',
   P('Forme compliquée (sepsis, infarctus, trouble métabolique grave, CO) : c’est une urgence, avec antibiotique dans l’heure en cas de choc et transfert en minutes vers la bonne filière.', 5, 9, 14) +
   P('Dans la forme non compliquée, le patient reste en ambulatoire avec des mesures générales : repos, hydratation, éducation aux signes d’alerte.', 41), 'fenetre') +
 F('11.B Moyens',
   F('Mesures générales',
     OL(['Repos adapté et hydratation orale suffisante.',
         'Révision de l’ordonnance et arrêt du médicament en cause (déprescription).',
         'Évacuation et oxygène à 100 % au masque à réservoir si le CO est suspecté.',
         'Consignes écrites de reconsultation (safety-netting).']), 23, 14, 41) +
   MED +
   F('Volets social et professionnel',
     SOCIAL('Un arrêt de travail court suffit souvent pour une virose ; un certificat d’incapacité de travail est requis selon l’employeur.',
            'La conduite automobile est déconseillée en cas de confusion, de malaise avec perte de connaissance ou de traitement sédatif, jusqu’à évaluation de l’aptitude (OAC, annexe 1).',
            'Une cause professionnelle (CO au travail) relève de la LAA.'), 59, 60, 61) +
   F('Situations spéciales',
     TAB(['Situation', 'Adaptation'], [
      ['Grossesse et allaitement', 'Paracétamol à dose minimale efficace ; antibiotique choisi selon l’AIPS ; CO : OHB plus large'],
      ['Enfant', 'Doses calculées au poids ; avis pédiatrique devant une plainte floue'],
      ['Personne âgée', 'Seuil d’hospitalisation plus bas ; dépistage du delirium'],
      ['Insuffisance rénale', 'Doses d’antibiotique adaptées au DFGe'],
      ['Insuffisance hépatique', 'Paracétamol réduit, avis spécialisé'],
     ]), 1, 16), 'fenetre') +
 F('11.C Surveillance et critères de sortie',
   TAB(['Quoi', 'Quand', 'Seuil d’action'], [
    ['Constantes, vigilance', 'Toutes les heures si hospitalisé', 'Aggravation : filière urgente'],
    ['CRP, créatinine, ionogramme', 'Contrôle à 48 heures', 'Hausse : réévaluer la cause'],
    ['Procalcitonine', 'Tous les 2–3 jours sous antibiotique', '< 0,25 µg/L et clinique favorable : arrêt possible'],
    ['Symptômes en ambulatoire', '48–72 heures', 'Pas d’amélioration : reconsulter'],
   ]) + P('Pourquoi surveiller : une virose apparente peut révéler un sepsis ou un infarctus dans les heures suivantes. '
          'La procalcitonine aide à arrêter l’antibiotique : l’exposition baisse de 8,1 à 5,7 jours sans hausse de mortalité.', 117, 5) +
   H4('Critères de sortie, un par un') +
   OL(['Constantes normales et qSOFA à 0.', 'ECG et glycémie normaux si indiqués.', 'Cause bénigne identifiée ou suivi fixé.', 'Consignes de reconsultation comprises.']), 117, 5, 4) +
 F('11.D Pronostic, guérison et recherche 2026',
   P('Le pronostic dépend de la cause : une virose guérit seule en quelques jours, alors qu’une plainte non spécifique aux urgences cache souvent une affection grave. '
     'Les biomarqueurs suPAR et MR-proADM sont étudiés pour le tri ; la précision « supérieure à 90 % » annoncée par l’original n’a pas été retrouvée et a été retirée.', 116), 'fenetre')))

# ---------- 12
PTS.append(POINT(12, 'Prévention',
 P('La prévention primaire repose sur la vaccination contre la grippe et la COVID-19 des personnes vulnérables, selon le Plan de vaccination suisse. '
   'La prévention secondaire révise les ordonnances polymédiquées avec les critères STOPP/START. '
   'L’entretien des chauffages prévient l’intoxication au CO.', 3, 23, 109) +
 F('Niveaux de prévention',
   TAB(['Niveau', 'Mesure', 'Source'], [
    ['Primaire', 'Vaccination annuelle contre la grippe dès 65 ans ou maladie chronique', 'OFSP' + S(3)],
    ['Primaire', 'Contrôle des émissions des chauffages (OPair), détecteur de CO recommandé', 'OFEV' + S(109, 110)],
    ['Secondaire', 'Révision de la polymédication, contrôle en pharmacie', 'STOPP/START, pharmaSuisse' + S(23, 78)],
    ['Tertiaire', 'Prévention du delirium à l’hôpital par des mesures non médicamenteuses', 'Méta-analyse' + S(39)],
   ]))))

# ---------- 13
PTS.append(POINT(13, 'Points clés',
 P('Le médecin traite « je ne me sens pas bien » comme un symptôme d’alarme, surtout chez la personne âgée. '
   'Il mesure toutes les constantes et calcule le qSOFA avant de conclure. '
   'Il fait un ECG et une glycémie devant tout malaise inexpliqué de l’adulte à risque. '
   'Il pense au médicament récent et au CO devant un malaise collectif. '
   'Il ne rassure pas sur une CRP normale au début. '
   'Il donne des consignes écrites de reconsultation.', 116, 4, 36, 14, 119)))

# ---------- 14
PTS.append(POINT(14, 'Pièges d’examen',
 TAB(['Piège', 'Bonne réponse'], [
  ['Conclure à une gastro-entérite chez une diabétique de 68 ans avec malaise, nausée et sueurs, sans ECG.', 'Non : ECG d’abord, l’infarctus peut être sans douleur.'],
  ['Exclure un sepsis sur une CRP normale 3 heures après les frissons.', 'Non : la CRP monte en 6 à 12 heures.'],
  ['Exclure un sepsis sur un qSOFA à 1.', 'Non : le qSOFA n’est pas un test d’exclusion.'],
  ['Prescrire un antibiotique pour une virose.', 'Non : aucun bénéfice, effets indésirables.'],
  ['Exclure le CO sur une SpO2 normale.', 'Non : CO-oxymétrie.'],
  ['Attribuer une confusion à la démence connue.', 'Non : un changement aigu est un delirium jusqu’à preuve du contraire.'],
 ]) + P('Ces pièges entraînent le raisonnement et ne sont pas des questions officielles de l’examen fédéral.', 36, 119, 5, 14, 17)))

# ---------- Bloc 2
L = lambda f, t: f'<a href="{f}">{t}</a>'
DXL = [
 ('DX.1', 'Infections virales aiguës, syndrome grippal', 'LOT_005_DX1_Infections_virales_syndrome_grippal_AUDITÉ.html', PR('≈ 3 611 consultations / 100 000 par saison (Suisse)', 2), 'Première cause probable en premier recours, surtout en hiver.', (2, 63)),
 ('DX.2', 'Malaise iatrogène médicamenteux', 'LOT_005_DX2_Malaise_iatrogene_medicamenteux_AUDITÉ.html', PR('6,5 % des admissions (Royaume-Uni)', 42), 'Cause fréquente chez la personne polymédiquée, réversible à l’arrêt.', (42, 23)),
 ('DX.3', 'Attaque de panique et trouble somatique', 'LOT_005_DX3_Panique_et_trouble_somatique_AUDITÉ.html', PR('troubles anxieux 14 %, somatoformes 4,9 % sur 12 mois (Europe)', 46), 'Fréquent, retenu après exclusion des urgences.', (46, 18)),
 ('DX.4', 'Troubles métaboliques et électrolytiques', 'LOT_005_DX4_Troubles_metaboliques_electrolytiques_AUDITÉ.html', PR('hyponatrémie 15–30 % des hospitalisés', 44), 'Malaise diffus avec confusion ou faiblesse, prouvé par le ionogramme.', (44, 12)),
 ('DX.5', 'Sepsis occulte', 'LOT_005_DX5_Sepsis_occulte_AUDITÉ.html', PR('240 / 100 000 par an (Suisse)', 92), 'Urgence infectieuse qui débute par un malaise avant le choc.', (4, 92)),
 ('DX.6', 'Syndrome coronarien aigu atypique', 'LOT_005_DX6_SCA_atypique_AUDITÉ.html', PR('sans douleur thoracique : 42,0 % des femmes avec infarctus', 36), 'Urgence chez la femme, le diabétique et la personne âgée.', (36, 9)),
 ('DX.7', 'PPR, maladie de Horton, lupus', 'LOT_005_DX7_PPR_Horton_lupus_AUDITÉ.html', PR('PPR 63,9 / 100 000 personnes ≥ 50 ans par an', 100), 'Malaise subaigu avec VS et CRP élevées après 50 ans.', (100, 51)),
 ('DX.8', 'Delirium et glissement', 'LOT_005_DX8_Delirium_et_glissement_AUDITÉ.html', PR('14,6 % des admissions non programmées', 102), 'Présentation fréquente de toute maladie grave chez la personne très âgée.', (102, 17)),
 ('DX.9', 'Endocardite subaiguë', 'LOT_005_DX9_Endocardite_subaigue_AUDITÉ.html', PR('13,8 / 100 000 par an (monde)', 11), 'Malaise « grippal » qui dure des semaines ; hémocultures avant antibiotique.', (11, 37)),
 ('DX.10', 'Intoxication au CO et aux gaz', 'LOT_005_DX10_Intoxication_CO_gaz_AUDITÉ.html', PR('≈ 0,5 consultation / 100 000 par an (Suisse)', 105), 'Grand imitateur hivernal, souvent collectif, potentiellement mortel.', (105, 14)),
]
b15 = (P('Les dix diagnostics suivent l’ordre de l’original, qui les classait par fréquence estimée. '
         'Les pourcentages de l’original (35 %, 18 %… 1 %) n’ont aucune source vérifiable : ils sont remplacés par la fréquence publiée de chaque cause, dans sa propre population.', 99) +
  TAB(['Rang', 'Diagnostic et fréquence', 'Pourquoi il figure dans la liste'],
      [[d, L(f, n) + pr, j + S(*s)] for d, n, f, pr, j, s in DXL]) +
  F('Tableau comparatif : signe, examen, mécanisme, décision',
    TAB(['Diagnostic', 'Signe clé', 'Examen clé', 'Mécanisme', 'Décision immédiate'], [
     ['Virose', 'Myalgies, fièvre, entourage', 'Clinique, PCR', 'Cytokines', 'Symptomatique, consignes'],
     ['Iatrogénie', 'Nouveau médicament', 'Chronologie, ionogramme', 'Effet indésirable', 'Arrêt ou adaptation'],
     ['Panique, somatique', 'Accès brefs, examen normal', 'Exclusion organique', 'Alarme anxieuse', 'Explication, TCC'],
     ['Métabolique', 'Confusion, chutes', 'Ionogramme, glycémie', 'Encéphalopathie', 'Correction prudente'],
     ['Sepsis', 'Tachypnée, confusion', 'Lactate, hémocultures', 'Dysfonction d’organe', 'Antibiotique dans l’heure'],
     ['SCA atypique', 'Sueurs, nausée', 'ECG, troponine', 'Ischémie', 'Filière 144'],
     ['PPR, Horton', 'Raideur, céphalée', 'VS, CRP, Doppler', 'Vascularite', 'Corticoïde rapide si Horton'],
     ['Delirium', 'Attention fluctuante', '4AT', 'Défaillance cérébrale', 'Chercher la cause'],
     ['Endocardite', 'Fièvre, souffle', 'Hémocultures, échocardiographie', 'Infection valvulaire', 'Hôpital'],
     ['CO', 'Malaise collectif', 'HbCO', 'Hypoxie', 'Évacuation, oxygène'],
    ]), 4, 9, 14, 17, 51) +
  F('Algorithme discriminant',
    OL(['Constantes anormales ou qSOFA ≥ 2 ? Sepsis : filière urgente.',
        'Sueurs, nausée, terrain à risque ? ECG et troponine.',
        'Plusieurs malades sous le même toit ? CO.',
        'Confusion aiguë ? Delirium et sa cause.',
        'Nouveau médicament ou trouble du sodium ? Iatrogénie, trouble métabolique.',
        'Après 50 ans, VS élevée ? PPR, Horton ; fièvre prolongée avec souffle ? Endocardite.',
        'Contexte viral et examen normal ? Virose ; accès répétés normaux ? Trouble anxieux.']) +
    P('Plusieurs branches peuvent coexister, surtout chez la personne âgée.', 116, 4, 14)))
PTS.append(f'<section class="point" id="ssp-p15"><h3><strong>Bloc 2 · Liste des dix diagnostics du LOT 5</strong></h3>\n{b15}</section>\n')

CTX = {'_prefixe': 'Devant une sensation de maladie',
 'ecg': 'L’ECG 12 dérivations cherche une ischémie silencieuse chez l’adulte à risque qui « ne se sent pas bien ».',
 'gly': 'La glycémie capillaire écarte d’emblée une hypoglycémie ou une hyperglycémie.',
 'nfs': 'L’hémogramme oriente vers une infection, une anémie ou une hémopathie.',
 'crp': 'Une CRP normale dans les 12 premières heures n’exclut pas une infection.',
 'pct': 'Une procalcitonine < 0,25 µg/L rend une infection bactérienne peu probable.',
 'lact': 'Un lactate ≥ 2 mmol/L impose la filière sepsis.',
 'hemoc': 'Les hémocultures se prélèvent avant l’antibiotique si un sepsis ou une endocardite est possible.',
 'iono': 'Le ionogramme cherche une hyponatrémie ou une dyskaliémie.',
 'creat': 'La créatinine cherche une atteinte rénale et guide les doses.',
 'hep': 'Les transaminases cherchent une atteinte hépatique.',
 'ecbu': 'La bandelette urinaire et l’ECBU cherchent une infection urinaire, fréquente chez la personne âgée.',
 'tropo': 'La troponine ultrasensible s’interprète selon l’algorithme 0 h / 1 h.',
 'vs': 'Une VS élevée après 50 ans fait penser à une PPR ou à une maladie de Horton.',
 'doppler': 'L’échographie Doppler temporale cherche le signe du halo de la maladie de Horton.',
 'radio': 'La radiographie du thorax cherche une pneumonie peu symptomatique.',
 'hbco': 'Une HbCO > 3 % chez le non-fumeur confirme une exposition au CO.',
 'gds': 'La gazométrie mesure le lactate et l’HbCO.',
 'oxy': 'La SpO2 ordinaire reste normale dans l’intoxication au CO.',
 'tsh': 'La TSH écarte une dysthyroïdie devant une asthénie subaiguë.',
 'hcg': 'Le test de grossesse précède l’imagerie et certains traitements.',
}
if __name__ == '__main__':
    produire(M, PTS, SOURCES, CTX)
