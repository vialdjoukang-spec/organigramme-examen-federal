#!/usr/bin/env python3
"""inserer_local.py — enveloppe locale (LOT 5–6) de bibliotheque_examens/inserer_fenetres.py, sans modifier l'outil partagé.
Ajoute : (1) les fragments de bib_extra/ (même format que la bibliothèque commune) ; (2) leurs entrées de lexique.
Usage identique à inserer_fenetres.py ; la variable d'environnement BIB_EXTRA pointe le dossier bib_extra."""
import sys, os, re, json
ROOT = '/workspace/audit_1_10'
sys.path.insert(0, os.path.join(ROOT, 'outils')); sys.path.insert(0, os.path.join(ROOT, 'bibliotheque_examens'))
import examens, inserer_fenetres as IF
EXTRA = os.environ.get('BIB_EXTRA', os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'bib_extra'))
idx = json.load(open(os.path.join(EXTRA, 'index.json'))) if os.path.exists(os.path.join(EXTRA, 'index.json')) else {}
# lexique : les entrées locales passent AVANT le lexique commun (priorité au plus spécifique à longueur égale)
examens.COMP[:0] = [(v['lex'], v['cat'], re.compile(v['regex'], re.I)) for v in idx.values()]
_orig = IF.load_lib
def load_lib():
    lex2key, frag = _orig()
    for k, v in idx.items():
        lex2key[v['lex']] = k
        frag[k] = open(os.path.join(EXTRA, v['fragment'])).read().strip()
    return lex2key, frag
IF.load_lib = load_lib
if __name__ == '__main__':
    IF.main()
