# -*- coding: utf-8 -*-
"""Lance decoupe/examens/style/score (outils partagés, non modifiés) sur corriges/LOT_00X,
en écrivant les résultats dans corriges/LOT_00X/source/work/ (et non dans work/ partagé),
et en traitant le fichier SSP (Appel A audité) comme cours « SSP ».
Usage : audit_local.py LOT_005_AUDITE [--lt 0]"""
import sys, os, runpy, re
BASE = '/workspace/audit_1_10'
sys.path.insert(0, os.path.join(BASE, 'outils'))
import commun
lot = sys.argv[1]
WD = os.path.join(BASE, 'corriges', lot.replace('_AUDITE', ''), 'source', 'work')
def work(l, name):
    os.makedirs(WD, exist_ok=True); return os.path.join(WD, name)
commun.work = work
import decoupe
_cl = decoupe.classify
def classify(name):
    if re.search(r'_ssp_.*_audit[ée](?:_[a-z])?\.html$', name.lower()):
        return 'Appel A'
    return _cl(name)
decoupe.classify = classify
decoupe.work = work
for tool, extra in (('decoupe', []), ('examens', []), ('style', ['--lt', '0']), ('score', [])):
    print('====', tool)
    sys.argv = [tool + '.py', lot] + extra
    if tool == 'decoupe':
        d = decoupe.decoupe(lot)
        import json; json.dump(d, open(work(lot, 'decoupe.json'), 'w'), ensure_ascii=False)
        for c in d['courses']:
            if c['id'] == 'APPEL_A_BLOC2': continue
            miss = [p for p in range(1, 15) if not c['points'][p]['present']]
            print(f"{c['id']:<14} {c['coverage']:>2}/14 manquants={miss} mots={sum(p['words_total'] for p in c['points'].values())}")
    else:
        runpy.run_path(os.path.join(BASE, 'outils', tool + '.py'), run_name='__main__')
