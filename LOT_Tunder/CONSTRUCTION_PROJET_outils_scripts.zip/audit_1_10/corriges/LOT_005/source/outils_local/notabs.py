import json, sys, os
sys.path.insert(0, 'outils'); import examens
W = sys.argv[1]; cid = sys.argv[2]
d = json.load(open(W + '/decoupe.json')); Wn = d['windows']
for c in d['courses']:
    if c['id'] != cid: continue
    for b in c['blocks']:
        if b.get('point') == 'sources': continue
        for (a, e, n, cat, g) in examens.find(b['text']):
            for (sa, se, wid, kind) in b['spans']:
                if sa <= a and e <= se:
                    w = Wn.get(wid, {})
                    if not (w.get('tab_principe') and w.get('tab_interpretation')):
                        print(b.get('point'), n, repr(b['text'][max(0,a-60):e+30]), wid)
                    break
