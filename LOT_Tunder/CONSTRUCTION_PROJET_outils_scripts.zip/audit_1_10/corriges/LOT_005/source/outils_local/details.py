import json, sys, re
W = sys.argv[1]; cid = sys.argv[2]
st = json.load(open(W + '/style.json'))['per_course'][cid]
sc = [c for c in json.load(open(W + '/score.json'))['courses'] if c['id'] == cid][0]
print('à revoir:', [(r['id'], r['critere'], r['note']) for r in sc['rows'] if r['note'] < 2])
print('sigles:', st['sigles_non_developpes']); print('pts trop longs:', st['points_trop_longs'])
print('creuses:', st['ex_creuses']); print('longues:'); [print('  ', x) for x in st['ex_longues']]
