# -*- coding: utf-8 -*-
"""gen_local.py — gen_v7 (partagé, importé tel quel) + pipeline local : inserer_local (bib_extra) → mobile → sigles_local → charte_v7plus."""
import os, sys, subprocess
sys.path.insert(0, '/workspace/audit_1_10/outils')
import gen_v7
from gen_v7 import *
HERE = os.path.dirname(os.path.abspath(__file__))
def pipeline(src_html, out, ctx_path, uid):
    PY, R = gen_v7.PY, gen_v7.ROOT
    r = subprocess.run([PY, f'{HERE}/inserer_local.py', src_html, out, '--ctx', ctx_path, '--portee', 'point',
                        '--max-octets', '100000000', '--prefixe-uid', uid], capture_output=True, text=True)
    if r.returncode: raise SystemExit(r.stderr)
    for tool in (f'{R}/outils/mobile.py', f'{HERE}/sigles_local.py', f'{R}/outils/charte_v7plus.py'):
        r2 = subprocess.run([PY, tool], capture_output=False, text=True) if False else subprocess.run([PY, tool, out], capture_output=True, text=True)
        if r2.returncode: raise SystemExit(r2.stderr)
        if 'sigles' in tool: print('   ', r2.stdout.strip().split(':', 1)[-1][:300])
    return os.path.getsize(out)
gen_v7.pipeline = pipeline
