import sys, re, subprocess
f = sys.argv[1]
for _ in range(30):
    r = subprocess.run([sys.executable, '-m', 'py_compile', f], capture_output=True, text=True)
    if r.returncode == 0: print('OK'); break
    m = re.search(r'line (\d+)', r.stderr)
    if "unmatched ')'" not in r.stderr or not m: print(r.stderr); break
    L = int(m.group(1)); lines = open(f).read().split('\n')
    lines[L-1] = re.sub(r'\)(\s*)$', r'\1', lines[L-1], count=1); open(f, 'w').write('\n'.join(lines)); print('fixed', L)
