#!/usr/bin/env python3
"""sigles_local.py — glossaire des sigles : outil partagé outils/sigles.py + dictionnaire complémentaire local (sigles_extra.py)."""
import sys, os
sys.path.insert(0, '/workspace/audit_1_10/outils'); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sigles
from sigles_extra import DEV_EXTRA, DEV_OVERRIDE
for k, v in DEV_EXTRA.items(): sigles.DEV.setdefault(k, v)
sigles.DEV.update(DEV_OVERRIDE)
if __name__ == '__main__':
    for f in sys.argv[1:]: sigles.main(f)
