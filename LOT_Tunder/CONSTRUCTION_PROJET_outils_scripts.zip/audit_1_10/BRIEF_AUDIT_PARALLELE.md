# Brief commun — audit + correction parallèle des LOTs (Tunder, 24.10.2026 15:39)

## Contexte
- Cours « Flash » pour l'examen fédéral suisse de médecine. Chaque LOT = Appel A (Plan et Liste) + Appel B Parties 1–4 (DX.1–2, DX.3–5, DX.6–7, DX.8–10), fichiers HTML V7.
- Prompt de référence : /workspace/v7.md (14 points V7 §6, §6.1, score §6.3 ≥ 90 %) et /workspace/v7_tunder/PROMPT_ULTIME_PRODUCTION_LOTS_V7-Tunder.md.
- Le modèle validé par l'utilisateur : /workspace/audit_1_10/corriges/LOT_001/ (DX.6 Hyperthyroïdie AUDITÉ a/b, DX.1 SCA). Lire PROGRESS.md et source/ (générateurs gen_<pref>.py qui importent outils/gen_v7.py ; pipeline produire() → inserer_fenetres → mobile → sigles → charte_v7plus ; découpage auto ; verif_v7.py ; score.py ; captures.py).
- Diagnostics par LOT : /workspace/audit_1_10/rapports/LOT_00X_diagnostic.md.

## Ce qu'on produit, par chapitre (DX) et pour l'Appel A
Audit médical (14 points V7) → grande complétion + reformulation CONCISE → audit linguistique → fichier `LOT_00X_<DX>_<Titre>_AUDITÉ.html` (découper en _a/_b seulement si > 200 Ko, à une frontière de point, sans couper de contenu utile). Score cible ≈ 98 %+.

## Charte qualité (exigences de l'utilisateur, non négociables)
1. Pédagogie obsessionnelle : chaque notion (physiopathologie, signe, examen, traitement, molécule, classe) EXPLIQUÉE, le pourquoi avant le quoi ; chaîne logique anatomie → physiologie → physiopathologie → clinique → examens → traitement.
2. Clarté immédiate : phrases verbales, concises, langage simple + terme dédié exact. Test : « Vial la comprend-il d'emblée ? » ; si doute, renforcer. Test final : « si Vial lit ce cours, n'a-t-il aucun souci à l'examen sur ce chapitre ? »
3. Sourçage obsessionnel, inviolable : chaque chiffre, seuil, dose, prévalence, probabilité cité. Ne jamais inventer un chiffre ou une source ; si non sourçable, le dire.
4. Prévalences comparables : pathologie et diagnostics différentiels dans la même unité et population.
5. Probabilité de chaque diagnostic en exposant à droite, en rouge normalisé lisible : `<sup class="proba">≈ 30 %</sup>`, `.proba{color:#C8102E;font-weight:700}` (plus d écarlate #FF2400 ni de halo).
6. Police : `font-family:"Atkinson Hyperlegible",Verdana,Arial,sans-serif` dans le `<style>` interne. Garder les jeux de couleurs.
7. Tout examen complémentaire (biologie +++, fonctionnel, imagerie) cliquable → fenêtre à 2 onglets sans JS : Principe (très bref) / Interprétation (tableau anomalies → signification → diagnostics ; imagerie : lésions attendues dans le contexte et ce qu'il faut en plus). Tout avec concision.
8. Règles V7 : HTML autonome, pas de script, pas d'image, pas de CSS externe, pas de `title=`, tableaux enveloppés (défilement horizontal), marqueur FIN_FICHIER, glossaire des sigles, 90–200 Ko par fichier, mention « contenu produit par IA, non validé cliniquement ».
9. Automatiser tout le mécanique avec des scripts gratuits et déterministes, mais NE JAMAIS sacrifier la qualité médicale ou rédactionnelle pour économiser des tokens.
10. Pour chaque leçon auditée : 3 captures représentatives (chaîne physiopathologique, tableau des différentiels avec probabilités rouges, fenêtre d'examen) dans corriges/LOT_00X/captures/<DX>_1..3.png.

## Travail en parallèle — règles de cohabitation
- Plusieurs auditeurs tournent en même temps (LOT_1 ; LOT_2 ; LOT_3–4 ; LOT_5–6). Écrivez UNIQUEMENT dans corriges/LOT_00X/ de vos LOTs.
- N'éditez PAS les fichiers partagés de outils/ ni de bibliotheque_examens/. Importez-les. Si vous devez modifier un outil, copiez-le dans corriges/LOT_00X/source/outils_local/ et utilisez la copie. Nouveaux fragments d'examens : dans corriges/LOT_00X/source/bib_extra/ (même format que bibliotheque_examens/fragments), chargés en plus de la bibliothèque commune.
- Local uniquement : aucune écriture Drive, aucun push GitHub. Ne JAMAIS ouvrir le dossier Drive 1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB (dossier médical d'un patient).
- Les originaux dans originaux/ ne sont jamais modifiés.

## Livrables par LOT terminé
- corriges/LOT_00X/*_AUDITÉ*.html + .fenetres.json
- corriges/LOT_00X/RAPPORT_AUDIT.md : tableau avant/après par fichier (score V7, examens cliquables, fenêtres, phrases creuses, phrases > 30 mots, sigles non développés, nombre de probabilités rouges), noms et tailles, captures, liste des chiffres/doses/seuils à vérifier par un médecin.
- corriges/LOT_00X/MANIFEST.sha256 (sha256 octet-exact de chaque fichier AUDITÉ).
- Terminez complètement un LOT avant de passer au suivant. Rapportez quels LOTs sont terminés.

## RÈGLE AJOUTÉE 16:30 — CONTRASTE
Contraste naturel obligatoire entre texte et fond (jamais de vert sur vert). Ratio WCAG ≥ 4,5 pour tout texte, sauf `<sup class="proba">` (rouge #C8102E sans halo, ratio 5,5 — normalisé à la demande de l utilisateur 16:31). Contrôle : `./venv/bin/python outils/contraste.py <fichiers.html>` doit lister 0 élément hors .proba.
Captures : plus besoin de les montrer à l'utilisateur ; garder 1 capture de contrôle par DX suffit.

## RÈGLES AJOUTÉES 16:31–16:32 (utilisateur)
- Rouge des probabilités NORMALISÉ : `.proba{color:#C8102E;font-weight:700}` (plus de #FF2400 ni de halo). contraste.py doit rendre 0 élément, .proba compris.
- FOND BLEU CIEL PÂLE : les fonds et bordures clairs verts deviennent bleu ciel pâle (#edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6). C'est fait automatiquement par outils/charte_v7plus.py (déjà mis à jour) : relancez-le sur tous vos fichiers AUDITÉ déjà produits. bibliotheque_examens/fenetres_examens.css est déjà converti.
