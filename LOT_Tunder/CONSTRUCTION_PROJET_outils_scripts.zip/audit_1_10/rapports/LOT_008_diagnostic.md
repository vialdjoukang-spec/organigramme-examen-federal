# LOT_008 — diagnostic automatique (phase 0)

> Généré par `outils/` (scripts déterministes, aucun appel à une IA). Les notes PROXY/HUMAIN sont **indicatives** : elles signalent où regarder ; l’auditeur médical tranche.

## 1. Fichiers analysés

| Type | Fichier | Octets |
|---|---|---|
| Appel A | LOT_8_Appel_A_V6_Ultra_Pedagogique_Plan_et_Liste.html | 16199 |
| Partie 1 | LOT_8_Appel_B_V6_Ultra_Pedagogique_Partie_1_DX.1_a_DX.2.html | 15270 |

## 2. Découpage et couverture des 14 points

| Cours | Titre | Points | Mots | Points absents / quasi vides | Anomalies |
|---|---|---|---|---|---|
| SSP | SSP — LOT_8_Appel_A_V6_Ultra_Pedagogique_Plan_et_Liste.html | 14/14 | 1102 | — | — |
| APPEL_A_BLOC2 | Bloc 2 : Liste DX.1–DX.10 et Algorithme Discriminant | (bloc 2 de l’Appel A : 473 mots, None tableaux) | | | |
| DX.1 | DX.1 — Hypothermie accidentelle (immersion/exposition) Fréqu | 13/14 | 743 | — / quasi vides : 12 | point 12 (Prévention) quasi vide (19 mots) |
| DX.2 | DX.2 — Hypothermie d'avalanche Spécificité montagnarde [S2] | 13/14 | 712 | — / quasi vides : 12 | point 12 (Prévention) quasi vide (21 mots) |

## 3. Examens complémentaires (exigence : cliquable + fenêtre à 2 onglets « Principe » / « Interprétation »)

| Cours | Mentions | Cliquables | Avec 2 onglets | BIO | FONC | IMG | AUTRE |
|---|---|---|---|---|---|---|---|
| SSP | 15 | 0 | 0 | 12 | 2 | 1 | 0 |
| APPEL_A_BLOC2 | 15 | 0 | 0 | 13 | 0 | 2 | 0 |
| DX.1 | 7 | 1 | 0 | 4 | 2 | 1 | 0 |
| DX.2 | 5 | 0 | 0 | 4 | 0 | 1 | 0 |
| **Total** | **42** | **1** (2.4 %) | **0** | | | | |

Fenêtres à 2 onglets détectées dans le LOT : **0**.

**Examens distincts nécessitant une fenêtre Principe / Interprétation** (14) :

| Examen | Cat. | Mentions | Cliquables | Cours |
|---|---|---|---|---|
| Ionogramme / électrolytes | BIO | 12 | 0 | APPEL_A_BLOC2, DX.1, DX.2, SSP |
| Glycémie | BIO | 6 | 0 | APPEL_A_BLOC2, SSP |
| ECG | FONC | 4 | 0 | DX.1, SSP |
| TSH | BIO | 3 | 0 | APPEL_A_BLOC2, SSP |
| Gaz du sang | BIO | 3 | 1 | DX.1, SSP |
| Scanner / TDM | IMG | 3 | 0 | APPEL_A_BLOC2, DX.1, SSP |
| Lactate | BIO | 2 | 0 | APPEL_A_BLOC2, SSP |
| T4 / T3 libres | BIO | 2 | 0 | APPEL_A_BLOC2, SSP |
| Cortisol / test de freinage | BIO | 2 | 0 | APPEL_A_BLOC2, SSP |
| Toxicologie / dosage médicamenteux | BIO | 1 | 0 | APPEL_A_BLOC2 |
| Hémocultures | BIO | 1 | 0 | APPEL_A_BLOC2 |
| Bilan hépatique | BIO | 1 | 0 | APPEL_A_BLOC2 |
| IRM | IMG | 1 | 0 | APPEL_A_BLOC2 |
| Échocardiographie (ETT/ETO) | IMG | 1 | 0 | DX.2 |

## 4. Style (§7)

Phrases nominales : estimation spaCy `fr_core_news_md` + règles ; l’échantillon de contrôle montre encore des faux positifs (verbes non reconnus) → chiffre **majorant**, à relire.

| Cours | Phrases | Nominales (texte/fen./tabl.) | % | > 30 mots | Symboles à la place d’un verbe | Paragraphes sans connecteur | Sigles non développés à la 1re occurrence | Points > 4 phrases dans le texte principal | Phrases creuses / méta |
|---|---|---|---|---|---|---|---|---|---|
| SSP | 85 | 47 (39/3/3) | 55.3 | 4 | 11 | 6 | 17 : ACR, ECG, ECMO, ERC, HOPE, HT, PAS, PR, QRS, QT, RCP, RETENUS, SANS, SGNOR, TDM | 3 (5), 6 (5), 9 (8), 10 (5), 11 (12) | 0 |
| APPEL_A_BLOC2 | 46 | 13 (0/11/2) | 28.3 | 0 | 2 | 0 | 6 : ACTH, ATB, IRM, NaCl, T4L, VAS | — | 0 |
| DX.1 | 49 | 17 (15/2/0) | 34.7 | 2 | 0 | 4 | 7 : ACR, ECLS, HOPE, LUCAS, PaCO2, PaO2, RCP | 9 (6), 11 (9) | 0 |
| DX.2 | 44 | 19 (16/2/1) | 43.2 | 1 | 4 | 3 | 5 : DVA, ERC, EtCO2, ICAR, VAS | 9 (5), 11 (6) | 0 |

**Exemples à relire** (extraits automatiques) :

- [SSP pt 2/main] (45 mots) En Suisse, on recense environ 200 à 300 cas d'hypothermie accidentelle sévère par an, principalement liés aux sports de montagne (avalanches, alpinisme) et à l'exposition urbaine (personnes âgées, éth…
- [SSP pt 4/main] (31 mots) Il faut éliminer en priorité les causes graves : enfouissement sous avalanche (asphyxie vs hypothermie), coma myxœdémateux (urgence endocrinienne mortelle), sepsis sévère (hypothermie au lieu de fièvr…
- [SSP pt None/summary] Monographie du SSP (Symptôme d'appel en 14 points)
- [SSP pt 1/main] Définition et sémantique de la plainte.
- [SSP pt 2/main] Épidémiologie (Suisse, Europe).
- [SSP pt 3/fenetre] Si Avalanche + ACR : K+ > 8 mmol/L = Asphyxie létale (Arrêt réanimation). Si Hypothermie pure sans asphyxie + ACR : K+ < 12 mmol/L = Indication à ECMO/ECLS (Sco
- [APPEL_A_BLOC2 pt None/fenetre] Hypothermie accidentelle (immersion/exposition) : Urgence environnementale majeure.
- [APPEL_A_BLOC2 pt None/fenetre] Hypothermie d'avalanche : Spécificité suisse ;
- [APPEL_A_BLOC2 pt None/fenetre] Défaillance thyroïdienne terminale, HT centrale sans frisson.
- [APPEL_A_BLOC2 pt None/tableau] Déperdition > Production thermique
- [DX.1 pt 8/fenetre] (35 mots) Règle de gestion : On analyse les gaz du sang selon le modèle alpha-stat (mesure lue par la machine chauffée à 37 °C sans correction mathématique pour la T° réelle du patient) pour diriger la ventilat…
- [DX.1 pt 10/main] (37 mots) Si le patient présente un arrêt cardiorespiratoire avec Tcc < 32 °C, l'équipe médicale maintient la RCP en continu (idéalement via un dispositif mécanique de type LUCAS) et organise un transfert direc…
- [DX.1 pt 1/main] Définition et sémantique de la plainte.
- [DX.1 pt 1/fenetre] , conduction (eau, sol froid), radiation et évaporation, dépassant largement ses capacités métaboliques de thermogenèse.
- [DX.1 pt 3/main] Physiopathologie : mécanismes générateurs.
- [DX.2 pt 14/main] (39 mots) Le candidat propose à tort un transfert sous ECMO pour une victime extraite au bout de 90 minutes avec des voies aériennes remplies de glace et un arrêt asystolique (la réponse correcte est l'arrêt im…
- [DX.2 pt 1/main] Définition et sémantique de la plainte.
- [DX.2 pt 3/main] Physiopathologie : mécanismes générateurs.
- [DX.2 pt 5/main] Anamnèse ciblée et drapeaux rouges.
- [DX.2 pt 8/fenetre] Algorithme : Si temps > 35 min ET VAS obstruées (asystolie) → Déclarer décès. Si temps > 35 min ET VAS libres (ou inconnues) → Mesurer K+ → Si K+ > 8 mmol/L → D

**LanguageTool (API publique, échantillon de 9002 caractères du texte principal, 1 requêtes, 0 échecs)** : {'Faute de frappe possible': 54, 'Typographie': 12, 'Punctuation virgule': 2, 'Concordances': 1, 'Miscellaneous': 4, 'Majuscules': 2, 'Confusion d’homonymes et paronymes': 1, 'Grammaire': 1}. La catégorie « faute de frappe » contient surtout des termes médicaux absents du dictionnaire.

- [Typographie] Ne placez pas d’espace avant le point. — « ...C, résultant d'un déséquilibre thermique .  2. Épidémiologie (Suisse, Europe). En ... » → ['.']
- [Punctuation virgule] La virgule doit être omise dans ce contexte. — « ...is en hypothermie profonde), d'engelures, et évaluation du Glasgow (GCS). [S1]  7. A... » → [' et']
- [Concordances] Vérifiez la concordance de « confirmée » avec les noms précédents. — « ...linique et thermométrique : Tcc < 35 °C confirmée par une sonde centrale de basse lecture... » → ['confirmé', 'confirmés']
- [Miscellaneous] Nombre ordinal. Premier : 1ᵉʳ. Première : 1ʳᵉ. Premiers : 1ᵉʳˢ. Premières : 1ʳᵉˢ. — « ...c seuils < 35 °C. Sensibilité 100%. 9.b 1re intention : ECG 12 dérivations (bradyca... » → ['1ʳᵉ']
- [Miscellaneous] Nombre ordinal singulier. Exemples : 2ᵉ, 3ᵉ, 4ᵉ… — « ...sme ou d'avalanche avec contusions. 9.d 2e intention : TSH, T4 libre, Cortisol si ... » → ['2ᵉ']
- [Majuscules] La majuscule ne se place que sur la première lettre du mot en début de phrase. — « ...ypothermique → Conscient et frissonne ? OUI = HT I → Hôpital de proximité, réchauff... » → ['Oui']
- [Majuscules] La majuscule ne se place que sur la première lettre du mot en début de phrase. — « ...al de proximité, réchauffement externe. NON = Évaluation signes vitaux (pouls sur 1... » → ['Non']
- [Typographie] Le trait d’union est employé sans espaces pour former des mots, alors que le tiret est encadré par des espaces et placé entre deux mots distincts. — « ...mmandations suisses (ERC 2021 / SGNOR). A- But : Augmenter la Tcc de 1 à 2 °C par heur... » → ['A-But', 'A – But', 'A But']
- [Typographie] Le trait d’union est employé sans espaces pour former des mots, alors que le tiret est encadré par des espaces et placé entre deux mots distincts. — « ... ventriculaire et restaurer la volémie. B- Moyens et méthodes : - Non pharmacologiques : ... » → ['B-Moyens', 'B – Moyens', 'B Moyens']
- [Typographie] Le trait d’union est employé sans espaces pour former des mots, alors que le tiret est encadré par des espaces et placé entre deux mots distincts. — « ...aurer la volémie. B- Moyens et méthodes : - Non pharmacologiques : Extraction prude... » → [' –', ' —', ': ']

## 5. Score §6.3 (proxy) — LOT : **32.5 %** (seuil de dépôt : ≥ 90 % et zéro erreur critique)

Les erreurs critiques ne sont PAS détectables automatiquement : relecture médicale obligatoire.

| Cours | Score | Hors critères HUMAIN | Critères < 2 |
|---|---|---|---|
| SSP | 36.2 % | 38.7 % | 1.c 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.c 9.d 9.e 9.f 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 11.j 12.a 13.b 14.a |
| DX.1 | 32.5 % | 35.5 % | 1.c 2.a 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.c 9.d 9.e 9.f 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 11.j 12.a 13.b 14.a |
| DX.2 | 28.8 % | 33.9 % | 1.c 2.a 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.c 9.d 9.e 9.f 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 11.j 12.a 13.b |

Légende des critères :

- **1.a** (AUTO) Texte principal en 1 à 4 phrases
- **1.b** (PROXY) Définition issue d’une source médicale (référence [Sx])
- **1.c** (HUMAIN) Distinction avec les notions voisines
- **2.a** (PROXY) Données suisses chiffrées (OFS/OFSP/Obsan…)
- **2.b** (PROXY) Données européennes / internationales
- **2.c** (HUMAIN) Facteurs de risque / terrain / pronostic chiffré
- **3.a** (PROXY) Tableau lésion → exploration → cible thérapeutique
- **3.b** (HUMAIN) Chaque signe relié à son mécanisme
- **4.a** (PROXY) Priorités : urgence d’abord, puis étapes ordonnées
- **5.a** (PROXY) Questions d’anamnèse ciblées
- **5.b** (HUMAIN) Drapeaux rouges complets et actionnables
- **6.a** (PROXY) Le normal avant le pathologique
- **6.b** (HUMAIN) Technique de recherche + valeur diagnostique de chaque signe
- **7.a** (PROXY) Syndromes énumérés
- **7.b** (PROXY) Signes fonctionnels / signes physiques séparés
- **7.c** (HUMAIN) Chaque signe défini en fenêtre, avec geste et mécanisme
- **8.a** (PROXY) Critères diagnostiques : société savante + année + seuils
- **8.b** (PROXY) Ce qui ne suffit pas à poser le diagnostic
- **9.a** (PROXY) Gold standard dit (existe/n’existe pas) avec Se/Spé/seuil
- **9.b** (PROXY) 1re / 2e intention et critère de passage
- **9.c** (PROXY) Prescription : indication, moment, préparation
- **9.d** (PROXY) Tableau d’interprétation normal (SI) | seuil | signification | conduite
- **9.e** (PROXY) Cas de figure : positif / négatif / limite / discordant
- **9.f** (PROXY) Alternatives : grossesse, enfant, DFGe < 30, iode, pacemaker
- **10.a** (PROXY) Arbre : chaque embranchement → décision
- **11.a** (PROXY) But du traitement chiffré
- **11.b** (PROXY) Ordre de la prise en charge et pourquoi (A→D)
- **11.c** (HUMAIN) Formes compliquées : urgence + chronologie (fenêtre)
- **11.d** (PROXY) Formes non compliquées : mesures générales puis ordre
- **11.e** (HUMAIN) Médicament : classe, PK/PD, EI, ®, dose AIPS, durée, CI, interactions
- **11.f** (PROXY) Traitements non médicamenteux
- **11.g** (PROXY) Volets social / professionnel (LAMal, LAA, LAI, conduite, arrêt)
- **11.h** (PROXY) Situations spéciales : grossesse/allaitement, âgé, enfant, IH, IR (DFGe)
- **11.i** (PROXY) Surveillance : quoi, quand, pourquoi, seuils d’arrêt
- **11.j** (PROXY) Critères de sortie un par un
- **11.k** (PROXY) Pronostic / guérison / recherche 2026
- **12.a** (PROXY) Prévention primaire / secondaire / tertiaire, reco suisses
- **13.a** (AUTO) Points clés : 3 à 6 phrases
- **13.b** (HUMAIN) Contenu : ce qu’un médecin ne doit jamais oublier
- **14.a** (PROXY) Pièges réels de l’examen, chacun avec sa bonne réponse

## 6. Contrôles techniques §10 / §16 par fichier

| Fichier | Octets | FIN_FICHIER | 90–200 Ko | title= | Tableaux (enveloppés) | Lignes > 3000 | script/img/CSS ext. | `<details>` | Sources | Mention « non validé » | Export Google Docs |
|---|---|---|---|---|---|---|---|---|---|---|---|
| LOT_8_Appel_A_V6_Ultra_Pedagogique_Plan_et_Liste.html | 16199 | oui | non | 0 | 2 (2) | 0 | 0/0/0 | 5 | oui | oui | non |
| LOT_8_Appel_B_Partie_2_DX.3_a_DX.5_A_REDIGER.html | 963 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| LOT_8_Appel_B_Partie_3_DX.6_a_DX.7_A_REDIGER.html | 963 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| LOT_8_Appel_B_Partie_4_DX.8_a_DX.10_A_REDIGER.html | 965 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| LOT_8_Appel_B_V6_Ultra_Pedagogique_Partie_1_DX.1_a_DX.2.html | 15270 | oui | non | 0 | 2 (2) | 0 | 0/0/0 | 6 | oui | oui | non |
