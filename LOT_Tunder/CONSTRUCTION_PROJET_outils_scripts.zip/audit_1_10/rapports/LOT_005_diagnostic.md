# LOT_005 — diagnostic automatique (phase 0)

> Généré par `outils/` (scripts déterministes, aucun appel à une IA). Les notes PROXY/HUMAIN sont **indicatives** : elles signalent où regarder ; l’auditeur médical tranche.

## 1. Fichiers analysés

| Type | Fichier | Octets |
|---|---|---|
| Appel A | LOT_5_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.gdoc_export.html | 94897 |
| Partie 1 | LOT_5_Appel_B_V5_Ultra_Pedagogique_Partie_1_DX.1_a_DX.2.gdoc_export.html | 138815 |
| Partie 2 | LOT_5_Appel_B_V5_Ultra_Pedagogique_Partie_2_DX.3_a_DX.5.gdoc_export.html | 192929 |
| Partie 3 | LOT_5_Appel_B_V5_Ultra_Pedagogique_Partie_3_DX.6_a_DX.7.gdoc_export.html | 129613 |
| Partie 4 | LOT_5_Appel_B_V5_Ultra_Pedagogique_Partie_4_DX.8_a_DX.10.gdoc_export.html | 157008 |

## 2. Découpage et couverture des 14 points

| Cours | Titre | Points | Mots | Points absents / quasi vides | Anomalies |
|---|---|---|---|---|---|
| SSP | SSP — LOT_5_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.gdoc_ | 14/14 | 2460 | — | — |
| DX.1 | D5.1 — Phase prodromique et d'état des infections virales ai | 14/14 | 1837 | — | — |
| DX.2 | D5.2 — Effets indésirables médicamenteux, polymédication et  | 14/14 | 1781 | — | — |
| DX.3 | D5.3 — Troubles anxieux aigus (Attaque de panique) et Troubl | 14/14 | 1205 | — | — |
| DX.4 | D5.4 — Troubles métaboliques et hydro-électrolytiques aigus  | 14/14 | 1432 | — | — |
| DX.5 | D5.5 — Infections bactériennes invasives débutantes et Sepsi | 14/14 | 1538 | — | — |
| DX.6 | D5.6 — Syndrome coronarien aigu à présentation atypique (Équ | 14/14 | 3067 | — | point 1 : 2 titres concurrents → 1. Définition et sémantique de la plainte. | 1. Définition et sémantique de la plainte.; point 2 : 2 titres concurrents → 2. Épidémiologie (Suisse, Europe). | 2. Épidémiologie (Suisse, Europe).; point 3 : 2 titres concurrents → 3. Physiopathologie : mécanismes généra |
| DX.8 | D5.8 — Décompensation gériatrique aiguë (« Glissement / Fail | 13/14 | 1302 | — / quasi vides : 12 | point 12 (Prévention) quasi vide (22 mots) |
| DX.9 | D5.9 — Endocardite infectieuse subaiguë (Maladie d'Osler) [1 | 14/14 | 1493 | — | — |
| DX.10 | D5.10 — Intoxication occulte aux gaz et toxiques environneme | 14/14 | 1432 | — | — |

## 3. Examens complémentaires (exigence : cliquable + fenêtre à 2 onglets « Principe » / « Interprétation »)

| Cours | Mentions | Cliquables | Avec 2 onglets | BIO | FONC | IMG | AUTRE |
|---|---|---|---|---|---|---|---|
| SSP | 50 | 0 | 0 | 42 | 4 | 4 | 0 |
| DX.1 | 11 | 1 | 0 | 8 | 1 | 2 | 0 |
| DX.2 | 23 | 0 | 0 | 12 | 8 | 2 | 1 |
| DX.3 | 19 | 0 | 0 | 12 | 7 | 0 | 0 |
| DX.4 | 76 | 1 | 0 | 72 | 4 | 0 | 0 |
| DX.5 | 33 | 0 | 0 | 26 | 0 | 7 | 0 |
| DX.6 | 75 | 0 | 0 | 39 | 11 | 23 | 2 |
| DX.8 | 13 | 0 | 0 | 10 | 3 | 0 | 0 |
| DX.9 | 53 | 0 | 0 | 17 | 1 | 35 | 0 |
| DX.10 | 19 | 0 | 0 | 9 | 7 | 2 | 1 |
| **Total** | **372** | **2** (0.5 %) | **0** | | | | |

Fenêtres à 2 onglets détectées dans le LOT : **0**.

**Examens distincts nécessitant une fenêtre Principe / Interprétation** (39) :

| Examen | Cat. | Mentions | Cliquables | Cours |
|---|---|---|---|---|
| Ionogramme / électrolytes | BIO | 82 | 1 | DX.2, DX.3, DX.4, DX.5, DX.8, DX.9, SSP |
| ECG | FONC | 38 | 0 | DX.10, DX.2, DX.3, DX.4, DX.6, DX.8, DX.9, SSP |
| Échocardiographie (ETT/ETO) | IMG | 32 | 0 | DX.5, DX.6, DX.9 |
| CRP | BIO | 21 | 0 | DX.1, DX.5, DX.6, DX.8, DX.9, SSP |
| Hémocultures | BIO | 20 | 0 | DX.1, DX.5, DX.9, SSP |
| Lactate | BIO | 17 | 0 | DX.10, DX.5, SSP |
| Glycémie | BIO | 16 | 0 | DX.3, DX.4, DX.6, DX.8, SSP |
| Créatinine / DFGe | BIO | 15 | 0 | DX.10, DX.2, DX.4, DX.5, DX.6, DX.8, DX.9, SSP |
| Vitesse de sédimentation (VS) | BIO | 14 | 0 | DX.6, DX.9, SSP |
| Troponine | BIO | 12 | 0 | DX.10, DX.6, SSP |
| Scanner / TDM | IMG | 11 | 0 | DX.2, DX.5, DX.6, DX.9 |
| Échographie (générique) | IMG | 10 | 0 | DX.1, DX.5, DX.6, DX.9, SSP |
| Gaz du sang | BIO | 8 | 0 | DX.10, DX.4, DX.5, SSP |
| Procalcitonine (PCT) | BIO | 7 | 0 | DX.1, DX.5, SSP |
| Oxymétrie / saturation | FONC | 6 | 0 | DX.1, DX.10 |
| TEP / PET-scan | IMG | 6 | 0 | DX.10, DX.6, DX.9 |
| Bilan hépatique | BIO | 5 | 0 | DX.2, DX.5, DX.6, SSP |
| ECBU / analyse d’urine | BIO | 5 | 0 | DX.5, DX.8, SSP |
| Doppler | IMG | 5 | 0 | DX.6, SSP |
| PCR (amplification génique) | BIO | 5 | 1 | DX.1, DX.5 |
| Radiographie | IMG | 4 | 0 | DX.1, DX.5, DX.6, SSP |
| TSH | BIO | 4 | 0 | DX.3, DX.4 |
| Coronarographie / angiographie | IMG | 3 | 0 | DX.6 |
| Biopsie / histologie | AUTRE | 3 | 0 | DX.10, DX.6 |
| IRM | IMG | 3 | 0 | DX.10, DX.6 |
| NFS / hémogramme | BIO | 2 | 0 | DX.6, SSP |
| CK | BIO | 2 | 0 | DX.2 |
| Bilan phosphocalcique / PTH | BIO | 2 | 0 | DX.4 |
| Bilan lipidique | BIO | 2 | 0 | DX.6 |
| HbA1c | BIO | 2 | 0 | DX.6 |
| EEG | FONC | 2 | 0 | DX.8 |
| Examen microbiologique des expectorations (BAAR, culture, PCR mycobactéries) | BIO | 1 | 0 | DX.1 |
| Tests génétiques | AUTRE | 1 | 0 | DX.2 |
| T4 / T3 libres | BIO | 1 | 0 | DX.3 |
| Métanéphrines | BIO | 1 | 0 | DX.3 |
| Cortisol / test de freinage | BIO | 1 | 0 | DX.4 |
| Lymphocytes CD4 | BIO | 1 | 0 | DX.6 |
| Coagulation (TP/INR/TCA/fibrinogène) | BIO | 1 | 0 | DX.6 |
| Ostéodensitométrie | IMG | 1 | 0 | DX.6 |

## 4. Style (§7)

Phrases nominales : estimation spaCy `fr_core_news_md` + règles ; l’échantillon de contrôle montre encore des faux positifs (verbes non reconnus) → chiffre **majorant**, à relire.

| Cours | Phrases | Nominales (texte/fen./tabl.) | % | > 30 mots | Symboles à la place d’un verbe | Paragraphes sans connecteur | Sigles non développés à la 1re occurrence | Points > 4 phrases dans le texte principal | Phrases creuses / méta |
|---|---|---|---|---|---|---|---|---|---|
| SSP | 109 | 56 (51/0/5) | 51.4 | 26 | 13 | 5 | 48 : ALAT, ANRESIS, ASAT, BLOC, CIM, CO, CRP, CoV, DAMPs, DE, DES, DIAGNOSTICS, DSM, DU, ECG | 3 (15), 9 (13), 11 (18), 14 (19) | 0 |
| DX.1 | 78 | 34 (32/0/2) | 43.6 | 19 | 17 | 3 | 29 : AINS, ARN, ARNm, BPCO, COVID, CRB, CRP, CURB, CoV, FC, H3N2, IFN, IL, ILI, IRF | 3 (14), 11 (25) | 0 |
| DX.2 | 83 | 41 (36/0/5) | 49.4 | 18 | 11 | 6 | 29 : ALAT, CYP2C19, CYP2C9, CYP2D6, CYP3A4, DFG, DII, DILI, ECG, ElViS, FINISH, GGT, HLA, HUG, IPP | 3 (20), 9 (11), 11 (15) | 0 |
| DX.3 | 61 | 32 (30/0/2) | 52.5 | 11 | 1 | 4 | 7 : CIM, DSM, ECG, GAD, NMDA, OFSP, TSH | 3 (9), 11 (21) | 0 |
| DX.4 | 73 | 45 (38/0/7) | 61.6 | 13 | 4 | 8 | 16 : ADH, AINS, ARA, AVP, FV, IEC, NaCl, OH, PTH, PTHrP, QRS, QT, SIADH, SSED, SSN | 3 (9), 10 (5), 11 (20) | 0 |
| DX.5 | 68 | 37 (34/0/3) | 54.4 | 15 | 12 | 5 | 19 : ALI, ANRESIS, CIVD, CRP, CT, ECBU, ETO, ETT, GCS, IL, IVSE, LPS, NO, PCR, SDRA | 3 (18), 9 (5), 11 (18) | 0 |
| DX.6 | 160 | 88 (76/0/12) | 55.0 | 23 | 6 | 12 | 25 : ACG, ACR, ATP, CD4, CHUV, CRP, CT, ECG, EULAR, FDG, HbA1c, IL, IRM, IVA, LDL | 3 (40), 5 (5), 7 (6), 9 (8), 11 (34) | 0 |
| DX.8 | 64 | 34 (30/0/4) | 53.1 | 12 | 3 | 4 | 10 : CRP, CT, DELIRIUM, DSM, ECG, EEG, FSC, IM, IQCODE, SPSG | 3 (17), 11 (13) | 0 |
| DX.9 | 69 | 37 (32/0/5) | 53.6 | 13 | 3 | 6 | 10 : CMI, ESC, ETO, ETT, FDG, HACEK, OAP, PET, SSI, VS | 3 (15), 9 (6), 11 (15) | 0 |
| DX.10 | 64 | 35 (32/0/3) | 54.7 | 9 | 1 | 1 | 7 : CHUV, FiO, HbCO, IRM, OHB, TEP, USZ | 3 (21), 11 (14) | 0 |

**Exemples à relire** (extraits automatiques) :

- [SSP pt 1/main] (53 mots) La sensation de maladie (feeling of illness ou malaise général) désigne une perception intéroceptive subjective, diffuse et inconfortable d'altération de l'état de santé habituel (« ne pas se sentir b…
- [SSP pt 2/main] (49 mots) En médecine de premier recours et dans les services d'urgences en Suisse, la plainte non spécifique de sensation de maladie ou d'altération aiguë de l'état général motive 8 à 15 % des consultations (a…
- [SSP pt None/main] Sensation de maladie, Malaise général (SSP G5 — Feeling of illness)
- [SSP pt None/main] PLAN MONOGRAPHIQUE DU SSP PRINCIPAL (G5 — SENSATION DE MALADIE, MALAISE)
- [SSP pt 2/main] SSMIG] et la Revue Médicale Suisse), avec une étiologie infectieuse bénigne dominante chez le sujet jeune, mais un taux d'hospitalisation et de pathologie grave dépassant
- [SSP pt 3/main] Score qSOFA (0 à 3 points) = [FR ≥ 22/min (1 pt)] + [GCS < 15 (1 pt)] + [PAS ≤ 100 mmHg (1 pt)]
- [DX.1 pt 1/main] (52 mots) Le syndrome prodromique et grippal viral aigu (Influenza-Like Illness, ILI) désigne l'irruption soudaine d'une sensation de malaise général intense accompagnée de frissons, de myalgies, de céphalées e…
- [DX.1 pt 2/main] (43 mots) , les infections virales respiratoires aiguës motivent chaque hiver entre 150 000 et 350 000 consultations médicales en Suisse (représentant 35 % de toutes les plaintes aiguës de « sensation d'être ma…
- [DX.1 pt 2/main] Selon le système de surveillance national suisse
- [DX.1 pt 2/main] Sentinella piloté par l'Office Fédéral de la Santé Publique (OFSP)
- [DX.1 pt 3/main] , provoquant une sécrétion massive d'Interférons de type I (IFN-α et IFN
- [DX.1 pt 3/main] Indice de Choc (SI) = Fréquence Cardiaque (bpm) / Pression Artérielle Systolique (mmHg) [Norme : 0,5 à 0,7]
- [DX.2 pt 1/main] (45 mots) Le malaise général d'origine iatrogène médicamenteuse regroupe l'ensemble des sensations subjectives d'inconfort systémique, d'ébriété, de faiblesse, de nausées ou d'instabilité neurovégétative induit…
- [DX.2 pt 2/main] (55 mots) En Suisse, les effets indésirables médicamenteux (EIM) représentent 18 % des plaintes de malaise non spécifique en ambulatoire et sont directement responsables de 5 à 10 % de toutes les admissions hos…
- [DX.2 pt 3/main] -bloquants prostatiques ou les neuroleptiques ;
- [DX.2 pt 3/main] hyponatrémie hypo-osmolaire par SIADH sous ISRS/carbamazépine ou par déplétion sous diurétiques thiazidiques) ; (2) la toxicité neuro-réceptorielle centrale (charge antic
- [DX.2 pt 3/main] hyperstimulation sérotoninergique des récepteurs et ;
- [DX.2 pt 3/main] Intervalle RR (secondes) = 60 / Fréquence Cardiaque (bpm)
- [DX.3 pt 1/main] (44 mots) Les troubles anxieux aigus et somatoformes regroupent d'une part l'attaque de panique (survenue paroxystique imprévisible d'une peur intense avec symptômes somatiques cataclysmiques mimant une urgence…
- [DX.3 pt 2/main] (55 mots) Selon les enquêtes de santé publique de l'OFSP et de la Société Suisse de Psychiatrie et Psychothérapie (SSPP), les troubles anxieux touchent environ 15 % de la population suisse au cours de leur vie,…
- [DX.3 pt 3/main] 🔍 Fenêtre Interactive Bio-Mathématique 3.3 : Échelle d'Anxiété GAD-7
- [DX.3 pt 3/main] & Critères de l'Attaque de Panique (DSM-5)
- [DX.3 pt 3/main] Explicitation des variables et Formules :
- [DX.3 pt 3/main] Score GAD-7 (0 à 21 points) = Somme des items (1 à 7)
- [DX.4 pt 1/main] (33 mots) constituent des urgences médicales redoutables se manifestant initialement par une sensation de malaise général insidieux, une faiblesse neuromusculaire, des nausées ou une léthargie, avant de bascule…
- [DX.4 pt 2/main] (34 mots) compliquent 10 à 25 % des hospitalisations en médecine interne générale en Suisse (l'hyponatrémie étant le désordre ionique le plus fréquent, touchant 15 à 30 % des patients gériatriques polymédiqués …
- [DX.4 pt 1/main] Les troubles métaboliques et hydro
- [DX.4 pt 1/main] hyponatrémie, dyskaliémies, hypercalcémie, acidose ou hyperglycémie majeure
- [DX.4 pt 2/main] Les désordres hydro
- [DX.4 pt 3/main] Natrémie corrigée (mmol/L) = mesurée +
- [DX.5 pt 1/main] (57 mots) Le sepsis occulte et l'infection bactérienne invasive débutante se caractérisent par une sensation de malaise général inexpliqué, de fatigue ou de faiblesse, qui constitue souvent la seule et unique m…
- [DX.5 pt 3/main] (53 mots) Cet orage cytokinique (IL-1, IL-6, TNF-α, interféron-γ) déclenche une production massive de monoxyde d'azote () par la NO-synthase inductible (iNOS), provoquant une **vasoplégie artériolaire systémiqu…
- [DX.5 pt 3/main] La pénétration intravasculaire ou tissulaire de bactéries (bactéries Gram-négatives via les lipopolysaccharides [LPS] / endotoxines ;
- [DX.5 pt 3/main] via les peptidoglycanes et acides téichoïques)
- [DX.5 pt 3/main] Critères Sepsis-3 & Score SOFA (Sequential Organ Failure Assessment)
- [DX.5 pt 3/main] Sepsis = Infection suspectée/prouvée + Variation du score SOFA ≥ 2 points.
- [DX.6 pt 1/main] (53 mots) Le syndrome coronarien aigu (SCA) à présentation atypique (ou équivalent angineux) désigne un infarctus du myocarde ou une ischémie myocardique critique dont l'expression clinique ne prend pas la form…
- [DX.6 pt 2/main] (65 mots) Selon les registres de la Société Suisse de Cardiologie (SSC) et de l'European Society of Cardiology (ESC), près de 20 à 30 % de l'ensemble des infarctus du myocarde aigus se manifestent de manière at…
- [DX.6 pt 3/main] L'occlusion brutale ou critique d'une artère coronaire par rupture d'une plaque d'athérome vulnérable et formation d'un thrombus plaquettaire interrompt le flux sanguin m
- [DX.6 pt 3/main] -Jarisch ou des afférences vagales viscérales).
- [DX.6 pt 3/main] : Algorithme ESC 0h/1h pour la Troponine Cardiaque
- [DX.6 pt 3/main] • Exclusion (Rule-out) : hs-cTn à OU ( et faible) → Exclusion du SCA.
- [DX.8 pt 1/main] (62 mots) La décompensation gériatrique aiguë (connue sous le terme de « syndrome de glissement » ou failure to thrive) et l'état confusionnel aigu hypoactif (delirium) désignent une altération brutale et fluct…
- [DX.8 pt 2/main] (50 mots) En Suisse, le delirium et le syndrome de glissement compliquent 20 à 30 % des hospitalisations de patients gériatriques de plus de 80 ans (et jusqu'à 50 % en milieu chirurgical ou de soins intensifs),…
- [DX.8 pt 3/main] Grille de Dépistage CAM (Confusion Assessment Method) & Échelle 4AT du Delirium
- [DX.8 pt 3/main] Explicitation des variables et Formules :
- [DX.8 pt 3/main] Altération du niveau de conscience.
- [DX.8 pt 3/main] Exemple clinique : Patiente de 87 ans hospitalisée pour « malaise général et apathie » : somnolente par moments (1 pt), incapable de réciter les mois à l'envers
- [DX.9 pt 1/main] (40 mots) L'endocardite infectieuse subaiguë (Maladie d'Osler) se manifeste par un tableau trompeur et insidieux de malaise général prolongé, de fébricule vespéral, d'asthénie et d'altération pondérale, simulan…
- [DX.9 pt 2/main] (39 mots) En Suisse, l'endocardite infectieuse touche environ 600 à 800 patients par an (incidence de 7 à 10 cas pour 100 000 habitants, en augmentation chez les patients âgés porteurs de prothèses valvulaires,…
- [DX.9 pt 3/main] Critères de Duke Modifiés (ESC 2023/2025) & Scores Pronostiques d'Eichhorn
- [DX.9 pt 3/main] Explicitation des variables et Formules :
- [DX.9 pt 3/main] Hémocultures positives caractéristiques (germes typiques sur 2 prélèvements distincts) ; (2) Preuve d'atteinte endocardique à l'imagerie (Végétation, abcès, nouvelle régu
- [DX.9 pt 3/main] Diagnostic Certain = 2 critères majeurs OU 1 critère majeur + 3 critères mineurs OU 5 critères mineurs.
- [DX.10 pt 1/main] (53 mots) L'intoxication occulte au monoxyde de carbone (CO) et aux gaz environnementaux se manifeste par un syndrome pseudo-grippal trompeur de malaise général, de céphalées frontales, de vertiges et de nausée…
- [DX.10 pt 2/main] (54 mots) En Suisse, Tox Info Suisse (numéro d'urgence 145) enregistre chaque année entre 300 et 400 appels pour exposition au monoxyde de carbone, provoquant des intoxications symptomatiques chez plus de 500 à…
- [DX.10 pt 3/main] Cinétique de la Demi-vie de la Carboxyhémoglobine () & Seuils de Gravité Toxique
- [DX.10 pt 3/main] Explicitation des variables et Formules :
- [DX.10 pt 3/main] - Oxygénothérapie normobare à haut débit ($100\ \%$ au masque à réservoir, ) : Demi-vie réduite à 60 à 90 minutes.
- [DX.10 pt 3/main] 1. Explicitation des variables et Formules : L'élimination pulmonaire de la carboxyhémoglobine obéit à une cinétique de premier ordre dont la demi-vie () dépend

**LanguageTool (API publique, échantillon de 9002 caractères du texte principal, 1 requêtes, 0 échecs)** : {'Faute de frappe possible': 42, 'Tours critiqués divers (barbarismes, impropriétés, solécismes, etc.)': 1, 'style rules': 2, 'Typographie': 5, 'Miscellaneous': 1, 'Punctuation virgule': 1, 'Concordances': 4, 'Élision': 2, 'Ponctuation': 1, 'Punctuation point': 1}. La catégorie « faute de frappe » contient surtout des termes médicaux absents du dictionnaire.

- [Tours critiqués divers (barbarismes, impropriétés, solécismes, etc.)] Cet adjectif précède généralement le nom. — « ...e infectieuse bénigne dominante chez le sujet jeune, mais un taux d'hospitalisation et de p... » → ['jeune sujet']
- [style rules] Les chiffres s’écrivent généralement en lettres. — « ...rgan Failure Assessment) qui additionne 3 variables cliniques binaires (cotées 0 ... » → ['trois']
- [Typographie] Ne placez pas d’espace avant le point. — « ...gow ; (3) Pression Artérielle Systolique . Parallèlement, la Pression Artérielle M... » → ['.']
- [Miscellaneous] Pas d’espace après ce signe. — « ...ssion Artérielle Moyenne : PAM (mmHg) = [ PAS + (2 × PAD) ] / 3 = PAD + 1/3 (PAS -... » → ['[']
- [Punctuation virgule] Une virgule est conseillée dans ce contexte. — « ... 52)] / 3 = 198 / 3 = 66 mmHg (≥ 65 mmHg mais limite) → Alerte Sepsis immédiate, prél... » → [', mais']
- [Concordances] Vérifiez la concordance de « immédiate » avec les noms précédents. — « ...(≥ 65 mmHg mais limite) → Alerte Sepsis immédiate, prélèvement de lactatémie et hémocultu... » → ['immédiat']
- [Élision] « de Horton » s’élide en « d’Horton ». — « ...ctivite, vascularite à cellules géantes de Horton, ou trouble somatoforme/attaque de pani... » → ["d'Horton"]
- [Typographie] Insérez une espace après la virgule et non avant. — « ... drapeaux rouges absolus sont : un score , des frissons solennels secouant le lit ... » → [',']
- [style rules] Il peut être plus approprié d’écrire ce chiffre en lettres afin d’assurer la cohérence de la phrase. — « ...out, fréquence respiratoire comptée sur 1 minute, saturation pulsée en oxygène et... » → ['une']
- [Concordances] Vérifiez la concordance de « points » avec les noms précédents. — « ...es Sepsis-3 (augmentation du score SOFA points liée à une infection), critères de la 4... » → ['point', 'pointe']
- [Typographie] Faute de typographie. — « ...s liée à une infection), critères de la 4ème Définition Universelle de l'Infarctus d... » → ['4ᵉ']

## 5. Score §6.3 (proxy) — LOT : **32.4 %** (seuil de dépôt : ≥ 90 % et zéro erreur critique)

Les erreurs critiques ne sont PAS détectables automatiquement : relecture médicale obligatoire.

| Cours | Score | Hors critères HUMAIN | Critères < 2 |
|---|---|---|---|
| SSP | 37.5 % | 38.7 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 11.b 11.c 11.d 11.e 11.g 11.h 12.a 13.a 13.b 14.a |
| DX.1 | 33.8 % | 33.9 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 6.a 6.b 7.b 7.c 8.a 8.b 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.2 | 35.0 % | 33.9 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.j 12.a 13.a 13.b 14.a |
| DX.3 | 33.8 % | 35.5 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 5.b 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.4 | 30.0 % | 29.0 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.5 | 27.5 % | 29.0 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.6 | 41.2 % | 38.7 % | 1.b 1.c 2.c 3.a 4.a 5.a 6.a 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.8 | 27.5 % | 29.0 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.9 | 31.2 % | 32.3 % | 1.b 1.c 2.a 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.10 | 26.2 % | 27.4 % | 1.b 1.c 2.a 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |

Légende des critères :

- **1.a** (AUTO) Texte principal en 1 à 4 phrases
- **1.b** (PROXY) Définition issue d’une source médicale (référence [Sx])
- **1.c** (HUMAIN) Distinction avec les notions voisines
- **2.a** (PROXY) Données suisses chiffrées (OFS/OFSP/Obsan…)
- **2.b** (PROXY) Données européennes / internationales
- **2.c** (HUMAIN) Facteurs de risque / terrain / pronostic chiffré
- **3.a** (PROXY) Tableau lésion → exploration → cible thérapeutique
- **3.b** (HUMAIN) Chaque signe relié à son mécanisme
- **4.a** (PROXY) Priorités : urgence d’abord, puis étapes ordonnées
- **5.a** (PROXY) Questions d’anamnèse ciblées
- **5.b** (HUMAIN) Drapeaux rouges complets et actionnables
- **6.a** (PROXY) Le normal avant le pathologique
- **6.b** (HUMAIN) Technique de recherche + valeur diagnostique de chaque signe
- **7.a** (PROXY) Syndromes énumérés
- **7.b** (PROXY) Signes fonctionnels / signes physiques séparés
- **7.c** (HUMAIN) Chaque signe défini en fenêtre, avec geste et mécanisme
- **8.a** (PROXY) Critères diagnostiques : société savante + année + seuils
- **8.b** (PROXY) Ce qui ne suffit pas à poser le diagnostic
- **9.a** (PROXY) Gold standard dit (existe/n’existe pas) avec Se/Spé/seuil
- **9.b** (PROXY) 1re / 2e intention et critère de passage
- **9.c** (PROXY) Prescription : indication, moment, préparation
- **9.d** (PROXY) Tableau d’interprétation normal (SI) | seuil | signification | conduite
- **9.e** (PROXY) Cas de figure : positif / négatif / limite / discordant
- **9.f** (PROXY) Alternatives : grossesse, enfant, DFGe < 30, iode, pacemaker
- **10.a** (PROXY) Arbre : chaque embranchement → décision
- **11.a** (PROXY) But du traitement chiffré
- **11.b** (PROXY) Ordre de la prise en charge et pourquoi (A→D)
- **11.c** (HUMAIN) Formes compliquées : urgence + chronologie (fenêtre)
- **11.d** (PROXY) Formes non compliquées : mesures générales puis ordre
- **11.e** (HUMAIN) Médicament : classe, PK/PD, EI, ®, dose AIPS, durée, CI, interactions
- **11.f** (PROXY) Traitements non médicamenteux
- **11.g** (PROXY) Volets social / professionnel (LAMal, LAA, LAI, conduite, arrêt)
- **11.h** (PROXY) Situations spéciales : grossesse/allaitement, âgé, enfant, IH, IR (DFGe)
- **11.i** (PROXY) Surveillance : quoi, quand, pourquoi, seuils d’arrêt
- **11.j** (PROXY) Critères de sortie un par un
- **11.k** (PROXY) Pronostic / guérison / recherche 2026
- **12.a** (PROXY) Prévention primaire / secondaire / tertiaire, reco suisses
- **13.a** (AUTO) Points clés : 3 à 6 phrases
- **13.b** (HUMAIN) Contenu : ce qu’un médecin ne doit jamais oublier
- **14.a** (PROXY) Pièges réels de l’examen, chacun avec sa bonne réponse

## 6. Contrôles techniques §10 / §16 par fichier

| Fichier | Octets | FIN_FICHIER | 90–200 Ko | title= | Tableaux (enveloppés) | Lignes > 3000 | script/img/CSS ext. | `<details>` | Sources | Mention « non validé » | Export Google Docs |
|---|---|---|---|---|---|---|---|---|---|---|---|
| LOT_5_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.gdoc_export.html | 94897 | non | oui | 0 | 1 (0) | 1 | 0/19/0 | 0 | non | non | oui |
| LOT_5_Appel_B_V5_Ultra_Pedagogique_Partie_1_DX.1_a_DX.2.gdoc_export.html | 138815 | non | oui | 0 | 2 (0) | 1 | 0/28/0 | 0 | non | non | oui |
| LOT_5_Appel_B_V5_Ultra_Pedagogique_Partie_2_DX.3_a_DX.5.gdoc_export.html | 192929 | non | oui | 0 | 3 (0) | 1 | 0/38/0 | 0 | non | non | oui |
| LOT_5_Appel_B_V5_Ultra_Pedagogique_Partie_3_DX.6_a_DX.7.gdoc_export.html | 129613 | non | oui | 0 | 2 (0) | 1 | 0/26/0 | 0 | non | non | oui |
| LOT_5_Appel_B_V5_Ultra_Pedagogique_Partie_4_DX.8_a_DX.10.gdoc_export.html | 157008 | non | oui | 0 | 3 (0) | 1 | 0/17/0 | 0 | non | non | oui |
