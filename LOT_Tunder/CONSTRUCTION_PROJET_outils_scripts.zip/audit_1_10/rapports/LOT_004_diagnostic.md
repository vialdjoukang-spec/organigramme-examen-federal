# LOT_004 — diagnostic automatique (phase 0)

> Généré par `outils/` (scripts déterministes, aucun appel à une IA). Les notes PROXY/HUMAIN sont **indicatives** : elles signalent où regarder ; l’auditeur médical tranche.

## 1. Fichiers analysés

| Type | Fichier | Octets |
|---|---|---|
| Appel A | LOT_4_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.gdoc_export.html | 49223 |
| Partie 1 | LOT_4_Appel_B_V5_Ultra_Pedagogique_Partie_1_DX.1_a_DX.2.gdoc_export.html | 75108 |
| Partie 2 | LOT_4_Appel_B_V5_Ultra_Pedagogique_Partie_2_DX.3_a_DX.5.gdoc_export.html | 140403 |
| Partie 3 | LOT_4_Appel_B_V5_Ultra_Pedagogique_Partie_3_DX.6_a_DX.7.gdoc_export.html | 161266 |
| Partie 4 | LOT_4_Appel_B_V5_Ultra_Pedagogique_Partie_4_DX.8_a_DX.10.gdoc_export.html | 191136 |

## 2. Découpage et couverture des 14 points

| Cours | Titre | Points | Mots | Points absents / quasi vides | Anomalies |
|---|---|---|---|---|---|
| SSP | SSP — LOT_4_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.gdoc_ | 14/14 | 1114 | — | — |
| DX.1 | D4.1 — Anémie ferriprive et Carences martiales [25 %] | 14/14 | 975 | — | — |
| DX.2 | D4.2 — Épisode dépressif caractérisé et Syndromes d'épuiseme | 14/14 | 902 | — | — |
| DX.3 | D4.3 — Syndrome d'Apnées Obstructives du Sommeil (SAOS) [15  | 13/14 | 1212 | — / quasi vides : 12 | point 12 (Prévention) quasi vide (24 mots) |
| DX.4 | D4.4 — Hypothyroïdie primaire (Thyroïdite d'Hashimoto ou iat | 14/14 | 1260 | — | — |
| DX.5 | D4.5 — Infections virales prolongées (Mononucléose EBV, CMV, | 14/14 | 1285 | — | — |
| DX.6 | D4.6 — Insuffisance cardiaque chronique (HFrEF, HFmrEF, HFpE | 14/14 | 1506 | — | — |
| DX.7 | D4.7 — Maladie rénale chronique avancée (IRC et syndrome uré | 13/14 | 1516 | — / quasi vides : 12 | point 12 (Prévention) quasi vide (22 mots) |
| DX.8 | D4.8 — Néoplasie occulte (Cancer colorectal, Lymphome malin, | 14/14 | 1561 | — | — |
| DX.9 | D4.9 — Syndrome de Fatigue Chronique / Encéphalomyélite Myal | 14/14 | 1554 | — | — |
| DX.10 | D4.10 — Maladie d'Addison (Insuffisance surrénalienne primai | 14/14 | 1654 | — | — |

## 3. Examens complémentaires (exigence : cliquable + fenêtre à 2 onglets « Principe » / « Interprétation »)

| Cours | Mentions | Cliquables | Avec 2 onglets | BIO | FONC | IMG | AUTRE |
|---|---|---|---|---|---|---|---|
| SSP | 20 | 3 | 0 | 19 | 1 | 0 | 0 |
| DX.1 | 14 | 1 | 0 | 9 | 0 | 0 | 5 |
| DX.2 | 9 | 0 | 0 | 6 | 2 | 1 | 0 |
| DX.3 | 12 | 2 | 0 | 5 | 7 | 0 | 0 |
| DX.4 | 41 | 1 | 0 | 40 | 0 | 1 | 0 |
| DX.5 | 16 | 1 | 0 | 14 | 0 | 2 | 0 |
| DX.6 | 37 | 3 | 0 | 22 | 3 | 12 | 0 |
| DX.7 | 45 | 0 | 0 | 39 | 1 | 4 | 1 |
| DX.8 | 43 | 1 | 0 | 19 | 0 | 11 | 13 |
| DX.9 | 16 | 0 | 0 | 13 | 3 | 0 | 0 |
| DX.10 | 37 | 1 | 0 | 36 | 0 | 1 | 0 |
| **Total** | **290** | **13** (4.5 %) | **0** | | | | |

Fenêtres à 2 onglets détectées dans le LOT : **0**.

**Examens distincts nécessitant une fenêtre Principe / Interprétation** (48) :

| Examen | Cat. | Mentions | Cliquables | Cours |
|---|---|---|---|---|
| Ionogramme / électrolytes | BIO | 32 | 0 | DX.10, DX.2, DX.6, DX.7, DX.8, DX.9 |
| TSH | BIO | 26 | 2 | DX.10, DX.2, DX.4, DX.6, DX.8, DX.9, SSP |
| Créatinine / DFGe | BIO | 25 | 0 | DX.10, DX.6, DX.7, DX.8, DX.9, SSP |
| Ferritine / bilan martial | BIO | 20 | 2 | DX.1, DX.6, DX.7, DX.8, DX.9, SSP |
| Cortisol / test de freinage | BIO | 19 | 0 | DX.10, DX.2, DX.4, DX.8, DX.9, SSP |
| T4 / T3 libres | BIO | 16 | 0 | DX.4 |
| BNP / NT-proBNP | BIO | 12 | 1 | DX.6 |
| Endoscopie (FOGD, coloscopie, bronchoscopie) | AUTRE | 9 | 0 | DX.1, DX.8 |
| Biopsie / histologie | AUTRE | 8 | 1 | DX.7, DX.8 |
| CRP | BIO | 7 | 0 | DX.1, DX.8, DX.9, SSP |
| Bilan hépatique | BIO | 7 | 0 | DX.2, DX.5, DX.8, DX.9, SSP |
| Sérologies | BIO | 7 | 1 | DX.5, SSP |
| Polysomnographie / polygraphie | FONC | 7 | 2 | DX.3, SSP |
| Échocardiographie (ETT/ETO) | IMG | 7 | 2 | DX.6 |
| Glycémie | BIO | 6 | 1 | DX.10, DX.9, SSP |
| Scanner / TDM | IMG | 6 | 0 | DX.6, DX.8 |
| Bilan phosphocalcique / PTH | BIO | 6 | 0 | DX.7 |
| Vitamine B12 / folates | BIO | 5 | 1 | DX.10, DX.2, DX.9, SSP |
| NFS / hémogramme | BIO | 5 | 0 | DX.1, DX.5, DX.8, SSP |
| Électrophorèse des protéines | BIO | 5 | 0 | DX.1, DX.7, DX.8 |
| Anti-TPO | BIO | 5 | 0 | DX.10, DX.4 |
| Échographie (générique) | IMG | 5 | 0 | DX.5, DX.6, DX.7 |
| ECG | FONC | 4 | 0 | DX.6, DX.7 |
| EEG | FONC | 3 | 0 | DX.2, DX.3 |
| HbA1c | BIO | 3 | 0 | DX.10, DX.3, DX.9 |
| Vitesse de sédimentation (VS) | BIO | 3 | 0 | DX.8, DX.9 |
| Myélogramme / biopsie ostéomédullaire | AUTRE | 2 | 0 | DX.1 |
| IRM | IMG | 2 | 0 | DX.2, DX.6 |
| Ponction lombaire / LCR | BIO | 2 | 0 | DX.3 |
| Échographie abdominale / pelvienne | IMG | 2 | 0 | DX.5, DX.8 |
| Radiographie | IMG | 2 | 0 | DX.6, DX.8 |
| ECBU / analyse d’urine | BIO | 2 | 0 | DX.7 |
| Mammographie | IMG | 2 | 0 | DX.8 |
| LDH | BIO | 2 | 0 | DX.8 |
| TEP / PET-scan | IMG | 2 | 0 | DX.8 |
| Tests autonomiques (tilt-test, Ewing) | FONC | 2 | 0 | DX.9 |
| Gaz du sang | BIO | 1 | 0 | DX.3 |
| Bilan lipidique | BIO | 1 | 0 | DX.3 |
| Échographie cervicale / thyroïdienne | IMG | 1 | 0 | DX.4 |
| Frottis sanguin | BIO | 1 | 0 | DX.5 |
| PCR (amplification génique) | BIO | 1 | 0 | DX.5 |
| Charge virale | BIO | 1 | 0 | DX.5 |
| Examen microbiologique des expectorations (BAAR, culture, PCR mycobactéries) | BIO | 1 | 0 | DX.6 |
| Coronarographie / angiographie | IMG | 1 | 0 | DX.6 |
| Doppler | IMG | 1 | 0 | DX.7 |
| CK | BIO | 1 | 0 | DX.9 |
| Épreuve d’effort | FONC | 1 | 0 | DX.9 |
| Ostéodensitométrie | IMG | 1 | 0 | DX.10 |

## 4. Style (§7)

Phrases nominales : estimation spaCy `fr_core_news_md` + règles ; l’échantillon de contrôle montre encore des faux positifs (verbes non reconnus) → chiffre **majorant**, à relire.

| Cours | Phrases | Nominales (texte/fen./tabl.) | % | > 30 mots | Symboles à la place d’un verbe | Paragraphes sans connecteur | Sigles non développés à la 1re occurrence | Points > 4 phrases dans le texte principal | Phrases creuses / méta |
|---|---|---|---|---|---|---|---|---|---|
| SSP | 76 | 38 (38/0/0) | 50.0 | 4 | 4 | 6 | 26 : ALAT, ASAT, ATP, BLOC, CMV, DES, DIAGNOSTICS, DU, FATIGUE, IL, KDIGO, LISTE, MDI, OFSP, OMS | 3 (8), 9 (8), 11 (14), 14 (15) | 0 |
| DX.1 | 59 | 27 (26/0/1) | 45.8 | 5 | 8 | 2 | 5 : AINS, CRP, OFS, OMS, VGM | 3 (12), 11 (17) | 0 |
| DX.2 | 48 | 18 (16/0/2) | 37.5 | 2 | 2 | 3 | 8 : CIM, IRM, MADRS, MINI, PHQ, PLAFA, SIADH, TSH | 3 (9), 11 (15) | 0 |
| DX.3 | 62 | 27 (25/0/2) | 43.5 | 8 | 4 | 3 | 7 : CPAP, GIP, GLP, IMC, NoSAS, STOP, TTS | 3 (9), 9 (5), 11 (18) | 0 |
| DX.4 | 70 | 33 (29/0/4) | 47.1 | 11 | 4 | 4 | 6 : DIO2, ETA, PD, SSED, TPO, TR | 3 (12), 9 (7), 11 (16) | 0 |
| DX.5 | 64 | 31 (29/0/2) | 48.4 | 10 | 3 | 3 | 20 : ALAT, ARN, ARNm, ASAT, CD21, CMV, CoV, EBNA, EBV, IL, IgG, IgM, MNI, OFSP, PCR | 3 (11), 9 (6), 11 (16) | 0 |
| DX.6 | 75 | 37 (30/0/7) | 49.3 | 12 | 8 | 3 | 22 : ARM, ARNI, BNP, CHAMPIT, CST, DFGe, ECG, ESC, FE, GIP, GLP, IEC, IRM, NT, NYHA | 3 (10), 9 (6), 11 (21) | 0 |
| DX.7 | 70 | 32 (30/0/2) | 45.7 | 14 | 7 | 3 | 16 : AEIOU, CKD, CRISPR, DFG, EPI, G3a, G3b, HIF, IRC, KDIGO, NaCl, PAS, PHI, PTH, QRS | 3 (12), 9 (8), 11 (17) | 0 |
| DX.8 | 88 | 37 (35/0/2) | 42.0 | 12 | 5 | 7 | 22 : ADC, ARNm, ATP, CAR, CD20, CRAB, CRP, CT, DFGe, ECOG, ESMO, FDG, FIT, GDF, IL | 3 (13), 9 (8), 11 (20) | 0 |
| DX.9 | 70 | 36 (28/0/8) | 51.4 | 12 | 5 | 4 | 24 : AI, BC007, COVID, CPET, CoV, EM, FC, FSC, HbA1c, IOM, LDN, NASA, NICE, NaCl, OFSP | 3 (12), 9 (8), 11 (16) | 0 |
| DX.10 | 78 | 32 (31/0/1) | 41.0 | 13 | 4 | 7 | 9 : ACTH, ENaC, HCO3, IM, LC, MC1R, MS, PEAI, SSED | 3 (13), 9 (6), 11 (21) | 0 |

**Exemples à relire** (extraits automatiques) :

- [SSP pt 1/main] (33 mots) La Fatigue (Asthénie) désigne un épuisement global qui altère le fonctionnement quotidien, et se différencie de la fatigue physiologique par sa disproportion face à l'effort fourni et son caractère ré…
- [SSP pt 3/main] (47 mots) L'épuisement cellulaire procède de déficits en substrats (hypoxie tissulaire par anémie, carence en ATP par hypothyroïdie), d'une surcharge catabolique induite par des cytokines pro-inflammatoires (IL…
- [SSP pt None/main] Fatigue, Épuisement (SSP G4)
- [SSP pt None/main] PLAN MONOGRAPHIQUE DU SSP PRINCIPAL (G4 — FATIGUE, ÉPUISEMENT)
- [SSP pt 2/main] Revue Médicale Suisse).
- [SSP pt 3/main] VGM (fL) = Hématocrite (%) × 10 / Nombre d'Érythrocytes (T/L)
- [DX.1 pt 1/main] (34 mots) L'anémie ferriprive se définit comme une baisse de la concentration sanguine en hémoglobine secondaire à un épuisement des réserves de fer de l'organisme, ce qui entrave l'érythropoïèse et provoque un…
- [DX.1 pt 2/main] (42 mots) L'anémie ferriprive constitue la carence nutritionnelle la plus prévalente en Suisse, touchant jusqu'à 20 % des femmes en âge de procréer (à cause des menstruations) et environ 5 % des hommes adultes,…
- [DX.1 pt 3/main] Formule de Ganzoni (Calcul du déficit martial global pour perfusion IV)
- [DX.1 pt 3/main] Explicitation des variables et Formule :
- [DX.1 pt 3/main] Utilisée pour calculer la dose totale de fer intraveineux nécessaire pour corriger l'anémie et reconstituer les réserves martiales.
- [DX.1 pt 3/main] 1. Explicitation des variables et Formule : Utilisée pour calculer la dose totale de fer intraveineux nécessaire pour corriger l'anémie et reconstituer les rése
- [DX.2 pt 5/main] (36 mots) Les drapeaux rouges nécessitant une hospitalisation en urgence comprennent : les idées suicidaires structurées sans facteurs protecteurs, la présence de délires congruents à l'humeur (syndrome de Cota…
- [DX.2 pt 8/main] (35 mots) Les critères de la CIM-10 exigent la présence pendant 2 semaines d'au moins 2 symptômes cardinaux (humeur dépressive, perte d'intérêt, baisse d'énergie) couplés à des symptômes accessoires (troubles d…
- [DX.2 pt 2/main] Parallèlement, le burn-out fragilise environ 25 % des travailleurs suisses, constituant un fléau économique majeur.
- [DX.2 pt 3/main] Échelle d'Évaluation de la Dépression (Score PHQ-9)
- [DX.2 pt 3/main] Explicitation des variables et Formule :
- [DX.2 pt 3/main] Score PHQ-9 = Somme des items (1 à 9) sur un maximum de 27 points.
- [DX.3 pt 2/main] (40 mots) L'étude de cohorte lausannoise HypnoLaus démontre qu'en Suisse, un SAOS modéré à sévère touche jusqu'à 49 % des hommes et 23 % des femmes de plus de 40 ans, bien que le syndrome cliniquement symptomat…
- [DX.3 pt 3/main] (39 mots) Durant le sommeil paradoxal et lent profond, l'hypotonie physiologique des muscles dilatateurs du pharynx (notamment le muscle génioglosse) s'associe au rétrécissement anatomique pariétal (infiltratio…
- [DX.3 pt 3/main] Hypopnées (IAH) & Score de Dépistage STOP-Bang
- [DX.3 pt 3/main] Explicitation des variables et Formule :
- [DX.3 pt 3/main] IAH (événements/h)
- [DX.3 pt 3/main] IAH (événements/h) = (Nombre total d'Apnées + Nombre total d'Hypopnées) / Temps Total de Sommeil (heures)
- [DX.4 pt 2/main] (50 mots) En Suisse, pays où la carence en iode est historiquement éradiquée grâce à la fluoration et l'iodation du sel de cuisine, l'hypothyroïdie avérée touche 1 à 2 % de la population générale (et jusqu'à 8 …
- [DX.4 pt 4/main] (34 mots) Le clinicien recherche en priorité une thyroïdite auto-immune chronique d'Hashimoto ou une cause iatrogène (surcharge iodée par amiodarone ou produits de contraste, lithium, immunothérapie oncologique…
- [DX.4 pt 3/main] Dans la thyroïdite d'Hashimoto, une infiltration lymphocytaire T cytotoxique associée à des auto-anticorps anti-thyroperoxydase (anti-TPO) détruit progressivement les fol
- [DX.4 pt 3/main] Au niveau périphérique, le défaut d'activation des récepteurs nucléaires TR
- [DX.4 pt 3/main] -α et TR
- [DX.4 pt 3/main] Dose quotidienne de Lévothyroxine (μg/jour) = 1,6 μg × Poids corporel (kg)
- [DX.5 pt 1/main] (33 mots) Les asthénies infectieuses et post-virales désignent un état d'épuisement physique et cognitif persistant plusieurs semaines à plusieurs mois au cours ou au décours immédiat d'une primo-infection vira…
- [DX.5 pt 2/main] (36 mots) lorsque la primo-infection survient chez l'adolescent ou le jeune adulte (15-25 ans), elle se manifeste dans 50 % des cas par une mononucléose infectieuse symptomatique suivie d'une fatigue prolongée …
- [DX.5 pt 1/main] , le Cytomégalovirus [CMV], le Virus de l'Immunodéficience Humaine [VIH] ou le SARS-CoV-2).
- [DX.5 pt 3/main] Lors de la mononucléose infectieuse, l'EBV (Herpesviridae) infecte l'épithélium oropharyngé
- [DX.5 pt 3/main] puis les lymphocytes B via le récepteur CD21.
- [DX.5 pt 3/main] Lymphocytes absolus (G/L) = Leucocytes totaux (G/L) × (% Lymphocytes / 100)
- [DX.6 pt 1/main] (48 mots) L'insuffisance cardiaque chronique (ICC) est un syndrome clinique complexe résultant d'une anomalie cardiaque structurelle et/ou fonctionnelle qui altère le remplissage ventriculaire ou l'éjection sys…
- [DX.6 pt 2/main] (42 mots) En Suisse, l'insuffisance cardiaque affecte environ 200 000 personnes (prévalence de 1 à 2 % dans la population adulte globale, grimpant à plus de 10 % chez les sujets de plus de 70 ans selon l'OFS et…
- [DX.6 pt 3/main] aldostérone (SRAA, rétention hydrosodée et fibrose myocardique).
- [DX.6 pt 3/main] Gauche (FEVG) & Seuils Décisionnels du NT-proBNP
- [DX.6 pt 3/main] Explicitation des variables et Formule :
- [DX.6 pt 3/main] FEVG (%) = [ (VTD - VTS) / VTD ] × 100 = (VES / VTD) × 100
- [DX.7 pt 1/main] (38 mots) se définit, selon le consortium international KDIGO, par la persistance pendant plus de 3 mois consécutifs soit d'un Débit de Filtration Glomérulaire estimé () inférieur à , soit d'un marqueur d'attei…
- [DX.7 pt 2/main] (37 mots) En Suisse, la maladie rénale chronique touche environ 10 % de la population adulte (soit près de 800 000 personnes, principalement aux stades G1 à G3), avec le diabète sucré de type 2 et la néphroangi…
- [DX.7 pt 1/main] La Maladie Rénale
- [DX.7 pt 3/main] et (4) le déficit en calcitriol (
- [DX.7 pt 3/main] par perte de la -hydroxylase rénale.
- [DX.7 pt 3/main] Calcémie corrigée (mmol/L) = Calcémie totale mesurée (mmol/L) + 0,02 × [ 40 - Albuminémie (g/L) ]
- [DX.8 pt 1/main] (45 mots) La fatigue liée à une néoplasie occulte (ou asthénie paranéoplasique inaugurale) désigne un état d'épuisement physique et cognitif persistant, réfractaire au sommeil, qui constitue la manifestation ré…
- [DX.8 pt 2/main] (45 mots) bien que la prévalence d'une néoplasie occulte chez un patient consultant en médecine de premier recours pour une fatigue isolée ne soit que de 1 à 3 %, ce taux grimpe à plus de 15 % dès que l'asthéni…
- [DX.8 pt 3/main] et (3) les noyaux arqués hypothalamiques, induisant une anorexie centrale et une léthargie profonde.
- [DX.8 pt 3/main] Cinétique de la Cachexie Oncologique (
- [DX.8 pt 3/main] Critères de Fearon) & Critères CRAB du Myélome
- [DX.8 pt 3/main] Perte pondérale (%) = [ (Poids habituel - Poids actuel) / Poids habituel ] × 100
- [DX.9 pt 1/main] (48 mots) L'Encéphalomyélite Myalgique / Syndrome de Fatigue Chronique (EM/SFC) est une maladie neurologique et immunométabolique chronique sévèrement invalidante, évoluant depuis plus de 6 mois, dont la signat…
- [DX.9 pt 3/main] (59 mots) Souvent déclenchée par une infection virale aiguë (EBV, SARS-CoV-2, entérovirus), la maladie procède d'une dysrégulation neuro-immuno-vasculaire tripartite : (1) une auto-immunité fonctionnelle (auto-…
- [DX.9 pt 2/main] , touchant préférentiellement les adultes jeunes de 20 à 45 ans avec un ratio de 3 femmes pour 1 homme.
- [DX.9 pt 3/main] et (3) une activation microgliale chronique (neuro-inflammation) responsable du brouillard cognitif.
- [DX.9 pt 3/main] 🔍 Fenêtre Interactive Bio-Mathématique 3.9 : Test de Schellong Actif sur 10 Minutes (NASA Lean Test) & Critères Hémodynamiques
- [DX.9 pt 3/main] 1. Explicitation des variables et Formules : L'intolérance orthostatique, et particulièrement le Syndrome de Tachycardie Orthostatique Posturale (POTS), est pré
- [DX.10 pt 1/main] (37 mots) La Maladie d'Addison (insuffisance surrénalienne primaire) résulte de la destruction anatomique bilatérale de plus de 90 % du cortex surrénalien, entraînant une carence hormonale vitale combinant un d…
- [DX.10 pt 3/main] (93 mots) La destruction des trois couches corticales (glomérulée, fasciculée et réticulée), le plus souvent médiée par des lymphocytes T autoréactifs et des auto-anticorps dirigés contre l'enzyme 21-hydroxylas…
- [DX.10 pt 3/main] Test Dynamique au Synacthène® (ACTH 1-24) & Natrémie Corrigée / Trou Anionique
- [DX.10 pt 3/main] Explicitation des variables et Formules :
- [DX.10 pt 3/main] ) (Norme : 8 à 12 mmol/L)
- [DX.10 pt 3/main] Trou Anionique plasmatique : TA (mmol/L) = [Na+] - ( [Cl-] + [HCO3-] ) (Norme : 8 à 12 mmol/L)

**LanguageTool (API publique, échantillon de 9002 caractères du texte principal, 1 requêtes, 0 échecs)** : {'Faute de frappe possible': 49, 'style rules': 6, 'Concordances': 1, 'Typographie': 5, 'Règles de base': 1, 'Punctuation virgule': 1, 'Miscellaneous': 1}. La catégorie « faute de frappe » contient surtout des termes médicaux absents du dictionnaire.

- [style rules] Les chiffres s’écrivent généralement en lettres. — « ...antifie la durée de la plainte (aiguë < 1 mois, subaiguë 1 à 6 mois, chronique > ... » → ['un']
- [style rules] Les chiffres s’écrivent généralement en lettres. — « ... mois, subaiguë 1 à 6 mois, chronique > 6 mois), l'impact sur les activités profe... » → ['six']
- [style rules] Les chiffres s’écrivent généralement en lettres. — « ...es de l'OMS si elle persiste au-delà de 6 mois de manière inexpliquée malgré l'ex... » → ['six']
- [Concordances] Ce nombre ordinal doit être féminin et mis en exposant. — « ...nostic est un processus d'exclusion.  - 1ère intention (Bilan de base de l'asthénie ... » → ['1ʳᵉ']
- [style rules] Les chiffres s’écrivent généralement en lettres. — « ...n (Bilan de base de l'asthénie isolée > 1 mois) : Formule Sanguine Complète (FSC)... » → ['un']
- [Typographie] Faute de typographie. — « ...), Glycémie à jeun et Créatininémie.  - 2ème intention (Orientée par la clinique) : ... » → ['2ᵉ']
- [style rules] Les chiffres s’écrivent généralement en lettres. — « ...). En l'absence de cause évidente après 6 mois, il évoque un Syndrome de Fatigue ... » → ['six']
- [Typographie] Le trait d’union est employé sans espaces pour former des mots, alors que le tiret est encadré par des espaces et placé entre deux mots distincts. — « ...que ou une Encéphalomyélite Myalgique.  A- But : Traiter l'étiologie sous-jacente, res... » → ['A-But', 'A – But', 'A But']
- [Typographie] Le trait d’union est employé sans espaces pour former des mots, alors que le tiret est encadré par des espaces et placé entre deux mots distincts. — « ...venir le déconditionnement musculaire.  B- Moyens et méthodes :  - Moyens non médicamente... » → ['B-Moyens', 'B – Moyens', 'B Moyens']
- [Typographie] Le trait d’union est employé sans espaces pour former des mots, alors que le tiret est encadré par des espaces et placé entre deux mots distincts. — « ...es) n'est validé de manière empirique.  C- Surveillance :  - Clinique et Biologique : Réévaluat... » → ['C-Surveillance', 'C – Surveillance', 'C Surveillance']
- [style rules] Les chiffres s’écrivent généralement en lettres. — « ...ologique : Réévaluation des symptômes à 4 semaines et contrôle biologique ciblé s... » → ['quatre']
- [Typographie] Le trait d’union est employé sans espaces pour former des mots, alors que le tiret est encadré par des espaces et placé entre deux mots distincts. — « ...tes à J7 post-supplémentation en fer).  D- Pronostic, Critères de guérison et Recherche 2026... » → ['D-Pronostic', 'D – Pronostic', 'D Pronostic']

## 5. Score §6.3 (proxy) — LOT : **32.7 %** (seuil de dépôt : ≥ 90 % et zéro erreur critique)

Les erreurs critiques ne sont PAS détectables automatiquement : relecture médicale obligatoire.

| Cours | Score | Hors critères HUMAIN | Critères < 2 |
|---|---|---|---|
| SSP | 30.0 % | 30.6 % | 1.b 2.b 2.c 3.a 3.b 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.1 | 30.0 % | 32.3 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.2 | 28.8 % | 30.6 % | 1.b 1.c 2.b 2.c 3.a 3.b 5.a 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.3 | 31.2 % | 33.9 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.4 | 32.5 % | 33.9 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.5 | 35.0 % | 38.7 % | 1.b 1.c 2.c 3.a 3.b 4.a 5.a 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b |
| DX.6 | 35.0 % | 40.3 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 11.b 11.c 11.d 11.e 11.g 11.h 11.j 12.a 13.a 13.b 14.a |
| DX.7 | 33.8 % | 33.9 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 11.b 11.c 11.d 11.e 11.g 11.h 11.j 12.a 13.a 13.b 14.a |
| DX.8 | 31.2 % | 33.9 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.9 | 40.0 % | 41.9 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 5.b 6.b 7.b 7.c 8.b 9.a 9.b 9.c 9.d 9.e 9.f 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.10 | 32.5 % | 35.5 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |

Légende des critères :

- **1.a** (AUTO) Texte principal en 1 à 4 phrases
- **1.b** (PROXY) Définition issue d’une source médicale (référence [Sx])
- **1.c** (HUMAIN) Distinction avec les notions voisines
- **2.a** (PROXY) Données suisses chiffrées (OFS/OFSP/Obsan…)
- **2.b** (PROXY) Données européennes / internationales
- **2.c** (HUMAIN) Facteurs de risque / terrain / pronostic chiffré
- **3.a** (PROXY) Tableau lésion → exploration → cible thérapeutique
- **3.b** (HUMAIN) Chaque signe relié à son mécanisme
- **4.a** (PROXY) Priorités : urgence d’abord, puis étapes ordonnées
- **5.a** (PROXY) Questions d’anamnèse ciblées
- **5.b** (HUMAIN) Drapeaux rouges complets et actionnables
- **6.a** (PROXY) Le normal avant le pathologique
- **6.b** (HUMAIN) Technique de recherche + valeur diagnostique de chaque signe
- **7.a** (PROXY) Syndromes énumérés
- **7.b** (PROXY) Signes fonctionnels / signes physiques séparés
- **7.c** (HUMAIN) Chaque signe défini en fenêtre, avec geste et mécanisme
- **8.a** (PROXY) Critères diagnostiques : société savante + année + seuils
- **8.b** (PROXY) Ce qui ne suffit pas à poser le diagnostic
- **9.a** (PROXY) Gold standard dit (existe/n’existe pas) avec Se/Spé/seuil
- **9.b** (PROXY) 1re / 2e intention et critère de passage
- **9.c** (PROXY) Prescription : indication, moment, préparation
- **9.d** (PROXY) Tableau d’interprétation normal (SI) | seuil | signification | conduite
- **9.e** (PROXY) Cas de figure : positif / négatif / limite / discordant
- **9.f** (PROXY) Alternatives : grossesse, enfant, DFGe < 30, iode, pacemaker
- **10.a** (PROXY) Arbre : chaque embranchement → décision
- **11.a** (PROXY) But du traitement chiffré
- **11.b** (PROXY) Ordre de la prise en charge et pourquoi (A→D)
- **11.c** (HUMAIN) Formes compliquées : urgence + chronologie (fenêtre)
- **11.d** (PROXY) Formes non compliquées : mesures générales puis ordre
- **11.e** (HUMAIN) Médicament : classe, PK/PD, EI, ®, dose AIPS, durée, CI, interactions
- **11.f** (PROXY) Traitements non médicamenteux
- **11.g** (PROXY) Volets social / professionnel (LAMal, LAA, LAI, conduite, arrêt)
- **11.h** (PROXY) Situations spéciales : grossesse/allaitement, âgé, enfant, IH, IR (DFGe)
- **11.i** (PROXY) Surveillance : quoi, quand, pourquoi, seuils d’arrêt
- **11.j** (PROXY) Critères de sortie un par un
- **11.k** (PROXY) Pronostic / guérison / recherche 2026
- **12.a** (PROXY) Prévention primaire / secondaire / tertiaire, reco suisses
- **13.a** (AUTO) Points clés : 3 à 6 phrases
- **13.b** (HUMAIN) Contenu : ce qu’un médecin ne doit jamais oublier
- **14.a** (PROXY) Pièges réels de l’examen, chacun avec sa bonne réponse

## 6. Contrôles techniques §10 / §16 par fichier

| Fichier | Octets | FIN_FICHIER | 90–200 Ko | title= | Tableaux (enveloppés) | Lignes > 3000 | script/img/CSS ext. | `<details>` | Sources | Mention « non validé » | Export Google Docs |
|---|---|---|---|---|---|---|---|---|---|---|---|
| LOT_4_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.gdoc_export.html | 49223 | non | non | 0 | 1 (0) | 1 | 0/0/0 | 0 | non | non | oui |
| LOT_4_Appel_B_V5_Ultra_Pedagogique_Partie_1_DX.1_a_DX.2.gdoc_export.html | 75108 | non | non | 0 | 2 (0) | 1 | 0/0/0 | 0 | non | non | oui |
| LOT_4_Appel_B_V5_Ultra_Pedagogique_Partie_2_DX.3_a_DX.5.gdoc_export.html | 140403 | non | oui | 0 | 3 (0) | 1 | 0/5/0 | 0 | non | non | oui |
| LOT_4_Appel_B_V5_Ultra_Pedagogique_Partie_3_DX.6_a_DX.7.gdoc_export.html | 161266 | non | oui | 0 | 2 (0) | 1 | 0/45/0 | 0 | non | non | oui |
| LOT_4_Appel_B_V5_Ultra_Pedagogique_Partie_4_DX.8_a_DX.10.gdoc_export.html | 191136 | non | oui | 0 | 3 (0) | 1 | 0/34/0 | 0 | non | non | oui |
