# LOT_009 — diagnostic automatique (phase 0)

> Généré par `outils/` (scripts déterministes, aucun appel à une IA). Les notes PROXY/HUMAIN sont **indicatives** : elles signalent où regarder ; l’auditeur médical tranche.

## 1. Fichiers analysés

| Type | Fichier | Octets |
|---|---|---|

## 2. Découpage et couverture des 14 points

| Cours | Titre | Points | Mots | Points absents / quasi vides | Anomalies |
|---|---|---|---|---|---|

## 3. Examens complémentaires (exigence : cliquable + fenêtre à 2 onglets « Principe » / « Interprétation »)

| Cours | Mentions | Cliquables | Avec 2 onglets | BIO | FONC | IMG | AUTRE |
|---|---|---|---|---|---|---|---|
| **Total** | **0** | **0** (0 %) | **0** | | | | |

Fenêtres à 2 onglets détectées dans le LOT : **0**.

**Examens distincts nécessitant une fenêtre Principe / Interprétation** (0) :

| Examen | Cat. | Mentions | Cliquables | Cours |
|---|---|---|---|---|

## 4. Style (§7)

Phrases nominales : estimation spaCy `fr_core_news_md` + règles ; l’échantillon de contrôle montre encore des faux positifs (verbes non reconnus) → chiffre **majorant**, à relire.

| Cours | Phrases | Nominales (texte/fen./tabl.) | % | > 30 mots | Symboles à la place d’un verbe | Paragraphes sans connecteur | Sigles non développés à la 1re occurrence | Points > 4 phrases dans le texte principal | Phrases creuses / méta |
|---|---|---|---|---|---|---|---|---|---|

**Exemples à relire** (extraits automatiques) :


**LanguageTool (API publique, échantillon de 0 caractères du texte principal, 0 requêtes, 0 échecs)** : {}. La catégorie « faute de frappe » contient surtout des termes médicaux absents du dictionnaire.


## 5. Score §6.3 (proxy) — LOT : **None %** (seuil de dépôt : ≥ 90 % et zéro erreur critique)

Les erreurs critiques ne sont PAS détectables automatiquement : relecture médicale obligatoire.

| Cours | Score | Hors critères HUMAIN | Critères < 2 |
|---|---|---|---|

Légende des critères :


## 6. Contrôles techniques §10 / §16 par fichier

| Fichier | Octets | FIN_FICHIER | 90–200 Ko | title= | Tableaux (enveloppés) | Lignes > 3000 | script/img/CSS ext. | `<details>` | Sources | Mention « non validé » | Export Google Docs |
|---|---|---|---|---|---|---|---|---|---|---|---|
| LOT_9_Appel_A_Plan_et_Liste_A_REDIGER.html | 935 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| LOT_9_Appel_B_Partie_1_DX.1_a_DX.2_A_REDIGER.html | 959 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| LOT_9_Appel_B_Partie_2_DX.3_a_DX.5_A_REDIGER.html | 959 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| LOT_9_Appel_B_Partie_3_DX.6_a_DX.7_A_REDIGER.html | 959 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| LOT_9_Appel_B_Partie_4_DX.8_a_DX.10_A_REDIGER.html | 961 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
