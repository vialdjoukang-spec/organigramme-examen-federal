# LOT_001 — diagnostic automatique (phase 0)

> Généré par `outils/` (scripts déterministes, aucun appel à une IA). Les notes PROXY/HUMAIN sont **indicatives** : elles signalent où regarder ; l’auditeur médical tranche.

## 1. Fichiers analysés

| Type | Fichier | Octets |
|---|---|---|
| Appel A | LOT_1_Appel_A_V7_Plan_et_Liste_V9_a.html | 156277 |
| Appel A | LOT_1_Appel_A_V7_Plan_et_Liste_V9_b.html | 147392 |
| Partie 1 | LOT_1_Appel_B_V7_Partie_1_DX.1_a_DX.2_a_r1.html | 130912 |
| Partie 1 | LOT_1_Appel_B_V7_Partie_1_DX.1_a_DX.2_b_r1.html | 120298 |
| Partie 2 | LOT_1_Appel_B_V7_Partie_2_DX.3_a_DX.5_a_r1.html | 140728 |
| Partie 2 | LOT_1_Appel_B_V7_Partie_2_DX.3_a_DX.5_b_r1.html | 130474 |
| Partie 3 | LOT_1_Appel_B_V7_Partie_3_DX.6_a_DX.7_a_r2.html | 95449 |
| Partie 3 | LOT_1_Appel_B_V7_Partie_3_DX.6_a_DX.7_b_r2.html | 122026 |
| Partie 4 | LOT_1_Appel_B_V7_Partie_4_DX.8_a_DX.10_a_r1.html | 109928 |
| Partie 4 | LOT_1_Appel_B_V7_Partie_4_DX.8_a_DX.10_b_r1.html | 135292 |

## 2. Découpage et couverture des 14 points

| Cours | Titre | Points | Mots | Points absents / quasi vides | Anomalies |
|---|---|---|---|---|---|
| SSP | SSP — LOT_1_Appel_A_V7_Plan_et_Liste_V9_a.html | 14/14 | 27245 | — | — |
| APPEL_A_BLOC2 | Bloc 2 · Dix diagnostics organisent le raisonnement | (bloc 2 de l’Appel A : 4403 mots, None tableaux) | | | |
| DX.1 | DX.1 — Syndrome coronarien aigu | 14/14 | 14156 | — | — |
| DX.2 | DX.2 — Hypoglycémie | 14/14 | 11229 | — | — |
| DX.3 | DX.3 — Endocardite infectieuse | 14/14 | 8812 | — | titre « 8. Examens complémentaires et hiérarchisation » numéroté 8 mais correspond au point 9 (§6); titre « 9. Critères, seuils et résultats opérationnels » numéroté 9 mais correspond au point 8 (§6); titre « 10. Confirmation étiologique et bilan des complications » non reconnu par le lexique §6 (at |
| DX.4 | DX.4 — Hyperhidrose focale primaire | 14/14 | 8548 | — | titre « 9. Scores, mesures et interprétation opérationnelle » non reconnu par le lexique §6 (attribué au n° 9) |
| DX.5 | DX.5 — Symptômes vasomoteurs de la ménopause | 14/14 | 9516 | — | — |
| DX.6 | DX.6 · Hyperthyroïdie · 6e rang — fréquence non quantifiée p | 14/14 | 10609 | — | — |
| DX.7 | DX.7 · Tuberculose · 7e rang — fréquence non quantifiée parm | 14/14 | 13795 | — | — |
| DX.8 | DX.8 · Infection par VIH · 8e rang — fréquence non quantifié | 14/14 | 8764 | — | — |
| DX.9 | DX.9 · Lymphome de Hodgkin · 9e rang — fréquence non quantif | 14/14 | 9071 | — | — |
| DX.10 | DX.10 · Phéochromocytome et paragangliome · 10e rang — fréqu | 14/14 | 9081 | — | — |

## 3. Examens complémentaires (exigence : cliquable + fenêtre à 2 onglets « Principe » / « Interprétation »)

| Cours | Mentions | Cliquables | Avec 2 onglets | BIO | FONC | IMG | AUTRE |
|---|---|---|---|---|---|---|---|
| SSP | 214 | 18 | 0 | 147 | 14 | 41 | 12 |
| APPEL_A_BLOC2 | 39 | 10 | 0 | 29 | 1 | 6 | 3 |
| DX.1 | 133 | 9 | 0 | 67 | 26 | 40 | 0 |
| DX.2 | 131 | 8 | 0 | 107 | 2 | 16 | 6 |
| DX.3 | 53 | 0 | 0 | 19 | 1 | 31 | 2 |
| DX.4 | 23 | 2 | 0 | 8 | 8 | 4 | 3 |
| DX.5 | 43 | 1 | 0 | 41 | 0 | 2 | 0 |
| DX.6 | 109 | 8 | 0 | 77 | 7 | 25 | 0 |
| DX.7 | 72 | 1 | 0 | 48 | 0 | 16 | 8 |
| DX.8 | 31 | 1 | 0 | 31 | 0 | 0 | 0 |
| DX.9 | 62 | 2 | 0 | 13 | 1 | 28 | 20 |
| DX.10 | 35 | 4 | 0 | 21 | 1 | 11 | 2 |
| **Total** | **945** | **64** (6.8 %) | **0** | | | | |

Fenêtres à 2 onglets détectées dans le LOT : **0**.

**Examens distincts nécessitant une fenêtre Principe / Interprétation** (49) :

| Examen | Cat. | Mentions | Cliquables | Cours |
|---|---|---|---|---|
| Glycémie | BIO | 184 | 18 | APPEL_A_BLOC2, DX.1, DX.10, DX.2, DX.4, DX.5, DX.6, DX.7, DX.8, SSP |
| TSH | BIO | 60 | 3 | APPEL_A_BLOC2, DX.4, DX.6, DX.9, SSP |
| ECG | FONC | 50 | 0 | APPEL_A_BLOC2, DX.1, DX.10, DX.2, DX.3, DX.6, DX.9, SSP |
| Biopsie / histologie | AUTRE | 45 | 3 | APPEL_A_BLOC2, DX.10, DX.3, DX.4, DX.7, DX.9, SSP |
| Troponine | BIO | 42 | 2 | APPEL_A_BLOC2, DX.1, SSP |
| T4 / T3 libres | BIO | 40 | 6 | APPEL_A_BLOC2, DX.6, SSP |
| IRM | IMG | 39 | 5 | DX.1, DX.10, DX.2, DX.6, DX.7, DX.9, SSP |
| Échographie (générique) | IMG | 37 | 1 | APPEL_A_BLOC2, DX.1, DX.10, DX.2, DX.3, DX.4, DX.5, DX.6, DX.9, SSP |
| Scanner / TDM | IMG | 36 | 0 | APPEL_A_BLOC2, DX.1, DX.10, DX.2, DX.3, DX.4, DX.5, DX.6, DX.7, DX.9, SSP |
| Échocardiographie (ETT/ETO) | IMG | 35 | 0 | APPEL_A_BLOC2, DX.1, DX.3, DX.9, SSP |
| Examen microbiologique des expectorations (BAAR, culture, PCR mycobactéries) | BIO | 28 | 3 | APPEL_A_BLOC2, DX.10, DX.7, SSP |
| Métanéphrines | BIO | 28 | 5 | APPEL_A_BLOC2, DX.10, SSP |
| Bilan hépatique | BIO | 26 | 0 | DX.1, DX.3, DX.5, DX.7, DX.8, DX.9 |
| TEP / PET-scan | IMG | 25 | 0 | APPEL_A_BLOC2, DX.2, DX.3, DX.6, DX.9, SSP |
| NFS / hémogramme | BIO | 22 | 0 | DX.1, DX.3, DX.4, DX.6, DX.7, DX.9, SSP |
| Hémocultures | BIO | 21 | 5 | APPEL_A_BLOC2, DX.3, DX.4, DX.5, SSP |
| Créatinine / DFGe | BIO | 20 | 0 | DX.1, DX.10, DX.3, DX.4, DX.5, DX.7, DX.8, DX.9, SSP |
| FSH / LH / œstradiol | BIO | 19 | 0 | DX.5 |
| Coronarographie / angiographie | IMG | 18 | 4 | DX.1, DX.2, SSP |
| Charge virale | BIO | 15 | 1 | DX.8 |
| Peptide C / insuline | BIO | 13 | 0 | DX.2 |
| Scintigraphie (thyroïde, MIBG, DOTATATE…) | IMG | 13 | 4 | DX.3, DX.6 |
| Radiographie | IMG | 12 | 0 | DX.1, DX.10, DX.4, DX.7, SSP |
| Ionogramme / électrolytes | BIO | 12 | 0 | DX.1, SSP |
| PCR (amplification génique) | BIO | 11 | 0 | DX.7, SSP |
| CRP | BIO | 10 | 2 | APPEL_A_BLOC2, DX.3, DX.7, SSP |
| Gravimétrie sudorale | FONC | 9 | 2 | DX.4, SSP |
| Endoscopie (FOGD, coloscopie, bronchoscopie) | AUTRE | 9 | 0 | DX.2, DX.7 |
| IGRA / test tuberculinique | BIO | 8 | 0 | APPEL_A_BLOC2, DX.7, SSP |
| Sérologies | BIO | 8 | 0 | DX.3, DX.7, DX.8, DX.9 |
| Test VIH (Ag/Ac 4e génération) | BIO | 6 | 0 | DX.7, DX.8, SSP |
| Coagulation (TP/INR/TCA/fibrinogène) | BIO | 6 | 0 | DX.1, DX.7 |
| Lymphocytes CD4 | BIO | 6 | 0 | DX.8 |
| Bilan lipidique | BIO | 4 | 0 | DX.1 |
| Vitesse de sédimentation (VS) | BIO | 4 | 0 | DX.9 |
| Cortisol / test de freinage | BIO | 3 | 0 | DX.2, SSP |
| Prolactine | BIO | 3 | 0 | DX.5 |
| Tests génétiques | AUTRE | 2 | 0 | DX.4 |
| Test de Minor (iode-amidon) | FONC | 2 | 0 | DX.4 |
| hCG (test de grossesse) | BIO | 2 | 0 | DX.5 |
| Doppler | IMG | 2 | 0 | DX.6, DX.7 |
| D-dimères | BIO | 2 | 0 | DX.7 |
| Cytométrie en flux | BIO | 2 | 0 | DX.7 |
| Échographie abdominale / pelvienne | IMG | 1 | 0 | SSP |
| CK | BIO | 1 | 0 | DX.1 |
| Lactate | BIO | 1 | 0 | DX.2 |
| Gaz du sang | BIO | 1 | 0 | DX.2 |
| Échographie cervicale / thyroïdienne | IMG | 1 | 0 | DX.6 |
| Mammographie | IMG | 1 | 0 | DX.9 |

## 4. Style (§7)

Phrases nominales : estimation spaCy `fr_core_news_md` + règles ; l’échantillon de contrôle montre encore des faux positifs (verbes non reconnus) → chiffre **majorant**, à relire.

| Cours | Phrases | Nominales (texte/fen./tabl.) | % | > 30 mots | Symboles à la place d’un verbe | Paragraphes sans connecteur | Sigles non développés à la 1re occurrence | Points > 4 phrases dans le texte principal | Phrases creuses / méta |
|---|---|---|---|---|---|---|---|---|---|
| SSP | 1809 | 97 (16/36/45) | 5.4 | 26 | 5 | 129 | 16 : AX, BOTOX, CG055, CHUV, CIMS, DDG, DE, ECG, HDSS, HUG, P4503A4, SMIFK, SNAP, TDM, TEP | 3 (5), 6 (13), 7 (8), 8 (6), 9 (30), 11 (25), 13 (5) | 5 |
| APPEL_A_BLOC2 | 178 | 14 (8/0/6) | 7.9 | 1 | 0 | 10 | 2 : TDM, TEP | — | 10 |
| DX.1 | 942 | 92 (7/13/72) | 9.8 | 5 | 1 | 62 | 40 : AAS, ACS, AIPS, AIT, AVC, CHUV, CPK, CYP3A4, CoA, DFGe, ECG, ESC, ESUR, FI, GRACE | 2 (5), 5 (5), 6 (5), 7 (5), 9 (7), 11 (25), 13 (5) | 22 |
| DX.2 | 701 | 42 (6/9/27) | 6.0 | 6 | 0 | 40 | 18 : ABCDE, AIPS, CNEC, ECLIA, ENETS, ENETS2023, HELP, HUG, IA, IRM, JBDS, LUKS, LeJBDS, MR, SFE | 2 (5), 6 (5), 7 (5), 9 (10), 11 (14), 13 (5), 14 (9) | 22 |
| DX.3 | 655 | 52 (8/12/32) | 7.9 | 5 | 0 | 44 | 10 : AIPS, CSV, ESC, ESC2023, FI, HACEK, HELP, HUG, IgG, LAI | 1 (5), 2 (5), 3 (5), 8 (8), 11 (9), 12 (6), 13 (5) | 16 |
| DX.4 | 617 | 43 (7/8/28) | 7.0 | 3 | 0 | 42 | 14 : AIPS, AWMF, AWMF2023, BOTOX, CSV, DFGe, FI, HDSS, HDSS3, HUG, IA, LAI, SCA, USZ | 2 (5), 7 (5), 9 (5), 10 (10), 11 (11), 13 (5) | 19 |
| DX.5 | 700 | 53 (5/10/38) | 7.6 | 1 | 0 | 45 | 16 : ALAT, ASAT, CYP1A2, CYP3A4, ESE, ESE2025, FI2026, FSH, IA, KNDy, LSN, SCA, SSGO, SVM, TCC | 1 (5), 2 (5), 3 (6), 6 (5), 7 (5), 11 (11), 13 (5), 14 (9) | 19 |
| DX.6 | 746 | 34 (3/10/19) | 4.6 | 9 | 0 | 32 | 3 : HELP, IA, OrPha | 9 (10), 11 (12), 13 (6), 14 (5) | 5 |
| DX.7 | 864 | 52 (4/7/39) | 6.0 | 14 | 0 | 40 | 5 : HELP, HRZE, IA, PCR, PRO | 3 (5), 9 (14), 11 (8), 13 (8), 14 (7) | 3 |
| DX.8 | 611 | 29 (3/5/21) | 4.7 | 5 | 0 | 20 | 6 : AIDS, ARN, CD4, HELP, OFSP, RS | 3 (6), 9 (17), 11 (14), 13 (6) | 1 |
| DX.9 | 596 | 25 (6/8/11) | 4.2 | 8 | 0 | 31 | 16 : ABVD, AIPS, AVD, BrECADD, CD20, CD30, CSF, CYP3A4, EHA2026, HELP, IA, IIA, IIB, IRM, PD | 6 (8), 9 (17), 11 (15), 13 (6) | 0 |
| DX.10 | 588 | 27 (5/6/15) | 4.6 | 7 | 0 | 32 | 9 : CHUV2025, CR, ESH2020, EXPeRT, IA, LC, MS, PNDS, PPGL | 2 (5), 9 (15), 11 (14), 13 (6), 14 (7) | 0 |

**Exemples à relire** (extraits automatiques) :

- [SSP pt 1/fenetre] (31 mots) L’entretien précise si les vêtements ou les draps deviennent mouillés pendant le sommeil, si une chambre surchauffée explique l’épisode et si une fièvre, une perte de poids ou une toux l’accompagnent.…
- [SSP pt 2/fenetre] (31 mots) Le résumé rapporte une forme primaire chez 5,5 % des répondants et une forme primaire sévère classée 3–4 sur l’échelle de sévérité de l’hyperhidrose (Hyperhidrosis Disease Severity Scale, HDSS) chez 1…
- [SSP pt None/main] LOT 1 · situation clinique de départ (Situation as Starting Point, SSP)
- [SSP pt None/main] Il conduit d’abord à reconnaître une urgence, puis à distinguer un trouble sudoral primaire d’une maladie secondaire.
- [SSP pt None/main] Déjouer les pièges
- [SSP pt None/tableau] Le lecteur retrouve le point.
- [SSP pt 9/tableau] la fenêtre est de six semaines.
- [SSP pt 9/tableau] Le tableau secondaire reste inexpliqué et stable.
- [SSP pt 6/fenetre] Passer de 70 à 62 kg correspond à une perte de 8/70 × 100 = 11,4 %. Si cette perte est involontaire et survenue en six mois, elle franchit le seuil cité ; elle 
- [APPEL_A_BLOC2 pt None/main] (41 mots) Une cause qui n’obtient pas sa propre monographie demeure dans le différentiel lorsqu’elle change une décision : l’iatrogénie, le sevrage, une attaque de panique, un syndrome d’apnées obstructives du …
- [APPEL_A_BLOC2 pt None/main] Syndrome coronarien aigu
- [APPEL_A_BLOC2 pt None/main] Hyperhidrose focale primaire
- [APPEL_A_BLOC2 pt None/main] Symptômes vasomoteurs de la ménopause
- [APPEL_A_BLOC2 pt None/main] Le rang 1 organise le cours ;
- [APPEL_A_BLOC2 pt None/main] Le rang 2 organise le cours ;
- [APPEL_A_BLOC2 pt None/main] Le rang 3 organise le cours ;
- [DX.1 pt 6/fenetre] (32 mots) Ses doses de médicaments, sa stratégie d’oxygène du SCA et ses bolus de liquide ne sont pas importés : la stratégie propre au SCA reste celle de l’ESC et des AIPS déjà exposées.…
- [DX.1 pt 11/fenetre] (33 mots) Les contre-indications de Metalyse comprennent notamment saignement sévère, traitement anticoagulant oral efficace avec INR>1,3, affection du système nerveux central, chirurgie ou traumatisme récents …
- [DX.1 pt 2/tableau] 2181 décès par infarctus en 2023.
- [DX.1 pt 3/tableau] L’exploration la documente.
- [DX.1 pt 3/tableau] La lésion des cardiomyocytes libère de la troponine.
- [DX.1 pt 1/tableau] Le tableau relie le résultat à la décision.
- [DX.1 pt 2/tableau] Le tableau relie le résultat à la décision.
- [DX.1 pt 3/tableau] Le tableau relie le résultat à la décision.
- [DX.1 pt 9/fenetre] Exemple pédagogique fictif : une valeur initiale de 10 ng/L puis 12 ng/L à 1 heure donne une variation absolue de 2 ng/L. Le calcul dérivé est 12 − 10 = 2 ng/L 
- [DX.2 pt 8/fenetre] (36 mots) Le chapitre SFE reprend une recommandation de 2013 : après une triade de Whipple, une glycémie veineuse ≤ 0,45 g/L, une insulinémie ≥ 3 mUI/L et un peptide C ≥ 0,6 ng/mL, sans sulfamide ni glinide, ét…
- [DX.2 pt 9/fenetre] (34 mots) En cas de preuve biologique avec localisation négative, un centre expert peut discuter une tomographie par émission de positons ciblant le récepteur du peptide de typeglucagon1, ou une stimulation art…
- [DX.2 pt 1/fenetre] elle corrige sans attendre une prise de sang.
- [DX.2 pt 2/fenetre] Dans l’audit hospitalier britannique
- [DX.2 pt 3/tableau] L’examen la documente.
- [DX.2 pt 1/tableau] Le tableau relie le résultat à la décision.
- [DX.2 pt 2/fenetre] Le guide britannique
- [DX.2 pt 3/tableau] Le tableau relie le résultat à la décision.
- [DX.3 pt 8/tableau] (31 mots) Deux prélèvements positifs sont séparés de plus de douze heures, ou tous les trois, ou la majorité d’au moins quatre sont positifs avec au moins une heure entre premier et dernier.…
- [DX.3 pt 8/fenetre] (31 mots) Les mineurs comprennent une prédisposition ou l’injection de drogues, une température supérieure à 38°C, des phénomènes vasculaires emboliques, des phénomènes immunologiques et une preuve microbiologi…
- [DX.3 pt None/main] HUG les Hôpitaux universitaires de Genève ;
- [DX.3 pt None/main] CSV un fichier de données séparées par des délimiteurs.
- [DX.3 pt 1/tableau] Il influence une décision.
- [DX.3 pt 1/tableau] Le tableau relie le résultat à la décision.
- [DX.3 pt 2/tableau] Le tableau relie le résultat à la décision.
- [DX.3 pt 3/tableau] Le tableau relie le résultat à la décision.
- [DX.4 pt 2/fenetre] (32 mots) Une incidence annuelle suisse, un rapport de sexe national chiffré, une distribution cantonale et une prévalence mesurée de la seule forme focale primaire restent des données non trouvées dans les sou…
- [DX.4 pt 8/main] (36 mots) La revue suisse2017 présente une règle distincte : sudation focale dépassant les besoins thermorégulateurs depuis plus de six mois avec quatre critères parmi sept. Ces deux approches sont attribuées s…
- [DX.4 pt 1/fenetre] Primaire ou idiopathique
- [DX.4 pt 1/tableau] Il recherche particulièrement médicaments et maladie générale selon le contexte.
- [DX.4 pt 2/fenetre] Un début tardif fait toutefois rechercher plus activement une cause secondaire.
- [DX.4 pt 1/tableau] Le tableau relie le résultat à la décision.
- [DX.4 pt 2/tableau] Le tableau relie le résultat à la décision.
- [DX.4 pt 3/tableau] Le tableau relie le résultat à la décision.
- [DX.5 pt 11/fenetre] (39 mots) Les contre-indications comprennent cancer du sein actuel, suspecté ou antérieur, néoplasie hormonodépendante, saignement vaginal non exploré, maladie hépatique grave tant que non normalisée, événement…
- [DX.5 pt 2/fenetre] faute de source adaptée.
- [DX.5 pt 2/tableau] La donnée éclaire une décision.
- [DX.5 pt 2/tableau] La durée moyenne rapportée des symptômes est7,4ans.
- [DX.5 pt 1/tableau] Le tableau relie le résultat à la décision.
- [DX.5 pt 2/tableau] Le tableau relie le résultat à la décision.
- [DX.5 pt 3/tableau] Le tableau relie le résultat à la décision.
- [DX.6 pt 6/fenetre] (32 mots) Il palpe le pouls radial et note fréquence et régularité : le manuel cité appelle tachycardie une fréquence supérieure à 100/min et bradycardie une fréquence inférieure à 60/min, à interpréter dans le…
- [DX.6 pt 8/main] (34 mots) Pour Basedow, les anticorps du récepteur de la TSH, l’échographie et le contexte permettent d’établir l’étiologie selon l’European Thyroid Association (ETA), tandis que la crise reste un diagnostic cl…
- [DX.6 pt 3/tableau] L’excès hormonal prolongé fragilise l’os.
- [DX.6 pt 3/fenetre] L’installation d’une défaillance, et non un chiffre hormonal isolé, commande l’urgence.
- [DX.6 pt 4/tableau] Une crise thyrotoxique menace.
- [DX.6 pt 1/tableau] Le traitement en découle.
- [DX.6 pt 2/tableau] Le lecteur l’utilise ainsi.
- [DX.6 pt 2/tableau] La ligne directrice de 2018 synthétise des données extérieures ;
- [DX.7 pt None/main] (33 mots) Devant des sueurs nocturnes, l’objectif est de distinguer une maladie tuberculeuse de l’infection sans manifestation clinique, d’identifier une éventuelle contagiosité respiratoire et de ne pas confon…
- [DX.7 pt 2/fenetre] (34 mots) Le risque de progression est plus élevé dans les deux premières années suivant l’infection, chez le jeune enfant et chez les personnes immunodéprimées, notamment lors d’une infection par le virus de l…
- [DX.7 pt 2/fenetre] Le groupe de vingt à trente-neuf ans
- [DX.7 pt 2/fenetre] compte le plus de cas, avec 207 notifications ;
- [DX.7 pt 3/tableau] Le raisonnement garde une limite.
- [DX.7 pt 8/main] Le guide OFSP et Ligue pulmonaire suisse
- [DX.7 pt 9/fenetre] le guide recommande de l’évaluer.
- [DX.7 pt 14/tableau] parce que le guide recommande le schéma standard ?
- [DX.8 pt 11/fenetre] (33 mots) Les règles de prise avec cations sont spécifiques : magnésium et aluminium ne sont pas pris simultanément ni dans les six heures avant Biktarvy, tandis que Biktarvy peut les précéder d’au moins deux h…
- [DX.8 pt 11/fenetre] (32 mots) Après un séjour pour maladie aiguë, l’équipe vérifie la stabilité respiratoire, hémodynamique et neurologique, le traitement de la complication, la possibilité de s’alimenter et de prendre les médicam…
- [DX.8 pt 1/main] Le traitement antirétroviral contrôle la réplication et préserve ou restaure l’immunité ;
- [DX.8 pt 4/main] La démarche recherche d’abord une défaillance respiratoire, une atteinte neurologique ou visuelle et une réaction médicamenteuse sévère.
- [DX.8 pt 5/tableau] , une éruption, une douleur de gorge ou des ganglions ?
- [DX.8 pt 7/tableau] Ce tableau inflammatoire peut accompagner une primo-infection ;
- [DX.9 pt 1/fenetre] (32 mots) Le lymphome classique exprime typiquement le marqueur CD30, alors que les cellules de la forme nodulaire à prédominance lymphocytaire conservent un phénotype B avec CD20 et ne justifient pas automatiq…
- [DX.9 pt 8/fenetre] (40 mots) retient une masse médiastinale d’au moins un tiers de la largeur thoracique maximale, une atteinte extranodale, une vitesse de sédimentation supérieure à 50 mm/h sans symptômes B ou supérieure à 30 mm…
- [DX.9 pt 3/tableau] Une prolifération tumorale déforme le tissu ganglionnaire.
- [DX.9 pt 3/tableau] Le nivolumab bloque PD-1 et restaure une activité immunitaire, au prix possible d’une inflammation de tissus sains.
- [DX.9 pt 5/tableau] sans attendre le rendez-vous de routine.
- [DX.10 pt 8/main] (36 mots) Le consensus de la Société européenne d’hypertension (ESH) de 2020 et le protocole national français de 2021 fondent la confirmation d’une forme sécrétante sur les métanéphrines interprétées avec les …
- [DX.10 pt 9/tableau] (31 mots) Le protocole privilégie les libres plasmatiques en insuffisance rénale et demande prudence avec le stress de réanimation ; forte suspicion et instabilité peuvent conduire à l’imagerie sans attendre un…
- [DX.10 pt 1/fenetre] tout en ne répondant pas à toutes les masses non fonctionnelles.
- [DX.10 pt 2/fenetre] Exemple pédagogique : une personne jeune sans parent connu atteint garde une indication de discussion génétique ;
- [DX.10 pt 3/tableau] Une équipe d’anesthésie et de chirurgie expérimentée planifie préparation et surveillance.

**LanguageTool (API publique, échantillon de 36002 caractères du texte principal, 5 requêtes, 0 échecs)** : {'Miscellaneous': 2, 'Faute de frappe possible': 75, 'Grammaire': 6, 'Tours critiqués divers (barbarismes, impropriétés, solécismes, etc.)': 3, 'Punctuation point': 8, 'style rules': 12, 'Typographie': 2, 'Punctuation virgule': 1, 'Concordances': 1, 'Répétitions (Style)': 1}. La catégorie « faute de frappe » contient surtout des termes médicaux absents du dictionnaire.

- [Miscellaneous] Conjugaison erronée. Accord avec “Le référentiel…”. Le verbe devrait être à la 3ᵉ personne du singulier. — « ...une maladie secondaire.  Le référentiel PROFILES 2023 nomme G1 « abnormal perspiration »... » → ['PROFILE']
- [Grammaire] Après l’auxiliaire « a », le verbe devrait être au participe passé. Quant à l’accord, celui-ci s’accorde avec le COD s’il est placé avant l’auxiliaire ; sinon il restera au masculin singulier. — « ...e fois sur les deux pièces.  La pièce a contient les points 1 à 9 ; la pièce b contient ... » → ['contenu', 'contenue', 'contenus']
- [Tours critiqués divers (barbarismes, impropriétés, solécismes, etc.)] Cet adjectif précède généralement le nom. — « ...hoix Les données européennes illustrent des méthodes différentes L’estimation suisse institutionnelle pr... » → ['différentes méthodes']
- [Punctuation point] Un point est requis pour indiquer la fin de cette phrase. — « ...ficitaires et qualitatives dépendent du contexte  La commande sympathique active les gla... » → ['contexte.']
- [Punctuation point] Un point est requis pour indiquer la fin de cette phrase. — « ...age est un creusement visible pendant l’inspiration  Les signes fonctionnels sont rapportés... » → ['inspiration.']
- [Punctuation point] Un point est requis pour indiquer la fin de cette phrase. — « ...oit les résultats négatifs, réactifs et douteux  Les résultats d’une suspicion d’endoca... » → ['douteux.']
- [Punctuation point] Un point est requis pour indiquer la fin de cette phrase. — « ...ple de laboratoire suisse rend le bilan interprétable  Le médecin demande les métanéphrines p... » → ['interprétable.']
- [Punctuation point] Un point est requis pour indiquer la fin de cette phrase. — « ...he suit des seuils de triage propres au réactif  La bibliographie suivante est commune ... » → ['réactif.']
- [Miscellaneous] Conjugaison erronée. Accord avec “Le référentiel…”. Le verbe devrait être à la 3ᵉ personne du singulier. — « Le référentiel PROFILES 2023 nomme G1 « abnormal perspiration »... » → ['PROFILE']
- [Grammaire] Après l’auxiliaire « a », le verbe devrait être au participe passé. Quant à l’accord, celui-ci s’accorde avec le COD s’il est placé avant l’auxiliaire ; sinon il restera au masculin singulier. — « ...e fois sur les deux pièces.  La pièce a contient les points 1 à 9 ; la pièce b contient ... » → ['contenu', 'contenue', 'contenus']
- [Punctuation point] Un point est requis pour indiquer la fin de cette phrase. — « ...agnement psychologique vise un objectif fonctionnel  Les critères de retour diffèrent selon... » → ['fonctionnel.']
- [Grammaire] Vérifiez la concordance entre les verbes. — « ...ent responsable Le retour après chaleur dispose ici d’une branche militaire surtout d’e... » → ['disposent']

## 5. Score §6.3 (proxy) — LOT : **72.6 %** (seuil de dépôt : ≥ 90 % et zéro erreur critique)

Les erreurs critiques ne sont PAS détectables automatiquement : relecture médicale obligatoire.

| Cours | Score | Hors critères HUMAIN | Critères < 2 |
|---|---|---|---|
| SSP | 87.5 % | 85.5 % | 1.a 4.a 5.a 8.a 8.b 11.b 11.j 13.b |
| DX.1 | 81.2 % | 82.3 % | 2.a 5.a 5.b 6.b 8.b 9.e 9.f 11.b 11.d 11.e 11.j 13.b |
| DX.2 | 78.8 % | 85.5 % | 1.a 1.c 2.c 5.a 5.b 7.a 9.d 11.b 11.c 11.d 11.e 11.g 11.j 13.b |
| DX.3 | 63.8 % | 64.5 % | 1.a 1.c 5.a 5.b 7.a 7.b 7.c 8.a 9.a 9.b 9.e 9.f 11.a 11.b 11.c 11.d 11.e 11.g 11.j 12.a 13.b |
| DX.4 | 58.8 % | 56.5 % | 2.b 2.c 5.a 5.b 7.a 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 11.a 11.b 11.c 11.d 11.j 13.b |
| DX.5 | 61.2 % | 59.7 % | 1.a 2.b 5.a 5.b 7.a 7.b 7.c 8.a 8.b 9.a 9.b 9.e 9.f 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.j 12.a 13.b |
| DX.6 | 85.0 % | 83.9 % | 3.a 5.b 8.a 8.b 9.f 11.b 11.d 11.g 12.a 13.a 13.b |
| DX.7 | 70.0 % | 72.6 % | 2.b 2.c 4.a 5.b 8.a 8.b 9.a 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 13.a 13.b |
| DX.8 | 68.8 % | 67.7 % | 1.a 2.a 2.b 2.c 4.a 5.b 8.a 8.b 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.h 12.a 13.a 13.b |
| DX.9 | 66.2 % | 71.0 % | 1.c 2.c 4.a 5.b 7.b 8.a 8.b 9.b 9.f 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.j 13.a 13.b |
| DX.10 | 77.5 % | 83.9 % | 1.c 2.c 4.a 5.b 8.a 8.b 9.a 10.a 11.b 11.c 11.d 11.e 13.a 13.b |

Légende des critères :

- **1.a** (AUTO) Texte principal en 1 à 4 phrases
- **1.b** (PROXY) Définition issue d’une source médicale (référence [Sx])
- **1.c** (HUMAIN) Distinction avec les notions voisines
- **2.a** (PROXY) Données suisses chiffrées (OFS/OFSP/Obsan…)
- **2.b** (PROXY) Données européennes / internationales
- **2.c** (HUMAIN) Facteurs de risque / terrain / pronostic chiffré
- **3.a** (PROXY) Tableau lésion → exploration → cible thérapeutique
- **3.b** (HUMAIN) Chaque signe relié à son mécanisme
- **4.a** (PROXY) Priorités : urgence d’abord, puis étapes ordonnées
- **5.a** (PROXY) Questions d’anamnèse ciblées
- **5.b** (HUMAIN) Drapeaux rouges complets et actionnables
- **6.a** (PROXY) Le normal avant le pathologique
- **6.b** (HUMAIN) Technique de recherche + valeur diagnostique de chaque signe
- **7.a** (PROXY) Syndromes énumérés
- **7.b** (PROXY) Signes fonctionnels / signes physiques séparés
- **7.c** (HUMAIN) Chaque signe défini en fenêtre, avec geste et mécanisme
- **8.a** (PROXY) Critères diagnostiques : société savante + année + seuils
- **8.b** (PROXY) Ce qui ne suffit pas à poser le diagnostic
- **9.a** (PROXY) Gold standard dit (existe/n’existe pas) avec Se/Spé/seuil
- **9.b** (PROXY) 1re / 2e intention et critère de passage
- **9.c** (PROXY) Prescription : indication, moment, préparation
- **9.d** (PROXY) Tableau d’interprétation normal (SI) | seuil | signification | conduite
- **9.e** (PROXY) Cas de figure : positif / négatif / limite / discordant
- **9.f** (PROXY) Alternatives : grossesse, enfant, DFGe < 30, iode, pacemaker
- **10.a** (PROXY) Arbre : chaque embranchement → décision
- **11.a** (PROXY) But du traitement chiffré
- **11.b** (PROXY) Ordre de la prise en charge et pourquoi (A→D)
- **11.c** (HUMAIN) Formes compliquées : urgence + chronologie (fenêtre)
- **11.d** (PROXY) Formes non compliquées : mesures générales puis ordre
- **11.e** (HUMAIN) Médicament : classe, PK/PD, EI, ®, dose AIPS, durée, CI, interactions
- **11.f** (PROXY) Traitements non médicamenteux
- **11.g** (PROXY) Volets social / professionnel (LAMal, LAA, LAI, conduite, arrêt)
- **11.h** (PROXY) Situations spéciales : grossesse/allaitement, âgé, enfant, IH, IR (DFGe)
- **11.i** (PROXY) Surveillance : quoi, quand, pourquoi, seuils d’arrêt
- **11.j** (PROXY) Critères de sortie un par un
- **11.k** (PROXY) Pronostic / guérison / recherche 2026
- **12.a** (PROXY) Prévention primaire / secondaire / tertiaire, reco suisses
- **13.a** (AUTO) Points clés : 3 à 6 phrases
- **13.b** (HUMAIN) Contenu : ce qu’un médecin ne doit jamais oublier
- **14.a** (PROXY) Pièges réels de l’examen, chacun avec sa bonne réponse

## 6. Contrôles techniques §10 / §16 par fichier

| Fichier | Octets | FIN_FICHIER | 90–200 Ko | title= | Tableaux (enveloppés) | Lignes > 3000 | script/img/CSS ext. | `<details>` | Sources | Mention « non validé » | Export Google Docs |
|---|---|---|---|---|---|---|---|---|---|---|---|
| LOT_1_Appel_A_V7_Plan_et_Liste_V9_a.html | 156277 | oui | oui | 0 | 27 (27) | 0 | 0/0/0 | 52 | oui | oui | non |
| LOT_1_Appel_A_V7_Plan_et_Liste_V9_b.html | 147392 | oui | oui | 0 | 17 (17) | 0 | 0/0/0 | 34 | oui | oui | non |
| LOT_1_Appel_A_Validation_et_Audit.html | 44628 | oui | non | 0 | 16 (16) | 0 | 0/0/0 | 14 | oui | oui | non |
| LOT_1_Appel_B_Partie_1_DX.1_a_DX.2_INDEX_TRAVAIL.html | 1219 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| LOT_1_Appel_B_Partie_2_DX.3_a_DX.5_INDEX_TRAVAIL.html | 1219 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| LOT_1_Appel_B_Partie_3_DX.6_a_DX.7_INDEX_TRAVAIL.html | 1219 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| LOT_1_Appel_B_Partie_4_DX.8_a_DX.10_INDEX_TRAVAIL.html | 1223 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
| Versions de travail — Appel B — non validées/LOT_1_Appel_B_V7_Partie_1_DX.1_a_DX.2_a_r1.html | 130912 | oui | oui | 0 | 22 (22) | 0 | 0/0/0 | 30 | oui | oui | non |
| Versions de travail — Appel B — non validées/LOT_1_Appel_B_V7_Partie_1_DX.1_a_DX.2_b_r1.html | 120298 | oui | oui | 0 | 23 (23) | 0 | 0/0/0 | 30 | oui | oui | non |
| Versions de travail — Appel B — non validées/LOT_1_Appel_B_V7_Partie_2_DX.3_a_DX.5_a_r1.html | 140728 | oui | oui | 0 | 27 (27) | 0 | 0/0/0 | 34 | oui | oui | non |
| Versions de travail — Appel B — non validées/LOT_1_Appel_B_V7_Partie_2_DX.3_a_DX.5_b_r1.html | 130474 | oui | oui | 0 | 24 (24) | 0 | 0/0/0 | 31 | oui | oui | non |
| Versions de travail — Appel B — non validées/LOT_1_Appel_B_V7_Partie_3_DX.6_a_DX.7_a_r2.html | 95449 | oui | oui | 0 | 19 (19) | 0 | 0/0/0 | 31 | oui | oui | non |
| Versions de travail — Appel B — non validées/LOT_1_Appel_B_V7_Partie_3_DX.6_a_DX.7_b_r2.html | 122026 | oui | oui | 0 | 23 (23) | 0 | 0/0/0 | 48 | oui | oui | non |
| Versions de travail — Appel B — non validées/LOT_1_Appel_B_V7_Partie_4_DX.8_a_DX.10_a_r1.html | 109928 | oui | oui | 0 | 20 (20) | 0 | 0/0/0 | 48 | oui | oui | non |
| Versions de travail — Appel B — non validées/LOT_1_Appel_B_V7_Partie_4_DX.8_a_DX.10_b_r1.html | 135292 | oui | oui | 0 | 24 (24) | 0 | 0/0/0 | 57 | oui | oui | non |
