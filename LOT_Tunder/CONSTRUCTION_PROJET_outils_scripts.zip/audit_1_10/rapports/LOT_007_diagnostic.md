# LOT_007 — diagnostic automatique (phase 0)

> Généré par `outils/` (scripts déterministes, aucun appel à une IA). Les notes PROXY/HUMAIN sont **indicatives** : elles signalent où regarder ; l’auditeur médical tranche.

## 1. Fichiers analysés

| Type | Fichier | Octets |
|---|---|---|
| Appel A | LOT_7_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.html | 164115 |

## 2. Découpage et couverture des 14 points

| Cours | Titre | Points | Mots | Points absents / quasi vides | Anomalies |
|---|---|---|---|---|---|
| SSP | SSP — LOT_7_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.html | 14/14 | 14383 | — | — |
| APPEL_A_BLOC2 | Bloc 2 — Liste différentielle fixée et comparaison des dix d | (bloc 2 de l’Appel A : 2799 mots, None tableaux) | | | |

## 3. Examens complémentaires (exigence : cliquable + fenêtre à 2 onglets « Principe » / « Interprétation »)

| Cours | Mentions | Cliquables | Avec 2 onglets | BIO | FONC | IMG | AUTRE |
|---|---|---|---|---|---|---|---|
| SSP | 129 | 11 | 0 | 101 | 2 | 25 | 1 |
| APPEL_A_BLOC2 | 8 | 0 | 0 | 8 | 0 | 0 | 0 |
| **Total** | **137** | **11** (8.0 %) | **0** | | | | |

Fenêtres à 2 onglets détectées dans le LOT : **0**.

**Examens distincts nécessitant une fenêtre Principe / Interprétation** (19) :

| Examen | Cat. | Mentions | Cliquables | Cours |
|---|---|---|---|---|
| Tryptase | BIO | 25 | 1 | APPEL_A_BLOC2, SSP |
| Bilan hépatique | BIO | 23 | 0 | SSP |
| Métanéphrines | BIO | 14 | 1 | APPEL_A_BLOC2, SSP |
| 5-HIAA | BIO | 12 | 2 | APPEL_A_BLOC2, SSP |
| FSH / LH / œstradiol | BIO | 11 | 1 | SSP |
| IRM | IMG | 11 | 1 | SSP |
| TSH | BIO | 9 | 2 | SSP |
| Scanner / TDM | IMG | 8 | 1 | SSP |
| Créatinine / DFGe | BIO | 5 | 0 | SSP |
| Échographie (générique) | IMG | 5 | 1 | SSP |
| T4 / T3 libres | BIO | 4 | 1 | SSP |
| Glycémie | BIO | 3 | 0 | APPEL_A_BLOC2, SSP |
| Biopsie / histologie | AUTRE | 1 | 0 | SSP |
| hCG (test de grossesse) | BIO | 1 | 0 | SSP |
| Ionogramme / électrolytes | BIO | 1 | 0 | SSP |
| Chromogranine A | BIO | 1 | 0 | SSP |
| Scintigraphie (thyroïde, MIBG, DOTATATE…) | IMG | 1 | 0 | SSP |
| ECG | FONC | 1 | 0 | SSP |
| Oxymétrie / saturation | FONC | 1 | 0 | SSP |

## 4. Style (§7)

Phrases nominales : estimation spaCy `fr_core_news_md` + règles ; l’échantillon de contrôle montre encore des faux positifs (verbes non reconnus) → chiffre **majorant**, à relire.

| Cours | Phrases | Nominales (texte/fen./tabl.) | % | > 30 mots | Symboles à la place d’un verbe | Paragraphes sans connecteur | Sigles non développés à la 1re occurrence | Points > 4 phrases dans le texte principal | Phrases creuses / méta |
|---|---|---|---|---|---|---|---|---|---|
| SSP | 915 | 89 (13/12/54) | 9.7 | 6 | 4 | 43 | 20 : ALAT, APPEL, ASAT, CYP1A2, DCI, DFGe, EAACI, FSH, HELP, HIAA, HUG, IRM, KIT, LSN, OFFICIEL | 11 (5) | 2 |
| APPEL_A_BLOC2 | 107 | 12 (0/0/12) | 11.2 | 0 | 0 | 0 | 0 :  | — | 0 |

**Exemples à relire** (extraits automatiques) :

- [SSP pt 5/fenetre] (35 mots) Chez un patient stable, une diarrhée persistante, un amaigrissement inexpliqué, une masse, des adénopathies, des accès sans déclencheur reproductible ou des réactions systémiques répétées justifient u…
- [SSP pt 9/fenetre] (31 mots) Dans un cas fictif construit uniquement pour illustrer l’arithmétique, Tb vaut 10 µg/L et Ta vaut 15 µg/L. Le calcul donne 1,2 × 10 = 12, puis 12 + 2 = 14 µg/L. La valeur aiguë de 15 dépasse le seuil …
- [SSP pt None/main] Flushing / bouffées vasomotrices
- [SSP pt None/main] Périmètre principal adulte ;
- [SSP pt None/main] État documentaire : 21 octobre 2026 (Europe/Zurich).
- [SSP pt 9/summary] si le contexte le justifie
- [SSP pt 9/tableau] si le contexte le justifie
- [SSP pt 9/fenetre] Calcul dérivé : S (µg/L) = 1,2 × Tb (µg/L) + 2 µg/L ; une valeur Ta > S soutient l’activation mastocytaire.
- [APPEL_A_BLOC2 pt None/tableau] DX.1 — Flushing physiologique émotionnel, thermique ou d’effort 1er rang — fréquence non quantifiée (Suisse)
- [APPEL_A_BLOC2 pt None/tableau] Flushing médicamenteux ou lié à un complément 3e rang —
- [APPEL_A_BLOC2 pt None/tableau] Rosacée avec composante de flushing 4e rang — fréquence non quantifiée (Suisse)

**LanguageTool (API publique, échantillon de 5931 caractères du texte principal, 1 requêtes, 0 échecs)** : {'Faute de frappe possible': 8, 'Miscellaneous': 1, 'Tours critiqués divers (barbarismes, impropriétés, solécismes, etc.)': 1}. La catégorie « faute de frappe » contient surtout des termes médicaux absents du dictionnaire.

- [Miscellaneous] Conjugaison erronée. Accord avec “Le référentiel…”. Le verbe devrait être à la 3ᵉ personne du singulier. — « ...t d’audit documentaire.  Le référentiel PROFILES 2023 attribue le flushing au SSP G7. Le... » → ['PROFILE']
- [Tours critiqués divers (barbarismes, impropriétés, solécismes, etc.)] Cet adjectif précède généralement le nom. — « ... Si la réponse attendue manque ou si un signe nouveau apparaît, il reprend le raisonnement au... » → ['nouveau signe']

## 5. Score §6.3 (proxy) — LOT : **71.2 %** (seuil de dépôt : ≥ 90 % et zéro erreur critique)

Les erreurs critiques ne sont PAS détectables automatiquement : relecture médicale obligatoire.

| Cours | Score | Hors critères HUMAIN | Critères < 2 |
|---|---|---|---|
| SSP | 71.2 % | 72.6 % | 1.c 2.a 3.a 4.a 6.b 7.b 8.a 8.b 9.b 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.j 13.b |

Légende des critères :

- **1.a** (AUTO) Texte principal en 1 à 4 phrases
- **1.b** (PROXY) Définition issue d’une source médicale (référence [Sx])
- **1.c** (HUMAIN) Distinction avec les notions voisines
- **2.a** (PROXY) Données suisses chiffrées (OFS/OFSP/Obsan…)
- **2.b** (PROXY) Données européennes / internationales
- **2.c** (HUMAIN) Facteurs de risque / terrain / pronostic chiffré
- **3.a** (PROXY) Tableau lésion → exploration → cible thérapeutique
- **3.b** (HUMAIN) Chaque signe relié à son mécanisme
- **4.a** (PROXY) Priorités : urgence d’abord, puis étapes ordonnées
- **5.a** (PROXY) Questions d’anamnèse ciblées
- **5.b** (HUMAIN) Drapeaux rouges complets et actionnables
- **6.a** (PROXY) Le normal avant le pathologique
- **6.b** (HUMAIN) Technique de recherche + valeur diagnostique de chaque signe
- **7.a** (PROXY) Syndromes énumérés
- **7.b** (PROXY) Signes fonctionnels / signes physiques séparés
- **7.c** (HUMAIN) Chaque signe défini en fenêtre, avec geste et mécanisme
- **8.a** (PROXY) Critères diagnostiques : société savante + année + seuils
- **8.b** (PROXY) Ce qui ne suffit pas à poser le diagnostic
- **9.a** (PROXY) Gold standard dit (existe/n’existe pas) avec Se/Spé/seuil
- **9.b** (PROXY) 1re / 2e intention et critère de passage
- **9.c** (PROXY) Prescription : indication, moment, préparation
- **9.d** (PROXY) Tableau d’interprétation normal (SI) | seuil | signification | conduite
- **9.e** (PROXY) Cas de figure : positif / négatif / limite / discordant
- **9.f** (PROXY) Alternatives : grossesse, enfant, DFGe < 30, iode, pacemaker
- **10.a** (PROXY) Arbre : chaque embranchement → décision
- **11.a** (PROXY) But du traitement chiffré
- **11.b** (PROXY) Ordre de la prise en charge et pourquoi (A→D)
- **11.c** (HUMAIN) Formes compliquées : urgence + chronologie (fenêtre)
- **11.d** (PROXY) Formes non compliquées : mesures générales puis ordre
- **11.e** (HUMAIN) Médicament : classe, PK/PD, EI, ®, dose AIPS, durée, CI, interactions
- **11.f** (PROXY) Traitements non médicamenteux
- **11.g** (PROXY) Volets social / professionnel (LAMal, LAA, LAI, conduite, arrêt)
- **11.h** (PROXY) Situations spéciales : grossesse/allaitement, âgé, enfant, IH, IR (DFGe)
- **11.i** (PROXY) Surveillance : quoi, quand, pourquoi, seuils d’arrêt
- **11.j** (PROXY) Critères de sortie un par un
- **11.k** (PROXY) Pronostic / guérison / recherche 2026
- **12.a** (PROXY) Prévention primaire / secondaire / tertiaire, reco suisses
- **13.a** (AUTO) Points clés : 3 à 6 phrases
- **13.b** (HUMAIN) Contenu : ce qu’un médecin ne doit jamais oublier
- **14.a** (PROXY) Pièges réels de l’examen, chacun avec sa bonne réponse

## 6. Contrôles techniques §10 / §16 par fichier

| Fichier | Octets | FIN_FICHIER | 90–200 Ko | title= | Tableaux (enveloppés) | Lignes > 3000 | script/img/CSS ext. | `<details>` | Sources | Mention « non validé » | Export Google Docs |
|---|---|---|---|---|---|---|---|---|---|---|---|
| LOT_7_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.html | 164115 | oui | oui | 0 | 29 (29) | 0 | 0/0/0 | 53 | oui | oui | non |
| LOT_7_Appel_B_Partie_1_DX.1_a_DX.2_INDEX_SOURCE_ANTERIEURE.html | 1226 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | non | non |
| LOT_7_Appel_B_Partie_2_DX.3_a_DX.5_INDEX_SOURCE_ANTERIEURE.html | 1226 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | non | non |
| LOT_7_Appel_B_Partie_3_DX.6_a_DX.7_INDEX_SOURCE_ANTERIEURE.html | 1226 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | non | non |
| LOT_7_Appel_B_Partie_4_DX.8_a_DX.10_A_REDIGER.html | 962 | non | non | 0 | 0 (0) | 0 | 0/0/0 | 0 | non | oui | non |
