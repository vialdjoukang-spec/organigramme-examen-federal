# LOT_003 — diagnostic automatique (phase 0)

> Généré par `outils/` (scripts déterministes, aucun appel à une IA). Les notes PROXY/HUMAIN sont **indicatives** : elles signalent où regarder ; l’auditeur médical tranche.

## 1. Fichiers analysés

| Type | Fichier | Octets |
|---|---|---|
| Appel A | LOT_3_Appel_A_V7_Plan_et_Liste_TRAVAIL_r1.html | 96174 |
| Partie 1 | LOT_3_Appel_B_V5_Ultra_Pedagogique_Partie_1_D3.1_a_D3.2.gdoc_export.html | 227945 |
| Partie 2 | LOT_3_Appel_B_V5_Ultra_Pedagogique_Partie_2_D3.3_a_D3.5.gdoc_export.html | 177475 |
| Partie 3 | LOT_3_Appel_B_V5_Ultra_Pedagogique_Partie_3_D3.6_a_D3.7.gdoc_export.html | 147465 |
| Partie 4 | LOT_3_Appel_B_V5_Ultra_Pedagogique_Partie_4_D3.8_a_D3.10.gdoc_export.html | 207758 |

## 2. Découpage et couverture des 14 points

| Cours | Titre | Points | Mots | Points absents / quasi vides | Anomalies |
|---|---|---|---|---|---|
| SSP | SSP — LOT_3_Appel_A_V7_Plan_et_Liste_TRAVAIL_r1.html | 14/14 | 4842 | — | — |
| APPEL_A_BLOC2 | Bloc 2 — Dix diagnostics discriminants : liste provisoire | (bloc 2 de l’Appel A : 2680 mots, None tableaux) | | | |
| DX.1 | D3.1 — Diabète sucré décompensé (Inaugural, Acidocétose diab | 14/14 | 2470 | — | — |
| DX.2 | D3.2 — Déshydratation intracellulaire hypernatrémique (Sujet | 13/14 | 1180 | — / quasi vides : 8 | point 8 (Diagnostic positif et critères) quasi vide (21 mots) |
| DX.3 | D3.3 — Xérostomie iatrogène médicamenteuse et Syndrome de Sj | 13/14 | 1178 | — / quasi vides : 8 | point 8 (Diagnostic positif et critères) quasi vide (21 mots) |
| DX.4 | D3.4 — Polydipsie primaire (Potomanie psychogène et Dipsoman | 14/14 | 1334 | — | — |
| DX.5 | D3.5 — Diurèse osmotique ou aquarétique iatrogène (Inhibiteu | 14/14 | 1304 | — | — |
| DX.6 | D3.6 — Insuffisance cardiaque chronique et Cirrhose hépatiqu | 14/14 | 1523 | — | — |
| DX.7 | D3.7 — Hypercalcémie (Hyperparathyroïdie primaire, Hypercalc | 13/14 | 1634 | — / quasi vides : 8 | point 8 (Diagnostic positif et critères) quasi vide (22 mots); point 11 : 2 titres concurrents → 11. Prise en charge selon les recommandations suisses. | 3. Traitement de fond anti-ostéoclastique (débuté à J1, mais délai d'action de 48 à 72 heures) :; titre « 3. Traitement de fond anti-ostéoclastiqu |
| DX.8 | D3.8 — Maladie rénale chronique (Isosthénurie) et Syndrome d | 13/14 | 1699 | — / quasi vides : 8 | point 7 : 3 titres concurrents → 2. Les 4 moteurs simultanés du Syndrome de Levée d'Obstacle (SLO) après sondage d'un globe vésical : | 7. Approche syndromique. | 2. Tableau de prise en charge mathématique du Syndrome de Levée d'Obstacle (SLO : Diurèse > 200 mL/h) :; point 8 (Diagnostic positif et c |
| DX.9 | D3.9 — Déficit en Arginine-Vasopressine (AVP-D / Diabète ins | 13/14 | 1981 | — / quasi vides : 8 | point 7 : 2 titres concurrents → 7. Approche syndromique. | 2. Les 2 signes cardinaux à l'IRM hypothalamo-hypophysaire :; point 8 (Diagnostic positif et critères) quasi vide (17 mots); titre « 2. Les 2 signes cardinaux à l'IRM hypothalamo-hypophysaire : » numéroté 2 mais correspond au point 7 (§6) |
| DX.10 | D3.10 — Résistance à l'Arginine-Vasopressine (AVP-R / Diabèt | 14/14 | 1761 | — | — |

## 3. Examens complémentaires (exigence : cliquable + fenêtre à 2 onglets « Principe » / « Interprétation »)

| Cours | Mentions | Cliquables | Avec 2 onglets | BIO | FONC | IMG | AUTRE |
|---|---|---|---|---|---|---|---|
| SSP | 70 | 3 | 0 | 68 | 0 | 2 | 0 |
| APPEL_A_BLOC2 | 62 | 3 | 0 | 59 | 3 | 0 | 0 |
| DX.1 | 53 | 0 | 0 | 52 | 1 | 0 | 0 |
| DX.2 | 31 | 0 | 0 | 30 | 0 | 1 | 0 |
| DX.3 | 7 | 0 | 0 | 5 | 0 | 2 | 0 |
| DX.4 | 16 | 0 | 0 | 15 | 0 | 1 | 0 |
| DX.5 | 27 | 0 | 0 | 27 | 0 | 0 | 0 |
| DX.6 | 48 | 0 | 0 | 42 | 1 | 5 | 0 |
| DX.7 | 84 | 0 | 0 | 74 | 3 | 6 | 1 |
| DX.8 | 23 | 0 | 0 | 22 | 0 | 1 | 0 |
| DX.9 | 35 | 0 | 0 | 30 | 0 | 5 | 0 |
| DX.10 | 15 | 0 | 0 | 13 | 0 | 1 | 1 |
| **Total** | **471** | **6** (1.3 %) | **0** | | | | |

Fenêtres à 2 onglets détectées dans le LOT : **0**.

**Examens distincts nécessitant une fenêtre Principe / Interprétation** (32) :

| Examen | Cat. | Mentions | Cliquables | Cours |
|---|---|---|---|---|
| Ionogramme / électrolytes | BIO | 232 | 4 | APPEL_A_BLOC2, DX.1, DX.10, DX.2, DX.4, DX.5, DX.6, DX.7, DX.8, DX.9, SSP |
| Glycémie | BIO | 68 | 2 | APPEL_A_BLOC2, DX.1, DX.2, DX.3, DX.4, DX.5, SSP |
| Créatinine / DFGe | BIO | 51 | 0 | APPEL_A_BLOC2, DX.1, DX.10, DX.2, DX.4, DX.5, DX.6, DX.7, DX.8, DX.9, SSP |
| Bilan phosphocalcique / PTH | BIO | 21 | 0 | DX.7, DX.8 |
| BNP / NT-proBNP | BIO | 12 | 0 | DX.6 |
| IRM | IMG | 8 | 0 | DX.4, DX.9, SSP |
| ECG | FONC | 8 | 0 | APPEL_A_BLOC2, DX.1, DX.6, DX.7 |
| Peptide C / insuline | BIO | 6 | 0 | DX.1, DX.9 |
| Cortisol / test de freinage | BIO | 6 | 0 | DX.1, DX.9 |
| Bilan hépatique | BIO | 6 | 0 | DX.5, DX.6 |
| ECBU / analyse d’urine | BIO | 4 | 0 | APPEL_A_BLOC2, DX.5 |
| HbA1c | BIO | 4 | 0 | DX.1 |
| Lactate | BIO | 4 | 0 | DX.1 |
| Scanner / TDM | IMG | 4 | 0 | DX.2, DX.7 |
| Électrophorèse des protéines | BIO | 4 | 0 | DX.3, DX.7 |
| Échographie (générique) | IMG | 4 | 0 | DX.10, DX.3, DX.6, DX.8 |
| TSH | BIO | 4 | 0 | DX.10, DX.9 |
| Gaz du sang | BIO | 3 | 0 | DX.1 |
| Échocardiographie (ETT/ETO) | IMG | 3 | 0 | DX.3, DX.6 |
| Prolactine | BIO | 3 | 0 | DX.9 |
| Doppler | IMG | 2 | 0 | DX.6 |
| Coagulation (TP/INR/TCA/fibrinogène) | BIO | 2 | 0 | DX.6 |
| Tests génétiques | AUTRE | 2 | 0 | DX.10, DX.7 |
| FSH / LH / œstradiol | BIO | 2 | 0 | DX.9 |
| Lymphocytes CD4 | BIO | 1 | 0 | DX.3 |
| Toxicologie / dosage médicamenteux | BIO | 1 | 0 | DX.6 |
| Échographie cervicale / thyroïdienne | IMG | 1 | 0 | DX.7 |
| Scintigraphie (thyroïde, MIBG, DOTATATE…) | IMG | 1 | 0 | DX.7 |
| TEP / PET-scan | IMG | 1 | 0 | DX.7 |
| T4 / T3 libres | BIO | 1 | 0 | DX.9 |
| Ponction lombaire / LCR | BIO | 1 | 0 | DX.9 |
| hCG (test de grossesse) | BIO | 1 | 0 | DX.9 |

## 4. Style (§7)

Phrases nominales : estimation spaCy `fr_core_news_md` + règles ; l’échantillon de contrôle montre encore des faux positifs (verbes non reconnus) → chiffre **majorant**, à relire.

| Cours | Phrases | Nominales (texte/fen./tabl.) | % | > 30 mots | Symboles à la place d’un verbe | Paragraphes sans connecteur | Sigles non développés à la 1re occurrence | Points > 4 phrases dans le texte principal | Phrases creuses / méta |
|---|---|---|---|---|---|---|---|---|---|
| SSP | 372 | 72 (9/6/52) | 19.4 | 1 | 5 | 14 | 14 : ACTION, AIPS, AQP2, AVANT, AVP, ESS, IRM, LECTURE, OBLIGATOIRE, OFSP, PAS, SGLT2, STATUT, TOUTE | 11 (9) | 0 |
| APPEL_A_BLOC2 | 185 | 76 (0/42/29) | 41.1 | 0 | 0 | 12 | 3 : DFGe, EASD, ECG | — | 0 |
| DX.1 | 157 | 73 (51/0/22) | 46.5 | 10 | 12 | 7 | 26 : ACR, ADA, AMPK, CD3, CPT, CoA, DFGe, DT1, EASD, GABA, GAD65, GIP, GLP, HGPO, HM | 3 (5), 7 (5), 9 (34), 11 (28) | 2 |
| DX.2 | 60 | 33 (28/0/5) | 55.0 | 7 | 3 | 2 | 3 : AVP, DEC, EMS | 9 (17), 11 (8) | 0 |
| DX.3 | 63 | 33 (28/0/5) | 52.4 | 8 | 0 | 1 | 22 : ACR, AQP5, BAFF, CD4, CD40L, DU, ELISA, EULAR, FcRn, IgG, IgG4, OMERACT, ORL, OSS, SCORE | 9 (9), 11 (16) | 0 |
| DX.4 | 59 | 20 (16/0/4) | 33.9 | 15 | 0 | 3 | 12 : AINS, AVP, CODDI, ESE, GLP, IRM, ISRS, NEJM, NaCl, OVLT, SIADH, SSPP | 3 (5), 9 (11), 11 (11) | 0 |
| DX.5 | 63 | 27 (20/0/7) | 42.9 | 12 | 2 | 2 | 7 : ALAT, ASAT, FEVG, NKCC2, SADMANS, SGLT2, SGLT2i | 3 (10), 11 (10) | 0 |
| DX.6 | 84 | 44 (40/0/4) | 52.4 | 12 | 5 | 4 | 24 : AKI, ARM, AVP, BNP, DFG, DFGe, ECG, ESC, FEVG, FINEARTS, GIP, GLP, HF, INR, MELD | 3 (5), 9 (23), 11 (25) | 0 |
| DX.7 | 84 | 40 (34/0/6) | 47.6 | 10 | 3 | 2 | 22 : CASR, CT, DS, FHH, IIa, IM, IgG2, JAMAIS, MIBI, NE, NKCC2, NaPi, ORL, PET, PTH | 3 (5), 9 (23), 11 (24) | 0 |
| DX.8 | 104 | 61 (52/0/9) | 58.7 | 8 | 7 | 9 | 21 : ACEi, ACR, AINS, ARA2, AVP, CKD, EPI, FLOW, G3b, GLP, IEC, KDIGO, NSAIDs, NaCl, PNa | 3 (8), 7 (8), 9 (22), 11 (20) | 0 |
| DX.9 | 111 | 49 (40/0/9) | 44.1 | 15 | 1 | 3 | 18 : ACTH, AMPc, CT, CTLA, ELLE, ESE, FSH, IGF, IRM, IgG4, LCR, LH, MASQUE, NEJM, SC | 3 (15), 4 (7), 7 (11), 9 (12), 11 (20) | 0 |
| DX.10 | 86 | 39 (31/0/8) | 45.3 | 16 | 6 | 4 | 9 : AMILORIDE, AMPK, COX, EP2, EP4, GMPc, HCTZ, NCC, UT | 3 (15), 9 (8), 11 (16) | 0 |

**Exemples à relire** (extraits automatiques) :

- [SSP pt 11/fenetre] (36 mots) Avant de prescrire un analogue de la vasopressine, le médecin vérifie que la physiopathologie correspond à un déficit démontré et que la personne est capable de percevoir la soif, de boire et de suivr…
- [SSP pt None/main] OBLIGATOIRE AVANT TOUTE ACTION — STATUT
- [SSP pt None/main] , version de travail r1, non validée médicalement.
- [SSP pt None/main] G3 — Soif excessive et polydipsie
- [SSP pt 9/fenetre] Une approximation en unités SI est : osmolalité efficace (mmol/kg environ) = 2 × sodium (mmol/L) + glucose (mmol/L). Exemple dérivé, recalculé : pour Na = 145 m
- [APPEL_A_BLOC2 pt None/tableau] Diabète sucré de type 2 avec diurèse osmotique
- [APPEL_A_BLOC2 pt None/tableau] Soif, nycturie, perte pondérale éventuelle ;
- [APPEL_A_BLOC2 pt None/tableau] Glycémie, cétonémie si état aigu, fonction rénale
- [DX.1 pt 3/main] (31 mots) Transporter 2, segment S1 du tube contourné proximal, 90 % de la réabsorption) et SGLT1 (segment S3, 10 %), c'est-à-dire au-delà du seuil rénal de 10,0 mmol/L (180 mg/dL), le glucose non réabsorbé res…
- [DX.1 pt 4/main] (31 mots) Le clinicien distingue la décompensation hyperglycémique simple de l'ACD, de l'EHH et de l'Acidocétose euglycémique (glycémie < 11,1 mmol/L mais cétonémie ≥ 3,0 mmol/L chez un patient sous inhibiteur …
- [DX.1 pt 1/main] Diabétique (ACD) et l'État Hyperosmolaire Hyperglycémique (EHH)
- [DX.1 pt 3/main] Cétogenèse hépatique (ACD) vs Hyperosmolalité pure sans cétose (EHH)
- [DX.1 pt 3/tableau] Carence absolue en insuline (peptide C effondré)
- [DX.1 pt 8/main] sont synthétisés dans la fenêtre interactive ci-dessous.
- [DX.1 pt 11/main] détaillés dans le tableau interactif ci-dessous.
- [DX.1 pt 3/tableau] Activation de la Lipase hormono-sensible → libération d'Acides Gras Libres (AGL) → entrée dans la mitochondrie hépatique via la CPT-1 (Carnitine Palmitoyltransf
- [DX.2 pt 1/main] (32 mots) La Déshydratation intracellulaire (DIC) est la conséquence obligatoire d'une Hypernatrémie () et d'une hyperosmolalité plasmatique efficace (), qui traduit toujours un déficit relatif ou absolu en eau…
- [DX.2 pt 2/main] (32 mots) Elle représente 15 % des situations de soif pathologique et touche 1 à 3 % des patients âgés hospitalisés en Suisse (jusqu'à 30 % en réanimation), avec une mortalité hospitalière associée de 40 % lors…
- [DX.2 pt 4/main] Hypernatrémie hypovolémique (déshydratation globale : perte d'eau > perte de sel) ; 2)
- [DX.2 pt 4/main] Hypernatrémie euvolémique (perte d'eau pure : insensible ou diabète insipide) ;
- [DX.2 pt 4/main] Hypernatrémie hypervolémique (surcharge iatrogène en NaCl hypertonique ou bicarbonate de sodium).
- [DX.2 pt 4/main] Le clinicien évalue simultanément le compartiment extracellulaire pour classer l'hypernatrémie en 3 catégories : 1) Hypernatrémie hypovolémique (déshydratation 
- [DX.3 pt 3/main] (41 mots) La sécrétion aqueuse des glandes salivaires (parotides, sous-mandibulaires, sublinguales) est commandée par le système nerveux parasympathique via la liaison de l'acétylcholine sur les récepteurs musc…
- [DX.3 pt 5/main] (31 mots) L'interrogatoire recherche le signe du biscuit sec (impossibilité d'avaler un aliment sec sans boire d'eau), une sensation de sable dans les yeux (xérophtalmie), et calcule le score de charge antichol…
- [DX.3 pt 4/main] d'abord un vrai syndrome polyuro-polydipsique (diabète sucré)
- [DX.3 pt 6/main] -buccale objective une langue dépapillée, sèche, érythémateuse et fissurée ("langue rôtie")
- [DX.3 pt 6/main] , l'absence du lac salivaire au plancher buccal, des caries cervicales du collet dentaire, une perlèche commissurale candidosique et parfois une hypertrophie parotidienne
- [DX.4 pt 1/main] (43 mots) La Polydipsie primaire (ou Potomanie) est un trouble primitif de la prise de boisson caractérisé par une ingestion excessive d'eau (souvent > 4 à 10 L/24h) non motivée par une hyperosmolalité ni par u…
- [DX.4 pt 4/main] (32 mots) Le défi diagnostique majeur consiste à différencier la polydipsie primaire du Déficit en AVP (Diabète insipide central) partiel ou complet, car leurs traitements sont strictement opposés et l'erreur d…
- [DX.4 pt 2/main] Les patients atteints de troubles psychiatriques chroniques (présente chez 6 à 20 % des patients souffrant de schizophrénie chronique ou de troubles anxieux/personnalité 
- [DX.4 pt 2/main] Les jeunes adultes ("health enthusiasts") pratiquant une hyperhydratation volontaire excessive (ESE / SSPP).
- [DX.4 pt 6/main] En cas d'intoxication aiguë par l'eau (), l'examen neurologique objective des nausées, des céphalées, une confusion, une ataxie puis des crises convulsives tonico
- [DX.5 pt 1/main] (40 mots) La Polyurie et polydipsie iatrogène résulte de l'administration de médicaments qui inhibent la réabsorption tubulaire rénale du glucose (gliflozines), des électrolytes (diurétiques), qui filtrent une …
- [DX.5 pt 2/main] (39 mots) Avec la prescription massive des inhibiteurs SGLT2 en Suisse (devenus la 1ère ligne du diabète de type 2, de l'insuffisance cardiaque quelle que soit la FEVG et de la maladie rénale chronique), cette …
- [DX.5 pt 3/main] Cibles Moléculaires par Segment Tubulaire & Formules de la Fraction d'Excrétion du Sodium (FENa)
- [DX.5 pt 3/main] Formules de la Fraction d'Excrétion du Sodium () et de l'Urée () :
- [DX.5 pt 3/main] Créatinine plasmatique) / (Urée plasmatique ×
- [DX.5 pt 3/main] FENa (%) = [(Na⁺ urinaire × Créatinine plasmatique) / (Na⁺ plasmatique × Créatinine urinaire)] × 100
- [DX.6 pt 1/main] (59 mots) Dans l'Insuffisance Cardiaque (IC) et la Cirrhose hépatique décompensée, le patient éprouve une soif non osmotique paradoxale : bien que son stock corporel total d'eau et de sodium soit massivement au…
- [DX.6 pt 2/main] (33 mots) En Suisse (~200 000 patients atteints d'IC selon la Société Suisse de Cardiologie / ESC), une détresse liée à la soif (Thirst Distress) touche 20 à 45 % des patients en stade NYHA III–IV, et l'hyponat…
- [DX.6 pt 3/main] La chute du débit cardiaque systolique (dans l'IC) ou la vasodilatation artérielle splanchnique massive induite par le monoxyde d'azote NO suite à l'hypertension portale 
- [DX.6 pt 3/main] Hypertonie sympathique rénale : réabsorption proximale massive de et d'eau, empêchant l'arrivée d'eau au segment diluant de Henle.
- [DX.6 pt 6/main] L'examen recherche les signes d'hyperhydratation extracellulaire interstitielle :
- [DX.6 pt 9/main] SAAG (g/L) = Albumine sérique [g/L] − Albumine dans le liquide d'ascite [g/L]
- [DX.7 pt 2/main] (51 mots) En Suisse, 90 % de toutes les hypercalcémies sont dues à deux causes : l'Hyperparathyroïdie primaire (HPP) (première cause en ambulatoire, prévalence de 1 % après 55 ans, surtout chez la femme ménopau…
- [DX.7 pt 3/main] (46 mots) ) Dans le tube collecteur principal (Effet Diabète Insipide Néphrogénique) : L'activation du CaSR apical par le calcium filtré (ou l'hypokaliémie chronique) déclenche la dégradation par autophagie (vi…
- [DX.7 pt 3/main] Dans la branche ascendante large de Henle (Effet Furosémide
- [DX.7 pt 5/main] L'interrogatoire recherche la tétrade classique de l'hyperparathyroïdie : "Bones, Stones, Abdominal
- [DX.7 pt 5/main] Groans, and Psychic
- [DX.7 pt 9/main] Calcémie corrigée (mmol/L) = Calcémie totale mesurée [mmol/L] + 0,02 × (40 − Albumine [g/L])
- [DX.8 pt 3/main] (31 mots) Dans la MRC et la PKAD, la destruction de l'architecture médullaire (anses de Henle et vasa recta comprimées par les kystes ou la fibrose tubulo-interstitielle) effondre le gradient osmotique cortico…
- [DX.8 pt 3/main] (47 mots) Dans le SLO, l'hyperpression hydrostatique rétrograde dans la lumière tubulaire écrase l'épithélium, détruit les transporteurs apicaux NKCC2 (anse de Henle), ENaC (canal épithélial sodique) et AQP2 (A…
- [DX.8 pt 1/main] L'Isosthénurie de la MRC (Maladie Rénale Chronique, stades G3b à G5) et de la PKAD (Polykystose Rénale
- [DX.8 pt 2/main] Le SLO complique 30 à 50 % des drainages de rétentions urinaires chroniques avec urétéro
- [DX.8 pt 3/main] : Loi de la Charge Osmolaire
- [DX.8 pt 3/main] Volume urinaire minimal obligatoire (L/24h) = Charge osmolaire quotidienne à excréter (mOsm/24h) / Osmolalité urinaire maximale (Uosm max [mOsm/kg])
- [DX.9 pt 1/main] (59 mots) Le Déficit en Arginine-Vasopressine (AVP-D, nouvelle nomenclature internationale officielle 2022–2026 de l'Endocrine Society et de l'ESE remplaçant le terme « Diabète insipide central ou neurogène » a…
- [DX.9 pt 3/main] (56 mots) Sans AVP circulante, le récepteur rénal V2 (couplé à la protéine Gs sur la membrane basolatérale des cellules principales du tube collecteur) reste inactif : l'adénylate cyclase ne produit plus d'AMPc…
- [DX.9 pt 3/main] -optiques (NSO) et paraventriculaires (
- [DX.9 pt 3/main] NPV) de l'hypothalamus, clivée en 3 peptides équimolaires (AVP, Neurophysine II et Copeptine)
- [DX.9 pt 3/main] pendant son transport axonal dans la tige pituitaire,
- [DX.9 pt 9/main] L'AVP est un minuscule peptide de 9 acides aminés, instable (demi-vie in vivo de 15 minutes), lié à 90 % aux plaquettes sanguines et détruit rapidement dans le 
- [DX.10 pt 1/main] (40 mots) La Résistance à l'Arginine-Vasopressine (AVP-R, nouvelle nomenclature internationale remplaçant le terme « Diabète insipide néphrogénique ») se définit par l'incapacité des cellules principales du tub…
- [DX.10 pt 2/main] (42 mots) Chez l'adulte en Suisse, la cause numéro un absolue est l'exposition au Lithium : une diminution du pouvoir de concentration urinaire touche 40 à 50 % des patients traités au long cours pour trouble b…
- [DX.10 pt 3/main] : Cascade Biochimique de l'Intoxication Rénale au Lithium (ENaC
- [DX.10 pt 3/main] → GSK3β) & Génétique de l'AVP-R
- [DX.10 pt 3/main] 1 (Entrée apicale via ENaC)
- [DX.10 pt 3/main] 🔍 Fenêtre Interactive Bio-Mathématique 3.1 : Cascade Biochimique de l'Intoxication Rénale au Lithium (ENaC → GSK3β) & Génétique de l'AVP-R

**LanguageTool (API publique, échantillon de 9002 caractères du texte principal, 1 requêtes, 0 échecs)** : {'Faute de frappe possible': 53, 'Punctuation virgule': 2, 'Concordances': 1, 'Typographie': 4, 'style rules': 1, 'Grammaire': 1}. La catégorie « faute de frappe » contient surtout des termes médicaux absents du dictionnaire.

- [Punctuation virgule] La virgule doit être omise dans ce contexte. — « ...èse compatible avec une hydratation sûre, et la disparition des symptômes liés à la ... » → [' et']
- [Punctuation virgule] Une virgule est conseillée dans ce contexte. — « ...ose euglycémique (glycémie < 11,1 mmol/L mais cétonémie ≥ 3,0 mmol/L chez un patient ... » → [', mais']

## 5. Score §6.3 (proxy) — LOT : **34.7 %** (seuil de dépôt : ≥ 90 % et zéro erreur critique)

Les erreurs critiques ne sont PAS détectables automatiquement : relecture médicale obligatoire.

| Cours | Score | Hors critères HUMAIN | Critères < 2 |
|---|---|---|---|
| SSP | 68.8 % | 72.6 % | 2.b 2.c 6.b 7.c 8.a 8.b 9.a 9.b 9.c 9.e 9.f 11.a 11.b 11.c 11.d 11.e 11.g 11.i 13.b |
| DX.1 | 37.5 % | 37.1 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.e 11.g 11.h 11.j 12.a 13.a 13.b 14.a |
| DX.2 | 27.5 % | 29.0 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.3 | 27.5 % | 32.3 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.j 12.a 13.a 13.b 14.a |
| DX.4 | 31.2 % | 35.5 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.b 7.b 7.c 8.a 8.b 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.5 | 35.0 % | 37.1 % | 1.b 1.c 2.c 3.a 4.a 5.a 5.b 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.6 | 26.2 % | 27.4 % | 1.b 1.c 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.7 | 27.5 % | 25.8 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.8 | 28.8 % | 30.6 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.9 | 36.2 % | 33.9 % | 1.b 1.c 2.a 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b |
| DX.10 | 35.0 % | 37.1 % | 1.b 1.c 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.j 12.a 13.a 13.b 14.a |

Légende des critères :

- **1.a** (AUTO) Texte principal en 1 à 4 phrases
- **1.b** (PROXY) Définition issue d’une source médicale (référence [Sx])
- **1.c** (HUMAIN) Distinction avec les notions voisines
- **2.a** (PROXY) Données suisses chiffrées (OFS/OFSP/Obsan…)
- **2.b** (PROXY) Données européennes / internationales
- **2.c** (HUMAIN) Facteurs de risque / terrain / pronostic chiffré
- **3.a** (PROXY) Tableau lésion → exploration → cible thérapeutique
- **3.b** (HUMAIN) Chaque signe relié à son mécanisme
- **4.a** (PROXY) Priorités : urgence d’abord, puis étapes ordonnées
- **5.a** (PROXY) Questions d’anamnèse ciblées
- **5.b** (HUMAIN) Drapeaux rouges complets et actionnables
- **6.a** (PROXY) Le normal avant le pathologique
- **6.b** (HUMAIN) Technique de recherche + valeur diagnostique de chaque signe
- **7.a** (PROXY) Syndromes énumérés
- **7.b** (PROXY) Signes fonctionnels / signes physiques séparés
- **7.c** (HUMAIN) Chaque signe défini en fenêtre, avec geste et mécanisme
- **8.a** (PROXY) Critères diagnostiques : société savante + année + seuils
- **8.b** (PROXY) Ce qui ne suffit pas à poser le diagnostic
- **9.a** (PROXY) Gold standard dit (existe/n’existe pas) avec Se/Spé/seuil
- **9.b** (PROXY) 1re / 2e intention et critère de passage
- **9.c** (PROXY) Prescription : indication, moment, préparation
- **9.d** (PROXY) Tableau d’interprétation normal (SI) | seuil | signification | conduite
- **9.e** (PROXY) Cas de figure : positif / négatif / limite / discordant
- **9.f** (PROXY) Alternatives : grossesse, enfant, DFGe < 30, iode, pacemaker
- **10.a** (PROXY) Arbre : chaque embranchement → décision
- **11.a** (PROXY) But du traitement chiffré
- **11.b** (PROXY) Ordre de la prise en charge et pourquoi (A→D)
- **11.c** (HUMAIN) Formes compliquées : urgence + chronologie (fenêtre)
- **11.d** (PROXY) Formes non compliquées : mesures générales puis ordre
- **11.e** (HUMAIN) Médicament : classe, PK/PD, EI, ®, dose AIPS, durée, CI, interactions
- **11.f** (PROXY) Traitements non médicamenteux
- **11.g** (PROXY) Volets social / professionnel (LAMal, LAA, LAI, conduite, arrêt)
- **11.h** (PROXY) Situations spéciales : grossesse/allaitement, âgé, enfant, IH, IR (DFGe)
- **11.i** (PROXY) Surveillance : quoi, quand, pourquoi, seuils d’arrêt
- **11.j** (PROXY) Critères de sortie un par un
- **11.k** (PROXY) Pronostic / guérison / recherche 2026
- **12.a** (PROXY) Prévention primaire / secondaire / tertiaire, reco suisses
- **13.a** (AUTO) Points clés : 3 à 6 phrases
- **13.b** (HUMAIN) Contenu : ce qu’un médecin ne doit jamais oublier
- **14.a** (PROXY) Pièges réels de l’examen, chacun avec sa bonne réponse

## 6. Contrôles techniques §10 / §16 par fichier

| Fichier | Octets | FIN_FICHIER | 90–200 Ko | title= | Tableaux (enveloppés) | Lignes > 3000 | script/img/CSS ext. | `<details>` | Sources | Mention « non validé » | Export Google Docs |
|---|---|---|---|---|---|---|---|---|---|---|---|
| INDEX_LOT_3.html | 6163 | oui | non | 0 | 1 (1) | 0 | 0/0/0 | 0 | oui | non | non |
| LOT_3_Appel_A_PREAUDIT_14_POINTS_r1.json | 32901 | (non HTML) |||||||||| 
| LOT_3_Appel_A_PREAUDIT_MEDICAL_LINGUISTIQUE_r1.html | 28940 | oui | non | 0 | 2 (2) | 0 | 0/0/0 | 0 | oui | oui | non |
| LOT_3_Appel_A_V7_Plan_et_Liste_TRAVAIL_r1.html | 96174 | oui | oui | 0 | 14 (14) | 0 | 0/0/0 | 46 | oui | oui | non |
| LOT_3_Appel_B_V5_Ultra_Pedagogique_Partie_1_D3.1_a_D3.2.gdoc_export.html | 227945 | non | non | 0 | 4 (0) | 1 | 0/61/0 | 0 | non | non | oui |
| LOT_3_Appel_B_V5_Ultra_Pedagogique_Partie_2_D3.3_a_D3.5.gdoc_export.html | 177475 | non | oui | 0 | 3 (0) | 1 | 0/46/0 | 0 | non | non | oui |
| LOT_3_Appel_B_V5_Ultra_Pedagogique_Partie_3_D3.6_a_D3.7.gdoc_export.html | 147465 | non | oui | 0 | 2 (0) | 1 | 0/39/0 | 0 | non | non | oui |
| LOT_3_Appel_B_V5_Ultra_Pedagogique_Partie_4_D3.8_a_D3.10.gdoc_export.html | 207758 | non | non | 0 | 6 (0) | 1 | 0/0/0 | 0 | non | non | oui |
