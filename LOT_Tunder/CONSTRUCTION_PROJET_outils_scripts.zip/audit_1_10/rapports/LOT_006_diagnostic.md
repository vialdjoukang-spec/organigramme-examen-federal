# LOT_006 — diagnostic automatique (phase 0)

> Généré par `outils/` (scripts déterministes, aucun appel à une IA). Les notes PROXY/HUMAIN sont **indicatives** : elles signalent où regarder ; l’auditeur médical tranche.

## 1. Fichiers analysés

| Type | Fichier | Octets |
|---|---|---|
| Appel A | LOT_6_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.gdoc_export.html | 72579 |
| Partie 1 | LOT_6_Appel_B_V5_Ultra_Pedagogique_Partie_1_DX.1_a_DX.2.gdoc_export.html | 75135 |
| Partie 2 | LOT_6_Appel_B_V5_Ultra_Pedagogique_Partie_2_DX.3_a_DX.4.gdoc_export.html | 65850 |
| Partie 3 | LOT_6_Appel_B_V5_Ultra_Pedagogique_Partie_3_DX.5_a_DX.7.gdoc_export.html | 91960 |
| Partie 4 | LOT_6_Appel_B_V5_Ultra_Pedagogique_Partie_4_DX.8_a_DX.10.gdoc_export.html | 80817 |

## 2. Découpage et couverture des 14 points

| Cours | Titre | Points | Mots | Points absents / quasi vides | Anomalies |
|---|---|---|---|---|---|
| SSP | SSP — LOT_6_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.gdoc_ | 14/14 | 1980 | — | point 11 : 2 titres concurrents → 11. Prise en charge selon les recommandations suisses. | 1. Traitement symptomatique antipyrétique et antalgique : Classe : Analgésique-antipyrétiq; titre « 1. Traitement symptomatique antipyrétique et antalgique : Classe : Analgésique-a » numéroté 1 mais correspond |
| DX.1 | D6.1 — Infections des voies aériennes supérieures et basses  | 11/14 | 741 | — / quasi vides : 12, 13, 14 | point 12 (Prévention) quasi vide (6 mots); point 13 (Points clés) quasi vide (18 mots); point 14 (Pièges et questions d’examen) quasi vide (13 mots) |
| DX.2 | D6.2 — Infections urinaires hautes et basses (Cystite aiguë, | 11/14 | 709 | — / quasi vides : 12, 13, 14 | point 12 (Prévention) quasi vide (10 mots); point 13 (Points clés) quasi vide (24 mots); point 14 (Pièges et questions d’examen) quasi vide (24 mots) |
| DX.3 | D6.3 — Gastro-entérites aiguës infectieuses (Viroses à Norov | 11/14 | 658 | — / quasi vides : 12, 13, 14 | point 12 (Prévention) quasi vide (15 mots); point 13 (Points clés) quasi vide (21 mots); point 14 (Pièges et questions d’examen) quasi vide (13 mots) |
| DX.4 | D6.4 — Infections cutanées et des tissus mous (Érysipèle, Ce | 10/14 | 623 | — / quasi vides : 8, 12, 13, 14 | point 8 (Diagnostic positif et critères) quasi vide (17 mots); point 12 (Prévention) quasi vide (7 mots); point 13 (Points clés) quasi vide (24 mots); point 14 (Pièges et questions d’examen) quasi vide (18 mots) |
| DX.5 | D6.5 — Méningites et encéphalites infectieuses aiguës (Ménin | 12/14 | 746 | — / quasi vides : 8, 12 | point 8 (Diagnostic positif et critères) quasi vide (17 mots); point 12 (Prévention) quasi vide (21 mots) |
| DX.6 | D6.6 — Endocardite infectieuse subaiguë ou aiguë [4 %] | 6/14 | 413 | — / quasi vides : 4, 6, 8, 9, 10, 12, 13, 14 | point 4 (Démarche diagnostique) quasi vide (24 mots); point 6 (Examen physique ciblé) quasi vide (19 mots); point 8 (Diagnostic positif et critères) quasi vide (9 mots); point 9 (Examens complémentaires) quasi vide (22 mots); point 10 (Arbre décisionnel) quasi vide (13 mots); point 12 (Prévention) q |
| DX.7 | D6.7 — Infections ostéo-articulaires (Arthrite septique, Ost | 5/14 | 422 | — / quasi vides : 1, 4, 5, 6, 7, 8, 12, 13, 14 | point 1 (Définition et sémantique) quasi vide (23 mots); point 4 (Démarche diagnostique) quasi vide (18 mots); point 5 (Anamnèse ciblée et drapeaux rouges) quasi vide (23 mots); point 6 (Examen physique ciblé) quasi vide (17 mots); point 7 (Approche syndromique) quasi vide (21 mots); point 8 (Diagno |
| DX.8 | D6.8 — Maladies inflammatoires systémiques et Connectivites  | 5/14 | 432 | — / quasi vides : 2, 4, 5, 6, 8, 10, 12, 13, 14 | point 2 (Épidémiologie (Suisse, puis Europe)) quasi vide (24 mots); point 4 (Démarche diagnostique) quasi vide (20 mots); point 5 (Anamnèse ciblée et drapeaux rouges) quasi vide (23 mots); point 6 (Examen physique ciblé) quasi vide (9 mots); point 8 (Diagnostic positif et critères) quasi vide (12 mo |
| DX.9 | D6.9 — Néoplasies solides et Hémopathies malignes (Lymphomes | 6/14 | 436 | — / quasi vides : 2, 4, 6, 8, 10, 12, 13, 14 | point 2 (Épidémiologie (Suisse, puis Europe)) quasi vide (23 mots); point 4 (Démarche diagnostique) quasi vide (20 mots); point 6 (Examen physique ciblé) quasi vide (8 mots); point 8 (Diagnostic positif et critères) quasi vide (12 mots); point 10 (Arbre décisionnel) quasi vide (19 mots); point 12 (P |
| DX.10 | D6.10 — Fièvres d'importation et maladies tropicales (Paludi | 8/14 | 520 | — / quasi vides : 6, 8, 10, 12, 13, 14 | point 6 (Examen physique ciblé) quasi vide (15 mots); point 8 (Diagnostic positif et critères) quasi vide (17 mots); point 10 (Arbre décisionnel) quasi vide (21 mots); point 12 (Prévention) quasi vide (7 mots); point 13 (Points clés) quasi vide (23 mots); point 14 (Pièges et questions d’examen) quas |

## 3. Examens complémentaires (exigence : cliquable + fenêtre à 2 onglets « Principe » / « Interprétation »)

| Cours | Mentions | Cliquables | Avec 2 onglets | BIO | FONC | IMG | AUTRE |
|---|---|---|---|---|---|---|---|
| SSP | 23 | 0 | 0 | 15 | 0 | 7 | 1 |
| DX.1 | 14 | 0 | 0 | 10 | 1 | 3 | 0 |
| DX.2 | 19 | 0 | 0 | 16 | 0 | 3 | 0 |
| DX.3 | 5 | 0 | 0 | 5 | 0 | 0 | 0 |
| DX.4 | 10 | 0 | 0 | 9 | 0 | 0 | 1 |
| DX.5 | 23 | 0 | 0 | 22 | 0 | 1 | 0 |
| DX.6 | 21 | 0 | 0 | 9 | 0 | 12 | 0 |
| DX.7 | 7 | 0 | 0 | 3 | 0 | 4 | 0 |
| DX.8 | 4 | 0 | 0 | 4 | 0 | 0 | 0 |
| DX.9 | 18 | 0 | 0 | 11 | 0 | 6 | 1 |
| DX.10 | 12 | 0 | 0 | 12 | 0 | 0 | 0 |
| **Total** | **156** | **0** (0.0 %) | **0** | | | | |

Fenêtres à 2 onglets détectées dans le LOT : **0**.

**Examens distincts nécessitant une fenêtre Principe / Interprétation** (28) :

| Examen | Cat. | Mentions | Cliquables | Cours |
|---|---|---|---|---|
| CRP | BIO | 17 | 0 | DX.1, DX.10, DX.2, DX.3, DX.4, DX.5, DX.6, DX.7, DX.8, DX.9, SSP |
| Ponction lombaire / LCR | BIO | 14 | 0 | DX.5, SSP |
| ECBU / analyse d’urine | BIO | 14 | 0 | DX.1, DX.2, SSP |
| Hémocultures | BIO | 13 | 0 | DX.2, DX.4, DX.5, DX.6, DX.7, SSP |
| Échocardiographie (ETT/ETO) | IMG | 12 | 0 | DX.6 |
| Créatinine / DFGe | BIO | 10 | 0 | DX.1, DX.10, DX.2, DX.3, DX.4, DX.6, DX.8, SSP |
| Procalcitonine (PCT) | BIO | 8 | 0 | DX.1, DX.2, DX.4, DX.5, DX.7, SSP |
| Glycémie | BIO | 8 | 0 | DX.10, DX.4, DX.5 |
| Frottis sanguin | BIO | 7 | 0 | DX.10, DX.9, SSP |
| Scanner / TDM | IMG | 7 | 0 | DX.2, DX.9, SSP |
| LDH | BIO | 7 | 0 | DX.9 |
| Radiographie | IMG | 5 | 0 | DX.1, DX.7, DX.9, SSP |
| PCR (amplification génique) | BIO | 5 | 0 | DX.1, DX.3, DX.5 |
| TEP / PET-scan | IMG | 4 | 0 | DX.9, SSP |
| IRM | IMG | 4 | 0 | DX.5, DX.7 |
| Échographie (générique) | IMG | 3 | 0 | DX.1, DX.2 |
| Ionogramme / électrolytes | BIO | 2 | 0 | DX.3, SSP |
| Bilan hépatique | BIO | 2 | 0 | DX.10, SSP |
| Examen microbiologique des expectorations (BAAR, culture, PCR mycobactéries) | BIO | 2 | 0 | DX.1 |
| Biopsie / histologie | AUTRE | 2 | 0 | DX.4, DX.9 |
| Vitesse de sédimentation (VS) | BIO | 2 | 0 | DX.6, DX.8 |
| Ferritine / bilan martial | BIO | 2 | 0 | DX.9 |
| NFS / hémogramme | BIO | 1 | 0 | SSP |
| Sérologies | BIO | 1 | 0 | SSP |
| Échographie abdominale / pelvienne | IMG | 1 | 0 | SSP |
| Tests génétiques | AUTRE | 1 | 0 | SSP |
| Oxymétrie / saturation | FONC | 1 | 0 | DX.1 |
| Lactate | BIO | 1 | 0 | DX.10 |

## 4. Style (§7)

Phrases nominales : estimation spaCy `fr_core_news_md` + règles ; l’échantillon de contrôle montre encore des faux positifs (verbes non reconnus) → chiffre **majorant**, à relire.

| Cours | Phrases | Nominales (texte/fen./tabl.) | % | > 30 mots | Symboles à la place d’un verbe | Paragraphes sans connecteur | Sigles non développés à la 1re occurrence | Points > 4 phrases dans le texte principal | Phrases creuses / méta |
|---|---|---|---|---|---|---|---|---|---|
| SSP | 104 | 58 (56/0/2) | 55.8 | 12 | 2 | 8 | 38 : AINS, AMP, BLOC, CMV, COX, CT, DES, DIAGNOSTICS, DU, EBV, ECBU, EP3, ESC, ESMO, EULAR | 3 (19), 7 (6), 9 (12), 11 (17), 14 (16) | 0 |
| DX.1 | 52 | 24 (23/0/1) | 46.2 | 3 | 6 | 3 | 13 : CRP, CT, CURB, ECBU, FSC, IL, OFSP, ORL, PCR, PCT, SpO, TA, TNF | 3 (12), 11 (10) | 0 |
| DX.2 | 51 | 33 (33/0/0) | 64.7 | 2 | 1 | 4 | 2 : BU, UFC | 3 (11), 11 (11) | 0 |
| DX.3 | 41 | 22 (22/0/0) | 53.7 | 2 | 3 | 2 | 7 : CRP, CT, FSC, IL, OFSP, PCR, SSI | 3 (10), 9 (5), 11 (5) | 0 |
| DX.4 | 46 | 32 (31/0/1) | 69.6 | 1 | 5 | 2 | 2 : PCT, PLA | 3 (11), 11 (8) | 0 |
| DX.5 | 46 | 27 (27/0/0) | 58.7 | 4 | 6 | 2 | 11 : CRP, CT, FSC, IL, IRM, PCR, PCT, PNN, ROR, SSI, TNF | 3 (11), 9 (5), 11 (8) | 0 |
| DX.6 | 34 | 25 (25/0/0) | 73.5 | 0 | 0 | 0 | 3 : ETT, OAP, VS | 3 (6), 11 (6) | 0 |
| DX.7 | 32 | 28 (28/0/0) | 87.5 | 0 | 1 | 0 | 0 :  | 3 (8), 11 (6) | 0 |
| DX.8 | 31 | 26 (25/0/1) | 83.9 | 1 | 1 | 1 | 13 : ACR, ANA, CCP, CRP, DNA, EULAR, FSC, HEp, IL, JAK, SLICC, SSR, VS | 3 (8) | 0 |
| DX.9 | 29 | 22 (20/0/2) | 75.9 | 1 | 1 | 0 | 6 : CT, EPP, FDG, PET, TAP, TNF | 3 (6) | 0 |
| DX.10 | 38 | 23 (22/0/1) | 60.5 | 2 | 1 | 1 | 2 : OFSP, TDR | 3 (9) | 0 |

**Exemples à relire** (extraits automatiques) :

- [SSP pt 1/main] (56 mots) La fièvre (pyrexie) se définit par une élévation de la température corporelle centrale supérieure à $38{,}0\ ^\circ\text{C}$ (prise buccale, tympanique ou rectale), résultant d'une réinitialisation ac…
- [SSP pt 2/main] (37 mots) En médecine de premier recours et aux urgences en Suisse, la fièvre représente l'un des motifs de consultation les plus fréquents (plus de 10 à 15 % de l'ensemble des motifs aigus, selon la Société Su…
- [SSP pt None/main] Fièvre (SSP G6 — Fever)
- [SSP pt None/main] PLAN MONOGRAPHIQUE DU SSP PRINCIPAL (G6 —
- [SSP pt 3/main] : Loi de Van't Hoff (Consommation Métabolique & Fréquence Cardiaque) et Score de MacIsaac (Streptest)
- [SSP pt 3/main] $\text{FC attendue} = \text{FC de base} + 10 \times (\text{Température corporelle en }\ ^\circ\text{C} - 37\ ^\circ\text{C})$
- [DX.1 pt 1/main] (38 mots) Les infections respiratoires aiguës (IRA) englobent l'ensemble des atteintes inflammatoires virales ou bactériennes des fosses nasales, des sinus, du pharynx, des bronches ou du parenchyme alvéolaire,…
- [DX.1 pt 2/main] (39 mots) En Suisse, les infections respiratoires représentent la première cause de consultation médicale en médecine de premier recours (plus de 40 % des motifs de fièvre aiguë), avec un pic saisonnier automno…
- [DX.1 pt 3/main] rhinorrhée, expectorations) et une réinitialisation thermique hypothalamique
- [DX.1 pt 3/main] Bio-Mathématique 6.1 : Score CURB-65 & Seuil Discriminant PCT pour l'Antibiothérapie
- [DX.1 pt 3/main] Explicitation des variables et Formules :
- [DX.1 pt 3/main] Score CURB-65 (0 à 5 points) = Somme des critères de gravité
- [DX.2 pt 2/main] (32 mots) Les infections urinaires touchent préférentiellement la femme jeune (cystites) mais constituent une cause majeure de sepsis urologique fébrile chez la femme âgée et l'homme porteur d'une hypertrophie …
- [DX.2 pt 3/main] (34 mots) dans plus de 75-80 % des cas, suivi par Klebsiella pneumoniae, Proteus mirabilis et Enterococcus faecalis) le long de l'urètre vers la vessie et, pour les formes hautes, par reflux vésico-urétéral ver…
- [DX.2 pt 3/main] Ascension rétrograde de bactéries commensales du tube digestif (principalement Escherichia coli
- [DX.2 pt 3/main] dans plus de 75-80 % des cas, suivi par Klebsiella pneumoniae, Proteus mirabilis et Enterococcus faecalis) le long de l'urètre vers la vessie et, pour les formes hautes, 
- [DX.2 pt 3/main] Analyse de la Bandelette Urinaire & Seuils de Leucocyturie/Bactériurie (ECBU)
- [DX.2 pt 3/main] Exemple clinique : Patiente de 32 ans avec dysurie et fièvre à 38,5 °C : Leucocyturie à 10&sup5; / mL et ECBU positif à E. coli > 10&sup5; UFC/mL → Pyélonéphrit
- [DX.3 pt 1/main] (37 mots) La gastro-entérite aiguë infectieuse (GEA) désigne un syndrome inflammatoire transitoire de l'estomac et des intestins d'origine virale ou bactérienne, caractérisé par l'association de selles molles o…
- [DX.3 pt 2/main] (36 mots) En Suisse, les gastro-entérites aiguës représentent 12 % des consultations pour fièvre aiguë en médecine de premier recours, avec des toxi-infections alimentaires collectives (TIAC) fréquemment signal…
- [DX.3 pt 3/main] -colique, libérant des cytotoxines et induisant une réponse macrophagique avec relargage d'IL-1 et d'IL-6 (fièvre, douleurs coliques et selles sanglantes glaireuses).
- [DX.3 pt 3/main] 6.3 : Évaluation du Degré de Déshydratation & Correction Volémique dans la GEA
- [DX.3 pt 3/main] Explicitation des variables et Formules :
- [DX.3 pt 3/main] Déficit hydrique estimé (en Litres) = Poids corporel (kg) × Pourcentage de perte pondérale (%)
- [DX.4 pt 4/main] (33 mots) Le praticien différencie l'érysipèle classique de la cellulite et élimine d'urgence la **fasciite nécrosante** (urgence chirurgicale vitale caractérisée par une douleur disproportionnée par rapport au…
- [DX.4 pt 3/main] Pénétration cutanée de bactéries (principalement *Streptococcus pyogenes
- [DX.4 pt 3/main] , et *Staphylococcus aureus* pour les abcès) par une effraction cutanée (intertrigo interdigital, plaie, ulcère), entraînant une prolifération locale, une libération de t
- [DX.4 pt 3/main] Score LRINEC (Laboratory Risk Indicator for Necrotizing Fasciitis)
- [DX.4 pt 3/main] Exemple clinique : Patient avec cellulite de jambe douloureuse, bulles hémorragiques, CRP = 180 mg/L (4 pts), Leucocytes = 22 G/L (2 pts), Na = 130 mmol/L (2 pt
- [DX.5 pt 1/main] (48 mots) Les méningites et encéphalites aiguës désignent l'inflammation de la pie-mère et de l'arachnoïde (méningite) ou du parenchyme cérébral (encéphalite) d'origine bactérienne, virale ou fongique, se manif…
- [DX.5 pt 2/main] (40 mots) En Suisse, les méningites bactériennes aiguës (principalement à Streptococcus pneumoniae et Neisseria meningitidis) touchent environ 300 à 400 patients par an, avec une létalité globale de 10 à 20 % e…
- [DX.5 pt 3/main] Pénétration hématogène ou contiguë de pathogènes envahissant l'espace subarachnoïdien.
- [DX.5 pt 3/main] Cytologie et Biochimie du Liquide Céphalo-Rachidien (LCR) : Bactérien vs Viral
- [DX.5 pt 3/main] Explicitation des variables et Formules :
- [DX.5 pt 3/main] Rapport glycorachie / glycémie = [Glucose LCR (mmol/L)] / [Glycémie veineuse (mmol/L)]
- [DX.6 pt 3/main] Fixation de micro-organismes circulants sur une lésion endothéliale valvulaire (végétation stérile de fibrine et plaquettes).
- [DX.6 pt 3/main] Critères de Duke Modifiés (Rappel synthétique)
- [DX.6 pt 3/main] Explicitation des variables et Formules :
- [DX.7 pt 3/main] Incursion bactérienne (souvent S. aureus) par voie hématogène ou par contiguïté (chirurgie, plaie, escarre), provoquant destruction cartilagineuse rapide dans l'arthrite 
- [DX.7 pt 3/main] Analyse du Liquide Synovial (Arthrite Septique)
- [DX.7 pt 3/main] Explicitation des variables et Formules :
- [DX.7 pt 3/main] Exemple clinique : Ponction d'un genou fébrile et tuméfié : 78 000 leucocytes/μL (95% PNN), direct positif à cocci Gram+ → Arthrite septique à S. aureus, urgenc
- [DX.8 pt 1/main] (35 mots) Les maladies inflammatoires systémiques et connectivites regroupent des pathologies caractérisées par une rupture de la tolérance immunitaire induisant une inflammation systémique, fréquemment révélée…
- [DX.8 pt 3/main] Dérèglement de l'immunité adaptative ou innée (production d'auto-anticorps, dépôts de complexes immuns, activation de l'inflammasome avec surproduction d'IL-1β et d'IL-6)
- [DX.8 pt 3/main] Profil Immunologique et Anticorps Spécifiques des Connectivites
- [DX.8 pt 3/main] Explicitation des variables et Formules :
- [DX.8 pt 3/main] Exemple clinique : Patiente de 34 ans avec fièvre, arthrites et éruption malaire : AAN positifs à 1/640 (moucheté), anti-DNA natif fortement positifs et complém
- [DX.9 pt 1/main] (35 mots) Les néoplasies solides et hémopathies malignes (notamment les lymphomes de Hodgkin et non hodgkiniens, les leucémies aiguës et le carcinome à cellules claires du rein) constituent une cause majeure de…
- [DX.9 pt 3/main] Libération par la tumeur de cytokines pyrogènes endogènes (IL-6, TNF-α), nécrose tumorale ischémique centrale, ou immunodépression induisant des surinfections opportunist
- [DX.9 pt 3/main] Marqueurs de Masse Tumorale & Index Pronostiques
- [DX.9 pt 3/main] Explicitation des variables et Formules :
- [DX.9 pt 3/main] Exemple clinique : Patient de 58 ans avec sueurs nocturnes, perte de poids et fièvre inexpliquée (Symptômes B) : LDH à 3 fois la normale et ferritinémie très él
- [DX.10 pt 3/main] (35 mots) Inoculation de parasites (plasmodiums) ou de virus (dengue) par des vecteurs (moustiques Anophèle ou Aedes) ou ingestion d'aliments contaminés (fièvre typhoïde à Salmonella typhi), provoquant une phas…
- [DX.10 pt 4/main] (31 mots) Toujours éliminer en premier lieu un **paludisme à Plasmodium falciparum** devant toute fièvre au retour d'une zone tropicale (même sans notion de prophylaxie), car le décès peut survenir en quelques …
- [DX.10 pt 3/main] Critères de Gravité du Paludisme à Plasmodium falciparum (OMS)
- [DX.10 pt 3/main] Explicitation des variables et Formules :
- [DX.10 pt 3/main] Critère de gravité absolu : Parasitémie
- [DX.10 pt 3/main] Exemple clinique : Voyageur rentrant du Cameroun il y a 8 jours consultant pour « fièvre et confusion » : Parasitémie à 6,4 %, créatinine à 280 μmol/L, glycémie

**LanguageTool (API publique, échantillon de 9002 caractères du texte principal, 1 requêtes, 0 échecs)** : {'Faute de frappe possible': 61, 'Typographie': 13, 'Punctuation virgule': 2, 'Majuscules': 1, 'Grammaire': 1, 'style rules': 4, 'Concordances': 3, 'Répétitions (Style)': 1, 'Errors ortogràfics': 1, 'repetitions style': 1}. La catégorie « faute de frappe » contient surtout des termes médicaux absents du dictionnaire.

- [Typographie] En français, le symbole monétaire est généralement placé après le nombre. — « ...rature corporelle centrale supérieure à $38{,}0\ ^\circ\text{C}$ (prise buccale, ty... » → ['38 $']
- [Typographie] Insérez une espace après la virgule. — « ...re corporelle centrale supérieure à $38{,}0\ ^\circ\text{C}$ (prise buccale, tympa... » → [', }']
- [Punctuation virgule] Une virgule est conseillée dans ce contexte. — « ...thermie (où le thermostat demeure normal mais où les mécanismes de thermolyse sont dé... » → [', mais']
- [Majuscules] Un usage différent des majuscules et des minuscules est recommandé. — « ...ve ou d'affection systémique grave.  La genèse de la fièvre obéit à une cascade immuno... » → ['Genèse']
- [Grammaire] L’adverbe de lieu et l’interjection « là » s’écrivent avec un accent grave. — « ...chidonique en **Prostaglandine ()**. 4) La se lie aux récepteurs EP3 des neurones ... » → ['Là']
- [Typographie] En français, le symbole monétaire est généralement placé après le nombre. — « ...ntation de la température corporelle de $1\ ^\circ\text{C}$ au-dessus de $37\ ^\ci... » → ['1 $']
- [Typographie] En français, le symbole monétaire est généralement placé après le nombre. — « ...lle de $1\ ^\circ\text{C}$ au-dessus de $37\ ^\circ\text{C}$, le métabolisme de bas... » → ['37 $']

## 5. Score §6.3 (proxy) — LOT : **18.5 %** (seuil de dépôt : ≥ 90 % et zéro erreur critique)

Les erreurs critiques ne sont PAS détectables automatiquement : relecture médicale obligatoire.

| Cours | Score | Hors critères HUMAIN | Critères < 2 |
|---|---|---|---|
| SSP | 33.8 % | 29.0 % | 1.b 2.b 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.a 13.b 14.a |
| DX.1 | 20.0 % | 24.2 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.2 | 21.2 % | 22.6 % | 1.b 1.c 2.a 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.3 | 21.2 % | 22.6 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.4 | 17.5 % | 21.0 % | 1.b 1.c 2.a 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.a 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.5 | 22.5 % | 25.8 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.6 | 13.8 % | 16.1 % | 1.b 1.c 2.a 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.7 | 11.2 % | 12.9 % | 1.b 1.c 2.a 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.a 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.8 | 17.5 % | 21.0 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.9 | 13.8 % | 16.1 % | 1.b 1.c 2.a 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |
| DX.10 | 11.2 % | 12.9 % | 1.b 1.c 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.a 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 11.j 11.k 12.a 13.a 13.b 14.a |

Légende des critères :

- **1.a** (AUTO) Texte principal en 1 à 4 phrases
- **1.b** (PROXY) Définition issue d’une source médicale (référence [Sx])
- **1.c** (HUMAIN) Distinction avec les notions voisines
- **2.a** (PROXY) Données suisses chiffrées (OFS/OFSP/Obsan…)
- **2.b** (PROXY) Données européennes / internationales
- **2.c** (HUMAIN) Facteurs de risque / terrain / pronostic chiffré
- **3.a** (PROXY) Tableau lésion → exploration → cible thérapeutique
- **3.b** (HUMAIN) Chaque signe relié à son mécanisme
- **4.a** (PROXY) Priorités : urgence d’abord, puis étapes ordonnées
- **5.a** (PROXY) Questions d’anamnèse ciblées
- **5.b** (HUMAIN) Drapeaux rouges complets et actionnables
- **6.a** (PROXY) Le normal avant le pathologique
- **6.b** (HUMAIN) Technique de recherche + valeur diagnostique de chaque signe
- **7.a** (PROXY) Syndromes énumérés
- **7.b** (PROXY) Signes fonctionnels / signes physiques séparés
- **7.c** (HUMAIN) Chaque signe défini en fenêtre, avec geste et mécanisme
- **8.a** (PROXY) Critères diagnostiques : société savante + année + seuils
- **8.b** (PROXY) Ce qui ne suffit pas à poser le diagnostic
- **9.a** (PROXY) Gold standard dit (existe/n’existe pas) avec Se/Spé/seuil
- **9.b** (PROXY) 1re / 2e intention et critère de passage
- **9.c** (PROXY) Prescription : indication, moment, préparation
- **9.d** (PROXY) Tableau d’interprétation normal (SI) | seuil | signification | conduite
- **9.e** (PROXY) Cas de figure : positif / négatif / limite / discordant
- **9.f** (PROXY) Alternatives : grossesse, enfant, DFGe < 30, iode, pacemaker
- **10.a** (PROXY) Arbre : chaque embranchement → décision
- **11.a** (PROXY) But du traitement chiffré
- **11.b** (PROXY) Ordre de la prise en charge et pourquoi (A→D)
- **11.c** (HUMAIN) Formes compliquées : urgence + chronologie (fenêtre)
- **11.d** (PROXY) Formes non compliquées : mesures générales puis ordre
- **11.e** (HUMAIN) Médicament : classe, PK/PD, EI, ®, dose AIPS, durée, CI, interactions
- **11.f** (PROXY) Traitements non médicamenteux
- **11.g** (PROXY) Volets social / professionnel (LAMal, LAA, LAI, conduite, arrêt)
- **11.h** (PROXY) Situations spéciales : grossesse/allaitement, âgé, enfant, IH, IR (DFGe)
- **11.i** (PROXY) Surveillance : quoi, quand, pourquoi, seuils d’arrêt
- **11.j** (PROXY) Critères de sortie un par un
- **11.k** (PROXY) Pronostic / guérison / recherche 2026
- **12.a** (PROXY) Prévention primaire / secondaire / tertiaire, reco suisses
- **13.a** (AUTO) Points clés : 3 à 6 phrases
- **13.b** (HUMAIN) Contenu : ce qu’un médecin ne doit jamais oublier
- **14.a** (PROXY) Pièges réels de l’examen, chacun avec sa bonne réponse

## 6. Contrôles techniques §10 / §16 par fichier

| Fichier | Octets | FIN_FICHIER | 90–200 Ko | title= | Tableaux (enveloppés) | Lignes > 3000 | script/img/CSS ext. | `<details>` | Sources | Mention « non validé » | Export Google Docs |
|---|---|---|---|---|---|---|---|---|---|---|---|
| LOT_6_Appel_A_V5_Ultra_Pedagogique_Plan_et_Liste.gdoc_export.html | 72579 | non | non | 0 | 1 (0) | 1 | 0/9/0 | 0 | non | non | oui |
| LOT_6_Appel_B_V5_Ultra_Pedagogique_Partie_1_DX.1_a_DX.2.gdoc_export.html | 75135 | non | non | 0 | 2 (0) | 1 | 0/3/0 | 0 | non | non | oui |
| LOT_6_Appel_B_V5_Ultra_Pedagogique_Partie_2_DX.3_a_DX.4.gdoc_export.html | 65850 | non | non | 0 | 2 (0) | 1 | 0/0/0 | 0 | non | non | oui |
| LOT_6_Appel_B_V5_Ultra_Pedagogique_Partie_3_DX.5_a_DX.7.gdoc_export.html | 91960 | non | oui | 0 | 3 (0) | 1 | 0/0/0 | 0 | non | non | oui |
| LOT_6_Appel_B_V5_Ultra_Pedagogique_Partie_4_DX.8_a_DX.10.gdoc_export.html | 80817 | non | non | 0 | 3 (0) | 1 | 0/0/0 | 0 | non | non | oui |
