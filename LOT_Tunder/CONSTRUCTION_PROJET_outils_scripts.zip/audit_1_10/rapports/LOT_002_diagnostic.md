# LOT_002 — diagnostic automatique (phase 0)

> Généré par `outils/` (scripts déterministes, aucun appel à une IA). Les notes PROXY/HUMAIN sont **indicatives** : elles signalent où regarder ; l’auditeur médical tranche.

## 1. Fichiers analysés

| Type | Fichier | Octets |
|---|---|---|
| Appel A | LOT_2_Appel_A_V7_Plan_et_Liste_AUDIT_CORRIGE_r2.html | 67149 |
| Partie 1 | LOT_2_Appel_B_V7_Partie_1_DX.1_a_DX.2_AUDIT_CORRIGE_r2.html | 98899 |
| Partie 2 | LOT_2_Appel_B_V7_Partie_2_DX.3_a_DX.5_AUDIT_CORRIGE_r2.html | 134214 |
| Partie 3 | LOT_2_Appel_B_V7_Partie_3_DX.6_a_DX.7_AUDIT_CORRIGE_r2.html | 94231 |
| Partie 4 | LOT_2_Appel_B_V7_Partie_4_DX.8_a_DX.10_AUDIT_CORRIGE_r2.html | 132613 |

## 2. Découpage et couverture des 14 points

| Cours | Titre | Points | Mots | Points absents / quasi vides | Anomalies |
|---|---|---|---|---|---|
| SSP | SSP — LOT_2_Appel_A_V7_Plan_et_Liste_AUDIT_CORRIGE_r2.html | 14/14 | 4413 | — | — |
| APPEL_A_BLOC2 | Bloc 2 — Dix hypothèses diagnostiques provisoires | (bloc 2 de l’Appel A : 1833 mots, None tableaux) | | | |
| DX.1 | DX.1 — Adénopathie réactionnelle non spécifique | 14/14 | 3837 | — | — |
| DX.2 | DX.2 — Lymphadénite bactérienne et adénite suppurée | 14/14 | 4998 | — | — |
| DX.3 | DX.3 — Mononucléose infectieuse liée au virus Epstein–Barr | 14/14 | 3347 | — | — |
| DX.4 | DX.4 — Infection par le VIH révélée par des adénopathies | 14/14 | 3467 | — | — |
| DX.5 | DX.5 — Tuberculose ganglionnaire | 14/14 | 5176 | — | — |
| DX.6 | DX.6 — Lymphome hodgkinien ou non hodgkinien | 14/14 | 3746 | — | — |
| DX.7 | DX.7 — Métastase ganglionnaire d’un carcinome | 14/14 | 4515 | — | — |
| DX.8 | DX.8 — Lipome superficiel | 14/14 | 3292 | — | — |
| DX.9 | DX.9 — Sarcome des tissus mous | 14/14 | 3458 | — | — |
| DX.10 | DX.10 — Nodule ou masse thyroïdienne | 14/14 | 4959 | — | — |

## 3. Examens complémentaires (exigence : cliquable + fenêtre à 2 onglets « Principe » / « Interprétation »)

| Cours | Mentions | Cliquables | Avec 2 onglets | BIO | FONC | IMG | AUTRE |
|---|---|---|---|---|---|---|---|
| SSP | 43 | 0 | 0 | 11 | 0 | 18 | 14 |
| APPEL_A_BLOC2 | 10 | 0 | 0 | 1 | 0 | 6 | 3 |
| DX.1 | 6 | 0 | 0 | 1 | 0 | 1 | 4 |
| DX.2 | 3 | 0 | 0 | 0 | 0 | 1 | 2 |
| DX.3 | 14 | 0 | 0 | 14 | 0 | 0 | 0 |
| DX.4 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| DX.5 | 18 | 0 | 0 | 16 | 0 | 0 | 2 |
| DX.6 | 20 | 1 | 0 | 0 | 0 | 3 | 17 |
| DX.7 | 14 | 0 | 0 | 0 | 0 | 1 | 13 |
| DX.8 | 4 | 0 | 0 | 0 | 0 | 2 | 2 |
| DX.9 | 7 | 0 | 0 | 0 | 0 | 4 | 3 |
| DX.10 | 22 | 0 | 0 | 1 | 0 | 11 | 10 |
| **Total** | **161** | **1** (0.6 %) | **0** | | | | |

Fenêtres à 2 onglets détectées dans le LOT : **0**.

**Examens distincts nécessitant une fenêtre Principe / Interprétation** (15) :

| Examen | Cat. | Mentions | Cliquables | Cours |
|---|---|---|---|---|
| Biopsie / histologie | AUTRE | 66 | 1 | APPEL_A_BLOC2, DX.1, DX.10, DX.2, DX.5, DX.6, DX.7, DX.8, DX.9, SSP |
| Échographie (générique) | IMG | 30 | 0 | APPEL_A_BLOC2, DX.1, DX.10, DX.2, DX.8, DX.9, SSP |
| IGRA / test tuberculinique | BIO | 16 | 0 | DX.5, SSP |
| Sérologies | BIO | 11 | 0 | DX.3, DX.5, SSP |
| IRM | IMG | 10 | 0 | APPEL_A_BLOC2, DX.7, DX.8, DX.9, SSP |
| PCR (amplification génique) | BIO | 10 | 0 | DX.3, DX.5, SSP |
| NFS / hémogramme | BIO | 4 | 0 | APPEL_A_BLOC2, SSP |
| Endoscopie (FOGD, coloscopie, bronchoscopie) | AUTRE | 4 | 0 | DX.7 |
| Échographie cervicale / thyroïdienne | IMG | 3 | 0 | DX.10, SSP |
| TEP / PET-scan | IMG | 2 | 0 | DX.6 |
| CRP | BIO | 1 | 0 | SSP |
| Créatinine / DFGe | BIO | 1 | 0 | DX.1 |
| Scanner / TDM | IMG | 1 | 0 | DX.6 |
| Radiographie | IMG | 1 | 0 | DX.9 |
| TSH | BIO | 1 | 0 | DX.10 |

## 4. Style (§7)

Phrases nominales : estimation spaCy `fr_core_news_md` + règles ; l’échantillon de contrôle montre encore des faux positifs (verbes non reconnus) → chiffre **majorant**, à relire.

| Cours | Phrases | Nominales (texte/fen./tabl.) | % | > 30 mots | Symboles à la place d’un verbe | Paragraphes sans connecteur | Sigles non développés à la 1re occurrence | Points > 4 phrases dans le texte principal | Phrases creuses / méta |
|---|---|---|---|---|---|---|---|---|---|
| SSP | 296 | 38 (15/15/8) | 12.8 | 0 | 0 | 31 | 20 : ACTION, AIPS, APPEL, AVANT, CHUV, CRP, ETA, EU, IRM, LECTURE, LINGUISTIQUE, OBLIGATOIRE, OFSP, ORL, PCR | 13 (5) | 0 |
| APPEL_A_BLOC2 | 91 | 29 (4/0/25) | 31.9 | 0 | 2 | 6 | 1 : PAS | — | 0 |
| DX.1 | 367 | 15 (10/2/3) | 4.1 | 0 | 2 | 14 | 2 : AIPS, DAFALGAN | 4 (5), 13 (5) | 1 |
| DX.2 | 426 | 25 (22/3/0) | 5.9 | 1 | 2 | 18 | 3 : CHUV, DCI, IA | 11 (6), 13 (5), 14 (30) | 0 |
| DX.3 | 327 | 11 (11/0/0) | 3.4 | 0 | 2 | 13 | 5 : AIPS, EBNA, EBV, PCR, VCA | 13 (5) | 0 |
| DX.4 | 336 | 11 (9/1/1) | 3.3 | 0 | 2 | 13 | 2 : HAS, OFSP | 8 (5), 13 (5) | 0 |
| DX.5 | 440 | 24 (23/0/1) | 5.5 | 1 | 2 | 15 | 2 : IA, IGRA | 13 (5), 14 (31) | 2 |
| DX.6 | 368 | 14 (10/3/1) | 3.8 | 0 | 4 | 14 | 5 : AIPS, CHOP, CHP, TDM, TEP | 1 (5), 11 (5), 13 (5) | 0 |
| DX.7 | 413 | 24 (22/2/0) | 5.8 | 1 | 2 | 16 | 2 : CUP, IA | 13 (5), 14 (27) | 1 |
| DX.8 | 332 | 10 (8/1/1) | 3.0 | 0 | 2 | 9 | 2 : AIPS, IRM | 13 (5) | 0 |
| DX.9 | 330 | 10 (8/2/0) | 3.0 | 0 | 2 | 12 | 0 :  | 13 (5) | 0 |
| DX.10 | 434 | 23 (22/1/0) | 5.3 | 1 | 2 | 15 | 4 : ETA, EU, IA, TIRADS | 13 (5), 14 (34) | 0 |

**Exemples à relire** (extraits automatiques) :

- [SSP pt None/main] Tuméfaction, masse et adénopathie
- [SSP pt None/main] version de travail r0
- [SSP pt None/main] OBLIGATOIRE AVANT TOUTE ACTION — STATUT
- [APPEL_A_BLOC2 pt None/main] ni l’ordre de fréquence suisse ni l’exhaustivité de dix étiologies
- [APPEL_A_BLOC2 pt None/tableau] Terrain infectieux local, ganglion mobile et sensible possible
- [APPEL_A_BLOC2 pt None/tableau] Examen du territoire drainé ;
- [APPEL_A_BLOC2 pt None/main] Indices provisoires de suffisance : médical 13/28 = 46.4 % ; examen 10/28 = 35.7 %. Ces indices n’autorisent pas la livraison finale ; leurs dénominateurs diffè
- [DX.1 pt None/main] Définition et sémantique 2.
- [DX.1 pt None/main] Épidémiologie et histoire naturelle 3.
- [DX.1 pt None/main] Anamnèse et drapeaux rouges 6.
- [DX.1 pt 3/summary] Le tableau teste la cohérence du raisonnement.
- [DX.1 pt 14/tableau] Le tableau lésion → exploration → thérapeutique est présent et explicite.
- [DX.2 pt 14/main] (32 mots) Le second passage a vérifié les titres, les références, le statut documentaire, la présence des 14 points, la lisibilité des ajouts, les renvois internes et l’absence de nouvelle prescription non véri…
- [DX.2 pt None/main] Définition et sémantique 2.
- [DX.2 pt None/main] Épidémiologie et histoire naturelle 3.
- [DX.2 pt None/main] Anamnèse et drapeaux rouges 6.
- [DX.2 pt 14/tableau] Le tableau lésion → exploration → thérapeutique est présent et explicite.
- [DX.3 pt None/main] Définition et sémantique 2.
- [DX.3 pt None/main] Épidémiologie et histoire naturelle 3.
- [DX.3 pt None/main] Anamnèse et drapeaux rouges 6.
- [DX.3 pt 14/tableau] Le tableau lésion → exploration → thérapeutique est présent et explicite.
- [DX.4 pt None/main] Définition et sémantique 2.
- [DX.4 pt None/main] Épidémiologie et histoire naturelle 3.
- [DX.4 pt None/main] Anamnèse et drapeaux rouges 6.
- [DX.4 pt 14/tableau] Le tableau lésion → exploration → thérapeutique est présent et explicite.
- [DX.5 pt 14/main] (32 mots) Le second passage a vérifié les titres, les références, le statut documentaire, la présence des 14 points, la lisibilité des ajouts, les renvois internes et l’absence de nouvelle prescription non véri…
- [DX.5 pt None/main] Définition et sémantique 2.
- [DX.5 pt None/main] Épidémiologie et histoire naturelle 3.
- [DX.5 pt None/main] Anamnèse et drapeaux rouges 6.
- [DX.5 pt 3/summary] Le tableau relie preuve, traitement et sécurité.
- [DX.5 pt 9/fenetre] Le guide suisse
- [DX.5 pt 14/tableau] Le tableau lésion → exploration → thérapeutique est présent et explicite.
- [DX.6 pt None/main] Définition et sémantique 2.
- [DX.6 pt None/main] Épidémiologie et histoire naturelle 3.
- [DX.6 pt None/main] Anamnèse et drapeaux rouges 6.
- [DX.6 pt 7/fenetre] Dans le cas fictif de 80 kg puis 70 kg, le calcul dérivé est : (80 − 70) ÷ 80 × 100 = 12,5 %. Il a été recalculé avec Python. La durée et le caractère involonta
- [DX.7 pt 14/main] (32 mots) Le second passage a vérifié les titres, les références, le statut documentaire, la présence des 14 points, la lisibilité des ajouts, les renvois internes et l’absence de nouvelle prescription non véri…
- [DX.7 pt None/main] Définition et sémantique 2.
- [DX.7 pt None/main] Épidémiologie et histoire naturelle 3.
- [DX.7 pt None/main] Anamnèse et drapeaux rouges 6.
- [DX.7 pt 13/main] Il discute l’intention thérapeutique selon le tableau.
- [DX.7 pt 14/tableau] Le tableau lésion → exploration → thérapeutique est présent et explicite.
- [DX.8 pt None/main] Définition et sémantique 2.
- [DX.8 pt None/main] Épidémiologie et histoire naturelle 3.
- [DX.8 pt None/main] Anamnèse et drapeaux rouges 6.
- [DX.8 pt 14/tableau] Le tableau lésion → exploration → thérapeutique est présent et explicite.
- [DX.9 pt None/main] Définition et sémantique 2.
- [DX.9 pt None/main] Épidémiologie et histoire naturelle 3.
- [DX.9 pt None/main] Anamnèse et drapeaux rouges 6.
- [DX.9 pt 14/tableau] Le tableau lésion → exploration → thérapeutique est présent et explicite.
- [DX.10 pt 14/main] (32 mots) Le second passage a vérifié les titres, les références, le statut documentaire, la présence des 14 points, la lisibilité des ajouts, les renvois internes et l’absence de nouvelle prescription non véri…
- [DX.10 pt None/main] Définition et sémantique 2.
- [DX.10 pt None/main] Épidémiologie et histoire naturelle 3.
- [DX.10 pt None/main] Anamnèse et drapeaux rouges 6.
- [DX.10 pt 14/tableau] Le tableau lésion → exploration → thérapeutique est présent et explicite.

**LanguageTool (API publique, échantillon de 9002 caractères du texte principal, 1 requêtes, 0 échecs)** : {'Faute de frappe possible': 24, 'Concordances': 2, 'Typographie': 2, 'style rules': 1}. La catégorie « faute de frappe » contient surtout des termes médicaux absents du dictionnaire.

- [Concordances] Vérifiez l’accord entre « diagnostique » et « différentiels ». — « ...ysiopathologie et mécanismes4. Démarche diagnostique et différentiels discriminants5. Anamnèse ciblée et dr » → ['diagnostique et différentiel', 'diagnostique et différentielle', 'diagnostiques et différentiels']
- [Typographie] Le trait d’union est employé sans espaces pour former des mots, alors que le tiret est encadré par des espaces et placé entre deux mots distincts. — « ...0. Arbre décisionnel11. Prise en charge A–D12. Prévention13. Points clés à retenir14.... » → ['A — D12', 'A-D12']
- [Typographie] Le trait d’union est employé sans espaces pour former des mots, alors que le tiret est encadré par des espaces et placé entre deux mots distincts. — « ...sitent double audit de validation avant B1–B4.  Les scores d’audit médical indépendan... » → ['B1 — B4', 'B1-B4']
- [style rules] Les chiffres s’écrivent généralement en lettres. — « ...de travail est 47/92 — 51,09 %. Le rang 1 reprend la liste provisoire de l’Appel ... » → ['un']
- [Concordances] Vérifiez la concordance de « exploitable » avec les noms précédents. — « ...nt pas d’incidence suisse toutes causes exploitable pour cette catégorie. La fich   » → ['exploitables']

## 5. Score §6.3 (proxy) — LOT : **38.2 %** (seuil de dépôt : ≥ 90 % et zéro erreur critique)

Les erreurs critiques ne sont PAS détectables automatiquement : relecture médicale obligatoire.

| Cours | Score | Hors critères HUMAIN | Critères < 2 |
|---|---|---|---|
| SSP | 72.5 % | 72.6 % | 2.a 2.b 5.a 8.a 8.b 9.c 9.e 9.f 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 13.b |
| DX.1 | 40.0 % | 43.5 % | 1.c 2.a 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 11.j 12.a 13.b |
| DX.2 | 40.0 % | 41.9 % | 2.a 2.b 2.c 4.a 5.a 5.b 6.a 6.b 7.a 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 12.a 13.b |
| DX.3 | 32.5 % | 41.9 % | 1.c 2.a 2.c 3.a 3.b 4.a 5.a 5.b 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 11.j 11.k 12.a 13.b |
| DX.4 | 35.0 % | 40.3 % | 1.c 2.a 2.c 3.a 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 11.j 12.a 13.b |
| DX.5 | 36.2 % | 40.3 % | 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.a 7.b 7.c 8.a 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.j 11.k 12.a 13.b |
| DX.6 | 41.2 % | 38.7 % | 1.a 2.a 3.a 4.a 5.a 5.b 6.b 7.a 7.b 8.a 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 11.j 12.a 13.b |
| DX.7 | 30.0 % | 33.9 % | 2.a 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.a 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 12.a 13.b |
| DX.8 | 26.2 % | 32.3 % | 1.c 2.a 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.a 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 11.j 11.k 12.a 13.b |
| DX.9 | 37.5 % | 45.2 % | 1.c 2.a 2.b 2.c 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.g 11.h 11.i 12.a 13.b |
| DX.10 | 28.8 % | 35.5 % | 1.c 2.a 2.b 2.c 3.a 3.b 4.a 5.a 5.b 6.a 6.b 7.b 7.c 8.a 8.b 9.a 9.b 9.c 9.d 9.e 9.f 10.a 11.a 11.b 11.c 11.d 11.e 11.f 11.g 11.h 11.i 11.j 11.k 12.a 13.b |

Légende des critères :

- **1.a** (AUTO) Texte principal en 1 à 4 phrases
- **1.b** (PROXY) Définition issue d’une source médicale (référence [Sx])
- **1.c** (HUMAIN) Distinction avec les notions voisines
- **2.a** (PROXY) Données suisses chiffrées (OFS/OFSP/Obsan…)
- **2.b** (PROXY) Données européennes / internationales
- **2.c** (HUMAIN) Facteurs de risque / terrain / pronostic chiffré
- **3.a** (PROXY) Tableau lésion → exploration → cible thérapeutique
- **3.b** (HUMAIN) Chaque signe relié à son mécanisme
- **4.a** (PROXY) Priorités : urgence d’abord, puis étapes ordonnées
- **5.a** (PROXY) Questions d’anamnèse ciblées
- **5.b** (HUMAIN) Drapeaux rouges complets et actionnables
- **6.a** (PROXY) Le normal avant le pathologique
- **6.b** (HUMAIN) Technique de recherche + valeur diagnostique de chaque signe
- **7.a** (PROXY) Syndromes énumérés
- **7.b** (PROXY) Signes fonctionnels / signes physiques séparés
- **7.c** (HUMAIN) Chaque signe défini en fenêtre, avec geste et mécanisme
- **8.a** (PROXY) Critères diagnostiques : société savante + année + seuils
- **8.b** (PROXY) Ce qui ne suffit pas à poser le diagnostic
- **9.a** (PROXY) Gold standard dit (existe/n’existe pas) avec Se/Spé/seuil
- **9.b** (PROXY) 1re / 2e intention et critère de passage
- **9.c** (PROXY) Prescription : indication, moment, préparation
- **9.d** (PROXY) Tableau d’interprétation normal (SI) | seuil | signification | conduite
- **9.e** (PROXY) Cas de figure : positif / négatif / limite / discordant
- **9.f** (PROXY) Alternatives : grossesse, enfant, DFGe < 30, iode, pacemaker
- **10.a** (PROXY) Arbre : chaque embranchement → décision
- **11.a** (PROXY) But du traitement chiffré
- **11.b** (PROXY) Ordre de la prise en charge et pourquoi (A→D)
- **11.c** (HUMAIN) Formes compliquées : urgence + chronologie (fenêtre)
- **11.d** (PROXY) Formes non compliquées : mesures générales puis ordre
- **11.e** (HUMAIN) Médicament : classe, PK/PD, EI, ®, dose AIPS, durée, CI, interactions
- **11.f** (PROXY) Traitements non médicamenteux
- **11.g** (PROXY) Volets social / professionnel (LAMal, LAA, LAI, conduite, arrêt)
- **11.h** (PROXY) Situations spéciales : grossesse/allaitement, âgé, enfant, IH, IR (DFGe)
- **11.i** (PROXY) Surveillance : quoi, quand, pourquoi, seuils d’arrêt
- **11.j** (PROXY) Critères de sortie un par un
- **11.k** (PROXY) Pronostic / guérison / recherche 2026
- **12.a** (PROXY) Prévention primaire / secondaire / tertiaire, reco suisses
- **13.a** (AUTO) Points clés : 3 à 6 phrases
- **13.b** (HUMAIN) Contenu : ce qu’un médecin ne doit jamais oublier
- **14.a** (PROXY) Pièges réels de l’examen, chacun avec sa bonne réponse

## 6. Contrôles techniques §10 / §16 par fichier

| Fichier | Octets | FIN_FICHIER | 90–200 Ko | title= | Tableaux (enveloppés) | Lignes > 3000 | script/img/CSS ext. | `<details>` | Sources | Mention « non validé » | Export Google Docs |
|---|---|---|---|---|---|---|---|---|---|---|---|
| AUDIT_R2_MANIFEST.json | 13387 | (non HTML) |||||||||| 
| AUDIT_R2_VALIDATIONS_STATIQUES.json | 6031 | (non HTML) |||||||||| 
| LOT_2_AUDIT_MEDICAL_LINGUISTIQUE_SCORES_14_POINTS_r2.html | 12144 | oui | non | 0 | 4 (0) | 1 | 0/0/0 | 0 | oui | oui | non |
| LOT_2_Appel_A_V7_Plan_et_Liste_AUDIT_CORRIGE_r2.html | 67149 | oui | non | 0 | 5 (1) | 0 | 0/0/0 | 74 | oui | oui | non |
| LOT_2_Appel_B_V7_Partie_1_DX.1_a_DX.2_AUDIT_CORRIGE_r2.html | 98899 | oui | oui | 0 | 37 (37) | 0 | 0/0/0 | 55 | oui | oui | non |
| LOT_2_Appel_B_V7_Partie_2_DX.3_a_DX.5_AUDIT_CORRIGE_r2.html | 134214 | oui | oui | 0 | 52 (52) | 0 | 0/0/0 | 75 | oui | oui | non |
| LOT_2_Appel_B_V7_Partie_3_DX.6_a_DX.7_AUDIT_CORRIGE_r2.html | 94231 | oui | oui | 0 | 36 (36) | 0 | 0/0/0 | 53 | oui | oui | non |
| LOT_2_Appel_B_V7_Partie_4_DX.8_a_DX.10_AUDIT_CORRIGE_r2.html | 132613 | oui | oui | 0 | 53 (53) | 0 | 0/0/0 | 77 | oui | oui | non |
