#!/usr/bin/env python3
"""build_bibliotheque.py — génère, de façon déterministe, un fragment HTML par examen (onglets Principe / Interprétation
en CSS pur, sans JavaScript) à partir de donnees_bio.py et donnees_img.py.
Sorties : fragments/<clé>.html, index.json, apercu_bibliotheque.html (toutes les fenêtres, pour contrôle visuel).
Marqueurs des fragments : {{UID}} (identifiant unique par insertion), {{LIBELLE}} (mot cliqué dans le texte),
{{CTX}} (crochet de contexte : ligne propre au diagnostic, vide par défaut)."""
import os, json, html, sys
D = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, D)
from donnees_bio import BIO
from donnees_img import IMG
from donnees_sup import SUP

def table(cols, rows):
    h = ''.join(f'<th>{c}</th>' for c in cols)
    b = ''.join('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>' for r in rows)
    return f"<div style='overflow-x:auto;'><table><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table></div>"

def fragment(key, e):
    note = f"<div class='exn'>{e['note']}</div>" if e.get('note') else ''
    return ("<details class='ex' data-ex='%s'><summary>{{LIBELLE}}</summary><div class='exw'>"
            "<div class='ext'>%s</div><div class='onglets'>"
            "<input type='radio' name='o{{UID}}' id='o{{UID}}p' checked><label for='o{{UID}}p'>Principe</label>"
            "<input type='radio' name='o{{UID}}' id='o{{UID}}i'><label for='o{{UID}}i'>Interprétation</label>"
            "<div class='op'>%s</div><div class='oi'>{{CTX}}%s%s</div></div></div></details>") % (
            key, e['titre'], e['p'], table(e['cols'], e['rows']), note)

def main():
    os.makedirs(os.path.join(D, 'fragments'), exist_ok=True)
    idx = {}
    allx = {**{k: dict(v, cat='BIO') for k, v in BIO.items()}, **IMG, **SUP}
    for k, e in sorted(allx.items()):
        fr = fragment(k, e)
        open(os.path.join(D, 'fragments', k + '.html'), 'w').write(fr + '\n')
        idx[k] = {'lex': e['lex'], 'cat': e['cat'], 'titre': e['titre'], 'fragment': f'fragments/{k}.html', 'octets': len(fr.encode())}
    json.dump(idx, open(os.path.join(D, 'index.json'), 'w'), ensure_ascii=False, indent=1)
    css = open(os.path.join(D, 'fenetres_examens.css')).read().strip()
    body = []
    for i, (k, e) in enumerate(sorted(allx.items(), key=lambda x: (x[1]['cat'], x[1]['titre']))):
        fr = open(os.path.join(D, 'fragments', k + '.html')).read().replace('{{UID}}', f'a{i}').replace('{{LIBELLE}}', html.escape(e['titre'])).replace('{{CTX}}', '')
        body.append(f"<div class='p'>{e['cat']} · {fr}</div>")
    page = ("<!DOCTYPE html><html lang='fr'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>"
            "<title>Bibliothèque des fenêtres d’examens</title><style>body{font:17px/1.6 Tahoma,Arial,sans-serif;margin:0 auto;max-width:1000px;padding:1rem;color:#17332e}"
            "table{border-collapse:collapse;width:100%;font-size:.93em}th,td{border:1px solid #a8cbe2;padding:.5rem;vertical-align:top;min-width:110px}th{background:#dceef9}.p{margin:.5rem 0}" + css +
            "</style></head><body><h1>Bibliothèque des fenêtres d’examens (NNN)</h1>BBB<!-- FIN_FICHIER --></body></html>").replace('NNN', str(len(allx))).replace('BBB', '\n'.join(body))
    open(os.path.join(D, 'apercu_bibliotheque.html'), 'w').write(page)
    print(len(allx), 'fragments ; taille moyenne', sum(v['octets'] for v in idx.values()) // len(idx), 'octets')

if __name__ == '__main__':
    main()
