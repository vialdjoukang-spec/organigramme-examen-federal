#!/usr/bin/env python3
"""captures.py — vérification visuelle sans JavaScript des fenêtres d'examens à 2 onglets.
Usage : captures.py FICHIER.html CLE_UID DOSSIER_SORTIE [largeur]
Ouvre la fenêtre <details class='ex'> d'uid donné, capture l'onglet Principe, clique « Interprétation », capture à nouveau."""
import sys, os
from playwright.sync_api import sync_playwright
f, uid, out = sys.argv[1], sys.argv[2], sys.argv[3]
w = int(sys.argv[4]) if len(sys.argv) > 4 else 900
os.makedirs(out, exist_ok=True)
base = os.path.join(out, f'{os.path.basename(f).replace(".html", "")}_{uid}_{w}px')
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': w, 'height': 820}, java_script_enabled=False)
    pg.goto('file://' + os.path.abspath(f))
    det = pg.locator(f"details.ex:has(#o{uid}p)").first
    anc = det.locator('xpath=ancestor::details')
    for i in range(anc.count()):   # ouvre d'abord les fenêtres parentes fermées (ordre extérieur → intérieur)
        a = anc.nth(i)
        if a.get_attribute('open') is None:
            a.locator('xpath=./summary').click()
    det.locator('summary').first.scroll_into_view_if_needed()
    det.locator('summary').first.click()
    box = det.locator('.exw').first
    box.scroll_into_view_if_needed()
    r = {'principe_visible': box.locator('.op').is_visible(), 'interp_visible_avant': box.locator('.oi').is_visible()}
    pg.screenshot(path=base + '_principe.png', clip=None, full_page=False)
    det.locator(f"label[for=o{uid}i]").click()
    r.update(principe_visible_apres=box.locator('.op').is_visible(), interp_visible_apres=box.locator('.oi').is_visible())
    box.scroll_into_view_if_needed()
    pg.screenshot(path=base + '_interpretation.png')
    print(r, base + '_principe.png', base + '_interpretation.png')
    b.close()
