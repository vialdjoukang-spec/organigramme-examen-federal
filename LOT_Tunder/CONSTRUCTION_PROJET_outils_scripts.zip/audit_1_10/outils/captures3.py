#!/usr/bin/env python3
"""captures3.py — 3 captures représentatives par leçon (règle 7), sans JavaScript.
Usage : captures3.py FICHIER.html DOSSIER_SORTIE NOM [largeur]
 1 : fenêtre « Chaîne logique » (physiopathologie) ; 2 : fenêtre « Diagnostic différentiel » (probabilités rouges) ;
 3 : première fenêtre d’examen du point 9, onglet Interprétation."""
import sys, os
from playwright.sync_api import sync_playwright
f, out, nom = sys.argv[1], sys.argv[2], sys.argv[3]
w = int(sys.argv[4]) if len(sys.argv) > 4 else 900
os.makedirs(out, exist_ok=True)
def ouvrir(det):
    anc = det.locator('xpath=ancestor-or-self::details')
    for i in range(anc.count()):
        a = anc.nth(i)
        if a.get_attribute('open') is None: a.locator('xpath=./summary').first.click()
with sync_playwright() as p:
    b = p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox'])
    pg = b.new_page(viewport={'width': w, 'height': 900}, java_script_enabled=False, device_scale_factor=1)
    pg.goto('file://' + os.path.abspath(f))
    res = []
    for k, txt in ((1, 'Chaîne logique'), (2, 'Diagnostic différentiel')):
        d = pg.locator('details.fenetre', has=pg.locator(f'xpath=./summary[contains(., "{txt}")]')).first
        if d.count() == 0: res.append((k, 'absent')); continue
        ouvrir(d); d.scroll_into_view_if_needed()
        d.screenshot(path=f'{out}/{nom}_{k}.png'); res.append((k, 'ok'))
    ex = pg.locator('section.point[id$="-p9"] details.ex').first
    if ex.count() == 0: ex = pg.locator('details.ex').first
    ouvrir(ex)
    lab = ex.locator('label').nth(1); lab.click()
    ex.scroll_into_view_if_needed(); ex.screenshot(path=f'{out}/{nom}_3.png'); res.append((3, 'ok', ex.locator('.oi').first.is_visible()))
    print(nom, res); b.close()
