#!/usr/bin/env python3
"""sources_orig.py SORTIE.py FICHIER.html... — extrait les sources [Sn] d'originaux en liste Python nettoyée (déterministe) :
espaces manquants rétablis, mention de consultation unique, lien conservé."""
import sys, re, html
from bs4 import BeautifulSoup
def espaces(t):
    t = t.replace('\u202f', ' ').replace('\xa0', ' ')
    t = re.sub(r'(?<=[a-zàâçéèêëîïôûùüÿœ]{2})(?=\d)', ' ', t)
    t = re.sub(r'(?<=\d)(?=(?:er)?[a-zàâçéèêëîïôûùüÿœ]{3,})', ' ', t)
    t = re.sub(r'(?<=\d)er(?=[a-zé]{3,})', 'er ', t)
    t = re.sub(r'(?<=\d)(?=[A-Z]{2,})', ' ', t)
    t = re.sub(r'(?<=[a-zé])(?=§)', ' ', t)
    return re.sub(r'\s+', ' ', t).strip()
out = {}
for f in sys.argv[2:]:
    soup = BeautifulSoup(open(f, encoding='utf-8').read(), 'html.parser')
    for li in soup.select('li[id^=source-S]'):
        n = int(li['id'][8:])
        a = li.find('a'); href = a.get('href') if a else None
        lab = espaces(a.get_text(' ', strip=True)) if a else ''
        lab = re.sub(r'^\[S\d+\]\s*', '', lab)
        rest = espaces(li.get_text(' ', strip=True)); rest = re.sub(r'^\[S\d+\]\s*', '', rest)
        if lab and rest.startswith(lab): rest = rest[len(lab):]
        rest = re.sub(r'\s*;?\s*la consultation date du 23 octobre 2026\.?', '', rest).strip(' .;')
        rest = re.sub(r'^Le document est daté de\s*', 'Version : ', rest)
        lien = f'<a href="{html.escape(href, quote=True)}">{html.escape(lab)}</a>' if href else html.escape(lab)
        txt = f'{lien}. {html.escape(rest)}. Document consulté le 23 octobre 2026.' if rest else f'{lien}. Document consulté le 23 octobre 2026.'
        txt = txt.replace('. .', '.').replace('..', '.')
        out.setdefault(n, txt)
with open(sys.argv[1], 'w', encoding='utf-8') as w:
    w.write('# -*- coding: utf-8 -*-\n# Sources extraites des originaux par outils/sources_orig.py (texte nettoyé, liens conservés).\nSOURCES_ORIG = {\n')
    for n in sorted(out): w.write(f' {n}: {out[n]!r},\n')
    w.write('}\n')
print(len(out), 'sources →', sys.argv[1])
