#!/usr/bin/env python3
"""mobile.py FICHIER... — rend lisible sur téléphone (≤ 640 px) toute fenêtre ouverte dans une cellule de tableau, sans JS.
Principe déterministe : chaque tableau dont une cellule contient une fenêtre (details) reçoit la classe « empile » et chaque cellule
reçoit data-l = intitulé de sa colonne. Sous 640 px, le CSS empile alors les cellules en cartes pleine largeur (l'intitulé de colonne
s'affiche avant la cellule) : la fenêtre ouverte occupe toute la largeur utile, sans défilement horizontal. Au-delà, le tableau reste normal."""
import sys, re, html
LAB = {}
CSS = ("@media (max-width:640px){table.empile,table.empile>tbody,table.empile>tbody>tr,table.empile>tbody>tr>td,table.empile>tr,table.empile>tr>td"
       "{display:block;width:auto;max-width:100%;min-width:0;box-sizing:border-box}table.empile{border-collapse:separate;border-spacing:0;width:100%}table.empile>thead{display:none}table.empile>tbody>tr,table.empile>tr{border:1px solid #b2c9c0;"
       "border-radius:6px;margin:0 0 .7rem;background:#fff}table.empile>tbody>tr>td,table.empile>tr>td{border:0;border-bottom:1px solid #e3ece8}"
       "table.empile td[class*=l]::before{display:block;font:bold .8em Arial,sans-serif;color:#14664f;margin-bottom:.15rem}"
       "div:has(>table.empile){overflow-x:visible!important}.exw{max-width:100%;overflow-wrap:anywhere}.exw .t,.exw div[style*='overflow-x']{max-width:100%}}")
from bs4 import BeautifulSoup
def own_rows(t):
    rows = []
    for ch in t.find_all(recursive=False):
        if ch.name == 'tr': rows.append(ch)
        elif ch.name in ('tbody', 'thead', 'tfoot'): rows += ch.find_all('tr', recursive=False)
    return rows
def traite(path):
    raw = open(path, encoding='utf-8').read()
    soup = BeautifulSoup(raw, 'html.parser'); LAB.clear()
    n = 0
    for t in soup.find_all('table'):
        rows = own_rows(t)
        cells = [c for r in rows for c in r.find_all(['td'], recursive=False)]
        if not (any(c.find('details') for c in cells) or t.find_parent(class_='exw')): continue   # tableau porteur de fenêtre, ou tableau d'interprétation dans une fenêtre
        hdr = next((r for r in rows if r.find('th', recursive=False) and not r.find('td', recursive=False)), None)
        labels = [h.get_text(' ', strip=True) for h in hdr.find_all('th', recursive=False)] if hdr else []
        t['class'] = (t.get('class') or []) + ['empile']
        for r in rows:
            if r is hdr: continue
            for i, c in enumerate(r.find_all(['td', 'th'], recursive=False)):
                if i < len(labels) and labels[i]:
                    k = LAB.setdefault(labels[i], len(LAB))
                    c['class'] = (c.get('class') or []) + [f'l{k}']
        n += 1
    # typographie française : espace insécable fine avant ; : ? ! » et après « (évite « ; » en début de ligne)
    from bs4 import NavigableString, Comment
    for ns in list(soup.find_all(string=True)):
        if isinstance(ns, Comment) or ns.parent.name in ('style', 'script'): continue
        t2 = re.sub(r' ([;:?!»])', '\u202f\\1', str(ns)); t2 = t2.replace('« ', '«\u202f')
        if t2 != str(ns): ns.replace_with(NavigableString(t2))
    def q(x): return '"' + x.replace('\\', '').replace('"', "'") + '"'
    regles = ''.join(f'table.empile .l{k}::before{{content:{q(l)}}}' for l, k in LAB.items())
    out = str(soup)
    out = re.sub(r'/\*mobile\*/.*?/\*fin-mobile\*/', '', out, flags=re.S)
    out = out.replace('</style>', '/*mobile*/' + CSS + '@media (max-width:640px){' + regles + '}/*fin-mobile*/</style>', 1)
    open(path, 'w', encoding='utf-8').write(out)
    print(f'{path}: {n} tableaux empilables sur mobile')
for p in sys.argv[1:]: traite(p)
