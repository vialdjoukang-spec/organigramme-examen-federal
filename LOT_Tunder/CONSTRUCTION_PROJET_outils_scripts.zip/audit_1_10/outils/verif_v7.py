#!/usr/bin/env python3
"""verif_v7.py FICHIER... : contrôles mécaniques V7 (aucun script, image, CSS externe, attribut title, tableaux enveloppés, FIN_FICHIER, glossaire/sigles, taille)."""
import sys, re, os
from bs4 import BeautifulSoup
ok_all = True
for f in sys.argv[1:]:
    h = open(f, encoding='utf-8').read(); s = BeautifulSoup(h, 'html.parser'); pb = []
    if s.find('script'): pb.append('script')
    if s.find('img'): pb.append('img')
    if s.find('link', rel='stylesheet') or re.search(r'@import', h): pb.append('css externe')
    if re.search(r'\stitle=', h): pb.append('title=')
    nw = [t for t in s.find_all('table') if not (t.parent.name == 'div' and 'overflow-x' in (t.parent.get('style') or '') + ' '.join(t.parent.get('class') or []))]
    if nw: pb.append(f'{len(nw)} tableaux non enveloppés')
    if 'FIN_FICHIER' not in h[-3000:]: pb.append('FIN_FICHIER absent')
    if '/*charte_v7plus*/' not in h: pb.append('charte V7+ absente')
    if 'Atkinson Hyperlegible' not in h: pb.append('police absente')
    if re.search(r'id="[a-z0-9]+-p4"', h) and h.count('class="proba"') < 3: pb.append('probabilités rouges < 3')
    if re.search(r'<sup class="proba">[^<]*</sup>(?! <span class="s">)', h): pb.append('probabilité sans source')
    if not re.search(r'Sigles et abréviations|Glossaire', h): pb.append('glossaire absent')
    if any(x.find('p') for x in s.select('section.point')): pb.append('<p> dans le corps')
    sz = os.path.getsize(f)
    if sz > 200_000: pb.append(f'taille {sz}')
    ok_all &= not pb
    print(f"{os.path.basename(f)} {sz} o : {'OK' if not pb else pb}")
sys.exit(0 if ok_all else 1)
