#!/usr/bin/env python3
"""charte_v7plus.py — post-traitement déterministe et idempotent des fichiers AUDITÉS (règles utilisateur du 24.10.2026, 15:36).
- police Atkinson Hyperlegible (pile locale, aucun lien externe) dans le <style> interne ;
- classe .proba (exposant rouge écarlate fluorescent) pour les probabilités/prévalences des diagnostics ;
- fond bleu ciel pâle (16:32) : les fonds/bordures clairs verts deviennent bleu ciel pâle, couleurs d'accent conservées ;
- rouge des probabilités normalisé #C8102E (16:31).
Usage : charte_v7plus.py FICHIER.html [...]"""
import sys, re
BLOC = ('/*charte_v7plus*/body,button,input,select,textarea,table,summary,label{font-family:"Atkinson Hyperlegible",Verdana,Arial,sans-serif}'
        'table.empile td[class*=l]::before{font-family:"Atkinson Hyperlegible",Verdana,Arial,sans-serif!important}'
        '.proba{color:#C8102E;font-weight:700;white-space:nowrap;margin-left:.15em}'
        '.proba+.s{font-size:.7em;vertical-align:super}/*fin-charte*/')
FOND = {'#edf7f4':'#eaf4fb','#f2faf7':'#f1f8fd','#dff1e9':'#dceef9','#d8e8e2':'#d6e6f1',
        '#e3ece8':'#e2ebf2','#aacfc3':'#a8cbe2','#b2c9c0':'#b2c7d6'}
def bleu(css):
    return re.sub(r'#[0-9a-fA-F]{6}\b', lambda m: FOND.get(m.group(0).lower(), m.group(0)), css)
for f in sys.argv[1:]:
    h = open(f, encoding='utf-8').read()
    h = re.sub(r'(<style[^>]*>)(.*?)(</style>)', lambda m: m.group(1)+bleu(m.group(2))+m.group(3), h, flags=re.S)
    h = h.replace('color:#FF2400;font-weight:700;text-shadow:0 0 4px #FF2400AA;', 'color:#C8102E;font-weight:700;')
    h = re.sub(r'/\*charte_v7plus\*/.*?/\*fin-charte\*/', '', h, flags=re.S)
    st = re.search(r'<style>(.*?)</style>', h, re.S)
    dette = (st.group(1).count('{') - st.group(1).count('}')) if st else 0   # accolade non fermée héritée (ancien mobile.py)
    h = h.replace('</style>', '}' * max(dette, 0) + BLOC + '</style>', 1)
    open(f, 'w', encoding='utf-8').write(h)
    print(f'charte_v7plus : {f.split("/")[-1]} ({h.count("class=\"proba\"")} probabilités)')
