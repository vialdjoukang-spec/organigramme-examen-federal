#!/usr/bin/env python3
"""style.py — heuristiques linguistiques déterministes (français), §7 et §12 du prompt V7.
Usage : style.py LOT_001 [--lt N]   (lit work/LOT_001/decoupe.json → work/LOT_001/style.json)
 - phrase sans verbe conjugué (phrase nominale) : analyse morphosyntaxique spaCy fr_core_news_sm (modèle local, sans appel réseau) ;
 - phrase > 30 mots ;
 - flèches / symboles remplaçant un verbe (→ ⇒ ⟹ ↑ ↓ +++ = >) ;
 - paragraphe de ≥ 3 phrases sans connecteur logique ;
 - sigle non développé à sa première apparition dans le FICHIER ;
 - points dont le texte principal dépasse 4 phrases (§7.2) ;
 - option --lt N : envoie au plus N caractères de texte principal à l'API publique LanguageTool (fr), 1 requête / 4 s, échecs tolérés."""
import sys, os, re, json, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from commun import work
import spacy

NLP = spacy.load('fr_core_news_md', disable=['ner'])
NLP.max_length = 3_000_000
ARROWS = re.compile(r'→|⇒|⟹|⟶|➔|➜|↑|↓|⇧|⇩|\+\+\+|(?<=\s)=(?=\s)|(?<=\s)>(?=\s\D)')
CONNECT = re.compile(r"\b(car|donc|parce qu|puisqu|ainsi|puis|ensuite|alors|en effet|cependant|toutefois|mais|or|afin|pour que|lorsqu|si|quand|dès qu|c['’]est pourquoi|par conséquent|de plus|en revanche|tandis qu|sauf|sinon|enfin|d['’]abord|même si|bien qu|parce|dont|qui|ce qui|à condition)\b", re.I)
SIGLE = re.compile(r"\b([A-Z][A-Z0-9]{1,}[a-z]?[A-Z0-9]*|[A-Z][a-z][A-Z][A-Za-z0-9]*)\b")
ROMAN = re.compile(r'^(?:I|II|III|IV|V|VI|VII|VIII|IX|X|XI|XII|XIII|XIV)$')
UNITS = {'SI','OK','HTML','URL','PDF','FIN_FICHIER','DX','CH','FR','EN','UE','A','B','C','D','N','ND','UI','IU','ID','ET','OU','NB','AB','II','III','IV','IMPORTANT','ATTENTION','NON','OUI','LOT','LOTS','PROFILES','SSP','CHATGPT','HTA'}
# SSP / HTA volontairement contrôlés plus bas uniquement s'ils ne sont jamais développés

CREUSE = re.compile(r"\b(?:le lecteur|ce cours|le cours|le rang \d+|cette ligne|la ligne|ce tableau|le tableau|cette fenêtre|la fenêtre|en découle|l[’']utilise|la motive|le justifie|le guide|l[’']oriente|le confirme)\b", re.I)

def sentences(text):
    doc = NLP(text)
    return list(doc.sents)

FREQ_VERBS = re.compile(r"^(?:est|sont|a|ont|reste|restent|découle|découlent|décrit|décrivent|oriente|orientent|indique|indiquent|impose|imposent|suggère|suggèrent|confirme|confirment|élimine|éliminent|exclut|excluent|permet|permettent|devient|deviennent|signale|signalent|traduit|traduisent|justifie|justifient|guide|guident|précède|précèdent|survient|surviennent|apparaît|apparaissent|persiste|persistent|mesure|mesurent|montre|montrent|prouve|prouvent|reflète|reflètent|associe|associent|augmente|augmentent|diminue|diminuent|baisse|baissent|change|changent|peut|peuvent|doit|doivent|faut|vaut|dépend|dépendent|concerne|concernent|touche|touchent|organise|organisent|nécessite|nécessitent|requiert|requièrent|utilise|utilisent|rapporte|rapportent|synthétise|synthétisent)$", re.I)

def has_finite_verb(sent):
    for t in sent:
        if FREQ_VERBS.match(t.text) and t.i > sent.start:
            return True
        if t.pos_ == 'VERB' and t.dep_ == 'ROOT' and 'Part' in t.morph.get('VerbForm') and t.i > sent.start + 1:
            return True
        if t.pos_ in ('VERB', 'AUX'):
            vf = t.morph.get('VerbForm'); md = t.morph.get('Mood')
            if 'Fin' in vf or md:
                return True
    return False

def first_use_expanded(text, pos, sig):
    """Développé si : « … (SIG) » précédé d'au moins 2 mots, ou « SIG (développement…) », ou « SIG, … » non. """
    before = text[max(0, pos - 2):pos]; after = text[pos + len(sig):pos + len(sig) + 3]
    if before.endswith('(') and after.startswith(')'):
        pre = text[max(0, pos - 90):pos - 1].split()
        return len(pre) >= 2
    if after.lstrip().startswith('(') :
        inside = text[pos + len(sig):pos + len(sig) + 120]
        m = re.match(r'\s*\(([^)]{6,})\)', inside)
        return bool(m and re.search(r'[a-zé]{3,}', m.group(1)))
    # forme « développement (SIG, …) »
    if before.endswith('(') and re.match(r'[,;]', after):
        return True
    return False

def analyse(lot, lt_budget=0):
    d = json.load(open(work(lot, 'decoupe.json')))
    per_course = {}
    seen_sigles = {}   # par fichier
    lt_texts = []
    for c in d['courses']:
        st = {'phrases': 0, 'nominales': {'main': 0, 'fenetre': 0, 'tableau': 0, 'summary': 0, 'titre': 0},
              'phrases_par_ctx': {'main': 0, 'fenetre': 0, 'tableau': 0, 'summary': 0, 'titre': 0},
              'longues_30': 0, 'symboles': 0, 'paragraphes_sans_connecteur': 0, 'sigles_non_developpes': [],
              'points_trop_longs': [], 'phrases_creuses': 0, 'ex_creuses': [], 'ex_nominales': [], 'ex_longues': [], 'ex_symboles': []}
        main_sent_per_point = {}
        for b in c['blocks']:
            if b.get('point') == 'sources' or re.match(r'\s*\[S\d+\]', b['text']) or re.search(r'\b(?:doi|https?://)', b['text'], re.I):
                continue
            txt = b['text']
            ctx = 'tableau' if b['cell'] else b['ctx']
            ctx = ctx if ctx in st['nominales'] else 'main'
            # sigles : première apparition dans le fichier
            fs = seen_sigles.setdefault(b['file'], {})
            for m in SIGLE.finditer(txt):
                sg = m.group(1)
                if sg in UNITS or ROMAN.match(sg) or re.fullmatch(r'[A-Z]\d+|\d+[A-Z]|S\d+', sg) or len(sg) > 12:
                    continue
                if sg not in fs:
                    fs[sg] = first_use_expanded(txt, m.start(), sg)
                    if not fs[sg]:
                        st['sigles_non_developpes'].append(sg)
            if b['ctx'] == 'fenetre' and re.fullmatch(r'\S{1,14} \(.+\)', txt.strip()) and len(txt) < 160:
                continue   # entrée de glossaire « SIGLE (développement) » : ni phrase ni nominale
            nsym = len(ARROWS.findall(txt))
            st['symboles'] += nsym
            if nsym and len(st['ex_symboles']) < 6:
                st['ex_symboles'].append(f"[{c['id']} pt {b.get('point')}/{ctx}] {txt[:160]}")
            sents = [s for s in sentences(txt) if len([t for t in s if t.is_alpha]) >= 3]
            if ctx == 'main' and b['tag'] not in ('h1','h2','h3','h4','h5','h6'):
                main_sent_per_point[b.get('point')] = main_sent_per_point.get(b.get('point'), 0) + len(sents)
                if lt_budget and sum(len(x) for x in lt_texts) < lt_budget:
                    lt_texts.append(txt)
            for s in sents:
                st['phrases'] += 1; st['phrases_par_ctx'][ctx] += 1
                nw = len([t for t in s if t.is_alpha])
                if nw <= 8 and CREUSE.search(s.text):
                    st['phrases_creuses'] += 1
                    if len(st['ex_creuses']) < 8:
                        st['ex_creuses'].append(f"[{c['id']} pt {b.get('point')}/{ctx}] {s.text[:120]}")
                label = ctx in ('tableau', 'titre', 'summary') and nw <= 6 and not s.text.rstrip().endswith(('.', '?', '!', ';'))
                if not label and not has_finite_verb(s):
                    st['nominales'][ctx] += 1
                    if len(st['ex_nominales']) < 12:
                        st['ex_nominales'].append(f"[{c['id']} pt {b.get('point')}/{ctx}] {s.text[:170]}")
                if nw > 30:
                    st['longues_30'] += 1
                    if len(st['ex_longues']) < 5:
                        st['ex_longues'].append(f"[{c['id']} pt {b.get('point')}/{ctx}] ({nw} mots) {s.text[:200]}…")
            if len(sents) >= 3 and not CONNECT.search(txt):
                st['paragraphes_sans_connecteur'] += 1
        st['points_trop_longs'] = sorted([(p, n) for p, n in main_sent_per_point.items() if isinstance(p, int) and n > (6 if p == 13 else 4)])
        st['n_nominales'] = sum(st['nominales'].values())
        st['taux_nominales_pct'] = round(100 * st['n_nominales'] / st['phrases'], 1) if st['phrases'] else 0
        st['sigles_non_developpes'] = sorted(set(st['sigles_non_developpes']))
        per_course[c['id']] = st
    lt = None
    if lt_budget:
        lt = languagetool('\n\n'.join(lt_texts)[:lt_budget])
    return {'lot': lot, 'per_course': per_course, 'languagetool': lt}

def languagetool(text, chunk=9000):
    import requests
    res = {'chars_envoyes': 0, 'requetes': 0, 'echecs': 0, 'matches': [], 'par_categorie': {}}
    parts, cur = [], ''
    for para in text.split('\n\n'):
        if len(cur) + len(para) > chunk:
            parts.append(cur); cur = ''
        cur += para + '\n\n'
    if cur.strip(): parts.append(cur)
    for p in parts:
        try:
            r = requests.post('https://api.languagetool.org/v2/check', data={'text': p, 'language': 'fr'}, timeout=60)
            res['requetes'] += 1
            if r.status_code != 200:
                res['echecs'] += 1; time.sleep(5); continue
            res['chars_envoyes'] += len(p)
            for m in r.json().get('matches', []):
                cat = m.get('rule', {}).get('category', {}).get('name', '?')
                res['par_categorie'][cat] = res['par_categorie'].get(cat, 0) + 1
                if len(res['matches']) < 40:
                    ctx = m.get('context', {})
                    res['matches'].append({'msg': m.get('message'), 'cat': cat, 'extrait': ctx.get('text', '')[ctx.get('offset', 0):ctx.get('offset', 0) + ctx.get('length', 0) + 0],
                                           'contexte': ctx.get('text'), 'suggestions': [x['value'] for x in m.get('replacements', [])[:3]]})
        except Exception as e:
            res['echecs'] += 1
        time.sleep(4)
    return res

if __name__ == '__main__':
    lot = sys.argv[1]
    lt = int(sys.argv[sys.argv.index('--lt') + 1]) if '--lt' in sys.argv else 0
    r = analyse(lot, lt)
    json.dump(r, open(work(lot, 'style.json'), 'w'), ensure_ascii=False, indent=1)
    for cid, s in r['per_course'].items():
        print(f"{cid:<14} phrases={s['phrases']:>5} nominales={s['n_nominales']:>4} ({s['taux_nominales_pct']}%) {s['nominales']} >30mots={s['longues_30']:>3} symboles={s['symboles']:>3} sansConnect={s['paragraphes_sans_connecteur']:>3} sigles={len(s['sigles_non_developpes'])} ptsTropLongs={len(s['points_trop_longs'])} creuses={s['phrases_creuses']}")
    if r['languagetool']:
        x = r['languagetool']; print('LanguageTool:', x['requetes'], 'req,', x['echecs'], 'échecs,', x['chars_envoyes'], 'car.,', x['par_categorie'])
