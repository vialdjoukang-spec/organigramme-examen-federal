#!/usr/bin/env python3
"""dump.py LOT COURS [sortie] — texte lisible d'un cours (marqueurs [M] principal, [F] fenêtre, [T] cellule, [S] summary, ## point)."""
import sys, json
from commun import work
lot, cid = sys.argv[1], sys.argv[2]
d = json.load(open(work(lot, 'decoupe.json')))
c = next(x for x in d['courses'] if x['id'] == cid)
out, last = [], object()
for b in c['blocks']:
    if b['point'] != last:
        out.append(f"\n######## POINT {b['point']}"); last = b['point']
    tag = 'S' if b['tag'] == 'summary' else 'H' if b['tag'][:1] == 'h' and b['tag'][1:].isdigit() else 'T' if b['cell'] else 'F' if b['ctx'] == 'fenetre' else 'M'
    out.append(f"[{tag}] {b['text']}")
s = '\n'.join(out)
(open(sys.argv[3], 'w').write(s) if len(sys.argv) > 3 else print(s))
