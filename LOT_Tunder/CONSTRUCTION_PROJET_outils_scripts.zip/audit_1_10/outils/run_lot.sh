#!/bin/bash
# usage : outils/run_lot.sh LOT_001 [LT_CHARS]   — enchaîne découpe → examens → style → score → rapport
cd "$(dirname "$0")/.." && PY=./venv/bin/python
L=$1; LT=${2:-0}
$PY outils/decoupe.py $L && $PY outils/examens.py $L && $PY outils/style.py $L --lt $LT && $PY outils/score.py $L
$PY outils/rapport.py $L
