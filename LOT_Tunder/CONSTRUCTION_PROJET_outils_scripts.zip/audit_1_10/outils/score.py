#!/usr/bin/env python3
"""score.py — score §6.3 (questions §6.1) par monographie, calculé par PROXYS déterministes.
Chaque critère porte une étiquette :
  AUTO   = vérifiable mécaniquement (structure, présence) ;
  PROXY  = présence de marqueurs lexicaux ; la note est indicative ;
  HUMAIN = jugement médical requis ; noté provisoirement par proxy et À CONFIRMER par l'auditeur.
Note : 2 = marqueurs complets, 1 = partiels, 0 = absents.  Aucune note « sans objet » n'est attribuée automatiquement.
Le critère « examens cliquables à 2 onglets » (exigence nouvelle) est rapporté à part, hors §6.3.
Sortie : work/LOT/score.json + contrôles §16 par fichier."""
import sys, os, re, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from commun import work, lot_dir
import glob

def R(*a): return [re.compile(x, re.I) for x in a]

def frac(text, pats):
    hit = sum(1 for p in pats if p.search(text))
    return hit / len(pats) if pats else 0

def note(f, full=0.99, part=0.34):
    return 2 if f >= full else (1 if f >= part else 0)

# (point, id, libellé, étiquette, fonction(texte_point, info) -> 0/1/2)
def crit():
    C = []
    def add(p, cid, lab, tag, fn): C.append((p, cid, lab, tag, fn))
    # Point 1
    add(1, '1.a', 'Texte principal en 1 à 4 phrases', 'AUTO', lambda t, i: 2 if 1 <= i['main_sent'] <= 4 else (1 if i['main_sent'] <= 6 else 0))
    add(1, '1.b', 'Définition issue d’une source médicale (référence [Sx])', 'PROXY', lambda t, i: 2 if re.search(r'\[S\d+\]', t) else 0)
    add(1, '1.c', 'Distinction avec les notions voisines', 'HUMAIN', lambda t, i: note(frac(t, R(r'\bdistingu|\bse différencie|\bà ne pas confondre|\bcontrairement|\bvoisin'))))
    # Point 2
    add(2, '2.a', 'Données suisses chiffrées (OFS/OFSP/Obsan…)', 'PROXY', lambda t, i: note(frac(t, R(r'suisse|OFS|OFSP|Obsan', r'\d+[,.]?\d*\s?(?:%|pour 100|/100)'))))
    add(2, '2.b', 'Données européennes / internationales', 'PROXY', lambda t, i: 2 if re.search(r'europ|mondial|international|OMS|ESC|ECDC', t, re.I) else 0)
    add(2, '2.c', 'Facteurs de risque / terrain / pronostic chiffré', 'HUMAIN', lambda t, i: note(frac(t, R(r'facteur|terrain|âge|sexe', r'mortalit|pronostic|létal'))))
    # Point 3
    add(3, '3.a', 'Tableau lésion → exploration → cible thérapeutique', 'PROXY', lambda t, i: note(frac(t, R(r'm[ée]canisme|l[ée]sion', r'exploration|examen|mesure', r'cible|th[ée]rapeut|traitement'))))
    add(3, '3.b', 'Chaque signe relié à son mécanisme', 'HUMAIN', lambda t, i: note(frac(t, R(r'explique|entraîne|provoque|augmente|diminue|parce que'))))
    # Point 4
    add(4, '4.a', 'Priorités : urgence d’abord, puis étapes ordonnées', 'PROXY', lambda t, i: note(frac(t, R(r'urgence|instable|vital', r'd[’\']abord|puis|ensuite|étape'))))
    # Point 5
    add(5, '5.a', 'Questions d’anamnèse ciblées', 'PROXY', lambda t, i: 2 if t.count('?') >= 5 else (1 if t.count('?') >= 1 or re.search(r'demande|interroge|recherche', t, re.I) else 0))
    add(5, '5.b', 'Drapeaux rouges complets et actionnables', 'HUMAIN', lambda t, i: note(frac(t, R(r'drapeau|alarme|red flag|signe de gravit', r'urgence|adresse|hospitalis|appelle|144|immédiat'))))
    # Point 6
    add(6, '6.a', 'Le normal avant le pathologique', 'PROXY', lambda t, i: 2 if re.search(r'\bnormal|habituel|physiologique', t, re.I) else 0)
    add(6, '6.b', 'Technique de recherche + valeur diagnostique de chaque signe', 'HUMAIN', lambda t, i: note(frac(t, R(r'technique|manœuvre|position|palpe|ausculte|inspecte|percute', r'sensibilit|spécificit|rapport de vraisemblance|valeur'))))
    # Point 7
    add(7, '7.a', 'Syndromes énumérés', 'PROXY', lambda t, i: 2 if len(re.findall(r'syndrome', t, re.I)) >= 2 else (1 if 'syndrom' in t.lower() else 0))
    add(7, '7.b', 'Signes fonctionnels / signes physiques séparés', 'PROXY', lambda t, i: note(frac(t, R(r'signes? fonctionnel|symptôme', r'signes? physique'))))
    add(7, '7.c', 'Chaque signe défini en fenêtre, avec geste et mécanisme', 'HUMAIN', lambda t, i: 2 if i['n_fen'] >= 5 else (1 if i['n_fen'] >= 1 else 0))
    # Point 8
    add(8, '8.a', 'Critères diagnostiques : société savante + année + seuils', 'PROXY', lambda t, i: note(frac(t, R(r'critère', r'\b(?:19|20)\d{2}\b', r'ESC|ADA|ATS|IDSA|ACR|ETA|ATA|EULAR|ESE|NICE|SSED|OMS|WHO|ESMO|société|consensus|recommandation', r'\d+[,.]?\d*\s?(?:mmol|µmol|nmol|pmol|mU|g/|mg|ng|%|mm|cm|L)'))))
    add(8, '8.b', 'Ce qui ne suffit pas à poser le diagnostic', 'PROXY', lambda t, i: 2 if re.search(r'ne suffit pas|insuffisant|ne permet pas|n[’\']établit pas|ne pose pas', t, re.I) else 0)
    # Point 9
    add(9, '9.a', 'Gold standard dit (existe/n’existe pas) avec Se/Spé/seuil', 'PROXY', lambda t, i: note(frac(t, R(r'gold standard|référence|étalon', r'sensibilit', r'spécificit'))))
    add(9, '9.b', '1re / 2e intention et critère de passage', 'PROXY', lambda t, i: note(frac(t, R(r'(?:1re|première|premier)\s+intention|en premier', r'(?:2e|seconde|deuxième)\s+intention|en second'))))
    add(9, '9.c', 'Prescription : indication, moment, préparation', 'PROXY', lambda t, i: note(frac(t, R(r'indication|indiqu', r'moment|à jeun|matin|délai|après', r'préparation|arrêt|sevrage|repos|position'))))
    add(9, '9.d', 'Tableau d’interprétation normal (SI) | seuil | signification | conduite', 'PROXY', lambda t, i: note(frac(t, R(r'normal', r'seuil', r'signifi|interpr', r'conduite|décision'))) if i['n_cells'] else 0)
    add(9, '9.e', 'Cas de figure : positif / négatif / limite / discordant', 'PROXY', lambda t, i: note(frac(t, R(r'positi', r'négati', r'limite|intermédiaire|zone grise', r'discordan'))))
    add(9, '9.f', 'Alternatives : grossesse, enfant, DFGe < 30, iode, pacemaker', 'PROXY', lambda t, i: note(frac(t, R(r'grossesse|enceinte', r'enfant|pédiatr', r'DFGe|insuffisan\w* rénal', r'iod', r'pacemaker|stimulateur|IRM'))))
    # Point 10
    add(10, '10.a', 'Arbre : chaque embranchement → décision', 'PROXY', lambda t, i: note(frac(t, R(r'\bsi\b|lorsque|en cas de', r'alors|→|conduit|décision|oriente|adresse'))))
    # Point 11
    add(11, '11.a', 'But du traitement chiffré', 'PROXY', lambda t, i: note(frac(t, R(r'\bbut\b|objectif|cible', r'[<>≤≥]\s?\d|\d+\s?(?:%|mmol|mmHg|bpm|/min)'))))
    add(11, '11.b', 'Ordre de la prise en charge et pourquoi (A→D)', 'PROXY', lambda t, i: note(frac(t, R(r'\bA\b.{0,40}(?:urgence|compliqu)', r'\bB\b', r'\bC\b', r'\bD\b', r'parce que|car|afin'))))
    add(11, '11.c', 'Formes compliquées : urgence + chronologie (fenêtre)', 'HUMAIN', lambda t, i: note(frac(t, R(r'compliqu', r'urgence', r'minute|heure|H\d|J\d|premi[eè]re heure'))))
    add(11, '11.d', 'Formes non compliquées : mesures générales puis ordre', 'PROXY', lambda t, i: note(frac(t, R(r'non compliqu|ambulatoire', r'mesures? générales|hygiéno|éducation'))))
    add(11, '11.e', 'Médicament : classe, PK/PD, EI, ®, dose AIPS, durée, CI, interactions', 'HUMAIN', lambda t, i: note(frac(t, R(r'classe', r'pharmacocin|demi-vie|élimination', r'pharmacodyn|mécanisme d[’\']action|inhib|agonist|antagonist|bloque', r'effets? indésirable', r'®', r'AIPS|Swissmedic|compendium', r'\d+\s?(?:mg|µg|g|UI)\b', r'durée|pendant \d|semaines', r'contre-indic', r'interaction'))))
    add(11, '11.f', 'Traitements non médicamenteux', 'PROXY', lambda t, i: note(frac(t, R(r'non médicament|mesures physiques|nutrition|rééducation|psychoth|chirurg|dispositif|activité physique'))))
    add(11, '11.g', 'Volets social / professionnel (LAMal, LAA, LAI, conduite, arrêt)', 'PROXY', lambda t, i: note(frac(t, R(r'LAMal|LAA|LAI|assuran', r'arrêt de travail|incapacité de travail|professionnel', r'conduite automobile|aptitude à la conduite|conduire'))))
    add(11, '11.h', 'Situations spéciales : grossesse/allaitement, âgé, enfant, IH, IR (DFGe)', 'PROXY', lambda t, i: note(frac(t, R(r'grossesse|enceinte|allait', r'âgé|gériatr', r'enfant|pédiatr', r'hépatique', r'rénal|DFGe')), full=0.99, part=0.4))
    add(11, '11.i', 'Surveillance : quoi, quand, pourquoi, seuils d’arrêt', 'PROXY', lambda t, i: note(frac(t, R(r'surveill', r'semaine|mois|jour|contrôle à', r'arrêt|interromp|stopp'))))
    add(11, '11.j', 'Critères de sortie un par un', 'PROXY', lambda t, i: 2 if re.search(r'critères? de sortie|retour à domicile|sortie d[’\']hospitalisation|peut rentrer', t, re.I) else 0)
    add(11, '11.k', 'Pronostic / guérison / recherche 2026', 'PROXY', lambda t, i: note(frac(t, R(r'pronostic|guérison|rémission|récidive|rechute', r'recherche|essai|2025|2026'))))
    # Point 12
    add(12, '12.a', 'Prévention primaire / secondaire / tertiaire, reco suisses', 'PROXY', lambda t, i: note(frac(t, R(r'primaire', r'secondaire', r'tertiaire', r'suisse|OFSP|SSED|BAG|plan de vaccination|swissmedic'))))
    # Point 13
    add(13, '13.a', 'Points clés : 3 à 6 phrases', 'AUTO', lambda t, i: 2 if 3 <= i['main_sent'] + i['sent_other'] <= 6 or 3 <= i['main_sent'] <= 6 else 1 if i['main_sent'] else 0)
    add(13, '13.b', 'Contenu : ce qu’un médecin ne doit jamais oublier', 'HUMAIN', lambda t, i: 1 if i['words'] >= 40 else 0)
    # Point 14
    add(14, '14.a', 'Pièges réels de l’examen, chacun avec sa bonne réponse', 'PROXY', lambda t, i: note(frac(t, R(r'piège|confusion|erreur|faux', r'bonne réponse|réponse|correct|en réalité|il faut'))))
    return C

CRIT = crit()

def course_texts(c):
    pts = {}
    for b in c['blocks']:
        p = b.get('point')
        if not isinstance(p, int): continue
        x = pts.setdefault(p, {'text': [], 'main_sent': 0, 'sent_other': 0, 'n_fen': 0, 'n_cells': 0, 'words': 0, 'wids': set()})
        x['text'].append(b['text']); x['words'] += len(b['text'].split())
        n_s = len([s for s in re.split(r'(?<=[.!?;])\s+', re.sub(r'\[S\d+\]', '', b['text'])) if len(s.split()) >= 3])   # appels de source [Sn] exclus
        if b['ctx'] == 'main' and not b['cell'] and b['tag'] not in ('h1','h2','h3','h4','h5','h6','summary'):
            x['main_sent'] += n_s
        else:
            x['sent_other'] += 0
        if b['cell']: x['n_cells'] += 1
        for sp in b['spans']: x['wids'].add(sp[2])
        if b['ctx'] == 'fenetre': x['n_fen'] += 0
    for p, x in pts.items():
        x['n_fen'] = len(x['wids']) + c['points'].get(str(p), {}).get('n_fenetres', 0)
    return pts

def score_course(c):
    pts = course_texts(c)
    rows, tot, mx = [], 0, 0
    for p, cid, lab, tag, fn in CRIT:
        if not c['points'].get(str(p), {}).get('present'):
            v = 0
        else:
            x = pts.get(p, {'text': [], 'main_sent': 0, 'sent_other': 0, 'n_fen': 0, 'n_cells': 0, 'words': 0})
            v = fn(' \n'.join(x['text']), x)
        rows.append({'point': p, 'id': cid, 'critere': lab, 'tag': tag, 'note': v})
        tot += v; mx += 2
    pct = round(100 * tot / mx, 1)
    auto = [r for r in rows if r['tag'] != 'HUMAIN']
    pct_auto = round(100 * sum(r['note'] for r in auto) / (2 * len(auto)), 1)
    return {'id': c['id'], 'title': c['title'], 'score_pct': pct, 'score_hors_humain_pct': pct_auto, 'rows': rows,
            'a_revoir': [r['id'] for r in rows if r['note'] < 2]}

def file_checks(lot):
    out = []
    files = [f for f in glob.glob(os.path.join(lot_dir(lot), '**', '*'), recursive=True) if os.path.isfile(f)]
    for f in sorted(files):
        name = os.path.basename(f); size = os.path.getsize(f)
        try: raw = open(f, encoding='utf-8', errors='replace').read()
        except Exception: raw = ''
        is_html = name.lower().endswith(('.html', '.htm'))
        r = {'file': os.path.relpath(f, lot_dir(lot)), 'size': size, 'html': is_html}
        if is_html and size:
            low = raw.lower()
            tables = len(re.findall(r'<table\b', low))
            wrapped = len(re.findall(r"<div[^>]*overflow-x\s*:\s*auto[^>]*>\s*<table\b", low))
            r.update({
                'FIN_FICHIER': 'FIN_FICHIER' in raw,
                'taille_90_200k': 90_000 <= size <= 200_000,
                'title_attr': len(re.findall(r'\stitle\s*=', low)),
                'tables': tables, 'tables_enveloppees': wrapped,
                'lignes_gt_3000': sum(1 for l in raw.splitlines() if len(l) > 3000),
                'script': len(re.findall(r'<script\b', low)), 'img': len(re.findall(r'<img\b', low)),
                'css_externe': len(re.findall(r'<link[^>]+stylesheet', low)),
                'details': len(re.findall(r'<details\b', low)),
                'section_sources': bool(re.search(r'sources|références|bibliograph', low)),
                'mention_non_valide': bool(re.search(r'provisoire|non valid|audits? en cours|à rédiger|a_rediger', low)),
                'gdoc_export': name.endswith('.gdoc_export.html'),
            })
        out.append(r)
    return out

if __name__ == '__main__':
    lot = sys.argv[1]
    d = json.load(open(work(lot, 'decoupe.json')))
    res = {'lot': lot, 'courses': [score_course(c) for c in d['courses'] if c['id'] != 'APPEL_A_BLOC2'], 'fichiers': file_checks(lot)}
    sc = [c['score_pct'] for c in res['courses']]
    res['score_lot_pct'] = round(sum(sc) / len(sc), 1) if sc else None
    json.dump(res, open(work(lot, 'score.json'), 'w'), ensure_ascii=False, indent=1)
    for c in res['courses']:
        print(f"{c['id']:<8} {c['score_pct']:>5}%  (hors HUMAIN {c['score_hors_humain_pct']}%)  à revoir: {' '.join(c['a_revoir'])}")
    print('SCORE LOT (proxy):', res['score_lot_pct'])
