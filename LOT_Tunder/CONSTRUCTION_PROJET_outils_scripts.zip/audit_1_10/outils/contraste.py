import sys,asyncio,glob,json
from playwright.async_api import async_playwright
JS='''()=>{function p(c){const m=c.match(/[\\d.]+/g);return m?m.map(Number):[0,0,0,0]}
function L(r,g,b){[r,g,b]=[r,g,b].map(v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return .2126*r+.7152*g+.0722*b}
function bg(e){while(e){const c=p(getComputedStyle(e).backgroundColor);if(c.length<4||c[3]>0.5)return c;e=e.parentElement}return[255,255,255]}
const out={};for(const e of document.querySelectorAll('body *')){if(!e.childNodes.length)continue;let t='';for(const n of e.childNodes)if(n.nodeType==3)t+=n.textContent;t=t.trim();if(!t)continue;
const c=p(getComputedStyle(e).color),b=bg(e);const l1=L(...c.slice(0,3)),l2=L(...b.slice(0,3));const r=(Math.max(l1,l2)+.05)/(Math.min(l1,l2)+.05);
if(r<4.5){const k=getComputedStyle(e).color+' sur '+getComputedStyle(e.closest('*')).backgroundColor+' / bg '+b.join(',')+' r='+r.toFixed(2)+' <'+e.tagName.toLowerCase()+' class='+e.className+'>';out[k]=out[k]||t.slice(0,50)}}return out}'''
async def main():
  async with async_playwright() as pw:
    br=await pw.chromium.launch(executable_path='/usr/bin/google-chrome',args=['--no-sandbox']);pg=await br.new_page()
    for f in sys.argv[1:]:
      await pg.goto('file://'+f);await pg.evaluate("document.querySelectorAll('details').forEach(d=>d.open=true)")
      r=await pg.evaluate(JS);print('==',f.split('/')[-1],len(r))
      for k,v in list(r.items())[:15]:print('  ',k,'|',v)
    await br.close()
asyncio.run(main())
