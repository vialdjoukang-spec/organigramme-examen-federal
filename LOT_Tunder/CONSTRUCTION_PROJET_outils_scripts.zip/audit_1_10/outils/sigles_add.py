#!/usr/bin/env python3
"""sigles_add.py 'SIGLE=développement' ... : ajoute des entrées au dictionnaire DEV de sigles.py (idempotent)."""
import sys, os
p = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'sigles.py'); s = open(p, encoding='utf-8').read(); ins = ''
for a in sys.argv[1:]:
    k, v = a.split('=', 1)
    if f"'{k}':" not in s and f'"{k}":' not in s: ins += f" {k!r}: {v!r},\n"
s = s.replace("DEV = {\n", "DEV = {\n" + ins, 1); open(p, 'w', encoding='utf-8').write(s); print('ajoutés :', ins.count('\n'))
