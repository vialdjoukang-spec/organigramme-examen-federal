#!/usr/bin/env python3
"""rapport.py — assemble work/LOT/{decoupe,examens,style,score}.json en rapports/LOT_00X_diagnostic.md"""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from commun import work
BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PN = {1:'Définition',2:'Épidémiologie',3:'Physiopathologie',4:'Démarche diagnostique',5:'Anamnèse / drapeaux rouges',6:'Examen physique',7:'Approche syndromique',8:'Diagnostic positif',9:'Examens complémentaires',10:'Arbre décisionnel',11:'Prise en charge',12:'Prévention',13:'Points clés',14:'Pièges'}

def load(lot, n):
    p = work(lot, n)
    return json.load(open(p)) if os.path.exists(p) else None

def main(lot):
    D, E, S, SC = (load(lot, x) for x in ('decoupe.json', 'examens.json', 'style.json', 'score.json'))
    L = [f"# {lot} — diagnostic automatique (phase 0)\n",
         "> Généré par `outils/` (scripts déterministes, aucun appel à une IA). Les notes PROXY/HUMAIN sont **indicatives** : elles signalent où regarder ; l’auditeur médical tranche.\n"]
    if not D:
        L.append("**Aucun contenu analysable** (fichiers absents, vides ou « A_REDIGER »).\n")
    else:
        L.append("## 1. Fichiers analysés\n\n| Type | Fichier | Octets |\n|---|---|---|")
        for t, f, s in D['files']: L.append(f"| {t} | {f} | {s} |")
        L.append("\n## 2. Découpage et couverture des 14 points\n\n| Cours | Titre | Points | Mots | Points absents / quasi vides | Anomalies |\n|---|---|---|---|---|---|")
        for c in D['courses']:
            if 'coverage' not in c:
                L.append(f"| {c['id']} | {c['title'][:60]} | (bloc 2 de l’Appel A : {c.get('bloc2_words','?')} mots, {c.get('bloc2_tables','?')} tableaux) | | | |"); continue
            words = sum(p['words_total'] for p in c['points'].values())
            miss = [k for k, p in c['points'].items() if not p['present']]
            thin = [k for k, p in c['points'].items() if p['present'] and p['words_total'] < 25]
            L.append(f"| {c['id']} | {c['title'][:60]} | {c['coverage']}/14 | {words} | {', '.join(miss) or '—'}{' / quasi vides : ' + ', '.join(thin) if thin else ''} | {'; '.join(c['anomalies'])[:300] or '—'} |")
    if E:
        L.append("\n## 3. Examens complémentaires (exigence : cliquable + fenêtre à 2 onglets « Principe » / « Interprétation »)\n\n| Cours | Mentions | Cliquables | Avec 2 onglets | BIO | FONC | IMG | AUTRE |\n|---|---|---|---|---|---|---|---|")
        T = [0, 0, 0]
        for cid, s in E['per_course'].items():
            b = s['by_cat']; T[0] += s['occ']; T[1] += s['clickable']; T[2] += s['two_tabs']
            L.append(f"| {cid} | {s['occ']} | {s['clickable']} | {s['two_tabs']} | {b.get('BIO',0)} | {b.get('FONC',0)} | {b.get('IMG',0)} | {b.get('AUTRE',0)} |")
        L.append(f"| **Total** | **{T[0]}** | **{T[1]}** ({round(100*T[1]/T[0],1) if T[0] else 0} %) | **{T[2]}** | | | | |")
        L.append(f"\nFenêtres à 2 onglets détectées dans le LOT : **{E['n_windows_with_2_tabs']}**.\n\n**Examens distincts nécessitant une fenêtre Principe / Interprétation** ({len(E['distinct'])}) :\n\n| Examen | Cat. | Mentions | Cliquables | Cours |\n|---|---|---|---|---|")
        for n, x in sorted(E['distinct'].items(), key=lambda k: -k[1]['occ']):
            L.append(f"| {n} | {x['cat']} | {x['occ']} | {x['clickable']} | {', '.join(sorted(x['courses']))} |")
    if S:
        L.append("\n## 4. Style (§7)\n\nPhrases nominales : estimation spaCy `fr_core_news_md` + règles ; l’échantillon de contrôle montre encore des faux positifs (verbes non reconnus) → chiffre **majorant**, à relire.\n\n| Cours | Phrases | Nominales (texte/fen./tabl.) | % | > 30 mots | Symboles à la place d’un verbe | Paragraphes sans connecteur | Sigles non développés à la 1re occurrence | Points > 4 phrases dans le texte principal | Phrases creuses / méta |\n|---|---|---|---|---|---|---|---|---|---|")
        for cid, s in S['per_course'].items():
            n = s['nominales']
            L.append(f"| {cid} | {s['phrases']} | {s['n_nominales']} ({n['main']}/{n['fenetre']}/{n['tableau']}) | {s['taux_nominales_pct']} | {s['longues_30']} | {s['symboles']} | {s['paragraphes_sans_connecteur']} | {len(s['sigles_non_developpes'])} : {', '.join(s['sigles_non_developpes'][:15])} | {', '.join(f'{p} ({k})' for p, k in s['points_trop_longs']) or '—'} | {s.get('phrases_creuses', 0)} |")
        L.append("\n**Exemples à relire** (extraits automatiques) :\n")
        for cid, s in S['per_course'].items():
            ex = s['ex_longues'][:2] + s['ex_nominales'][:3] + s.get('ex_creuses', [])[:3] + s['ex_symboles'][:1]
            for x in ex: L.append(f"- {x}")
        lt = S.get('languagetool')
        if lt:
            L.append(f"\n**LanguageTool (API publique, échantillon de {lt['chars_envoyes']} caractères du texte principal, {lt['requetes']} requêtes, {lt['echecs']} échecs)** : {lt['par_categorie']}. La catégorie « faute de frappe » contient surtout des termes médicaux absents du dictionnaire.\n")
            for m in [m for m in lt['matches'] if 'frappe' not in m['cat'].lower()][:12]:
                L.append(f"- [{m['cat']}] {m['msg']} — « {(m['contexte'] or '')[:110]} » → {m['suggestions']}")
    if SC:
        L.append(f"\n## 5. Score §6.3 (proxy) — LOT : **{SC['score_lot_pct']} %** (seuil de dépôt : ≥ 90 % et zéro erreur critique)\n\nLes erreurs critiques ne sont PAS détectables automatiquement : relecture médicale obligatoire.\n\n| Cours | Score | Hors critères HUMAIN | Critères < 2 |\n|---|---|---|---|")
        for c in SC['courses']:
            L.append(f"| {c['id']} | {c['score_pct']} % | {c['score_hors_humain_pct']} % | {' '.join(c['a_revoir'])} |")
        L.append("\nLégende des critères :\n")
        seen = set()
        for r in SC['courses'][0]['rows'] if SC['courses'] else []:
            if r['id'] not in seen:
                seen.add(r['id']); L.append(f"- **{r['id']}** ({r['tag']}) {r['critere']}")
        L.append("\n## 6. Contrôles techniques §10 / §16 par fichier\n\n| Fichier | Octets | FIN_FICHIER | 90–200 Ko | title= | Tableaux (enveloppés) | Lignes > 3000 | script/img/CSS ext. | `<details>` | Sources | Mention « non validé » | Export Google Docs |\n|---|---|---|---|---|---|---|---|---|---|---|---|")
        for f in SC['fichiers']:
            if not f.get('html'):
                L.append(f"| {f['file']} | {f['size']} | (non HTML) |||||||||| "); continue
            if not f['size']:
                L.append(f"| {f['file']} | 0 | **VIDE** |||||||||| "); continue
            yn = lambda v: 'oui' if v else 'non'
            L.append(f"| {f['file']} | {f['size']} | {yn(f['FIN_FICHIER'])} | {yn(f['taille_90_200k'])} | {f['title_attr']} | {f['tables']} ({f['tables_enveloppees']}) | {f['lignes_gt_3000']} | {f['script']}/{f['img']}/{f['css_externe']} | {f['details']} | {yn(f['section_sources'])} | {yn(f['mention_non_valide'])} | {yn(f['gdoc_export'])} |")
    os.makedirs(os.path.join(BASE, 'rapports'), exist_ok=True)
    out = os.path.join(BASE, 'rapports', f'{lot}_diagnostic.md')
    open(out, 'w').write('\n'.join(L) + '\n')
    print(out)

if __name__ == '__main__':
    main(sys.argv[1])
