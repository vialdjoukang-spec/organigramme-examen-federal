"""commun.py — linéarisation déterministe d'un fichier HTML de cours (LOTS V7).
Produit une liste de blocs (texte propre + contexte) et un registre de fenêtres <details>.
Aucun appel IA."""
import re, hashlib, os, json
from bs4 import BeautifulSoup, NavigableString, Tag, Comment

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BLOCK = {'p','div','section','article','main','header','footer','li','ul','ol','table','thead','tbody','tfoot','tr',
         'td','th','caption','h1','h2','h3','h4','h5','h6','blockquote','pre','dl','dt','dd','figure','figcaption',
         'nav','aside','body','html','form','fieldset','details','summary','hr','br_block'}
SKIP = {'script','style','head','title','meta','link','noscript','template'}
CLICK_INLINE = {'a','button','label'}
TAB_RE_P = re.compile(r'^\s*(onglet\s*\d*\s*[:\-–—·]?\s*)?(\d\s*[\.\-–—·:]\s*)?principe\b', re.I)
TAB_RE_I = re.compile(r'^\s*(onglet\s*\d*\s*[:\-–—·]?\s*)?(\d\s*[\.\-–—·:]\s*)?interpr[ée]tation\b', re.I)

def norm(t):
    return re.sub(r'\s+', ' ', t.replace('\xa0', ' ')).strip()

def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for ch in iter(lambda: f.read(1 << 16), b''):
            h.update(ch)
    return h.hexdigest()

def is_inline_details(d):
    st = (d.get('style') or '').replace(' ', '').lower()
    return 'display:inline' in st or bool({'ex','terme'} & set(d.get('class') or []))

def window_tabs(d):
    """Cherche dans une fenêtre <details> deux onglets libellés 'Principe' et 'Interprétation'."""
    p = i = False
    for el in d.find_all(['summary','strong','b','h1','h2','h3','h4','h5','h6','button','label','th','legend','span','div','p','li']):
        if el.get('role') not in (None, 'tab') and el.name not in ('summary','strong','b','button','label','th','legend') and not el.name.startswith('h'):
            if el.name in ('span','div','p','li') and 'tab' not in ' '.join(el.get('class') or []).lower() and el.get('role') != 'tab':
                continue
        if el.find_parent('details') is not d and el is not d:
            continue  # onglet d'une fenêtre imbriquée : ne compte pas pour la fenêtre parente
        t = norm(el.get_text(' '))
        if len(t) > 60:
            continue
        if TAB_RE_P.match(t): p = True
        if TAB_RE_I.match(t): i = True
    return p, i

class Linearizer:
    def __init__(self, html, fname):
        self.soup = BeautifulSoup(html, 'lxml')
        for c in self.soup.find_all(string=lambda s: isinstance(s, Comment)):
            c.extract()
        self.fname = fname
        self.blocks = []
        self.windows = {}
        self._wid = 0

    def new_window(self, d, depth):
        self._wid += 1
        wid = f'{os.path.basename(self.fname)}#W{self._wid}'
        sm = d.find('summary', recursive=False)
        p, i = window_tabs(d)
        cls = d.get('class') or []
        self.windows[wid] = {'summary': norm(sm.get_text(' ')) if sm else '', 'tab_principe': p,
                             'tab_interpretation': i, 'monographie': ('monographie' in cls or 'mono' in cls),
                             'n_tables': len(d.find_all('table')), 'words': len(norm(d.get_text(' ')).split())}
        return wid

    def run(self):
        root = self.soup.body or self.soup
        self._block(root, depth=0, ctx='main')
        return self.blocks, self.windows

    def _emit(self, tag, buf, spans, depth, ctx, cell):
        text = ''.join(buf)
        lead = len(text) - len(text.lstrip())
        t = norm(text)
        if not t:
            return
        # recalcule les spans sur le texte normalisé (approximation : on retrouve les sous-chaînes)
        nspans = []
        for (a, b, wid, kind) in spans:
            frag = norm(text[a:b])
            if not frag:
                continue
            pos = t.find(frag)
            if pos >= 0:
                nspans.append((pos, pos + len(frag), wid, kind))
        self.blocks.append({'i': len(self.blocks), 'file': os.path.basename(self.fname), 'tag': tag, 'text': t,
                            'depth': depth, 'ctx': ctx, 'cell': cell, 'spans': nspans})

    def _block(self, el, depth, ctx, cell=False):
        buf, spans, deferred = [], [], []
        tag = el.name
        if tag in ('td', 'th', 'caption'):
            cell = True
            ctx = 'tableau' if ctx == 'main' else ctx
        def flush():
            nonlocal buf, spans
            self._emit(tag, buf, spans, depth, ctx, cell)
            buf, spans = [], []
            for fn in deferred:
                fn()
            deferred.clear()
        def inline(node):
            for ch in node.children:
                if isinstance(ch, NavigableString):
                    buf.append(str(ch)); continue
                if not isinstance(ch, Tag) or ch.name in SKIP:
                    continue
                if ch.name == 'br':
                    buf.append(' '); continue
                if ch.name == 'details':
                    if is_inline_details(ch) or ''.join(buf).strip():
                        wid = self.new_window(ch, depth + 1)
                        sm = ch.find('summary', recursive=False)
                        st = sm.get_text(' ') if sm else ''
                        a = len(''.join(buf)); buf.append(' ' + st + ' ')
                        spans.append((a, a + len(st) + 2, wid, 'details'))
                        kids = [k for k in ch.children if k is not sm]
                        def later(kids=kids, wid=wid):
                            for k in kids:
                                if isinstance(k, Tag) and k.name not in SKIP:
                                    self._block(k, depth + 1, 'fenetre', cell)
                                elif isinstance(k, NavigableString) and norm(str(k)):
                                    self.blocks.append({'i': len(self.blocks), 'file': os.path.basename(self.fname), 'tag': 'text',
                                                        'text': norm(str(k)), 'depth': depth + 1, 'ctx': 'fenetre', 'cell': cell, 'spans': []})
                        deferred.append(later)
                    else:
                        flush(); self._details_block(ch, depth, ctx, cell)
                    continue
                if ch.name in BLOCK:
                    flush(); self._block(ch, depth, ctx, cell); continue
                clickable = ch.name in CLICK_INLINE and (ch.name != 'a' or ch.get('href')) or ch.get('onclick') or ch.get('role') in ('tab', 'button') \
                            or ch.has_attr('popovertarget') or ch.has_attr('data-bs-toggle') or ch.has_attr('data-toggle')
                if clickable:
                    a = len(''.join(buf)); inline(ch); b = len(''.join(buf))
                    spans.append((a, b, None, ch.name))
                else:
                    inline(ch)
        if tag == 'details':
            self._details_block(el, depth, ctx, cell); return
        inline(el)
        flush()

    def _details_block(self, d, depth, ctx, cell):
        wid = self.new_window(d, depth + 1)
        mono = self.windows[wid]['monographie']
        sm = d.find('summary', recursive=False)
        if sm:
            t = norm(sm.get_text(' '))
            if t:
                self.blocks.append({'i': len(self.blocks), 'file': os.path.basename(self.fname), 'tag': 'summary', 'text': t,
                                    'depth': depth, 'ctx': 'titre' if mono else 'summary', 'cell': cell,
                                    'spans': [(0, len(t), wid, 'details')], 'mono': mono})
        ndepth = depth if mono else depth + 1
        nctx = ctx if mono else 'fenetre'
        for k in d.children:
            if k is sm: continue
            if isinstance(k, Tag) and k.name not in SKIP:
                self._block(k, ndepth, nctx, cell)
            elif isinstance(k, NavigableString) and norm(str(k)):
                self.blocks.append({'i': len(self.blocks), 'file': os.path.basename(self.fname), 'tag': 'text', 'text': norm(str(k)),
                                    'depth': ndepth, 'ctx': nctx, 'cell': cell, 'spans': []})

def linearize(path):
    raw = open(path, 'rb').read()
    html = raw.decode('utf-8', errors='replace')
    return Linearizer(html, path).run()

def lot_dir(lot):
    if lot.endswith('_AUDITE'):  # pseudo-LOT : fichiers corrigés « AUDITÉ »
        return os.path.join(BASE, 'corriges', lot[:-len('_AUDITE')])
    return os.path.join(BASE, 'originaux', lot)

def work(lot, name):
    os.makedirs(os.path.join(BASE, 'work', lot), exist_ok=True)
    return os.path.join(BASE, 'work', lot, name)
