import re,json
T1="LOT_218 à LOT_110 (109 lots, ordre décroissant : 218, 217, …, 110)"
T2="LOT_109 à LOT_1 (109 lots, ordre décroissant : 109, 108, …, 1)"
names={}
for n in range(1,9):
    d=open(f"desc_agent_{n}.txt").read()
    team1 = n%2==1
    rng="LOT_218–110" if team1 else "LOT_109–1"
    first="LOT_218" if team1 else "LOT_109"
    if n==1:
        d=re.sub(r"Série attribuée : .*?Ne touchez jamais à aucun autre LOT ni à aucun autre fichier\.",
          f"Série attribuée : {T1}. Vous rédigez UNIQUEMENT l'Appel A (plan et liste des 10 DX) et l'Appel B Partie 1 (DX.1–DX.2). Les Parties 2, 3 et 4 appartiennent aux Agents 3, 5 et 7 de votre équipe 1. LOT_219 à LOT_248 sont hors plage (LOT_227–228 faits, Appel A de LOT_229 laissé en place). Ne touchez jamais à aucun autre LOT ni à aucun autre fichier.",d,flags=re.S)
    elif n==2:
        d=re.sub(r"Série attribuée : .*?Ne touchez jamais à aucun autre LOT ni à aucun autre fichier\.",
          f"Série attribuée : {T2}. D'abord, complétez LOT_239 en ajoutant uniquement ses Parties 3 et 4, déjà rédigées (/workspace/lots/LOT_239/), puis une ligne à Tunder. Ensuite vous rédigez UNIQUEMENT l'Appel A (plan et liste des 10 DX) et l'Appel B Partie 1 (DX.1–DX.2). Pour LOT_001, vérifiez et réutilisez l'Appel A V7 déjà présent sur Drive. Les Parties 2, 3 et 4 appartiennent aux Agents 4, 6 et 8 de votre équipe 2. LOT_219 à LOT_248 sont hors plage. Ne touchez jamais à aucun autre LOT ni à aucun autre fichier.",d,flags=re.S)
    else:
        d=re.sub(r"Série attribuée : LOT_\d+ à LOT_\d+ \(9 lots\)", "Série attribuée : "+(T1 if team1 else T2), d)
    d=d.replace("LOT_X+1","LOT suivant en descendant (LOT_X−1)")
    d=re.sub(r"« LOT_2\d\d ", f"« {first} ", d)
    d=re.sub(r"\[FIN DE SÉRIE\] Agent (\d) — LOT_\d+–\d+", lambda m:f"[FIN DE SÉRIE] Agent {m.group(1)} — {rng}", d)
    d=d.replace("sous-dossier existant dont le nom commence par LOT_X","sous-dossier existant « LOT_NNN — … » (numéro sur 3 chiffres)")
    d=re.sub(r"Déposez uniquement (.*?), en \.html sans conversion",
      lambda m:f"En local, gardez les noms V7 ({m.group(1)}). Sur Drive, déposez-les en .html sans conversion sous le nom « Agent_{n} | LOT_X Appel A — Plan et liste des différentiels.html » ou « Agent_{n} | LOT_X Partie K — <noms des différentiels>.html »",d)
    d=d.replace("Ne commencez pas avant le signal de départ de Tunder.","Crédo : être concis, précision fine et élégante dans la formulation, EXHAUSTIF sur le fond, fenêtres et mots cliquables pour les précisions ; obsession : la grille des 14 parties. Lisez le SPEC.md du LOT en lecture seule s'il existe ; ne touchez pas aux fichiers _A_REDIGER. Instructions : /workspace/instructions_agents/instructions_agent_%d.md (v1.5)."%n)
    open(f"desc218_agent_{n}.txt","w").write(d)
    chap={1:"Appel A + Partie 1",2:"Appel A + Partie 1",3:"Partie 2",4:"Partie 2",5:"Partie 3",6:"Partie 3",7:"Partie 4",8:"Partie 4"}[n]
    names[n]=f"Agent {n} — Équipe {1 if team1 else 2} · {chap} ({rng})"
    print(n,len(d),names[n], re.findall(r"LOT_2[2-4]\d",d))
json.dump(names,open("names218.json","w"),ensure_ascii=False)
