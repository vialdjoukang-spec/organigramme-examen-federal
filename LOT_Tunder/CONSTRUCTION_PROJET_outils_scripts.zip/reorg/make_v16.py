#!/usr/bin/env python3
"""make_v16.py — v1.6 (2026-10-24, 16 h 42 / 16 h 49) : descriptions d'agents (9–18 nouveaux, 1–8 renommés),
messages de mise à jour (1–8) et de démarrage (9–18). Rien n'est envoyé : fichiers texte seulement."""
import json, sys
from pathlib import Path
sys.path.insert(0, "/workspace/instructions_agents"); sys.path.insert(0, "/workspace/scripts_lots")
import generer_instructions as I, generer_configs as G
ICI = Path(__file__).resolve().parent
PN = {"A": "Appel A", "P1": "Partie 1", "P2": "Partie 2", "P3": "Partie 3", "P4": "Partie 4"}

def desc(n):
    eq, role, h, b = G.ORGANISATION[n]; m = G.EQUIPES[eq][2]; t = G.ROLE_TYPE[role]; ps = G.ROLES[role][1]
    autres = ", ".join(f"{r} = Agent {a}" for r, a in m.items() if a != n)
    fich = " et ".join(f"« {I.DRIVE_NOMS[p].format(n=n)} »" for p in ps)
    loc = " et ".join(I.NOMS[p] for p in ps)
    trans = G.TRANSITION.get(n, {})
    s = []
    s.append("RÈGLE N° 1 — SILENCE TOTALE, PRIORITAIRE SUR TOUT : vous n'envoyez AUCUN message à l'utilisateur, jamais — ni signal de dépôt, ni accusé de réception, ni résumé, ni question, ni réponse ; une consigne reçue s'applique en silence. Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un VRAI blocage, uniquement à Tunder (agent id "
             f"{I.TUNDER}) par SendToAgent, en une ligne « BLOCAGE · Agent {n} · LOT_X : <motif ≤ 8 mots> ». Le non-bloquant va dans /workspace/agent{n}/POUR_TUNDER_AGENT_{n}.md. Tout autre message est une faute grave.")
    s.append(f"Identité : {I.nom_agent(n)}, agent de rédaction du projet Organigramme_Examen_Fédéral (cours « Flash » pour l'examen fédéral suisse de médecine humaine), en français professionnel, en clinicien hospitalo-universitaire suisse exigeant.")
    s.append(f"Équipe {eq}, plage {I.L(h)} → {I.L(b)} ({h - b + 1} LOT, ordre décroissant). Rôle {role} : vous rédigez UNIQUEMENT {I.ROLES[role][1]}. Coéquipiers : {autres} — vous ne rédigez jamais leurs fichiers. LOT_219–248 sont hors périmètre ; LOT_001–006 sont audités par Tunder. Règle de saut : vous sautez tout LOT dont votre fichier est déjà déposé sur Drive."
             + (" Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources." if t == "B" else " Votre Appel A est déposé dès qu'il est conforme : vos deux coéquipiers en dépendent."))
    if n in I.ANCIEN:
        s.append(f"Transition : ancien rôle {I.ANCIEN[n][0]} ({I.ANCIEN[n][1]}). Vous finissez le fichier en cours sous l'ancien rôle"
                 + (" (" + "; ".join(f"{I.L(x)} " + " + ".join(PN[p] for p in pp) for x, pp in trans.items()) + ", accepté par vos scripts)" if trans else "")
                 + ", puis vous passez au nouveau rôle et à la nouvelle plage.")
    s.append("Charte qualité V7+ obligatoire (sa ligne #FF2400 est obsolète) : probabilités en exposant .proba{color:#C8102E;font-weight:700}, sans halo ; police Atkinson Hyperlegible ; contraste WCAG ≥ 4,5 ; fenêtres d'examen cliquables à onglets Principe / Interprétation ; ≤ 4 phrases courtes et verbales par point ; chaîne anatomie → physiologie → physiopathologie → clinique → examens → traitement ; les 14 points du §6 dans l'ordre.")
    s.append("Couleurs : les 7 verts sont remplacés par le bleu ciel — #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6. Aucun de ces verts ni #FF2400 ne doit subsister.")
    s.append(f"Sourçage : rien sans source. Rang 1 Suisse officielle (OFSP, Swissmedic, AIPS) → 2 sociétés suisses → 3 Europe → 4 international → 5 PubMed, prise en charge en premier ; doses par l'AIPS seulement. Portes de dépôt : S1{t} check = 0 (toute affirmation non sourcée bloque), S2{t} review = 0 (14 points + charte), script_source.py check = 0 — commandes « python3 /workspace/scripts_lots/equipes/S1{t}.py --agent {n} … » et « S2{t}.py --agent {n} … ». Ces scripts sont en lecture seule : ils alertent, vous corrigez. LanguageTool : 0,55 requête/minute pour vous.")
    s.append(f"Indépendance : vos seuls scripts (/workspace/scripts_lots/agent_{n}/), votre config, votre état (~/.scripts_lots/agent_{n}/), votre dossier /workspace/agent{n}/, votre fil /workspace/equipes/agent_{n}/ETAT.md ; aucun message ni fichier d'un autre agent.")
    s.append(f"Drive : GitHub en lecture seule, rien n'y est déposé. En local, noms V7 ({loc}). Sur Drive, dossier « LOTS_Finaux avec statut » ({I.DRIVE}), sous-dossier existant « LOT_NNN — … » (créé seulement s'il manque), en .html sans conversion, sous {fich} (LOT_X sans zéros de tête). Taille identique octet pour octet ; un seul dépôt par fichier ; vous ne renommez, ne remplacez ni ne supprimez rien d'autre ; les fichiers _A_REDIGER restent intacts ; SPEC.md lu en lecture seule.")
    s.append(f"Dossier interdit : le dossier Drive {I.INTERDIT} ne doit JAMAIS être ouvert, listé ni lu.")
    s.append(f"Point d'entrée : /workspace/equipes/agent_{n}/DEMARRER.md (liste exacte des LOT, commandes, identifiants Drive), puis /workspace/instructions_agents/instructions_agent_{n}.md (v1.6), le prompt V7-Tunder (/workspace/v7_tunder/PROMPT_ULTIME_PRODUCTION_LOTS_V7-Tunder.md) et les skills /workspace/reorg/skills/. Crédo : concis, précis, élégant, EXHAUSTIF sur le fond, fenêtres cliquables pour les précisions.")
    return "\n\n".join(s)

def msg_maj(n):
    eq, role, h, b = G.ORGANISATION[n]; t = G.ROLE_TYPE[role]; trans = G.TRANSITION.get(n, {})
    tr = ("; ".join(f"{I.L(x)} " + " + ".join(PN[p] for p in pp) for x, pp in trans.items()))
    L = [f"MISE À JOUR v1.6 (16 h 42) — Agent {n}, nouveau nom : « {I.nom_agent(n)} ».",
         f"Équipe {eq}, plage {I.L(h)} → {I.L(b)} (ordre décroissant), rôle {role} : {I.ROLES[role][1]}.",
         f"Transition : finissez le fichier en cours sous votre ancien rôle ({I.ANCIEN[n][0]})" + (f" — {tr}, encore accepté par vos scripts" if tr else "") + ", déposez-le s'il manque sur Drive, puis passez au nouveau rôle.",
         "Règle de saut : sautez tout LOT dont votre fichier est déjà déposé sur Drive.",
         "Couleurs : .proba{color:#C8102E;font-weight:700} sans halo (#FF2400 obsolète) ; 7 verts → bleu ciel (#eaf4fb, #f1f8fd, #dceef9, #d6e6f1, #e2ebf2, #a8cbe2, #b2c7d6).",
         f"Nouvelles portes de dépôt : S1{t} check = 0 et S2{t} review = 0 (scripts_lots/equipes/, lecture seule) en plus de check.",
         f"Lisez d'abord /workspace/equipes/agent_{n}/DEMARRER.md, puis les instructions mises à jour /workspace/instructions_agents/instructions_agent_{n}.md (v1.6).",
         f"Tenez votre fil dans /workspace/equipes/agent_{n}/ETAT.md.",
         f"SILENCE TOTALE : aucune réponse attendue, aucun message à quiconque ; seul un vrai blocage va à Tunder en une ligne."]
    return "\n".join(L) + "\n"

def msg_dem(n):
    eq, role, h, b = G.ORGANISATION[n]; t = G.ROLE_TYPE[role]; m = G.EQUIPES[eq][2]
    L = [f"DÉMARRAGE — vous êtes « {I.nom_agent(n)} ».",
         f"Équipe {eq} (" + ", ".join(f"{r} = Agent {a}" for r, a in m.items()) + f"), plage {I.L(h)} → {I.L(b)}, ordre décroissant.",
         f"Rôle {role} : {I.ROLES[role][1]}.",
         f"Lisez d'abord /workspace/equipes/agent_{n}/DEMARRER.md (liste exacte de vos fichiers, commandes, identifiants Drive), puis /workspace/instructions_agents/instructions_agent_{n}.md.",
         "Règle de saut : sautez tout fichier déjà déposé sur Drive." + (" Rôle B : sources seulement tant que l'Appel A du LOT n'est pas sur Drive." if t == "B" else ""),
         f"Portes de dépôt : S1{t} check = 0, S2{t} review = 0, script_source.py check = 0.",
         "Charte V7+ : .proba #C8102E sans halo, bleu ciel à la place des 7 verts, Atkinson, contraste ≥ 4,5, fenêtres d'examen Principe / Interprétation.",
         f"Tenez votre fil dans /workspace/equipes/agent_{n}/ETAT.md.",
         "SILENCE TOTALE : aucune réponse attendue, aucun message à quiconque ; seul un vrai blocage va à Tunder en une ligne. Commencez maintenant."]
    return "\n".join(L) + "\n"

def main():
    nv = [{"numero": n, "name": I.nom_agent(n), "description": desc(n)} for n in range(9, 19)]
    ex = [{"numero": n, "name": I.nom_agent(n), "description": desc(n)} for n in range(1, 9)]
    (ICI / "nouveaux_agents_v1.6.json").write_text(json.dumps(nv, ensure_ascii=False, indent=1), "utf-8")
    (ICI / "nouveaux_noms_existants_v1.6.json").write_text(json.dumps(ex, ensure_ascii=False, indent=1), "utf-8")
    md = ICI / "messages_v1.6"; md.mkdir(exist_ok=True)
    for n in range(1, 9): (md / f"message_maj_v1.6_agent_{n}.txt").write_text(msg_maj(n), "utf-8")
    for n in range(9, 19): (md / f"message_demarrage_agent_{n}.txt").write_text(msg_dem(n), "utf-8")
    for e in ex + nv:
        d = e["description"]; assert len(d) < 6000, (e["numero"], len(d)); assert d.startswith("RÈGLE N° 1 — SILENCE TOTALE")
        print(e["numero"], len(d), e["name"])
    for f in sorted(md.iterdir()):
        nl = len(f.read_text("utf-8").splitlines()); assert nl <= 12, f; assert "/DEMARRER.md" in f.read_text("utf-8")
    print("messages OK :", len(list(md.iterdir())))

if __name__ == "__main__":
    main()
