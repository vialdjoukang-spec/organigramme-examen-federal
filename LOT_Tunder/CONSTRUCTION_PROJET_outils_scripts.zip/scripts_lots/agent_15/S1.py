#!/usr/bin/env python3
"""Agent 15 — équipe 5, Appel B Parties 1–2 (DX.1–DX.5), LOT_078→LOT_043 (décroissant) — raccourci vers equipes/S1B.py avec la configuration de CET agent (lecture seule absolue sur les LOT)."""
import sys
from pathlib import Path
ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI.parent / "equipes"))
import s1_sources
sys.exit(s1_sources.main("B", ["--config", str(ICI / "config.json")] + sys.argv[1:]))
