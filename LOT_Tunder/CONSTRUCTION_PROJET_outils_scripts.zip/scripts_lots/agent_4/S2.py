#!/usr/bin/env python3
"""Agent 4 — équipe 4, Appel B Parties 1–2 (DX.1–DX.5), LOT_113→LOT_079 (décroissant) — raccourci vers equipes/S2B.py avec la configuration de CET agent (lecture seule absolue sur les LOT)."""
import sys
from pathlib import Path
ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI.parent / "equipes"))
import s2_conformite
sys.exit(s2_conformite.main("B", ["--config", str(ICI / "config.json")] + sys.argv[1:]))
