#!/usr/bin/env python3
"""Génère agent_1 … agent_18 (config.json + enveloppes minces) pour l'organisation v1.6 (2026-10-24, 16 h 42) :
6 équipes de 3 agents = 18 agents de rédaction, travail DESCENDANT de LOT_218 à LOT_007, sans chevauchement.
Dans chaque équipe : rôle A = Appel A seul ; rôle B1 = Appel B Parties 1 et 2 (DX.1–DX.5) ; rôle B2 = Appel B Parties 3 et 4 (DX.6–DX.10).
LOT_219–248 hors périmètre (déjà produits) ; LOT_001–006 audités par Tunder (hors périmètre de rédaction).
Déterministe, bibliothèque standard. Relancer après toute modification de EQUIPES, TRANSITION ou des débits.

Loi d'indépendance absolue : chaque agent a ses propres cache, retours, compteur ET état des seaux
(~/.scripts_lots/agent_N/etat) ; le dossier ~/.scripts_lots/partage n'est utilisé par aucune configuration.

Partage des budgets externes (les 18 agents ensemble restent sous les anciennes limites globales) :
  LanguageTool : 10 req/min et 60 000 o/min au total → 0,55 req/min (9,9 au total) et 3 333 o/min par agent (59 994 o/min) ;
                 requête ≤ 2 700 o (capacité 3 240 o ; rafale cumulée 58 320 o ≤ 60 000 o) ; 1 requête par passage.
  NCBI E-utilities : 3 req/s sans clé → 3/18 ≈ 0,1667 req/s par agent ; 10 req/s avec clé → 10/18 ≈ 0,5556 req/s.
  Par domaine : 1 req/s → 1/18 ≈ 0,0556 req/s par agent et par domaine (une requête toutes les 18 s ; capacité 1 jeton).
"""
import json
from pathlib import Path

ICI = Path(__file__).resolve().parent
TOUT = ["A", "P1", "P2", "P3", "P4"]
ROLES = {"A": ("Appel A (plan et liste des 10 DX)", ["A"]),
         "B1": ("Appel B Parties 1–2 (DX.1–DX.5)", ["P1", "P2"]),
         "B2": ("Appel B Parties 3–4 (DX.6–DX.10)", ["P3", "P4"])}
# équipe: (LOT de départ (haut), LOT d'arrivée (bas), {rôle: agent})
EQUIPES = {1: (218, 184, {"A": 1, "B1": 3, "B2": 5}),
           2: (183, 149, {"A": 9, "B1": 10, "B2": 7}),
           3: (148, 114, {"A": 11, "B1": 12, "B2": 13}),
           4: (113, 79, {"A": 2, "B1": 4, "B2": 6}),
           5: (78, 43, {"A": 14, "B1": 15, "B2": 8}),
           6: (42, 7, {"A": 16, "B1": 17, "B2": 18})}
ROLE_TYPE = {"A": "A", "B1": "B", "B2": "B"}
NB_AGENTS = sum(len(m) for _, _, m in EQUIPES.values())          # 18
# Historique antérieur conservé (contrôle/relecture/dépôt de l'existant seulement, aucun nouveau travail).
HISTORIQUE = {1: {227: TOUT, 228: TOUT, 229: ["A", "P1"]}, 2: {238: TOUT, 239: TOUT}}
# Règle de transition (16 h 42) : un agent existant finit le fichier EN COURS sous son ancien rôle, puis bascule.
# Relevé déterministe des dossiers de travail à 16 h 4x : seul fichier en cours hors du nouveau rôle/de la nouvelle plage :
#   Agent 2 — LOT_007 Appel A (/workspace/agent2/LOT_007/LOT_007_Appel_A_V7_Plan_et_Liste.html, 16:43).
#   (Agent 1 : LOT_213 Appel A, dans son nouveau rôle ; Agents 3–8 : aucun fichier de LOT_213 ou LOT_007 entamé.)
#   Relevé complémentaire de 17 h 00 : Agent 1 a terminé LOT_213 Partie 1 (16:59) sous son ancien rôle (A + P1) ;
#   ce fichier lui reste rattaché (contrôle/dépôt), LOT_213 Partie 2 reste à l'Agent 3.
#   Relevé de 17 h 05 : l'équipe 2 v1.5 poursuit le LOT_007 sous ses anciens rôles (Agent 2 : Partie 1 terminée à 17 h 02 ;
#   Agent 8 : Partie 4 terminée à 17 h 05 ; Agents 4 et 6 : sources + copie de l'Appel A, Parties 2 et 3 en cours) : transition élargie.
TRANSITION = {1: {213: ["P1"]}, 2: {7: ["A", "P1"]}, 4: {7: ["P2"]}, 6: {7: ["P3"]}, 8: {7: ["P4"]}}
DOSSIERS_SUP = {2: ["/workspace/lots"]}       # ancien dossier de l'Agent 2 (LOT_238–239)

def organisation():
    o = {}
    for eq, (haut, bas, membres) in EQUIPES.items():
        for role, n in membres.items():
            o[n] = (eq, role, haut, bas)
    assert sorted(o) == list(range(1, NB_AGENTS + 1)), sorted(o)
    return o
ORGANISATION = organisation()

def lots_de(n):
    """Série dans l'ordre de traitement (décroissant), puis LOT de transition, puis historique (croissant)."""
    _, _, haut, bas = ORGANISATION[n]
    serie = list(range(haut, bas - 1, -1))
    extra = sorted(x for x in TRANSITION.get(n, {}) if x not in serie) + sorted(HISTORIQUE.get(n, {}))
    return serie + extra

LT = {"budget_req_per_min": 0.55, "budget_bytes_per_min": 60000 // NB_AGENTS,
      "max_bytes_per_request": 2700, "max_requests_per_pass": 1}
PUBMED = {"rate_per_s_without_key": 3 / NB_AGENTS, "rate_per_s_with_key": 10 / NB_AGENTS, "mcp_url": ""}
HTTP = {"per_domain_per_s": 1.0 / NB_AGENTS}

ENVELOPPE_EQ = '''#!/usr/bin/env python3
"""Agent {n} — {titre} — raccourci vers equipes/{script}.py avec la configuration de CET agent (lecture seule absolue sur les LOT)."""
import sys
from pathlib import Path
ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI.parent / "equipes"))
import {mod}
sys.exit({mod}.main("{profil}", ["--config", str(ICI / "config.json")] + sys.argv[1:]))
'''

ENVELOPPE = '''#!/usr/bin/env python3
"""Agent {n} — {titre} — point d'entrée mince vers common/{mod}.py avec la configuration de CET agent uniquement."""
import sys
from pathlib import Path
ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI.parent / "common"))
import {mod}
sys.exit({mod}.main(ICI / "config.json", sys.argv[1:]))
'''

def parties_autorisees(n):
    _, role, _, _ = ORGANISATION[n]
    parties = ROLES[role][1]
    special = {}
    for x, p in TRANSITION.get(n, {}).items():
        special[x] = sorted(set(p) | (set(parties) if x in range(ORGANISATION[n][3], ORGANISATION[n][2] + 1) else set()), key=TOUT.index)
    for x, p in HISTORIQUE.get(n, {}).items():
        special[x] = list(p)
    return {**{str(x): p for x, p in sorted(special.items())}, "*": list(parties)} if special else list(parties)

def config(n):
    eq, role, haut, bas = ORGANISATION[n]
    libelle = ROLES[role][0]
    lots = lots_de(n)
    r = f"~/.scripts_lots/agent_{n}"
    dossiers = [f"/workspace/agent{n}"] + DOSSIERS_SUP.get(n, [])
    com = f"Agent {n} — équipe {eq} — rôle {role} : {libelle} — LOT_{haut:03d}→LOT_{bas:03d} (ordre décroissant, v1.6 du 2026-10-24)"
    if TRANSITION.get(n):
        com += " ; transition (fichier en cours sous l'ancien rôle) : " + ", ".join(f"LOT_{x:03d} ({'+'.join(p)})" for x, p in sorted(TRANSITION[n].items()))
    if HISTORIQUE.get(n):
        com += " ; historique conservé : " + ", ".join(f"LOT_{x} ({'entier' if p == TOUT else '+'.join(p)})" for x, p in sorted(HISTORIQUE[n].items()))
    com += ". Indépendance absolue : tous les chemins inscriptibles, y compris l'état des seaux, sont propres à cet agent."
    return {
        "_commentaire": com,
        "agent": n, "equipe": eq, "chapitre": libelle, "role": role,
        "equipes": {"S1": f"/workspace/scripts_lots/equipes/S1{ROLE_TYPE[role]}.py", "S2": f"/workspace/scripts_lots/equipes/S2{ROLE_TYPE[role]}.py",
                    "demarrer": f"/workspace/equipes/agent_{n}/DEMARRER.md", "etat": f"/workspace/equipes/agent_{n}/ETAT.md",
                    "skills": "/workspace/reorg/skills"},
        "lot_min": min(lots), "lot_max": max(lots), "lots": lots,
        "parties_autorisees": parties_autorisees(n), "dossier_travail": dossiers if len(dossiers) > 1 else dossiers[0],
        "lots_root": None,
        "cache_dir": f"{r}/cache", "output_dir": f"{r}/retours", "shared_state_dir": f"{r}/etat",
        "prompt_path": "/workspace/v7_tunder/PROMPT_ULTIME_PRODUCTION_LOTS_V7-Tunder.md",
        "enforce_os_readonly": False,
        "languagetool": dict(LT), "pubmed": dict(PUBMED), "http": dict(HTTP),
        "compteur": {"csv": f"{r}/COMPTEUR_TOKENS_AGENT_{n}.csv"},
    }

def main():
    for n in sorted(ORGANISATION):
        d = ICI / f"agent_{n}"; d.mkdir(exist_ok=True)
        Path(f"/workspace/agent{n}").mkdir(exist_ok=True)
        eq, role, a, b = ORGANISATION[n]
        titre = f"équipe {eq}, {ROLES[role][0]}, LOT_{a:03d}→LOT_{b:03d} (décroissant)"
        (d / "config.json").write_text(json.dumps(config(n), ensure_ascii=False, indent=1) + "\n", "utf-8")
        for f, mod in (("script_source.py", "source_engine"), ("script_synchrone.py", "sync_reviewer")):
            (d / f).write_text(ENVELOPPE.format(n=n, titre=titre, mod=mod), "utf-8"); (d / f).chmod(0o755)
        t = ROLE_TYPE[role]
        for f, mod in (("S1.py", "s1_sources"), ("S2.py", "s2_conformite")):
            (d / f).write_text(ENVELOPPE_EQ.format(n=n, titre=titre, script=f[:2] + t, mod=mod, profil=t), "utf-8"); (d / f).chmod(0o755)
        print(f"agent_{n} : {titre}")

if __name__ == "__main__":
    main()
