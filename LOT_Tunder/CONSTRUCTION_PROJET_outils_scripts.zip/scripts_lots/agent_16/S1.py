#!/usr/bin/env python3
"""Agent 16 — équipe 6, Appel A (plan et liste des 10 DX), LOT_042→LOT_007 (décroissant) — raccourci vers equipes/S1A.py avec la configuration de CET agent (lecture seule absolue sur les LOT)."""
import sys
from pathlib import Path
ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI.parent / "equipes"))
import s1_sources
sys.exit(s1_sources.main("A", ["--config", str(ICI / "config.json")] + sys.argv[1:]))
