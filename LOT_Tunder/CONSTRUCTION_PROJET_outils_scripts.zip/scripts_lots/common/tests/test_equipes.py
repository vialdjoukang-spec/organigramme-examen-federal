"""v1.6 — scripts d'équipe S1A / S1B / S2A / S2B (sur LOT FICTIFS uniquement) :
lecture seule absolue (sha256 avant/après, aucune ouverture en écriture, droits OS), refus hors périmètre / hors type,
tableau de 14 lignes, contrôles de la Charte V7+, alertes bloquantes de sourçage — pour les 18 agents."""
import builtins, contextlib, io, json, os, sys, tempfile, unittest
from pathlib import Path
from fabrique_lot import fabriquer, monographie
RACINE = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(RACINE / "equipes")); sys.path.insert(0, str(RACINE))
import generer_configs as G
import noyau, s1_sources, s2_conformite, lot_readonly

STYLE_OK = "<style>body{font-family:\"Atkinson Hyperlegible\",Verdana,Arial,sans-serif;color:#1a1a1a;background:#ffffff}.proba{color:#C8102E;font-weight:700}.enc{background:#eaf4fb;color:#0b3d5c}</style>"
STYLE_ANCIEN = "<style>body{font-family:Arial}.proba{color:#FF2400;font-weight:700;text-shadow:0 0 4px #FF2400AA}.enc{background:#edf7f4;color:#999999}</style>"
EXAMEN = ("<details class='ex'><summary>natrémie</summary><div class='exw'><div class='onglets'><input type='radio' name='o1' id='o1p' checked>"
          "<label for='o1p'>Principe</label><input type='radio' name='o1' id='o1i'><label for='o1i'>Interprétation</label>"
          "<div class='op'>Le dosage mesure le sodium [S1].</div><div class='oi'>Une valeur sous 135 mmol/L signe une hyponatrémie [S1].</div></div></div></details>")

def fichier_a(chemin, lot, style=STYLE_OK, proba_source=True):
    m = monographie(1, ()).replace("<details open><summary>DX.1 — Hyponatrémie de type 1</summary>", "<details open><summary>Bloc 1 — SSP hyponatrémie</summary>")
    ref = " [S1]" if proba_source else ""
    dx = "".join(f"<li>DX.{i} — Cause {i} <sup class=\"proba\">≈ {i} %</sup>{ref}</li>" for i in range(1, 11))
    bloc2 = ("<h3>Bloc 2 — Liste ordonnée des 10 DX</h3><p>L'ordre suit la fréquence suisse pondérée par la gravité [S1].</p><ol>" + dx + "</ol>"
             "<div style='overflow-x:auto;'><table><tr><th>DX</th><th>Signe clé</th><th>Examen clé</th><th>Conduite</th></tr>"
             + "".join(f"<tr><td>DX.{i}</td><td>s</td><td>e</td><td>c</td></tr>" for i in range(1, 11)) + "</table></div>"
             "<p>L'algorithme discriminant écarte d'abord les causes graves à ne pas manquer [S1].</p>")
    html = ("<!DOCTYPE html>\n<html lang='fr'><head><meta charset='utf-8'>" + style + "</head><body>\n<h2>LOT fictif</h2>\n" + m.replace("<p><strong>9.", EXAMEN + "<p><strong>9.")
            + bloc2 + "<h2>Sources</h2><ol><li>[S1] Swissmedic, 2026, https://www.swissmedicinfo.ch/ (consulté le 2026-10-24)</li>"
            "<li>[S2] OFSP, 2026, https://www.bag.admin.ch/ (consulté le 2026-10-24)</li></ol>"
            "<p>Contenu produit par IA ; non validé cliniquement par un médecin.</p></body></html>\n" f"<!-- FIN_FICHIER LOT_{lot}_Appel_A -->\n")
    Path(chemin).parent.mkdir(parents=True, exist_ok=True); Path(chemin).write_text(html, "utf-8"); return chemin

NOMS = {"A": "LOT_{n:03d}_Appel_A_V7_Plan_et_Liste.html", "P1": "LOT_{n:03d}_Appel_B_V7_Partie_1_DX.1_a_DX.2.html",
        "P2": "LOT_{n:03d}_Appel_B_V7_Partie_2_DX.3_a_DX.5.html", "P3": "LOT_{n:03d}_Appel_B_V7_Partie_3_DX.6_a_DX.7.html",
        "P4": "LOT_{n:03d}_Appel_B_V7_Partie_4_DX.8_a_DX.10.html"}

def lancer(fonction, *args):
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        rc = fonction(*args)
    return rc, out.getvalue(), err.getvalue()

class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.r = Path(self.tmp.name)
    def tearDown(self):
        for p in self.r.rglob("*"):
            try: os.chmod(p, 0o755 if p.is_dir() else 0o644)
            except OSError: pass
        self.tmp.cleanup()
    def cfg(self, n, **extra):
        c = G.config(n); t = self.r / f"agent_{n}"
        c.update(dossier_travail=str(t / "travail"), cache_dir=str(t / "cache"), output_dir=str(t / "retours"),
                 shared_state_dir=str(t / "etat"), compteur={"csv": str(t / "c.csv")}, languagetool=dict(c["languagetool"], enabled=False))
        c.update(extra); p = self.r / f"cfg_{n}.json"; p.write_text(json.dumps(c)); return p, c
    def fichier(self, c, partie, n=None, **kw):
        n = n or G.lots_de(c["agent"])[0]
        ch = Path(c["dossier_travail"]) / f"LOT_{n:03d}" / NOMS[partie].format(n=n)
        if partie == "A": return fichier_a(ch, n, **kw)
        return Path(fabriquer(ch, lot=n, nb=2, defauts=kw.get("defauts", ()), cible=30_000)[0])

class TestDix_huitAgents(Base):
    def test_s1_s2_lecture_seule_et_14_lignes_pour_les_18(self):
        for n in range(1, 19):
            p, c = self.cfg(n); role = G.ORGANISATION[n][1]; prof = noyau.ROLE_TYPE[role]
            crees = []
            for partie in G.ROLES[role][1]:
                f = self.fichier(c, partie); dossier = f.parent; crees.append(f.name)
                avant = lot_readonly.empreintes(dossier); h = noyau.sha256(f)
                rc1, o1, e1 = lancer(s1_sources.main, prof, ["--config", str(p), "check", str(f), "--format", "json"])
                rc2, o2, e2 = lancer(s2_conformite.main, prof, ["--config", str(p), "review", str(f), "--format", "json"])
                self.assertIn(rc1, (0, 1), (n, partie, e1)); self.assertIn(rc2, (0, 1), (n, partie, e2))
                r = json.loads(o2)
                self.assertEqual([x["point"] for x in r["points_14"]], list(range(1, 15)))
                self.assertTrue(all(x["statut"] in ("CONFORME", "ALERTE", "ÉCHEC") and x["references"] for x in r["points_14"]))
                self.assertEqual(noyau.sha256(f), h); self.assertEqual(lot_readonly.empreintes(dossier), avant)
                self.assertEqual(sorted(x.name for x in dossier.iterdir()), sorted(crees))          # rien d'ajouté au LOT
                rapports = list((Path(c["output_dir"]) / "equipes").rglob(f"{f.stem}.S*"))
                self.assertEqual(len(rapports), 4, (n, partie))                                 # S1 + S2, .md + .json, hors du LOT

    def test_configs_designent_le_bon_profil(self):
        for n in range(1, 19):
            c = G.config(n); t = noyau.ROLE_TYPE[c["role"]]
            self.assertTrue(c["equipes"]["S1"].endswith(f"S1{t}.py") and c["equipes"]["S2"].endswith(f"S2{t}.py"))
            self.assertTrue((RACINE / f"agent_{n}" / "S1.py").is_file() and (RACINE / f"agent_{n}" / "S2.py").is_file())

class TestRefus(Base):
    def test_type_perimetre_et_role(self):
        p9, c9 = self.cfg(9); fa = self.fichier(c9, "A")
        self.assertEqual(lancer(s1_sources.main, "B", ["--config", str(p9), "check", str(fa)])[0], 2)    # S1B sur un Appel A
        self.assertEqual(lancer(s2_conformite.main, "B", ["--config", str(p9), "review", str(fa)])[0], 2)
        p10, c10 = self.cfg(10); f3 = self.fichier(c10, "P1"); f3 = f3.rename(f3.with_name(NOMS["P3"].format(n=183)))
        self.assertEqual(lancer(s2_conformite.main, "B", ["--config", str(p10), "review", str(f3)])[0], 2)  # P3 hors rôle B1
        p1, c1 = self.cfg(1); fhors = self.fichier(c1, "A", n=150)                                          # LOT de l'équipe 2
        rc, _, err = lancer(s2_conformite.main, "A", ["--config", str(p1), "review", str(fhors)])
        self.assertEqual(rc, 2); self.assertIn("hors de la série", err)
        self.assertFalse((Path(c1["output_dir"]) / "equipes").exists())                                    # refus AVANT toute écriture

class TestLectureSeule(Base):
    def test_aucune_ouverture_en_ecriture_dans_le_lot(self):
        p, c = self.cfg(17); f = self.fichier(c, "P1"); dossier = str(f.parent.resolve())
        ecritures = []; o_open, o_osopen = builtins.open, os.open
        def espion_open(fich, mode="r", *a, **k):
            if any(x in mode for x in "wax+") and str(Path(fich).resolve()).startswith(dossier): ecritures.append((fich, mode))
            return o_open(fich, mode, *a, **k)
        def espion_osopen(fich, flags, *a, **k):
            if flags & (os.O_WRONLY | os.O_RDWR | os.O_APPEND | os.O_CREAT | os.O_TRUNC) and str(Path(fich).resolve()).startswith(dossier): ecritures.append((fich, flags))
            return o_osopen(fich, flags, *a, **k)
        builtins.open, os.open = espion_open, espion_osopen
        try:
            lancer(s1_sources.main, "B", ["--config", str(p), "check", str(f)]); lancer(s2_conformite.main, "B", ["--config", str(p), "review", str(f)])
        finally:
            builtins.open, os.open = o_open, o_osopen
        self.assertEqual(ecritures, [])

    def test_lot_en_lecture_seule_os_et_mode_strict(self):
        p, c = self.cfg(16, enforce_os_readonly=True); f = self.fichier(c, "A"); h = noyau.sha256(f)
        os.chmod(f, 0o444); os.chmod(f.parent, 0o555)
        if os.geteuid() != 0:
            for mod in (s1_sources, s2_conformite):
                self.assertIn(lancer(mod.main, "A", ["--config", str(p), "check" if mod is s1_sources else "review", str(f)])[0], (0, 1))
        self.assertEqual(noyau.sha256(f), h)

    def test_modification_externe_detectee_code_3_sans_rapport(self):
        p, c = self.cfg(13); f = self.fichier(c, "P3"); orig = s2_conformite.controler
        def saboteur(raw, et):
            with open(f, "a") as x: x.write("<!-- modif externe -->")
            return orig(raw, et)
        s2_conformite.controler = saboteur
        try:
            rc, _, err = lancer(s2_conformite.main, "B", ["--config", str(p), "review", str(f)])
        finally:
            s2_conformite.controler = orig
        self.assertEqual(rc, 3); self.assertIn("LOT modifié", err)
        self.assertEqual(list((Path(c["output_dir"]) / "equipes").rglob("*.S2B.*")), [])

    def test_ecrire_sortie_refuse_le_lot(self):
        p, c = self.cfg(9); f = self.fichier(c, "A")
        with self.assertRaises(noyau.ViolationLectureSeule):
            noyau.publier(dict(c, output_dir=str(f.parent)), 183, "x.md", "x", str(f.parent))

class TestCharteEtSources(Base):
    def test_charte_conforme_puis_ancienne(self):
        p, c = self.cfg(11)
        f = self.fichier(c, "A")
        r = json.loads(lancer(s2_conformite.main, "A", ["--config", str(p), "review", str(f), "--format", "json"])[1])
        ch = {x["code"]: x["statut"] for x in r["charte"]}
        for k in ("C1", "C2", "C3", "C4", "C5"): self.assertEqual(ch[k], "CONFORME", (k, r["charte"]))
        self.assertTrue(all(x["statut"] != "ÉCHEC" for x in r["bloc2"]))
        f2 = self.fichier(c, "A", n=147, style=STYLE_ANCIEN)
        r2 = json.loads(lancer(s2_conformite.main, "A", ["--config", str(p), "review", str(f2), "--format", "json"])[1])
        ch2 = {x["code"]: x for x in r2["charte"]}
        self.assertEqual(ch2["C1"]["statut"], "ÉCHEC"); self.assertIn("#FF2400", ch2["C1"]["detail"]); self.assertIn("halo", ch2["C1"]["detail"])
        self.assertEqual(ch2["C2"]["statut"], "ÉCHEC"); self.assertEqual(ch2["C3"]["statut"], "ÉCHEC"); self.assertEqual(ch2["C4"]["statut"], "ÉCHEC")

    def test_contraste_wcag(self):
        self.assertAlmostEqual(s2_conformite.contraste("#777777", "#ffffff"), 4.48, places=2)
        self.assertGreaterEqual(s2_conformite.contraste("#c8102e", "#ffffff"), 4.5)
        self.assertLess(s2_conformite.contraste("#ff2400", "#ffffff"), 4.5)

    def test_point_absent_echec_au_bon_numero(self):
        p, c = self.cfg(12); f = self.fichier(c, "P1", defauts=("point_manquant",))
        r = json.loads(lancer(s2_conformite.main, "B", ["--config", str(p), "review", str(f), "--format", "json"])[1])
        self.assertEqual(r["points_14"][11]["statut"], "ÉCHEC"); self.assertIn("point absent", r["points_14"][11]["detail"])

    def test_s1_alertes_bloquantes(self):
        p, c = self.cfg(15); f = self.fichier(c, "P2", defauts=("pec_sans_source",))
        rc, out, _ = lancer(s1_sources.main, "B", ["--config", str(p), "check", str(f)])
        self.assertEqual(rc, 1); self.assertIn("DÉPÔT BLOQUÉ", out)
        p14, c14 = self.cfg(14); fa = self.fichier(c14, "A", proba_source=False)
        rc, out, _ = lancer(s1_sources.main, "A", ["--config", str(p14), "check", str(fa), "--format", "json"])
        self.assertEqual(rc, 1); self.assertTrue(any(x["section"] == "§9.3" and x["gravite"] == "P1" for x in json.loads(out)["items"]))

    def test_s1_plan_hierarchise_sans_reseau(self):
        p, c = self.cfg(18)
        rc, out, _ = lancer(s1_sources.main, "B", ["--config", str(p), "plan", "hyponatrémie", "--format", "json"])
        res = json.loads(out); self.assertEqual(rc, 3)                                                   # index vide : « À CRAWLER »
        self.assertTrue(any(r["pec"] and r["niveaux_vises"] == "N1–N1" for r in res))                     # molécules : AIPS (N1) seul
