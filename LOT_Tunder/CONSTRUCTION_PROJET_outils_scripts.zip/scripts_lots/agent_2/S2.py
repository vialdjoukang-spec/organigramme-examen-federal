#!/usr/bin/env python3
"""Agent 2 — équipe 4, Appel A (plan et liste des 10 DX), LOT_113→LOT_079 (décroissant) — raccourci vers equipes/S2A.py avec la configuration de CET agent (lecture seule absolue sur les LOT)."""
import sys
from pathlib import Path
ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI.parent / "equipes"))
import s2_conformite
sys.exit(s2_conformite.main("A", ["--config", str(ICI / "config.json")] + sys.argv[1:]))
