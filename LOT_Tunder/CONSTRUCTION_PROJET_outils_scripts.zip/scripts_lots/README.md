# scripts_lots — v1.6 (2026-10-24, 16 h 42 / 16 h 49) : 18 agents, 6 équipes × 3 (A, B1, B2), LOT_218 → LOT_007

Code Python 3 (bibliothèque standard). **Aucune IA, aucune dépendance à installer.** Configurations : `python3 generer_configs.py` (source unique de l'organisation : `EQUIPES`, `TRANSITION`, `HISTORIQUE`). Tests : `./lancer_tests.sh` (57 tests).

| Agent | Équipe | Rôle | Série (décroissant) | Transition acceptée | S1 / S2 | Point d'entrée |
|---|---|---|---|---|---|---|
| 1 | 1 | A | LOT_218 → LOT_184 | LOT_213 P1 | `equipes/S1A.py`, `S2A.py` | `/workspace/equipes/agent_1/DEMARRER.md` |
| 3 | 1 | B1 | LOT_218 → LOT_184 | — | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_3/DEMARRER.md` |
| 5 | 1 | B2 | LOT_218 → LOT_184 | — | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_5/DEMARRER.md` |
| 9 | 2 | A | LOT_183 → LOT_149 | — | `equipes/S1A.py`, `S2A.py` | `/workspace/equipes/agent_9/DEMARRER.md` |
| 10 | 2 | B1 | LOT_183 → LOT_149 | — | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_10/DEMARRER.md` |
| 7 | 2 | B2 | LOT_183 → LOT_149 | — | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_7/DEMARRER.md` |
| 11 | 3 | A | LOT_148 → LOT_114 | — | `equipes/S1A.py`, `S2A.py` | `/workspace/equipes/agent_11/DEMARRER.md` |
| 12 | 3 | B1 | LOT_148 → LOT_114 | — | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_12/DEMARRER.md` |
| 13 | 3 | B2 | LOT_148 → LOT_114 | — | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_13/DEMARRER.md` |
| 2 | 4 | A | LOT_113 → LOT_079 | LOT_007 Appel A + P1 | `equipes/S1A.py`, `S2A.py` | `/workspace/equipes/agent_2/DEMARRER.md` |
| 4 | 4 | B1 | LOT_113 → LOT_079 | LOT_007 P2 | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_4/DEMARRER.md` |
| 6 | 4 | B2 | LOT_113 → LOT_079 | LOT_007 P3 | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_6/DEMARRER.md` |
| 14 | 5 | A | LOT_078 → LOT_043 | — | `equipes/S1A.py`, `S2A.py` | `/workspace/equipes/agent_14/DEMARRER.md` |
| 15 | 5 | B1 | LOT_078 → LOT_043 | — | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_15/DEMARRER.md` |
| 8 | 5 | B2 | LOT_078 → LOT_043 | LOT_007 P4 | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_8/DEMARRER.md` |
| 16 | 6 | A | LOT_042 → LOT_007 | — | `equipes/S1A.py`, `S2A.py` | `/workspace/equipes/agent_16/DEMARRER.md` |
| 17 | 6 | B1 | LOT_042 → LOT_007 | — | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_17/DEMARRER.md` |
| 18 | 6 | B2 | LOT_042 → LOT_007 | — | `equipes/S1B.py`, `S2B.py` | `/workspace/equipes/agent_18/DEMARRER.md` |

- **Rôles** : A = Appel A (1 fichier/LOT) ; B1 = Parties 1 puis 2 (DX.1–5) ; B2 = Parties 3 puis 4 (DX.6–10). LOT_219–248 hors périmètre ; LOT_001–006 audités par Tunder.
- **Transition** : chaque agent 1–8 garde, en plus de sa nouvelle série, le(s) fichier(s) en cours au basculement (table ci-dessus) ; tout le reste est refusé (code 2) par le contrôle de série. Les nouveaux propriétaires sautent ces fichiers s'ils sont déposés.
- **Budgets divisés par 18** : LanguageTool 0,55 req/min, 3 333 o/min, 2 700 o/requête ; NCBI 3/18 (10/18 avec clé) req/s ; HTTP 1/18 req/s par domaine.
- **Scripts d'équipe** (`equipes/`, lecture seule, alertes seulement) : `S1A.py`/`S1B.py` (sourçage hiérarchisé, `plan` / `check` bloquant), `S2A.py`/`S2B.py` (14 points + Charte V7+). Voir `equipes/README.md`. Raccourcis par agent : `agent_N/S1.py`, `agent_N/S2.py`.

---
_Historique v1.5 (remplacé) ci-dessous._

# scripts_lots — scripts déterministes des agents de rédaction (v1.5 — 8 agents, 2 équipes, LOT_218 → LOT_1)

Code Python 3 (bibliothèque standard), plus `curl` et `pdftotext`. **Aucune IA, aucune dépendance à installer.**

**Réorganisation du 2026-10-24 (v1.5)** : travail **descendant** de LOT_218 à LOT_1, sans chevauchement ; LOT_219–248 hors périmètre (déjà produits). `lots` est listé dans l'ordre de traitement (décroissant), suivi de l'historique éventuel.

| Agent | Équipe | Chapitre | Série (ordre de traitement) | Historique conservé (sans nouveau travail) | Scripts | État propre |
|---|---|---|---|---|---|---|
| 1 | 1 | Appel A + Partie 1 | LOT_218 → LOT_110 | LOT_227, LOT_228 (entiers), LOT_229 (A + P1) | `agent_1/` | `~/.scripts_lots/agent_1/` |
| 3 | 1 | Partie 2 | LOT_218 → LOT_110 | — | `agent_3/` | `~/.scripts_lots/agent_3/` |
| 5 | 1 | Partie 3 | LOT_218 → LOT_110 | — | `agent_5/` | `~/.scripts_lots/agent_5/` |
| 7 | 1 | Partie 4 | LOT_218 → LOT_110 | — | `agent_7/` | `~/.scripts_lots/agent_7/` |
| 2 | 2 | Appel A + Partie 1 | LOT_109 → LOT_1 | LOT_238 (entier) ; LOT_239 (entier : dépôt des Parties 3 et 4 déjà rédigées) | `agent_2/` | `~/.scripts_lots/agent_2/` |
| 4 | 2 | Partie 2 | LOT_109 → LOT_1 | — | `agent_4/` | `~/.scripts_lots/agent_4/` |
| 6 | 2 | Partie 3 | LOT_109 → LOT_1 | — | `agent_6/` | `~/.scripts_lots/agent_6/` |
| 8 | 2 | Partie 4 | LOT_109 → LOT_1 | — | `agent_8/` | `~/.scripts_lots/agent_8/` |

Numéros de LOT : `LOT_1`, `LOT_01` et `LOT_001` sont équivalents (`config.RE_NUM`, `lot_readonly.RE_LOT` : `LOT_0*(\d{1,3})(?!\d)`) ; les clés de `parties_autorisees` acceptent 1 à 3 chiffres.

Chaque `agent_N/` contient deux enveloppes minces (`script_source.py`, `script_synchrone.py`) et sa propre `config.json`, générées par `python3 generer_configs.py`.

```sh
python3 agent_1/script_source.py crawl --domaines www.bag.admin.ch,www.sginf.ch --max-pages 40
python3 agent_1/script_source.py search "hyponatrémie traitement" --pec
python3 agent_1/script_source.py extrait https://www.bag.admin.ch/fr/… --requete "dose"
python3 agent_1/script_source.py pubmed "hyponatremia guideline" --max 5
python3 agent_1/script_source.py check /workspace/agent1/LOT_218/LOT_218_Appel_B_V7_Partie_1_DX.1_a_DX.2.html   # code 1 = DÉPÔT BLOQUÉ
python3 agent_1/script_synchrone.py review /workspace/agent1/LOT_218/LOT_218_Appel_A_V7_Plan_et_Liste.html
python3 agent_1/script_synchrone.py watch /workspace/agent1/LOT_218
python3 common/compteur_tokens.py log --config agent_1/config.json --lot LOT_218 --cas 1 --message "LOT_218 Appel A + Partie 1 déposés."
python3 common/compteur_tokens.py rapport --config agent_1/config.json --config agent_2/config.json   # … jusqu'à agent_8
python3 agent_3/script_synchrone.py review /workspace/agent3/LOT_218/LOT_218_Appel_B_V7_Partie_2_DX.3_a_DX.5.html --appel-a /workspace/agent3/LOT_218/LOT_218_Appel_A_V7_Plan_et_Liste.html
./lancer_tests.sh                 # 42 tests, sans réseau, sur LOT fictifs
python3 banc/banc_essai.py        # banc d'essai sur LOT fictif dans /tmp
```

Configuration : `agent_N/config.json`. **Loi d'indépendance absolue (v1.4)** : aucun chemin inscriptible commun à deux agents — cache, retours, compteur et état des seaux (`shared_state_dir` = `~/.scripts_lots/agent_N/etat`) sont propres à chaque agent ; `~/.scripts_lots/partage` n'est plus utilisé (conservé tel quel, non supprimé). `pubmed.mcp_url` vide : aucun serveur MCP local partagé, E-utilities directement.

Champs facultatifs v1.4 (rétrocompatibles ; une configuration v1.3 sans eux fonctionne comme avant) : `equipe`, `chapitre`, `lots` (liste), `parties_autorisees` (liste de `A`, `P1`…`P4`, ou dictionnaire par LOT avec clé `*`), `dossier_travail` (chemin ou liste). `check` et `review` refusent (code 2, « REFUS (périmètre) ») un fichier hors LOT, hors Partie ou hors dossier de travail ; `review --appel-a` n'accepte que l'Appel A du même LOT ; `watch` ignore les fichiers d'autres chapitres. Avec `equipe`, `config.py` refuse tout chemin inscriptible hors d'un dossier `agent_N/` ou dans un dossier `partage`.

Budgets externes partagés en 8 (les huit agents ensemble restent sous les anciennes limites globales) :

| Ressource | Ancienne limite globale (2 agents) | Par agent (v1.4) | Total 8 agents |
|---|---|---|---|
| LanguageTool, requêtes | 10 req/min | 1 req/min (10 // 8, arrondi inférieur) ; 1 requête par passage | 8 req/min |
| LanguageTool, octets | 60 000 o/min ; 18 000 o/requête | 7 500 o/min ; 6 000 o/requête (rafale ≤ 7 200 o) | 60 000 o/min ; rafale ≤ 57 600 o |
| NCBI E-utilities sans clé | 3 req/s | 0,375 req/s (1 requête / 2,7 s ; capacité 1 jeton) | 3 req/s |
| NCBI E-utilities avec `NCBI_API_KEY` | 10 req/s | 1,25 req/s | 10 req/s |
| Par domaine (HTTP) | 1 req/s | 0,125 req/s (1 requête / 8 s par domaine ; capacité 1 jeton) | 1 req/s |

Conséquence : `crawl` est 8 fois plus lent par domaine (≈ 11 pages par domaine en 90 s) ; le recul après 429 est désormais propre à l'agent. Variables facultatives : `NCBI_API_KEY`, `NCBI_ADMIN_EMAIL`.
Spécification complète : `CAHIER_DES_CHARGES_SCRIPTS_SKILLS/CAHIER_DES_CHARGES_SCRIPTS_SKILLS_GROK.md`.
