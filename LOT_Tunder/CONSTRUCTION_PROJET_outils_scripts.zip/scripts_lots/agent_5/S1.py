#!/usr/bin/env python3
"""Agent 5 — équipe 1, Appel B Parties 3–4 (DX.6–DX.10), LOT_218→LOT_184 (décroissant) — raccourci vers equipes/S1B.py avec la configuration de CET agent (lecture seule absolue sur les LOT)."""
import sys
from pathlib import Path
ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI.parent / "equipes"))
import s1_sources
sys.exit(s1_sources.main("B", ["--config", str(ICI / "config.json")] + sys.argv[1:]))
