"""Noyau commun aux scripts d'équipe S1A / S1B (sources) et S2A / S2B (conformité) — v1.6, 2026-10-24.

GARANTIE ABSOLUE : ces scripts n'écrivent ni ne modifient JAMAIS un fichier de LOT.
- toute lecture de LOT passe par common/lot_readonly.lire_octets (os.open en O_RDONLY | O_NOFOLLOW) ;
- l'empreinte sha256 du fichier ET du dossier du LOT est prise avant et après chaque passage :
  toute différence lève ModificationDetectee (code de sortie 3) et aucun rapport n'est publié ;
- les rapports vont uniquement dans ~/.scripts_lots/agent_N/retours/equipes/ via lot_readonly.ecrire_sortie,
  qui refuse tout chemin situé dans un dossier de LOT ;
- les scripts ALERTENT seulement : ils ne corrigent rien, ne déposent rien, n'envoient aucun message.
Bibliothèque standard uniquement ; aucun appel IA."""
import hashlib, json, os, re, sys
from pathlib import Path

ICI = Path(__file__).resolve().parent
RACINE = ICI.parent
COMMON = RACINE / "common"
sys.path.insert(0, str(COMMON))
import config as cfgmod, lot_readonly                      # noqa: E402
from lot_readonly import ViolationLectureSeule              # noqa: E402

VERSION = "v1.6 (2026-10-24)"
ROLE_TYPE = {"A": "A", "B1": "B", "B2": "B"}
NOMS_TYPE = {"A": "Appel A (plan et liste des 10 DX)", "B": "Appel B (monographies DX, Parties 1–4)"}

class ModificationDetectee(Exception):
    """Le fichier ou le dossier du LOT a changé pendant le passage (le script n'écrit jamais : origine externe)."""

class Refus(Exception):
    """Fichier hors périmètre ou hors type du script : aucun contrôle effectué (code 2)."""

def charger_config(agent=None, config=None):
    if config:
        chemin = Path(config)
    elif agent:
        chemin = RACINE / f"agent_{int(agent)}" / "config.json"
    else:
        env = os.environ.get("AGENT_LOT")
        if not env:
            raise Refus("préciser --agent N (ou --config chemin, ou la variable AGENT_LOT)")
        chemin = RACINE / f"agent_{int(env)}" / "config.json"
    return cfgmod.charger(chemin)

def sha256(chemin):
    return hashlib.sha256(lot_readonly.lire_octets(chemin)).hexdigest()

def type_fichier(chemin):
    p = cfgmod.partie_de(chemin)
    return None if p is None else ("A" if p == "A" else "B")

def garde(cfg, fichier, type_attendu, nom_script):
    """Refus AVANT toute lecture : type de fichier, périmètre de l'agent, isolation des sorties."""
    fichier = Path(fichier)
    if not fichier.is_file():
        raise Refus(f"{fichier} : fichier introuvable")
    t = type_fichier(fichier)
    if t != type_attendu:
        autre = nom_script.replace("A", "B") if type_attendu == "A" else nom_script.replace("B", "A")
        raise Refus(f"{fichier.name} : {nom_script} ne traite que les fichiers « {NOMS_TYPE[type_attendu]} » ; utilisez {autre}")
    n = lot_readonly.numero_lot(fichier)
    ok, raison = cfgmod.fichier_autorise(cfg, str(fichier), n)
    if not ok:
        raise Refus(f"périmètre — {raison}. Ce fichier n'est pas le vôtre : aucun contrôle effectué")
    dossier_lot = str(fichier.resolve().parent)
    for cle in ("output_dir", "cache_dir", "shared_state_dir"):
        lot_readonly.verifier_isolation(cfg[cle], [dossier_lot])
    if cfg.get("enforce_os_readonly"):
        lot_readonly.verifier_droits_os(dossier_lot)
    return n, dossier_lot

class LectureSeule:
    """with LectureSeule(fichier) as html: … — empreintes sha256 avant/après ; lève ModificationDetectee si le LOT change."""
    def __init__(self, fichier):
        self.fichier = Path(fichier); self.dossier = self.fichier.resolve().parent
    def __enter__(self):
        self.avant_f = sha256(self.fichier); self.avant_d = lot_readonly.empreintes(self.dossier)
        self.octets = lot_readonly.lire_octets(self.fichier)
        return self.octets.decode("utf-8", "replace")
    def __exit__(self, et, ev, tb):
        apres_f = sha256(self.fichier); apres_d = lot_readonly.empreintes(self.dossier)
        self.integrite = {"sha256_avant": self.avant_f, "sha256_apres": apres_f, "dossier_inchange": self.avant_d == apres_d}
        if et is None and (apres_f != self.avant_f or apres_d != self.avant_d):
            diff = sorted(k for k in set(self.avant_d) | set(apres_d) if self.avant_d.get(k) != apres_d.get(k))
            raise ModificationDetectee(f"LOT modifié pendant le passage ({diff}) : passage annulé, aucun rapport publié")
        return False

def publier(cfg, n, nom, contenu, dossier_lot):
    """Écrit un rapport dans ~/.scripts_lots/agent_N/retours/equipes/LOT_n/ (jamais dans un LOT)."""
    base = Path(cfg["output_dir"]) / "equipes"
    chemin = base / f"LOT_{n:03d}" / nom
    lot_readonly.ecrire_sortie(chemin, contenu, cfg["output_dir"], [dossier_lot])
    return chemin

def role_agent(cfg):
    r = cfg.get("role")
    if r: return r
    pa = cfg.get("parties_autorisees")
    p = pa if isinstance(pa, list) else (pa or {}).get("*", [])
    return "A" if p == ["A"] else ("B1" if p == ["P1", "P2"] else ("B2" if p == ["P3", "P4"] else "?"))

def tableau_md(entetes, lignes):
    l = ["| " + " | ".join(entetes) + " |", "|" + "|".join("---" for _ in entetes) + "|"]
    for r in lignes:
        l.append("| " + " | ".join(str(c).replace("|", "/").replace("\n", " ") for c in r) + " |")
    return "\n".join(l)

def executer(fonction):
    """Codes de sortie : 0 conforme · 1 au moins un bloquant (dépôt bloqué) · 2 refus · 3 LOT modifié pendant le passage."""
    try:
        return fonction()
    except Refus as e:
        print(f"REFUS : {e}", file=sys.stderr); return 2
    except ViolationLectureSeule as e:
        print(f"REFUS (lecture seule) : {e}", file=sys.stderr); return 2
    except cfgmod.ConfigErreur as e:
        print(f"REFUS (configuration) : {e}", file=sys.stderr); return 2
    except ModificationDetectee as e:
        print(f"ALERTE : {e}", file=sys.stderr); return 3
