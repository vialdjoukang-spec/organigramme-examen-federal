#!/usr/bin/env python3
"""S1B — script SOURCE pour l'Appel B (Parties 1–4 : physiopathologie, examens, traitements, molécules).
Usage : python3 /workspace/scripts_lots/equipes/S1B.py --agent N {plan|check|domaines|crawl|search|extrait|pubmed} …
Lecture seule absolue sur les LOT (sha256 avant/après) ; il alerte, il ne modifie jamais. Voir s1_sources.py."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import s1_sources
if __name__ == "__main__":
    sys.exit(s1_sources.main("B", sys.argv[1:]))
