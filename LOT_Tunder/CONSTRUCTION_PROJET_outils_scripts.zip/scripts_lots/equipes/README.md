# scripts_lots/equipes — S1A, S1B, S2A, S2B (v1.6, 2026-10-24 16 h 49)

Scripts déterministes (Python 3, bibliothèque standard), **strictement en lecture seule** sur le fichier contrôlé : ouverture `O_RDONLY|O_NOFOLLOW`, empreinte sha256 du fichier et du dossier du LOT avant/après (code 3 et aucun rapport si quelque chose a changé), rapports écrits uniquement dans `~/.scripts_lots/agent_N/retours/equipes/LOT_NNN/` (et `…/sourcage/` pour `plan`). Ils **alertent**, ils ne corrigent jamais.

| Script | Profil | Commandes |
|---|---|---|
| `S1A.py` | Appel A | `--agent N plan "thème" [--dx "a;b"] [--limite K] [--format md|json]` · `--agent N check FICHIER` · `domaines|crawl|search|extrait|pubmed` (relais vers script_source) |
| `S1B.py` | Appel B | idem ; requêtes de doses ciblées sur l'AIPS (rang N1) |
| `S2A.py` | Appel A | `--agent N review FICHIER [--format] [--contraste-navigateur]` |
| `S2B.py` | Appel B | `--agent N review FICHIER --appel-a APPEL_A.html [--contraste-navigateur]` |

`--agent N` peut être remplacé par `--config CHEMIN` ou la variable `AGENT_LOT`. Codes : **0** conforme · **1** bloquant (S1 : affirmation non sourcée / dose sans AIPS / probabilité sans [Sn] ; S2 : au moins un ÉCHEC) · **2** refus (mauvais type « utilisez S1B/S1A », hors série, hors Partie, hors dossier — rien n'est lu ni écrit) · **3** fichier modifié pendant la lecture.

- **S1 (sourçage)** : priorité N1 Suisse officielle → N2 sociétés suisses → N3 Europe → N4 international → N5 PubMed (liste blanche de 92 domaines), bonus « prise en charge » ; `plan` signale « À CRAWLER » (code 3) quand l'index local ne couvre pas un besoin ; `check` = `verifier_sources` + contrôles de profil (A : `.proba` → [Sn] P1, unités de prévalence, source N1–N2 au point 2 ; B : dose → AIPS P1, ® sourcé).
- **S2 (conformité)** : tableau de 14 lignes (points 1 à 14, statut, section, détail) + Charte : C1 rouge #C8102E sans halo, sans #FF2400 · C2 aucun des 7 verts · C3 Atkinson · C4 contraste WCAG ≥ 4,5 (statique) · C5 fenêtres d'examen Principe/Interprétation · C6 ≤ 4 phrases · C7 chaîne logique · C8 technique V7 · C9 sources (renvoi S1) · C10 phrases verbales · C11 sigles ; B : C12 probabilité dans le titre de chaque DX, C13 cohérence avec l'Appel A ; A : lignes Bloc 2 (B2.1–B2.5).
- Tests : `common/tests/test_equipes.py` (12 tests, 18 agents), lancés par `../lancer_tests.sh`.
