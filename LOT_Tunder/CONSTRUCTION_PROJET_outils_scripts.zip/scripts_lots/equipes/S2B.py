#!/usr/bin/env python3
"""S2B — script de CONFORMITÉ pour l'Appel B : 14 points sur chaque monographie DX + Charte V7+.
Usage : python3 /workspace/scripts_lots/equipes/S2B.py --agent N review FICHIER.html [--appel-a APPEL_A.html] [--format json] [--contraste-navigateur]
Lecture seule absolue sur les LOT (sha256 avant/après) ; il alerte, il ne modifie jamais. Voir s2_conformite.py."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import s2_conformite
if __name__ == "__main__":
    sys.exit(s2_conformite.main("B", sys.argv[1:]))
