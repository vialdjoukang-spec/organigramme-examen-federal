#!/usr/bin/env python3
"""S1A — script SOURCE pour l'Appel A (plan, prévalences comparables, probabilités des 10 DX).
Usage : python3 /workspace/scripts_lots/equipes/S1A.py --agent N {plan|check|domaines|crawl|search|extrait|pubmed} …
Lecture seule absolue sur les LOT (sha256 avant/après) ; il alerte, il ne modifie jamais. Voir s1_sources.py."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import s1_sources
if __name__ == "__main__":
    sys.exit(s1_sources.main("A", sys.argv[1:]))
