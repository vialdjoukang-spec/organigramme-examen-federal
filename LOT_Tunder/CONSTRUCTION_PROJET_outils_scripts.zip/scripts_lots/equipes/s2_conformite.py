"""S2 — script de CONFORMITÉ d'équipe (moteur commun de S2A et S2B), v1.6.

Pour chaque fichier : un tableau de 14 lignes (les 14 points du plan monographique, V7-Tunder §6 / v7.md §6),
statut CONFORME / ALERTE / ÉCHEC et numéro du point (et section §) cités, puis le tableau de la CHARTE QUALITÉ V7+ :
  C1 probabilités rouge #C8102E gras, sans halo (#FF2400 obsolète) · C2 bleu ciel (7 verts remplacés) ·
  C3 Atkinson Hyperlegible · C4 contraste WCAG ≥ 4,5 (calcul statique du <style> et des styles en ligne) ·
  C5 fenêtres d'examen cliquables Principe / Interprétation · C6 ≤ 4 phrases par point (§7.2) ·
  C7 chaîne logique anatomie → physiologie → physiopathologie → clinique → examens → traitement ·
  C8 technique V7 (§2, §10, §11) · C9 sourçage (§4, détail par S1) · C10 phrases verbales (§7.1) · C11 abréviations (§7.4).
S2A (Appel A) : les 14 points s'appliquent à la monographie du SSP (Bloc 1) ; le Bloc 2 (§9) est contrôlé à part
(10 DX, probabilités en exposant, tableau comparatif, algorithme discriminant, critère d'ordre annoncé).
S2B (Appel B) : les 14 points s'appliquent à CHAQUE monographie DX du fichier ; cohérence avec l'Appel A si --appel-a.
Lecture seule absolue (sha256 avant/après) ; S2 alerte, il ne corrige jamais. Code 1 si au moins un ÉCHEC.

Commande :  review FICHIER.html [--appel-a FICHIER_APPEL_A] [--format md|json] [--contraste-navigateur]
"""
import argparse, json, re, subprocess, sys, time
from pathlib import Path
import noyau
from noyau import Refus
import config as cfgmod, lot_readonly, v7_rules, sync_reviewer, source_engine     # noqa: E402
from sync_reviewer import Noeud, texte, phrases                                  # noqa: E402
from controle_v7 import controler                                                # noqa: E402

TITRES = ["Définition et sémantique", "Épidémiologie (Suisse, puis Europe)", "Physiopathologie", "Démarche diagnostique",
          "Anamnèse ciblée et drapeaux rouges", "Examen physique ciblé", "Approche syndromique", "Diagnostic positif et critères",
          "Examens complémentaires", "Arbre décisionnel", "Prise en charge (recommandations suisses)", "Prévention",
          "Points clés", "Pièges et questions de l'examen fédéral"]
VERTS = {"#edf7f4": "#eaf4fb", "#f2faf7": "#f1f8fd", "#dff1e9": "#dceef9", "#d8e8e2": "#d6e6f1",
         "#e3ece8": "#e2ebf2", "#aacfc3": "#a8cbe2", "#b2c9c0": "#b2c7d6"}
ROUGE = "#c8102e"
OUTIL_CONTRASTE = "/workspace/audit_1_10/outils/contraste.py"

# ---------- points d'une monographie (même découpage que common/sync_reviewer) ----------
def classes(n):
    return set((n.attrs.get("class") or "").split())

def points_de(mono):
    pts = {}; cour = {"n": None}
    def p():
        return pts[cour["n"]]
    def parc(n, fen, tab):
        for c in n.enfants:
            if isinstance(c, str):
                if cour["n"] is not None:
                    p()["complet"] += c
                    if not fen and not tab: p()["principal"] += c
                continue
            if c.tag == "summary" and c.parent is mono:
                continue
            if c.tag == "strong" and not fen:
                mm = re.match(r"\s*(\d{1,2})\s*[.)]", texte(c))
                if mm and 1 <= int(mm.group(1)) <= 14:
                    cour["n"] = int(mm.group(1))
                    pts.setdefault(cour["n"], {"principal": "", "complet": "", "fenetres": 0, "examens": [], "tableaux": 0, "listes": 0, "titre": texte(c).strip()})
                    continue
            if cour["n"] is not None:
                if c.tag == "details":
                    p()["fenetres"] += 1
                    if "ex" in classes(c):
                        t = texte(c); p()["examens"].append({"principe": "Principe" in t, "interpretation": "Interprétation" in t,
                                                             "onglets": _a_classe(c, "onglets"), "op": _a_classe(c, "op"), "oi": _a_classe(c, "oi")})
                if c.tag == "table" and not fen: p()["tableaux"] += 1
                if c.tag in ("ol", "ul") and not fen: p()["listes"] += 1
                if c.tag in sync_reviewer.BLOCS_ESPACE:
                    p()["complet"] += " "
                    if not fen and not tab: p()["principal"] += " "
            parc(c, fen or c.tag == "details", tab or c.tag == "table")
    parc(mono, False, False)
    return pts

def _a_classe(n, k):
    if k in classes(n): return True
    return any(isinstance(c, Noeud) and _a_classe(c, k) for c in n.enfants)

def _nom(mono, i):
    s = next((c for c in mono.enfants if isinstance(c, Noeud) and c.tag == "summary"), None)
    nom = re.sub(r"\s+", " ", texte(s)).strip() if s else f"monographie {i}"
    m = re.search(r"DX\.\s?\d+", nom)
    return (m.group(0).replace(" ", "") if m else (nom.split("—")[0].strip()[:30] or f"M{i}")), nom, s

# ---------- contrôles par point ----------
def controles_point(n, pt):
    """Retourne une liste (gravité, section, message) pour le point n d'une monographie."""
    c = pt["complet"].lower(); r = []
    def a(*mots): return any(m in c for m in mots)
    sref = bool(re.search(r"\[s\d+", c))
    if n == 1 and not sref: r.append(("P2", "§6.1 point 1", "définition sans société savante citée [Sn]"))
    if n == 2:
        if not re.search(r"\d+(?:[,.]\d+)?\s?(?:%|/\s?100\s?000|pour\s+\d)", c): r.append(("P2", "§6.1 point 2", "épidémiologie non chiffrée (prévalence, incidence)"))
        if not a("suisse", "ch)", "obsan", "ofs"): r.append(("P2", "§6 point 2", "épidémiologie suisse non repérée (Suisse, puis Europe)"))
    if n == 3:
        if not a("→", "entraîne", "provoque", "aboutit", "conduit", "car ", "donc"): r.append(("P2", "§6.1 point 3", "cascade causale (cause → signe) non repérée"))
        if not a("anatom", "physiolog", "normal"): r.append(("P3", "Charte V7+ §1", "maillons anatomie / physiologie normale non repérés avant la physiopathologie"))
    if n == 4:
        if not a("grave", "exclure", "urgence", "ne pas manquer"): r.append(("P2", "§6.1 point 4", "hypothèses graves à exclure d'abord non nommées"))
        if not a("piège"): r.append(("P3", "§6.1 point 4", "piège associé aux DX discriminants non repéré"))
    if n == 5 and not a("drapeau"): r.append(("P2", "§6.1 point 5", "drapeaux rouges non repérés"))
    if n == 6 and not a("normal"): r.append(("P2", "§7.5", "le normal avant le pathologique : « normal » non repéré"))
    if n == 7 and not (a("fonctionnel") and a("physique")): r.append(("P2", "§6.1 point 7", "syndromes non éclatés en signes fonctionnels / physiques"))
    if n == 8 and not (a("critère") and re.search(r"\b(?:19|20)\d{2}\b", c)): r.append(("P2", "§6.1 point 8", "critères diagnostiques sans société savante + année"))
    if n == 9:
        if not pt["examens"]: r.append(("P1", "Charte V7+ §6", "aucune fenêtre d'examen cliquable (details.ex, onglets Principe / Interprétation)"))
        inc = [e for e in pt["examens"] if not (e["principe"] and e["interpretation"])]
        if inc: r.append(("P1", "Charte V7+ §6", f"{len(inc)} fenêtre(s) d'examen sans les volets Principe ET Interprétation"))
        sans_onglets = [e for e in pt["examens"] if e["principe"] and e["interpretation"] and not (e["onglets"] and e["op"] and e["oi"])]
        if sans_onglets: r.append(("P2", "Charte V7+ §6", f"{len(sans_onglets)} fenêtre(s) d'examen à volets non présentés en onglets (gabarit fenetres_examens.css : .onglets/.op/.oi)"))
        if not a("gold standard", "étalon"): r.append(("P2", "§6.1 point 9", "existence ou absence d'un gold standard non dite"))
        if pt["tableaux"] == 0 and not any(e["oi"] for e in pt["examens"]): r.append(("P2", "§6.1 point 9", "tableau d'interprétation (normal | seuil | signification | conduite) non repéré"))
    if n == 10 and not (a("→", "si ", "alors") or pt["tableaux"] or pt["listes"]): r.append(("P2", "§6.1 point 10", "arbre décisionnel (embranchements) non repéré"))
    if n == 11:
        if "®" not in pt["complet"]: r.append(("P2", "§6.1 point 11", "spécialité suisse ® non repérée"))
        if not a("aips", "information professionnelle", "swissmedicinfo", "compendium"): r.append(("P2", "§4.1", "doses : référence AIPS non repérée"))
    if n == 12 and not all(x in c for x in ("primaire", "secondaire", "tertiaire")): r.append(("P2", "§6 point 12", "prévention primaire / secondaire / tertiaire incomplète"))
    if n == 13:
        k = len(phrases(pt["principal"]))
        if not 3 <= k <= 6: r.append(("P2", "§6 point 13", f"{k} phrase(s) : 3 à 6 phrases courtes et verbales attendues"))
    if n == 14 and not a("piège", "?", "question"): r.append(("P2", "§6 point 14", "pièges / questions de l'examen fédéral non repérés"))
    return r

# ---------- charte : couleurs, police, contraste ----------
def _hex(c):
    c = c.strip().lower()
    if re.fullmatch(r"#[0-9a-f]{3}", c): c = "#" + "".join(x * 2 for x in c[1:])
    if re.fullmatch(r"#[0-9a-f]{6}([0-9a-f]{2})?", c): return c[:7]
    nommees = {"white": "#ffffff", "black": "#000000", "#fff": "#ffffff", "#000": "#000000"}
    return nommees.get(c)

def _lum(h):
    v = [int(h[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    v = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in v]
    return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]

def contraste(a, b):
    la, lb = _lum(a), _lum(b); return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)

def _decl(bloc, prop):
    m = re.findall(rf"(?:^|[;{{\s]){prop}\s*:\s*([^;}}]+)", bloc, re.I)
    if not m: return None
    for v in m[::-1]:
        h = re.search(r"#[0-9a-fA-F]{3,8}\b|\bwhite\b|\bblack\b", v)
        if h: return _hex(h.group(0))
    return None

def contrastes(html):
    """Paires texte/fond déclarées ensemble (règle CSS ou style en ligne) ; fond implicite = fond du body (blanc par défaut)."""
    styles = " ".join(re.findall(r"<style[^>]*>(.*?)</style>", html, re.S | re.I))
    fond_body = "#ffffff"
    m = re.search(r"(?:^|})\s*(?:html\s*,\s*)?body\s*{([^}]*)}", styles)
    if m: fond_body = _decl(m.group(1), "background(?:-color)?") or fond_body
    paires = []
    for sel, corps in re.findall(r"([^{}]+){([^{}]*)}", styles):
        c = _decl(corps, "color"); f = _decl(corps, "background(?:-color)?")
        if c: paires.append((sel.strip()[:60], c, f or fond_body, f is None))
    for st in re.findall(r"style\s*=\s*[\"']([^\"']+)[\"']", html):
        c = _decl(st, "color"); f = _decl(st, "background(?:-color)?")
        if c: paires.append(("style en ligne", c, f or fond_body, f is None))
    mauvais = {}
    for sel, c, f, implicite in paires:
        r = contraste(c, f)
        if r < 4.5:
            k = (c, f); mauvais.setdefault(k, {"selecteur": sel, "texte": c, "fond": f, "ratio": round(r, 2), "fond_implicite": implicite, "occurrences": 0})
            mauvais[k]["occurrences"] += 1
    return len(paires), sorted(mauvais.values(), key=lambda x: x["ratio"])

def charte(html, monos_pts, items_rel, err_tech, sources_p1, profil):
    st = " ".join(re.findall(r"<style[^>]*>(.*?)</style>", html, re.S | re.I)); bas = html.lower(); lignes = []
    def ligne(code, libelle, ref, pb, grav="P1"):
        lignes.append({"code": code, "critere": libelle, "reference": ref,
                       "statut": "CONFORME" if not pb else ("ÉCHEC" if grav == "P1" else "ALERTE"), "detail": "; ".join(pb)[:400]})
    # C1
    pb = []; nb_proba = len(re.findall(r"class=[\"']?proba", html))
    regles = re.findall(r"\.proba\s*{([^}]*)}", st)
    if "#ff2400" in bas: pb.append("#FF2400 présent (obsolète)")
    if any("text-shadow" in r.lower() for r in regles): pb.append("halo (text-shadow) sur .proba")
    if nb_proba and not any(ROUGE in r.lower().replace(" ", "") and re.search(r"font-weight\s*:\s*(700|bold)", r, re.I) for r in regles):
        pb.append(".proba{color:#C8102E;font-weight:700} absent du <style>")
    if profil == "A" and nb_proba < 10: pb.append(f"{nb_proba} probabilité(s) en exposant pour 10 DX")
    ligne("C1", "Probabilités en exposant rouge #C8102E gras, sans halo", "Charte V7+ §5 (amendement couleurs)", pb)
    # C2
    pb = [f"{v} → {VERTS[v]}" for v in VERTS if v in bas]
    ligne("C2", "Palette bleu ciel (aucun des 7 verts)", "Charte V7+ couleurs", pb)
    # C3
    ligne("C3", "Police Atkinson Hyperlegible", "Charte V7+ §6", [] if re.search(r"font-family\s*:[^;}]*Atkinson Hyperlegible", html, re.I) else ["font-family « Atkinson Hyperlegible » absente"])
    # C4
    nbp, mauvais = contrastes(html)
    ligne("C4", f"Contraste WCAG ≥ 4,5 ({nbp} paires déclarées)", "WCAG 2.1 AA 1.4.3",
          [f"{m['texte']} sur {m['fond']}{' (fond implicite)' if m['fond_implicite'] else ''} = {m['ratio']} ×{m['occurrences']} [{m['selecteur']}]" for m in mauvais[:6]])
    # C5
    ex = [e for pts in monos_pts for p in pts.values() for e in p["examens"]]
    inc = [e for e in ex if not (e["principe"] and e["interpretation"])]
    so = [e for e in ex if e["principe"] and e["interpretation"] and not (e["onglets"] and e["op"] and e["oi"])]
    pb5 = (["aucune fenêtre d'examen (details.ex)"] if not ex else []) + ([f"{len(inc)} fenêtre(s) sans Principe ET Interprétation"] if inc else [])
    ligne("C5", f"Fenêtres d'examen cliquables Principe / Interprétation ({len(ex)})", "Charte V7+ §6",
          pb5 or ([f"{len(so)} fenêtre(s) à volets mais sans onglets .onglets/.op/.oi"] if so else []), "P1" if pb5 else "P2")
    # C6, C10
    trop = [f"{x['lieu']}" for x in items_rel if x["section"] == "§7.2" and x["gravite"] == "P1"]
    ligne("C6", "≤ 4 phrases courtes par point du texte principal", "§7.2", [f"{len(trop)} point(s) : " + ", ".join(trop[:6])] if trop else [])
    nominales = [x["lieu"] for x in items_rel if x["section"] == "§7.1"]
    ligne("C10", "Phrases verbales (zéro phrase nominale)", "§7.1", [f"{len(nominales)} phrase(s) nominale(s) probable(s) : " + ", ".join(nominales[:5])] if nominales else [], "P2")
    # C7
    pb = []
    for x in items_rel:
        if x["section"] == "§6" and "ordre" in x["message"]: pb.append(f"{x['lieu']} : {x['message']}")
    for i, pts in enumerate(monos_pts, 1):
        if 3 in pts and not re.search(r"anatom|physiolog|normal", pts[3]["complet"], re.I): pb.append(f"M{i} point 3 : maillon anatomie/physiologie absent")
        if 11 in pts and 3 in pts and not re.search(r"mécanisme|corrige|cible", pts[11]["complet"] + pts[3]["complet"], re.I): pb.append(f"M{i} : lien physiopathologie → traitement non explicité")
    ligne("C7", "Chaîne logique anatomie → physiologie → physiopathologie → clinique → examens → traitement", "Charte V7+ §1 ; §6", pb, "P2")
    # C8, C9, C11
    ligne("C8", "Technique V7 (HTML autonome, taille, FIN_FICHIER, tableaux enveloppés, aucun title=)", "§2, §10, §11", [f"{s} {e}" for s, e in err_tech])
    ligne("C9", "Sourçage : aucune affirmation orpheline (détail : S1)", "§4.1, §4.10", [f"{sources_p1} affirmation(s)/source(s) bloquante(s) — lancer S1{profil} check"] if sources_p1 else [])
    abr = [x for x in items_rel if x["section"] == "§7.4"]
    ligne("C11", "Abréviations développées à la première apparition", "§7.4", [f"{len(abr)} abréviation(s) : " + ", ".join(re.findall(r"« ([^»]+) »", " ".join(x["message"] for x in abr))[:8])] if abr else [], "P2")
    return sorted(lignes, key=lambda x: int(x["code"][1:]))

# ---------- Bloc 2 de l'Appel A ----------
def bloc2(html):
    t = re.sub(r"<[^>]+>", " ", html); lignes = []
    def ligne(code, lib, ref, pb, grav="P1"):
        lignes.append({"code": code, "critere": lib, "reference": ref, "statut": "CONFORME" if not pb else ("ÉCHEC" if grav == "P1" else "ALERTE"), "detail": "; ".join(pb)})
    dx = sorted({int(x) for x in re.findall(r"DX\.\s?(\d{1,2})\b", t) if 1 <= int(x) <= 10})
    ligne("B2.1", "Liste DX.1–DX.10 complète", "§5.1, §9.1", [] if dx == list(range(1, 11)) else [f"DX repérés : {dx}"])
    ligne("B2.2", "Critère d'ordre annoncé (fréquence suisse sourcée pondérée par la gravité)", "§9.1",
          [] if re.search(r"ordre|ordonn", t, re.I) and re.search(r"fréquence|gravité", t, re.I) else ["critère d'ordre non annoncé"], "P2")
    tabs = re.findall(r"<table\b.*?</table>", html, re.S | re.I)
    comp = [x for x in tabs if len(re.findall(r"DX\.\s?\d", x)) >= 8 or (re.search(r"signe", x, re.I) and re.search(r"examen", x, re.I) and re.search(r"conduite|mécanisme", x, re.I))]
    ligne("B2.3", "Tableau comparatif des 10 DX (signe clé, examen clé, mécanisme, conduite)", "§9.4", [] if comp else ["tableau comparatif non repéré"])
    ligne("B2.4", "Algorithme discriminant", "§9.4", [] if re.search(r"algorithme", t, re.I) else ["algorithme discriminant non repéré"])
    ligne("B2.5", "« Ne pas manquer » grave non relégué sans justification", "§9.2", [] if re.search(r"ne pas manquer|grave", t, re.I) else ["DX graves « ne pas manquer » non signalés"], "P2")
    return lignes

# ---------- passage ----------
def review(cfg, profil, fichier, appel_a, fmt, nav, nom_script):
    n, dossier = noyau.garde(cfg, fichier, profil, nom_script)
    if appel_a:
        if noyau.type_fichier(appel_a) != "A" or lot_readonly.numero_lot(appel_a) != n:
            raise Refus(f"--appel-a {Path(appel_a).name} : seul l'Appel A du LOT_{n} est lisible")
    t0 = time.perf_counter(); prompt = v7_rules.charger(cfg["prompt_path"])
    with noyau.LectureSeule(fichier) as html:
        raw = html.encode("utf-8")
        m = re.search(r"<!--\s*FIN_FICHIER\s+(\S+)\s*-->", html); etiquette = m.group(1) if m else Path(fichier).stem
        err_tech = controler(lot_readonly.lire_octets(fichier), etiquette)
        pb_src, st_src = source_engine.verifier_sources(html)
        dom = sync_reviewer._Dom(); dom.feed(html); monos = sync_reviewer.monographies(dom.racine)
        if profil == "A": monos = monos[:1]                     # Bloc 1 = monographie du SSP
        items_rel, monos_pts, noms = [], [], []
        for i, mo in enumerate(monos, 1):
            r = sync_reviewer.analyser_monographie(mo, i, prompt); items_rel += r["items"]
            monos_pts.append(points_de(mo)); noms.append(_nom(mo, i))
        corps = re.sub(r"<(style|title|head)\b.*?</\1>", " ", re.split(r"<h[1-4][^>]*>\s*Sources", html)[0], flags=re.S | re.I)
        items_rel += sync_reviewer.abreviations(re.sub(r"<[^>]+>", " ", corps))
        coh = sync_reviewer.coherence_dx(html, lot_readonly.lire_octets(appel_a).decode("utf-8", "replace")) if appel_a else []
        lignes14 = []
        for k in range(1, 15):
            pbs = []
            for (lieu, nom, _), pts in zip(noms, monos_pts):
                if k not in pts:
                    pbs.append(("P1", "§6", f"{lieu} : point absent")); continue
                pbs += [(g, s, f"{lieu} : {m}") for g, s, m in controles_point(k, pts[k])]
                pbs += [(x["gravite"], x["section"], f"{lieu} : {x['message']}") for x in items_rel if x["lieu"].endswith(f"point {k}") and x["lieu"].startswith(lieu)]
            if not monos: pbs.append(("P1", "§10", "aucune monographie <details open>"))
            g = {x[0] for x in pbs}
            statut = "ÉCHEC" if "P1" in g else ("ALERTE" if "P2" in g else "CONFORME")
            refs = sorted({x[1] for x in pbs if x[0] != "P3"})
            lignes14.append({"point": k, "intitule": TITRES[k - 1], "statut": statut, "references": ", ".join(refs) or f"§6 point {k}",
                             "detail": "; ".join(x[2] for x in pbs if x[0] != "P3")[:500], "notes": "; ".join(x[2] for x in pbs if x[0] == "P3")[:200]})
        lignes_charte = charte(html, monos_pts, items_rel, err_tech, st_src["bloquants"], profil)
        if profil == "B":
            sans = [lieu for lieu, nom, s in noms if s is None or "proba" not in "".join(f"{k}{v}" for c in s.enfants if isinstance(c, Noeud) for k, v in c.attrs.items())]
            lignes_charte.append({"code": "C12", "critere": "Probabilité du DX en exposant dans le titre de chaque monographie", "reference": "Charte V7+ §5",
                                  "statut": "ALERTE" if sans else "CONFORME", "detail": ("sans exposant : " + ", ".join(sans)) if sans else ""})
            if appel_a:
                lignes_charte.append({"code": "C13", "critere": "Cohérence des noms de DX avec l'Appel A", "reference": "§9.5",
                                      "statut": "ÉCHEC" if coh else "CONFORME", "detail": "; ".join(f"{x['lieu']} : {x['message']}" for x in coh)[:400]})
        lignes_b2 = bloc2(html) if profil == "A" else []
    nav_res = None
    if nav and Path(OUTIL_CONTRASTE).is_file():
        try:
            nav_res = subprocess.run([sys.executable, OUTIL_CONTRASTE, str(Path(fichier).resolve())], capture_output=True, text=True, timeout=180).stdout[-3000:]
        except Exception as e:
            nav_res = f"contraste navigateur indisponible : {e}"
    echecs = sum(1 for x in lignes14 + lignes_charte + lignes_b2 if x["statut"] == "ÉCHEC")
    res = {"script": nom_script, "version": noyau.VERSION, "fichier": str(fichier), "lot": f"LOT_{n:03d}", "agent": cfg["agent"],
           "horodatage": time.strftime("%Y-%m-%d %H:%M (%Z)"), "duree_ms": round(1000 * (time.perf_counter() - t0), 1),
           "monographies": [x[1][:80] for x in noms], "points_14": lignes14, "charte": lignes_charte, "bloc2": lignes_b2,
           "contraste_navigateur": nav_res, "echecs": echecs, "depot": "BLOQUÉ" if echecs else "autorisé (conformité)",
           "lecture_seule": "sha256 identique avant/après"}
    texte_md = rendu(res, profil)
    stem = Path(fichier).stem
    noyau.publier(cfg, n, f"{stem}.{nom_script}.json", json.dumps(res, ensure_ascii=False, indent=1), dossier)
    noyau.publier(cfg, n, f"{stem}.{nom_script}.md", texte_md, dossier)
    print(json.dumps(res, ensure_ascii=False, indent=1) if fmt == "json" else texte_md)
    return 1 if echecs else 0

def rendu(r, profil):
    portee = "monographie du SSP (Bloc 1)" if profil == "A" else f"{len(r['monographies'])} monographie(s) DX"
    l = [f"# {r['script']} — conformité V7 + Charte V7+ — {Path(r['fichier']).name}", "",
         f"{r['lot']} · agent {r['agent']} · {r['horodatage']} · {r['duree_ms']} ms · 14 points appliqués à : {portee}", "",
         "## Les 14 points (V7-Tunder §6)", "",
         noyau.tableau_md(["Point", "Intitulé", "Statut", "Référence", "Détail"],
                          [[x["point"], x["intitule"], x["statut"], x["references"], x["detail"] or "—"] for x in r["points_14"]]), "",
         "## Charte qualité V7+ et technique", "",
         noyau.tableau_md(["Code", "Critère", "Statut", "Référence", "Détail"],
                          [[x["code"], x["critere"], x["statut"], x["reference"], x["detail"] or "—"] for x in r["charte"]])]
    if r["bloc2"]:
        l += ["", "## Bloc 2 de l'Appel A (§9)", "", noyau.tableau_md(["Code", "Critère", "Statut", "Référence", "Détail"],
                                                                    [[x["code"], x["critere"], x["statut"], x["reference"], x["detail"] or "—"] for x in r["bloc2"]])]
    if r["contraste_navigateur"]:
        l += ["", "## Contraste mesuré dans le navigateur (contraste.py)", "", "```", r["contraste_navigateur"], "```"]
    l += ["", f"**{r['echecs']} ÉCHEC(S) — DÉPÔT BLOQUÉ** : corriger puis relancer." if r["echecs"] else "Aucun échec : dépôt autorisé du point de vue de la conformité (les ALERTES restent à traiter).",
          "S2 n'a rien modifié : il alerte seulement (empreinte sha256 identique avant/après)."]
    return "\n".join(l) + "\n"

def main(profil, argv=None):
    nom_script = f"S2{profil}"
    ap = argparse.ArgumentParser(prog=nom_script, description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--agent", type=int); ap.add_argument("--config")
    sp = ap.add_subparsers(dest="cmd", required=True)
    r = sp.add_parser("review"); r.add_argument("fichier"); r.add_argument("--appel-a"); r.add_argument("--format", default="md")
    r.add_argument("--contraste-navigateur", action="store_true")
    a = ap.parse_args(argv)
    def run():
        cfg = noyau.charger_config(a.agent, a.config)
        if a.appel_a and profil == "A":
            raise Refus("--appel-a n'a de sens que pour S2B")
        return review(cfg, profil, a.fichier, a.appel_a, a.format, a.contraste_navigateur, nom_script)
    return noyau.executer(run)
