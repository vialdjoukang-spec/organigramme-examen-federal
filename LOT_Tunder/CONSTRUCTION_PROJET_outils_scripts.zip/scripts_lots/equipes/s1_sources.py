"""S1 — script SOURCE d'équipe (moteur commun de S1A et S1B), v1.6.

Hiérarchie imposée, dans cet ordre (common/allowlist.json, validée par sonde HTTP) :
  N1 Suisse officielle (swissmedicinfo / compendium AIPS, Fedlex, OFSP-BAG, Swissmedic, OFS, Obsan, Infovac…)
  N2 Sociétés savantes et institutions suisses (SSI, SSMIG, SGK, SSN, HUG, CHUV, Unisanté…)
  N3 Recommandations européennes (ESC, EASL, ERS, ESMO, EAU, ESCMID, ECDC, EMA…)
  N4 International (OMS, NICE, CDC, IDSA, KDIGO, GINA, GOLD…) — jamais seule pour une conduite (V7-Tunder §4.2)
  N5 Littérature (PubMed / NCBI E-utilities, Europe PMC)
Priorité « prise en charge » : les requêtes de traitement sont classées avec le bonus PEC de l'index.
Toute affirmation chiffrée ou normative sans [Sn] = ALERTE BLOQUANTE : dépôt interdit (code 1).
S1 n'écrit jamais dans un LOT : il lit en O_RDONLY, vérifie le sha256 avant/après et n'écrit que dans
~/.scripts_lots/agent_N/retours/equipes/.

Commandes :
  plan  "SSP ou DX" [--dx "DX1;DX2;…"] [--limite 3] [--format md|json]   fiche de sourçage hiérarchisée (index local, 0 réseau)
  check FICHIER.html [--format md|json]                                   contrôle des sources propre au profil (A ou B)
  domaines | crawl … | search … | extrait … | pubmed …                     relais vers le moteur commun (script_source)
"""
import argparse, json, re, sys, time
from pathlib import Path
import noyau
from noyau import Refus
import config as cfgmod, lot_readonly, source_engine          # noqa: E402  (chemin ajouté par noyau)
from netutil import ListeBlanche                                # noqa: E402

AIPS = ("swissmedicinfo.ch", "compendium.ch", "download.swissmedicinfo.ch")
RE_DOSE = re.compile(r"\b\d+(?:[,.]\d+)?\s?(?:mg|µg|mcg|g|UI|U|mmol|mL|ml)(?:\s?/\s?(?:kg|m2|m²))?(?:\s?(?:/|par)\s?(?:j|jour|h|24\s?h|semaine))?\b(?!\s?/\s?L)")
RE_PROBA = re.compile(r"<sup\b[^>]*class=[\"']?[^\"'>]*\bproba\b[^>]*>(.*?)</sup>", re.S | re.I)
RE_SREF = re.compile(r"\[S\d+(?:\s*[,–-]\s*S?\d+)*\]")

# Gabarits de requêtes par profil : (intitulé, gabarit, priorité PEC, niveaux visés)
PROFILS = {
 "A": {"nom": "S1A — Appel A (plan, prévalences comparables, probabilités des DX)", "gabarits": [
    ("Définition (société savante)", "{t} définition", False, "1-3"),
    ("Épidémiologie suisse", "{t} prévalence Suisse", False, "1-2"),
    ("Incidence / fréquence", "{t} incidence épidémiologie", False, "1-3"),
    ("Diagnostics différentiels", "{t} diagnostic différentiel", False, "1-4"),
    ("Drapeaux rouges / urgence", "{t} urgence drapeaux rouges", True, "1-3"),
    ("Prise en charge initiale", "{t} recommandations prise en charge", True, "1-3")],
  "par_dx": [("Fréquence du DX (même unité, même population)", "{d} prévalence {t}", False, "1-3"),
             ("Signe / examen qui tranche", "{d} diagnostic examen", False, "1-4")]},
 "B": {"nom": "S1B — Appel B (physiopathologie, examens, traitements, molécules)", "gabarits": [],
  "par_dx": [("Définition et critères", "{d} critères diagnostiques définition", False, "1-3"),
             ("Physiopathologie", "{d} physiopathologie mécanisme", False, "1-5"),
             ("Examens (gold standard, intentions)", "{d} examens diagnostic gold standard", False, "1-4"),
             ("Prise en charge (recommandation suisse)", "{d} traitement recommandations prise en charge", True, "1-3"),
             ("Molécules : dose AIPS, spécialité ®", "{d} information professionnelle posologie", True, "1"),
             ("Surveillance et sortie", "{d} surveillance suivi sortie", True, "1-3"),
             ("Prévention", "{d} prévention vaccination dépistage", True, "1-3")]},
}

def _niveaux(spec):
    a, _, b = spec.partition("-"); return int(a), int(b or a)

def fiche(cfg, profil, theme, dx, limite):
    idx = source_engine.Index(cfg["cache_dir"])
    reqs = [(lib, g.format(t=theme, d=theme), pec, niv) for lib, g, pec, niv in PROFILS[profil]["gabarits"]]
    for d in (dx or ([theme] if profil == "B" else [])):
        reqs += [(f"{d} — {lib}", g.format(t=theme, d=d), pec, niv) for lib, g, pec, niv in PROFILS[profil]["par_dx"]]
    res = []
    for lib, q, pec, niv in reqs:
        lo, hi = _niveaux(niv)
        trouves = [r for r in idx.chercher(q, 5, pec, 40) if r["niveau"] >= lo]
        cibles = [r for r in trouves if r["niveau"] <= hi][:limite]
        repli = [r for r in trouves if r["niveau"] > hi][:1]
        statut = "OK" if cibles else ("REPLI niveau inférieur" if repli else "À CRAWLER")
        res.append({"besoin": lib, "requete": q, "pec": pec, "niveaux_vises": f"N{lo}–N{hi}", "statut": statut,
                    "resultats": cibles or repli})
    return res

def rendu_fiche(profil, theme, res):
    l = [f"# Fiche de sourçage — {theme} — {PROFILS[profil]['nom']}", "",
         "Ordre : N1 Suisse officielle → N2 sociétés suisses → N3 Europe → N4 international → N5 PubMed. Prise en charge prioritaire.",
         "Chaque fait retenu porte son [Sn], son URL et sa date de consultation (V7-Tunder §4).", ""]
    for r in res:
        l.append(f"## {r['besoin']} — {r['statut']} ({r['niveaux_vises']}{', PEC' if r['pec'] else ''})")
        l.append(f"_Requête : « {r['requete']} »_")
        for x in r["resultats"]:
            l.append(f"- N{x['niveau']} [{x['titre'] or x['url']}]({x['url']}) — {x['extrait'][:160]} _(consulté le {x['consulte_le'][:10]})_")
        if r["statut"] == "À CRAWLER":
            l.append("- Aucun résultat indexé : lancer `crawl --niveaux 1,2` puis `search` ; à défaut `pubmed` (N5), jamais de mémoire.")
        l.append("")
    return "\n".join(l)

# ---------- contrôle des sources propre au profil ----------
def _blocs(html):
    p = source_engine._Blocs(); p.feed(html)
    defs = {}
    for b in (x for x in p.blocs if x["sources"]):
        for m in re.finditer(r"\[S(\d+)\]", b["texte"]):
            defs[int(m.group(1))] = source_engine._url(b["texte"])
    return [b for b in p.blocs if not b["sources"]], defs

def _refs(t):
    return {int(x) for m in source_engine.RE_REF.finditer(t) for x in re.findall(r"\d+", m.group(0))}

def controle_profil(html, profil, lb):
    corps, defs = _blocs(html); al = []
    niv_def = {n: lb.niveau(u) if u else None for n, u in defs.items()}
    if profil == "A":
        unites = set()
        for m in RE_PROBA.finditer(html):
            contenu = re.sub(r"<[^>]+>", "", m.group(1)).strip()
            ligne = html.count("\n", 0, m.start()) + 1
            if re.search(r"\d", contenu):
                unites.add("%" if "%" in contenu else ("/100 000" if "100" in contenu and "000" in contenu else "autre"))
                debut = max(html.rfind("<li", 0, m.start()), html.rfind("<tr", 0, m.start()), html.rfind("<p", 0, m.start()),
                            html.rfind("<summary", 0, m.start()), html.rfind("<h", 0, m.start()))
                fins = [x for x in (html.find(t, m.end()) for t in ("</li>", "</tr>", "</p>", "</summary>")) if x > 0]
                zone = html[debut: min(fins) if fins else m.end() + 400]
                if not RE_SREF.search(zone):
                    al.append(("P1", "§9.3", ligne, f"probabilité « {contenu} » sans source [Sn] (Charte V7+ §3 : aucun chiffre orphelin)"))
            elif not re.search(r"n\.\s?d\.|non quantifi", contenu, re.I):
                al.append(("P2", "§9.3", ligne, f"exposant de probabilité vide ou non conforme : « {contenu} »"))
        if len(unites) > 1:
            al.append(("P2", "§9.1", None, f"prévalences/probabilités en unités différentes {sorted(unites)} : même unité et même population exigées (Charte V7+ §4)"))
        epi = [b for b in corps if b["point"] == 2 and _refs(b["texte"])]
        if epi and not any((niv_def.get(r) or 9) <= 2 for b in epi for r in _refs(b["texte"])):
            al.append(("P2", "§4.2", None, "épidémiologie (point 2) sans aucune source suisse N1–N2 : Suisse d'abord"))
    else:
        for b in corps:
            t = re.sub(r"\s+", " ", b["texte"])
            if not RE_DOSE.search(t) or not re.search(r"\b(dose|posologie|mg|µg|UI|perfus|per os|i\.v\.|p\.o\.)", t, re.I):
                continue
            r = _refs(t)
            if b["point"] in (11, None) and r and not any(defs.get(x) and any(a in defs[x] for a in AIPS) for x in r):
                al.append(("P1", "§4.1", b["ligne"], "dose sans référence à l'AIPS (swissmedicinfo.ch / compendium.ch) : une dose vient uniquement de l'AIPS"))
            if "®" in t and not r:
                al.append(("P2", "§4.1", b["ligne"], "spécialité ® sans source [Sn]"))
    n12 = sum(1 for v in niv_def.values() if v in (1, 2))
    if defs and n12 == 0:
        al.append(("P2", "§4.2", None, "aucune source suisse (N1–N2) dans la section Sources"))
    repart = {f"N{k}": sum(1 for v in niv_def.values() if v == k) for k in range(1, 6)}
    repart["hors liste"] = sum(1 for v in niv_def.values() if v is None)
    return al, repart

def check(cfg, profil, fichier, fmt, nom_script):
    n, dossier = noyau.garde(cfg, fichier, profil, nom_script)
    t0 = time.perf_counter()
    with noyau.LectureSeule(fichier) as html:
        lb = ListeBlanche()
        pb, st = source_engine.verifier_sources(html, lb)
        al, repart = controle_profil(html, profil, lb)
    items = [{"gravite": x["gravite"], "section": x["section"], "ligne": x["ligne"], "message": x["message"], "extrait": x["extrait"]} for x in pb]
    items += [{"gravite": g, "section": s, "ligne": li, "message": m, "extrait": ""} for g, s, li, m in al]
    items.sort(key=lambda x: x["gravite"])
    bloq = sum(1 for x in items if x["gravite"] == "P1")
    res = {"script": nom_script, "version": noyau.VERSION, "fichier": str(fichier), "lot": f"LOT_{n:03d}", "agent": cfg["agent"],
           "horodatage": time.strftime("%Y-%m-%d %H:%M (%Z)"), "duree_ms": round(1000 * (time.perf_counter() - t0), 1),
           "stats": st, "repartition_niveaux": repart, "bloquants": bloq, "items": items,
           "depot": "BLOQUÉ" if bloq else "autorisé (sources)", "lecture_seule": "sha256 identique avant/après"}
    md = [f"# {nom_script} — contrôle des sources — {Path(fichier).name}", "",
          f"{st['affirmations_detectees']} affirmations détectées · {st['sources_definies']} sources · répartition {repart} · **{bloq} bloquant(s)**", ""]
    md += [f"- {x['gravite']} [{x['section']}] {('ligne ' + str(x['ligne'])) if x['ligne'] else ''} : {x['message']}" + (f" — « {x['extrait'][:100]} »" if x["extrait"] else "") for x in items[:60]]
    if len(items) > 60: md.append(f"- … {len(items) - 60} autres (voir le .json)")
    md += ["", "ALERTE — DÉPÔT BLOQUÉ : sourcer chaque affirmation signalée, puis relancer." if bloq else "Dépôt autorisé du point de vue des sources.",
           "S1 n'a rien modifié : il alerte seulement (empreinte sha256 identique avant/après)."]
    texte = "\n".join(md) + "\n"
    stem = Path(fichier).stem
    noyau.publier(cfg, n, f"{stem}.{nom_script}.json", json.dumps(res, ensure_ascii=False, indent=1), dossier)
    noyau.publier(cfg, n, f"{stem}.{nom_script}.md", texte, dossier)
    print(json.dumps(res, ensure_ascii=False, indent=1) if fmt == "json" else texte)
    return 1 if bloq else 0

def main(profil, argv=None):
    nom_script = f"S1{profil}"
    ap = argparse.ArgumentParser(prog=nom_script, description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--agent", type=int); ap.add_argument("--config")
    ap.add_argument("cmd", choices=["plan", "check", "domaines", "crawl", "search", "extrait", "pubmed"])
    ap.add_argument("reste", nargs=argparse.REMAINDER)
    a = ap.parse_args(argv)
    def run():
        cfg = noyau.charger_config(a.agent, a.config)
        if a.cmd == "plan":
            p = argparse.ArgumentParser(prog=f"{nom_script} plan"); p.add_argument("theme"); p.add_argument("--dx", default="")
            p.add_argument("--limite", type=int, default=3); p.add_argument("--format", default="md"); b = p.parse_args(a.reste)
            res = fiche(cfg, profil, b.theme, [x.strip() for x in b.dx.split(";") if x.strip()], b.limite)
            txt = rendu_fiche(profil, b.theme, res)
            out = Path(cfg["output_dir"]) / "equipes" / "sourcage" / (re.sub(r"\W+", "_", b.theme.lower())[:60] + f".{nom_script}.md")
            lot_readonly.ecrire_sortie(out, txt, cfg["output_dir"], [])
            print(json.dumps(res, ensure_ascii=False, indent=1) if b.format == "json" else txt)
            return 0 if all(r["statut"] == "OK" for r in res) else 3
        if a.cmd == "check":
            p = argparse.ArgumentParser(prog=f"{nom_script} check"); p.add_argument("fichier"); p.add_argument("--format", default="md")
            b = p.parse_args(a.reste)
            return check(cfg, profil, b.fichier, b.format, nom_script)
        return source_engine.main(cfg["_chemin"], [a.cmd] + a.reste)
    return noyau.executer(run)
