#!/usr/bin/env python3
"""Agent 14 — équipe 5, Appel A (plan et liste des 10 DX), LOT_078→LOT_043 (décroissant) — raccourci vers equipes/S2A.py avec la configuration de CET agent (lecture seule absolue sur les LOT)."""
import sys
from pathlib import Path
ICI = Path(__file__).resolve().parent
sys.path.insert(0, str(ICI.parent / "equipes"))
import s2_conformite
sys.exit(s2_conformite.main("A", ["--config", str(ICI / "config.json")] + sys.argv[1:]))
