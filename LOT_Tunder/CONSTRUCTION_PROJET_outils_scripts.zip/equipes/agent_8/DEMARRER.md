# DÉMARRER — Agent 8 — Équipe 5 · Appel B Parties 3–4 (LOT_078–043)

> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `db322130-de1f-49d9-a669-bd9b54729c37`), en une ligne : `BLOCAGE · Agent 8 · LOT_X : <motif ≤ 8 mots>`. Le non-bloquant va dans `/workspace/agent8/POUR_TUNDER_AGENT_8.md`.

## 1. Identité
- **Nom** : Agent 8 — Équipe 5 · Appel B Parties 3–4 (LOT_078–043)
- **Équipe 5** : LOT_078 → LOT_043 (36 LOT, ordre décroissant) — A = Agent 14, B1 = Agent 15, B2 = Agent 8 (vous)
- **Rôle B2** : l'Appel B Partie 3 (DX.6 à DX.7) puis l'Appel B Partie 4 (DX.8 à DX.10) — deux fichiers distincts par LOT.
- **Dossier de travail** : `/workspace/agent8/LOT_X/` · **fil** : `/workspace/equipes/agent_8/ETAT.md` · **config** : `/workspace/scripts_lots/agent_8/config.json` (ne pas modifier)
- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_8.md` (v1.6) — elles priment en cas de doute.

## 2. Transition (ancien rôle → nouveau rôle)
- Ancien rôle : Équipe 2 · Partie 4 (LOT_109 → LOT_001). **Vous finissez le fichier en cours sous l'ancien rôle, puis vous passez au nouveau rôle et à la nouvelle plage.**
- Fichier de transition accepté par vos scripts : LOT_007 Partie 4 → le finir, le contrôler, le déposer s'il n'est pas déjà sur Drive.
- Relevé local : Transition : la Partie 4 du LOT_007 est terminée dans votre dossier (17 h 05) : vous la contrôlez, la corrigez si S1/S2 bloquent et la déposez si elle n'est pas déjà sur Drive (acceptée par vos scripts : LOT_007 Partie 4, rien d'autre). Ensuite vous commencez à LOT_078 : Partie 3 puis Partie 4.

## 3. Règle de saut
Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).

## 4. Liste exacte de vos fichiers (73 fichiers, dans cet ordre)
Dossier Drive parent « LOTS_Finaux avec statut » : `1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`. Le dossier `1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB` ne doit **jamais** être ouvert, listé ni lu.

| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |
|---|---|---|---|---|---|
| 1 | LOT_007 | Partie 4 (transition) | `LOT_007_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1DToymCzAnIP1BrJ0Oh7S8PWQ3ns5u4EB` | terminé localement par l'Agent 8 — vérifier Drive, sauter si déposé |
| 2 | LOT_078 | Partie 3 | `LOT_078_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1pBsQFCcMJVJz5oew5yoN-aTp8y-L3nPb` | à faire |
| 3 | LOT_078 | Partie 4 | `LOT_078_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1pBsQFCcMJVJz5oew5yoN-aTp8y-L3nPb` | à faire |
| 4 | LOT_077 | Partie 3 | `LOT_077_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1bNlyDTRlksiznLRROWcfoNtfwYAAks_a` | à faire |
| 5 | LOT_077 | Partie 4 | `LOT_077_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1bNlyDTRlksiznLRROWcfoNtfwYAAks_a` | à faire |
| 6 | LOT_076 | Partie 3 | `LOT_076_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `11bIgXnnOMbX16xpMofJ1oCyU-tQVEc1b` | à faire |
| 7 | LOT_076 | Partie 4 | `LOT_076_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `11bIgXnnOMbX16xpMofJ1oCyU-tQVEc1b` | à faire |
| 8 | LOT_075 | Partie 3 | `LOT_075_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1zsi9isxQuR1gEZCT1QHU1H-kWtwFDSBJ` | à faire |
| 9 | LOT_075 | Partie 4 | `LOT_075_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1zsi9isxQuR1gEZCT1QHU1H-kWtwFDSBJ` | à faire |
| 10 | LOT_074 | Partie 3 | `LOT_074_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `12aE2sEDBYa7Q48tI3UEFoPMi87tDsJvx` | à faire |
| 11 | LOT_074 | Partie 4 | `LOT_074_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `12aE2sEDBYa7Q48tI3UEFoPMi87tDsJvx` | à faire |
| 12 | LOT_073 | Partie 3 | `LOT_073_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `13b3YrcbdTnvrUUPUctsjZzylpENupg0d` | à faire |
| 13 | LOT_073 | Partie 4 | `LOT_073_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `13b3YrcbdTnvrUUPUctsjZzylpENupg0d` | à faire |
| 14 | LOT_072 | Partie 3 | `LOT_072_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1nxWpxMJ0Sn9u6xsUNHcl2-Cr6Cc-qITS` | à faire |
| 15 | LOT_072 | Partie 4 | `LOT_072_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1nxWpxMJ0Sn9u6xsUNHcl2-Cr6Cc-qITS` | à faire |
| 16 | LOT_071 | Partie 3 | `LOT_071_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1eBzOFKsbaGBKSLlubO_iOWAtRM7nOzid` | à faire |
| 17 | LOT_071 | Partie 4 | `LOT_071_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1eBzOFKsbaGBKSLlubO_iOWAtRM7nOzid` | à faire |
| 18 | LOT_070 | Partie 3 | `LOT_070_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1_XPXuHcrjzHyojTX-dEY9_-PCP_EVYzI` | à faire |
| 19 | LOT_070 | Partie 4 | `LOT_070_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1_XPXuHcrjzHyojTX-dEY9_-PCP_EVYzI` | à faire |
| 20 | LOT_069 | Partie 3 | `LOT_069_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `19iRN6OQ6YDOEhDKR5Y6PWQjORJbQD7Yk` | à faire |
| 21 | LOT_069 | Partie 4 | `LOT_069_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `19iRN6OQ6YDOEhDKR5Y6PWQjORJbQD7Yk` | à faire |
| 22 | LOT_068 | Partie 3 | `LOT_068_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1mxLSaXEhrHHNYV5ERY2AhHd2Zxr7Rzgk` | à faire |
| 23 | LOT_068 | Partie 4 | `LOT_068_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1mxLSaXEhrHHNYV5ERY2AhHd2Zxr7Rzgk` | à faire |
| 24 | LOT_067 | Partie 3 | `LOT_067_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `11a9k9UfFozneyph47txvgHIZ3TxPHU4R` | à faire |
| 25 | LOT_067 | Partie 4 | `LOT_067_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `11a9k9UfFozneyph47txvgHIZ3TxPHU4R` | à faire |
| 26 | LOT_066 | Partie 3 | `LOT_066_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1FsuXuE4qYmdp62R7UWfl9_W8OEvHcw0a` | à faire |
| 27 | LOT_066 | Partie 4 | `LOT_066_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1FsuXuE4qYmdp62R7UWfl9_W8OEvHcw0a` | à faire |
| 28 | LOT_065 | Partie 3 | `LOT_065_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1a5BdK7YxQsrFv7aGasANGn7fV8mMkX99` | à faire |
| 29 | LOT_065 | Partie 4 | `LOT_065_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1a5BdK7YxQsrFv7aGasANGn7fV8mMkX99` | à faire |
| 30 | LOT_064 | Partie 3 | `LOT_064_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1YlXKarX-eHTqQMM6OpR5bA6RLvjfJTCV` | à faire |
| 31 | LOT_064 | Partie 4 | `LOT_064_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1YlXKarX-eHTqQMM6OpR5bA6RLvjfJTCV` | à faire |
| 32 | LOT_063 | Partie 3 | `LOT_063_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1-KWp2UUkB-dVJAyPk1R_H-13Zd5IPwaQ` | à faire |
| 33 | LOT_063 | Partie 4 | `LOT_063_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1-KWp2UUkB-dVJAyPk1R_H-13Zd5IPwaQ` | à faire |
| 34 | LOT_062 | Partie 3 | `LOT_062_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `18974FglU-6mypzzSOVdZHELk-m7PKi-6` | à faire |
| 35 | LOT_062 | Partie 4 | `LOT_062_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `18974FglU-6mypzzSOVdZHELk-m7PKi-6` | à faire |
| 36 | LOT_061 | Partie 3 | `LOT_061_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `10SoszPJ0mBuS2gFm1B6ziKPzoDdtx-2_` | à faire |
| 37 | LOT_061 | Partie 4 | `LOT_061_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `10SoszPJ0mBuS2gFm1B6ziKPzoDdtx-2_` | à faire |
| 38 | LOT_060 | Partie 3 | `LOT_060_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1cuLARKq4uQxp1SW-IpVe0QWGPzn-JlMv` | à faire |
| 39 | LOT_060 | Partie 4 | `LOT_060_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1cuLARKq4uQxp1SW-IpVe0QWGPzn-JlMv` | à faire |
| 40 | LOT_059 | Partie 3 | `LOT_059_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1BqlBEtIfmRODVvkrMXyamlN9CorDG-Az` | à faire |
| 41 | LOT_059 | Partie 4 | `LOT_059_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1BqlBEtIfmRODVvkrMXyamlN9CorDG-Az` | à faire |
| 42 | LOT_058 | Partie 3 | `LOT_058_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `125irbmgjZ4U-ZtjLUcWxzJDKVHejzRnA` | à faire |
| 43 | LOT_058 | Partie 4 | `LOT_058_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `125irbmgjZ4U-ZtjLUcWxzJDKVHejzRnA` | à faire |
| 44 | LOT_057 | Partie 3 | `LOT_057_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1S2ueqo0pAP2nGfzll47du8az49l8-hd8` | à faire |
| 45 | LOT_057 | Partie 4 | `LOT_057_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1S2ueqo0pAP2nGfzll47du8az49l8-hd8` | à faire |
| 46 | LOT_056 | Partie 3 | `LOT_056_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1LDFmrSUBzOXWJ-cEpOx0UX36esWDtzWB` | à faire |
| 47 | LOT_056 | Partie 4 | `LOT_056_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1LDFmrSUBzOXWJ-cEpOx0UX36esWDtzWB` | à faire |
| 48 | LOT_055 | Partie 3 | `LOT_055_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1OD0UeceMAleXjE8pDBipKxAElSI7DWzK` | à faire |
| 49 | LOT_055 | Partie 4 | `LOT_055_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1OD0UeceMAleXjE8pDBipKxAElSI7DWzK` | à faire |
| 50 | LOT_054 | Partie 3 | `LOT_054_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1u4QFZ6SkZOQKcJYmskaJ8DTX7fRsLTWt` | à faire |
| 51 | LOT_054 | Partie 4 | `LOT_054_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1u4QFZ6SkZOQKcJYmskaJ8DTX7fRsLTWt` | à faire |
| 52 | LOT_053 | Partie 3 | `LOT_053_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1v80_IhAHOKPdIHpbRlmpxx5DxrUN44Mw` | à faire |
| 53 | LOT_053 | Partie 4 | `LOT_053_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1v80_IhAHOKPdIHpbRlmpxx5DxrUN44Mw` | à faire |
| 54 | LOT_052 | Partie 3 | `LOT_052_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1KNB9G-mZ8zIVV8Q6G_UjVy4XyRWYoukj` | à faire |
| 55 | LOT_052 | Partie 4 | `LOT_052_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1KNB9G-mZ8zIVV8Q6G_UjVy4XyRWYoukj` | à faire |
| 56 | LOT_051 | Partie 3 | `LOT_051_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `15p9jVp6JiZW11-QKttGxuxvxu2BfGyL0` | à faire |
| 57 | LOT_051 | Partie 4 | `LOT_051_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `15p9jVp6JiZW11-QKttGxuxvxu2BfGyL0` | à faire |
| 58 | LOT_050 | Partie 3 | `LOT_050_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1_rSqomvj3M1gJ4yYs0zC_Nma0IcR20u7` | à faire |
| 59 | LOT_050 | Partie 4 | `LOT_050_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1_rSqomvj3M1gJ4yYs0zC_Nma0IcR20u7` | à faire |
| 60 | LOT_049 | Partie 3 | `LOT_049_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1PUpKkEO0ctbXj2uve9xQt_jhwYLScPMN` | à faire |
| 61 | LOT_049 | Partie 4 | `LOT_049_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1PUpKkEO0ctbXj2uve9xQt_jhwYLScPMN` | à faire |
| 62 | LOT_048 | Partie 3 | `LOT_048_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1yTzzVlCe8wQWae3ENj3Cxj0iII8OZ5s1` | à faire |
| 63 | LOT_048 | Partie 4 | `LOT_048_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1yTzzVlCe8wQWae3ENj3Cxj0iII8OZ5s1` | à faire |
| 64 | LOT_047 | Partie 3 | `LOT_047_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1L9kNfL6lwPomLzUKVtwadyARZiNc3vZK` | à faire |
| 65 | LOT_047 | Partie 4 | `LOT_047_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1L9kNfL6lwPomLzUKVtwadyARZiNc3vZK` | à faire |
| 66 | LOT_046 | Partie 3 | `LOT_046_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1JwIWD9qfm-BnwO46Df842ER8MYDs-Ogg` | à faire |
| 67 | LOT_046 | Partie 4 | `LOT_046_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1JwIWD9qfm-BnwO46Df842ER8MYDs-Ogg` | à faire |
| 68 | LOT_045 | Partie 3 | `LOT_045_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1HeEa8-ot9frXjqf79D-P1yDRN_eXHmPb` | à faire |
| 69 | LOT_045 | Partie 4 | `LOT_045_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1HeEa8-ot9frXjqf79D-P1yDRN_eXHmPb` | à faire |
| 70 | LOT_044 | Partie 3 | `LOT_044_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1JI9flvxsDMnXMc5Y50EgcnwemmFw7Ztg` | à faire |
| 71 | LOT_044 | Partie 4 | `LOT_044_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1JI9flvxsDMnXMc5Y50EgcnwemmFw7Ztg` | à faire |
| 72 | LOT_043 | Partie 3 | `LOT_043_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1N8j7RaBINORH0Jdx5UzqSX90pwKid6Or` | à faire |
| 73 | LOT_043 | Partie 4 | `LOT_043_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1N8j7RaBINORH0Jdx5UzqSX90pwKid6Or` | à faire |

Nom de dépôt sur Drive : « Agent_8 | LOT_X Partie 3 — <noms des différentiels>.html » ; « Agent_8 | LOT_X Partie 4 — <noms des différentiels>.html » (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.

## 5. Commandes (dans cet ordre, pour chaque fichier)
```
python3 /workspace/scripts_lots/equipes/S1B.py --agent 8 plan "<thème du LOT>" --dx "<DX de la Partie>"
python3 /workspace/scripts_lots/agent_8/script_source.py search "<requête>" --pec      # index local d'abord
python3 /workspace/scripts_lots/agent_8/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »
# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste
python3 /workspace/scripts_lots/equipes/S1B.py --agent 8 check /workspace/agent8/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/equipes/S2B.py --agent 8 review /workspace/agent8/LOT_X/<fichier>.html --appel-a <Appel A du LOT>.html   # doit renvoyer 0
python3 /workspace/scripts_lots/agent_8/script_source.py check /workspace/agent8/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/agent_8/script_synchrone.py review /workspace/agent8/LOT_X/<fichier>.html     # un seul passage LanguageTool
grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0
```
Raccourcis : `python3 /workspace/scripts_lots/agent_8/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.

## 6. Charte (rappel)
`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.

## 7. Skills
- `skills/performance-redaction-lot/SKILL.md` (→ `/workspace/reorg/skills/performance-redaction-lot/SKILL.md`)
- `skills/concentration-fil-redaction/SKILL.md` (→ `/workspace/reorg/skills/concentration-fil-redaction/SKILL.md`)
- `skills/anti-gaspillage-redaction/SKILL.md` (→ `/workspace/reorg/skills/anti-gaspillage-redaction/SKILL.md`)
- `skills/harness-redacteur-v7/SKILL.md` (→ `/workspace/reorg/skills/harness-redacteur-v7/SKILL.md`)

## 8. Après chaque dépôt
Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.
Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.

FIN_DEMARRER
