# DÉMARRER — Agent 16 — Équipe 6 · Appel A (LOT_042–007)

> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `db322130-de1f-49d9-a669-bd9b54729c37`), en une ligne : `BLOCAGE · Agent 16 · LOT_X : <motif ≤ 8 mots>`. Le non-bloquant va dans `/workspace/agent16/POUR_TUNDER_AGENT_16.md`.

## 1. Identité
- **Nom** : Agent 16 — Équipe 6 · Appel A (LOT_042–007)
- **Équipe 6** : LOT_042 → LOT_007 (36 LOT, ordre décroissant) — A = Agent 16 (vous), B1 = Agent 17, B2 = Agent 18
- **Rôle A** : l'Appel A (plan et liste des 10 DX) — un fichier par LOT.
- **Dossier de travail** : `/workspace/agent16/LOT_X/` · **fil** : `/workspace/equipes/agent_16/ETAT.md` · **config** : `/workspace/scripts_lots/agent_16/config.json` (ne pas modifier)
- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_16.md` (v1.6) — elles priment en cas de doute.

## 2. Reprise
- LOT_007 et LOT_008 : sautez tout fichier déjà déposé sur Drive. L'Appel A du LOT_007 est celui de l'Agent 2 (transition) ; celui du LOT_008 est complet. LOT_010 et LOT_009 sont complets : vous les sautez.

## 3. Règle de saut
Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).

**Équipe 6 — LOT_008 et LOT_007** : ces deux LOT ont été largement rédigés par l'ancienne équipe 2 (Agents 2, 4, 6, 8), dont une partie en transition jusqu'à 17 h. Vous **sautez tout fichier LOT_007/LOT_008 déjà déposé sur Drive**, quel que soit l'agent qui l'a déposé ; vous ne rédigez un fichier de ces deux LOT que s'il est absent de Drive au moment où vous y arrivez (en fin de série).

## 4. Liste exacte de vos fichiers (36 fichiers, dans cet ordre)
Dossier Drive parent « LOTS_Finaux avec statut » : `1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`. Le dossier `1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB` ne doit **jamais** être ouvert, listé ni lu.

| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |
|---|---|---|---|---|---|
| 1 | LOT_042 | Appel A | `LOT_042_Appel_A_V7_Plan_et_Liste.html` | `1wGtXrSNVp_Tk0MF5ZNmQQtVF9CDPNX2G` | à faire |
| 2 | LOT_041 | Appel A | `LOT_041_Appel_A_V7_Plan_et_Liste.html` | `1MmX9BbqMURGaNOdMw4IqcM-HPG4OsDm7` | à faire |
| 3 | LOT_040 | Appel A | `LOT_040_Appel_A_V7_Plan_et_Liste.html` | `1h1gmQlRzd_J3GEHkXLTW5C8K4GkdW6W-` | à faire |
| 4 | LOT_039 | Appel A | `LOT_039_Appel_A_V7_Plan_et_Liste.html` | `1LDPRXZzXqg7ntubVB7IAF03KskCVGV03` | à faire |
| 5 | LOT_038 | Appel A | `LOT_038_Appel_A_V7_Plan_et_Liste.html` | `1hwLZQ6iq1V4TFG9fDM6uxvvvYnuOKZzN` | à faire |
| 6 | LOT_037 | Appel A | `LOT_037_Appel_A_V7_Plan_et_Liste.html` | `13w0CX8XmYrW4oSIX8JhC7LDPj-PRo3K4` | à faire |
| 7 | LOT_036 | Appel A | `LOT_036_Appel_A_V7_Plan_et_Liste.html` | `15wvJZYXKIabH1MksOUVD6L6Tdq-obViA` | à faire |
| 8 | LOT_035 | Appel A | `LOT_035_Appel_A_V7_Plan_et_Liste.html` | `1FIZvluqvB8b1zFAUDGBES8TrO62yFMMK` | à faire |
| 9 | LOT_034 | Appel A | `LOT_034_Appel_A_V7_Plan_et_Liste.html` | `1ndnIoJ0yIxd0lRGY1Rr5-xHiMQCjf1GT` | à faire |
| 10 | LOT_033 | Appel A | `LOT_033_Appel_A_V7_Plan_et_Liste.html` | `12VdKhk5wvrhpNhZ4-oG79RYL_huL3uKl` | à faire |
| 11 | LOT_032 | Appel A | `LOT_032_Appel_A_V7_Plan_et_Liste.html` | `1xxM_ijYmyzb_6R0XptuUxWv3xSWEtToM` | à faire |
| 12 | LOT_031 | Appel A | `LOT_031_Appel_A_V7_Plan_et_Liste.html` | `1yLCRkHFcF15f-QYAQdDMAwBIM1n0X1fF` | à faire |
| 13 | LOT_030 | Appel A | `LOT_030_Appel_A_V7_Plan_et_Liste.html` | `1JZmjZ9Xz2MjgzxPbOppaeT2UE9kNRK7Y` | à faire |
| 14 | LOT_029 | Appel A | `LOT_029_Appel_A_V7_Plan_et_Liste.html` | `1g4C3BWa8mFXym3Jt2TpvhN0jUBFUagkq` | à faire |
| 15 | LOT_028 | Appel A | `LOT_028_Appel_A_V7_Plan_et_Liste.html` | `1ax3RelfAwQM9X2lMOFzkPZCKHTtLiQM5` | à faire |
| 16 | LOT_027 | Appel A | `LOT_027_Appel_A_V7_Plan_et_Liste.html` | `1R0m49916OdNv364Y73dpQxncNaH01aJ6` | à faire |
| 17 | LOT_026 | Appel A | `LOT_026_Appel_A_V7_Plan_et_Liste.html` | `1WbnWxNKZiclgHzrrSg3uI49cq6lxS0aE` | à faire |
| 18 | LOT_025 | Appel A | `LOT_025_Appel_A_V7_Plan_et_Liste.html` | `1qYqi4w1D9JLCcBzx74h7bv5zrmJj42w2` | à faire |
| 19 | LOT_024 | Appel A | `LOT_024_Appel_A_V7_Plan_et_Liste.html` | `1CICM1O-a7cDfUENgGxLxL1jk5_28FuBH` | à faire |
| 20 | LOT_023 | Appel A | `LOT_023_Appel_A_V7_Plan_et_Liste.html` | `1RAm3AUYJT1u4aXjEnzawXe2ocE2h7-7t` | à faire |
| 21 | LOT_022 | Appel A | `LOT_022_Appel_A_V7_Plan_et_Liste.html` | `1MzPPIw3_04j7LxvCwmVSCAlIHCbQbn9F` | à faire |
| 22 | LOT_021 | Appel A | `LOT_021_Appel_A_V7_Plan_et_Liste.html` | `1-zNGeFfhpKh-kUcEXFyxh9MuYQWsBSbZ` | à faire |
| 23 | LOT_020 | Appel A | `LOT_020_Appel_A_V7_Plan_et_Liste.html` | `1dTBXLlJs6W3ODL7o38C9f3TrQg5bZf-y` | à faire |
| 24 | LOT_019 | Appel A | `LOT_019_Appel_A_V7_Plan_et_Liste.html` | `1T44N5t_7bx_JcoiptVKdwS-l7QhJQjXS` | à faire |
| 25 | LOT_018 | Appel A | `LOT_018_Appel_A_V7_Plan_et_Liste.html` | `1foeNbXbG14ouoXIh4rpZZWjTONLabu3Q` | à faire |
| 26 | LOT_017 | Appel A | `LOT_017_Appel_A_V7_Plan_et_Liste.html` | `1Q3k6mJCjI_7MIB0I9j9EwVXMSA2kPLt3` | à faire |
| 27 | LOT_016 | Appel A | `LOT_016_Appel_A_V7_Plan_et_Liste.html` | `1Bs4REilfH38tHnHgC9EsXX2Qh_X1cPHr` | à faire |
| 28 | LOT_015 | Appel A | `LOT_015_Appel_A_V7_Plan_et_Liste.html` | `1gi5tH4ror5ogRRmicC8TZwmCW0qU6j34` | à faire |
| 29 | LOT_014 | Appel A | `LOT_014_Appel_A_V7_Plan_et_Liste.html` | `1mJLHI1Y0fPh2PBvvsXL8CtYcMHYl846O` | à faire |
| 30 | LOT_013 | Appel A | `LOT_013_Appel_A_V7_Plan_et_Liste.html` | `1wyscZWFBY9GD8I9LOXGsRoZ9MG3Mb_fF` | à faire |
| 31 | LOT_012 | Appel A | `LOT_012_Appel_A_V7_Plan_et_Liste.html` | `1WYj7HAc2zHezy8CurwGshSpNxOhNeG3B` | à faire |
| 32 | LOT_011 | Appel A | `LOT_011_Appel_A_V7_Plan_et_Liste.html` | `13z0sK7ZRJaSf68KGNdFDl2hG9rJifvAE` | à faire |
| 33 | LOT_010 | Appel A | `LOT_010_Appel_A_V7_Plan_et_Liste.html` | `1rupiUExpNyLfiTAgSC7JmT9kbb_54p4r` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 34 | LOT_009 | Appel A | `LOT_009_Appel_A_V7_Plan_et_Liste.html` | `1LD7cCfwJ-1Eh1CbXWwQisJKdSIuXSl9K` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 35 | LOT_008 | Appel A | `LOT_008_Appel_A_V7_Plan_et_Liste.html` | `1QxQccTA70DBwo3bJ0rpjkz5yg_AcgO2j` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 36 | LOT_007 | Appel A | `LOT_007_Appel_A_V7_Plan_et_Liste.html` | `1DToymCzAnIP1BrJ0Oh7S8PWQ3ns5u4EB` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |

Nom de dépôt sur Drive : « Agent_16 | LOT_X Appel A — Plan et liste des différentiels.html » (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.

## 5. Commandes (dans cet ordre, pour chaque fichier)
```
python3 /workspace/scripts_lots/equipes/S1A.py --agent 16 plan "<thème du LOT>"
python3 /workspace/scripts_lots/agent_16/script_source.py search "<requête>" --pec      # index local d'abord
python3 /workspace/scripts_lots/agent_16/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »
# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste
python3 /workspace/scripts_lots/equipes/S1A.py --agent 16 check /workspace/agent16/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/equipes/S2A.py --agent 16 review /workspace/agent16/LOT_X/<fichier>.html   # doit renvoyer 0
python3 /workspace/scripts_lots/agent_16/script_source.py check /workspace/agent16/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/agent_16/script_synchrone.py review /workspace/agent16/LOT_X/<fichier>.html     # un seul passage LanguageTool
grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0
```
Raccourcis : `python3 /workspace/scripts_lots/agent_16/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.

## 6. Charte (rappel)
`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.

## 7. Skills
- `skills/performance-redaction-lot/SKILL.md` (→ `/workspace/reorg/skills/performance-redaction-lot/SKILL.md`)
- `skills/concentration-fil-redaction/SKILL.md` (→ `/workspace/reorg/skills/concentration-fil-redaction/SKILL.md`)
- `skills/anti-gaspillage-redaction/SKILL.md` (→ `/workspace/reorg/skills/anti-gaspillage-redaction/SKILL.md`)
- `skills/harness-redacteur-v7/SKILL.md` (→ `/workspace/reorg/skills/harness-redacteur-v7/SKILL.md`)

## 8. Après chaque dépôt
Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.
Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.

FIN_DEMARRER
