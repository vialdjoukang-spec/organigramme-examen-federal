# DÉMARRER — Agent 3 — Équipe 1 · Appel B Parties 1–2 (LOT_218–184)

> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `db322130-de1f-49d9-a669-bd9b54729c37`), en une ligne : `BLOCAGE · Agent 3 · LOT_X : <motif ≤ 8 mots>`. Le non-bloquant va dans `/workspace/agent3/POUR_TUNDER_AGENT_3.md`.

## 1. Identité
- **Nom** : Agent 3 — Équipe 1 · Appel B Parties 1–2 (LOT_218–184)
- **Équipe 1** : LOT_218 → LOT_184 (35 LOT, ordre décroissant) — A = Agent 1, B1 = Agent 3 (vous), B2 = Agent 5
- **Rôle B1** : l'Appel B Partie 1 (DX.1 à DX.2) puis l'Appel B Partie 2 (DX.3 à DX.5) — deux fichiers distincts par LOT.
- **Dossier de travail** : `/workspace/agent3/LOT_X/` · **fil** : `/workspace/equipes/agent_3/ETAT.md` · **config** : `/workspace/scripts_lots/agent_3/config.json` (ne pas modifier)
- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_3.md` (v1.6) — elles priment en cas de doute.

## 2. Transition (ancien rôle → nouveau rôle)
- Ancien rôle : Équipe 1 · Partie 2 (LOT_218 → LOT_110). **Vous finissez le fichier en cours sous l'ancien rôle, puis vous passez au nouveau rôle et à la nouvelle plage.**
- Relevé local : LOT_218–214 sont complets : vous les sautez. Au LOT_213, la Partie 1 a été terminée par l'Agent 1 (16 h 59, ancien rôle) : vous la sautez dès qu'elle est sur Drive (si elle n'y est pas encore, vous rédigez d'abord la Partie 2, puis vous revérifiez Drive). À partir du LOT_212, vous rédigez la Partie 1 puis la Partie 2.

## 3. Règle de saut
Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).

## 4. Liste exacte de vos fichiers (70 fichiers, dans cet ordre)
Dossier Drive parent « LOTS_Finaux avec statut » : `1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`. Le dossier `1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB` ne doit **jamais** être ouvert, listé ni lu.

| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |
|---|---|---|---|---|---|
| 1 | LOT_218 | Partie 1 | `LOT_218_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1kHPHThhhV_qDbxiBftCOuwQcfPp3mSxo` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 2 | LOT_218 | Partie 2 | `LOT_218_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1kHPHThhhV_qDbxiBftCOuwQcfPp3mSxo` | terminé localement par l'Agent 3 — vérifier Drive, sauter si déposé |
| 3 | LOT_217 | Partie 1 | `LOT_217_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1bEeJLCZmQEHyqiEnSQvT-z62jmkio_Mi` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 4 | LOT_217 | Partie 2 | `LOT_217_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1bEeJLCZmQEHyqiEnSQvT-z62jmkio_Mi` | terminé localement par l'Agent 3 — vérifier Drive, sauter si déposé |
| 5 | LOT_216 | Partie 1 | `LOT_216_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1cLlaj39EOMQw3zqDiigb9QNQdI90YTk-` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 6 | LOT_216 | Partie 2 | `LOT_216_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1cLlaj39EOMQw3zqDiigb9QNQdI90YTk-` | terminé localement par l'Agent 3 — vérifier Drive, sauter si déposé |
| 7 | LOT_215 | Partie 1 | `LOT_215_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1ohcz2Puxd3exoAbk3jAwn5meYGwlJb9l` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 8 | LOT_215 | Partie 2 | `LOT_215_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1ohcz2Puxd3exoAbk3jAwn5meYGwlJb9l` | terminé localement par l'Agent 3 — vérifier Drive, sauter si déposé |
| 9 | LOT_214 | Partie 1 | `LOT_214_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1dQIdgiaVJnZRpqm_CjW8WxD0JkbF3zvW` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 10 | LOT_214 | Partie 2 | `LOT_214_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1dQIdgiaVJnZRpqm_CjW8WxD0JkbF3zvW` | terminé localement par l'Agent 3 — vérifier Drive, sauter si déposé |
| 11 | LOT_213 | Partie 1 | `LOT_213_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1dOFE-MKyp_F8VU-bbh4CCCqgjLeXDM1Y` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 12 | LOT_213 | Partie 2 | `LOT_213_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1dOFE-MKyp_F8VU-bbh4CCCqgjLeXDM1Y` | terminé localement par l'Agent 3 — vérifier Drive, sauter si déposé |
| 13 | LOT_212 | Partie 1 | `LOT_212_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1GUuXmSG0DsP1bcP_FQ30sBURlnQeSEuT` | à faire |
| 14 | LOT_212 | Partie 2 | `LOT_212_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1GUuXmSG0DsP1bcP_FQ30sBURlnQeSEuT` | à faire |
| 15 | LOT_211 | Partie 1 | `LOT_211_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1jbs4hOW-I_KgpxD7ZO0EAZ6sw9f6jxrt` | à faire |
| 16 | LOT_211 | Partie 2 | `LOT_211_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1jbs4hOW-I_KgpxD7ZO0EAZ6sw9f6jxrt` | à faire |
| 17 | LOT_210 | Partie 1 | `LOT_210_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1eCAnfTbDMtrghWtk1e39EJF4xsWgsMvX` | à faire |
| 18 | LOT_210 | Partie 2 | `LOT_210_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1eCAnfTbDMtrghWtk1e39EJF4xsWgsMvX` | à faire |
| 19 | LOT_209 | Partie 1 | `LOT_209_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `18iNBECddwje0E7-gAuoLHAebIWrvKnXd` | à faire |
| 20 | LOT_209 | Partie 2 | `LOT_209_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `18iNBECddwje0E7-gAuoLHAebIWrvKnXd` | à faire |
| 21 | LOT_208 | Partie 1 | `LOT_208_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1n1-mD1_7uHaFgxN_O7eGR282PtP1kw2F` | à faire |
| 22 | LOT_208 | Partie 2 | `LOT_208_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1n1-mD1_7uHaFgxN_O7eGR282PtP1kw2F` | à faire |
| 23 | LOT_207 | Partie 1 | `LOT_207_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1Afip48FG0_aMBhcP8POgi-kd5mjeEY3z` | à faire |
| 24 | LOT_207 | Partie 2 | `LOT_207_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1Afip48FG0_aMBhcP8POgi-kd5mjeEY3z` | à faire |
| 25 | LOT_206 | Partie 1 | `LOT_206_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1cFghlm99QKjHT3t7UIVQecXgsgwdn2QR` | à faire |
| 26 | LOT_206 | Partie 2 | `LOT_206_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1cFghlm99QKjHT3t7UIVQecXgsgwdn2QR` | à faire |
| 27 | LOT_205 | Partie 1 | `LOT_205_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1HIedxEhJ4unChycITH9JRDfBLfwGVvb0` | à faire |
| 28 | LOT_205 | Partie 2 | `LOT_205_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1HIedxEhJ4unChycITH9JRDfBLfwGVvb0` | à faire |
| 29 | LOT_204 | Partie 1 | `LOT_204_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `11PBbTNjDANtMP9dLKT1UY7WvBl5gpY0h` | à faire |
| 30 | LOT_204 | Partie 2 | `LOT_204_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `11PBbTNjDANtMP9dLKT1UY7WvBl5gpY0h` | à faire |
| 31 | LOT_203 | Partie 1 | `LOT_203_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1BDDEGa89Z9UdkR6SkOi0M1IGflLXBDgC` | à faire |
| 32 | LOT_203 | Partie 2 | `LOT_203_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1BDDEGa89Z9UdkR6SkOi0M1IGflLXBDgC` | à faire |
| 33 | LOT_202 | Partie 1 | `LOT_202_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1t_7CTyuXVnK3LaKaRpPpqiHAEUMqPu0t` | à faire |
| 34 | LOT_202 | Partie 2 | `LOT_202_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1t_7CTyuXVnK3LaKaRpPpqiHAEUMqPu0t` | à faire |
| 35 | LOT_201 | Partie 1 | `LOT_201_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1Y9yCPesHKpNEvwFG4Rgt_LqZHKs6dfH7` | à faire |
| 36 | LOT_201 | Partie 2 | `LOT_201_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1Y9yCPesHKpNEvwFG4Rgt_LqZHKs6dfH7` | à faire |
| 37 | LOT_200 | Partie 1 | `LOT_200_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `11IS3GRQwsOy-i9vGINL3124sX0uW04Cs` | à faire |
| 38 | LOT_200 | Partie 2 | `LOT_200_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `11IS3GRQwsOy-i9vGINL3124sX0uW04Cs` | à faire |
| 39 | LOT_199 | Partie 1 | `LOT_199_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1clPIfFIQu9txdacWCdS8pqBn6C9Ghqmr` | à faire |
| 40 | LOT_199 | Partie 2 | `LOT_199_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1clPIfFIQu9txdacWCdS8pqBn6C9Ghqmr` | à faire |
| 41 | LOT_198 | Partie 1 | `LOT_198_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1qQy2WU3Y76FrKzKH6iuuGTRomWiPUpYY` | à faire |
| 42 | LOT_198 | Partie 2 | `LOT_198_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1qQy2WU3Y76FrKzKH6iuuGTRomWiPUpYY` | à faire |
| 43 | LOT_197 | Partie 1 | `LOT_197_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1_klcRmfOR-wJ0cGZEIk04S59EUucd5h-` | à faire |
| 44 | LOT_197 | Partie 2 | `LOT_197_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1_klcRmfOR-wJ0cGZEIk04S59EUucd5h-` | à faire |
| 45 | LOT_196 | Partie 1 | `LOT_196_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1JHOxngkvw5B262OCV0zdiEnjx-002vwy` | à faire |
| 46 | LOT_196 | Partie 2 | `LOT_196_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1JHOxngkvw5B262OCV0zdiEnjx-002vwy` | à faire |
| 47 | LOT_195 | Partie 1 | `LOT_195_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1eKWXApLn6s7AQxahuL_cHi0kslpr_pQT` | à faire |
| 48 | LOT_195 | Partie 2 | `LOT_195_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1eKWXApLn6s7AQxahuL_cHi0kslpr_pQT` | à faire |
| 49 | LOT_194 | Partie 1 | `LOT_194_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1BltDDDSP6rK6y4qAjdPdjgBCUX1cChHB` | à faire |
| 50 | LOT_194 | Partie 2 | `LOT_194_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1BltDDDSP6rK6y4qAjdPdjgBCUX1cChHB` | à faire |
| 51 | LOT_193 | Partie 1 | `LOT_193_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1fsfgglp1qRgy_v1MtpF4NQ08i6oVmnRw` | à faire |
| 52 | LOT_193 | Partie 2 | `LOT_193_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1fsfgglp1qRgy_v1MtpF4NQ08i6oVmnRw` | à faire |
| 53 | LOT_192 | Partie 1 | `LOT_192_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `16dcncbo7Xbi82WhDv_7FPQEAdPkG5L8O` | à faire |
| 54 | LOT_192 | Partie 2 | `LOT_192_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `16dcncbo7Xbi82WhDv_7FPQEAdPkG5L8O` | à faire |
| 55 | LOT_191 | Partie 1 | `LOT_191_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1S18Oj3rsYeMNlM7ZA7d3xwA0JEzz72mp` | à faire |
| 56 | LOT_191 | Partie 2 | `LOT_191_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1S18Oj3rsYeMNlM7ZA7d3xwA0JEzz72mp` | à faire |
| 57 | LOT_190 | Partie 1 | `LOT_190_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1vAj-e79W8N83bLVbSClhllcwhGhL3o7s` | à faire |
| 58 | LOT_190 | Partie 2 | `LOT_190_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1vAj-e79W8N83bLVbSClhllcwhGhL3o7s` | à faire |
| 59 | LOT_189 | Partie 1 | `LOT_189_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1DA8WDTzgbA3sSysQYAmLY-5jqCi6HxZV` | à faire |
| 60 | LOT_189 | Partie 2 | `LOT_189_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1DA8WDTzgbA3sSysQYAmLY-5jqCi6HxZV` | à faire |
| 61 | LOT_188 | Partie 1 | `LOT_188_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1K-HiXU71SYcMz2BhcsZW04rFOrb_ZNiU` | à faire |
| 62 | LOT_188 | Partie 2 | `LOT_188_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1K-HiXU71SYcMz2BhcsZW04rFOrb_ZNiU` | à faire |
| 63 | LOT_187 | Partie 1 | `LOT_187_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1U3fkmOmOlHzF4h75pqvTuNq4FdkB4YnH` | à faire |
| 64 | LOT_187 | Partie 2 | `LOT_187_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1U3fkmOmOlHzF4h75pqvTuNq4FdkB4YnH` | à faire |
| 65 | LOT_186 | Partie 1 | `LOT_186_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1TBjBS_khP7f36r6f_cR1tW7WhwhpxP5e` | à faire |
| 66 | LOT_186 | Partie 2 | `LOT_186_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1TBjBS_khP7f36r6f_cR1tW7WhwhpxP5e` | à faire |
| 67 | LOT_185 | Partie 1 | `LOT_185_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1w3kcq5BzYEwE-EjDADCR8n1zSzKoz2Dd` | à faire |
| 68 | LOT_185 | Partie 2 | `LOT_185_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1w3kcq5BzYEwE-EjDADCR8n1zSzKoz2Dd` | à faire |
| 69 | LOT_184 | Partie 1 | `LOT_184_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1RvAms-grbfUTgV6xhJRdaVDo1jOzau6Y` | à faire |
| 70 | LOT_184 | Partie 2 | `LOT_184_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1RvAms-grbfUTgV6xhJRdaVDo1jOzau6Y` | à faire |

Nom de dépôt sur Drive : « Agent_3 | LOT_X Partie 1 — <noms des différentiels>.html » ; « Agent_3 | LOT_X Partie 2 — <noms des différentiels>.html » (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.

## 5. Commandes (dans cet ordre, pour chaque fichier)
```
python3 /workspace/scripts_lots/equipes/S1B.py --agent 3 plan "<thème du LOT>" --dx "<DX de la Partie>"
python3 /workspace/scripts_lots/agent_3/script_source.py search "<requête>" --pec      # index local d'abord
python3 /workspace/scripts_lots/agent_3/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »
# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste
python3 /workspace/scripts_lots/equipes/S1B.py --agent 3 check /workspace/agent3/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/equipes/S2B.py --agent 3 review /workspace/agent3/LOT_X/<fichier>.html --appel-a <Appel A du LOT>.html   # doit renvoyer 0
python3 /workspace/scripts_lots/agent_3/script_source.py check /workspace/agent3/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/agent_3/script_synchrone.py review /workspace/agent3/LOT_X/<fichier>.html     # un seul passage LanguageTool
grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0
```
Raccourcis : `python3 /workspace/scripts_lots/agent_3/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.

## 6. Charte (rappel)
`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.

## 7. Skills
- `skills/performance-redaction-lot/SKILL.md` (→ `/workspace/reorg/skills/performance-redaction-lot/SKILL.md`)
- `skills/concentration-fil-redaction/SKILL.md` (→ `/workspace/reorg/skills/concentration-fil-redaction/SKILL.md`)
- `skills/anti-gaspillage-redaction/SKILL.md` (→ `/workspace/reorg/skills/anti-gaspillage-redaction/SKILL.md`)
- `skills/harness-redacteur-v7/SKILL.md` (→ `/workspace/reorg/skills/harness-redacteur-v7/SKILL.md`)

## 8. Après chaque dépôt
Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.
Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.

FIN_DEMARRER
