#!/usr/bin/env python3
"""construire_equipes.py — v1.6 (2026-10-24) : construit /workspace/equipes/agent_N/ (N = 1..18) et agent_N.zip.
Contenu : DEMARRER.md (point d'entrée unique), config.json (copie de scripts_lots/agent_N/config.json), ETAT.md (fil),
skills/ (liens vers /workspace/reorg/skills/<slug>). Aucune requête Drive : l'état provient de etat_jauge.json (local).
ETAT.md n'est jamais écrasé s'il existe déjà (il appartient à l'agent)."""
import json, os, shutil, sys, zipfile
from pathlib import Path
sys.path.insert(0, "/workspace/instructions_agents"); sys.path.insert(0, "/workspace/scripts_lots")
import generer_instructions as I, generer_configs as G

ICI = Path(__file__).resolve().parent
SKILLS = Path("/workspace/reorg/skills")
SLUGS = ["performance-redaction-lot", "concentration-fil-redaction", "anti-gaspillage-redaction", "harness-redacteur-v7"]
IDS = json.load(open("/workspace/ids.json"))
ETAT = json.load(open(ICI / "etat_jauge.json"))["fichiers"]
PNOM = {"A": "Appel A", "P1": "Partie 1", "P2": "Partie 2", "P3": "Partie 3", "P4": "Partie 4"}

def statut(lot, p, n=None):
    e = ETAT.get(f"LOT_{lot:03d}:{p}")
    autres = [m for m, t in G.TRANSITION.items() if m != n and p in t.get(lot, [])]
    if not e and autres: return f"en cours chez l'Agent {autres[0]} (transition) — vérifier Drive, sauter si déposé"
    if not e: return "à faire"
    return f"terminé localement par l'Agent {e['agent_auteur']} — vérifier Drive, sauter si déposé"

def demarrer(n):
    eq, role, h, b = G.ORGANISATION[n]; membres = G.EQUIPES[eq][2]; ps = G.ROLES[role][1]; t = G.ROLE_TYPE[role]
    cfg = f"/workspace/scripts_lots/agent_{n}/config.json"
    trans = G.TRANSITION.get(n, {})
    L = []; w = L.append
    w(f"# DÉMARRER — {I.nom_agent(n)}\n")
    w("> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. "
      f"Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `{I.TUNDER}`), en une ligne : `BLOCAGE · Agent {n} · LOT_X : <motif ≤ 8 mots>`. "
      f"Le non-bloquant va dans `/workspace/agent{n}/POUR_TUNDER_AGENT_{n}.md`.\n")
    w("## 1. Identité")
    w(f"- **Nom** : {I.nom_agent(n)}")
    w(f"- **Équipe {eq}** : {I.L(h)} → {I.L(b)} ({h - b + 1} LOT, ordre décroissant) — " + ", ".join(f"{r} = Agent {m}" + (" (vous)" if m == n else "") for r, m in membres.items()))
    w(f"- **Rôle {role}** : {I.ROLES[role][1]}.")
    w(f"- **Dossier de travail** : `/workspace/agent{n}/LOT_X/` · **fil** : `/workspace/equipes/agent_{n}/ETAT.md` · **config** : `{cfg}` (ne pas modifier)")
    w(f"- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_{n}.md` (v1.6) — elles priment en cas de doute.\n")
    if n in I.ANCIEN:
        w("## 2. Transition (ancien rôle → nouveau rôle)")
        w(f"- Ancien rôle : {I.ANCIEN[n][0]} ({I.ANCIEN[n][1]}). **Vous finissez le fichier en cours sous l'ancien rôle, puis vous passez au nouveau rôle et à la nouvelle plage.**")
        for lot, pp in trans.items():
            w(f"- Fichier de transition accepté par vos scripts : {I.L(lot)} " + " + ".join(PNOM[p] for p in pp) + " → le finir, le contrôler, le déposer s'il n'est pas déjà sur Drive.")
        if n in I.NOTES: w(f"- Relevé local : {I.NOTES[n]}")
        w("")
    elif n in I.NOTES:
        w("## 2. Reprise"); w(f"- {I.NOTES[n]}\n")
    else:
        w("## 2. Reprise"); w("- Nouvel agent : vous commencez au premier LOT de votre plage (règle de saut appliquée).\n")
    w("## 3. Règle de saut")
    w("Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. "
      "Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).\n")
    if eq == 6:
        w("**Équipe 6 — LOT_008 et LOT_007** : ces deux LOT ont été largement rédigés par l'ancienne équipe 2 (Agents 2, 4, 6, 8), dont une partie en transition jusqu'à 17 h. "
          "Vous **sautez tout fichier LOT_007/LOT_008 déjà déposé sur Drive**, quel que soit l'agent qui l'a déposé ; vous ne rédigez un fichier de ces deux LOT que s'il est absent de Drive au moment où vous y arrivez (en fin de série).\n")
    nb = len(ps) * (h - b + 1) + sum(len(v) for v in trans.values())
    w(f"## 4. Liste exacte de vos fichiers ({nb} fichiers, dans cet ordre)")
    w(f"Dossier Drive parent « LOTS_Finaux avec statut » : `{I.DRIVE}`. Le dossier `{I.INTERDIT}` ne doit **jamais** être ouvert, listé ni lu.\n")
    w("| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |")
    w("|---|---|---|---|---|---|")
    k = 0
    hors = [x for x in trans if x not in range(b, h + 1)]          # transition hors plage (Agent 2 : LOT_007) : d'abord
    for lot in hors + list(range(h, b - 1, -1)):
        pp = trans[lot] if lot in hors else sorted(set(ps) | set(trans.get(lot, [])), key=G.TOUT.index)
        for p in pp:
            k += 1
            nomloc = I.NOMS[p].replace("LOT_X", I.L(lot))
            tag = " (transition)" if p in trans.get(lot, []) else ""
            w(f"| {k} | {I.L(lot)} | {PNOM[p]}{tag} | `{nomloc}` | `{IDS.get(str(lot), 'à créer « LOT_%03d »' % lot)}` | {statut(lot, p, n)} |")
    w("\nNom de dépôt sur Drive : " + " ; ".join(f"« {I.DRIVE_NOMS[p].format(n=n)} »" for p in ps) + " (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.\n")
    w("## 5. Commandes (dans cet ordre, pour chaque fichier)")
    w("```")
    w(f"python3 /workspace/scripts_lots/equipes/S1{t}.py --agent {n} plan \"<thème du LOT>\"" + ("" if t == "A" else " --dx \"<DX de la Partie>\""))
    w(f"python3 /workspace/scripts_lots/agent_{n}/script_source.py search \"<requête>\" --pec      # index local d'abord")
    w(f"python3 /workspace/scripts_lots/agent_{n}/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »")
    w("# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste")
    w(f"python3 /workspace/scripts_lots/equipes/S1{t}.py --agent {n} check /workspace/agent{n}/LOT_X/<fichier>.html        # doit renvoyer 0")
    w(f"python3 /workspace/scripts_lots/equipes/S2{t}.py --agent {n} review /workspace/agent{n}/LOT_X/<fichier>.html" + ("" if t == "A" else " --appel-a <Appel A du LOT>.html") + "   # doit renvoyer 0")
    w(f"python3 /workspace/scripts_lots/agent_{n}/script_source.py check /workspace/agent{n}/LOT_X/<fichier>.html        # doit renvoyer 0")
    w(f"python3 /workspace/scripts_lots/agent_{n}/script_synchrone.py review /workspace/agent{n}/LOT_X/<fichier>.html     # un seul passage LanguageTool")
    w("grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0")
    w("```")
    w(f"Raccourcis : `python3 /workspace/scripts_lots/agent_{n}/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. "
      "S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.\n")
    w("## 6. Charte (rappel)")
    w("`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : "
      "#edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · "
      "Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.\n")
    w("## 7. Skills")
    for s in SLUGS: w(f"- `skills/{s}/SKILL.md` (→ `/workspace/reorg/skills/{s}/SKILL.md`)")
    w("\n## 8. Après chaque dépôt")
    w("Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.")
    w(f"Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.\n")
    w("FIN_DEMARRER")
    return "\n".join(L) + "\n"

def etat_initial(n):
    eq, role, h, b = G.ORGANISATION[n]
    trans = G.TRANSITION.get(n, {})
    if trans:
        lot, pp = next(iter(trans.items()))
        enc = f"{I.L(lot)} · {' + '.join(PNOM[p] for p in pp)} · transition (ancien rôle) · étape : contrôles S1/S2 puis dépôt si absent de Drive"
    else:
        enc = f"{I.L(h)} · {PNOM[G.ROLES[role][1][0]]} · étape : règle de saut (Drive) puis sourçage"
    return (f"# ETAT — Agent {n} (fil de rédaction, écrit par l'Agent {n} seul)\n\n## En cours\n{enc}\n"
            "Prochaine action : appliquer la règle de saut, puis S1 plan.\n\n## Journal (une ligne par fichier, le plus récent en haut)\n"
            "2026-10-24 17:05 · état initial v1.6 créé (aucun fichier traité sous le nouveau rôle)\n")

def main():
    for n in sorted(G.ORGANISATION):
        d = ICI / f"agent_{n}"; d.mkdir(exist_ok=True)
        (d / "DEMARRER.md").write_text(demarrer(n), "utf-8")
        shutil.copy2(f"/workspace/scripts_lots/agent_{n}/config.json", d / "config.json")
        if not (d / "ETAT.md").exists(): (d / "ETAT.md").write_text(etat_initial(n), "utf-8")
        sk = d / "skills"; sk.mkdir(exist_ok=True)
        for s in SLUGS:
            l = sk / s
            if l.is_symlink() or l.exists(): l.unlink()
            l.symlink_to(SKILLS / s)
        z = ICI / f"agent_{n}.zip"
        with zipfile.ZipFile(z, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in ["DEMARRER.md", "config.json", "ETAT.md"]: zf.write(d / f, f"agent_{n}/{f}")
            for s in SLUGS: zf.write(SKILLS / s / "SKILL.md", f"agent_{n}/skills/{s}/SKILL.md")
        print(f"agent_{n} : DEMARRER {len((d / 'DEMARRER.md').read_text('utf-8'))} car., zip {z.stat().st_size} o")

if __name__ == "__main__" and "--equipes" not in sys.argv:
    main()

def equipes_md():
    """EQUIPES_V1.6.md : organisation, membres, LOT par LOT, état local, jauges (zone JAUGE remplie par jauge.py --maj)."""
    w = []; a = w.append
    a("# DISPOSITIF DES ÉQUIPES — v1.6 (2026-10-24, 16 h 42 · compléments 16 h 49)\n")
    a("Projet Organigramme_Examen_Fédéral · coordination : Tunder · 18 agents de rédaction en 6 équipes de 3 · LOT_218 → LOT_007, ordre décroissant. "
      "LOT_219–248 hors périmètre ; LOT_001–006 audités par Tunder.\n")
    a("## 1. Équipes et membres\n")
    a("| Équipe | Plage | LOT | Rôle A — Appel A | Rôle B1 — Parties 1–2 (DX.1–5) | Rôle B2 — Parties 3–4 (DX.6–10) | Fichiers attendus |")
    a("|---|---|---|---|---|---|---|")
    for eq, (h, b, m) in G.EQUIPES.items():
        a(f"| {eq} | {I.L(h)} → {I.L(b)} | {h - b + 1} | {I.nom_agent(m['A'])} | {I.nom_agent(m['B1'])} | {I.nom_agent(m['B2'])} | {5 * (h - b + 1)} |")
    a("\n## 2. Règles communes\n")
    a("- **Silence total** : aucun message à l'utilisateur ; aucun signal de dépôt ; seul un vrai blocage va à Tunder (une ligne, `SendToAgent`).")
    a("- **Règle de saut** : chaque agent saute tout LOT dont son fichier est déjà déposé sur Drive.")
    a("- **Transition (Agents 1–8)** : le fichier en cours sous l'ancien rôle est fini, puis l'agent passe au nouveau rôle. Fichiers de transition acceptés par les scripts : "
      + "; ".join(f"Agent {n} → {I.L(x)} " + " + ".join(PNOM[p] for p in pp) for n, t in G.TRANSITION.items() for x, pp in t.items()) + ".")
    a("- **Portes de dépôt** : S1A/S1B `check` = 0, S2A/S2B `review` = 0, `script_source.py check` = 0 (scripts en lecture seule, alertes seulement).")
    a("- **Charte V7+** : `.proba{color:#C8102E;font-weight:700}` sans halo ; bleu ciel à la place des 7 verts ; Atkinson Hyperlegible ; WCAG ≥ 4,5 ; fenêtres d'examen à onglets Principe / Interprétation.")
    a("- Point d'entrée de chaque agent : `/workspace/equipes/agent_N/DEMARRER.md` ; fil : `/workspace/equipes/agent_N/ETAT.md`.\n")
    a("## 3. Progression (jauges)\n")
    a("<!-- JAUGE:DEBUT -->\n_(zone remplie par `python3 /workspace/equipes/jauge.py --maj /workspace/equipes/EQUIPES_V1.6.md`)_\n<!-- JAUGE:FIN -->\n")
    a("## 4. LOT par LOT — Parties et état\n")
    a("Légende : ✔ = terminé localement (auteur entre parenthèses ; **produit ≠ déposé**, Drive non vérifié) · ○ = à faire. Agent responsable v1.6 indiqué dans l'en-tête de chaque équipe.\n")
    for eq, (h, b, m) in G.EQUIPES.items():
        a(f"### Équipe {eq} — {I.L(h)} → {I.L(b)} · A = Agent {m['A']} · P1–P2 = Agent {m['B1']} · P3–P4 = Agent {m['B2']}\n")
        a("| LOT | Appel A | Partie 1 | Partie 2 | Partie 3 | Partie 4 | Fichiers faits |"); a("|---|---|---|---|---|---|---|")
        for lot in range(h, b - 1, -1):
            cells = []; k = 0
            for p in G.TOUT:
                e = ETAT.get(f"LOT_{lot:03d}:{p}")
                if e: k += 1; cells.append(f"✔ ({e['agent_auteur']})")
                else: cells.append("○")
            a(f"| {I.L(lot)} | " + " | ".join(cells) + f" | {k}/5 |")
        a("")
    a("## 5. Fichiers du dispositif\n")
    a("- Configurations : `/workspace/scripts_lots/agent_N/config.json` (générées par `generer_configs.py`).")
    a("- Scripts d'équipe : `/workspace/scripts_lots/equipes/S1A.py`, `S1B.py`, `S2A.py`, `S2B.py`.")
    a("- Instructions : `/workspace/instructions_agents/instructions_agent_N.md` (v1.6).")
    a("- Environnements : `/workspace/equipes/agent_N/` et `agent_N.zip` ; skills : `/workspace/reorg/skills/`.")
    a("- Jauge : `/workspace/equipes/jauge.py` (local par défaut ; `--drive LISTE.json` pour un relevé Drive fourni par Tunder).")
    (ICI / "EQUIPES_V1.6.md").write_text("\n".join(w) + "\n", "utf-8")

if __name__ == "__main__" and "--equipes" in sys.argv:
    equipes_md()
