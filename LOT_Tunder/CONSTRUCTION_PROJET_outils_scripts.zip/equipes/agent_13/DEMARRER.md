# DÉMARRER — Agent 13 — Équipe 3 · Appel B Parties 3–4 (LOT_148–114)

> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `db322130-de1f-49d9-a669-bd9b54729c37`), en une ligne : `BLOCAGE · Agent 13 · LOT_X : <motif ≤ 8 mots>`. Le non-bloquant va dans `/workspace/agent13/POUR_TUNDER_AGENT_13.md`.

## 1. Identité
- **Nom** : Agent 13 — Équipe 3 · Appel B Parties 3–4 (LOT_148–114)
- **Équipe 3** : LOT_148 → LOT_114 (35 LOT, ordre décroissant) — A = Agent 11, B1 = Agent 12, B2 = Agent 13 (vous)
- **Rôle B2** : l'Appel B Partie 3 (DX.6 à DX.7) puis l'Appel B Partie 4 (DX.8 à DX.10) — deux fichiers distincts par LOT.
- **Dossier de travail** : `/workspace/agent13/LOT_X/` · **fil** : `/workspace/equipes/agent_13/ETAT.md` · **config** : `/workspace/scripts_lots/agent_13/config.json` (ne pas modifier)
- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_13.md` (v1.6) — elles priment en cas de doute.

## 2. Reprise
- Nouvel agent : vous commencez au premier LOT de votre plage (règle de saut appliquée).

## 3. Règle de saut
Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).

## 4. Liste exacte de vos fichiers (70 fichiers, dans cet ordre)
Dossier Drive parent « LOTS_Finaux avec statut » : `1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`. Le dossier `1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB` ne doit **jamais** être ouvert, listé ni lu.

| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |
|---|---|---|---|---|---|
| 1 | LOT_148 | Partie 3 | `LOT_148_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `11fTrxs_dGUDxBo0bYzPN84CwNrZltvrR` | à faire |
| 2 | LOT_148 | Partie 4 | `LOT_148_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `11fTrxs_dGUDxBo0bYzPN84CwNrZltvrR` | à faire |
| 3 | LOT_147 | Partie 3 | `LOT_147_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1_5PL9uqqGcfa4z0LJAt3cNHqWxIjAOpM` | à faire |
| 4 | LOT_147 | Partie 4 | `LOT_147_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1_5PL9uqqGcfa4z0LJAt3cNHqWxIjAOpM` | à faire |
| 5 | LOT_146 | Partie 3 | `LOT_146_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1wZ8tit8Ghh4rOcXwoQXUfLFMyGiza-vf` | à faire |
| 6 | LOT_146 | Partie 4 | `LOT_146_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1wZ8tit8Ghh4rOcXwoQXUfLFMyGiza-vf` | à faire |
| 7 | LOT_145 | Partie 3 | `LOT_145_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1N_Dwmwfca0dopxnmQf97z079nVl5L_AZ` | à faire |
| 8 | LOT_145 | Partie 4 | `LOT_145_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1N_Dwmwfca0dopxnmQf97z079nVl5L_AZ` | à faire |
| 9 | LOT_144 | Partie 3 | `LOT_144_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1WTSc_enVi92VzR_u5-W6pfzfW0pqKY1M` | à faire |
| 10 | LOT_144 | Partie 4 | `LOT_144_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1WTSc_enVi92VzR_u5-W6pfzfW0pqKY1M` | à faire |
| 11 | LOT_143 | Partie 3 | `LOT_143_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `16N4_MbzBvUjeF1eaGsnefnoT9XZ76rAS` | à faire |
| 12 | LOT_143 | Partie 4 | `LOT_143_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `16N4_MbzBvUjeF1eaGsnefnoT9XZ76rAS` | à faire |
| 13 | LOT_142 | Partie 3 | `LOT_142_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1h4uD4jr0Pu5idZiKI9gVqVK6k0dp4yyS` | à faire |
| 14 | LOT_142 | Partie 4 | `LOT_142_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1h4uD4jr0Pu5idZiKI9gVqVK6k0dp4yyS` | à faire |
| 15 | LOT_141 | Partie 3 | `LOT_141_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1hsICILF2IpMDPR2eZKncG9fxOMExuA0j` | à faire |
| 16 | LOT_141 | Partie 4 | `LOT_141_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1hsICILF2IpMDPR2eZKncG9fxOMExuA0j` | à faire |
| 17 | LOT_140 | Partie 3 | `LOT_140_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1eK13uigBSQeW4nNyP7BrAwTfM4nAuQk9` | à faire |
| 18 | LOT_140 | Partie 4 | `LOT_140_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1eK13uigBSQeW4nNyP7BrAwTfM4nAuQk9` | à faire |
| 19 | LOT_139 | Partie 3 | `LOT_139_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `11cFpgoc1Pea3xovzHb-pHynh62NUyOu5` | à faire |
| 20 | LOT_139 | Partie 4 | `LOT_139_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `11cFpgoc1Pea3xovzHb-pHynh62NUyOu5` | à faire |
| 21 | LOT_138 | Partie 3 | `LOT_138_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `182WscKZGQQOV1TzXGl_IGgzJu0FsPtmW` | à faire |
| 22 | LOT_138 | Partie 4 | `LOT_138_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `182WscKZGQQOV1TzXGl_IGgzJu0FsPtmW` | à faire |
| 23 | LOT_137 | Partie 3 | `LOT_137_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1OVF1QTeXRRtuglBc98tMS95Wp2EfiYdu` | à faire |
| 24 | LOT_137 | Partie 4 | `LOT_137_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1OVF1QTeXRRtuglBc98tMS95Wp2EfiYdu` | à faire |
| 25 | LOT_136 | Partie 3 | `LOT_136_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1o8hoxx88sxAYqrDyd6lFe3315hrtBd1i` | à faire |
| 26 | LOT_136 | Partie 4 | `LOT_136_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1o8hoxx88sxAYqrDyd6lFe3315hrtBd1i` | à faire |
| 27 | LOT_135 | Partie 3 | `LOT_135_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `16Q95mIsh_zzpLuJgzwp4BC9y61RDvpne` | à faire |
| 28 | LOT_135 | Partie 4 | `LOT_135_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `16Q95mIsh_zzpLuJgzwp4BC9y61RDvpne` | à faire |
| 29 | LOT_134 | Partie 3 | `LOT_134_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1qH4UNyKDsGzT-53uETY8hbCWqBlNn0v4` | à faire |
| 30 | LOT_134 | Partie 4 | `LOT_134_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1qH4UNyKDsGzT-53uETY8hbCWqBlNn0v4` | à faire |
| 31 | LOT_133 | Partie 3 | `LOT_133_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1U6Twr9Dy1cQJ9IGcKHpz6AQpjNCEWpxb` | à faire |
| 32 | LOT_133 | Partie 4 | `LOT_133_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1U6Twr9Dy1cQJ9IGcKHpz6AQpjNCEWpxb` | à faire |
| 33 | LOT_132 | Partie 3 | `LOT_132_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1-O6jVppntWQOfTqPtFT2KsqROwSlCb-U` | à faire |
| 34 | LOT_132 | Partie 4 | `LOT_132_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1-O6jVppntWQOfTqPtFT2KsqROwSlCb-U` | à faire |
| 35 | LOT_131 | Partie 3 | `LOT_131_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1t_QptwVQDxIU-M_3O8EODJvUvdUQOJR0` | à faire |
| 36 | LOT_131 | Partie 4 | `LOT_131_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1t_QptwVQDxIU-M_3O8EODJvUvdUQOJR0` | à faire |
| 37 | LOT_130 | Partie 3 | `LOT_130_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1VJA6khOEE15zbJ3CD6QgwEpJCPKxa_-o` | à faire |
| 38 | LOT_130 | Partie 4 | `LOT_130_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1VJA6khOEE15zbJ3CD6QgwEpJCPKxa_-o` | à faire |
| 39 | LOT_129 | Partie 3 | `LOT_129_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1WkW8TXcv4hpA5sGHk6v_VseVz47pLgQD` | à faire |
| 40 | LOT_129 | Partie 4 | `LOT_129_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1WkW8TXcv4hpA5sGHk6v_VseVz47pLgQD` | à faire |
| 41 | LOT_128 | Partie 3 | `LOT_128_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1HFeqZ_-mpu2WFmMzp4tRJO7AxaVQhljs` | à faire |
| 42 | LOT_128 | Partie 4 | `LOT_128_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1HFeqZ_-mpu2WFmMzp4tRJO7AxaVQhljs` | à faire |
| 43 | LOT_127 | Partie 3 | `LOT_127_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1k1fBd6XC3FLv9qUG5jIShXVLajdDb-t5` | à faire |
| 44 | LOT_127 | Partie 4 | `LOT_127_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1k1fBd6XC3FLv9qUG5jIShXVLajdDb-t5` | à faire |
| 45 | LOT_126 | Partie 3 | `LOT_126_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1WVwYjgyq4t09_wuUP7GEo-KPp2gZ6-Dj` | à faire |
| 46 | LOT_126 | Partie 4 | `LOT_126_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1WVwYjgyq4t09_wuUP7GEo-KPp2gZ6-Dj` | à faire |
| 47 | LOT_125 | Partie 3 | `LOT_125_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1rY0AHLHQGQl7seC0whTBLv-e0l2dDmAN` | à faire |
| 48 | LOT_125 | Partie 4 | `LOT_125_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1rY0AHLHQGQl7seC0whTBLv-e0l2dDmAN` | à faire |
| 49 | LOT_124 | Partie 3 | `LOT_124_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1lre8ePoGYO6_TfoNmd5VI49-v29A18wr` | à faire |
| 50 | LOT_124 | Partie 4 | `LOT_124_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1lre8ePoGYO6_TfoNmd5VI49-v29A18wr` | à faire |
| 51 | LOT_123 | Partie 3 | `LOT_123_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1cJxX5Ax5HlvZgP_owpB6n-6BXf1q2Ew6` | à faire |
| 52 | LOT_123 | Partie 4 | `LOT_123_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1cJxX5Ax5HlvZgP_owpB6n-6BXf1q2Ew6` | à faire |
| 53 | LOT_122 | Partie 3 | `LOT_122_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1bAqYcrRYBupz_VEPD_Xd6FWezv4j2JPQ` | à faire |
| 54 | LOT_122 | Partie 4 | `LOT_122_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1bAqYcrRYBupz_VEPD_Xd6FWezv4j2JPQ` | à faire |
| 55 | LOT_121 | Partie 3 | `LOT_121_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1MPKNKuG2Wd69tNfcudkpjEMMv4hrY9oD` | à faire |
| 56 | LOT_121 | Partie 4 | `LOT_121_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1MPKNKuG2Wd69tNfcudkpjEMMv4hrY9oD` | à faire |
| 57 | LOT_120 | Partie 3 | `LOT_120_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1SaELYXZOrF3ih9V_6JU6TJJ2HW2hTJVy` | à faire |
| 58 | LOT_120 | Partie 4 | `LOT_120_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1SaELYXZOrF3ih9V_6JU6TJJ2HW2hTJVy` | à faire |
| 59 | LOT_119 | Partie 3 | `LOT_119_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1vjDrVd0ww59and18VzN39UBV3trqAhXC` | à faire |
| 60 | LOT_119 | Partie 4 | `LOT_119_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1vjDrVd0ww59and18VzN39UBV3trqAhXC` | à faire |
| 61 | LOT_118 | Partie 3 | `LOT_118_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1EcEyQbsaQ26rXoB8UUd_g9UrKyVphhEh` | à faire |
| 62 | LOT_118 | Partie 4 | `LOT_118_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1EcEyQbsaQ26rXoB8UUd_g9UrKyVphhEh` | à faire |
| 63 | LOT_117 | Partie 3 | `LOT_117_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `13DRo5vtVL4IcXqHTr_7PfE0j3oz6ZWjS` | à faire |
| 64 | LOT_117 | Partie 4 | `LOT_117_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `13DRo5vtVL4IcXqHTr_7PfE0j3oz6ZWjS` | à faire |
| 65 | LOT_116 | Partie 3 | `LOT_116_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1dqX1PCybEKidk9ZzuF_Tv71pz5EJpcIm` | à faire |
| 66 | LOT_116 | Partie 4 | `LOT_116_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1dqX1PCybEKidk9ZzuF_Tv71pz5EJpcIm` | à faire |
| 67 | LOT_115 | Partie 3 | `LOT_115_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1sMmtfpNHM1HgIDZFhMDCCUAOD2z2BUyA` | à faire |
| 68 | LOT_115 | Partie 4 | `LOT_115_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1sMmtfpNHM1HgIDZFhMDCCUAOD2z2BUyA` | à faire |
| 69 | LOT_114 | Partie 3 | `LOT_114_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | `1s_3Kz1aBFQi5cLpBwaEoNuY9nfL-vdSA` | à faire |
| 70 | LOT_114 | Partie 4 | `LOT_114_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | `1s_3Kz1aBFQi5cLpBwaEoNuY9nfL-vdSA` | à faire |

Nom de dépôt sur Drive : « Agent_13 | LOT_X Partie 3 — <noms des différentiels>.html » ; « Agent_13 | LOT_X Partie 4 — <noms des différentiels>.html » (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.

## 5. Commandes (dans cet ordre, pour chaque fichier)
```
python3 /workspace/scripts_lots/equipes/S1B.py --agent 13 plan "<thème du LOT>" --dx "<DX de la Partie>"
python3 /workspace/scripts_lots/agent_13/script_source.py search "<requête>" --pec      # index local d'abord
python3 /workspace/scripts_lots/agent_13/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »
# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste
python3 /workspace/scripts_lots/equipes/S1B.py --agent 13 check /workspace/agent13/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/equipes/S2B.py --agent 13 review /workspace/agent13/LOT_X/<fichier>.html --appel-a <Appel A du LOT>.html   # doit renvoyer 0
python3 /workspace/scripts_lots/agent_13/script_source.py check /workspace/agent13/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/agent_13/script_synchrone.py review /workspace/agent13/LOT_X/<fichier>.html     # un seul passage LanguageTool
grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0
```
Raccourcis : `python3 /workspace/scripts_lots/agent_13/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.

## 6. Charte (rappel)
`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.

## 7. Skills
- `skills/performance-redaction-lot/SKILL.md` (→ `/workspace/reorg/skills/performance-redaction-lot/SKILL.md`)
- `skills/concentration-fil-redaction/SKILL.md` (→ `/workspace/reorg/skills/concentration-fil-redaction/SKILL.md`)
- `skills/anti-gaspillage-redaction/SKILL.md` (→ `/workspace/reorg/skills/anti-gaspillage-redaction/SKILL.md`)
- `skills/harness-redacteur-v7/SKILL.md` (→ `/workspace/reorg/skills/harness-redacteur-v7/SKILL.md`)

## 8. Après chaque dépôt
Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.
Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.

FIN_DEMARRER
