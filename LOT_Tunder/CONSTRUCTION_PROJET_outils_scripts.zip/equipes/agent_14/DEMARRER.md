# DÉMARRER — Agent 14 — Équipe 5 · Appel A (LOT_078–043)

> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `db322130-de1f-49d9-a669-bd9b54729c37`), en une ligne : `BLOCAGE · Agent 14 · LOT_X : <motif ≤ 8 mots>`. Le non-bloquant va dans `/workspace/agent14/POUR_TUNDER_AGENT_14.md`.

## 1. Identité
- **Nom** : Agent 14 — Équipe 5 · Appel A (LOT_078–043)
- **Équipe 5** : LOT_078 → LOT_043 (36 LOT, ordre décroissant) — A = Agent 14 (vous), B1 = Agent 15, B2 = Agent 8
- **Rôle A** : l'Appel A (plan et liste des 10 DX) — un fichier par LOT.
- **Dossier de travail** : `/workspace/agent14/LOT_X/` · **fil** : `/workspace/equipes/agent_14/ETAT.md` · **config** : `/workspace/scripts_lots/agent_14/config.json` (ne pas modifier)
- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_14.md` (v1.6) — elles priment en cas de doute.

## 2. Reprise
- Nouvel agent : vous commencez au premier LOT de votre plage (règle de saut appliquée).

## 3. Règle de saut
Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).

## 4. Liste exacte de vos fichiers (36 fichiers, dans cet ordre)
Dossier Drive parent « LOTS_Finaux avec statut » : `1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`. Le dossier `1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB` ne doit **jamais** être ouvert, listé ni lu.

| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |
|---|---|---|---|---|---|
| 1 | LOT_078 | Appel A | `LOT_078_Appel_A_V7_Plan_et_Liste.html` | `1pBsQFCcMJVJz5oew5yoN-aTp8y-L3nPb` | à faire |
| 2 | LOT_077 | Appel A | `LOT_077_Appel_A_V7_Plan_et_Liste.html` | `1bNlyDTRlksiznLRROWcfoNtfwYAAks_a` | à faire |
| 3 | LOT_076 | Appel A | `LOT_076_Appel_A_V7_Plan_et_Liste.html` | `11bIgXnnOMbX16xpMofJ1oCyU-tQVEc1b` | à faire |
| 4 | LOT_075 | Appel A | `LOT_075_Appel_A_V7_Plan_et_Liste.html` | `1zsi9isxQuR1gEZCT1QHU1H-kWtwFDSBJ` | à faire |
| 5 | LOT_074 | Appel A | `LOT_074_Appel_A_V7_Plan_et_Liste.html` | `12aE2sEDBYa7Q48tI3UEFoPMi87tDsJvx` | à faire |
| 6 | LOT_073 | Appel A | `LOT_073_Appel_A_V7_Plan_et_Liste.html` | `13b3YrcbdTnvrUUPUctsjZzylpENupg0d` | à faire |
| 7 | LOT_072 | Appel A | `LOT_072_Appel_A_V7_Plan_et_Liste.html` | `1nxWpxMJ0Sn9u6xsUNHcl2-Cr6Cc-qITS` | à faire |
| 8 | LOT_071 | Appel A | `LOT_071_Appel_A_V7_Plan_et_Liste.html` | `1eBzOFKsbaGBKSLlubO_iOWAtRM7nOzid` | à faire |
| 9 | LOT_070 | Appel A | `LOT_070_Appel_A_V7_Plan_et_Liste.html` | `1_XPXuHcrjzHyojTX-dEY9_-PCP_EVYzI` | à faire |
| 10 | LOT_069 | Appel A | `LOT_069_Appel_A_V7_Plan_et_Liste.html` | `19iRN6OQ6YDOEhDKR5Y6PWQjORJbQD7Yk` | à faire |
| 11 | LOT_068 | Appel A | `LOT_068_Appel_A_V7_Plan_et_Liste.html` | `1mxLSaXEhrHHNYV5ERY2AhHd2Zxr7Rzgk` | à faire |
| 12 | LOT_067 | Appel A | `LOT_067_Appel_A_V7_Plan_et_Liste.html` | `11a9k9UfFozneyph47txvgHIZ3TxPHU4R` | à faire |
| 13 | LOT_066 | Appel A | `LOT_066_Appel_A_V7_Plan_et_Liste.html` | `1FsuXuE4qYmdp62R7UWfl9_W8OEvHcw0a` | à faire |
| 14 | LOT_065 | Appel A | `LOT_065_Appel_A_V7_Plan_et_Liste.html` | `1a5BdK7YxQsrFv7aGasANGn7fV8mMkX99` | à faire |
| 15 | LOT_064 | Appel A | `LOT_064_Appel_A_V7_Plan_et_Liste.html` | `1YlXKarX-eHTqQMM6OpR5bA6RLvjfJTCV` | à faire |
| 16 | LOT_063 | Appel A | `LOT_063_Appel_A_V7_Plan_et_Liste.html` | `1-KWp2UUkB-dVJAyPk1R_H-13Zd5IPwaQ` | à faire |
| 17 | LOT_062 | Appel A | `LOT_062_Appel_A_V7_Plan_et_Liste.html` | `18974FglU-6mypzzSOVdZHELk-m7PKi-6` | à faire |
| 18 | LOT_061 | Appel A | `LOT_061_Appel_A_V7_Plan_et_Liste.html` | `10SoszPJ0mBuS2gFm1B6ziKPzoDdtx-2_` | à faire |
| 19 | LOT_060 | Appel A | `LOT_060_Appel_A_V7_Plan_et_Liste.html` | `1cuLARKq4uQxp1SW-IpVe0QWGPzn-JlMv` | à faire |
| 20 | LOT_059 | Appel A | `LOT_059_Appel_A_V7_Plan_et_Liste.html` | `1BqlBEtIfmRODVvkrMXyamlN9CorDG-Az` | à faire |
| 21 | LOT_058 | Appel A | `LOT_058_Appel_A_V7_Plan_et_Liste.html` | `125irbmgjZ4U-ZtjLUcWxzJDKVHejzRnA` | à faire |
| 22 | LOT_057 | Appel A | `LOT_057_Appel_A_V7_Plan_et_Liste.html` | `1S2ueqo0pAP2nGfzll47du8az49l8-hd8` | à faire |
| 23 | LOT_056 | Appel A | `LOT_056_Appel_A_V7_Plan_et_Liste.html` | `1LDFmrSUBzOXWJ-cEpOx0UX36esWDtzWB` | à faire |
| 24 | LOT_055 | Appel A | `LOT_055_Appel_A_V7_Plan_et_Liste.html` | `1OD0UeceMAleXjE8pDBipKxAElSI7DWzK` | à faire |
| 25 | LOT_054 | Appel A | `LOT_054_Appel_A_V7_Plan_et_Liste.html` | `1u4QFZ6SkZOQKcJYmskaJ8DTX7fRsLTWt` | à faire |
| 26 | LOT_053 | Appel A | `LOT_053_Appel_A_V7_Plan_et_Liste.html` | `1v80_IhAHOKPdIHpbRlmpxx5DxrUN44Mw` | à faire |
| 27 | LOT_052 | Appel A | `LOT_052_Appel_A_V7_Plan_et_Liste.html` | `1KNB9G-mZ8zIVV8Q6G_UjVy4XyRWYoukj` | à faire |
| 28 | LOT_051 | Appel A | `LOT_051_Appel_A_V7_Plan_et_Liste.html` | `15p9jVp6JiZW11-QKttGxuxvxu2BfGyL0` | à faire |
| 29 | LOT_050 | Appel A | `LOT_050_Appel_A_V7_Plan_et_Liste.html` | `1_rSqomvj3M1gJ4yYs0zC_Nma0IcR20u7` | à faire |
| 30 | LOT_049 | Appel A | `LOT_049_Appel_A_V7_Plan_et_Liste.html` | `1PUpKkEO0ctbXj2uve9xQt_jhwYLScPMN` | à faire |
| 31 | LOT_048 | Appel A | `LOT_048_Appel_A_V7_Plan_et_Liste.html` | `1yTzzVlCe8wQWae3ENj3Cxj0iII8OZ5s1` | à faire |
| 32 | LOT_047 | Appel A | `LOT_047_Appel_A_V7_Plan_et_Liste.html` | `1L9kNfL6lwPomLzUKVtwadyARZiNc3vZK` | à faire |
| 33 | LOT_046 | Appel A | `LOT_046_Appel_A_V7_Plan_et_Liste.html` | `1JwIWD9qfm-BnwO46Df842ER8MYDs-Ogg` | à faire |
| 34 | LOT_045 | Appel A | `LOT_045_Appel_A_V7_Plan_et_Liste.html` | `1HeEa8-ot9frXjqf79D-P1yDRN_eXHmPb` | à faire |
| 35 | LOT_044 | Appel A | `LOT_044_Appel_A_V7_Plan_et_Liste.html` | `1JI9flvxsDMnXMc5Y50EgcnwemmFw7Ztg` | à faire |
| 36 | LOT_043 | Appel A | `LOT_043_Appel_A_V7_Plan_et_Liste.html` | `1N8j7RaBINORH0Jdx5UzqSX90pwKid6Or` | à faire |

Nom de dépôt sur Drive : « Agent_14 | LOT_X Appel A — Plan et liste des différentiels.html » (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.

## 5. Commandes (dans cet ordre, pour chaque fichier)
```
python3 /workspace/scripts_lots/equipes/S1A.py --agent 14 plan "<thème du LOT>"
python3 /workspace/scripts_lots/agent_14/script_source.py search "<requête>" --pec      # index local d'abord
python3 /workspace/scripts_lots/agent_14/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »
# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste
python3 /workspace/scripts_lots/equipes/S1A.py --agent 14 check /workspace/agent14/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/equipes/S2A.py --agent 14 review /workspace/agent14/LOT_X/<fichier>.html   # doit renvoyer 0
python3 /workspace/scripts_lots/agent_14/script_source.py check /workspace/agent14/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/agent_14/script_synchrone.py review /workspace/agent14/LOT_X/<fichier>.html     # un seul passage LanguageTool
grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0
```
Raccourcis : `python3 /workspace/scripts_lots/agent_14/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.

## 6. Charte (rappel)
`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.

## 7. Skills
- `skills/performance-redaction-lot/SKILL.md` (→ `/workspace/reorg/skills/performance-redaction-lot/SKILL.md`)
- `skills/concentration-fil-redaction/SKILL.md` (→ `/workspace/reorg/skills/concentration-fil-redaction/SKILL.md`)
- `skills/anti-gaspillage-redaction/SKILL.md` (→ `/workspace/reorg/skills/anti-gaspillage-redaction/SKILL.md`)
- `skills/harness-redacteur-v7/SKILL.md` (→ `/workspace/reorg/skills/harness-redacteur-v7/SKILL.md`)

## 8. Après chaque dépôt
Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.
Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.

FIN_DEMARRER
