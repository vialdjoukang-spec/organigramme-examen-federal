# DÉMARRER — Agent 1 — Équipe 1 · Appel A (LOT_218–184)

> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `db322130-de1f-49d9-a669-bd9b54729c37`), en une ligne : `BLOCAGE · Agent 1 · LOT_X : <motif ≤ 8 mots>`. Le non-bloquant va dans `/workspace/agent1/POUR_TUNDER_AGENT_1.md`.

## 1. Identité
- **Nom** : Agent 1 — Équipe 1 · Appel A (LOT_218–184)
- **Équipe 1** : LOT_218 → LOT_184 (35 LOT, ordre décroissant) — A = Agent 1 (vous), B1 = Agent 3, B2 = Agent 5
- **Rôle A** : l'Appel A (plan et liste des 10 DX) — un fichier par LOT.
- **Dossier de travail** : `/workspace/agent1/LOT_X/` · **fil** : `/workspace/equipes/agent_1/ETAT.md` · **config** : `/workspace/scripts_lots/agent_1/config.json` (ne pas modifier)
- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_1.md` (v1.6) — elles priment en cas de doute.

## 2. Transition (ancien rôle → nouveau rôle)
- Ancien rôle : Équipe 1 · Appel A + Partie 1 (LOT_218 → LOT_110). **Vous finissez le fichier en cours sous l'ancien rôle, puis vous passez au nouveau rôle et à la nouvelle plage.**
- Fichier de transition accepté par vos scripts : LOT_213 Partie 1 → le finir, le contrôler, le déposer s'il n'est pas déjà sur Drive.
- Relevé local : LOT_218–214 sont complets. Au LOT_213, l'Appel A et la Partie 1 sont terminés dans votre dossier (16 h 43 et 16 h 59) : vous les contrôlez (S1A/S2A pour l'Appel A, S1B/S2B pour la Partie 1, que vos scripts acceptent encore) et les déposez s'ils ne sont pas déjà sur Drive. Ensuite, vous ne rédigez plus aucune Partie : la Partie 1 des LOT suivants revient à l'Agent 3. Vous continuez à LOT_212 (Appel A seul).

## 3. Règle de saut
Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).

## 4. Liste exacte de vos fichiers (36 fichiers, dans cet ordre)
Dossier Drive parent « LOTS_Finaux avec statut » : `1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`. Le dossier `1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB` ne doit **jamais** être ouvert, listé ni lu.

| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |
|---|---|---|---|---|---|
| 1 | LOT_218 | Appel A | `LOT_218_Appel_A_V7_Plan_et_Liste.html` | `1kHPHThhhV_qDbxiBftCOuwQcfPp3mSxo` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 2 | LOT_217 | Appel A | `LOT_217_Appel_A_V7_Plan_et_Liste.html` | `1bEeJLCZmQEHyqiEnSQvT-z62jmkio_Mi` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 3 | LOT_216 | Appel A | `LOT_216_Appel_A_V7_Plan_et_Liste.html` | `1cLlaj39EOMQw3zqDiigb9QNQdI90YTk-` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 4 | LOT_215 | Appel A | `LOT_215_Appel_A_V7_Plan_et_Liste.html` | `1ohcz2Puxd3exoAbk3jAwn5meYGwlJb9l` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 5 | LOT_214 | Appel A | `LOT_214_Appel_A_V7_Plan_et_Liste.html` | `1dQIdgiaVJnZRpqm_CjW8WxD0JkbF3zvW` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 6 | LOT_213 | Appel A | `LOT_213_Appel_A_V7_Plan_et_Liste.html` | `1dOFE-MKyp_F8VU-bbh4CCCqgjLeXDM1Y` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 7 | LOT_213 | Partie 1 (transition) | `LOT_213_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1dOFE-MKyp_F8VU-bbh4CCCqgjLeXDM1Y` | terminé localement par l'Agent 1 — vérifier Drive, sauter si déposé |
| 8 | LOT_212 | Appel A | `LOT_212_Appel_A_V7_Plan_et_Liste.html` | `1GUuXmSG0DsP1bcP_FQ30sBURlnQeSEuT` | à faire |
| 9 | LOT_211 | Appel A | `LOT_211_Appel_A_V7_Plan_et_Liste.html` | `1jbs4hOW-I_KgpxD7ZO0EAZ6sw9f6jxrt` | à faire |
| 10 | LOT_210 | Appel A | `LOT_210_Appel_A_V7_Plan_et_Liste.html` | `1eCAnfTbDMtrghWtk1e39EJF4xsWgsMvX` | à faire |
| 11 | LOT_209 | Appel A | `LOT_209_Appel_A_V7_Plan_et_Liste.html` | `18iNBECddwje0E7-gAuoLHAebIWrvKnXd` | à faire |
| 12 | LOT_208 | Appel A | `LOT_208_Appel_A_V7_Plan_et_Liste.html` | `1n1-mD1_7uHaFgxN_O7eGR282PtP1kw2F` | à faire |
| 13 | LOT_207 | Appel A | `LOT_207_Appel_A_V7_Plan_et_Liste.html` | `1Afip48FG0_aMBhcP8POgi-kd5mjeEY3z` | à faire |
| 14 | LOT_206 | Appel A | `LOT_206_Appel_A_V7_Plan_et_Liste.html` | `1cFghlm99QKjHT3t7UIVQecXgsgwdn2QR` | à faire |
| 15 | LOT_205 | Appel A | `LOT_205_Appel_A_V7_Plan_et_Liste.html` | `1HIedxEhJ4unChycITH9JRDfBLfwGVvb0` | à faire |
| 16 | LOT_204 | Appel A | `LOT_204_Appel_A_V7_Plan_et_Liste.html` | `11PBbTNjDANtMP9dLKT1UY7WvBl5gpY0h` | à faire |
| 17 | LOT_203 | Appel A | `LOT_203_Appel_A_V7_Plan_et_Liste.html` | `1BDDEGa89Z9UdkR6SkOi0M1IGflLXBDgC` | à faire |
| 18 | LOT_202 | Appel A | `LOT_202_Appel_A_V7_Plan_et_Liste.html` | `1t_7CTyuXVnK3LaKaRpPpqiHAEUMqPu0t` | à faire |
| 19 | LOT_201 | Appel A | `LOT_201_Appel_A_V7_Plan_et_Liste.html` | `1Y9yCPesHKpNEvwFG4Rgt_LqZHKs6dfH7` | à faire |
| 20 | LOT_200 | Appel A | `LOT_200_Appel_A_V7_Plan_et_Liste.html` | `11IS3GRQwsOy-i9vGINL3124sX0uW04Cs` | à faire |
| 21 | LOT_199 | Appel A | `LOT_199_Appel_A_V7_Plan_et_Liste.html` | `1clPIfFIQu9txdacWCdS8pqBn6C9Ghqmr` | à faire |
| 22 | LOT_198 | Appel A | `LOT_198_Appel_A_V7_Plan_et_Liste.html` | `1qQy2WU3Y76FrKzKH6iuuGTRomWiPUpYY` | à faire |
| 23 | LOT_197 | Appel A | `LOT_197_Appel_A_V7_Plan_et_Liste.html` | `1_klcRmfOR-wJ0cGZEIk04S59EUucd5h-` | à faire |
| 24 | LOT_196 | Appel A | `LOT_196_Appel_A_V7_Plan_et_Liste.html` | `1JHOxngkvw5B262OCV0zdiEnjx-002vwy` | à faire |
| 25 | LOT_195 | Appel A | `LOT_195_Appel_A_V7_Plan_et_Liste.html` | `1eKWXApLn6s7AQxahuL_cHi0kslpr_pQT` | à faire |
| 26 | LOT_194 | Appel A | `LOT_194_Appel_A_V7_Plan_et_Liste.html` | `1BltDDDSP6rK6y4qAjdPdjgBCUX1cChHB` | à faire |
| 27 | LOT_193 | Appel A | `LOT_193_Appel_A_V7_Plan_et_Liste.html` | `1fsfgglp1qRgy_v1MtpF4NQ08i6oVmnRw` | à faire |
| 28 | LOT_192 | Appel A | `LOT_192_Appel_A_V7_Plan_et_Liste.html` | `16dcncbo7Xbi82WhDv_7FPQEAdPkG5L8O` | à faire |
| 29 | LOT_191 | Appel A | `LOT_191_Appel_A_V7_Plan_et_Liste.html` | `1S18Oj3rsYeMNlM7ZA7d3xwA0JEzz72mp` | à faire |
| 30 | LOT_190 | Appel A | `LOT_190_Appel_A_V7_Plan_et_Liste.html` | `1vAj-e79W8N83bLVbSClhllcwhGhL3o7s` | à faire |
| 31 | LOT_189 | Appel A | `LOT_189_Appel_A_V7_Plan_et_Liste.html` | `1DA8WDTzgbA3sSysQYAmLY-5jqCi6HxZV` | à faire |
| 32 | LOT_188 | Appel A | `LOT_188_Appel_A_V7_Plan_et_Liste.html` | `1K-HiXU71SYcMz2BhcsZW04rFOrb_ZNiU` | à faire |
| 33 | LOT_187 | Appel A | `LOT_187_Appel_A_V7_Plan_et_Liste.html` | `1U3fkmOmOlHzF4h75pqvTuNq4FdkB4YnH` | à faire |
| 34 | LOT_186 | Appel A | `LOT_186_Appel_A_V7_Plan_et_Liste.html` | `1TBjBS_khP7f36r6f_cR1tW7WhwhpxP5e` | à faire |
| 35 | LOT_185 | Appel A | `LOT_185_Appel_A_V7_Plan_et_Liste.html` | `1w3kcq5BzYEwE-EjDADCR8n1zSzKoz2Dd` | à faire |
| 36 | LOT_184 | Appel A | `LOT_184_Appel_A_V7_Plan_et_Liste.html` | `1RvAms-grbfUTgV6xhJRdaVDo1jOzau6Y` | à faire |

Nom de dépôt sur Drive : « Agent_1 | LOT_X Appel A — Plan et liste des différentiels.html » (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.

## 5. Commandes (dans cet ordre, pour chaque fichier)
```
python3 /workspace/scripts_lots/equipes/S1A.py --agent 1 plan "<thème du LOT>"
python3 /workspace/scripts_lots/agent_1/script_source.py search "<requête>" --pec      # index local d'abord
python3 /workspace/scripts_lots/agent_1/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »
# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste
python3 /workspace/scripts_lots/equipes/S1A.py --agent 1 check /workspace/agent1/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/equipes/S2A.py --agent 1 review /workspace/agent1/LOT_X/<fichier>.html   # doit renvoyer 0
python3 /workspace/scripts_lots/agent_1/script_source.py check /workspace/agent1/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/agent_1/script_synchrone.py review /workspace/agent1/LOT_X/<fichier>.html     # un seul passage LanguageTool
grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0
```
Raccourcis : `python3 /workspace/scripts_lots/agent_1/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.

## 6. Charte (rappel)
`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.

## 7. Skills
- `skills/performance-redaction-lot/SKILL.md` (→ `/workspace/reorg/skills/performance-redaction-lot/SKILL.md`)
- `skills/concentration-fil-redaction/SKILL.md` (→ `/workspace/reorg/skills/concentration-fil-redaction/SKILL.md`)
- `skills/anti-gaspillage-redaction/SKILL.md` (→ `/workspace/reorg/skills/anti-gaspillage-redaction/SKILL.md`)
- `skills/harness-redacteur-v7/SKILL.md` (→ `/workspace/reorg/skills/harness-redacteur-v7/SKILL.md`)

## 8. Après chaque dépôt
Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.
Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.

FIN_DEMARRER
