#!/usr/bin/env python3
import json, sys, html, subprocess
from pathlib import Path
sys.path.insert(0, "/workspace/instructions_agents"); sys.path.insert(0, "/workspace/scripts_lots")
import generer_instructions as I, generer_configs as G
ICI = Path(__file__).resolve().parent
J = json.load(open("/workspace/equipes/etat_jauge.json"))
PN = {"A": "Appel A", "P1": "Partie 1", "P2": "Partie 2", "P3": "Partie 3", "P4": "Partie 4"}
e = html.escape
def barre(f, t):
    pc = 100 * f / t if t else 0
    return f'<div class="bar"><span style="width:{pc:.1f}%"></span></div><small>{f} / {t} · {pc:.1f} %</small>'
eqrows = "".join(f"<tr><td><b>{q}</b></td><td>{I.L(h)} → {I.L(b)}</td><td>{h-b+1}</td><td>Agent {m['A']}</td><td>Agent {m['B1']}</td><td>Agent {m['B2']}</td><td>{barre(J['equipes'][str(q)]['faits'], J['equipes'][str(q)]['total'])}</td></tr>" for q, (h, b, m) in G.EQUIPES.items())
agrows = ""
for n in sorted(G.ORGANISATION, key=lambda n: (G.ORGANISATION[n][0], ["A", "B1", "B2"].index(G.ORGANISATION[n][1]))):
    a = J["agents"][str(n)]; t = G.TRANSITION.get(n, {})
    tr = "; ".join(f"{I.L(x)} " + " + ".join(PN[p] for p in pp) for x, pp in t.items()) or "—"
    agrows += f"<tr><td>{e(I.nom_agent(n))}</td><td>{tr}</td><td>{e(a['prochain'])}</td><td>{barre(a['faits'], a['total'])}</td></tr>"
tot_f = sum(v["faits"] for v in J["equipes"].values()); tot_t = sum(v["total"] for v in J["equipes"].values())
H = f"""<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>Dispositif des équipes v1.6</title><style>
@page{{size:A4;margin:16mm 14mm 16mm 14mm}}
body{{font-family:"Atkinson Hyperlegible",Verdana,sans-serif;color:#14212b;font-size:10.5pt;line-height:1.4}}
h1{{color:#0b4f7c;font-size:21pt;margin:0 0 4px}} h2{{color:#0b4f7c;border-bottom:2px solid #a8cbe2;padding-bottom:3px;margin-top:18px;font-size:14pt}}
.sous{{color:#35556b;margin:0 0 12px}} .cart{{background:#eaf4fb;border-left:5px solid #2f7fb5;padding:8px 12px;margin:10px 0;border-radius:4px}}
.alerte{{background:#fdecee;border-left:5px solid #C8102E;padding:8px 12px;margin:10px 0;border-radius:4px}}
table{{border-collapse:collapse;width:100%;margin:6px 0;font-size:9.3pt}} th{{background:#dceef9;color:#0b3a5a;text-align:left}}
th,td{{border:1px solid #b2c7d6;padding:4px 6px;vertical-align:top}} tr:nth-child(even) td{{background:#f1f8fd}}
.bar{{height:8px;background:#e2ebf2;border-radius:4px;overflow:hidden;width:100%;min-width:90px}} .bar span{{display:block;height:100%;background:#2f7fb5}}
small{{color:#35556b}} code{{background:#f1f8fd;border:1px solid #d6e6f1;border-radius:3px;padding:0 3px;font-size:8.8pt}}
.proba{{color:#C8102E;font-weight:700}} .pb{{page-break-before:always}} ol li,ul li{{margin:2px 0}}
</style></head><body>
<h1>Dispositif des équipes de rédaction — v1.6</h1>
<p class="sous">Projet Organigramme_Examen_Fédéral · coordination Tunder · 24 octobre 2026, 16 h 42 (organisation) et 16 h 49 (outillage) · état relevé à 17 h 10 (Europe/Zurich), fichiers locaux</p>
<div class="cart"><b>18 agents, 6 équipes de 3, LOT_218 → LOT_007 en ordre décroissant.</b> Rôle A : Appel A (1 fichier par LOT). Rôle B1 : Parties 1 puis 2 (DX.1–5). Rôle B2 : Parties 3 puis 4 (DX.6–10). LOT_219–248 hors périmètre ; LOT_001–006 audités par Tunder. Total attendu : {tot_t} fichiers.</div>
<h2>1. Équipes et progression</h2>
<table><tr><th>Équipe</th><th>Plage</th><th>LOT</th><th>A</th><th>B1</th><th>B2</th><th>Fichiers faits (local)</th></tr>{eqrows}
<tr><td colspan="6"><b>Total</b></td><td>{barre(tot_f, tot_t)}</td></tr></table>
<p><small>« Fait » = fichier terminé localement (FIN_FICHIER présent) ; un fichier produit n'est pas forcément déposé. La jauge Drive s'obtient avec <code>jauge.py --drive LISTE.json</code> à partir d'un relevé fourni par Tunder.</small></p>
<h2>2. Règles communes</h2>
<div class="alerte"><b>Règle n° 1 — silence total.</b> Aucun message à l'utilisateur, jamais ; aucun signal de dépôt à personne (Tunder suit Drive). Seule exception : un vrai blocage, à Tunder seul, par SendToAgent, en une ligne « BLOCAGE · Agent N · LOT_X : motif ».</div>
<ul><li><b>Règle de saut</b> : chaque agent saute tout LOT dont son fichier est déjà déposé sur Drive. Équipe 6 : saut de tout fichier LOT_007/008 déjà déposé, quel qu'en soit l'auteur.</li>
<li><b>Transition (agents 1–8)</b> : le fichier en cours au basculement est fini et déposé sous l'ancien rôle, puis le contrôle de série s'applique.</li>
<li><b>Charte qualité V7+</b> (la ligne #FF2400 est obsolète) : probabilités <span class="proba">en rouge #C8102E gras</span>, sans halo ; police Atkinson Hyperlegible ; contraste WCAG ≥ 4,5 ; fenêtres d'examen cliquables à onglets Principe / Interprétation ; ≤ 4 phrases par point ; 14 points du §6.</li>
<li><b>Palette</b> : #edf7f4→#eaf4fb · #f2faf7→#f1f8fd · #dff1e9→#dceef9 · #d8e8e2→#d6e6f1 · #e3ece8→#e2ebf2 · #aacfc3→#a8cbe2 · #b2c9c0→#b2c7d6.</li>
<li><b>Drive</b> : dossier « LOTS_Finaux avec statut » (<code>{I.DRIVE}</code>), sous-dossier « LOT_NNN — … », nom « Agent_N | LOT_X … » ; le dossier <code>{I.INTERDIT}</code> n'est jamais ouvert, listé ni lu. GitHub en lecture seule.</li></ul>
<h2 class="pb">3. Agents, transitions et prochain fichier</h2>
<table><tr><th>Agent (nom v1.6)</th><th>Transition acceptée</th><th>Prochain fichier attendu</th><th>Progression</th></tr>{agrows}</table>
<h2>4. Outillage déterministe</h2>
<table><tr><th>Outil</th><th>Fonction</th><th>Commande</th></tr>
<tr><td>S1A / S1B</td><td>Sourçage hiérarchisé N1 → N5, prise en charge prioritaire ; toute affirmation non sourcée bloque le dépôt</td><td><code>python3 /workspace/scripts_lots/equipes/S1B.py --agent N check F</code></td></tr>
<tr><td>S2A / S2B</td><td>Tableau des 14 points + Charte V7+ (C1–C13) ; tout ÉCHEC bloque le dépôt</td><td><code>python3 /workspace/scripts_lots/equipes/S2B.py --agent N review F --appel-a A</code></td></tr>
<tr><td>script_source / script_synchrone</td><td>Recherche, crawl, PubMed, porte <code>check</code> ; relecture LanguageTool</td><td><code>scripts_lots/agent_N/…</code></td></tr>
<tr><td>Chaîne V7</td><td>gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste</td><td><code>/workspace/audit_1_10/outils/</code></td></tr>
<tr><td>jauge.py</td><td>Progression par équipe et par agent ; jamais d'appel Drive</td><td><code>python3 /workspace/equipes/jauge.py --maj EQUIPES_V1.6.md</code></td></tr></table>
<p>Garanties de S1/S2 : ouverture en lecture seule, empreinte sha256 avant/après (code 3 si modification), rapports hors du LOT, refus (code 2) de tout fichier hors série, hors Partie ou d'un autre agent. Budgets par agent : LanguageTool 0,55 requête/min ; NCBI 3/18 req/s ; HTTP 1 requête/18 s par domaine.</p>
<h2>5. Environnement de chaque agent</h2>
<p><code>/workspace/equipes/agent_N/</code> (et <code>agent_N.zip</code>) : <b>DEMARRER.md</b> (point d'entrée unique : identité, équipe, rôle, liste exacte des fichiers avec identifiants Drive et état, transition, commandes S1/S2, silence), <b>config.json</b>, <b>ETAT.md</b> (fil de rédaction), <b>skills/</b> : performance-redaction-lot, concentration-fil-redaction, anti-gaspillage-redaction, harness-redacteur-v7.</p>
<h2>6. Vérifications</h2>
<p>57 tests automatiques réussis (<code>./lancer_tests.sh</code>), dont 12 pour S1/S2 sur les 18 agents (lecture seule, refus, sabotage, contraste, charte).</p>
<h2>7. Points de vigilance</h2>
<ul><li>L'état des dépôts est déduit des fichiers locaux ; Drive n'a pas été consulté : la règle de saut tranche.</li>
<li>Des fichiers rédigés avant l'amendement couleurs (#FF2400 avec halo, badge #2e8b57 à 4,25 de contraste) échouent aux critères C1 et C4 : correction avant dépôt nécessaire.</li>
<li>LOT_007 : rédigé en parallèle par l'ancienne équipe 2 jusqu'à 17 h ; les agents 17 et 18 ne reprennent que les fichiers absents de Drive.</li></ul>
</body></html>"""
(ICI / "DISPOSITIF_EQUIPES_V1.6.html").write_text(H, "utf-8")
subprocess.run(["google-chrome", "--headless=new", "--no-sandbox", "--disable-gpu", "--no-pdf-header-footer",
                f"--print-to-pdf=/workspace/equipes/DISPOSITIF_EQUIPES_V1.6.pdf", str(ICI / "DISPOSITIF_EQUIPES_V1.6.html")], check=True, capture_output=True, timeout=120)
