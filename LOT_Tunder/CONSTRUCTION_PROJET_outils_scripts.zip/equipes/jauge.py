#!/usr/bin/env python3
"""Jauge d'avancement v1.6 — 6 équipes × 3 agents, LOT_218 → LOT_007 (décroissant).

Unités : rôle A = 1 fichier par LOT (Appel A) ; rôle B1 = 2 fichiers (Parties 1, 2) ; rôle B2 = 2 fichiers (Parties 3, 4) ;
équipe = 5 fichiers par LOT. Une Partie découpée en _a/_b compte pour UN fichier.

Sources d'état (au choix, combinables) :
  --drive LISTE.json  état DÉPOSÉ : export JSON d'un listage des sous-dossiers « LOT_NNN — … » du dossier Drive
                      1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu (réalisé par Tunder avec le connecteur Google Drive ; ce script
                      n'appelle JAMAIS Drive lui-même). Formats acceptés : liste d'objets {name, parents|folder_id|lot},
                      ou {"files": [...]}. Noms reconnus : « Agent_N | LOT_X Appel A — … », « Agent_N | LOT_X Partie K — … ».
  --local             état PRODUIT LOCALEMENT (repli hors ligne, défaut si --drive absent) : fichiers V7 finaux dans
                      /workspace/agentN/LOT_*/ (et /workspace/lots), terminés si la balise FIN_FICHIER est présente.
                      Un fichier local terminé n'est PAS une preuve de dépôt.
Sorties : tableau Markdown (stdout), --json FICHIER, --maj EQUIPES_V1.6.md (remplace la zone entre
<!-- JAUGE:DEBUT --> et <!-- JAUGE:FIN -->). Lecture seule sur les LOT (ouverture O_RDONLY, aucune écriture).
Bibliothèque standard ; aucun réseau."""
import argparse, json, os, re, sys, time
from pathlib import Path

sys.path.insert(0, "/workspace/scripts_lots")
import generer_configs as G                                   # source unique de l'organisation

PARTIES_ROLE = {r: p for r, (_, p) in G.ROLES.items()}
NOM_PARTIE = {"A": "Appel A", "P1": "Partie 1", "P2": "Partie 2", "P3": "Partie 3", "P4": "Partie 4"}
RE_LOCAL = re.compile(r"^LOT_0*(\d{1,3})_Appel_(?:A_V7_Plan_et_Liste|B_V7_Partie_([1-4])_.*)\.html$")
RE_DRIVE = re.compile(r"Agent_?\s?(\d{1,2})\s*\|\s*LOT_0*(\d{1,3})\s+(Appel A|Partie\s?([1-4]))", re.I)
IDS = "/workspace/ids.json"

def lire(p):
    fd = os.open(str(p), os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    try:
        taille = os.fstat(fd).st_size; os.lseek(fd, max(0, taille - 400), 0); return os.read(fd, 400)
    finally:
        os.close(fd)

def etat_local(racines=None):
    racines = racines or sorted(Path("/workspace").glob("agent[0-9]*")) + [Path("/workspace/lots")]
    etat = {}
    for r in racines:
        if not r.is_dir(): continue
        for f in r.glob("LOT_*/*.html"):
            m = RE_LOCAL.match(f.name)
            if not m: continue
            lot, k = int(m.group(1)), m.group(2); partie = f"P{k}" if k else "A"
            fini = b"FIN_FICHIER" in lire(f)
            prec = etat.get((lot, partie))
            st = "terminé (local)" if fini else "en cours (local)"
            if not prec or (prec["statut"].startswith("en cours") and fini):
                etat[(lot, partie)] = {"statut": st, "source": str(f), "agent_auteur": int(re.search(r"agent(\d+)", str(f)).group(1)) if re.search(r"agent(\d+)", str(f)) else 2}
    return etat

def etat_drive(chemin):
    doc = json.loads(Path(chemin).read_text("utf-8"))
    fichiers = doc.get("files", doc) if isinstance(doc, dict) else doc
    par_id = {}
    try: par_id = {v: int(k) for k, v in json.loads(Path(IDS).read_text()).items()}
    except Exception: pass
    etat = {}
    for x in fichiers:
        nom = x.get("name") or x.get("title") or ""
        m = RE_DRIVE.search(nom)
        if not m: continue
        lot = int(m.group(2)); partie = "A" if m.group(3).lower().startswith("appel") else f"P{m.group(4)}"
        dossier = (x.get("parents") or [x.get("folder_id")])[0] if (x.get("parents") or x.get("folder_id")) else None
        if dossier in par_id and par_id[dossier] != lot:
            continue                                            # rangé dans le mauvais sous-dossier : non compté
        etat[(lot, partie)] = {"statut": "déposé (Drive)", "source": nom, "agent_auteur": int(m.group(1))}
    return etat

def barre(f, t, n=20):
    p = f / t if t else 0; k = round(p * n); return "█" * k + "░" * (n - k) + f" {100 * p:5.1f} %"

def calcul(etat):
    agents, equipes = {}, {}
    for eq, (haut, bas, membres) in G.EQUIPES.items():
        serie = list(range(haut, bas - 1, -1)); te = fe = 0
        for role, n in membres.items():
            parts = PARTIES_ROLE[role]; total = len(serie) * len(parts)
            faits = sum(1 for lot in serie for p in parts if etat.get((lot, p), {}).get("statut", "").startswith(("déposé", "terminé")))
            cours = sum(1 for lot in serie for p in parts if etat.get((lot, p), {}).get("statut", "").startswith("en cours"))
            prochain = next(((lot, p) for lot in serie for p in parts if not etat.get((lot, p), {}).get("statut", "").startswith(("déposé", "terminé"))), None)
            agents[n] = {"agent": n, "equipe": eq, "role": role, "plage": f"LOT_{haut:03d}–{bas:03d}", "faits": faits, "en_cours": cours, "total": total,
                         "prochain": f"LOT_{prochain[0]:03d} {NOM_PARTIE[prochain[1]]}" if prochain else "série terminée"}
            te += total; fe += faits
        equipes[eq] = {"equipe": eq, "plage": f"LOT_{haut:03d}–{bas:03d}", "lots": len(serie), "faits": fe, "total": te}
    return agents, equipes

def rendu(etat, origine):
    agents, equipes = calcul(etat)
    l = [f"_Jauge générée le {time.strftime('%Y-%m-%d %H:%M')} (Europe/Zurich) — origine : {origine}._", "",
         "### Par équipe", "", "| Équipe | Plage | LOT | Fichiers faits / attendus | Jauge |", "|---|---|---|---|---|"]
    for e in equipes.values():
        l.append(f"| {e['equipe']} | {e['plage']} | {e['lots']} | {e['faits']} / {e['total']} | `{barre(e['faits'], e['total'])}` |")
    T = sum(e["total"] for e in equipes.values()); F = sum(e["faits"] for e in equipes.values())
    l += [f"| **Total** | LOT_218–007 | 212 | **{F} / {T}** | `{barre(F, T)}` |", "", "### Par agent", "",
          "| Agent | Équipe | Rôle | Plage | Faits / attendus | En cours | Prochain fichier | Jauge |", "|---|---|---|---|---|---|---|---|"]
    for n in sorted(agents):
        a = agents[n]
        l.append(f"| {n} | {a['equipe']} | {a['role']} | {a['plage']} | {a['faits']} / {a['total']} | {a['en_cours']} | {a['prochain']} | `{barre(a['faits'], a['total'], 12)}` |")
    return "\n".join(l), agents, equipes

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--drive"); ap.add_argument("--local", action="store_true"); ap.add_argument("--json"); ap.add_argument("--maj")
    a = ap.parse_args(argv)
    etat, origines = {}, []
    if a.local or not a.drive:
        etat.update(etat_local()); origines.append("fichiers locaux /workspace/agentN (produit ≠ déposé)")
    if a.drive:
        etat.update(etat_drive(a.drive)); origines.append(f"listage Drive {a.drive}")
    md, agents, equipes = rendu(etat, " + ".join(origines))
    print(md)
    if a.json:
        Path(a.json).write_text(json.dumps({"agents": agents, "equipes": equipes,
                                            "fichiers": {f"LOT_{k[0]:03d}:{k[1]}": v for k, v in sorted(etat.items())}}, ensure_ascii=False, indent=1), "utf-8")
    if a.maj:
        p = Path(a.maj); t = p.read_text("utf-8")
        t2 = re.sub(r"<!-- JAUGE:DEBUT -->.*?<!-- JAUGE:FIN -->", lambda m: "<!-- JAUGE:DEBUT -->\n" + md + "\n<!-- JAUGE:FIN -->", t, flags=re.S)
        p.write_text(t2, "utf-8")
    return 0

if __name__ == "__main__":
    sys.exit(main())
