# DÉMARRER — Agent 2 — Équipe 4 · Appel A (LOT_113–079)

> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `db322130-de1f-49d9-a669-bd9b54729c37`), en une ligne : `BLOCAGE · Agent 2 · LOT_X : <motif ≤ 8 mots>`. Le non-bloquant va dans `/workspace/agent2/POUR_TUNDER_AGENT_2.md`.

## 1. Identité
- **Nom** : Agent 2 — Équipe 4 · Appel A (LOT_113–079)
- **Équipe 4** : LOT_113 → LOT_079 (35 LOT, ordre décroissant) — A = Agent 2 (vous), B1 = Agent 4, B2 = Agent 6
- **Rôle A** : l'Appel A (plan et liste des 10 DX) — un fichier par LOT.
- **Dossier de travail** : `/workspace/agent2/LOT_X/` · **fil** : `/workspace/equipes/agent_2/ETAT.md` · **config** : `/workspace/scripts_lots/agent_2/config.json` (ne pas modifier)
- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_2.md` (v1.6) — elles priment en cas de doute.

## 2. Transition (ancien rôle → nouveau rôle)
- Ancien rôle : Équipe 2 · Appel A + Partie 1 (LOT_109 → LOT_001). **Vous finissez le fichier en cours sous l'ancien rôle, puis vous passez au nouveau rôle et à la nouvelle plage.**
- Fichier de transition accepté par vos scripts : LOT_007 Appel A + Partie 1 → le finir, le contrôler, le déposer s'il n'est pas déjà sur Drive.
- Relevé local : Au LOT_007, l'Appel A (16 h 47) et la Partie 1 (17 h 02) sont terminés dans votre dossier sous votre ancien rôle : vous les contrôlez et déposez ceux qui ne sont pas déjà sur Drive (transition acceptée par vos scripts : LOT_007 Appel A + Partie 1, rien d'autre), puis vous passez à LOT_113 (Appel A seul). LOT_109–105 sont faits : vous les sautez.

## 3. Règle de saut
Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).

## 4. Liste exacte de vos fichiers (37 fichiers, dans cet ordre)
Dossier Drive parent « LOTS_Finaux avec statut » : `1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`. Le dossier `1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB` ne doit **jamais** être ouvert, listé ni lu.

| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |
|---|---|---|---|---|---|
| 1 | LOT_007 | Appel A (transition) | `LOT_007_Appel_A_V7_Plan_et_Liste.html` | `1DToymCzAnIP1BrJ0Oh7S8PWQ3ns5u4EB` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 2 | LOT_007 | Partie 1 (transition) | `LOT_007_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1DToymCzAnIP1BrJ0Oh7S8PWQ3ns5u4EB` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 3 | LOT_113 | Appel A | `LOT_113_Appel_A_V7_Plan_et_Liste.html` | `1FtcdPZoNKTwSG7e_WpZy3D3MB2p3b6-f` | à faire |
| 4 | LOT_112 | Appel A | `LOT_112_Appel_A_V7_Plan_et_Liste.html` | `1PEVUqzfciEHuqVQ1BQRkFohFDvXNGb9A` | à faire |
| 5 | LOT_111 | Appel A | `LOT_111_Appel_A_V7_Plan_et_Liste.html` | `1NILNxoT93aer6Uke9u5Jfeu-KSIUI5wY` | à faire |
| 6 | LOT_110 | Appel A | `LOT_110_Appel_A_V7_Plan_et_Liste.html` | `1j2bvbgwhPXgLlDJ5yitbGRk1utdY5SIx` | à faire |
| 7 | LOT_109 | Appel A | `LOT_109_Appel_A_V7_Plan_et_Liste.html` | `1wG_IpVps1QOte6LfretqwMzo0r5POh-x` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 8 | LOT_108 | Appel A | `LOT_108_Appel_A_V7_Plan_et_Liste.html` | `1XzKWyB0l7DzLnnWEuovbZvV9an1IltZ-` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 9 | LOT_107 | Appel A | `LOT_107_Appel_A_V7_Plan_et_Liste.html` | `1FTPKTupMpz2iTu-ds_KuJW5IlznjSHSz` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 10 | LOT_106 | Appel A | `LOT_106_Appel_A_V7_Plan_et_Liste.html` | `1j2KZFw5CAKRUkoCkwHblMp9Xd_bwwvQu` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 11 | LOT_105 | Appel A | `LOT_105_Appel_A_V7_Plan_et_Liste.html` | `1tyntz5mFYEr4isSmwhbiWYqmHIndwLf7` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 12 | LOT_104 | Appel A | `LOT_104_Appel_A_V7_Plan_et_Liste.html` | `1XbL2VqM9mgtV6LqCYJIthRmDjSqs0W5n` | à faire |
| 13 | LOT_103 | Appel A | `LOT_103_Appel_A_V7_Plan_et_Liste.html` | `1hxfwoHf2nvd8VEsPA0jpJYjHVPyOCJiL` | à faire |
| 14 | LOT_102 | Appel A | `LOT_102_Appel_A_V7_Plan_et_Liste.html` | `1JGzNz6vNbcbkehzcbs_LLhXXcoTMozh6` | à faire |
| 15 | LOT_101 | Appel A | `LOT_101_Appel_A_V7_Plan_et_Liste.html` | `1Gm6LZE7CeNNTM-54cavJJDcIEmq34FfA` | à faire |
| 16 | LOT_100 | Appel A | `LOT_100_Appel_A_V7_Plan_et_Liste.html` | `1WotUbz7y0fn9xaOG4ktN4kwKraDChuXl` | à faire |
| 17 | LOT_099 | Appel A | `LOT_099_Appel_A_V7_Plan_et_Liste.html` | `1Grq_ALPaINHLtPlrgImMhPw_C3EkZp9z` | à faire |
| 18 | LOT_098 | Appel A | `LOT_098_Appel_A_V7_Plan_et_Liste.html` | `18SFhq46cRV3r1YL1sYTu_n5Qd7wsVWTv` | à faire |
| 19 | LOT_097 | Appel A | `LOT_097_Appel_A_V7_Plan_et_Liste.html` | `1wEW3SHrVGR7bAMYEECXayUDfmI47-TJB` | à faire |
| 20 | LOT_096 | Appel A | `LOT_096_Appel_A_V7_Plan_et_Liste.html` | `1qrX7L0LIw82P6di1JC3zsj4XW-PQsMTA` | à faire |
| 21 | LOT_095 | Appel A | `LOT_095_Appel_A_V7_Plan_et_Liste.html` | `1-qNAP_qAXH-xWDKc5fWc95A4Mh0uSz7J` | à faire |
| 22 | LOT_094 | Appel A | `LOT_094_Appel_A_V7_Plan_et_Liste.html` | `1OHKzUvLsB125bzYo4yooKmeF9QaWYRAW` | à faire |
| 23 | LOT_093 | Appel A | `LOT_093_Appel_A_V7_Plan_et_Liste.html` | `1jw40DUx7-akPBi_kG-I4g8ETsSqjha-q` | à faire |
| 24 | LOT_092 | Appel A | `LOT_092_Appel_A_V7_Plan_et_Liste.html` | `1mkd1fBjKz-kmaVcamOjFOaIrPdve4HfJ` | à faire |
| 25 | LOT_091 | Appel A | `LOT_091_Appel_A_V7_Plan_et_Liste.html` | `1I45DR9sPzPuKJFZn1DyMyMSe1d4xSj3A` | à faire |
| 26 | LOT_090 | Appel A | `LOT_090_Appel_A_V7_Plan_et_Liste.html` | `1Xn9DV5_iP3gmHRc1YyRonlPNLy-qRObo` | à faire |
| 27 | LOT_089 | Appel A | `LOT_089_Appel_A_V7_Plan_et_Liste.html` | `1ruyyDOPfXfrqIvs7SBABr2Y8UZT9x1Y5` | à faire |
| 28 | LOT_088 | Appel A | `LOT_088_Appel_A_V7_Plan_et_Liste.html` | `1MSkOQm-Db505_lfsCnbc7hzOcUiJBVjf` | à faire |
| 29 | LOT_087 | Appel A | `LOT_087_Appel_A_V7_Plan_et_Liste.html` | `1sHCnvA0O-iXkD8FLTG0tghLnQOVOmzb6` | à faire |
| 30 | LOT_086 | Appel A | `LOT_086_Appel_A_V7_Plan_et_Liste.html` | `1RzMIJpVerCfD1RNOIzd96SAzcaCNpSom` | à faire |
| 31 | LOT_085 | Appel A | `LOT_085_Appel_A_V7_Plan_et_Liste.html` | `1tsRN-uY8vCkR6YlQ_ijhaW6R9nzY-MAN` | à faire |
| 32 | LOT_084 | Appel A | `LOT_084_Appel_A_V7_Plan_et_Liste.html` | `1aZZA3aVFEFcrFG7Xi0H4G6tmEaxDeCSr` | à faire |
| 33 | LOT_083 | Appel A | `LOT_083_Appel_A_V7_Plan_et_Liste.html` | `1-CD59ai6orLKf9oE8qS2hkwZJKJVPpyc` | à faire |
| 34 | LOT_082 | Appel A | `LOT_082_Appel_A_V7_Plan_et_Liste.html` | `1iIJhQ1Vk-4A0w3iGg_EPaSa0rPfp6bRk` | à faire |
| 35 | LOT_081 | Appel A | `LOT_081_Appel_A_V7_Plan_et_Liste.html` | `16JTlFzlFkP2hH4Rc-PuV_fMGNyyhCLPg` | à faire |
| 36 | LOT_080 | Appel A | `LOT_080_Appel_A_V7_Plan_et_Liste.html` | `1OcokP7NTPEut6AXDsGWRKlSDQNSROQ-x` | à faire |
| 37 | LOT_079 | Appel A | `LOT_079_Appel_A_V7_Plan_et_Liste.html` | `1Pg9xB3tWbgUVHNDSsj5dL2BgkyCwTcI7` | à faire |

Nom de dépôt sur Drive : « Agent_2 | LOT_X Appel A — Plan et liste des différentiels.html » (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.

## 5. Commandes (dans cet ordre, pour chaque fichier)
```
python3 /workspace/scripts_lots/equipes/S1A.py --agent 2 plan "<thème du LOT>"
python3 /workspace/scripts_lots/agent_2/script_source.py search "<requête>" --pec      # index local d'abord
python3 /workspace/scripts_lots/agent_2/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »
# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste
python3 /workspace/scripts_lots/equipes/S1A.py --agent 2 check /workspace/agent2/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/equipes/S2A.py --agent 2 review /workspace/agent2/LOT_X/<fichier>.html   # doit renvoyer 0
python3 /workspace/scripts_lots/agent_2/script_source.py check /workspace/agent2/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/agent_2/script_synchrone.py review /workspace/agent2/LOT_X/<fichier>.html     # un seul passage LanguageTool
grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0
```
Raccourcis : `python3 /workspace/scripts_lots/agent_2/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.

## 6. Charte (rappel)
`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.

## 7. Skills
- `skills/performance-redaction-lot/SKILL.md` (→ `/workspace/reorg/skills/performance-redaction-lot/SKILL.md`)
- `skills/concentration-fil-redaction/SKILL.md` (→ `/workspace/reorg/skills/concentration-fil-redaction/SKILL.md`)
- `skills/anti-gaspillage-redaction/SKILL.md` (→ `/workspace/reorg/skills/anti-gaspillage-redaction/SKILL.md`)
- `skills/harness-redacteur-v7/SKILL.md` (→ `/workspace/reorg/skills/harness-redacteur-v7/SKILL.md`)

## 8. Après chaque dépôt
Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.
Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.

FIN_DEMARRER
