# DISPOSITIF DES ÉQUIPES — v1.6 (2026-10-24, 16 h 42 · compléments 16 h 49)

Projet Organigramme_Examen_Fédéral · coordination : Tunder · 18 agents de rédaction en 6 équipes de 3 · LOT_218 → LOT_007, ordre décroissant. LOT_219–248 hors périmètre ; LOT_001–006 audités par Tunder.

## 1. Équipes et membres

| Équipe | Plage | LOT | Rôle A — Appel A | Rôle B1 — Parties 1–2 (DX.1–5) | Rôle B2 — Parties 3–4 (DX.6–10) | Fichiers attendus |
|---|---|---|---|---|---|---|
| 1 | LOT_218 → LOT_184 | 35 | Agent 1 — Équipe 1 · Appel A (LOT_218–184) | Agent 3 — Équipe 1 · Appel B Parties 1–2 (LOT_218–184) | Agent 5 — Équipe 1 · Appel B Parties 3–4 (LOT_218–184) | 175 |
| 2 | LOT_183 → LOT_149 | 35 | Agent 9 — Équipe 2 · Appel A (LOT_183–149) | Agent 10 — Équipe 2 · Appel B Parties 1–2 (LOT_183–149) | Agent 7 — Équipe 2 · Appel B Parties 3–4 (LOT_183–149) | 175 |
| 3 | LOT_148 → LOT_114 | 35 | Agent 11 — Équipe 3 · Appel A (LOT_148–114) | Agent 12 — Équipe 3 · Appel B Parties 1–2 (LOT_148–114) | Agent 13 — Équipe 3 · Appel B Parties 3–4 (LOT_148–114) | 175 |
| 4 | LOT_113 → LOT_079 | 35 | Agent 2 — Équipe 4 · Appel A (LOT_113–079) | Agent 4 — Équipe 4 · Appel B Parties 1–2 (LOT_113–079) | Agent 6 — Équipe 4 · Appel B Parties 3–4 (LOT_113–079) | 175 |
| 5 | LOT_078 → LOT_043 | 36 | Agent 14 — Équipe 5 · Appel A (LOT_078–043) | Agent 15 — Équipe 5 · Appel B Parties 1–2 (LOT_078–043) | Agent 8 — Équipe 5 · Appel B Parties 3–4 (LOT_078–043) | 180 |
| 6 | LOT_042 → LOT_007 | 36 | Agent 16 — Équipe 6 · Appel A (LOT_042–007) | Agent 17 — Équipe 6 · Appel B Parties 1–2 (LOT_042–007) | Agent 18 — Équipe 6 · Appel B Parties 3–4 (LOT_042–007) | 180 |

## 2. Règles communes

- **Silence total** : aucun message à l'utilisateur ; aucun signal de dépôt ; seul un vrai blocage va à Tunder (une ligne, `SendToAgent`).
- **Règle de saut** : chaque agent saute tout LOT dont son fichier est déjà déposé sur Drive.
- **Transition (Agents 1–8)** : le fichier en cours sous l'ancien rôle est fini, puis l'agent passe au nouveau rôle. Fichiers de transition acceptés par les scripts : Agent 1 → LOT_213 Partie 1; Agent 2 → LOT_007 Appel A + Partie 1; Agent 4 → LOT_007 Partie 2; Agent 6 → LOT_007 Partie 3; Agent 8 → LOT_007 Partie 4.
- **Portes de dépôt** : S1A/S1B `check` = 0, S2A/S2B `review` = 0, `script_source.py check` = 0 (scripts en lecture seule, alertes seulement).
- **Charte V7+** : `.proba{color:#C8102E;font-weight:700}` sans halo ; bleu ciel à la place des 7 verts ; Atkinson Hyperlegible ; WCAG ≥ 4,5 ; fenêtres d'examen à onglets Principe / Interprétation.
- Point d'entrée de chaque agent : `/workspace/equipes/agent_N/DEMARRER.md` ; fil : `/workspace/equipes/agent_N/ETAT.md`.

## 3. Progression (jauges)

<!-- JAUGE:DEBUT -->
_Jauge générée le 2026-10-24 17:07 (Europe/Zurich) — origine : fichiers locaux /workspace/agentN (produit ≠ déposé)._

### Par équipe

| Équipe | Plage | LOT | Fichiers faits / attendus | Jauge |
|---|---|---|---|---|
| 1 | LOT_218–184 | 35 | 28 / 175 | `███░░░░░░░░░░░░░░░░░  16.0 %` |
| 2 | LOT_183–149 | 35 | 0 / 175 | `░░░░░░░░░░░░░░░░░░░░   0.0 %` |
| 3 | LOT_148–114 | 35 | 0 / 175 | `░░░░░░░░░░░░░░░░░░░░   0.0 %` |
| 4 | LOT_113–079 | 35 | 25 / 175 | `███░░░░░░░░░░░░░░░░░  14.3 %` |
| 5 | LOT_078–043 | 36 | 0 / 180 | `░░░░░░░░░░░░░░░░░░░░   0.0 %` |
| 6 | LOT_042–007 | 36 | 18 / 180 | `██░░░░░░░░░░░░░░░░░░  10.0 %` |
| **Total** | LOT_218–007 | 212 | **71 / 1060** | `█░░░░░░░░░░░░░░░░░░░   6.7 %` |

### Par agent

| Agent | Équipe | Rôle | Plage | Faits / attendus | En cours | Prochain fichier | Jauge |
|---|---|---|---|---|---|---|---|
| 1 | 1 | A | LOT_218–184 | 6 / 35 | 0 | LOT_212 Appel A | `██░░░░░░░░░░  17.1 %` |
| 2 | 4 | A | LOT_113–079 | 5 / 35 | 0 | LOT_113 Appel A | `██░░░░░░░░░░  14.3 %` |
| 3 | 1 | B1 | LOT_218–184 | 12 / 70 | 0 | LOT_212 Partie 1 | `██░░░░░░░░░░  17.1 %` |
| 4 | 4 | B1 | LOT_113–079 | 10 / 70 | 0 | LOT_113 Partie 1 | `██░░░░░░░░░░  14.3 %` |
| 5 | 1 | B2 | LOT_218–184 | 10 / 70 | 0 | LOT_213 Partie 3 | `██░░░░░░░░░░  14.3 %` |
| 6 | 4 | B2 | LOT_113–079 | 10 / 70 | 0 | LOT_113 Partie 3 | `██░░░░░░░░░░  14.3 %` |
| 7 | 2 | B2 | LOT_183–149 | 0 / 70 | 0 | LOT_183 Partie 3 | `░░░░░░░░░░░░   0.0 %` |
| 8 | 5 | B2 | LOT_078–043 | 0 / 72 | 0 | LOT_078 Partie 3 | `░░░░░░░░░░░░   0.0 %` |
| 9 | 2 | A | LOT_183–149 | 0 / 35 | 0 | LOT_183 Appel A | `░░░░░░░░░░░░   0.0 %` |
| 10 | 2 | B1 | LOT_183–149 | 0 / 70 | 0 | LOT_183 Partie 1 | `░░░░░░░░░░░░   0.0 %` |
| 11 | 3 | A | LOT_148–114 | 0 / 35 | 0 | LOT_148 Appel A | `░░░░░░░░░░░░   0.0 %` |
| 12 | 3 | B1 | LOT_148–114 | 0 / 70 | 0 | LOT_148 Partie 1 | `░░░░░░░░░░░░   0.0 %` |
| 13 | 3 | B2 | LOT_148–114 | 0 / 70 | 0 | LOT_148 Partie 3 | `░░░░░░░░░░░░   0.0 %` |
| 14 | 5 | A | LOT_078–043 | 0 / 36 | 0 | LOT_078 Appel A | `░░░░░░░░░░░░   0.0 %` |
| 15 | 5 | B1 | LOT_078–043 | 0 / 72 | 0 | LOT_078 Partie 1 | `░░░░░░░░░░░░   0.0 %` |
| 16 | 6 | A | LOT_042–007 | 4 / 36 | 0 | LOT_042 Appel A | `█░░░░░░░░░░░  11.1 %` |
| 17 | 6 | B1 | LOT_042–007 | 7 / 72 | 0 | LOT_042 Partie 1 | `█░░░░░░░░░░░   9.7 %` |
| 18 | 6 | B2 | LOT_042–007 | 7 / 72 | 0 | LOT_042 Partie 3 | `█░░░░░░░░░░░   9.7 %` |
<!-- JAUGE:FIN -->

## 4. LOT par LOT — Parties et état

Légende : ✔ = terminé localement (auteur entre parenthèses ; **produit ≠ déposé**, Drive non vérifié) · ○ = à faire. Agent responsable v1.6 indiqué dans l'en-tête de chaque équipe.

### Équipe 1 — LOT_218 → LOT_184 · A = Agent 1 · P1–P2 = Agent 3 · P3–P4 = Agent 5

| LOT | Appel A | Partie 1 | Partie 2 | Partie 3 | Partie 4 | Fichiers faits |
|---|---|---|---|---|---|---|
| LOT_218 | ✔ (1) | ✔ (1) | ✔ (3) | ✔ (5) | ✔ (7) | 5/5 |
| LOT_217 | ✔ (1) | ✔ (1) | ✔ (3) | ✔ (5) | ✔ (7) | 5/5 |
| LOT_216 | ✔ (1) | ✔ (1) | ✔ (3) | ✔ (5) | ✔ (7) | 5/5 |
| LOT_215 | ✔ (1) | ✔ (1) | ✔ (3) | ✔ (5) | ✔ (7) | 5/5 |
| LOT_214 | ✔ (1) | ✔ (1) | ✔ (3) | ✔ (5) | ✔ (7) | 5/5 |
| LOT_213 | ✔ (1) | ✔ (1) | ✔ (3) | ○ | ○ | 3/5 |
| LOT_212 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_211 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_210 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_209 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_208 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_207 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_206 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_205 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_204 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_203 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_202 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_201 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_200 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_199 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_198 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_197 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_196 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_195 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_194 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_193 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_192 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_191 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_190 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_189 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_188 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_187 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_186 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_185 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_184 | ○ | ○ | ○ | ○ | ○ | 0/5 |

### Équipe 2 — LOT_183 → LOT_149 · A = Agent 9 · P1–P2 = Agent 10 · P3–P4 = Agent 7

| LOT | Appel A | Partie 1 | Partie 2 | Partie 3 | Partie 4 | Fichiers faits |
|---|---|---|---|---|---|---|
| LOT_183 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_182 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_181 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_180 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_179 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_178 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_177 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_176 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_175 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_174 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_173 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_172 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_171 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_170 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_169 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_168 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_167 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_166 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_165 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_164 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_163 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_162 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_161 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_160 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_159 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_158 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_157 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_156 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_155 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_154 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_153 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_152 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_151 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_150 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_149 | ○ | ○ | ○ | ○ | ○ | 0/5 |

### Équipe 3 — LOT_148 → LOT_114 · A = Agent 11 · P1–P2 = Agent 12 · P3–P4 = Agent 13

| LOT | Appel A | Partie 1 | Partie 2 | Partie 3 | Partie 4 | Fichiers faits |
|---|---|---|---|---|---|---|
| LOT_148 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_147 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_146 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_145 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_144 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_143 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_142 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_141 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_140 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_139 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_138 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_137 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_136 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_135 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_134 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_133 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_132 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_131 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_130 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_129 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_128 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_127 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_126 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_125 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_124 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_123 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_122 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_121 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_120 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_119 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_118 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_117 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_116 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_115 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_114 | ○ | ○ | ○ | ○ | ○ | 0/5 |

### Équipe 4 — LOT_113 → LOT_079 · A = Agent 2 · P1–P2 = Agent 4 · P3–P4 = Agent 6

| LOT | Appel A | Partie 1 | Partie 2 | Partie 3 | Partie 4 | Fichiers faits |
|---|---|---|---|---|---|---|
| LOT_113 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_112 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_111 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_110 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_109 | ✔ (2) | ✔ (2) | ✔ (4) | ✔ (6) | ✔ (8) | 5/5 |
| LOT_108 | ✔ (2) | ✔ (2) | ✔ (4) | ✔ (6) | ✔ (8) | 5/5 |
| LOT_107 | ✔ (2) | ✔ (2) | ✔ (4) | ✔ (6) | ✔ (8) | 5/5 |
| LOT_106 | ✔ (2) | ✔ (2) | ✔ (4) | ✔ (6) | ✔ (8) | 5/5 |
| LOT_105 | ✔ (2) | ✔ (2) | ✔ (4) | ✔ (6) | ✔ (8) | 5/5 |
| LOT_104 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_103 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_102 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_101 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_100 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_099 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_098 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_097 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_096 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_095 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_094 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_093 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_092 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_091 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_090 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_089 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_088 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_087 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_086 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_085 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_084 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_083 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_082 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_081 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_080 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_079 | ○ | ○ | ○ | ○ | ○ | 0/5 |

### Équipe 5 — LOT_078 → LOT_043 · A = Agent 14 · P1–P2 = Agent 15 · P3–P4 = Agent 8

| LOT | Appel A | Partie 1 | Partie 2 | Partie 3 | Partie 4 | Fichiers faits |
|---|---|---|---|---|---|---|
| LOT_078 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_077 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_076 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_075 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_074 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_073 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_072 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_071 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_070 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_069 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_068 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_067 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_066 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_065 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_064 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_063 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_062 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_061 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_060 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_059 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_058 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_057 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_056 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_055 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_054 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_053 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_052 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_051 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_050 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_049 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_048 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_047 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_046 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_045 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_044 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_043 | ○ | ○ | ○ | ○ | ○ | 0/5 |

### Équipe 6 — LOT_042 → LOT_007 · A = Agent 16 · P1–P2 = Agent 17 · P3–P4 = Agent 18

| LOT | Appel A | Partie 1 | Partie 2 | Partie 3 | Partie 4 | Fichiers faits |
|---|---|---|---|---|---|---|
| LOT_042 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_041 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_040 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_039 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_038 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_037 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_036 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_035 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_034 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_033 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_032 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_031 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_030 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_029 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_028 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_027 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_026 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_025 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_024 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_023 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_022 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_021 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_020 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_019 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_018 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_017 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_016 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_015 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_014 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_013 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_012 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_011 | ○ | ○ | ○ | ○ | ○ | 0/5 |
| LOT_010 | ✔ (2) | ✔ (2) | ✔ (4) | ✔ (6) | ✔ (8) | 5/5 |
| LOT_009 | ✔ (2) | ✔ (2) | ✔ (4) | ✔ (6) | ✔ (8) | 5/5 |
| LOT_008 | ✔ (2) | ✔ (2) | ✔ (4) | ✔ (6) | ✔ (8) | 5/5 |
| LOT_007 | ✔ (2) | ✔ (2) | ○ | ○ | ✔ (8) | 3/5 |

## 5. Fichiers du dispositif

- Configurations : `/workspace/scripts_lots/agent_N/config.json` (générées par `generer_configs.py`).
- Scripts d'équipe : `/workspace/scripts_lots/equipes/S1A.py`, `S1B.py`, `S2A.py`, `S2B.py`.
- Instructions : `/workspace/instructions_agents/instructions_agent_N.md` (v1.6).
- Environnements : `/workspace/equipes/agent_N/` et `agent_N.zip` ; skills : `/workspace/reorg/skills/`.
- Jauge : `/workspace/equipes/jauge.py` (local par défaut ; `--drive LISTE.json` pour un relevé Drive fourni par Tunder).
