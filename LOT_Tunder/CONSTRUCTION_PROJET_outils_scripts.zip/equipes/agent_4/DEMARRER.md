# DÉMARRER — Agent 4 — Équipe 4 · Appel B Parties 1–2 (LOT_113–079)

> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `db322130-de1f-49d9-a669-bd9b54729c37`), en une ligne : `BLOCAGE · Agent 4 · LOT_X : <motif ≤ 8 mots>`. Le non-bloquant va dans `/workspace/agent4/POUR_TUNDER_AGENT_4.md`.

## 1. Identité
- **Nom** : Agent 4 — Équipe 4 · Appel B Parties 1–2 (LOT_113–079)
- **Équipe 4** : LOT_113 → LOT_079 (35 LOT, ordre décroissant) — A = Agent 2, B1 = Agent 4 (vous), B2 = Agent 6
- **Rôle B1** : l'Appel B Partie 1 (DX.1 à DX.2) puis l'Appel B Partie 2 (DX.3 à DX.5) — deux fichiers distincts par LOT.
- **Dossier de travail** : `/workspace/agent4/LOT_X/` · **fil** : `/workspace/equipes/agent_4/ETAT.md` · **config** : `/workspace/scripts_lots/agent_4/config.json` (ne pas modifier)
- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_4.md` (v1.6) — elles priment en cas de doute.

## 2. Transition (ancien rôle → nouveau rôle)
- Ancien rôle : Équipe 2 · Partie 2 (LOT_109 → LOT_001). **Vous finissez le fichier en cours sous l'ancien rôle, puis vous passez au nouveau rôle et à la nouvelle plage.**
- Fichier de transition accepté par vos scripts : LOT_007 Partie 2 → le finir, le contrôler, le déposer s'il n'est pas déjà sur Drive.
- Relevé local : Transition : vous finissez et déposez la Partie 2 du LOT_007 si vous l'aviez commencée (acceptée par vos scripts) ; si elle est déjà sur Drive ou jamais commencée, elle revient à l'Agent 17. LOT_109–105 sont faits. Ensuite vous commencez à LOT_113 : Partie 1 puis Partie 2.

## 3. Règle de saut
Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).

## 4. Liste exacte de vos fichiers (71 fichiers, dans cet ordre)
Dossier Drive parent « LOTS_Finaux avec statut » : `1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`. Le dossier `1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB` ne doit **jamais** être ouvert, listé ni lu.

| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |
|---|---|---|---|---|---|
| 1 | LOT_007 | Partie 2 (transition) | `LOT_007_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1DToymCzAnIP1BrJ0Oh7S8PWQ3ns5u4EB` | à faire |
| 2 | LOT_113 | Partie 1 | `LOT_113_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1FtcdPZoNKTwSG7e_WpZy3D3MB2p3b6-f` | à faire |
| 3 | LOT_113 | Partie 2 | `LOT_113_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1FtcdPZoNKTwSG7e_WpZy3D3MB2p3b6-f` | à faire |
| 4 | LOT_112 | Partie 1 | `LOT_112_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1PEVUqzfciEHuqVQ1BQRkFohFDvXNGb9A` | à faire |
| 5 | LOT_112 | Partie 2 | `LOT_112_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1PEVUqzfciEHuqVQ1BQRkFohFDvXNGb9A` | à faire |
| 6 | LOT_111 | Partie 1 | `LOT_111_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1NILNxoT93aer6Uke9u5Jfeu-KSIUI5wY` | à faire |
| 7 | LOT_111 | Partie 2 | `LOT_111_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1NILNxoT93aer6Uke9u5Jfeu-KSIUI5wY` | à faire |
| 8 | LOT_110 | Partie 1 | `LOT_110_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1j2bvbgwhPXgLlDJ5yitbGRk1utdY5SIx` | à faire |
| 9 | LOT_110 | Partie 2 | `LOT_110_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1j2bvbgwhPXgLlDJ5yitbGRk1utdY5SIx` | à faire |
| 10 | LOT_109 | Partie 1 | `LOT_109_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1wG_IpVps1QOte6LfretqwMzo0r5POh-x` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 11 | LOT_109 | Partie 2 | `LOT_109_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1wG_IpVps1QOte6LfretqwMzo0r5POh-x` | terminé localement par l'Agent 4 — vérifier Drive, sauter si déposé |
| 12 | LOT_108 | Partie 1 | `LOT_108_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1XzKWyB0l7DzLnnWEuovbZvV9an1IltZ-` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 13 | LOT_108 | Partie 2 | `LOT_108_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1XzKWyB0l7DzLnnWEuovbZvV9an1IltZ-` | terminé localement par l'Agent 4 — vérifier Drive, sauter si déposé |
| 14 | LOT_107 | Partie 1 | `LOT_107_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1FTPKTupMpz2iTu-ds_KuJW5IlznjSHSz` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 15 | LOT_107 | Partie 2 | `LOT_107_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1FTPKTupMpz2iTu-ds_KuJW5IlznjSHSz` | terminé localement par l'Agent 4 — vérifier Drive, sauter si déposé |
| 16 | LOT_106 | Partie 1 | `LOT_106_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1j2KZFw5CAKRUkoCkwHblMp9Xd_bwwvQu` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 17 | LOT_106 | Partie 2 | `LOT_106_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1j2KZFw5CAKRUkoCkwHblMp9Xd_bwwvQu` | terminé localement par l'Agent 4 — vérifier Drive, sauter si déposé |
| 18 | LOT_105 | Partie 1 | `LOT_105_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1tyntz5mFYEr4isSmwhbiWYqmHIndwLf7` | terminé localement par l'Agent 2 — vérifier Drive, sauter si déposé |
| 19 | LOT_105 | Partie 2 | `LOT_105_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1tyntz5mFYEr4isSmwhbiWYqmHIndwLf7` | terminé localement par l'Agent 4 — vérifier Drive, sauter si déposé |
| 20 | LOT_104 | Partie 1 | `LOT_104_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1XbL2VqM9mgtV6LqCYJIthRmDjSqs0W5n` | à faire |
| 21 | LOT_104 | Partie 2 | `LOT_104_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1XbL2VqM9mgtV6LqCYJIthRmDjSqs0W5n` | à faire |
| 22 | LOT_103 | Partie 1 | `LOT_103_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1hxfwoHf2nvd8VEsPA0jpJYjHVPyOCJiL` | à faire |
| 23 | LOT_103 | Partie 2 | `LOT_103_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1hxfwoHf2nvd8VEsPA0jpJYjHVPyOCJiL` | à faire |
| 24 | LOT_102 | Partie 1 | `LOT_102_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1JGzNz6vNbcbkehzcbs_LLhXXcoTMozh6` | à faire |
| 25 | LOT_102 | Partie 2 | `LOT_102_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1JGzNz6vNbcbkehzcbs_LLhXXcoTMozh6` | à faire |
| 26 | LOT_101 | Partie 1 | `LOT_101_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1Gm6LZE7CeNNTM-54cavJJDcIEmq34FfA` | à faire |
| 27 | LOT_101 | Partie 2 | `LOT_101_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1Gm6LZE7CeNNTM-54cavJJDcIEmq34FfA` | à faire |
| 28 | LOT_100 | Partie 1 | `LOT_100_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1WotUbz7y0fn9xaOG4ktN4kwKraDChuXl` | à faire |
| 29 | LOT_100 | Partie 2 | `LOT_100_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1WotUbz7y0fn9xaOG4ktN4kwKraDChuXl` | à faire |
| 30 | LOT_099 | Partie 1 | `LOT_099_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1Grq_ALPaINHLtPlrgImMhPw_C3EkZp9z` | à faire |
| 31 | LOT_099 | Partie 2 | `LOT_099_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1Grq_ALPaINHLtPlrgImMhPw_C3EkZp9z` | à faire |
| 32 | LOT_098 | Partie 1 | `LOT_098_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `18SFhq46cRV3r1YL1sYTu_n5Qd7wsVWTv` | à faire |
| 33 | LOT_098 | Partie 2 | `LOT_098_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `18SFhq46cRV3r1YL1sYTu_n5Qd7wsVWTv` | à faire |
| 34 | LOT_097 | Partie 1 | `LOT_097_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1wEW3SHrVGR7bAMYEECXayUDfmI47-TJB` | à faire |
| 35 | LOT_097 | Partie 2 | `LOT_097_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1wEW3SHrVGR7bAMYEECXayUDfmI47-TJB` | à faire |
| 36 | LOT_096 | Partie 1 | `LOT_096_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1qrX7L0LIw82P6di1JC3zsj4XW-PQsMTA` | à faire |
| 37 | LOT_096 | Partie 2 | `LOT_096_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1qrX7L0LIw82P6di1JC3zsj4XW-PQsMTA` | à faire |
| 38 | LOT_095 | Partie 1 | `LOT_095_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1-qNAP_qAXH-xWDKc5fWc95A4Mh0uSz7J` | à faire |
| 39 | LOT_095 | Partie 2 | `LOT_095_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1-qNAP_qAXH-xWDKc5fWc95A4Mh0uSz7J` | à faire |
| 40 | LOT_094 | Partie 1 | `LOT_094_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1OHKzUvLsB125bzYo4yooKmeF9QaWYRAW` | à faire |
| 41 | LOT_094 | Partie 2 | `LOT_094_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1OHKzUvLsB125bzYo4yooKmeF9QaWYRAW` | à faire |
| 42 | LOT_093 | Partie 1 | `LOT_093_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1jw40DUx7-akPBi_kG-I4g8ETsSqjha-q` | à faire |
| 43 | LOT_093 | Partie 2 | `LOT_093_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1jw40DUx7-akPBi_kG-I4g8ETsSqjha-q` | à faire |
| 44 | LOT_092 | Partie 1 | `LOT_092_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1mkd1fBjKz-kmaVcamOjFOaIrPdve4HfJ` | à faire |
| 45 | LOT_092 | Partie 2 | `LOT_092_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1mkd1fBjKz-kmaVcamOjFOaIrPdve4HfJ` | à faire |
| 46 | LOT_091 | Partie 1 | `LOT_091_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1I45DR9sPzPuKJFZn1DyMyMSe1d4xSj3A` | à faire |
| 47 | LOT_091 | Partie 2 | `LOT_091_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1I45DR9sPzPuKJFZn1DyMyMSe1d4xSj3A` | à faire |
| 48 | LOT_090 | Partie 1 | `LOT_090_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1Xn9DV5_iP3gmHRc1YyRonlPNLy-qRObo` | à faire |
| 49 | LOT_090 | Partie 2 | `LOT_090_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1Xn9DV5_iP3gmHRc1YyRonlPNLy-qRObo` | à faire |
| 50 | LOT_089 | Partie 1 | `LOT_089_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1ruyyDOPfXfrqIvs7SBABr2Y8UZT9x1Y5` | à faire |
| 51 | LOT_089 | Partie 2 | `LOT_089_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1ruyyDOPfXfrqIvs7SBABr2Y8UZT9x1Y5` | à faire |
| 52 | LOT_088 | Partie 1 | `LOT_088_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1MSkOQm-Db505_lfsCnbc7hzOcUiJBVjf` | à faire |
| 53 | LOT_088 | Partie 2 | `LOT_088_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1MSkOQm-Db505_lfsCnbc7hzOcUiJBVjf` | à faire |
| 54 | LOT_087 | Partie 1 | `LOT_087_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1sHCnvA0O-iXkD8FLTG0tghLnQOVOmzb6` | à faire |
| 55 | LOT_087 | Partie 2 | `LOT_087_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1sHCnvA0O-iXkD8FLTG0tghLnQOVOmzb6` | à faire |
| 56 | LOT_086 | Partie 1 | `LOT_086_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1RzMIJpVerCfD1RNOIzd96SAzcaCNpSom` | à faire |
| 57 | LOT_086 | Partie 2 | `LOT_086_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1RzMIJpVerCfD1RNOIzd96SAzcaCNpSom` | à faire |
| 58 | LOT_085 | Partie 1 | `LOT_085_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1tsRN-uY8vCkR6YlQ_ijhaW6R9nzY-MAN` | à faire |
| 59 | LOT_085 | Partie 2 | `LOT_085_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1tsRN-uY8vCkR6YlQ_ijhaW6R9nzY-MAN` | à faire |
| 60 | LOT_084 | Partie 1 | `LOT_084_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1aZZA3aVFEFcrFG7Xi0H4G6tmEaxDeCSr` | à faire |
| 61 | LOT_084 | Partie 2 | `LOT_084_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1aZZA3aVFEFcrFG7Xi0H4G6tmEaxDeCSr` | à faire |
| 62 | LOT_083 | Partie 1 | `LOT_083_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1-CD59ai6orLKf9oE8qS2hkwZJKJVPpyc` | à faire |
| 63 | LOT_083 | Partie 2 | `LOT_083_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1-CD59ai6orLKf9oE8qS2hkwZJKJVPpyc` | à faire |
| 64 | LOT_082 | Partie 1 | `LOT_082_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1iIJhQ1Vk-4A0w3iGg_EPaSa0rPfp6bRk` | à faire |
| 65 | LOT_082 | Partie 2 | `LOT_082_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1iIJhQ1Vk-4A0w3iGg_EPaSa0rPfp6bRk` | à faire |
| 66 | LOT_081 | Partie 1 | `LOT_081_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `16JTlFzlFkP2hH4Rc-PuV_fMGNyyhCLPg` | à faire |
| 67 | LOT_081 | Partie 2 | `LOT_081_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `16JTlFzlFkP2hH4Rc-PuV_fMGNyyhCLPg` | à faire |
| 68 | LOT_080 | Partie 1 | `LOT_080_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1OcokP7NTPEut6AXDsGWRKlSDQNSROQ-x` | à faire |
| 69 | LOT_080 | Partie 2 | `LOT_080_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1OcokP7NTPEut6AXDsGWRKlSDQNSROQ-x` | à faire |
| 70 | LOT_079 | Partie 1 | `LOT_079_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1Pg9xB3tWbgUVHNDSsj5dL2BgkyCwTcI7` | à faire |
| 71 | LOT_079 | Partie 2 | `LOT_079_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1Pg9xB3tWbgUVHNDSsj5dL2BgkyCwTcI7` | à faire |

Nom de dépôt sur Drive : « Agent_4 | LOT_X Partie 1 — <noms des différentiels>.html » ; « Agent_4 | LOT_X Partie 2 — <noms des différentiels>.html » (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.

## 5. Commandes (dans cet ordre, pour chaque fichier)
```
python3 /workspace/scripts_lots/equipes/S1B.py --agent 4 plan "<thème du LOT>" --dx "<DX de la Partie>"
python3 /workspace/scripts_lots/agent_4/script_source.py search "<requête>" --pec      # index local d'abord
python3 /workspace/scripts_lots/agent_4/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »
# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste
python3 /workspace/scripts_lots/equipes/S1B.py --agent 4 check /workspace/agent4/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/equipes/S2B.py --agent 4 review /workspace/agent4/LOT_X/<fichier>.html --appel-a <Appel A du LOT>.html   # doit renvoyer 0
python3 /workspace/scripts_lots/agent_4/script_source.py check /workspace/agent4/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/agent_4/script_synchrone.py review /workspace/agent4/LOT_X/<fichier>.html     # un seul passage LanguageTool
grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0
```
Raccourcis : `python3 /workspace/scripts_lots/agent_4/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.

## 6. Charte (rappel)
`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.

## 7. Skills
- `skills/performance-redaction-lot/SKILL.md` (→ `/workspace/reorg/skills/performance-redaction-lot/SKILL.md`)
- `skills/concentration-fil-redaction/SKILL.md` (→ `/workspace/reorg/skills/concentration-fil-redaction/SKILL.md`)
- `skills/anti-gaspillage-redaction/SKILL.md` (→ `/workspace/reorg/skills/anti-gaspillage-redaction/SKILL.md`)
- `skills/harness-redacteur-v7/SKILL.md` (→ `/workspace/reorg/skills/harness-redacteur-v7/SKILL.md`)

## 8. Après chaque dépôt
Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.
Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.

FIN_DEMARRER
