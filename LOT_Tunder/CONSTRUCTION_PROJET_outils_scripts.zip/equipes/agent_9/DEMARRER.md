# DÉMARRER — Agent 9 — Équipe 2 · Appel A (LOT_183–149)

> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `db322130-de1f-49d9-a669-bd9b54729c37`), en une ligne : `BLOCAGE · Agent 9 · LOT_X : <motif ≤ 8 mots>`. Le non-bloquant va dans `/workspace/agent9/POUR_TUNDER_AGENT_9.md`.

## 1. Identité
- **Nom** : Agent 9 — Équipe 2 · Appel A (LOT_183–149)
- **Équipe 2** : LOT_183 → LOT_149 (35 LOT, ordre décroissant) — A = Agent 9 (vous), B1 = Agent 10, B2 = Agent 7
- **Rôle A** : l'Appel A (plan et liste des 10 DX) — un fichier par LOT.
- **Dossier de travail** : `/workspace/agent9/LOT_X/` · **fil** : `/workspace/equipes/agent_9/ETAT.md` · **config** : `/workspace/scripts_lots/agent_9/config.json` (ne pas modifier)
- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_9.md` (v1.6) — elles priment en cas de doute.

## 2. Reprise
- Nouvel agent : vous commencez au premier LOT de votre plage (règle de saut appliquée).

## 3. Règle de saut
Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).

## 4. Liste exacte de vos fichiers (35 fichiers, dans cet ordre)
Dossier Drive parent « LOTS_Finaux avec statut » : `1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`. Le dossier `1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB` ne doit **jamais** être ouvert, listé ni lu.

| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |
|---|---|---|---|---|---|
| 1 | LOT_183 | Appel A | `LOT_183_Appel_A_V7_Plan_et_Liste.html` | `1GHkS8Q6q7lrFyhRF2jWeQsA6UVDFxjIO` | à faire |
| 2 | LOT_182 | Appel A | `LOT_182_Appel_A_V7_Plan_et_Liste.html` | `1lVWusB-mRqiiN3uC_r_oOIS9bA3Lw9kQ` | à faire |
| 3 | LOT_181 | Appel A | `LOT_181_Appel_A_V7_Plan_et_Liste.html` | `1a1nX38Jy7GiDyeVMlmIFvF_3C1v0udii` | à faire |
| 4 | LOT_180 | Appel A | `LOT_180_Appel_A_V7_Plan_et_Liste.html` | `1VYDdLPDhszAcsmE8Sz-BPTth-7KDAsfS` | à faire |
| 5 | LOT_179 | Appel A | `LOT_179_Appel_A_V7_Plan_et_Liste.html` | `1GevqZjSYHV2oQzPIxpbgtiSflSabeteo` | à faire |
| 6 | LOT_178 | Appel A | `LOT_178_Appel_A_V7_Plan_et_Liste.html` | `1OmYRcPLekvIi7R0ggdQFiPrePJgSrqCw` | à faire |
| 7 | LOT_177 | Appel A | `LOT_177_Appel_A_V7_Plan_et_Liste.html` | `1viSBS90An2z2qs5K4GyFV5ybPC9ZCmzV` | à faire |
| 8 | LOT_176 | Appel A | `LOT_176_Appel_A_V7_Plan_et_Liste.html` | `1f9LHUVT08S7Xt_jUGJebsrKT6tBd3jB2` | à faire |
| 9 | LOT_175 | Appel A | `LOT_175_Appel_A_V7_Plan_et_Liste.html` | `1x7tQxG73npQdpN7Rxm2Iys12jUT2OdF1` | à faire |
| 10 | LOT_174 | Appel A | `LOT_174_Appel_A_V7_Plan_et_Liste.html` | `1uHLq9_lyjcI76JJ07I9fj5ZpbOxW8CKv` | à faire |
| 11 | LOT_173 | Appel A | `LOT_173_Appel_A_V7_Plan_et_Liste.html` | `1vUHTQsFHiG2_KkFlCGfxywo0D6-t5Wpi` | à faire |
| 12 | LOT_172 | Appel A | `LOT_172_Appel_A_V7_Plan_et_Liste.html` | `1F-Go_n9OgIUdS_vvEByI3UGYQYlTlZMl` | à faire |
| 13 | LOT_171 | Appel A | `LOT_171_Appel_A_V7_Plan_et_Liste.html` | `1ZF_QHRYhBIfgF_HrJx-l4WXE3yFo7Pl2` | à faire |
| 14 | LOT_170 | Appel A | `LOT_170_Appel_A_V7_Plan_et_Liste.html` | `1pX8ORRXcJ3AbUxl6xWjK-p_aCjop8CSQ` | à faire |
| 15 | LOT_169 | Appel A | `LOT_169_Appel_A_V7_Plan_et_Liste.html` | `1ZDUbh14ejPwwdfmpoWG8NUHRfCn_NETO` | à faire |
| 16 | LOT_168 | Appel A | `LOT_168_Appel_A_V7_Plan_et_Liste.html` | `1UA6_K4KeiOUWhndavXdLaGoz2UbMJXVF` | à faire |
| 17 | LOT_167 | Appel A | `LOT_167_Appel_A_V7_Plan_et_Liste.html` | `1oirXa1YGM6XncCs1QVi6V0zQLsGE8LDo` | à faire |
| 18 | LOT_166 | Appel A | `LOT_166_Appel_A_V7_Plan_et_Liste.html` | `1kfpquRBfC9K8mBEj0RciJCddg0AHMr1L` | à faire |
| 19 | LOT_165 | Appel A | `LOT_165_Appel_A_V7_Plan_et_Liste.html` | `1Dct1O1RJ8msVQP1kHLTzipKdJItWlMMo` | à faire |
| 20 | LOT_164 | Appel A | `LOT_164_Appel_A_V7_Plan_et_Liste.html` | `1heIBH9Epp5jlc8ixpyWbqNt7CarPg2SI` | à faire |
| 21 | LOT_163 | Appel A | `LOT_163_Appel_A_V7_Plan_et_Liste.html` | `18cY2P8huEBu7AWVTwUdn6U7SQIYBvHYV` | à faire |
| 22 | LOT_162 | Appel A | `LOT_162_Appel_A_V7_Plan_et_Liste.html` | `1A9EUEXwCUGqTRXn0zbusAVO69hHwrJ60` | à faire |
| 23 | LOT_161 | Appel A | `LOT_161_Appel_A_V7_Plan_et_Liste.html` | `15lhtuwMYEi2SKc-gD9TmWg_ao2sWHbI9` | à faire |
| 24 | LOT_160 | Appel A | `LOT_160_Appel_A_V7_Plan_et_Liste.html` | `1ChPn1a0ahdeYLOp9oF12n1UsdNrI82BN` | à faire |
| 25 | LOT_159 | Appel A | `LOT_159_Appel_A_V7_Plan_et_Liste.html` | `1SuI-E71uCtN0FNe3kGkAbeE48h5Ot0Lz` | à faire |
| 26 | LOT_158 | Appel A | `LOT_158_Appel_A_V7_Plan_et_Liste.html` | `1iSa8BiMJnlaCf-BYI14_9JXo-smKjvOW` | à faire |
| 27 | LOT_157 | Appel A | `LOT_157_Appel_A_V7_Plan_et_Liste.html` | `1z42xo9yIeVVwGIE6L616GFV-mmXsFP3O` | à faire |
| 28 | LOT_156 | Appel A | `LOT_156_Appel_A_V7_Plan_et_Liste.html` | `1Dx4LCKIfey7qJUVd7EvSIwn9xOt3faPY` | à faire |
| 29 | LOT_155 | Appel A | `LOT_155_Appel_A_V7_Plan_et_Liste.html` | `1vk3umEdgv85piUvBGHiGi8WsOvOFUFuy` | à faire |
| 30 | LOT_154 | Appel A | `LOT_154_Appel_A_V7_Plan_et_Liste.html` | `185h0kdB9AXlb2yCs2OJXa-hhMNKixDbq` | à faire |
| 31 | LOT_153 | Appel A | `LOT_153_Appel_A_V7_Plan_et_Liste.html` | `1mLRzE5UOYerk6locWK0oKw_5Jqx5uU5z` | à faire |
| 32 | LOT_152 | Appel A | `LOT_152_Appel_A_V7_Plan_et_Liste.html` | `1TpF17KZXRYHYKvxVDq5zDL3OoXVC-DDq` | à faire |
| 33 | LOT_151 | Appel A | `LOT_151_Appel_A_V7_Plan_et_Liste.html` | `1nnrgDNdUiGXxgRHx4PfcQDqsIeKPZE2n` | à faire |
| 34 | LOT_150 | Appel A | `LOT_150_Appel_A_V7_Plan_et_Liste.html` | `1gsMAT_j3stL68bR4kuFTgehYyB9_JUDq` | à faire |
| 35 | LOT_149 | Appel A | `LOT_149_Appel_A_V7_Plan_et_Liste.html` | `11n1jaP1dx5DerINufW42_cLMAdwUlujA` | à faire |

Nom de dépôt sur Drive : « Agent_9 | LOT_X Appel A — Plan et liste des différentiels.html » (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.

## 5. Commandes (dans cet ordre, pour chaque fichier)
```
python3 /workspace/scripts_lots/equipes/S1A.py --agent 9 plan "<thème du LOT>"
python3 /workspace/scripts_lots/agent_9/script_source.py search "<requête>" --pec      # index local d'abord
python3 /workspace/scripts_lots/agent_9/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »
# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste
python3 /workspace/scripts_lots/equipes/S1A.py --agent 9 check /workspace/agent9/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/equipes/S2A.py --agent 9 review /workspace/agent9/LOT_X/<fichier>.html   # doit renvoyer 0
python3 /workspace/scripts_lots/agent_9/script_source.py check /workspace/agent9/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/agent_9/script_synchrone.py review /workspace/agent9/LOT_X/<fichier>.html     # un seul passage LanguageTool
grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0
```
Raccourcis : `python3 /workspace/scripts_lots/agent_9/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.

## 6. Charte (rappel)
`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.

## 7. Skills
- `skills/performance-redaction-lot/SKILL.md` (→ `/workspace/reorg/skills/performance-redaction-lot/SKILL.md`)
- `skills/concentration-fil-redaction/SKILL.md` (→ `/workspace/reorg/skills/concentration-fil-redaction/SKILL.md`)
- `skills/anti-gaspillage-redaction/SKILL.md` (→ `/workspace/reorg/skills/anti-gaspillage-redaction/SKILL.md`)
- `skills/harness-redacteur-v7/SKILL.md` (→ `/workspace/reorg/skills/harness-redacteur-v7/SKILL.md`)

## 8. Après chaque dépôt
Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.
Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.

FIN_DEMARRER
