# DÉMARRER — Agent 10 — Équipe 2 · Appel B Parties 1–2 (LOT_183–149)

> **RÈGLE N° 1 — SILENCE TOTALE.** Aucun message à l'utilisateur, jamais (ni dépôt, ni accusé, ni question). Aucun signal de dépôt à personne : Tunder suit Drive. Seule exception : un **vrai blocage**, à Tunder seul (`SendToAgent`, agent id `db322130-de1f-49d9-a669-bd9b54729c37`), en une ligne : `BLOCAGE · Agent 10 · LOT_X : <motif ≤ 8 mots>`. Le non-bloquant va dans `/workspace/agent10/POUR_TUNDER_AGENT_10.md`.

## 1. Identité
- **Nom** : Agent 10 — Équipe 2 · Appel B Parties 1–2 (LOT_183–149)
- **Équipe 2** : LOT_183 → LOT_149 (35 LOT, ordre décroissant) — A = Agent 9, B1 = Agent 10 (vous), B2 = Agent 7
- **Rôle B1** : l'Appel B Partie 1 (DX.1 à DX.2) puis l'Appel B Partie 2 (DX.3 à DX.5) — deux fichiers distincts par LOT.
- **Dossier de travail** : `/workspace/agent10/LOT_X/` · **fil** : `/workspace/equipes/agent_10/ETAT.md` · **config** : `/workspace/scripts_lots/agent_10/config.json` (ne pas modifier)
- **Instructions complètes** : `/workspace/instructions_agents/instructions_agent_10.md` (v1.6) — elles priment en cas de doute.

## 2. Reprise
- Nouvel agent : vous commencez au premier LOT de votre plage (règle de saut appliquée).

## 3. Règle de saut
Avant chaque LOT : lister le sous-dossier Drive du LOT (identifiant ci-dessous). Si votre fichier y est déjà, vous le **sautez** et vous l'inscrivez dans ETAT.md. Rôle B : tant que l'Appel A du LOT n'est pas sur Drive, vous ne faites que réunir des sources (revérifier toutes les 10 minutes environ).

## 4. Liste exacte de vos fichiers (70 fichiers, dans cet ordre)
Dossier Drive parent « LOTS_Finaux avec statut » : `1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`. Le dossier `1sY8ed56jWj1su0imvX-dk6mVb_sGTFoB` ne doit **jamais** être ouvert, listé ni lu.

| # | LOT | Fichier(s) | Nom local V7 | Sous-dossier Drive (id) | État au 2026-10-24 17 h (local, Drive non vérifié) |
|---|---|---|---|---|---|
| 1 | LOT_183 | Partie 1 | `LOT_183_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1GHkS8Q6q7lrFyhRF2jWeQsA6UVDFxjIO` | à faire |
| 2 | LOT_183 | Partie 2 | `LOT_183_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1GHkS8Q6q7lrFyhRF2jWeQsA6UVDFxjIO` | à faire |
| 3 | LOT_182 | Partie 1 | `LOT_182_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1lVWusB-mRqiiN3uC_r_oOIS9bA3Lw9kQ` | à faire |
| 4 | LOT_182 | Partie 2 | `LOT_182_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1lVWusB-mRqiiN3uC_r_oOIS9bA3Lw9kQ` | à faire |
| 5 | LOT_181 | Partie 1 | `LOT_181_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1a1nX38Jy7GiDyeVMlmIFvF_3C1v0udii` | à faire |
| 6 | LOT_181 | Partie 2 | `LOT_181_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1a1nX38Jy7GiDyeVMlmIFvF_3C1v0udii` | à faire |
| 7 | LOT_180 | Partie 1 | `LOT_180_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1VYDdLPDhszAcsmE8Sz-BPTth-7KDAsfS` | à faire |
| 8 | LOT_180 | Partie 2 | `LOT_180_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1VYDdLPDhszAcsmE8Sz-BPTth-7KDAsfS` | à faire |
| 9 | LOT_179 | Partie 1 | `LOT_179_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1GevqZjSYHV2oQzPIxpbgtiSflSabeteo` | à faire |
| 10 | LOT_179 | Partie 2 | `LOT_179_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1GevqZjSYHV2oQzPIxpbgtiSflSabeteo` | à faire |
| 11 | LOT_178 | Partie 1 | `LOT_178_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1OmYRcPLekvIi7R0ggdQFiPrePJgSrqCw` | à faire |
| 12 | LOT_178 | Partie 2 | `LOT_178_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1OmYRcPLekvIi7R0ggdQFiPrePJgSrqCw` | à faire |
| 13 | LOT_177 | Partie 1 | `LOT_177_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1viSBS90An2z2qs5K4GyFV5ybPC9ZCmzV` | à faire |
| 14 | LOT_177 | Partie 2 | `LOT_177_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1viSBS90An2z2qs5K4GyFV5ybPC9ZCmzV` | à faire |
| 15 | LOT_176 | Partie 1 | `LOT_176_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1f9LHUVT08S7Xt_jUGJebsrKT6tBd3jB2` | à faire |
| 16 | LOT_176 | Partie 2 | `LOT_176_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1f9LHUVT08S7Xt_jUGJebsrKT6tBd3jB2` | à faire |
| 17 | LOT_175 | Partie 1 | `LOT_175_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1x7tQxG73npQdpN7Rxm2Iys12jUT2OdF1` | à faire |
| 18 | LOT_175 | Partie 2 | `LOT_175_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1x7tQxG73npQdpN7Rxm2Iys12jUT2OdF1` | à faire |
| 19 | LOT_174 | Partie 1 | `LOT_174_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1uHLq9_lyjcI76JJ07I9fj5ZpbOxW8CKv` | à faire |
| 20 | LOT_174 | Partie 2 | `LOT_174_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1uHLq9_lyjcI76JJ07I9fj5ZpbOxW8CKv` | à faire |
| 21 | LOT_173 | Partie 1 | `LOT_173_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1vUHTQsFHiG2_KkFlCGfxywo0D6-t5Wpi` | à faire |
| 22 | LOT_173 | Partie 2 | `LOT_173_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1vUHTQsFHiG2_KkFlCGfxywo0D6-t5Wpi` | à faire |
| 23 | LOT_172 | Partie 1 | `LOT_172_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1F-Go_n9OgIUdS_vvEByI3UGYQYlTlZMl` | à faire |
| 24 | LOT_172 | Partie 2 | `LOT_172_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1F-Go_n9OgIUdS_vvEByI3UGYQYlTlZMl` | à faire |
| 25 | LOT_171 | Partie 1 | `LOT_171_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1ZF_QHRYhBIfgF_HrJx-l4WXE3yFo7Pl2` | à faire |
| 26 | LOT_171 | Partie 2 | `LOT_171_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1ZF_QHRYhBIfgF_HrJx-l4WXE3yFo7Pl2` | à faire |
| 27 | LOT_170 | Partie 1 | `LOT_170_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1pX8ORRXcJ3AbUxl6xWjK-p_aCjop8CSQ` | à faire |
| 28 | LOT_170 | Partie 2 | `LOT_170_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1pX8ORRXcJ3AbUxl6xWjK-p_aCjop8CSQ` | à faire |
| 29 | LOT_169 | Partie 1 | `LOT_169_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1ZDUbh14ejPwwdfmpoWG8NUHRfCn_NETO` | à faire |
| 30 | LOT_169 | Partie 2 | `LOT_169_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1ZDUbh14ejPwwdfmpoWG8NUHRfCn_NETO` | à faire |
| 31 | LOT_168 | Partie 1 | `LOT_168_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1UA6_K4KeiOUWhndavXdLaGoz2UbMJXVF` | à faire |
| 32 | LOT_168 | Partie 2 | `LOT_168_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1UA6_K4KeiOUWhndavXdLaGoz2UbMJXVF` | à faire |
| 33 | LOT_167 | Partie 1 | `LOT_167_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1oirXa1YGM6XncCs1QVi6V0zQLsGE8LDo` | à faire |
| 34 | LOT_167 | Partie 2 | `LOT_167_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1oirXa1YGM6XncCs1QVi6V0zQLsGE8LDo` | à faire |
| 35 | LOT_166 | Partie 1 | `LOT_166_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1kfpquRBfC9K8mBEj0RciJCddg0AHMr1L` | à faire |
| 36 | LOT_166 | Partie 2 | `LOT_166_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1kfpquRBfC9K8mBEj0RciJCddg0AHMr1L` | à faire |
| 37 | LOT_165 | Partie 1 | `LOT_165_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1Dct1O1RJ8msVQP1kHLTzipKdJItWlMMo` | à faire |
| 38 | LOT_165 | Partie 2 | `LOT_165_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1Dct1O1RJ8msVQP1kHLTzipKdJItWlMMo` | à faire |
| 39 | LOT_164 | Partie 1 | `LOT_164_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1heIBH9Epp5jlc8ixpyWbqNt7CarPg2SI` | à faire |
| 40 | LOT_164 | Partie 2 | `LOT_164_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1heIBH9Epp5jlc8ixpyWbqNt7CarPg2SI` | à faire |
| 41 | LOT_163 | Partie 1 | `LOT_163_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `18cY2P8huEBu7AWVTwUdn6U7SQIYBvHYV` | à faire |
| 42 | LOT_163 | Partie 2 | `LOT_163_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `18cY2P8huEBu7AWVTwUdn6U7SQIYBvHYV` | à faire |
| 43 | LOT_162 | Partie 1 | `LOT_162_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1A9EUEXwCUGqTRXn0zbusAVO69hHwrJ60` | à faire |
| 44 | LOT_162 | Partie 2 | `LOT_162_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1A9EUEXwCUGqTRXn0zbusAVO69hHwrJ60` | à faire |
| 45 | LOT_161 | Partie 1 | `LOT_161_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `15lhtuwMYEi2SKc-gD9TmWg_ao2sWHbI9` | à faire |
| 46 | LOT_161 | Partie 2 | `LOT_161_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `15lhtuwMYEi2SKc-gD9TmWg_ao2sWHbI9` | à faire |
| 47 | LOT_160 | Partie 1 | `LOT_160_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1ChPn1a0ahdeYLOp9oF12n1UsdNrI82BN` | à faire |
| 48 | LOT_160 | Partie 2 | `LOT_160_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1ChPn1a0ahdeYLOp9oF12n1UsdNrI82BN` | à faire |
| 49 | LOT_159 | Partie 1 | `LOT_159_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1SuI-E71uCtN0FNe3kGkAbeE48h5Ot0Lz` | à faire |
| 50 | LOT_159 | Partie 2 | `LOT_159_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1SuI-E71uCtN0FNe3kGkAbeE48h5Ot0Lz` | à faire |
| 51 | LOT_158 | Partie 1 | `LOT_158_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1iSa8BiMJnlaCf-BYI14_9JXo-smKjvOW` | à faire |
| 52 | LOT_158 | Partie 2 | `LOT_158_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1iSa8BiMJnlaCf-BYI14_9JXo-smKjvOW` | à faire |
| 53 | LOT_157 | Partie 1 | `LOT_157_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1z42xo9yIeVVwGIE6L616GFV-mmXsFP3O` | à faire |
| 54 | LOT_157 | Partie 2 | `LOT_157_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1z42xo9yIeVVwGIE6L616GFV-mmXsFP3O` | à faire |
| 55 | LOT_156 | Partie 1 | `LOT_156_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1Dx4LCKIfey7qJUVd7EvSIwn9xOt3faPY` | à faire |
| 56 | LOT_156 | Partie 2 | `LOT_156_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1Dx4LCKIfey7qJUVd7EvSIwn9xOt3faPY` | à faire |
| 57 | LOT_155 | Partie 1 | `LOT_155_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1vk3umEdgv85piUvBGHiGi8WsOvOFUFuy` | à faire |
| 58 | LOT_155 | Partie 2 | `LOT_155_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1vk3umEdgv85piUvBGHiGi8WsOvOFUFuy` | à faire |
| 59 | LOT_154 | Partie 1 | `LOT_154_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `185h0kdB9AXlb2yCs2OJXa-hhMNKixDbq` | à faire |
| 60 | LOT_154 | Partie 2 | `LOT_154_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `185h0kdB9AXlb2yCs2OJXa-hhMNKixDbq` | à faire |
| 61 | LOT_153 | Partie 1 | `LOT_153_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1mLRzE5UOYerk6locWK0oKw_5Jqx5uU5z` | à faire |
| 62 | LOT_153 | Partie 2 | `LOT_153_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1mLRzE5UOYerk6locWK0oKw_5Jqx5uU5z` | à faire |
| 63 | LOT_152 | Partie 1 | `LOT_152_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1TpF17KZXRYHYKvxVDq5zDL3OoXVC-DDq` | à faire |
| 64 | LOT_152 | Partie 2 | `LOT_152_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1TpF17KZXRYHYKvxVDq5zDL3OoXVC-DDq` | à faire |
| 65 | LOT_151 | Partie 1 | `LOT_151_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1nnrgDNdUiGXxgRHx4PfcQDqsIeKPZE2n` | à faire |
| 66 | LOT_151 | Partie 2 | `LOT_151_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1nnrgDNdUiGXxgRHx4PfcQDqsIeKPZE2n` | à faire |
| 67 | LOT_150 | Partie 1 | `LOT_150_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `1gsMAT_j3stL68bR4kuFTgehYyB9_JUDq` | à faire |
| 68 | LOT_150 | Partie 2 | `LOT_150_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `1gsMAT_j3stL68bR4kuFTgehYyB9_JUDq` | à faire |
| 69 | LOT_149 | Partie 1 | `LOT_149_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | `11n1jaP1dx5DerINufW42_cLMAdwUlujA` | à faire |
| 70 | LOT_149 | Partie 2 | `LOT_149_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | `11n1jaP1dx5DerINufW42_cLMAdwUlujA` | à faire |

Nom de dépôt sur Drive : « Agent_10 | LOT_X Partie 1 — <noms des différentiels>.html » ; « Agent_10 | LOT_X Partie 2 — <noms des différentiels>.html » (`LOT_X` sans zéros de tête dans ce nom). Localement, le nom V7 ci-dessus.

## 5. Commandes (dans cet ordre, pour chaque fichier)
```
python3 /workspace/scripts_lots/equipes/S1B.py --agent 10 plan "<thème du LOT>" --dx "<DX de la Partie>"
python3 /workspace/scripts_lots/agent_10/script_source.py search "<requête>" --pec      # index local d'abord
python3 /workspace/scripts_lots/agent_10/script_source.py crawl --domaines <d1,d2> --max-pages 40   # si « À CRAWLER »
# … rédaction + chaîne gen_v7 → inserer_fenetres → mobile → sigles → charte_v7plus → verif_v7 → score → contraste
python3 /workspace/scripts_lots/equipes/S1B.py --agent 10 check /workspace/agent10/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/equipes/S2B.py --agent 10 review /workspace/agent10/LOT_X/<fichier>.html --appel-a <Appel A du LOT>.html   # doit renvoyer 0
python3 /workspace/scripts_lots/agent_10/script_source.py check /workspace/agent10/LOT_X/<fichier>.html        # doit renvoyer 0
python3 /workspace/scripts_lots/agent_10/script_synchrone.py review /workspace/agent10/LOT_X/<fichier>.html     # un seul passage LanguageTool
grep -ciE '#FF2400|#edf7f4|#f2faf7|#dff1e9|#d8e8e2|#e3ece8|#aacfc3|#b2c9c0' <fichier>.html                # doit renvoyer 0
```
Raccourcis : `python3 /workspace/scripts_lots/agent_10/S1.py …` et `S2.py …`. Codes : 0 conforme · 1 bloquant · 2 pas votre fichier · 3 fichier modifié pendant la lecture. S1/S2 sont en lecture seule : ils alertent, ils ne corrigent rien.

## 6. Charte (rappel)
`.proba{color:#C8102E;font-weight:700}` sans halo (la ligne #FF2400 de la charte est obsolète) · aucun des 7 verts : #edf7f4→#eaf4fb, #f2faf7→#f1f8fd, #dff1e9→#dceef9, #d8e8e2→#d6e6f1, #e3ece8→#e2ebf2, #aacfc3→#a8cbe2, #b2c9c0→#b2c7d6 · Atkinson Hyperlegible · contraste WCAG ≥ 4,5 · fenêtres d'examen cliquables à onglets Principe / Interprétation · ≤ 4 phrases par point.

## 7. Skills
- `skills/performance-redaction-lot/SKILL.md` (→ `/workspace/reorg/skills/performance-redaction-lot/SKILL.md`)
- `skills/concentration-fil-redaction/SKILL.md` (→ `/workspace/reorg/skills/concentration-fil-redaction/SKILL.md`)
- `skills/anti-gaspillage-redaction/SKILL.md` (→ `/workspace/reorg/skills/anti-gaspillage-redaction/SKILL.md`)
- `skills/harness-redacteur-v7/SKILL.md` (→ `/workspace/reorg/skills/harness-redacteur-v7/SKILL.md`)

## 8. Après chaque dépôt
Vérifier la taille sur Drive (identique octet pour octet), écrire une ligne dans ETAT.md, **n'envoyer aucun message**, passer au fichier suivant.
Progression (lecture locale) : `python3 /workspace/equipes/jauge.py`.

FIN_DEMARRER
