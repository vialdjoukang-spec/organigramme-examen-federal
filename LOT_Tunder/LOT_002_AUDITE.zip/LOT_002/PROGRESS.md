# LOT_002 — progression (24.10.2026)
- [x] Appel A (SSP + Bloc 2) - [x] DX.1 - [x] DX.2 - [x] DX.3 - [x] DX.4 - [x] DX.5 - [x] DX.6 - [x] DX.7 - [x] DX.8 - [x] DX.9 - [x] DX.10
- [x] Scores proxy 98,8 % partout ; verif_v7 OK ; 33 captures ; RAPPORT_AUDIT.md ; MANIFEST.sha256
Reconstruction : `bash source/rebuild_all.sh`. Voir RAPPORT_AUDIT.md (chiffres à vérifier).
