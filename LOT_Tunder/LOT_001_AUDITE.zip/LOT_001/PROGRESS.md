# LOT_001 — progression de la correction complète (run du 24.10.2026, après validation du pilote DX.6)
Méthode : un générateur par DX (corriges/LOT_001/source/gen_<pref>.py) qui importe outils/gen_v7.py ; produire() → inserer → mobile → sigles ; découpage auto.
Sources originales extraites : source/src_P1..P4.py (outils/sources_orig.py). Bibliothèque : +20 fragments (donnees_sup.py) → 76.
Mobile : outils/mobile.py (cartes ≤ 640 px + typographie fine insécable) — ajouté à rebuild DX6.
## État
- [x] Tâche 1 mobile (DX6 reconstruit)
- [ ] DX.1 SCA   - [ ] DX.2 Hypoglycémie  - [ ] DX.3 Endocardite  - [ ] DX.4 Hyperhidrose focale primaire  - [ ] DX.5 SVM ménopause
- [ ] DX.7 Tuberculose  - [ ] DX.8 VIH  - [ ] DX.9 Hodgkin  - [ ] DX.10 Phéochromocytome
- [ ] Appel A (SSP + bloc 2 liste)  - [ ] Validation_et_Audit (document méta : à traiter ?)
## Chiffres à vérifier (cumul)

## DX.1 SCA — FAIT (24.10.2026)
- Fichier : LOT_001_DX1_Syndrome_coronarien_aigu_AUDITÉ.html (fichier unique < 200 Ko) ; score 98,8 % ; 59 fenêtres d’examen cliquables.
- Chiffres à vérifier : seuils ST ESC 2023 ; hs-TnT Roche 0 h/1 h (5/12/3/52/5 ng/L) ; VPN > 99 %, VPP ≈ 70 % ; sensibilité de l’ECG initial ≈ 50 % ; mortalité hospitalière du STEMI 4–12 % ; choc 5–10 % ; doses AIPS (AAS, ticagrelor, prasugrel, clopidogrel, énoxaparine, HNF, fondaparinux, ténectéplase, nitroglycérine, atorvastatine, métoprolol, ramipril, éplérénone) ; arrêt de travail 2–6 semaines (ordre de grandeur, ajouté par l’audit) ; délai de conduite (OAC annexe 1, non chiffré précisément) ; ESUR (DFGe < 30 en intra-artériel) ; seuils CK > 5 × LSN, ALAT > 3 × LSN.

## DX.2 Hypoglycémie — FAIT
- Fichier : LOT_001_DX2_Hypoglycemie_AUDITÉ.html ; score 98,8 %.
- Chiffres à vérifier : diabète déclaré en Suisse ≈ 5 % / ≈ 500 000 (OFS ESS 2022, ajouté par l’audit) ; IDF Europe 61 M ; mortalité ≈ ×2 après hypoglycémie sévère (ADVANCE) ; insulinome 1–4/million/an ; seuils de l’Endocrine Society 2009 (insuline ≥ 3 µU/mL, peptide C ≥ 0,6 ng/mL, pro-insuline ≥ 5 pmol/L, β-OHB ≤ 2,7 mmol/L, Δglycémie ≥ 1,4 mmol/L) ; sensibilité de l’épreuve de jeûne de 72 h 95–99 % ; échoendoscopie 80–90 % ; erreur du lecteur capillaire 10–15 % ; seuils du jeûne (< 3,3 → mesures toutes les 1–2 h ; arrêt < 2,5 avec neuroglucopénie : reformulés d’après la fiche 2019) ; HUG 15/30 g, 32 g de G40 % en 3–5 min ; GlucaGen 1/0,5 mg (seuil 25 kg / 6–8 ans) ; Baqsimi 3 mg dès 1 an ; Diamicron ≥ 48 h, Glimeryl ≥ 24 h (12–72 h) ; temps sous la cible < 4 % / < 1 % (consensus TIR) ; conduite : 45 min, 5 mmol/L (SSED/SSML 2025) ; risque ×6 avec les hypoglycémies non ressenties ; octréotide (sans dose).

## DX.3 Endocardite infectieuse — AUDITÉ (185 526 o, proxy 98.8 %)
Chiffres / doses à vérifier (ajoutés ou reformulés lors de l’audit) :
- Incidence européenne 3–10/100 000/an ; mortalité EURO-ENDO ≈ 17 % ; survie à 1 an > 70 % ; récidive 2–9 % ; chirurgie ≈ 50 %.
- Fièvre ≈ 90 %, souffle ≈ 85 %, signes cutanés < 10–20 % ; hémocultures positives 85–90 %.
- Sensibilités ETT ≈ 70 % (native) / 50 % (prothèse), ETO ≈ 96 % / 92 %, spécificité ≈ 90 %.
- Critères ESC 2023 (Coxiella IgG phase I > 1/800 ; TEP > 3 mois post-implantation ; exclusion ≤ 4 jours).
- Seuils chirurgicaux : < 24 h (œdème/choc), 3–5 jours ; végétation ≥ 10 mm, > 30 mm ; hémocultures > 7 jours.
- Doses ESC (non AIPS, à vérifier contre les corrigenda 2023/2025) : amoxicilline 100–200 mg/kg/j ; flucloxacilline 12 g/j ; ceftriaxone 2 g/j ou 2 g/12 h (E. faecalis) ; rifampicine après 3–5 jours ; schéma empirique amoxicilline + ceftriaxone/flucloxacilline ; vancomycine + gentamicine (prothèse précoce).
- Vancomycine 15–20 mg/kg/8–12 h, charge 25–30 mg/kg, ClCr 20–49 : 15–20 mg/kg/24 h (AIPS à vérifier) ; gentamicine 3 (–5) mg/kg/j.
- Durées 2–6 semaines (native), ≥ 6 semaines (prothèse) ; relais oral après ≥ 10 jours IV (POET).
- Prophylaxie suisse amoxicilline 2 g / 50 mg/kg (≤ 2 g) 1 h avant ; FI Sandoz 3 g ; alternative allergie non chiffrée (à préciser selon SMW 2025).
- LAMal art. 31 (soins dentaires liés à une maladie grave) — à vérifier ; OAC annexe 1.
- Jeûne TEP ≥ 6 h ; HUG : 2 paires d’hémocultures puis antibiotique dans l’heure en sepsis.

## DX.4 Hyperhidrose focale primaire — AUDITÉ (103 270 o, proxy 98.8 %)
Chiffres / doses à vérifier :
- Prévalence 2–4 % (USZ), ≈ 3 % (HUG) ; début 6–16 ans ; règle suisse 2017 (> 6 mois + 4/7 critères) ; HDSS 1–4.
- Gravimétrie ≥ 50 mg/aisselle/5 min (seuil d’étude) ; TSH < 0,4 mU/L (repère).
- Axhidrox® 2 pressions/aisselle = 540 mg crème, 4,4 mg glycopyrronium ; 1×/j 4 sem puis 2×/sem ; 31 traitements ; DFGe < 30 prudence ; non établi < 18 / > 65 ans.
- BOTOX® 50 U/aisselle, 100 U/4,0 mL, sites 1–2 cm, ≥ 16 semaines, effet 4–7 mois ; Dysport® 100 U/aisselle, 10 × 10 U, ≥ 12 semaines.
- Ajouts d’audit : chlorure d’aluminium 10–30 % (AWMF, à vérifier) ; ionophorèse 20–30 min, puis 1–2×/sem ; pacemaker = contre-indication de l’ionophorèse ; oxybutynine hors indication en Suisse ; arrêt de travail « quelques jours » après chirurgie ; remboursement LS à vérifier pour Botox/Axhidrox.

## DX.5 Ménopause (SVM) — AUDITÉ, 98,8 %
## DX.6 Hyperthyroïdie — AUDITÉ (_a/_b), 98,8 % (pilote validé)
## DX.7 Tuberculose — AUDITÉ, 98,8 %
- À vérifier : Xpert Se 91 % / Spé 96 % ; microscopie 50–60 % ; VIH 4/100 000 ; sarcoïdose ; Rimstar pendant la grossesse.
## DX.8 VIH — AUDITÉ, 98,8 %
- À vérifier : ECDC 5/100 000 ; sensibilité du test de 4e génération > 99 % ; CD4 < 200 ; PEP dans les 72 h.
## DX.9 Lymphome de Hodgkin — AUDITÉ, 98,8 %
- À vérifier : seuils EHA ; Adcetris 1,8/1,2 mg/kg ; Opdivo 240 mg ; doses AVD ; doxorubicine cumulée 550/400 mg/m².
## DX.10 Phéochromocytome — AUDITÉ, 98,8 %
- À vérifier : Lenders 0,2–0,6 % / 5 % ; cibles ESH < 130/80 et PAS debout > 90 ; préparation CHUV ; Cardura ; 7–14 jours ; panique 1,7 % ; HTA 30–45 %.
## Appel A SSP + bloc 2 — AUDITÉ (_a/_b), 98,8 %
- À vérifier : chiffres de S105–S117 ; règle suisse 2017 (4/7 critères) ; tailles de tache DDG ; doses BOTOX, Dysport, Axhidrox, GlucaGen et glucose 40 % ; ganglion > 1,5–2 cm ; 2 à 4 millions de glandes ; contrôle HDSS à 4–8 semaines.
