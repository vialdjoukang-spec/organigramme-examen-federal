# Mise en place d’un réseau de production documentaire

## Contexte fourni
{
  "description": "Produire des monographies médicales sourcées et des lots SSP avec un coût minimal.",
  "goal": "Publier chaque semaine avec preuves et revue experte",
  "type": "mixte",
  "volume": "large",
  "cost": "low",
  "web": "yes",
  "automation": "yes",
  "review": "yes",
  "local": "simple",
  "evidence": "strict",
  "memory": "yes",
  "parallel": "yes",
  "freshness": "often",
  "integrations": "yes"
}

## Recommandation locale de l’Atlas
Meilleure correspondance sur ce catalogue : **Recherche web et preuves (78/100)**. Ce score est une adéquation à des règles explicites, pas une probabilité de réussite.

Alternatives : Harnais et contrôles (70/100), Automatisation et mesure (59/100), MCP : prises normalisées (58/100).

## Mission
Conçois un schéma structuro-fonctionnel complexe mais exploitable pour : Deux lignes séparées : Medina / CHAPTER_SPEC et Organigramme-examen-fédéral / lots SSP. Le texte de référence du projet est :
> Produire des monographies médicales sourcées et des lots SSP avec un coût minimal.

Objectif : Publier chaque semaine avec preuves et revue experte.

Utilise prioritairement Recherche web et preuves pour recherche les sources originales et conserve les citations. Intègre les alternatives seulement si elles apportent une fonction mesurable. Ne transforme pas les deux formats de cours l’un dans l’autre.

## Livrables attendus
1. Une vue d’ensemble des acteurs, sources, outils, états et sorties.
2. Deux schémas de réseau : un pour Medina, un pour Organigramme SSP ; si un seul format est demandé, expliquer pourquoi l’autre reste hors périmètre.
3. Pour chaque nœud : entrée, traitement, sortie, permission, coût, preuve, gestion d’échec.
4. Les points de cache et de reprise par empreinte ; aucun texte volumineux dans les messages.
5. Des contrôles mécaniques avant appel modèle, une revue humaine avant publication et un budget d’arrêt.
6. Un prototype minimal, puis une extension seulement après mesure du coût, du temps et de la qualité.
7. Une liste explicite des hypothèses, données manquantes et actions nécessitant une autorisation.

## Outils du catalogue à examiner
- Brave Search API (B) : https://brave.com/search/api/
- Crawl4AI (C) : https://docs.crawl4ai.com/
- Trafilatura (T) : https://trafilatura.readthedocs.io/
- Warcio (W) : https://github.com/webrecorder/warcio
- Zotero (Z) : https://www.zotero.org/support/

Ne promets ni coût nul, ni zéro gaspillage absolu, ni exactitude automatique. Cite les sources réellement lues et signale toute incapacité.
