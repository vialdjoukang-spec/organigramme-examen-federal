# PROFILES 2023 — File de production LOT_9 à LOT_20 (mission du 23.10.2026)

Dernière mise à jour : 2026-10-23 15:40 (Europe/Zurich). Agent : Vibe (GLM), sans sous-agents — quatre passes annoncées par rôle, audit NON indépendant.

| LOT | SSP | Statut | Fichier en cours | Score V7 | Score 14 points |
|---|---|---|---|---|---|
| LOT_9 | G9 Prurit (itching) | ACTIF | Evidence puis Appel A | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_10 | G10 Douleur (pain of all types) | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_11 | G11 Troubles du sommeil | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_12 | G12 Œdème (diffus ou local) | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_13 | G13 Mort non naturelle | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_14 | G14 Mort subite ou inattendue | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_15 | G15 Prise de poids, obésité | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_16 | G16 Perte de poids, perte d'appétit | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_17 | S1.1 Diplopie, ptosis, mouvements oculaires anormaux | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_18 | S1.2 Perte de vision | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_19 | S1.3 Altération de la voix | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_20 | S1.4 Visage asymétrique, déformation | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |

## Règles
Un seul lot ACTIF à la fois dans cette mission. Ordre 9 → 20. Test de sortie inchangé (V7 §6.1, §6.2, §6.3 à 100 % audité, §16). LOT_1 reste géré séparément dans ETAT_FILE.md par ses propres agents ; aucun conflit de rédaction n'est créé sur LOT_1.

## Veille
Nom : VEILLE_PROFILES_LOT_9_a_LOT_20 ; taskId c1faf25e-81ad-491d-8bbb-2e24b02b7004 ; fréquence quotidienne 07:00 Europe/Zurich (±60 min) — une relance toutes les 60 minutes est techniquement impossible avec le planificateur disponible (maximum une exécution par jour) ; prochain déclenchement prévu le 24.10.2026 à 07:00, heure suisse. L'ancienne veille horaire du LOT_1 reste désactivée conformément à la demande de Vial ; celle-ci est une veille nouvelle créée sur instruction du PROMPT_DEMARRAGE_IA_UNIVERSEL du 23.10.2026.

## Accusé de lecture (ÉTAPE 1 — Plan A GitHub, branche claude/zealous-noether-c3jut5, répertoire claude/LOT Organigramme)
- PROMPT_ULTIME_PRODUCTION_LOTS_V7.md : lu en entier (copie téléversée par Vial, identique à la référence).
- SOURCES_OFFICIELLES_CH/INDEX_SOURCES_SUISSES.md : lu en entier (liens vérifiés le 22.10.2026 selon le fichier).
- Liste officielle des SSP PROFILES 2023 sur smifk-cims.ch : ouverte ; G9 = itching confirmé.
- reprise_HELP_reponses/VERIF_1 à VERIF_4.json : ouverts intégralement via GitHub (open_url tronque à 32 Ko) ; seuls les champs a_injecter sont conservés ; ils concernent LOT_1–8 et LOT_228–231 ; aucun ne porte sur le prurit : rien d'injectable dans LOT_9, leçons méthodologiques retenues (n° Swissmedic lus dans la liste, jamais déduits ; vérifier « export uniquement » ; versions les plus récentes ; jamais de dose HUG en lieu et place d'une dose AIPS).
- LOT_9_Liste_Corrections_Audit.docx : n'existe pas dans le dépôt (LOT_1 à LOT_8 seulement) ; aucune correction antérieure spécifique au LOT_9.
- Dossier Drive « LOTS_Finaux avec statut » : ouvert en lecture et écriture ; aucun dossier LOT_9 préexistant ; LOT_9_A_produire créé.

## Journal LOT_9
- 23.10.2026 : mission lancée ; SSP G9 identifié ; evidence en cours.
