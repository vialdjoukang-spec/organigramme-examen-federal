# État des lieux — lots Flash V4 / V3 (et variantes)

- **Dépôt :** [vialdjoukang-spec/organigramme-examen-federal](https://github.com/vialdjoukang-spec/organigramme-examen-federal)
- **Branche de référence :** `main` @ `5fceb61` (merge PR #272 LOT_Tunder)
- **Généré le :** 2026-10-25 10:41 CET
- **Périmètre demandé :** lots 001–248, branches `flash/vague3/*`, `flash/vague4/*` (+ variantes `flash/vague1`, `flash/vague2`, `lot/LOT_*`, `audit/LOT_*` documentées)
- **Action PR :** ouverture vers `main` sans fusion (autorisée oralement le 2026-10-25)

## Synthèse

| Indicateur | Valeur |
|---|---|
| Branches `flash/*` totales | **61** (v1=20, v2=20, v3=20, v4=1) |
| Branches Flash V3/V4 | **21** (toutes avec contenu `LOTS/LOT_*` substantiel) |
| Lots 001–248 avec ≥1 branche flash | **31** |
| Lots avec branche `lot/` ou `audit/` | **27** |
| Lots sans aucune branche Flash/lot/audit listée | **190** |
| PR Flash V3/V4 ouvertes vers main (avant cette passe) | **0** |
| PR `#272` LOT_Tunder | **MERGED** 2026-10-23 (Europe/Zurich 2026-10-24 ~01:48) |

### Point critique technique

Les branches `flash/vague3/*` et `flash/vague4/LOT_072-B` partagent une base **V7-Tunder** (`tunder/v7-tunder` @ `2a7ca0c`) qui n’est **pas** entièrement sur `main`.
Conséquence : chaque PR vers `main` affiche ~325 fichiers (socle V7-Tunder + fichiers du lot), et les PR se **chevauchent fortement**.
Aucun contenu n’a été fusionné par cette passe.

### Sessions Cursor Ultra (compte vialfed41) — observation lecture seule

Le 2026-10-25 matin (Europe/Zurich), la page Agents Cursor montrait des sessions **Flash V4** (Grok 4.7 High Fast) sur LOT_001, 038, 039, 040, 072, etc., datées ~5–6 h plus tôt.
**Seule** la branche distante `flash/vague4/LOT_072-B` a été trouvée poussée. Les autres sessions V4 n’ont **pas** laissé de branche `flash/vague4/LOT_XXX` sur GitHub (limite d’usage hebdomadaire Cursor signalée sur une session).

## Bitender / Thunder / Tunder (24 octobre 2026)

- **Aucune** branche, commit, PR ou fichier nommé « Bitender » / « Bitender » n’a été trouvé dans le dépôt ni sur Drive (recherche titre).
- **Thunder / Tunder** : coordinateur-auditeur du chantier Flash V7. Branches présentes :
  - `tunder/v7-tunder` — charte PROMPT V7-Tunder (tête `2a7ca0c`, 2026-10-24 01:08 UTC)
  - `tunder/outillage-agents` — instructions agents v1.5 (2026-10-24 09:06 UTC)
  - `tunder/passation` — archive de passation `LOT_Tunder/` + `STATUT_LOTS_001_248.csv` + prompts de reprise (2026-10-24 21:37 UTC)
- **PR #272** « Ajout du dossier LOT_Tunder » (`cursor/lot-tunder-a847`) : **fusionnée** dans `main` (dossier vide + `.gitkeep`).
- Le **prompt de reprise unique** (24.10 ~23:30 Europe/Zurich) demande au successeur de **reprendre le rôle de Tunder** (pas un nouveau nom « Bitender »). Hypothèse : « Bitender » = déformation vocale / surnom du successeur ou de l’agent de reprise sur le compte Ultra ; non attesté dans les artefacts Git/Drive.
- Sur Drive : dossier passation [LOT_Tunder](https://drive.google.com/drive/folders/1dnxkpQWmweU2DUApyUgamuX36aizduFB) (compte vialfmh) ; dossier de travail lots [LOTS_Finaux avec statut](https://drive.google.com/drive/folders/1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu).

## Inventaire Flash V3 / V4 (détail branches)

| Branche | Lot | Tip (UTC) | Ahead/Behind main | Fichiers (3-dot) | Fichiers LOT_* | Message tip |
|---|---|---|---|---|---|---|
| `flash/vague4/LOT_072-B` | LOT_072-B | 2026-10-25T04:05:29 | 38/3 | 326 | 6 | LOT_072 : DX.9, citations [S8] collées aux titres de fenêtre. |
| `flash/vague3/LOT_073-A` | LOT_073-A | 2026-10-25T03:49:05 | 33/3 | 325 | 5 | LOT 073 : Appel A et monographies V7 des DX.1 à DX.4. |
| `flash/vague3/LOT_073-B` | LOT_073-B | 2026-10-25T03:02:34 | 33/3 | 326 | 6 | Rédige les monographies Appel B DX.5 à DX.10 du LOT 073. |
| `flash/vague3/LOT_074-A` | LOT_074-A | 2026-10-25T03:07:55 | 33/3 | 325 | 5 | LOT_074 : Appel A et monographies DX.1 à DX.4 (écoulement urétral, V7) |
| `flash/vague3/LOT_074-B` | LOT_074-B | 2026-10-25T03:15:22 | 33/3 | 326 | 6 | LOT_074 Appel B : monographies V7 DX.5 à DX.10 (écoulement urétral). |
| `flash/vague3/LOT_104-A` | LOT_104-A | 2026-10-25T03:14:10 | 33/3 | 325 | 5 | LOT 104 S7.10 : plan V7 et monographies DX.1 à DX.4 |
| `flash/vague3/LOT_104-B` | LOT_104-B | 2026-10-25T03:19:46 | 33/3 | 326 | 6 | LOT 104 Appel B : monographies V7 DX.5 à DX.10 |
| `flash/vague3/LOT_110-A` | LOT_110-A | 2026-10-25T03:02:40 | 33/3 | 325 | 5 | LOT 110 agent A : Appel A et monographies DX.1 à DX.4 (S8.6, V7-Tunder |
| `flash/vague3/LOT_110-B` | LOT_110-B | 2026-10-25T03:26:51 | 33/3 | 326 | 6 | Rédige les monographies Appel B V7 du LOT_110, DX.5 à DX.10. |
| `flash/vague3/LOT_111-A` | LOT_111-A | 2026-10-25T03:09:49 | 33/3 | 325 | 5 | LOT_111 S8.7 : Appel A et monographies V7 DX.1 à DX.4. |
| `flash/vague3/LOT_111-B` | LOT_111-B | 2026-10-25T03:38:15 | 33/3 | 326 | 6 | Appel B LOT_111 : monographies V7 DX.5 à DX.10 (traumatisme crânien). |
| `flash/vague3/LOT_112-A` | LOT_112-A | 2026-10-25T03:21:26 | 33/3 | 325 | 5 | LOT_112 S8.8 : Appel A et monographies V7 des DX.1 à DX.4. |
| `flash/vague3/LOT_112-B` | LOT_112-B | 2026-10-25T03:21:03 | 33/3 | 326 | 6 | Ajoute les monographies V7 Appel B du LOT 112 (DX.5 à DX.10). |
| `flash/vague3/LOT_137-A` | LOT_137-A | 2026-10-25T03:49:51 | 33/3 | 325 | 5 | LOT 137, agent A : Appel A et monographies DX.1 à DX.4 (V7). |
| `flash/vague3/LOT_137-B` | LOT_137-B | 2026-10-25T03:18:41 | 38/3 | 326 | 6 | Rédiger la monographie Appel B DX.8 du LOT 137 (F1.8). |
| `flash/vague3/LOT_138-A` | LOT_138-A | 2026-10-25T03:14:43 | 33/3 | 325 | 5 | LOT_138 flash vague 3 : Appel A et monographies DX.1 à DX.4 |
| `flash/vague3/LOT_138-B` | LOT_138-B | 2026-10-25T03:55:55 | 37/3 | 326 | 6 | Rédige la monographie Appel B DX.10 du LOT 138. |
| `flash/vague3/LOT_139-A` | LOT_139-A | 2026-10-25T03:27:51 | 33/3 | 325 | 5 | LOT 139 : Appel A et monographies DX.1 à DX.4 (cyanose, V7). |
| `flash/vague3/LOT_139-B` | LOT_139-B | 2026-10-25T03:15:38 | 33/3 | 326 | 6 | Rédige les monographies Appel B DX.5 à DX.10 du LOT 139 (cyanose F1.10 |
| `flash/vague3/LOT_140-A` | LOT_140-A | 2026-10-25T03:02:09 | 33/3 | 325 | 5 | Rédiger LOT 140 F1.11 : Appel A et monographies DX.1 à DX.4. |
| `flash/vague3/LOT_140-B` | LOT_140-B | 2026-10-25T03:09:08 | 33/3 | 326 | 6 | Rédige les monographies Appel B DX.5 à DX.10 du LOT 140 (F1.11). |

## Lot par lot (001 → 248)

### LOT_001

- **Situation (connue) :** Transpiration anormale (G1)
- **Statut Tunder (CSV passation) :** AUDITÉ — livré (GitHub + Drive LOT_Tunder)
- **Branche CSV :** audit/LOT_001
- **État GitHub (cette passe) :** abouti (audit/) sans PR Flash
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `audit/LOT_001` · ahead 3 · 111 fichiers · 2026-10-24T14:36:15 · LOT_001 AUDITÉ : fond bleu ciel pâle et rouge des probabilités normalisé
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_002

- **Situation (connue) :** Tuméfaction, tumeur, adénopathie (G2)
- **Statut Tunder (CSV passation) :** AUDITÉ — livré (GitHub + Drive LOT_Tunder)
- **Branche CSV :** audit/LOT_002
- **État GitHub (cette passe) :** abouti (audit/) sans PR Flash
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `audit/LOT_002` · ahead 3 · 57 fichiers · 2026-10-24T14:36:15 · LOT_002 AUDITÉ : fond bleu ciel pâle et rouge des probabilités normalisé
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_003

- **Situation (connue) :** Soif excessive / polydipsie (G3)
- **Statut Tunder (CSV passation) :** AUDITÉ — livré (GitHub + Drive LOT_Tunder)
- **Branche CSV :** audit/LOT_003
- **État GitHub (cette passe) :** abouti (audit/) sans PR Flash
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `audit/LOT_003` · ahead 1 · 109 fichiers · 2026-10-24T14:54:54 · audit: LOT_003 AUDITÉ (34.7 → 98.8 %)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_004

- **Situation (connue) :** Fatigue, lassitude (G4)
- **Statut Tunder (CSV passation) :** AUDITÉ — livré (GitHub + Drive LOT_Tunder)
- **Branche CSV :** audit/LOT_004 (r1)
- **État GitHub (cette passe) :** abouti (audit/) sans PR Flash
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `audit/LOT_004` · ahead 2 · 108 fichiers · 2026-10-24T16:39:00 · AUDIT LOT_004 — révision 1 (vérification utilisateur 24.10.2026)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_005

- **Situation (connue) :** Sensation de maladie (G5)
- **Statut Tunder (CSV passation) :** AUDITÉ — livré (GitHub + Drive LOT_Tunder)
- **Branche CSV :** audit/LOT_005
- **État GitHub (cette passe) :** abouti (audit/) sans PR Flash
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `audit/LOT_005` · ahead 1 · 27 fichiers · 2026-10-24T14:54:27 · audit: LOT_005 AUDITÉ (32.4 → 98.8 %)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_006

- **Situation (connue) :** Fièvre, frissons, hyperthermie (G6)
- **Statut Tunder (CSV passation) :** AUDITÉ — sur Drive LOT_Tunder seulement
- **Branche CSV :** -
- **État GitHub (cette passe) :** audité (statut Tunder) — branche audit partielle ou Drive
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_007

- **Situation (connue) :** Bouffées vasomotrices / flush (G7)
- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** lot/LOT_007
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_007` · ahead 1 · 5 fichiers · 2026-10-24T16:12:27 · LOT LOT_007 : resynchronisation depuis Drive (5 fichiers V7)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_008

- **Situation (connue) :** Hypothermie (G8)
- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** lot/LOT_008
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_008` · ahead 1 · 5 fichiers · 2026-10-24T15:04:06 · LOT_008 : resynchronisation Drive → GitHub (5 fichiers V7)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_009

- **Situation (connue) :** Prurit (G9)
- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_009` · ahead 1 · 5 fichiers · 2026-10-24T14:05:13 · LOT_009 : 5 fichiers V7 resynchronisés depuis Drive
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_010

- **Situation (connue) :** Douleurs de tous types (G10)
- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_010` · ahead 1 · 5 fichiers · 2026-10-24T14:05:11 · LOT_010 : 5 fichiers V7 resynchronisés depuis Drive
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_011

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_012

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_013

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_014

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_015

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_016

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_017

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_018

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_019

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_020

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_021

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_022

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_023

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_024

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_025

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_026

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_027

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_028

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_029

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_030

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_031

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_032

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_033

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_034

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_035

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_036

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_037

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_038

- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** en cours (statut Tunder)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_039

- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** en cours (statut Tunder)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_040

- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** en cours (statut Tunder)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_041

- **Situation (connue) :** Modification du rythme respiratoire (S2.2)
- **Statut Tunder (CSV passation) :** EN COURS (2/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague1/LOT_041-A` · tip `51f8e7bea9` · 2026-10-25T00:42:49 · ahead 34 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_041 : enrichissement 150–200 Ko et Appel A
    - fichiers lot (extrait): LOTS/LOT_041/LOT_041_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_041/LOT_041_Appel_B_V7_DX.1.html, LOTS/LOT_041/LOT_041_Appel_B_V7_DX.2.html, LOTS/LOT_041/LOT_041_Appel_B_V7_DX.3.html, LOTS/LOT_041/LOT_041_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_041-A
  - `flash/vague1/LOT_041-B` · tip `023b94305f` · 2026-10-25T00:55:09 · ahead 34 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_041 : enrichir DX.5 à DX.10 sans remplacer le texte.
    - fichiers lot (extrait): LOTS/LOT_041/LOT_041_Appel_B_V7_Partie_2_DX.5.html, LOTS/LOT_041/LOT_041_Appel_B_V7_Partie_3_DX.6_a_DX.7.html, LOTS/LOT_041/LOT_041_Appel_B_V7_Partie_4_DX.8_a_DX.10.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_041-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_042

- **Situation (connue) :** Masse mammaire, écoulement mamelonnaire (S2.3)
- **Statut Tunder (CSV passation) :** EN COURS (3/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague1/LOT_042-A` · tip `db0cfd1434` · 2026-10-25T00:46:34 · ahead 34 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_042 S2.3 : enrichissement ajouté, trois HTML entre 150 et 200 Ko.
    - fichiers lot (extrait): LOTS/LOT_042/LOT_042_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_042/LOT_042_Appel_B_V7_DX.3_et_DX.4.html, LOTS/LOT_042/LOT_042_Appel_B_V7_Partie_1_DX.1_a_DX.2.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_042-A
  - `flash/vague1/LOT_042-B` · tip `ddd922ab2f` · 2026-10-25T01:50:25 · ahead 36 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_042 : enrichissement des trois HTML du rôle B dans la fenêtre 150–200 Ko.
    - fichiers lot (extrait): LOTS/LOT_042/LOT_042_Appel_B_V7_DX.5.html, LOTS/LOT_042/LOT_042_Appel_B_V7_Partie_3_DX.6_a_DX.7.html, LOTS/LOT_042/LOT_042_Appel_B_V7_Partie_4_DX.8_a_DX.10.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_042-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_043

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_044

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_045

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_046

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_047

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_048

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_049

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_050

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_051

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_052

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_053

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_054

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_055

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_056

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_057

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_058

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_059

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_060

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_061

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_062

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_063

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_064

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_065

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_066

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_067

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_068

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_069

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_070

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_071

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_072

- **Situation (connue) :** DX.5 Hernie obturatrice
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague4/LOT_072-B` · tip `81ff624418` · 2026-10-25T04:05:29 · ahead 38 / behind 3 · 326 fichiers · subst=True
    - msg: LOT_072 : DX.9, citations [S8] collées aux titres de fenêtre.
    - fichiers lot (extrait): LOTS/LOT_072/LOT_072_Appel_B_V7_DX.10.html, LOTS/LOT_072/LOT_072_Appel_B_V7_DX.5.html, LOTS/LOT_072/LOT_072_Appel_B_V7_DX.6.html, LOTS/LOT_072/LOT_072_Appel_B_V7_DX.7.html, LOTS/LOT_072/LOT_072_Appel_B_V7_DX.8.html, LOTS/LOT_072/LOT_072_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague4/LOT_072-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_073

- **Situation (connue) :** Symptômes liés à la ménopause (S4.12)
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague3/LOT_073-A` · tip `2ea8c71eca` · 2026-10-25T03:49:05 · ahead 33 / behind 3 · 325 fichiers · subst=True
    - msg: LOT 073 : Appel A et monographies V7 des DX.1 à DX.4.
    - fichiers lot (extrait): LOTS/LOT_073/LOT_073_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_073/LOT_073_Appel_B_V7_DX.1.html, LOTS/LOT_073/LOT_073_Appel_B_V7_DX.2.html, LOTS/LOT_073/LOT_073_Appel_B_V7_DX.3.html, LOTS/LOT_073/LOT_073_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_073-A
  - `flash/vague3/LOT_073-B` · tip `2053a9b326` · 2026-10-25T03:02:34 · ahead 33 / behind 3 · 326 fichiers · subst=True
    - msg: Rédige les monographies Appel B DX.5 à DX.10 du LOT 073.
    - fichiers lot (extrait): LOTS/LOT_073/LOT_073_Appel_B_V7_DX.10.html, LOTS/LOT_073/LOT_073_Appel_B_V7_DX.5.html, LOTS/LOT_073/LOT_073_Appel_B_V7_DX.6.html, LOTS/LOT_073/LOT_073_Appel_B_V7_DX.7.html, LOTS/LOT_073/LOT_073_Appel_B_V7_DX.8.html, LOTS/LOT_073/LOT_073_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_073-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_074

- **Situation (connue) :** Écoulement urétral (S4.13)
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague3/LOT_074-A` · tip `fb8be60536` · 2026-10-25T03:07:55 · ahead 33 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_074 : Appel A et monographies DX.1 à DX.4 (écoulement urétral, V7).
    - fichiers lot (extrait): LOTS/LOT_074/LOT_074_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_074/LOT_074_Appel_B_V7_DX.1.html, LOTS/LOT_074/LOT_074_Appel_B_V7_DX.2.html, LOTS/LOT_074/LOT_074_Appel_B_V7_DX.3.html, LOTS/LOT_074/LOT_074_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_074-A
  - `flash/vague3/LOT_074-B` · tip `3785994952` · 2026-10-25T03:15:22 · ahead 33 / behind 3 · 326 fichiers · subst=True
    - msg: LOT_074 Appel B : monographies V7 DX.5 à DX.10 (écoulement urétral).
    - fichiers lot (extrait): LOTS/LOT_074/LOT_074_Appel_B_V7_DX.10.html, LOTS/LOT_074/LOT_074_Appel_B_V7_DX.5.html, LOTS/LOT_074/LOT_074_Appel_B_V7_DX.6.html, LOTS/LOT_074/LOT_074_Appel_B_V7_DX.7.html, LOTS/LOT_074/LOT_074_Appel_B_V7_DX.8.html, LOTS/LOT_074/LOT_074_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_074-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_075

- **Situation (connue) :** Incontinence urinaire et énurésie (S4.14)
- **Statut Tunder (CSV passation) :** EN COURS (2/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague1/LOT_075-A` · tip `89323df307` · 2026-10-25T01:10:54 · ahead 35 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_075 : enrichit les parties DX.1–DX.4 au-dessus de 153 600 octets.
    - fichiers lot (extrait): LOTS/LOT_075/LOT_075_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_075/LOT_075_Appel_B_V7_Partie_1_DX.1_a_DX.2.html, LOTS/LOT_075/LOT_075_Appel_B_V7_Partie_2_DX.3_et_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_075-A
  - `flash/vague1/LOT_075-B` · tip `c67d4813e4` · 2026-10-25T01:57:10 · ahead 36 / behind 3 · 324 fichiers · subst=True
    - msg: V7-Tunder LOT_075 B09 : enrichit DX.5 à DX.10 dans la bande 150–200 Ko.
    - fichiers lot (extrait): LOTS/LOT_075/LOT_075_Appel_B_V7_DX.6.html, LOTS/LOT_075/LOT_075_Appel_B_V7_DX.7.html, LOTS/LOT_075/LOT_075_Appel_B_V7_Partie_2_DX.5.html, LOTS/LOT_075/LOT_075_Appel_B_V7_Partie_4_DX.8_a_DX.10.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_075-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_076

- **Situation (connue) :** Rétention urinaire (S4.15)
- **Statut Tunder (CSV passation) :** EN COURS (3/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague1/LOT_076-A` · tip `0f08ca2cc6` · 2026-10-25T00:56:25 · ahead 34 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_076 : enrichissement sourcé des trois HTML, sans remplacement.
    - fichiers lot (extrait): LOTS/LOT_076/LOT_076_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_076/LOT_076_Appel_B_V7_DX.3_et_DX.4.html, LOTS/LOT_076/LOT_076_Appel_B_V7_Partie_1_DX.1_a_DX.2.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_076-A
  - `flash/vague1/LOT_076-B` · tip `6dc0e40abc` · 2026-10-25T00:50:27 · ahead 34 / behind 3 · 322 fichiers · subst=True
    - msg: LOT_076 agent B : approfondit DX.5 à DX.10 vers 150–200 Ko.
    - fichiers lot (extrait): LOTS/LOT_076/LOT_076_Appel_B_V7_DX.5_a_DX.7.html, LOTS/LOT_076/LOT_076_Appel_B_V7_DX.8_a_DX.10.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_076-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_077

- **Situation (connue) :** Prolapsus utérin, plancher pelvien (S4.16)
- **Statut Tunder (CSV passation) :** EN COURS (3/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague1/LOT_077-A` · tip `cdc2e6da9d` · 2026-10-25T00:46:02 · ahead 34 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_077 : approfondir DX.1 à DX.4 et déposer l’Appel A.
    - fichiers lot (extrait): LOTS/LOT_077/LOT_077_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_077/LOT_077_Appel_B_V7_DX.1_Paroi_anterieure.html, LOTS/LOT_077/LOT_077_Appel_B_V7_DX.2_Prolapsus_uterin.html, LOTS/LOT_077/LOT_077_Appel_B_V7_DX.3_Paroi_posterieure.html, LOTS/LOT_077/LOT_077_Appel_B_V7_DX.4_Dome_vaginal.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_077-A
  - `flash/vague1/LOT_077-B` · tip `a525d229a4` · 2026-10-25T00:42:12 · ahead 34 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_077 agent B : compléments sourcés DX.5 à DX.10 (150–200 Ko)
    - fichiers lot (extrait): LOTS/LOT_077/LOT_077_Appel_B_V7_DX.5_a_DX.7.html, LOTS/LOT_077/LOT_077_Appel_B_V7_DX.8_a_DX.10.html, LOTS/LOT_077/LOT_077_evidence_B.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_077-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_078

- **Situation (connue) :** Saignement vaginal (S4.17)
- **Statut Tunder (CSV passation) :** EN COURS (3/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague1/LOT_078-A` · tip `7b0f53e3df` · 2026-10-25T01:01:28 · ahead 34 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_078 : enrichir l'Appel A et les parties DX.1 à DX.4 dans la charte 150–200 Ko.
    - fichiers lot (extrait): LOTS/LOT_078/LOT_078_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_078/LOT_078_Appel_B_V7_Partie_1_DX.1_a_DX.2.html, LOTS/LOT_078/LOT_078_Appel_B_V7_Partie_2_DX.3_a_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_078-A
  - `flash/vague1/LOT_078-B` · tip `fbffb103e5` · 2026-10-25T00:49:39 · ahead 36 / behind 3 · 326 fichiers · subst=True
    - msg: LOT_078 : enrichir DX.5 à DX.10 entre 150 et 200 Ko, sans dose AIPS.
    - fichiers lot (extrait): LOTS/LOT_078/LOT_078_Appel_B_V7_DX.10.html, LOTS/LOT_078/LOT_078_Appel_B_V7_DX.5.html, LOTS/LOT_078/LOT_078_Appel_B_V7_DX.6.html, LOTS/LOT_078/LOT_078_Appel_B_V7_DX.7.html, LOTS/LOT_078/LOT_078_Appel_B_V7_DX.8.html, LOTS/LOT_078/LOT_078_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_078-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_079

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_080

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_081

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_082

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_083

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_084

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_085

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_086

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_087

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_088

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_089

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_090

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_091

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_092

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_093

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_094

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_095

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_096

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_097

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_098

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_099

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_100

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_101

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_102

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_103

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_104

- **Situation (connue) :** Myoclonies, fasciculations, convulsion, état de mal (S7.10)
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague3/LOT_104-A` · tip `705106e661` · 2026-10-25T03:14:10 · ahead 33 / behind 3 · 325 fichiers · subst=True
    - msg: LOT 104 S7.10 : plan V7 et monographies DX.1 à DX.4
    - fichiers lot (extrait): LOTS/LOT_104/LOT_104_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_104/LOT_104_Appel_B_V7_DX.1.html, LOTS/LOT_104/LOT_104_Appel_B_V7_DX.2.html, LOTS/LOT_104/LOT_104_Appel_B_V7_DX.3.html, LOTS/LOT_104/LOT_104_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_104-A
  - `flash/vague3/LOT_104-B` · tip `96011faf1f` · 2026-10-25T03:19:46 · ahead 33 / behind 3 · 326 fichiers · subst=True
    - msg: LOT 104 Appel B : monographies V7 DX.5 à DX.10
    - fichiers lot (extrait): LOTS/LOT_104/LOT_104_Appel_B_V7_DX.10.html, LOTS/LOT_104/LOT_104_Appel_B_V7_DX.5.html, LOTS/LOT_104/LOT_104_Appel_B_V7_DX.6.html, LOTS/LOT_104/LOT_104_Appel_B_V7_DX.7.html, LOTS/LOT_104/LOT_104_Appel_B_V7_DX.8.html, LOTS/LOT_104/LOT_104_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_104-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_105

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_105` · ahead 1 · 6 fichiers · 2026-10-24T13:09:29 · LOT_105 : resync Drive -> GitHub (V7, 5 éléments)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_106

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_106` · ahead 1 · 5 fichiers · 2026-10-24T12:05:57 · LOT_106 : resynchronisation V7 depuis Drive (Équipe 2 — Agent 2 Appel A + P1, Ag
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_107

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_107` · ahead 1 · 5 fichiers · 2026-10-24T11:07:48 · LOT_107 : resynchronisation V7 depuis Drive (Équipe 2 — Agent 2 Appel A + P1, Ag
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_108

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_108` · ahead 1 · 5 fichiers · 2026-10-24T10:38:57 · LOT_108 : resynchronisation V7 depuis Drive (Équipe 2 — Agent 2 Appel A + P1, Ag
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_109

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_109` · ahead 1 · 5 fichiers · 2026-10-24T10:21:15 · LOT_109 : resynchronisation V7 depuis Drive (Équipe 2 — Agent 2 Appel A + P1, Ag
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_110

- **Situation (connue) :** Lésion par corps étranger (S8.6)
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague3/LOT_110-A` · tip `390274ac82` · 2026-10-25T03:02:40 · ahead 33 / behind 3 · 325 fichiers · subst=True
    - msg: LOT 110 agent A : Appel A et monographies DX.1 à DX.4 (S8.6, V7-Tunder).
    - fichiers lot (extrait): LOTS/LOT_110/LOT_110_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_110/LOT_110_Appel_B_V7_DX.1.html, LOTS/LOT_110/LOT_110_Appel_B_V7_DX.2.html, LOTS/LOT_110/LOT_110_Appel_B_V7_DX.3.html, LOTS/LOT_110/LOT_110_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_110-A
  - `flash/vague3/LOT_110-B` · tip `692953de4f` · 2026-10-25T03:26:51 · ahead 33 / behind 3 · 326 fichiers · subst=True
    - msg: Rédige les monographies Appel B V7 du LOT_110, DX.5 à DX.10.
    - fichiers lot (extrait): LOTS/LOT_110/LOT_110_Appel_B_V7_DX.10.html, LOTS/LOT_110/LOT_110_Appel_B_V7_DX.5.html, LOTS/LOT_110/LOT_110_Appel_B_V7_DX.6.html, LOTS/LOT_110/LOT_110_Appel_B_V7_DX.7.html, LOTS/LOT_110/LOT_110_Appel_B_V7_DX.8.html, LOTS/LOT_110/LOT_110_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_110-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_111

- **Situation (connue) :** Traumatisme crânien (S8.7)
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague3/LOT_111-A` · tip `8a0abcd675` · 2026-10-25T03:09:49 · ahead 33 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_111 S8.7 : Appel A et monographies V7 DX.1 à DX.4.
    - fichiers lot (extrait): LOTS/LOT_111/LOT_111_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_111/LOT_111_Appel_B_V7_DX.1.html, LOTS/LOT_111/LOT_111_Appel_B_V7_DX.2.html, LOTS/LOT_111/LOT_111_Appel_B_V7_DX.3.html, LOTS/LOT_111/LOT_111_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_111-A
  - `flash/vague3/LOT_111-B` · tip `b6271a3af7` · 2026-10-25T03:38:15 · ahead 33 / behind 3 · 326 fichiers · subst=True
    - msg: Appel B LOT_111 : monographies V7 DX.5 à DX.10 (traumatisme crânien).
    - fichiers lot (extrait): LOTS/LOT_111/LOT_111_Appel_B_V7_DX.10.html, LOTS/LOT_111/LOT_111_Appel_B_V7_DX.5.html, LOTS/LOT_111/LOT_111_Appel_B_V7_DX.6.html, LOTS/LOT_111/LOT_111_Appel_B_V7_DX.7.html, LOTS/LOT_111/LOT_111_Appel_B_V7_DX.8.html, LOTS/LOT_111/LOT_111_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_111-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_112

- **Situation (connue) :** Traumatismes des extrémités (S8.8)
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague3/LOT_112-A` · tip `d55bac0cff` · 2026-10-25T03:21:26 · ahead 33 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_112 S8.8 : Appel A et monographies V7 des DX.1 à DX.4.
    - fichiers lot (extrait): LOTS/LOT_112/LOT_112_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_112/LOT_112_Appel_B_V7_DX.1.html, LOTS/LOT_112/LOT_112_Appel_B_V7_DX.2.html, LOTS/LOT_112/LOT_112_Appel_B_V7_DX.3.html, LOTS/LOT_112/LOT_112_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_112-A
  - `flash/vague3/LOT_112-B` · tip `4755de2fa9` · 2026-10-25T03:21:03 · ahead 33 / behind 3 · 326 fichiers · subst=True
    - msg: Ajoute les monographies V7 Appel B du LOT 112 (DX.5 à DX.10).
    - fichiers lot (extrait): LOTS/LOT_112/LOT_112_Appel_B_V7_DX.10.html, LOTS/LOT_112/LOT_112_Appel_B_V7_DX.5.html, LOTS/LOT_112/LOT_112_Appel_B_V7_DX.6.html, LOTS/LOT_112/LOT_112_Appel_B_V7_DX.7.html, LOTS/LOT_112/LOT_112_Appel_B_V7_DX.8.html, LOTS/LOT_112/LOT_112_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_112-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_113

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_113` · ahead 1 · 5 fichiers · 2026-10-24T20:12:06 · LOT LOT_113 : resynchronisation depuis Drive (5 fichiers V7)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_114

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_115

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_116

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_117

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_118

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_119

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_120

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_121

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_122

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_123

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_124

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_125

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_126

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_127

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_128

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_129

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_130

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_131

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_132

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_133

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_134

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_135

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_136

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_137

- **Situation (connue) :** LOT 137 — F1.8 Cachexie et dénutrition
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague3/LOT_137-A` · tip `52158a31bc` · 2026-10-25T03:49:51 · ahead 33 / behind 3 · 325 fichiers · subst=True
    - msg: LOT 137, agent A : Appel A et monographies DX.1 à DX.4 (V7).
    - fichiers lot (extrait): LOTS/LOT_137/LOT_137_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_137/LOT_137_Appel_B_V7_DX.1.html, LOTS/LOT_137/LOT_137_Appel_B_V7_DX.2.html, LOTS/LOT_137/LOT_137_Appel_B_V7_DX.3.html, LOTS/LOT_137/LOT_137_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_137-A
  - `flash/vague3/LOT_137-B` · tip `b4ebc43515` · 2026-10-25T03:18:41 · ahead 38 / behind 3 · 326 fichiers · subst=True
    - msg: Rédiger la monographie Appel B DX.8 du LOT 137 (F1.8).
    - fichiers lot (extrait): LOTS/LOT_137/LOT_137_Appel_B_V7_DX.10.html, LOTS/LOT_137/LOT_137_Appel_B_V7_DX.5.html, LOTS/LOT_137/LOT_137_Appel_B_V7_DX.6.html, LOTS/LOT_137/LOT_137_Appel_B_V7_DX.7.html, LOTS/LOT_137/LOT_137_Appel_B_V7_DX.8.html, LOTS/LOT_137/LOT_137_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_137-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_138

- **Situation (connue) :** SSP F1.9 Troubles cognitifs — LOT_138
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague3/LOT_138-A` · tip `2583246cf8` · 2026-10-25T03:14:43 · ahead 33 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_138 flash vague 3 : Appel A et monographies DX.1 à DX.4
    - fichiers lot (extrait): LOTS/LOT_138/LOT_138_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_138/LOT_138_Appel_B_V7_DX.1.html, LOTS/LOT_138/LOT_138_Appel_B_V7_DX.2.html, LOTS/LOT_138/LOT_138_Appel_B_V7_DX.3.html, LOTS/LOT_138/LOT_138_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_138-A
  - `flash/vague3/LOT_138-B` · tip `96c6a65890` · 2026-10-25T03:55:55 · ahead 37 / behind 3 · 326 fichiers · subst=True
    - msg: Rédige la monographie Appel B DX.10 du LOT 138.
    - fichiers lot (extrait): LOTS/LOT_138/LOT_138_Appel_B_V7_DX.10.html, LOTS/LOT_138/LOT_138_Appel_B_V7_DX.5.html, LOTS/LOT_138/LOT_138_Appel_B_V7_DX.6.html, LOTS/LOT_138/LOT_138_Appel_B_V7_DX.7.html, LOTS/LOT_138/LOT_138_Appel_B_V7_DX.8.html, LOTS/LOT_138/LOT_138_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_138-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_139

- **Situation (connue) :** LOT 139 Appel A — Cyanose F1.10 — Plan et liste V7
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague3/LOT_139-A` · tip `dd6e11ec63` · 2026-10-25T03:27:51 · ahead 33 / behind 3 · 325 fichiers · subst=True
    - msg: LOT 139 : Appel A et monographies DX.1 à DX.4 (cyanose, V7).
    - fichiers lot (extrait): LOTS/LOT_139/LOT_139_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_139/LOT_139_Appel_B_V7_DX.1.html, LOTS/LOT_139/LOT_139_Appel_B_V7_DX.2.html, LOTS/LOT_139/LOT_139_Appel_B_V7_DX.3.html, LOTS/LOT_139/LOT_139_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_139-A
  - `flash/vague3/LOT_139-B` · tip `94ae64ebd9` · 2026-10-25T03:15:38 · ahead 33 / behind 3 · 326 fichiers · subst=True
    - msg: Rédige les monographies Appel B DX.5 à DX.10 du LOT 139 (cyanose F1.10).
    - fichiers lot (extrait): LOTS/LOT_139/LOT_139_Appel_B_V7_DX.10.html, LOTS/LOT_139/LOT_139_Appel_B_V7_DX.5.html, LOTS/LOT_139/LOT_139_Appel_B_V7_DX.6.html, LOTS/LOT_139/LOT_139_Appel_B_V7_DX.7.html, LOTS/LOT_139/LOT_139_Appel_B_V7_DX.8.html, LOTS/LOT_139/LOT_139_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_139-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_140

- **Situation (connue) :** LOT 140 — F1.11 Anomalie de la parole
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash V3/V4 sans PR
- **Branches flash :**
  - `flash/vague3/LOT_140-A` · tip `5f00d2b3b5` · 2026-10-25T03:02:09 · ahead 33 / behind 3 · 325 fichiers · subst=True
    - msg: Rédiger LOT 140 F1.11 : Appel A et monographies DX.1 à DX.4.
    - fichiers lot (extrait): LOTS/LOT_140/LOT_140_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_140/LOT_140_Appel_B_V7_DX.1.html, LOTS/LOT_140/LOT_140_Appel_B_V7_DX.2.html, LOTS/LOT_140/LOT_140_Appel_B_V7_DX.3.html, LOTS/LOT_140/LOT_140_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_140-A
  - `flash/vague3/LOT_140-B` · tip `9ea58585ec` · 2026-10-25T03:09:08 · ahead 33 / behind 3 · 326 fichiers · subst=True
    - msg: Rédige les monographies Appel B DX.5 à DX.10 du LOT 140 (F1.11).
    - fichiers lot (extrait): LOTS/LOT_140/LOT_140_Appel_B_V7_DX.10.html, LOTS/LOT_140/LOT_140_Appel_B_V7_DX.5.html, LOTS/LOT_140/LOT_140_Appel_B_V7_DX.6.html, LOTS/LOT_140/LOT_140_Appel_B_V7_DX.7.html, LOTS/LOT_140/LOT_140_Appel_B_V7_DX.8.html, LOTS/LOT_140/LOT_140_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague3/LOT_140-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_141

- **Situation (connue) :** Flash vague2
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague2/LOT_141-A` · tip `087b82af30` · 2026-10-25T01:11:05 · ahead 35 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_141 rôle A : chaque HTML du signe F1.12 passe entre 150 et 200 Ko.
    - fichiers lot (extrait): LOTS/LOT_141/LOT_141_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_141/LOT_141_Appel_B_V7_DX.1.html, LOTS/LOT_141/LOT_141_Appel_B_V7_DX.2.html, LOTS/LOT_141/LOT_141_Appel_B_V7_DX.3.html, LOTS/LOT_141/LOT_141_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_141-A
  - `flash/vague2/LOT_141-B` · tip `dda87d1040` · 2026-10-25T01:19:02 · ahead 36 / behind 3 · 324 fichiers · subst=True
    - msg: LOT_141 agent B : Partie 4 DX.8 à DX.10 enrichie entre 160 et 190 Ko.
    - fichiers lot (extrait): LOTS/LOT_141/LOT_141_Appel_B_V7_Partie_2_DX.5.html, LOTS/LOT_141/LOT_141_Appel_B_V7_Partie_3_DX.6_a_DX.7.html, LOTS/LOT_141/LOT_141_Appel_B_V7_Partie_4_DX.8_a_DX.10.html, LOTS/LOT_141/LOT_141_evidence_B.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_141-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_142

- **Situation (connue) :** Flash vague2
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague2/LOT_142-A` · tip `1757b15704` · 2026-10-25T01:45:38 · ahead 35 / behind 3 · 324 fichiers · subst=True
    - msg: LOT 142 : enrichir les HTML du rôle A entre 150 et 200 Ko.
    - fichiers lot (extrait): LOTS/LOT_142/LOT_142_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_142/LOT_142_Appel_B_V7_DX.3_et_DX.4.html, LOTS/LOT_142/LOT_142_Appel_B_V7_Partie_1_DX.1_a_DX.2.html, LOTS/LOT_142/LOT_142_evidence_A.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_142-A
  - `flash/vague2/LOT_142-B` · tip `005dd0502d` · 2026-10-25T01:33:01 · ahead 35 / behind 3 · 323 fichiers · subst=True
    - msg: LOT 142 agent B : monographies DX.5 à DX.10 portées au-dessus de 150 Ko.
    - fichiers lot (extrait): LOTS/LOT_142/LOT_142_Appel_B_V7_DX.5_a_DX.7.html, LOTS/LOT_142/LOT_142_Appel_B_V7_DX.8_a_DX.10.html, LOTS/LOT_142/LOT_142_evidence_B.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_142-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_143

- **Situation (connue) :** Flash vague2
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague2/LOT_143-A` · tip `4742a6b27c` · 2026-10-25T01:34:14 · ahead 35 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_143 F1.14 : enrichir les HTML du rôle A dans la fourchette 150–200 Ko.
    - fichiers lot (extrait): LOTS/LOT_143/LOT_143_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_143/LOT_143_Appel_B_V7_DX.3_a_DX.4.html, LOTS/LOT_143/LOT_143_Appel_B_V7_Partie_1_DX.1_a_DX.2.html, LOTS/LOT_143/LOT_143_evidence.json, LOTS/LOT_143/SUIVI_A08.md
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_143-A
  - `flash/vague2/LOT_143-B` · tip `39cf239cc1` · 2026-10-25T01:32:55 · ahead 35 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_143 agent B : enrichissement clinique DX.5 à DX.10
    - fichiers lot (extrait): LOTS/LOT_143/LOT_143_Appel_B_V7_DX.5_a_DX.7.html, LOTS/LOT_143/LOT_143_Appel_B_V7_DX.8_a_DX.10.html, LOTS/LOT_143/LOT_143_evidence_B.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_143-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_144

- **Situation (connue) :** Flash vague2
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague2/LOT_144-A` · tip `5ada6a4fe2` · 2026-10-25T01:05:35 · ahead 35 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_144 : chaque fichier du rôle A passe entre 150 et 200 Ko.
    - fichiers lot (extrait): LOTS/LOT_144/LOT_144_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_144/LOT_144_Appel_B_V7_DX.1.html, LOTS/LOT_144/LOT_144_Appel_B_V7_DX.2.html, LOTS/LOT_144/LOT_144_Appel_B_V7_DX.3.html, LOTS/LOT_144/LOT_144_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_144-A
  - `flash/vague2/LOT_144-B` · tip `6384d8237a` · 2026-10-25T00:58:20 · ahead 35 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_144 B07 : approfondissement DX.5 à DX.10 (150–200 Ko), sans audit ni PR
    - fichiers lot (extrait): LOTS/LOT_144/LOT_144_Appel_B_V7_B07_DX.5_DX.6.html, LOTS/LOT_144/LOT_144_Appel_B_V7_B07_DX.7_DX.8.html, LOTS/LOT_144/LOT_144_Appel_B_V7_B07_DX.9_DX.10.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_144-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_145

- **Situation (connue) :** Flash vague2
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague2/LOT_145-A` · tip `deb65320a1` · 2026-10-25T01:45:47 · ahead 35 / behind 3 · 324 fichiers · subst=True
    - msg: LOT 145 : enrichir les trois HTML du rôle A dans la fourchette 150–200 Ko.
    - fichiers lot (extrait): LOTS/LOT_145/LOT_145_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_145/LOT_145_Appel_B_V7_DX.3_et_DX.4.html, LOTS/LOT_145/LOT_145_Appel_B_V7_Partie_1_DX.1_a_DX.2.html, LOTS/LOT_145/LOT_145_evidence_A.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_145-A
  - `flash/vague2/LOT_145-B` · tip `d6f9724230` · 2026-10-25T00:46:11 · ahead 35 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_145 E06-B : HTML DX.5 à DX.10 entre 150 et 200 Ko
    - fichiers lot (extrait): LOTS/LOT_145/LOT_145_Appel_B_V7_E06B_DX.5_DX.6.html, LOTS/LOT_145/LOT_145_Appel_B_V7_E06B_DX.7_DX.8.html, LOTS/LOT_145/LOT_145_Appel_B_V7_E06B_DX.9_DX.10.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_145-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_146

- **Situation (connue) :** Flash vague1
- **Statut Tunder (CSV passation) :** EN COURS (2/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague1/LOT_146-A` · tip `b92b19b828` · 2026-10-25T00:49:56 · ahead 34 / behind 3 · 324 fichiers · subst=True
    - msg: LOT 146-A : remplacement des trois HTML entre 150 et 200 Ko.
    - fichiers lot (extrait): LOTS/LOT_146/LOT_146_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_146/LOT_146_Appel_B_V7_DX.3_et_DX.4.html, LOTS/LOT_146/LOT_146_Appel_B_V7_Partie_1_DX.1_a_DX.2.html, LOTS/LOT_146/LOT_146_evidence_A.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_146-A
  - `flash/vague1/LOT_146-B` · tip `3ef28424d9` · 2026-10-25T00:54:42 · ahead 34 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_146 B08 : remplacer DX.5 à DX.10 par les diagnostics de l'Appel A, sans audit ni PR.
    - fichiers lot (extrait): LOTS/LOT_146/LOT_146_Appel_B_V7_B08_DX.5_DX.6.html, LOTS/LOT_146/LOT_146_Appel_B_V7_B08_DX.7_DX.8.html, LOTS/LOT_146/LOT_146_Appel_B_V7_B08_DX.9_DX.10.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_146-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_147

- **Situation (connue) :** Flash vague1
- **Statut Tunder (CSV passation) :** EN COURS (3/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague1/LOT_147-A` · tip `06ac72150e` · 2026-10-25T01:18:33 · ahead 35 / behind 3 · 326 fichiers · subst=True
    - msg: LOT_147-A : Appel A (Plan et Liste) et enrichissement des DX.1 à DX.4.
    - fichiers lot (extrait): LOTS/LOT_147/LOT_147_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_147/LOT_147_Appel_B_V7_Partie_1_DX.1.html, LOTS/LOT_147/LOT_147_Appel_B_V7_Partie_1_DX.2.html, LOTS/LOT_147/LOT_147_Appel_B_V7_Partie_2_DX.3.html, LOTS/LOT_147/LOT_147_Appel_B_V7_Partie_2_DX.4.html, LOTS/LOT_147/LOT_147_sources_lues.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_147-A
  - `flash/vague1/LOT_147-B` · tip `e9604abcf7` · 2026-10-25T00:58:49 · ahead 34 / behind 3 · 326 fichiers · subst=True
    - msg: LOT_147-B : approfondir DX.5 à DX.10 (150–200 Ko)
    - fichiers lot (extrait): LOTS/LOT_147/LOT_147_Appel_B_V7_DX.10.html, LOTS/LOT_147/LOT_147_Appel_B_V7_DX.5.html, LOTS/LOT_147/LOT_147_Appel_B_V7_DX.6.html, LOTS/LOT_147/LOT_147_Appel_B_V7_DX.7.html, LOTS/LOT_147/LOT_147_Appel_B_V7_DX.8.html, LOTS/LOT_147/LOT_147_Appel_B_V7_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_147-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_148

- **Situation (connue) :** Flash vague1
- **Statut Tunder (CSV passation) :** EN COURS (3/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague1/LOT_148-A` · tip `140b4da5c5` · 2026-10-25T00:44:42 · ahead 34 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_148-A : remplacement des HTML en Atkinson, accent #C8102E, 150 à 200 Ko.
    - fichiers lot (extrait): LOTS/LOT_148/LOT_148_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_148/LOT_148_Appel_B_V7_DX.1.html, LOTS/LOT_148/LOT_148_Appel_B_V7_DX.2.html, LOTS/LOT_148/LOT_148_Appel_B_V7_DX.3.html, LOTS/LOT_148/LOT_148_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_148-A
  - `flash/vague1/LOT_148-B` · tip `ef1035ebb0` · 2026-10-25T01:18:05 · ahead 36 / behind 3 · 326 fichiers · subst=True
    - msg: Enrichit la monographie DX.5 au-dessus du plancher de 153 600 octets.
    - fichiers lot (extrait): LOTS/LOT_148/LOT_148_Appel_B_V7_Partie_2_DX.5.html, LOTS/LOT_148/LOT_148_Appel_B_V7_Partie_3_DX.6.html, LOTS/LOT_148/LOT_148_Appel_B_V7_Partie_3_DX.7.html, LOTS/LOT_148/LOT_148_Appel_B_V7_Partie_4_DX.10.html, LOTS/LOT_148/LOT_148_Appel_B_V7_Partie_4_DX.8.html, LOTS/LOT_148/LOT_148_Appel_B_V7_Partie_4_DX.9.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_148-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_149

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_150

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_151

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_152

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_153

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_154

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_155

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_156

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_157

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_158

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_159

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_160

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_161

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_162

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_163

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_164

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_165

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_166

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_167

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_168

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_169

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_170

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_171

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_172

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_173

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_174

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_175

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_176

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_177

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_178

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_179

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_180

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_181

- **Situation (connue) :** Flash vague2
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague2/LOT_181-A` · tip `4c007d6eea` · 2026-10-25T00:39:21 · ahead 35 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_181 O1.8 : chaque HTML de l'agent A entre 150 et 200 Ko.
    - fichiers lot (extrait): LOTS/LOT_181/LOT_181_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_181/LOT_181_Appel_B_V7_DX.3_a_DX.4.html, LOTS/LOT_181/LOT_181_Appel_B_V7_Partie_1_DX.1_a_DX.2.html, LOTS/LOT_181/LOT_181_evidence.json, LOTS/LOT_181/SUIVI_A05.md
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_181-A
  - `flash/vague2/LOT_181-B` · tip `9b58e06741` · 2026-10-25T00:37:41 · ahead 3 / behind 0 · 3 fichiers · subst=True
    - msg: LOT_181 agent B : monographies DX.5 à DX.10 entre 150 et 200 Ko (O1.8)
    - fichiers lot (extrait): LOTS/LOT_181/LOT_181_Appel_B_V7_DX.5_a_DX.7.html, LOTS/LOT_181/LOT_181_Appel_B_V7_DX.8_a_DX.10.html, LOTS/LOT_181/LOT_181_evidence_B.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_181-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_182

- **Situation (connue) :** Flash vague2
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague2/LOT_182-A` · tip `c501368ef8` · 2026-10-25T01:46:56 · ahead 35 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_182 O1.9 : enrichir les trois HTML du rôle A dans la fenêtre 150–200 Ko.
    - fichiers lot (extrait): LOTS/LOT_182/LOT_182_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_182/LOT_182_Appel_B_V7_DX.3_a_DX.4.html, LOTS/LOT_182/LOT_182_Appel_B_V7_Partie_1_DX.1_a_DX.2.html, LOTS/LOT_182/LOT_182_evidence.json, LOTS/LOT_182/SUIVI_E04-A.md
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_182-A
  - `flash/vague2/LOT_182-B` · tip `0d718f44b9` · 2026-10-25T01:36:48 · ahead 35 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_182 agent B : approfondissement DX.5 à DX.10
    - fichiers lot (extrait): LOTS/LOT_182/LOT_182_Appel_B_V7_DX.5_a_DX.7.html, LOTS/LOT_182/LOT_182_Appel_B_V7_DX.8_a_DX.10.html, LOTS/LOT_182/LOT_182_evidence_B.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_182-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_183

- **Situation (connue) :** Flash vague1
- **Statut Tunder (CSV passation) :** EN COURS (2/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague1/LOT_183-A` · tip `ab1319ecaf` · 2026-10-25T00:38:24 · ahead 34 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_183 O2.1 : remplacement des trois HTML entre 150 et 200 Ko.
    - fichiers lot (extrait): LOTS/LOT_183/LOT_183_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_183/LOT_183_Appel_B_V7_DX.3_a_DX.4.html, LOTS/LOT_183/LOT_183_Appel_B_V7_Partie_1_DX.1_a_DX.2.html, LOTS/LOT_183/LOT_183_evidence.json, LOTS/LOT_183/SUIVI_A07.md
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_183-A
  - `flash/vague1/LOT_183-B` · tip `1e77d439d4` · 2026-10-25T00:43:50 · ahead 34 / behind 3 · 330 fichiers · subst=True
    - msg: LOT_183-B : HTML DX.5 à DX.10 portés dans la bande 150–200 Ko.
    - fichiers lot (extrait): LOTS/LOT_183/LOT_183_Appel_B_V7_DX.5.html, LOTS/LOT_183/LOT_183_Appel_B_V7_Partie_3_DX.6_a_DX.7.html, LOTS/LOT_183/LOT_183_Appel_B_V7_Partie_4_DX.8_a_DX.10.html, LOTS/LOT_183/_gen_dx5_10.py, LOTS/LOT_183/approfondir_lot183.py, LOTS/LOT_183/approfondir_suite.py
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague1/LOT_183-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_184

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_185

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_186

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_187

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_188

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_189

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_190

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_191

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_192

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_193

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_194

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_195

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_196

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_197

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_198

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_199

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_200

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_201

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_202

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_203

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_204

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_205

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_206

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_207

- **Statut Tunder (CSV passation) :** À RÉDIGER (0/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_208

- **Situation (connue) :** Flash vague2
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague2/LOT_208-A` · tip `063c9040d9` · 2026-10-25T00:39:23 · ahead 35 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_208 rôle A : charte Atkinson et volume 150–200 Ko (O4.7).
    - fichiers lot (extrait): LOTS/LOT_208/LOT_208_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_208/LOT_208_Appel_B_V7_DX.1.html, LOTS/LOT_208/LOT_208_Appel_B_V7_DX.2.html, LOTS/LOT_208/LOT_208_Appel_B_V7_DX.3.html, LOTS/LOT_208/LOT_208_Appel_B_V7_DX.4.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_208-A
  - `flash/vague2/LOT_208-B` · tip `1b36aa542d` · 2026-10-25T01:36:00 · ahead 35 / behind 3 · 330 fichiers · subst=True
    - msg: LOT_208 : approfondissement DX.5 à DX.10 dans la fenêtre 150–200 Ko.
    - fichiers lot (extrait): LOTS/LOT_208/LOT_208_Appel_B_V7_DX.5.html, LOTS/LOT_208/LOT_208_Appel_B_V7_Partie_3_DX.6_a_DX.7.html, LOTS/LOT_208/LOT_208_Appel_B_V7_Partie_4_DX.8_a_DX.10.html, LOTS/LOT_208/evidence_DX5-DX10.json, LOTS/LOT_208/gen_lot208_b.py, LOTS/LOT_208/lot208_dx.py
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_208-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_209

- **Situation (connue) :** Flash vague2
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague2/LOT_209-A` · tip `6231bd2be4` · 2026-10-25T01:41:12 · ahead 35 / behind 3 · 325 fichiers · subst=True
    - msg: LOT_209 : enrichir les trois HTML du rôle A au-dessus de 150 Ko.
    - fichiers lot (extrait): LOTS/LOT_209/LOT_209_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_209/LOT_209_Appel_B_V7_DX.3_a_DX.4.html, LOTS/LOT_209/LOT_209_Appel_B_V7_Partie_1_DX.1_a_DX.2.html, LOTS/LOT_209/LOT_209_evidence.json, LOTS/LOT_209/SUIVI_E02A.md
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_209-A
  - `flash/vague2/LOT_209-B` · tip `5e696300f5` · 2026-10-25T01:36:11 · ahead 35 / behind 3 · 323 fichiers · subst=True
    - msg: LOT_209 : approfondir DX.5 à DX.10 dans la fourchette 150–200 Ko.
    - fichiers lot (extrait): LOTS/LOT_209/LOT_209_Appel_B_V7_DX.5_a_DX.7.html, LOTS/LOT_209/LOT_209_Appel_B_V7_DX.8_a_DX.10.html, LOTS/LOT_209/LOT_209_evidence_B.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_209-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_210

- **Situation (connue) :** Flash vague2
- **Statut Tunder (CSV passation) :** EN COURS (1/5)
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti Flash vague1/2 sans PR
- **Branches flash :**
  - `flash/vague2/LOT_210-A` · tip `31cd64aae0` · 2026-10-25T00:49:17 · ahead 35 / behind 3 · 323 fichiers · subst=True
    - msg: LOT 210 : approfondir l'appel et DX.1 à DX.4 dans la bande 150–200 Ko
    - fichiers lot (extrait): LOTS/LOT_210/LOT_210_Appel_A_V7_Plan_et_Liste.html, LOTS/LOT_210/LOT_210_Appel_B_V7_DX.3_a_DX.4.html, LOTS/LOT_210/LOT_210_Appel_B_V7_Partie_1_DX.1_a_DX.2.html
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_210-A
  - `flash/vague2/LOT_210-B` · tip `8531c8210c` · 2026-10-25T00:46:42 · ahead 37 / behind 3 · 324 fichiers · subst=True
    - msg: LOT_210 rôle B : porter DX.5 à DX.10 entre 150 et 200 Ko.
    - fichiers lot (extrait): LOTS/LOT_210/LOT_210_Appel_B_V7_DX.5.html, LOTS/LOT_210/LOT_210_Appel_B_V7_Partie_3_DX.6_a_DX.7.html, LOTS/LOT_210/LOT_210_Appel_B_V7_Partie_4_DX.8_a_DX.10.html, LOTS/LOT_210/LOT_210_evidence_B.json
    - URL: https://github.com/vialdjoukang-spec/organigramme-examen-federal/tree/flash/vague2/LOT_210-B
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_211

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_211` · ahead 1 · 5 fichiers · 2026-10-24T20:12:04 · LOT LOT_211 : resynchronisation depuis Drive (5 fichiers V7)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_212

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_212` · ahead 1 · 5 fichiers · 2026-10-24T20:12:05 · LOT LOT_212 : resynchronisation depuis Drive (5 fichiers V7)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_213

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** lot/LOT_213
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_213` · ahead 1 · 5 fichiers · 2026-10-24T16:12:34 · LOT LOT_213 : resynchronisation depuis Drive (5 fichiers V7)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_214

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** lot/LOT_214
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_214` · ahead 1 · 5 fichiers · 2026-10-24T15:04:05 · LOT_214 : resynchronisation Drive → GitHub (5 fichiers V7)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_215

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_215` · ahead 1 · 5 fichiers · 2026-10-24T14:05:15 · LOT_215 : 5 fichiers V7 resynchronisés depuis Drive
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_216

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_216` · ahead 1 · 5 fichiers · 2026-10-24T13:09:12 · LOT_216 : resync Drive -> GitHub (V7, 5 éléments)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_217

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_217` · ahead 1 · 5 fichiers · 2026-10-24T11:21:20 · LOT_217 : resynchronisation V7 depuis Drive (Équipe 1 — Agent 1 Appel A + P1, Ag
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_218

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_218` · ahead 1 · 5 fichiers · 2026-10-24T10:22:49 · LOT_218 : resynchronisation V7 depuis Drive (Équipe 1 — Agent 1 Appel A + P1, Ag
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_219

- **Statut Tunder (CSV passation) :** NON RÉDIGÉ — seulement des fichiers _A_REDIGER (placeholders)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_220

- **Statut Tunder (CSV passation) :** NON RÉDIGÉ — seulement des fichiers _A_REDIGER (placeholders)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_221

- **Statut Tunder (CSV passation) :** NON RÉDIGÉ — seulement des fichiers _A_REDIGER (placeholders)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_222

- **Statut Tunder (CSV passation) :** NON RÉDIGÉ — seulement des fichiers _A_REDIGER (placeholders)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_223

- **Statut Tunder (CSV passation) :** NON RÉDIGÉ — seulement des fichiers _A_REDIGER (placeholders)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_224

- **Statut Tunder (CSV passation) :** NON RÉDIGÉ — seulement des fichiers _A_REDIGER (placeholders)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_225

- **Statut Tunder (CSV passation) :** NON RÉDIGÉ — seulement des fichiers _A_REDIGER (placeholders)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_226

- **Statut Tunder (CSV passation) :** NON RÉDIGÉ — seulement des fichiers _A_REDIGER (placeholders)
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_227

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** lot/LOT_227
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_227` · ahead 1 · 10 fichiers · 2026-10-24T04:58:16 · LOT_227 : resynchronisation depuis Drive (Agent 1), copie à l'identique
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_228

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** lot/LOT_228
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_228` · ahead 1 · 10 fichiers · 2026-10-24T07:53:29 · LOT_228 : resynchronisation depuis Drive (Agent 1), copie à l'identique
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_229

- **Statut Tunder (CSV passation) :** V5 complète ; V7 : Appel A seul
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_230

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_231

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_232

- **Statut Tunder (CSV passation) :** V5 incomplète (P3 manquante), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_233

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_234

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_235

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_236

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_237

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_238

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 — non audité
- **Branche CSV :** lot/LOT_238
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_238` · ahead 1 · 12 fichiers · 2026-10-24T05:49:19 · LOT_238 : resynchronisation depuis Drive (Agent 2), copie à l'identique
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_239

- **Statut Tunder (CSV passation) :** ACHEVÉ V7 5/5 (Agent_2) — non audité
- **Branche CSV :** -
- **État GitHub (cette passe) :** abouti (lot/) sans PR
- **Branches flash :** aucune
- **Autres branches lot/audit :**
  - `lot/LOT_239` · ahead 1 · 7 fichiers · 2026-10-24T09:13:30 · LOT_239 : resynchronisation V7 depuis Drive (Agent 2 — Appel A + Parties 1–4)
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_240

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_241

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_242

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_243

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_244

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_245

- **Statut Tunder (CSV passation) :** V5 incomplète (Appel A manquant), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_246

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_247

- **Statut Tunder (CSV passation) :** V5 complète (5/5), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

### LOT_248

- **Statut Tunder (CSV passation) :** V5 incomplète (P2 manquante), pas de V7
- **Branche CSV :** -
- **État GitHub (cette passe) :** absent (pas de branche Flash/lot/audit)
- **Branches flash :** aucune
- **PR vers main :** aucune PR Flash ouverte/fermée trouvée pour ce lot (hors périmètre Alpha/Beta)

## Annexes

### Branches tunder/*
- `tunder/outillage-agents` · ahead=3 · fichiers (extrait): CAHIER_DES_CHARGES_SCRIPTS_SKILLS/CAHIER_DES_CHARGES_SCRIPTS_SKILLS_GROK.md, CAHIER_DES_CHARGES_SCRIPTS_SKILLS/README.md, CAHIER_DES_CHARGES_SCRIPTS_SKILLS/RECHERCHE_OUTILS.md, CAHIER_DES_CHARGES_SCRIPTS_SKILLS/controle_v7.py, INSTRUCTIONS_AGENTS/README.md, INSTRUCTIONS_AGENTS/generer_instructions.py, INSTRUCTIONS_AGENTS/instructions_agent_1.md, INSTRUCTIONS_AGENTS/instructions_agent_2.md
  - Outillage agents v1.5 : ordre décroissant LOT_218 → LOT_1 (équipe 1 : 218–110, équipe 2 : 109–1)
- `tunder/passation` · ahead=2 · fichiers (extrait): LOT_Tunder/.gitkeep, LOT_Tunder/00_PROMPT_DE_REPRISE_UNIQUE.txt, LOT_Tunder/00_PROMPT_DE_TRANSITION.md, LOT_Tunder/CONSTRUCTION_PROJET.md, LOT_Tunder/CONSTRUCTION_PROJET_outils_scripts.zip, LOT_Tunder/INDEX_CHEMINS.md, LOT_Tunder/LOT_001_AUDITE.zip, LOT_Tunder/LOT_002_AUDITE.zip
  - Passation Tunder : ajout INDEX_CHEMINS.md + manifeste mis à jour
- `tunder/v7-tunder` · ahead=924 · fichiers (extrait): 
  - V7-Tunder : contradictions levées (dépôt sans audit, GitHub au lieu du Drive, Drive en plan B)

### Méthode

1. `git ls-remote --heads` + filtre flash/vague/LOT/tunder
2. Analyse `git log` / `git diff main...branch` (historique approfondi de main)
3. `gh` pour PR state=all ; aucune PR head `flash/*`
4. Lecture `STATUT_LOTS_001_248.csv` et prompts sur `tunder/passation`
5. Dossier Drive cible : `LOTS_Finaux avec statut` (`1DaFAd0uamsJQY2NH0ocuy2bhpfcVk9Vu`)

---
*Fin du rapport. Les numéros de PR créées dans la foulée sont ajoutés en bas si la création réussit.*

## PR créées dans cette passe

- **Créées :** 21 / 21
- **Échecs :** 0
- **Fusionnées :** 0 (interdit)

| PR | Titre | Branche |
|---|---|---|
| [#273](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/273) | Flash V4 LOT_072-B - Gonflement ou douleur de l'aine (S4.11) | `flash/vague4/LOT_072-B` |
| [#274](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/274) | Flash V3 LOT_073-A - Symptômes liés à la ménopause (S4.12) | `flash/vague3/LOT_073-A` |
| [#275](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/275) | Flash V3 LOT_073-B - Symptômes liés à la ménopause (S4.12) | `flash/vague3/LOT_073-B` |
| [#276](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/276) | Flash V3 LOT_074-A - Écoulement urétral (S4.13) | `flash/vague3/LOT_074-A` |
| [#277](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/277) | Flash V3 LOT_074-B - Écoulement urétral (S4.13) | `flash/vague3/LOT_074-B` |
| [#278](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/278) | Flash V3 LOT_104-A - Myoclonies, fasciculations, convulsion, état de mal (S7.10) | `flash/vague3/LOT_104-A` |
| [#279](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/279) | Flash V3 LOT_104-B - Myoclonies, fasciculations, convulsion, état de mal (S7.10) | `flash/vague3/LOT_104-B` |
| [#280](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/280) | Flash V3 LOT_110-A - Lésion par corps étranger (S8.6) | `flash/vague3/LOT_110-A` |
| [#281](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/281) | Flash V3 LOT_110-B - Lésion par corps étranger (S8.6) | `flash/vague3/LOT_110-B` |
| [#282](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/282) | Flash V3 LOT_111-A - Traumatisme crânien (S8.7) | `flash/vague3/LOT_111-A` |
| [#283](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/283) | Flash V3 LOT_111-B - Traumatisme crânien (S8.7) | `flash/vague3/LOT_111-B` |
| [#284](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/284) | Flash V3 LOT_112-A - Traumatismes des extrémités (S8.8) | `flash/vague3/LOT_112-A` |
| [#285](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/285) | Flash V3 LOT_112-B - Traumatismes des extrémités (S8.8) | `flash/vague3/LOT_112-B` |
| [#286](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/286) | Flash V3 LOT_137-A - Cachexie et dénutrition (F1.8) | `flash/vague3/LOT_137-A` |
| [#287](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/287) | Flash V3 LOT_137-B - Cachexie et dénutrition (F1.8) | `flash/vague3/LOT_137-B` |
| [#288](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/288) | Flash V3 LOT_138-A - Troubles cognitifs (F1.9) | `flash/vague3/LOT_138-A` |
| [#289](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/289) | Flash V3 LOT_138-B - Troubles cognitifs (F1.9) | `flash/vague3/LOT_138-B` |
| [#290](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/290) | Flash V3 LOT_139-A - Cyanose (F1.10) | `flash/vague3/LOT_139-A` |
| [#291](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/291) | Flash V3 LOT_139-B - Cyanose (F1.10) | `flash/vague3/LOT_139-B` |
| [#292](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/292) | Flash V3 LOT_140-A - Anomalie de la parole (F1.11) | `flash/vague3/LOT_140-A` |
| [#293](https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/293) | Flash V3 LOT_140-B - Anomalie de la parole (F1.11) | `flash/vague3/LOT_140-B` |
