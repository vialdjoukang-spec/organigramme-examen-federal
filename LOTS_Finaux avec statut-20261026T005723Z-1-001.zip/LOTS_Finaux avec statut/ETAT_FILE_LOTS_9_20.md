# PROFILES 2023 — File de production LOT_9 à LOT_20 (mission du 23.10.2026)

Dernière mise à jour : 2026-10-23T14:45:00+02:00 (Europe/Zurich).

Mission décidée par Vial : « On fera graduellement du LOT_9 au LOT_20. Tâche : LOT_9 exclusivement maintenant. » LOT_9 est le seul lot ACTIF de cette mission. Le fichier ETAT_FILE.md (lots 1–8, ID 18psapJ1VUbxaqPxPqiCghYlAxKJZtgDu) reste intouché : il décrit un workflow parallèle dont LOT_1 est ACTIF ; je n'y écris pas, faute d'outil de mise à jour Drive et par respect du travail en cours.

| LOT | SSP | Statut | Fichier en cours | Score V7 | Score 14 points |
|---|---|---|---|---|---|
| LOT_9 | G9 Prurit (itching) | ACTIF | Recherche de preuves (evidence) puis Appel A | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_10 | G10 Douleur, tous types (pain of all types) | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_11 | G11 Troubles du sommeil (insomnies, hypersomnies, parasomnies) | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_12 | G12 Œdème (diffus ou localisé) | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_13 | G13 Mort non naturelle (unnatural death) | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_14 | G14 Mort inattendue ou subite | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_15 | G15 Prise de poids, obésité | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_16 | G16 Perte de poids, perte d'appétit | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_17 | S1.1 Diplopie, ptosis, mouvements oculaires anormaux | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_18 | S1.2 Perte de vision (aiguë, progressive, transitoire, partielle) | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_19 | S1.3 Altération de la voix (dysphonie, aphonie) | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_20 | S1.4 Asymétrie ou déformation du visage | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |

## Règles de cette mission

Un seul lot ACTIF à la fois dans cette mission. Ordre 9 → 20. Chaque lot compte 5 fichiers : Appel A (SSP en 14 points + liste DX.1–DX.10, tableau comparatif, algorithme), puis Appel B Parties 1 à 4 (cadence 2-3-2-3). Cadence d'agents du § 5 du prompt V7 : sans sous-agents, quatre passes séparées annoncées par rôle ; l'audit n'est pas indépendant et cela est signalé à chaque rapport. Test de sortie inchangé : score V7 § 6.3 de 100 %, questions § 6.1 satisfaites pour chaque point, § 6.2 « oui », checklist § 16 pour les 5 fichiers.

## Veille

Nom : VEILLE_PROFILES_LOT_9_a_LOT_20. ID : c1faf25e-81ad-491d-8bbb-2e24b02b7004. Fréquence réelle : quotidienne à 07:00 Europe/Zurich (déclenchement possible jusqu'à 60 minutes plus tard). Une relance toutes les 60 minutes est techniquement impossible avec le planificateur disponible (maximum une exécution par jour) ; je l'écris au lieu de le prétendre. Prochain déclenchement attendu : 24.10.2026 entre 07:00 et 08:00, heure suisse. La relance manuelle par le mot « CONTINUE » reste possible à tout moment.

## Point de reprise LOT_9

SSP : G9 itching (prurit), confirmé sur la liste officielle PROFILES 2023 (smifk-cims.ch/profiles-2023/ssps). Sources ouvertes à ce stade : prompt V7 (fichier téléversé par Vial, lu en entier), INDEX_SOURCES_SUISSES.md (GitHub, lu en entier), inventaire du dossier GitHub « LOT Organigramme » (parcouru), VERIF_1 à VERIF_4.json (champs a_injecter extraits : aucun ne concerne le prurit, rien n'est injectable dans LOT_9 ; les leçons méthodologiques s'appliquent). Il n'existe pas encore de LOT_9_Liste_Corrections_Audit.docx : le lot est une production neuve ; les corrections d'audit des lots 1 à 8 servent d'avertissements génériques. Dépôt : dossier LOT_9_A_produire créé dans « LOTS_Finaux avec statut ».

Contenu produit par IA à partir des sources citées ; non validé cliniquement par un médecin.
