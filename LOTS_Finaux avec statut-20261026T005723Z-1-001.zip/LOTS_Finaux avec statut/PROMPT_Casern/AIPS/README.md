# AIPS Swissmedic — corpus Medina

Source : dépôt `vialdjoukang-spec/Medina` → `AipsDownload_20261008.zip` (2026-10-08).

Contenu :
- `AipsDownload_20261008.xml` — information professionnelle (AIPS)
- `AIPS_Download.xsd` — schéma

Usage production/audit Organigramme : doses suisses **mot pour mot** depuis ce corpus (priorité), contrôle croisé swissmedicinfo.ch si besoin.
