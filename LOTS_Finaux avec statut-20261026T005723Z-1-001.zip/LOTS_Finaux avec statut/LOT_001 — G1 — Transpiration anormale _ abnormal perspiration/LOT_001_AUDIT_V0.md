# LOT_001 (G1 — Transpiration anormale) — Audit agressif V0

**Date :** 2026-10-25 ~19:55 Europe/Zurich  
**Auditeur :** sous-agent executor (Grok Bot) — posture non complaisante (PROMPT ULTIME V0 §4 / §12 / §17)  
**Poids fichier (owner update) :** **150–200 Ko** (remplace 90–200)  
**Canal :** rapport pour Grok Bot uniquement — **pas de dépôt Drive** (préparé localement)

---

## 1. Inventaire sources

| Pièce | Fichier local | Octets | Rôle |
|---|---|---:|---|
| Phase A Finaux | `src/A_V7_Finaux.html` | 121668 | **Scorée** (seule pièce dans Drive Finaux LOT_001) |
| Phase A V9 a/b | `src/V9_a.html` + `V9_b.html` | 156277 + 147392 | Plus complète ; liste DX retenue comme canonique proposée |
| B P1 a/b | `B_P1a.html` / `B_P1b.html` | 130912 / 120298 | DX.1 SCA + DX.2 Hypoglycémie |
| B P2 a/b | `B_P2a.html` / `B_P2b.html` | 140728 / 130474 | DX.3–DX.5 |
| B P3 a/b | `B_P3a.html` / `B_P3b.html` | 95449 / 122026 | DX.6–DX.7 — **P3a < 150 Ko** |
| B P4 a/b | `B_P4a.html` / `B_P4b.html` | 109928 / 135292 | DX.8–DX.10 — **P4a < 150 Ko** |
| UNIQUE | `LOT_001_UNIQUE_V0.html` | **195856** | Vue consolidée owner |

Drive Finaux `1BQbx7heLdqDwD4YdrgArhGHfZwcEKKsO` : **uniquement** Appel A V7. Pièces B hors Finaux.

---

## 2. Liste DX — cohérence Phase A ↔ B (contrôle critique §17)

| Rang | Canon (V9 / B) | A V7 Finaux | Cohérence |
|---|---|---|---|
| DX.1 | Syndrome coronarien aigu 🚩 E1 | Hyperhidrose focale primaire | **DIVERGE** |
| DX.2 | Hypoglycémie 🚩 E2 | Hyperhidrose secondaire iatrogène | **DIVERGE** |
| DX.3 | Endocardite infectieuse 🚩 E3 | Hyperthyroïdie | **DIVERGE** |
| DX.4 | Hyperhidrose focale primaire | Hypoglycémie… | **DIVERGE** |
| DX.5 | Symptômes vasomoteurs ménopause | SCA / choc | **DIVERGE** |
| DX.6–10 | Hyperthyroïdie ; TB ; VIH ; Hodgkin ; Phéo | Ordre différent / regroupements | **Désaligné** |

→ **Erreur critique** : dépôt interdit pour tout le lot tant que Phase A Finaux ≠ liste B.

---

## 3. Score Phase A (SSP) — grille V0 §11–12 (notes 2/1/0)

Base : **A V7 Finaux** (121668 o).

| # | Point | Note | Motif court |
|---|---|:---:|---|
| 1 | Définition | 1 | Pas de société savante nommée/datée en P1 |
| 2 | Épidémiologie | 1 | 3 % HUG ; pas OFS/Obsan |
| 3 | Physiopathologie | 1 | Cascade OK ; tableau Lésion→Expl→Tx non conforme |
| 4 | Démarche DX | 2 | Graves avant bénins dans la démarche |
| 5 | Anamnèse | 2 | Drapeaux actionnables |
| 6 | Examen physique | 2 | Normal avant patho |
| 7 | Syndromes | 1 | Présents ; 7.1/7.2/gestes incomplets |
| 8 | Diagnostic positif | 2 | Critères HUG 2016 |
| 9 | Examens | 1 | Gold clinique OK ; Se/Sp/tableaux faibles |
| 10 | Arbre | 1 | Narratif |
| 11 | Prise en charge | 1 | 11.A–D ; **Axhidrox grossesse adouci** |
| 12 | Prévention | 1 | Structure oui, substance mince |
| 13 | Points clés | 1 | Phrase mydriase coupée |
| 14 | Pièges | 2 | Pertinents |

**Total : 19/28 ≈ 67,9 %** — **< 90 %** → refusé.  
**Question finale :** NON.

---

## 4. Phase B — estimation structurelle (non AIPS ligne-à-ligne)

Dix monographies présentes (14 points chacun dans les pièces a/b). Score estimé prudent **≈ 20/28 (71,4 %)** par DX (structure riche, mais non ≥90 tant que AIPS/Se-Sp/situations spéciales non réaudités un par un).  
**Moyenne estimée B ≈ 71,4 %.**  
Fichiers sous seuil poids 150 Ko : **B_P3a (95 Ko)**, **B_P4a (110 Ko)**.

---

## 5. Trois critiques restantes (bloquantes)

1. **Liste DX A Finaux ≠ B/V9** (§9.1 / §17 V0).  
2. **Ordre gravité** : bénin en DX.1 Finaux ; SCA en DX.5 sans rangs E/🚩 V0.  
3. **Axhidrox grossesse** texte adouci (« peut être envisagé… ») ≠ §13.2 AIPS mot pour mot.

---

## 6. Livrable UNIQUE

| Champ | Valeur |
|---|---|
| Fichier | `/workspace/inv-dd/audit-graduel/LOT_001/LOT_001_UNIQUE_V0.html` |
| Octets | **195856** |
| SHA-256 | `d7da75c32e6cb3e8c74e0751b412499690a1dc85e1e8827f47981f66b006e19f` |
| Bande 150–200 Ko | **oui** |

---

## 7. Prêt-pour-dépôt Drive Finaux ?

**NON.**

Motifs : score A 67,9 % ; critiques ≥1 ; question finale NON ; Finaux incomplet (A seul) ; poids B_P3a/P4a < 150 Ko.

**Prochaine action Grok Bot :** figer liste canonique → réécrire Phase A V0 → corriger AIPS → enrichir P3a/P4a → réaudit → puis dépôt/remplacement Finaux.

---

*Audit produit par IA ; non validation clinique médicale.*
