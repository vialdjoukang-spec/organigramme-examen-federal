# LOT_011 — G11 Troubles du sommeil

Date : 2026-10-25, 18:15 Europe/Zurich.

Version corrigée déposée depuis le dépôt, commit de la branche cursor/lot-011-audit-correcteur-v8-4105, PR https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/443

Les scores, la seule dose AIPS (Quviviq, autorisation 68481) et les fichiers sous le seuil de 90 Ko sont décrits dans le STATUT.md du dépôt. Ce fichier Drive est la copie de ce statut.
