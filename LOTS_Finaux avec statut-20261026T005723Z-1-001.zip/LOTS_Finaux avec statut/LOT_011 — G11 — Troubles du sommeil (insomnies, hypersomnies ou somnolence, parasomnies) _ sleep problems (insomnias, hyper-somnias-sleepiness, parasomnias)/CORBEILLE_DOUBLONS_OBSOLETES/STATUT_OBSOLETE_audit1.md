# LOT_011 — G11 Troubles du sommeil

Date : 2026-10-25, 18:15 Europe/Zurich.

- SSP : G11 « Troubles du sommeil » (PROFILES 2023, lot n° 11).
- Audit correcteur V8 : fait. Deux rôles distincts du rédacteur d’origine, et distincts l’un de l’autre : auditeur médical, auditeur linguistique et de conformité. Rapports : `AUDIT_MEDICAL_LOT_011.md`, `AUDIT_LINGUISTIQUE_LOT_011.md`.
- Rédacteurs d’origine : non identifiés dans ce dépôt comme les auditeurs de cette session. Le texte audité n’a pas été réécrit comme une rédaction nouvelle.
- Erreur critique restante : **aucune**.
- Score d’application du prompt (V8 §6.3), moyenne des monographies du fichier :

| Fichier | Monographies | Score | Taille | Seuil dépôt §6.3 et taille 90–200 Ko |
|---|---|---|---|---|
| `LOT_011_Appel_A_V7_G11_Troubles_sommeil.html` | SSP + DX.1 à DX.10 | **90 %** | 151,7 Ko | score oui ; taille oui |
| `LOT_011_Appel_B_V7_Partie_1_DX.1_a_DX.2.html` | DX.1, DX.2 | **93 %** | 92,4 Ko | oui |
| `LOT_011_Appel_B_V7_Partie_2_DX.3_a_DX.5.html` | DX.3 à DX.5 | **89 %** | 89,3 Ko | non |
| `LOT_011_Appel_B_V7_Partie_3_DX.6_a_DX.7.html` | DX.6, DX.7 | **90 %** | 75,1 Ko | score oui ; taille non |
| `LOT_011_Appel_B_V7_Partie_4_DX.8_a_DX.10.html` | DX.8 à DX.10 | **89 %** | 86,2 Ko | non |

- Moyenne non pondérée des cinq fichiers : **90 %**.
- Les parties 2, 3 et 4 sont sous 90 Ko parce que le remplissage dupliqué a été retiré. Il n’a pas été remplacé par du texte inventé.
- Appel B : les quatre HTML étaient absents du dépôt git local au début de l’audit et présents dans ce dossier Drive. Ils ont été repris octet pour octet avant correction (90 526, 90 482, 92 472, 90 319 octets). Ils sont aussi sur main via la PR #437.
- PR de la version corrigée : https://github.com/vialdjoukang-spec/organigramme-examen-federal/pull/443
- Seule posologie chiffrée ajoutée : Quviviq® (daridorexant), information professionnelle suisse, état juillet 2024, numéro d’autorisation **68481** lu dans la rubrique du texte. Toute autre dose reste « À vérifier (AIPS) ».
- Les HTML corrigés de cette version sont dans la PR. Leur remplacement Drive fichier par fichier est demandé à Grok Bot si l’envoi HTML intégral n’est pas confirmé dans le même fil, afin d’éviter une conversion en Google Docs.
- Contenu produit par IA à partir des sources citées ; non validé cliniquement par un médecin.
