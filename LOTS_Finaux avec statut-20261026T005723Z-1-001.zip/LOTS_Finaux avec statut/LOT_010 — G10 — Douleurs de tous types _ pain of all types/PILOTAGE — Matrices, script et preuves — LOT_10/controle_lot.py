#!/usr/bin/env python3
"""Contrôle reproductible : structure, preuves de cotation, calculs, chaîne A→B4.

Ce programme ne juge pas l'exactitude médicale d'une phrase et ne crée aucune note.
Il valide et agrège des cotations explicites de personnes/agents indépendants.
"""
import argparse
import hashlib
import html
import json
import re
import copy
from datetime import datetime, timezone
from collections import defaultdict
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent

def read_json(p):
    return json.loads(Path(p).read_text())

def fingerprint(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def plain(s):
    return ' '.join(html.unescape(re.sub(r'<[^>]+>', ' ', s)).split())

class InspectHTML(HTMLParser):
    VOID = {'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack=[]; self.errors=[]; self.ids={}; self.duplicate_ids=[]
        self.sections=defaultdict(set); self.links=[]; self.details=0
        self.tables=0; self.unwrapped_tables=0; self.forbidden=[]
        self.anchor_text=defaultdict(str); self.anchor_sections={}
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if 'id' in a:
            if a['id'] in self.ids:self.duplicate_ids.append(a['id'])
            self.ids[a['id']]=tag
            contexts=[b for t,b in self.stack if t=='section' and 'data-point' in b]
            if 'data-point' in a:contexts.append(a)
            if contexts:self.anchor_sections[a['id']]=(contexts[-1].get('data-monograph'),contexts[-1].get('data-point'))
        if tag=='section' and 'data-monograph' in a and 'data-point' in a:
            self.sections[a['data-monograph']].add(a['data-point'])
        if tag=='details':self.details+=1
        if tag=='table':
            self.tables+=1
            if not any(t=='div' and 'overflow-x' in b.get('style','') and 'auto' in b.get('style','') for t,b in self.stack):self.unwrapped_tables+=1
        if 'title' in a:self.forbidden.append('attribut title')
        if tag=='script':self.forbidden.append('script')
        if tag in {'link','img','iframe'} and any(re.match(r'https?://',a.get(k,'')) for k in ('href','src')):self.forbidden.append('ressource externe '+tag)
        if tag=='a' and 'href' in a:self.links.append(a['href'])
        if tag not in self.VOID:self.stack.append((tag,a))
    def handle_startendtag(self,tag,attrs):
        self.handle_starttag(tag,attrs)
        if tag not in self.VOID:self.handle_endtag(tag)
    def handle_endtag(self,tag):
        if tag in self.VOID:return
        if not self.stack or self.stack[-1][0]!=tag:
            self.errors.append('Fermeture inattendue : '+tag)
            return
        self.stack.pop()
    def handle_data(self,data):
        if any(t in ('style','script','head') or 'hidden' in a or 'display:none' in a.get('style','').replace(' ','') for t,a in self.stack):return
        for tag,a in self.stack:
            if 'id' in a:self.anchor_text[a['id']]+=' '+data

def inspect_file(p):
    raw=Path(p).read_text(); parser=InspectHTML(); parser.feed(raw)
    errors=list(parser.errors)
    if parser.stack:errors.append('Balises non fermées : '+str([t for t,a in parser.stack]))
    if not raw.lstrip().lower().startswith('<!doctype html>'):errors.append('DOCTYPE absent')
    if not re.search(r'</html>\s*<!--\s*FIN_FICHIER LOT_10_[^>]+-->\s*$',raw,re.I):errors.append('Fin de fichier absente ou incorrecte')
    if parser.duplicate_ids:errors.append('Identifiants dupliqués : '+str(parser.duplicate_ids))
    broken=[u for u in parser.links if u.startswith('#') and u[1:] not in parser.ids]
    if broken:errors.append('Liens internes invalides : '+str(broken))
    if parser.forbidden:errors.append('Éléments interdits : '+str(parser.forbidden))
    if parser.unwrapped_tables:errors.append(f'{parser.unwrapped_tables} tableaux non enveloppés')
    if max(map(len,raw.splitlines()),default=0)>3000:errors.append('Une ligne dépasse 3000 caractères')
    size=Path(p).stat().st_size
    if not 90000<=size<=200000:errors.append(f'Taille hors plage 90000–200000 : {size}')
    for mono,points in parser.sections.items():
        if points != set(map(str,range(1,15))):errors.append(mono+' : rubriques manquantes ou surnuméraires '+str(points))
        for sub in 'abcd':
            if f'{mono.lower()}-p11-{sub}' not in parser.ids:errors.append(mono+' : sous-partie 11.'+sub+' absente')
    if not parser.sections:errors.append('Aucune monographie identifiée')
    if 'non validé cliniquement par un médecin' not in raw:errors.append('Mention IA/non-validation manquante')
    return {'file':str(p),'sha256':fingerprint(p),'size_bytes':size,'monographs':list(parser.sections),'details':parser.details,'tables':parser.tables,'errors':errors,'mobile':'NON VÉRIFIÉ PAR CE SCRIPT'}, parser, plain(raw)

def score_cells(cells, criteria, ids=None, visible=None, anchor_text=None, anchor_sections=None, mono=None):
    valid_ids={c['id'] for c in criteria}; errors=[]; earned=0; possible=0; unknown=0; out=[]
    if set(cells)!=valid_ids:errors.append('Critères manquants ou inattendus : '+str(sorted(valid_ids^set(cells))))
    for c in criteria:
        v=cells.get(c['id'],{}); s=v.get('score'); reason=v.get('reason','').strip()
        if not reason:errors.append(c['id']+' : justification absente')
        if s=='NA':
            forbidden_na=c['id'] in {'T01','T03','T05','T06','T07','T11','T12','T13','T14','T15','T16','T17','T18'}
            if forbidden_na or not v.get('na_approved') or not v.get('na_approved_by') or len(reason)<30:errors.append(c['id']+' : sans-objet interdit, non approuvé ou insuffisamment justifié');unknown+=1;possible+=2
        elif s is None:unknown+=1;possible+=2
        elif type(s) is int and s in (0,1,2):
            earned+=s;possible+=2
            if s>0 and ids is not None:
                if v.get('anchor') not in ids:errors.append(c['id']+' : ancre justificative absente')
                q=plain(v.get('quote',''))
                target=plain(anchor_text.get(v.get('anchor'),'')) if anchor_text is not None else visible
                if len(q)<10 or q not in target:errors.append(c['id']+' : passage justificatif non retrouvé dans son ancre')
                if anchor_sections is not None and 'point' in c and anchor_sections.get(v.get('anchor'))!=(mono,str(c['point'])):errors.append(c['id']+' : preuve hors de sa rubrique/monographie')
                for sid in v.get('source_ids',[]):
                    if not any(k.lower()==sid.lower() for k in ids):errors.append(c['id']+' : source bibliographique inconnue '+sid)
            if c.get('subchecks'):
                sub=v.get('subchecks',[])
                if not isinstance(sub,list) or len(sub)!=len(c['subchecks']) or any(not isinstance(x,dict) or type(x.get('score')) is not int or x['score'] not in (0,1,2) or not x.get('reason') or not x.get('anchor') for x in sub):errors.append(c['id']+' : cinq situations particulières à évaluer séparément')
                else:
                    expected=2 if all(x['score']==2 for x in sub) else 0 if all(x['score']==0 for x in sub) else 1
                    if s!=expected:errors.append(c['id']+' : note incompatible avec les cinq sous-contrôles')
                    for x in sub:
                        if anchor_sections is not None and anchor_sections.get(x['anchor'])!=(mono,str(c['point'])):errors.append(c['id']+' : sous-preuve hors de la rubrique')
                        if anchor_text is not None and (len(plain(x.get('quote','')))<10 or plain(x.get('quote','')) not in plain(anchor_text.get(x['anchor'],''))):errors.append(c['id']+' : extrait de sous-contrôle absent')
        else:unknown+=1;possible+=2;errors.append(c['id']+' : note invalide')
        out.append({**c,**v})
    return {'earned':earned,'possible':possible,'unknown':unknown,'out_of_10':round(10*earned/possible,6) if possible and not unknown else None,'errors':errors,'cells':out}

def aggregate(p,audit_paths):
    req=read_json(ROOT/'requirements.json'); structural,parser,visible=inspect_file(p)
    reports=[read_json(f) for f in audit_paths]; errors=list(structural['errors']); results=[]
    if sorted(r.get('role','') for r in reports)!=['linguistique','medical','writer']:errors.append('Il faut exactement un rédacteur, un auditeur médical et un auditeur linguistique')
    report_authors=[r.get('author','').strip() for r in reports]
    if len(set(report_authors))!=3 or any(len(x)<3 or x.lower() in ('à renseigner','a renseigner','unknown') for x in report_authors):errors.append('Les trois auteurs doivent être nommés et distincts')
    for r in reports:
        if r.get('sha256')!=structural['sha256']:errors.append('Audit lié à une autre empreinte : '+r.get('role','?'))
        if not r.get('author'):errors.append('Auteur de cotation absent')
    independent=[r for r in reports if r.get('role') in ('medical','linguistique')]
    authors={r.get('author') for r in independent}
    complete_roles={r.get('role') for r in independent}=={'medical','linguistique'} and len(authors)==2
    if not complete_roles:errors.append('Deux audits indépendants distincts sont nécessaires')
    for mono in parser.sections:
        merged={}; selfcells={}
        for r in reports:
            rc=r.get('monographs',{}).get(mono,{})
            if r.get('role')=='writer':selfcells=rc;continue
            for c in req['criteria']:
                if c['owner']==r.get('role') and c['id'] in rc:merged[c['id']]=rc[c['id']]
        score=score_cells(merged,req['criteria'],parser.ids,visible,parser.anchor_text,parser.anchor_sections,mono)
        writer=score_cells(selfcells,req['criteria'],parser.ids,visible,parser.anchor_text,parser.anchor_sections,mono) if selfcells else None
        if writer is None:errors.append(mono+' : auto-contrôle du rédacteur absent')
        elif writer['errors'] or writer['unknown']:errors.append(mono+' : auto-contrôle incomplet ou invalide')
        points=[]
        for n in range(1,15):
            cs=[c for c in req['criteria'] if c['point']==n]
            cells={c['id']:merged.get(c['id'],{}) for c in cs}
            detail=score_cells(cells,cs,parser.ids,visible,parser.anchor_text,parser.anchor_sections,mono)
            points.append({'point':n,**detail})
        errors.extend(mono+' : '+s for s in score['errors'])
        results.append({'monograph':mono,'independent':score,'writer':writer,'points':points,'full_points_14':sum(any(v.get('score')==2 for v in pt['cells']) and all(v.get('score')==2 or (v.get('score')=='NA' and v.get('na_approved') and v.get('na_approved_by')) for v in pt['cells']) for pt in points)})
    finals=[]
    for r in independent:
        for mono in parser.sections:
            f=r.get('final_answer',{}).get(mono,{})
            if f.get('answer')!='oui' or not f.get('reason'):errors.append(f'Question 6.2 non satisfaite : {r.get("role")} / {mono}')
        if r.get('critical_errors'):errors.append('Erreur critique ouverte : '+r['role'])
        finals.append({'role':r['role'],'local':r.get('local',{})})
    local_merged={}
    for c in req['local_criteria']:
        values=[r.get('local',{}).get(c['id'],{}) for r in independent]
        vals=[x.get('score') for x in values]
        if any(not str(x.get('reason','')).strip() for x in values):errors.append('Justification transversale absente : '+c['id'])
        if len(vals)==2 and all(type(s) is int for s in vals):local_merged[c['id']]={'score':min(vals),'reason':' | '.join(x.get('reason','') for x in values)}
        elif len(vals)==2 and all(x.get('score')=='NA' and x.get('na_approved') and x.get('na_approved_by') for x in values):local_merged[c['id']]={'score':'NA','na_approved':True,'na_approved_by':' | '.join(x['na_approved_by'] for x in values),'reason':' | '.join(x.get('reason','') for x in values)}
        else:local_merged[c['id']]={'score':None,'reason':'Non évalué par les deux auditeurs.'}
        if c['blocking'] and local_merged[c['id']]['score'] not in (2,'NA'):errors.append('Verrou transversal non satisfait : '+c['id'])
    local_score=score_cells(local_merged,req['local_criteria'])
    errors.extend(local_score['errors'])
    global_score=None if any(x['independent']['out_of_10'] is None for x in results) else round(sum(x['independent']['out_of_10'] for x in results)/len(results),6)
    if global_score is None or global_score<9:errors.append('Score indépendant inférieur à 9/10 ou incomplet')
    before_deposit=[x for x in errors if x!='Verrou transversal non satisfait : T18']
    return {'structural':structural,'monographs':results,'transversal':local_score,'score_10':global_score,'upload_allowed':not before_deposit,'release_allowed':not errors,'errors':errors,'reports':reports}

def render_matrix(result,dest,mode='independent'):
    e=lambda s:html.escape(str(s)); rows=[]
    for m in result['monographs']:
        for p in m['points']:
            cells=[]
            for c in p['cells']:
                cells.append('<td><details><summary>'+e(c['id'])+' : '+e(c.get('score') if c.get('score') is not None else 'NE')+'/2</summary><p>'+e(c['question'])+'</p><p>'+e(c.get('reason','Non évalué'))+'</p><blockquote>'+e(c.get('quote',''))+'</blockquote><p>Ancre : '+e(c.get('anchor','—'))+'</p></details></td>')
            while len(cells)<11:cells.append('<td>—</td>')
            raw_score=str(p['earned'])+'/'+str(p['possible']) if not p['unknown'] else 'NON ÉVALUÉ (maximum '+str(p['possible'])+')'
            rows.append('<tr><th>'+e(m['monograph'])+' / Point '+str(p['point'])+'</th>'+''.join(cells)+'<td>'+raw_score+'</td><td>'+e(p['out_of_10'] if p['out_of_10'] is not None else 'NON ÉVALUÉ')+'</td></tr>')
    headers='<th>Monographie / partie</th>'+''.join('<th>Critère '+str(n)+'</th>' for n in range(1,12))+'<th>Total brut</th><th>Note /10</th>'
    body='<!DOCTYPE html>\n<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>LOT_10 — Matrice de contrôle</title><style>body{font:16px Tahoma,sans-serif;color:#173348;background:#f0f8ff;padding:24px}table{border-collapse:collapse;background:white}td,th{border:1px solid #b5d2df;padding:10px;vertical-align:top;min-width:150px}summary{cursor:pointer;color:#126743}h1{font-size:24px}blockquote{margin:10px 0;font-size:14px}p{max-width:100ch}</style></head><body><h1>LOT_10 — Matrice de contrôle</h1><p>Le contrôle sépare les notes du rédacteur des cotations indépendantes. Une note non évaluée n’est pas un zéro ni une réussite. Les critères sans objet exigent une justification approuvée.</p><p>Empreinte du cours : '+e(result['structural']['sha256'])+'</p><p>Note indépendante : '+e(result['score_10'])+'/10. Dépôt autorisé : '+e(result['release_allowed'])+'.</p><div style="overflow-x:auto;"><table><thead><tr>'+headers+'</tr></thead><tbody>'+''.join(rows)+'</tbody></table></div><h2>Critères transversaux</h2><div style="overflow-x:auto;"><table><tr><th>Critère</th><th>Question</th><th>Note /2</th><th>Justification</th></tr>'+''.join('<tr><td>'+e(c['id'])+'</td><td>'+e(c['question'])+'</td><td>'+e(c.get('score','NE'))+'</td><td>'+e(c.get('reason',''))+'</td></tr>' for c in result['transversal']['cells'])+'</table></div><h2>Écarts ouverts</h2><ul>'+''.join('<li>'+e(x)+'</li>' for x in result['errors'])+'</ul><p>Ce script ne certifie pas la sécurité clinique ni une réussite à l’examen. Les auditeurs répondent de leurs constats sur l’empreinte indiquée.</p></body></html>'
    total=result['transversal'];t_raw=str(total['earned'])+'/'+str(total['possible']) if not total['unknown'] else 'NON ÉVALUÉ'
    footer='<tfoot><tr><th colspan="2">Total brut / maximum</th><td>'+t_raw+'</td><td>Note /10 : '+e(total['out_of_10'] if total['out_of_10'] is not None else 'NON ÉVALUÉ')+'</td></tr></tfoot>'
    body=body.replace('</table></div><h2>Écarts ouverts',footer+'</table></div><h2>Écarts ouverts')
    Path(dest).write_text(body)

def writer_matrix(result):
    """Présenter l'auto-contrôle sans le confondre avec une validation indépendante."""
    out=copy.deepcopy(result);req=read_json(ROOT/'requirements.json');notes=[]
    for m in out['monographs']:
        cells={c['id']:c for c in (m.get('writer') or {}).get('cells',[])}
        m['points']=[]
        for n in range(1,15):
            cs=[c for c in req['criteria'] if c['point']==n]
            m['points'].append({'point':n,**score_cells({c['id']:cells.get(c['id'],{}) for c in cs},cs)})
        notes.append((m.get('writer') or {}).get('out_of_10'))
    wr=next((r for r in out['reports'] if r.get('role')=='writer'),{})
    out['transversal']=score_cells(wr.get('local',{}),req['local_criteria'])
    out['score_10']=round(sum(notes)/len(notes),6) if notes and all(n is not None for n in notes) else None
    out['release_allowed']=False;out['errors']=['Cette grille contient uniquement l’auto-évaluation du rédacteur. Elle ne vaut pas autorisation de dépôt.']
    return out

def init_assessment(p,role,dest):
    req=read_json(ROOT/'requirements.json');structure,parser,visible=inspect_file(p)
    template=lambda c:{'score':None,'reason':'À évaluer.','anchor':'','quote':'','source_ids':[],'na_approved':False}
    out={'file':Path(p).name,'sha256':fingerprint(p),'role':role,'author':'À RENSEIGNER','monographs':{m:{c['id']:template(c) for c in req['criteria'] if role=='writer' or c['owner']==role} for m in parser.sections},'local':{c['id']:template(c) for c in req['local_criteria']},'critical_errors':[],'final_answer':{m:{'answer':'pas sûr','reason':'À évaluer.'} for m in parser.sections}}
    Path(dest).write_text(json.dumps(out,ensure_ascii=False,indent=2))

def check_chain(state_path):
    state=read_json(state_path);order=['APPEL_A','B1','B2','B3','B4']
    expected={'APPEL_A':{'SSP'},'B1':{'DX1','DX2'},'B2':{'DX3','DX4','DX5'},'B3':{'DX6','DX7'},'B4':{'DX8','DX9','DX10'}}
    errors=[];completed=[];next_stage=None
    if state.get('order')!=order:errors.append('Ordre de chaîne incorrect')
    if any(s.get('status')=='TERMINE' for s in state.get('stages',{}).values()):
        manifest=ROOT/state.get('diagnostics_path','')
        if not manifest.is_file() or fingerprint(manifest)!=state.get('diagnostics_sha256'):errors.append('Liste réelle de diagnostics absente ou modifiée après gel')
    for key in order:
        step=state.get('stages',{}).get(key,{})
        if step.get('status')!='TERMINE':
            if next_stage is None:next_stage=key
            continue
        if next_stage is not None:errors.append('Une étape ultérieure est déclarée terminée avant '+next_stage)
        monos=set();fs=step.get('files',[])
        if not fs:errors.append(key+' : aucun fichier lié')
        for f in fs:
            path=ROOT/f.get('path','');audit_path=ROOT/f.get('audit_path','')
            if not path.is_file() or not audit_path.is_file():errors.append(key+' : pièce locale absente');continue
            audit=read_json(audit_path)
            if not audit.get('release_allowed'):errors.append(key+' : audit sans autorisation finale')
            if audit.get('structural',{}).get('sha256')!=fingerprint(path):errors.append(key+' : empreinte modifiée après audit')
            if f.get('drive_size_bytes')!=path.stat().st_size or not f.get('drive_url'):errors.append(key+' : dépôt non vérifié')
            monos.update(audit.get('structural',{}).get('monographs',[]))
        if monos!=expected[key]:errors.append(key+' : identités de monographies incorrectes '+str(monos))
        if step.get('diagnostics_sha256')!=state.get('diagnostics_sha256') or not state.get('diagnostics_sha256'):errors.append(key+' : liste de diagnostics non figée ou discordante')
        completed.append(key)
    if state.get('status')=='TERMINE' and len(completed)!=5:errors.append('Achèvement global sans cinq étapes terminées')
    return {'completed':completed,'next':next_stage,'finished':len(completed)==5 and not errors,'errors':errors}

def prepare_stage(stage,state_path,author):
    chain=check_chain(state_path)
    if chain['errors'] or chain['next']!=stage:raise ValueError('Cette étape n’est pas autorisée : '+json.dumps(chain,ensure_ascii=False))
    prompt=(ROOT/'PROMPT_V7.md').read_text();req=read_json(ROOT/'requirements.json')
    if hashlib.sha256(prompt.encode()).hexdigest()!=req['prompt_sha256']:raise ValueError('Le prompt a changé ; régénérer puis relire les critères')
    record={'stage':stage,'author':author,'read_at':datetime.now(timezone.utc).isoformat(),'prompt_sha256':req['prompt_sha256'],'requirements_sha256':fingerprint(ROOT/'requirements.json'),'note':'Cette lecture de rappel ne remplace pas la lecture humaine/agent intégrale des exigences.'}
    (ROOT/f'LECTURE_EXIGENCES_{stage}.json').write_text(json.dumps(record,ensure_ascii=False,indent=2))
    print(prompt)
    print('\nGRILLE DE CONTRÔLE APRÈS RÉDACTION :\n'+json.dumps(req,ensure_ascii=False,indent=2))

def main():
    a=argparse.ArgumentParser(); sub=a.add_subparsers(dest='cmd',required=True)
    p=sub.add_parser('inspect');p.add_argument('html')
    p=sub.add_parser('init');p.add_argument('html');p.add_argument('role',choices=['writer','medical','linguistique']);p.add_argument('output')
    p=sub.add_parser('audit');p.add_argument('html');p.add_argument('assessments',nargs='+');p.add_argument('--output',required=True)
    p=sub.add_parser('chain');p.add_argument('state')
    p=sub.add_parser('prepare');p.add_argument('stage',choices=['APPEL_A','B1','B2','B3','B4']);p.add_argument('--state',required=True);p.add_argument('--author',required=True)
    args=a.parse_args()
    if args.cmd=='inspect':print(json.dumps(inspect_file(args.html)[0],ensure_ascii=False,indent=2))
    elif args.cmd=='init':init_assessment(args.html,args.role,args.output)
    elif args.cmd=='chain':print(json.dumps(check_chain(args.state),ensure_ascii=False,indent=2))
    elif args.cmd=='prepare':prepare_stage(args.stage,args.state,args.author)
    else:
        result=aggregate(args.html,args.assessments);out=Path(args.output);out.write_text(json.dumps(result,ensure_ascii=False,indent=2));render_matrix(result,out.with_suffix('.html'))
        writer_path=out.with_name(out.stem+'_REDACTEUR.html');render_matrix(writer_matrix(result),writer_path,mode='writer')
        s=writer_path.read_text().replace('Matrice de contrôle','Auto-contrôle du rédacteur').replace('Note indépendante :','Note auto-évaluée :');writer_path.write_text(s)
        print(json.dumps({'score_10':result['score_10'],'release_allowed':result['release_allowed'],'errors':result['errors']},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
