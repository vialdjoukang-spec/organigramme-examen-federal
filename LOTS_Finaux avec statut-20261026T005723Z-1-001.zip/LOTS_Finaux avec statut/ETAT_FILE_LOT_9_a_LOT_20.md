# PROFILES 2023 — File de production LOT_9 à LOT_20

Dernière mise à jour : 2026-10-23T14:40:00+02:00 (Europe/Zurich).
Mission donnée par Vial le 23.10.2026 : « On fera graduellement du LOT_9 au LOT20. Tâche : LOT_9 exclusivement maintenant. »

Ce fichier suit la mission LOT_9 à LOT_20. Le fichier ETAT_FILE.md (LOT_1 à LOT_8) reste inchangé : LOT_1 y reste ACTIF dans son propre workflow. Le connecteur Google Drive utilisé ici ne permet pas l'édition en place ; créer un second ETAT_FILE.md aurait produit un doublon interdit par le V7 §13. Ce fichier dédié évite ce doublon.

| LOT | SSP | Statut | Fichier en cours | Score V7 | Score 14 points |
|---|---|---|---|---|---|
| LOT_9 | G9 Prurit (itching) | ACTIF | Appel A — collecte de preuves (evidence) en cours | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_10 | G10 Douleur (pain of all types) | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_11 | G11 Troubles du sommeil | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_12 | G12 Œdème (diffus ou localisé) | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_13 | G13 Mort non naturelle | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_14 | G14 Mort inattendue ou soudaine | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_15 | G15 Prise de poids, obésité | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_16 | G16 Perte de poids, perte d'appétit | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_17 | S1.1 Diplopie, ptosis, mouvements oculaires anormaux | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_18 | S1.2 Perte de vision | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_19 | S1.3 Altération de la voix | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |
| LOT_20 | S1.4 Visage asymétrique, déformation | EN ATTENTE | — | NON ÉVALUÉ | NON ÉVALUÉ |

Noms des SSP d'après la liste officielle PROFILES 2023 (smifk-cims.ch/profiles-2023/ssps), consultée le 23.10.2026.

## Règle de transition

Un seul lot ACTIF à la fois dans cette file. Ordre 9 → 20. Un lot devient TERMINÉ uniquement si : score V7 §6.3 de 100 % audité, toutes les questions §6.1 satisfaites pour les 14 points de chaque diagnostic, réponse « oui » à §6.2, checklist §16 cochée pour les 5 fichiers. Aucun score auto-attribué sans audit.

## Veille

Nom : VEILLE_PROFILES_LOT_9_a_LOT_20. ID : c1faf25e-81ad-491d-8bbb-2e24b02b7004. Fréquence : quotidienne à 07:00 Europe/Zurich (déclenchement possible jusqu'à 60 min plus tard). Prochain déclenchement attendu : 24.10.2026 entre 07:00 et 08:00, heure suisse. Limite technique assumée : l'outil de planification accepte au maximum une exécution par jour ; la relance de 60 minutes exigée par le prompt de démarrage est impossible ici. La reprise manuelle par le mot « CONTINUE » reste valable.

## Lecture et acquisition réellement effectuée (session du 23.10.2026)

Plan A : GitHub, branche claude/zealous-noether-c3jut5, répertoire claude/LOT Organigramme.
- PROMPT_ULTIME_PRODUCTION_LOTS_V7.md : lu en entier (version téléversée par Vial, identique à la référence).
- SOURCES_OFFICIELLES_CH/INDEX_SOURCES_SUISSES.md : lu en entier.
- Liste officielle des SSP (smifk-cims.ch/profiles-2023/ssps) : ouverte ; LOT_9 = G9 itching (prurit) confirmé.
- reprise_HELP_reponses/VERIF_1.json, VERIF_2.json, VERIF_3.json, VERIF_4.json : ouverts intégralement via GitHub ; seuls les champs a_injecter sont conservés. Aucun ne concerne le prurit : VERIF_1 à VERIF_4 couvrent les LOT_1 à LOT_8 et LOT_228 à LOT_231. A-079 (VERIF_4) concerne la lévothyroxine IV du LOT_8 : rien d'injectable dans le LOT_9. Leurs leçons méthodologiques s'appliquent (numéros Swissmedic vérifiés dans la liste, produits « export uniquement » interdits, versions de recommandations vérifiées).
- LOT_9_Liste_Corrections_Audit.docx : absent du dépôt (aucun LOT_9 n'existe encore nulle part) ; les corrections des LOT_1 à LOT_8 et les audits précédents servent de matrice d'erreurs à ne pas reproduire.
- Les trois listes Swissmedic (état au 30.09.2026) : consultation en cours pour chaque spécialité citée.
